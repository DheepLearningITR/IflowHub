import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def jsonSlurper = new JsonSlurper();
    def apiResult = jsonSlurper.parse(body);
    
    def properties = message.getProperties();
    
    // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    def db_schema = properties.get('Database_Schema_Name');
    
     message.setProperty("projectOrigin", apiResult.origin);
    
    sqlStatement.root {
        sqlStatement.InsertStatement {
            sqlStatement.app_sourcing_projects(action: 'INSERT') {
                sqlStatement.table(db_schema + '.APP_SOURCING_PROJECTS')
                sqlStatement.access {
                    sqlStatement.TITLE(apiResult.title)
                    sqlStatement.DESCRIPTION(apiResult.description)
                    sqlStatement.INTERNAL_ID(apiResult.internalId)
                    sqlStatement.STATUS(apiResult.status)
                    sqlStatement.BEGIN_DATE(apiResult.beginDate)
                    sqlStatement.OWNER_NAME(apiResult.owner.name)
                    sqlStatement.PARENT_DOCUMENT_ID(apiResult.parentDocumentId)
                    sqlStatement.PROCESS_STATUS(apiResult.processStatus)
                    sqlStatement.CURRENCY_CODE(apiResult.currency)
                    sqlStatement.ORIGIN(apiResult.origin)
                    if (apiResult.baselineSpend) {
                        sqlStatement.BASE_LINE_SPEND_AMOUNT(apiResult.baselineSpend.amount)
                        sqlStatement.BASE_LINE_SPEND_CURRENCY(apiResult.baselineSpend.currency)
                    }
                    sqlStatement.CREATEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                    sqlStatement.CREATEDBY(properties.get('Extension_User'))
                    for (customField in apiResult.sourcingProjectCustomFields) {
                        if (customField.textValue && !customField.textValue.empty) {
                            switch(customField.fieldId) {
                                case 'cus_NombredelaGestiondeCompra':
                                    sqlStatement.NOMBRE_GC(customField.textValue[0])
                                    break;
                                case 'cus_NReferenciaGestiondeCompra':
                                     sqlStatement.NOMBRE_REF_GC(customField.textValue[0])
                                    break;
                                case 'cus_TipodeGestiondeCompra':
                                    sqlStatement.NOMBRE_TIPO_GC(customField.textValue[0])
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
            }
        }
    };
    
    message.setBody(writer.toString());
  
    return message;

}