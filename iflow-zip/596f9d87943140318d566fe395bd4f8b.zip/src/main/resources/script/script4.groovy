import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def jsonSlurper = new JsonSlurper();
    def apiResult = jsonSlurper.parse(body);
    
    def properties = message.getProperties();
    valueCount = properties.get("count");
    valueCount = valueCount + 1;
    message.setProperty("count", valueCount);
    message.setProperty("projectId", apiResult.parentProjectId);
    
    // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    def db_schema = properties.get('Database_Schema_Name');
    
    sqlStatement.root {
        sqlStatement.UpdateStatement {
            sqlStatement.app_sourcing_events(action: 'UPDATE') {
                sqlStatement.table(db_schema + '.APP_SOURCING_EVENTS')
                sqlStatement.access {
                    sqlStatement.PARENT_PROJECT_ID(apiResult.parentProjectId)
                    sqlStatement.HAS_AWARD(apiResult.hasAward)
                    sqlStatement.EVENT_STATE_NAME(apiResult.eventStateName)
                    sqlStatement.STATUS(apiResult.status)
                    sqlStatement.EVENT_TYPE_NAME(apiResult.eventTypeName)
                    sqlStatement.MODIFIEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                    sqlStatement.MODIFIEDBY(properties.get('Extension_User'))
                    sqlStatement.STEP_FLOW('EVENT_DETAIL')
                }
                sqlStatement.key {
                    sqlStatement.INTERNAL_ID(apiResult.internalId)
                }
            }
        }
    };
   
   
   message.setBody(writer.toString());
  
    return message;
}