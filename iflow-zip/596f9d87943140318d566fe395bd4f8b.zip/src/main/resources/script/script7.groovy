import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();
    
    def headers = message.getHeaders();

    def properties = message.getProperties();
    def projectId = properties.get("projectId");
    
    def objectError = 'Unknown';
    def stepFlow = 'ERROR';
    def isTemplate = false;
    def comments = ''
    
    if (body.contains('https://openapi.ariba.com/api/sourcing-project-management/v2/prod/projects/')) {
        objectError = 'Project';
        stepFlow = 'PROJECT_ERROR';
        
        def errorType = 'Unknown';
        if (body.contains('statusCode: 400')) {
            errorType = '400-BadRequest';
            isTemplate = true;
        } 
        else if (body.contains('statusCode: 500')) {
            errorType = '500-InternalServerError';
            isTemplate = true;
        }
        
        def messageError = 'There was an error in ' + objectError + '. Error: ' + errorType;
        if (projectId && projectId.size()>2 && projectId.substring(0,2).toUpperCase()=='CW') {
            messageError = 'Project is a Contract. ' + messageError;
        }
        comments = messageError;
    } else if (body.contains('[301]: unique constraint violated: Table(APP_SOURCING_PROJECTS)')) {
        stepFlow = 'PROJECT_DETAIL';
        isTemplate = false;
        comments = 'The Project already exist in APP_SOURCING_PROJECTS';
    } else {
        comments = body.size() > 500 ? body.substring(0,500) : body;
    }
    
    // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    def db_schema = properties.get('Database_Schema_Name');
    
    sqlStatement.root {
        sqlStatement.UpdateStatement {
            sqlStatement.app_sourcing_events(action: 'UPDATE') {
                sqlStatement.table(db_schema + '.APP_SOURCING_EVENTS')
                sqlStatement.access {
                    sqlStatement.STEP_FLOW(stepFlow)
                    sqlStatement.COMMENTS(comments)
                    sqlStatement.IS_TEMPLATE(isTemplate)
                    sqlStatement.MODIFIEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                    sqlStatement.MODIFIEDBY(properties.get('Extension_User'))
                }
                sqlStatement.key {
                    sqlStatement.INTERNAL_ID(properties.get("eventId"))
                }
            }
        }
    };
   
   message.setBody(writer.toString());

    return message;
}