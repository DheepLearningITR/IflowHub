/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.lang.String;
def Message processData(Message message) {
     def sbBody = message.getBody(String.class);
    def jsonParser = new JsonSlurper();
    def sbRatePlan = jsonParser.parseText(sbBody);
    def sbRatePlans = sbRatePlan.rateplan;
 
    def map = message.getProperties();
    def marketId = map.marketId;
    def productCode = map.productCode;
    def createdAt = map.createdAt;
    def infiniteDate = "9999-12-31" ;
    
    sbRatePlans.put("marketId", marketId);
    sbRatePlans.put("productCode", productCode);
      
     def sbRatePlansJson = JsonOutput.toJson(sbRatePlans);
     
     def sbRatePlanSnapshots = jsonParser.parseText(sbRatePlansJson);
      sbRatePlanSnapshots['snapshots'].sort{ a, b -> b.effectiveAt <=> a.effectiveAt}
    
     def endDate;
     def baseDate;
     def startDate;
     

    sbRatePlanSnapshots.snapshots.eachWithIndex{it,index->

               if(it.effectiveAt == null){
               Calendar c = Calendar.getInstance();
               String dateFormat = "yyyy-MM-dd";
               c.setTime(new SimpleDateFormat(dateFormat).parse(createdAt));
               DateFormat dateFormat_required = new SimpleDateFormat(dateFormat);
               def converted_datetime=dateFormat_required.format(c.getTime());
               it.put("effectiveAt", converted_datetime); 
               baseDate = createdAt;
              }

              if(it.endDate == null){
                   Calendar c = Calendar.getInstance();
                   String dateFormat = "yyyy-MM-dd";
                   DateFormat dateFormat_required = new SimpleDateFormat(dateFormat);
                  
                   if(index == 0){
                   c.setTime(new SimpleDateFormat(dateFormat).parse(infiniteDate));
                   }
                   else{
                        c.setTime(new SimpleDateFormat(dateFormat).parse(startDate));
                        c.add(Calendar.DATE, -1);
                   }
                   endDate = dateFormat_required.format(c.getTime());
              it.put("endDate", endDate); 
            }
  

          startDate = it.effectiveAt;
           
               }

       def sbFinalRatePlansJson = JsonOutput.toJson(sbRatePlanSnapshots);
       message.setBody(sbFinalRatePlansJson);
       return message;
       
}