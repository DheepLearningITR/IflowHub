import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.lang.String;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String customFunc(String arg1){
    
    Calendar c = Calendar.getInstance();
    String dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS";
    c.setTime(new SimpleDateFormat(dateFormat).parse(arg1));
    c.add(Calendar.YEAR, 1);
    DateFormat dateFormat_required = new SimpleDateFormat(dateFormat);
    def converted_datetime=dateFormat_required.format(c.getTime());
    return converted_datetime;

}