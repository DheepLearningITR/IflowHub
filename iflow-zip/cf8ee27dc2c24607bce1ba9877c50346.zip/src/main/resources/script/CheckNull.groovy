import com.sap.it.api.mapping.*;

def String checkNull(String arg1){
    
    if(arg1)
    return true;
    else
	return false; 
}