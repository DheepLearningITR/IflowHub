import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;


def Message processData(Message msg) {
    def helperValMap = ITApiFactory.getApi(ValueMappingApi.class, null)
    def properties = msg.getProperties();

    def input = properties.get('logsys');
    def carurl = helperValMap.getMappedValue('GK', 'logsys', input , 'CAR', 'car_binding_url');
    def carcredentials = helperValMap.getMappedValue('GK', 'logsys', input , 'CAR', 'car_credentials_id');
    def carcloudconnectionid = helperValMap.getMappedValue('GK', 'logsys', input , 'CAR' , 'cloud_connector_id');
    msg.setProperty( 'cloud_connector_id', carcloudconnectionid);
    msg.setProperty( 'car_credentials_id', carcredentials);
    msg.setProperty( 'car_binding_url', carurl);
	return msg;
	
}