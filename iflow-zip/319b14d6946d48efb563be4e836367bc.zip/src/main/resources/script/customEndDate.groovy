import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.lang.String;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String getQuoteEntryId(String arg1){
    
      String[] str;
      str = arg1.split('_');
      
      def quoteEntryId = str[0]
    
    return quoteEntryId;

}