import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.lang.String;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String getRatePlanId(String arg1){
    
      String[] str;
      str = arg1.split('_');
      
      def ratePlanId = str[2]
    
    return ratePlanId;

}