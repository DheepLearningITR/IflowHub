import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.*
import groovy.xml.*

def Message processData(Message message) {
def payload = message.getBody(Reader);
 
def xml = new XmlSlurper().parse( payload )
if(!(xml.children().find( {it.name() == "results"}))) {
    
    message.setBody("<root><results></results></root>")
}

return message
}