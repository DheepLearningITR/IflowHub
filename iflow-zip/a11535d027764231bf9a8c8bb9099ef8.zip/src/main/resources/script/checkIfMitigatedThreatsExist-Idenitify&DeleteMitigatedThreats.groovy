import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    
    def payload = message.getBody(java.lang.String.class)toString();

    def slurper = new XmlSlurper().parseText(payload)

    def isIgnored = slurper.row.results.find { it.is_ignored.text() == 'true'}

    if (isIgnored) {
        message.setProperty("mitigatedThreatsExists", 'true')
        
    } else {
        message.setProperty("mitigatedThreatsExists", 'false')
    }
    
    binding.variables.remove 'payload'
    binding.variables.remove 'slurper'
    binding.variables.remove 'isIgnored'
    
    return message;
}
