import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    def headers = message.getHeaders()
    def properties = message.getProperties()
    def lastRunTimestamp = headers.get('lastSuccessfullRun') 
    def globalVariableLastSuccessfulRun = properties.get('lastSuccessfullRunObject')
    def timestampID = properties.get('timestampID')
    def timestampKey = timestampID.toString() + '_lastSuccessfulRun'
    
    if(globalVariableLastSuccessfulRun) {

        def hashMap = generateHashMapFromPairs(globalVariableLastSuccessfulRun)

        hashMap.put(timestampKey, lastRunTimestamp)
        message.setProperty('timestampObject', hashMap)

    } else {
        def hashMap = [:]
        hashMap.put(timestampKey, lastRunTimestamp)
        message.setProperty('timestampObject', hashMap)
    }
    
    return message
}


def generateHashMapFromPairs(globalVariableLastSuccessfulRun) {
    def hashMap = [:]

    def globalParamValue = globalVariableLastSuccessfulRun.toString().replaceAll(/[{}\[\]]+/, "")
        def keyValuePairs = globalParamValue.split(',')
        keyValuePairs.each { pair ->
            if (!pair.isEmpty()) { 
                def keyValue = pair.split('=')
                def key = keyValue[0].trim()
                def value = keyValue.size() > 1 ? keyValue[1].trim() : ''
                hashMap[key] = value
            }
        }
        return hashMap
}