import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.*;

def Message processData(Message message) {

    String esstartdate = message.getProperties().get("EsStartDate").toString();
    String esenddate = message.getProperties().get("EsEndDate").toString();
    
    if (esstartdate.toLowerCase().contains('z')) {
    
        def formattedDate_esstart = esstartdate.replaceAll(/[zZ]/, '')
        message.setProperty('Everstream_StartDate', formattedDate_esstart)
       //message.setProperty('Everstream_StartDate', '2024-04-05T08:04:59')
    }

    if(esenddate.toLowerCase().contains('z')) {
        def formattedDate_esend = esenddate.replaceAll(/[zZ]/, '')
        message.setProperty('Everstream_EndDate', formattedDate_esend)
        //message.setProperty('Everstream_EndDate', '2024-06-29T16:06:11')
    }
    
    return message;
}