import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.*
import groovy.xml.*

def Message processData(Message message) {
	
    def payload = message.getBody(java.lang.String.class)toString();

def root = new XmlSlurper().parseText(payload)

root.row.results.findAll { it.is_ignored.text() == 'true' }.each { it.replaceNode { } }

def validThreats = XmlUtil.serialize(root)

def mitgatedThreatsRoot = new XmlSlurper().parseText(payload)

mitgatedThreatsRoot.row.results.findAll { it.is_ignored.text() == 'false' }.each { it.replaceNode { } }

def mitigatedThreats = XmlUtil.serialize(mitgatedThreatsRoot)

message.setProperty("VALID_THREATS", validThreats)
message.setProperty("MITIGATED_THREATS", mitigatedThreats)

if(!(root.row.children().find( {it.name() == "results"}))) {
    
    message.setBody("<root><results></results></root>")
} else {
    message.setBody("")
    
    
    binding.variables.remove 'payload'
    binding.variables.remove 'root'
    binding.variables.remove 'validThreats'
    binding.variables.remove 'mitgatedThreatsRoot'
    binding.variables.remove 'mitigatedThreats'
}
    return message;
}