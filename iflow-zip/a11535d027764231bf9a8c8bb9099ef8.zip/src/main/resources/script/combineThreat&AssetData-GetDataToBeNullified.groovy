import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.*
import groovy.xml.*
def Message processData(Message message) {

def xmlString = message.getProperty("keyFigureData").toString()
def threatID = message.getProperty("EsRiskId")
def threatDataXML = new XmlParser().parseText(xmlString)
String Separator = message.getProperties().get("Separator");
String Location_Master_Data = message.getProperties().get("Location_Master_Data");
String MDT_Prefix = message.getProperties().get("MDT_Prefix");
def splittext = MDT_Prefix+Location_Master_Data+Separator;
message.setProperty('Prefix', splittext);

def dates = threatDataXML.results.Date.collect { it.text() }

def payload = message.getBody(Reader);
def output = new XmlParser().parseText("<root/>")
def assetData = new XmlSlurper().parse( payload )
if((assetData.children().find( {it.name() == "results"}))) {
    dates.each { date ->
        assetData.results.each { eachXmlNode ->
            Node resultsNode = output.appendNode( new QName("results"), [:] )
            eachXmlNode.children().findAll { child -> child.name() in [ 'asset_guid' , 'asset_id', 'asset_name', 'score' , 'modified_date' ] } .each { child ->
                   resultsNode.appendNode( new QName(child.name()), [:], child.text() )
                                                                                                                      }
            resultsNode.appendNode(new QName("Date"), [:], date)
            resultsNode.appendNode(new QName("id"), [:], threatID)
            resultsNode.appendNode(new QName("Score_isNull"), [:], true)
    
        }
    } //end of dates

}//endof if

changedxml = XmlUtil.serialize(output);
message.setBody(changedxml)
return message
}
