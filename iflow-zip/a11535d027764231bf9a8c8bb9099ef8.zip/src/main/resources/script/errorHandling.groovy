import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*;

def Message processData(Message message) {  
    def errorMessage = ""
    def map = message.getProperties()
    def ex = map.get("CamelExceptionCaught")
    def httpStatusText = "HTTP_STATUSTXT"
    def httpStatucCode = "HTTP_STATUSCODE"
    def oDataExceptionClass = "com.sap.gateway.core.ip.component.odata.exception.OsciException"
    def httpExceptionClass = "org.apache.camel.component.ahc.AhcOperationFailedException"
    
if (ex!=null) {
    
 if (ex.getClass().getCanonicalName() == httpExceptionClass) {
     
   def body = ex.getResponseBody().toString()
   
   if(body) {
        def statusCode = ex.getStatusCode().toString()
    
        switch(statusCode) { 
            case "400": 
                    errorMessage = "Bad Request " + ex.getResponseBody().toString()
                break;
            case "404": 
                errorMessage = "Not Found: The server cannot find the requested resource."
                break;
                
            case "401": 
                def httpResponseStr401 = new JsonSlurper().parse(new StringReader(body))
                errorMessage = httpResponseStr401.detail.toString()
                break;
            
            case "405": 
                def httpResponseStr405 = new JsonSlurper().parse(new StringReader(body))
                errorMessage = httpResponseStr405.detail.toString()
                break;
                
            case "500": 
                def httpResponseStr500 = new JsonSlurper().parse(new StringReader(body))
                errorMessage = httpResponseStr500.errors.message.toString()
                break;
            default:
                errorMessage = "\n This error response is a generic \"catch-all\" response. "
                break
        }   
        
        
        //Update Properties 
        message.setProperty(httpStatucCode , statusCode ? statusCode : 'Not Available')
        message.setProperty(httpStatusText , ex.getStatusText() ? ex.getStatusText() : 'Not Available')
        message.setProperty("EX_RESPONSEBODY" , body ? body : 'Not Available')
        message.setProperty("EX_MSG" , ex.getMessage() ? ex.getMessage() : 'Not Available')
        
        
        message.setBody(errorMessage.toString())
    }
 } else if (ex.getClass().getCanonicalName() == oDataExceptionClass) {
    
    
    def httpResponseCode = message.getHeaders().get("CamelHttpResponseCode")
    def httpResponseBody = message.getBody(java.io.Reader).toString()
    def httpResponseBodyResult = ''
    
    if(httpResponseBody) {
        new JsonSlurper().parse(new StringReader(httpResponseBody))    
    }
    
    if(httpResponseCode != "null") {
      message.setProperty(httpStatucCode , httpResponseCode ? httpResponseCode : 'Not Available')
      message.setProperty(httpStatusText , httpResponseBodyResult ? httpResponseBodyResult : 'Not Available')
    }
    
    message.setProperty("EX_MSG" , ex.getMessage() ? ex.getMessage() : '')
     
    message.setBody("ODATA Error - Check Stack Trace Below \nRequested URI: " + ex.getRequestUri())
 }
}

    return message;  
}