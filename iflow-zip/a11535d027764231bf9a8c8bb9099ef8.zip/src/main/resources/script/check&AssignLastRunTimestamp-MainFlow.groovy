import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    def properties = message.getProperties()
    def timestampID = properties.get('timestampID')
    def lastRunObject = properties.get('lastSuccessfullRunObject')
    def timestampKey = timestampID.toString() + '_lastSuccessfulRun'
    

     if(lastRunObject) {
        def hashMap = generateHashMapFromPairs(lastRunObject, message)    
        if(hashMap.get(timestampKey)) {
            message.setProperty('timestampKey_value', timestampKey)
            def lastRunDate = hashMap.get(timestampKey)       
            message.setProperty('lastRunDate_value', lastRunDate)        
            message.setProperty('LastRunForThreats', lastRunDate.toString())
        } else {
            message.setProperty('LastRunForThreats', '')
        }
    } else {
        message.setProperty('LastRunForThreats', '')
    }
    return message;
}

def generateHashMapFromPairs(lastRunObject, message) {
    def hashMap = [:]

    def lastRunObjectValue = lastRunObject.toString().replaceAll(/[{}\[\]]+/, "")
        def keyValuePairs = lastRunObjectValue.split(',')
        
        keyValuePairs.each { pair ->
            if (!pair.isEmpty()) { 
                def keyValue = pair.split('=')
                def key = keyValue[0].trim()
                def value = keyValue.size() > 1 ? keyValue[1].trim() : ''
                message.setProperty('keyValue[0]_value', key)
                message.setProperty('keyValue[1]_value', value)
                hashMap[key] = value
            }
        }
        return hashMap
}