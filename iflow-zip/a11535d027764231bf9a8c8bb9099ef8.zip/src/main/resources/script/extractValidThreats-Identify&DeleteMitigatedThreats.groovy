import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.*
import groovy.xml.*

def Message processData(Message message) {
	
def payload = message.getBody(java.lang.String.class)toString();

def root = new XmlSlurper().parseText(payload)

root.row.results.findAll { it.is_ignored.text() == 'true' }.each { it.replaceNode { } }

def validThreats = XmlUtil.serialize(root)

message.setProperty("VALID_THREATS", validThreats)

if(!(root.row.children().find( {it.name() == "results"}))) {
    
    message.setProperty("VALID_THREATS","<root><results></results></root>")
}


    binding.variables.remove 'payload'
    binding.variables.remove 'root'
    binding.variables.remove 'validThreats'

    return message;
}