import com.sap.it.api.mapping.*;

def String generateGuid(String arg1) {
  return UUID.randomUUID().toString()
}

def String removeLeadingZeros(String arg1) {
  try {
    return Long.parseLong(arg1)
  } catch (NumberFormatException ex) {
    return arg1
  }
}

def String getBusinessSystemDisplayId(String arg1, MappingContext context) {
  return context.getProperty(arg1)
}

def void concatTextLine(String[] input, String[] format, Output output, MappingContext context) {

  // This function will Concat the text line for a Text ID based on FORMAT_COL
  StringBuffer sb = new StringBuffer();
  if (input.length > 0)
    sb.append(input[0]);
  for (int j = 1; j < input.length; j++) {
    sb.append("\n");
    sb.append(input[j]);
  }
  output.addValue(sb.toString());

}

def void determineStatus(String[] status, Output output, MappingContext context) {

  boolean lv_status_found = false;

  // search for ERP status, which should be mapped to C4C status 'OBSOLETE'
  for (int j = 0; j < status.length; j++) {
    if (status[j].equals("I0076") || status[j].equals("I0013")) {
      output.addValue("OBSOLETE");
      lv_status_found = true;
    }
  }

  if (lv_status_found) {
    return;
  }

  // search for ERP status, which should be mapped to C4C status 'BLOCKED'
  for (int j = 0; j < status.length; j++) {
    if (status[j].equals("I0190") || status[j].equals("I0320")) {
      output.addValue("BLOCKED");
      lv_status_found = true;
    }
  }

  if (lv_status_found) {
    return;
  }

  // search for ERP status, which should be mapped to C4C status 'ACTIVE'
  for (int j = 0; j < status.length; j++) {
    if (status[j].equals("I0099") || status[j].equals("I0116") || status[j].equals("I0188") || status[j].equals("I0186") || status[j].equals("I0184") || status[j].equals("I0100") || status[j].equals("I0194")) {
      output.addValue("ACTIVE");
      lv_status_found = true;
    }
  }

  if (lv_status_found) {
    return;
  }

  // search for ERP status, which should be mapped to C4C status 'IN_PREPARATION'
  for (int j = 0; j < status.length; j++) {
    if (status[j].equals("I0488")) {
      output.addValue("IN_PREPARATION");
      lv_status_found = true;
    }
  }

  if (lv_status_found) {
    return;
  }

  // What should be the default?
  output.addValue("IN_PREPARATION");

}