import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import java.util.HashMap

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    def configSystemId = message.getProperties().get('systemId')
    def configSender_BN_MT_id = message.getProperties().get('Sender_BN_MT_id')
    def eventPackages =  input['n0:MaterialTraceabilityEventNotificationMessage'].EventPackage
    
    def msgHeader = input['n0:MaterialTraceabilityEventNotificationMessage'].MessageHeader
	msgHeader.SenderParty.InternalID = configSender_BN_MT_id
	msgHeader.SenderParty.StandardID.'$' = configSender_BN_MT_id
	msgHeader.RecipientParty.InternalID = configSender_BN_MT_id
	msgHeader.RecipientParty.StandardID.'$' = configSender_BN_MT_id

    // Handle Receive Events - If SystemId doesn't exist, add it from Configuration
    if (eventPackages.ReceiveEvents) {
        if (eventPackages.ReceiveEvents instanceof List) {
            eventPackages.ReceiveEvents.each {
                checkAndAddSystemId(it, configSystemId)
            }
        } else {
            checkAndAddSystemId(eventPackages.ReceiveEvents, configSystemId)
        }
    }

    // Handle Receive Events - If SystemId doesn't exist, add it from Configuration
    if (eventPackages.ReceiveSerialNumberEvents) {
        if (eventPackages.ReceiveSerialNumberEvents instanceof List) {
            eventPackages.ReceiveSerialNumberEvents.each {
                checkAndAddSystemId(it, configSystemId)
            }
        } else {
            checkAndAddSystemId(eventPackages.ReceiveSerialNumberEvents, configSystemId)
        }
    }

    // ProduceEvent - If SystemId doesn't exist, add it from Configuration
    if (eventPackages.ProduceEvents) {
        if (eventPackages.ProduceEvents instanceof List) {
            eventPackages.ProduceEvents.each {
                checkAndAddSystemId(it, configSystemId)
                checkAndAddComponentSystemId(it, configSystemId)
            }
        } else {
            checkAndAddSystemId(eventPackages.ProduceEvents, configSystemId)
            checkAndAddComponentSystemId(eventPackages.ProduceEvents, configSystemId)
        }
    }

    if (eventPackages.ProduceSerialNumberEvents) {
        if (eventPackages.ProduceSerialNumberEvents instanceof List) {
            eventPackages.ProduceSerialNumberEvents.each {
                checkAndAddSystemId(it, configSystemId)
                checkAndAddComponentSystemId(it, configSystemId)
            }
        } else {
            checkAndAddSystemId(eventPackages.ProduceSerialNumberEvents, configSystemId)
            checkAndAddComponentSystemId(eventPackages.ProduceSerialNumberEvents, configSystemId)
        }
    }


    // Handle Deliver Events - If SystemId doesn't exist, add it from Configuration
    if (eventPackages.DeliverEvents) {
        if (eventPackages.DeliverEvents instanceof List) {
            eventPackages.DeliverEvents.each {
                checkAndAddSystemId(it, configSystemId)
            }
        } else {
            checkAndAddSystemId(eventPackages.DeliverEvents, configSystemId)
        }
    }
    // Handle DeliverSerialNumberEvents Events and add SystemId if missing
    if (eventPackages.DeliverSerialNumberEvents) {
        if (eventPackages.DeliverSerialNumberEvents instanceof List) {
            eventPackages.DeliverSerialNumberEvents.each {
                checkAndAddSystemId(it, configSystemId)
            }
        } else {
            checkAndAddSystemId(eventPackages.DeliverSerialNumberEvents, configSystemId)
        }
    }

    input['n0:MaterialTraceabilityEventNotificationMessage'].EventPackage = eventPackages
    def aasJson = new JsonBuilder(input)
    message.setBody(aasJson.toPrettyString())
    return message
}
def checkAndAddSystemId(def event, def configSystemId) {
    // If SystemId is missing in Input, add the configured value
    //if(event.SystemID == null || event.SystemID == '') {
        if(configSystemId) {
            event.SystemID = configSystemId
        }
    //}
}
def checkAndAddComponentSystemId(def event, def configSystemId) {
    if(configSystemId) {
        if(event.SerialNumbers){
            if(event.SerialNumbers instanceof List){
                event.SerialNumbers.each{
                    if(it.ComponentSerialNumbers ){
                        if(it.ComponentSerialNumbers instanceof List ){
                            it.ComponentSerialNumbers.each{
                                it.SystemID = configSystemId
                            }
                        }else{
                            it.ComponentSerialNumbers.SystemID = configSystemId
                        }
                    }
                }
            }else{
                if(event.SerialNumbers.ComponentSerialNumbers ){
                    if(event.SerialNumbers.ComponentSerialNumbers instanceof List ){
                        event.SerialNumbers.ComponentSerialNumbers.each{
                            it.SystemID = configSystemId
                        }
                    }else{
                        event.SerialNumbers.ComponentSerialNumbers.SystemID = configSystemId
                    }
                }
            }
        }

        if(event.Components){
            if(event.Components instanceof List){
               event.Components.each{
                    it.SystemID = configSystemId
               } 
            }else{
                event.Components.SystemID = configSystemId
            }
         }
    }
}

