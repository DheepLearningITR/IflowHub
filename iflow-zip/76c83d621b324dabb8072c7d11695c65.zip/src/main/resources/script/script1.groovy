import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import java.util.HashMap

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    message.setHeader('processReceiveEvents', 'N')
    message.setHeader('hasReceiveEvents', 'N')
    message.setHeader('hasReceiveSerialNumberEvents', 'N')
    def eventPackages =  input['n0:MaterialTraceabilityEventNotificationMessage'].EventPackage

    // Handle Receive Events and Clone each SerialNumber to own Record
    if (eventPackages.ReceiveEvents) {
        message.setHeader('processReceiveEvents', 'Y')
        message.setHeader('hasReceiveEvents', 'Y')
    }

    // Handle Receive Events and Clone each SerialNumber to own Record
    if (eventPackages.ReceiveSerialNumberEvents) {
        message.setHeader('processReceiveEvents', 'Y')
        message.setHeader('hasReceiveSerialNumberEvents', 'Y')
        if (eventPackages.ReceiveSerialNumberEvents instanceof List) {
            def receiveSerialNumberEventsArray = []
            eventPackages.ReceiveSerialNumberEvents.each {
                def tempEventMap = it
                if (it.SerialNumbers instanceof List) {
                    def serialNumbers = it.SerialNumbers
                    serialNumbers.each {
                        tempEventMap.SerialNumbers = it
                        receiveSerialNumberEventsArray << tempEventMap.clone()
                    }
                } else {
					receiveSerialNumberEventsArray << tempEventMap
				}
            }
            eventPackages.ReceiveSerialNumberEvents = receiveSerialNumberEventsArray
        } else {
            def tempEventMap = eventPackages.ReceiveSerialNumberEvents
            def receiveSerialNumberEventsArray = []
            if (eventPackages.ReceiveSerialNumberEvents.SerialNumbers instanceof List) {
                def serialNumbers = eventPackages.ReceiveSerialNumberEvents.SerialNumbers
                serialNumbers.each {
                    tempEventMap.SerialNumbers = it
                    receiveSerialNumberEventsArray << tempEventMap.clone()
                }
                eventPackages.ReceiveSerialNumberEvents = receiveSerialNumberEventsArray
            }
        }
    }

    // ProduceEvent - If CatenaX ID doesn't exist, create a new UUID
    if (eventPackages.ProduceEvents) {
        if (eventPackages.ProduceEvents instanceof List) {
            eventPackages.ProduceEvents.each {
                setKeyAssignments(it, 'CATENA_X_BATCH')
            }
        } else {
            setKeyAssignments(eventPackages.ProduceEvents, 'CATENA_X_BATCH')
        }
    }

    if (eventPackages.ProduceSerialNumberEvents) {
        if (eventPackages.ProduceSerialNumberEvents instanceof List) {
            eventPackages.ProduceSerialNumberEvents.each {
                if (it.SerialNumbers instanceof List) {
                    def serialNumbers = it.SerialNumbers
                    serialNumbers.each {
                        setKeyAssignments(it, 'CATENA_X_PART')
                    }
                } else {
                    setKeyAssignments(it.SerialNumbers, 'CATENA_X_PART')
                }
            }
        } else {
            if (eventPackages.ProduceSerialNumberEvents.SerialNumbers instanceof List) {
                def serialNumbers = eventPackages.ProduceSerialNumberEvents.SerialNumbers
                serialNumbers.each {
                    setKeyAssignments(it, 'CATENA_X_PART')
                }
            } else {
                setKeyAssignments(eventPackages.ProduceSerialNumberEvents.SerialNumbers, 'CATENA_X_PART')
            }
        }
    }

    input['n0:MaterialTraceabilityEventNotificationMessage'].EventPackage = eventPackages
    message.setHeader('payload', input)
    def aasJson = new JsonBuilder(input)
    message.setBody(aasJson.toPrettyString())
    return message
}

def setKeyAssignments(def events, def qualifier) {
    if (events.KeyAssignments) {
        if (!getKeyAssignments(events.KeyAssignments, qualifier)) {
            def keyAssignmentsNode = [:]
            def keyAssignmentsArray = []
            def value = UUID.randomUUID().toString()
            keyAssignmentsArray << events.KeyAssignments
            keyAssignmentsNode.Qualifier = qualifier
            keyAssignmentsNode.Value = value
            keyAssignmentsArray << keyAssignmentsNode
            events.KeyAssignments = keyAssignmentsArray
        }
    } else {
        def keyAssignmentsNode = [:]
        def value = UUID.randomUUID().toString()
        keyAssignmentsNode.Qualifier = qualifier
        keyAssignmentsNode. Value = value
        events.KeyAssignments = keyAssignmentsNode
    }
}

def getKeyAssignments(def keyAssignments, def qualifier) {
    def  res = ""
    if (keyAssignments) {
        if (keyAssignments instanceof List) {
            keyAssignments.each{
                if (it.Qualifier == qualifier) {
                    res = it.Value
                }
            }
	    } else if (keyAssignments.Qualifier == qualifier) {
            res = keyAssignments.Value
        } else {
            res = ''
        }
    } else {
        res = ''
    }
    return res
}
