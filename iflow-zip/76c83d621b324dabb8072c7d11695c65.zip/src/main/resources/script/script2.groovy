import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder

def Message processData(Message message) {
    // Get Original Payload and send it to AAS and EDC Registrering
    def payload = message.getHeaders().get('payload')
    def aasJson = new JsonBuilder(payload['n0:MaterialTraceabilityEventNotificationMessage'])
    message.setBody(aasJson.toPrettyString())
    return message
}
