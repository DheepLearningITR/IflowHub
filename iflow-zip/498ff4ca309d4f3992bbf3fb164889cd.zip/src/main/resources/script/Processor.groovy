import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Map;
import java.util.List;
import java.util.HashMap;
import groovy.transform.Field;
import java.lang.Exception;
import java.text.Normalizer;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import java.net.URI;

// {C} 2017
// SAP SE
// 28.05.2018
// this script is a part of standard HCI flow for Colombia



// constants

public interface SIIBoolean {
	String Yes = 'yes';	
	String No  = 'no';	
};

public interface MessageProperty {
	String logMode                 = 'loggingEnabled';
	String canonicalLogMode        = 'canonicalLoggingEnabled';
	String NIT                     = 'NIT';
	String keyAliasSuffix          = 'keyAliasSuffix';
	String addNiftoKeyAlias        = 'addNiftoKeyAlias';
	String privateKeyAlias         = 'privateKeyAlias';
	String canonicaladdNIT         = 'canonicaladdNIT';
}


// aliases

@Field addNitAliasMap = 
[
	(Boolean.Yes) : [  "YES" ],
	(Boolean.No) : [  "NO" ]
];


def Message setupConfiguration( Message message ) {
    
	def props = message.getProperties();
	
	def region = props.get( MessageProperty.reportTo );	
	def region_normalized = '';

	def usageMode = props.get( MessageProperty.usageMode );	
	def usageMode_normalized = '';

//3.0.0
//Add dinmayc private key alias
    def Nit = props.get( MessageProperty.NIT );
    def kSuffix = props.get( MessageProperty.keyAliasSuffix );	
    def addNit = props.get( MessageProperty.addNiftoKeyAlias );	
    def addNit_normalized = '';
        
    
    if ( addNit_normalized == '' )
		throw new Exception( ExceptionPrefix.config + 'Add NIT to private key Alias cannot be empty');
    
   if( addNit_normalized == Boolean.No ) {
    
     message.setProperty( MessageProperty.privateKeyAlias, kSuffix ); 
      }
      else{
      
     message.setProperty( MessageProperty.privateKeyAlias, kSuffix + '_' + Nit.toLowerCase()  ); //Nit
      }
   
   
   	message.setProperty( MessageProperty.canonicaladdNIT, addNit_normalized );

	def logMode = message.getProperty( MessageProperty.logMode );
	def logMode_normalized = Boolean.No;
	
	if ( isByRequest( logMode ) ) {
		logMode = getQueryParam( message, MessageProperty.logMode );
		if ( isByRequest( logMode ) )
			logMode = Boolean.No; // here recursion leads to immediate no
	}
	
	// for logging purposes only, visible if logging mode is on
	logMode_normalized = getNormalizedName( logMode, logYesAliasMap );
	logMode_normalized = logMode_normalized ? logMode_normalized : Boolean.No;		
	message.setProperty( MessageProperty.canonicalLogMode,   logMode_normalized );
   
