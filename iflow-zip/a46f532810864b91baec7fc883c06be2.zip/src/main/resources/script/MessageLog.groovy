import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processDataUpdateBillStatus(Message message) {
	def map = message.getProperties();
	def property_ENABLE_MPL_LOGGING = map.get("EnableLog");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") ) {
	    def body = message.getBody(java.lang.String) as String;
	    def billLogID = map.get("SBBillNumber");
	    def messageLog = messageLogFactory.getMessageLog(message);
	    if (messageLog != null) {
			messageLog.addAttachmentAsString("Bill(" + billLogID + ")_status_update_req_success", body, "text/json");
		}
	}
	return message;
}

def Message processDataS4Log(Message message) {
	def map = message.getProperties();
	def property_ENABLE_MPL_LOGGING = map.get("EnableLog");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") ) {
	    def body = message.getBody(java.lang.String) as String;
	    def billLogID = map.get("SBBillNumber");
	    def messageLog = messageLogFactory.getMessageLog(message);
	    if (messageLog != null) {
			messageLog.addAttachmentAsString("Bill(" + billLogID + ")_S4Log", body, "text/xml");
		}
	}
	return message;
}

def Message processAlreadyExistErrorAndGetS4DocId(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def s4BillDocId = getS4BillDocIdFromAlreadyExistsErrorLog(body);
    // Parse the XML
    message.setProperty("S4BillDocId", s4BillDocId);
    return message;
}

def String getS4BillDocIdFromAlreadyExistsErrorLog(String s4ErrorLog){
    def xml = new XmlSlurper().parseText(s4ErrorLog)

    // Find the Note where TypeID equals 020(EBDR)
    def notes = xml.'**'.findAll { it.name() == 'Item' && it.TypeID.text() == '020(EBDR)' }*.Note*.text()
    // Print the extracted Note content
    def patternLanguage = ~/Billing document request (\d+)/
    // Set to store unique values
    def uniqueValuesDeterminedByText = new HashSet<String>()
    notes.each {
        def matcherLanguage = patternLanguage.matcher(it)
        if (matcherLanguage.find()) {
            uniqueValuesDeterminedByText.add(matcherLanguage.group(1))
        }
    }

    def pattern = ~/(?<!\()\b\d+\b(?!\s*\(\d+\))/
    def matcher = pattern.matcher(notes.join());
    def uniqueValuesDeterminedByRegex = new HashSet<String>()
    while (matcher.find()) {
        uniqueValuesDeterminedByRegex << matcher.group()
    }
    // Print extracted values
    uniqueValuesDeterminedByRegex.each { println it }

    if(uniqueValuesDeterminedByText.equals(uniqueValuesDeterminedByRegex)) {
        def S4BillDocId = uniqueValuesDeterminedByText.join(" ")
        println "The extracted values are the same, will use the value determined by text: ${S4BillDocId}"
        return S4BillDocId
    } else {
        def S4BillDocId = uniqueValuesDeterminedByRegex.join(" ")
        println "The extracted values are different, will use the value determined by regex: ${S4BillDocId}"
        return S4BillDocId
    }
}
