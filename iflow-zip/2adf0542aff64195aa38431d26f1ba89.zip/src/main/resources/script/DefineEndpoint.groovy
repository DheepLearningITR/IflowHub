import com.sap.gateway.ip.core.customdev.util.Message

def Message processData( Message message ) throws Exception {


       map = message.getProperties();
       String  ExecutionID = map.get("ExecutionId");

if(ExecutionID == "PROD") { 
    
message.setProperty("EndpointAddress", "https://vpfe.dian.gov.co/WcfDianCustomerServices.svc");

} else{ 
    
message.setProperty("EndpointAddress", "https://vpfe-hab.dian.gov.co/WcfDianCustomerServices.svc");

}


	return message;
}
