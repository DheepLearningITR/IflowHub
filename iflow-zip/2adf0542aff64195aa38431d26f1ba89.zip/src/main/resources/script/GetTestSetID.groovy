import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.security.MessageDigest;
import java.security.Security;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;




def Message processGetTestSetID( Message message ) throws Exception {
    
    def map = message.getProperties();
    def SoftwareID = map.get("SoftwareID").toLowerCase();
    def credentials = "edoc_co_setid_" + SoftwareID;
	
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
	
	try {
		credential = service.getUserCredential( credentials );
	} catch (all) {
		throw new Exception("No information found for alias: " + credentials );
	}
	
	 String testSetId = new String(credential.getPassword());
	 
	 message.setProperty("TestSetID", testSetId);
	 
	return message;
}





