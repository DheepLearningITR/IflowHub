
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

 	// get a map of iflow properties
 	def map = message.getProperties();

 	// get an exception java class instance
 	def ex = map.get("CamelExceptionCaught");
 	
 	if (ex!=null) {

 		// an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
 		if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {

	 		// save the http error response as a message attachment
		 	def messageLog = messageLogFactory.getMessageLog(message);
			messageLog.addAttachmentAsString("http.ResponseBody", ex.getResponseBody(), "text/plain");
			
		 	// copy the http error response to an iflow's property
			message.setProperty("http.ResponseBody",ex.getResponseBody());
			
		 	// copy the value of http error code (i.e. 500) to a property
			message.setProperty("ErrorCode","HTTP " + ex.getStatusCode());
			
		 	// copy the value of http error text (i.e. "Internal Server Error") to a property
			message.setProperty("ErrorText",ex.getStatusText());
 		} else {
 		    //Other exception
 		    message.setProperty("ErrorCode",ex.getClass().getCanonicalName());
 		    
 		    message.setProperty("ErrorText",ex.getMessage());
 		}
 	}
 	
 	return message;
}


