import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.util.*;
import java.util.HashMap;

def Message processData(Message message) { 
def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    object.remove("@odata.context");
    object.remove("@odata.metadataEtag");
    object.remove("@odata.nextLink");
    message.setBody(JsonOutput.toJson( object ));
    return message;
}
