import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import java.util.HashMap;

def Message processData(Message message) { 
    String count = message.getBody(String.class);
    message.setProperty("count", count);
    message.setBody("");
    return message;
}