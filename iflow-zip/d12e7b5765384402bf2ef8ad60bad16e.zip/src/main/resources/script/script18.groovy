import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

// MessageLog
def messageLog = messageLogFactory.getMessageLog(message);
def bodyAsString =  message.getBody(String.class);
messageLog.addAttachmentAsString("01 Payload", bodyAsString, "text/xml");

       return message;
}
