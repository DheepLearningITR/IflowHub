
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

    


def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	
	def error =  "Please check the resource iflow ID.";
        if(messageLog != null){
                messageLog.addCustomHeaderProperty("Get resource failed", error);   
        }
        
        message.setHeader("checkpk", "none");// route to Escalation
        return message;
}