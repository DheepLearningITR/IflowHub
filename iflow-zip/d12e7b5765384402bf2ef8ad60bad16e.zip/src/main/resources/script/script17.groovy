import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import org.apache.poi.util.IOUtils;
import org.apache.commons.codec.binary.Base64;


def Message processData(Message message) 

 { 
    def input = message.getBody(java.io.InputStream);
    def map = message.getHeaders();
   	/*def SourceIflowID = map.get("SourceIflowID");
    def TargetIflowID = map.get("TragetIflowID");*/
    
    def SourceIflowID = "Test_iflow_C";
    def TargetIflowID = "Test_iflow_C.dev";
    
    
    def ID_to_replace = "Bundle-SymbolicName: "+ SourceIflowID;
    def Bundle_to_replace = "Origin-Bundle-SymbolicName: "+ SourceIflowID;
    
    def ID = "Bundle-SymbolicName: "+TargetIflowID;
    def Bundle = "Origin-Bundle-SymbolicName: "+TargetIflowID;
    
    def text ="";
    def zipfile = SourceIflowID+"zip";
    String manifest='';
    
       ByteArrayOutputStream baos = new ByteArrayOutputStream();  
    
       def zip = new ZipInputStream(input);
       def file = new ZipEntry()
        
       ByteArrayOutputStream zipout = new ByteArrayOutputStream();
       ZipOutputStream zos = new ZipOutputStream(zipout);
        
        
        
        try{
            
             while ((file = zip.getNextEntry()) != null) {
                
                String fileName = file.getName();
               
                if (file.getName().endsWith('MANIFEST.MF')) {
   
                 def out = new ByteArrayOutputStream()
                 IOUtils.copy(zip, out);
                 
                 ByteArrayOutputStream realOutput = new ByteArrayOutputStream();

	    		    realOutput.writeTo(out);
	    		    realOutput.close();
                
             baos.write(out.toByteArray());
                }

	    	   else {
	    	    /***other files***/   
	    	       
	    	  zos.putNextEntry(new ZipEntry(file.getName()));
              zos.write(zip.text.getBytes());
	    	       
	    	       
	    	       
	    	       
	    	   }
	    	   
	    	   zos.closeEntry();
	    	   
	    	   
	    	   
	    	   zip.closeEntry()
	    	   
            }
            
             zip.close()
        } catch (IOException e) {
            e.printStackTrace();
        }
     
     
        String str = baos.toString();
        
         if (str.contains(SourceIflowID)) {
             
          manifest = str.replaceAll(SourceIflowID,TargetIflowID);  
    	   
    	            }
        
  
        
    
    
    // encode Base 64  zip file
    /*    File originalFile = new File(zipfile);
		String encodedBase64 = null;
		try {
			FileInputStream fileInputStreamReader = new FileInputStream(originalFile);
			
			byte[] bytes = new byte[(int) originalFile.length()];
			
			fileInputStreamReader.read(bytes);
			
			encodedBase64 = new String(Base64.encodeBase64(bytes));
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
    
     message.setBody(encodedBase64)*/
     
    //  message.setBody(ID_to_replace+Bundle_to_replace);

    message.setBody(manifest)
    return message

}