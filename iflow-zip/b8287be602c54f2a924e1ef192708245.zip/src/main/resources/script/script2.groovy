import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*
   
def Message processData(Message message) {
       
    sub = new XmlParser().parse(message.getBody())
    main = new XmlParser().parseText(message.getProperty("afterMapping"))
    def ns0 = new groovy.xml.Namespace("http://sap.com/xi/XI/SplitAndMerge")

    sub[ns0.Message1].Common.Organisation.each{
        
        id = it.externalID.text()
        Node name_element = it.Name[0]

        bp = main.BusinessPartnerSUITEReplicateRequestMessage.BusinessPartner.find{it.UUID.text() == id}
        if (bp) {
            bp.Common.Organisation.Name.replaceNode{}
            bp.Common.Organisation*.append(name_element)
        }

    }

    message.setBody(XmlUtil.serialize(main)) 
    return message;
	
}