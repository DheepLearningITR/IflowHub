import com.sap.it.api.mapping.*;

//Add MappingContext parameter to read or set headers and properties
def String randomuniqueID(String P1) {
        
 def extCode = UUID.randomUUID().toString()

extCode = extCode.replaceAll("-","")
return extCode
}