import com.sap.it.api.mapping.*;

//Add MappingContext parameter to read or set headers and properties
def String randomID(String P1) {
        
 def extCode = UUID.randomUUID().toString()


return extCode
}