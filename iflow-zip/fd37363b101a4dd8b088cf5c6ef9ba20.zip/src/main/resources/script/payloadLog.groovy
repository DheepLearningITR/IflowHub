import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message requestPayload(Message message) {
    //Body 
	def messageLog = messageLogFactory.getMessageLog(message);
	//Properties 
    def map = message.getProperties();
    def logging = map.get("EnableLogging");
	
    if(messageLog !=null && logging == 'true')	
	messageLog.addAttachmentAsString("CDCPayload_XML",message.getBody(String),'text/xml');
	return message;
}

