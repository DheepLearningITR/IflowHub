import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.UnsupportedEncodingException;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}
*/ 

//def messageLog = messageLogFactory.getMessageLog();

def String generatePublicKey(String object_id, String street, String house_no, String city, String postal_code, String country_iso){
    String addressMessage = getAddressMessage(object_id, street, house_no, city, postal_code, country_iso);
	String result = "";
	try {
		MessageDigest digest = MessageDigest.getInstance("MD5");
		
		byte[] hashedBytes = digest.digest(addressMessage.getBytes("UTF-8"));
		result = convertByteArrayToString(hashedBytes);
	} catch (NoSuchAlgorithmException | UnsupportedEncodingException ex) {
        //log
	}
	return addressMessage;  //for debug only
	return result;
}

def private String convertByteArrayToString(byte[] arrayBytes) {
	StringBuilder hashcode = new StringBuilder();
	for (int i = 0; i < arrayBytes.length; i++) {
		hashcode.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16).substring(1));
	}
	return hashcode.toString();
}

def private String getAddressMessage(String object_id, String street, String house_no, String city, String postal_code, String country_iso) {
    return object_id + street + house_no + city + postal_code + country_iso;
}