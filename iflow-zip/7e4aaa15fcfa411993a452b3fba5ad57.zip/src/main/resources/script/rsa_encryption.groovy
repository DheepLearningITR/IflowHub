
import com.sap.gateway.ip.core.customdev.util.Message;


import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPublicKeySpec;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;


import org.apache.commons.codec.binary.Base64;


def Message processData(Message message) {
	
    //Properties
	def map = message.getProperties();
	//String aes_key = "1234567890123458";
	String aes_key = map.get("aes_symmetrical_key"); //"1234567890123456";
	                                                 //${date:now:yyyyMMddHHmmss}
	                                                   // 20151119165600
    String password = map.get("password");
    
    def nonce_enc = encode_rsa_base64(aes_key);
    
    String key = aes_key; // 128 bit key
    String password_enc = encrypt_aes_ecb_pkcs5_base64(aes_key, password);
    
    
    //2013-01-01T19: 20: 30.45Z
    TimeZone tz = TimeZone.getTimeZone("UTC");
    DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH: mm: ss.SSS'Z'");
    df.setTimeZone(tz);
    String nowAsISO = df.format(new Date());
    String now_enc = encrypt_aes_ecb_pkcs5_base64(aes_key, nowAsISO);
    
    
    message.setProperty("nonce", nonce_enc);
    message.setProperty("password", password_enc);
    message.setProperty("created", now_enc);
    
    return message;
}


//intentionally spoiling modulus value to simulate failing call!
def String encode_rsa_base64(String text) {
    
    //public key valid till April 15th, 2027
    BigInteger modulus = new BigInteger("C4B05FF29E933C2D8A2BB5CBE6AEBCD50CDF6F5E7EABA99353C355160005B5849B1B737936232617877D884CDD6F1530BA797AE46A4870C7D6F0757AD486B64AE62022358CBFC6B45E413CD99BB80C8FADF0268F5EAC9A7C08DD92DED7547611475A8D3B4125E11FE565FFBFED0C17CE41500E6DD960BA280FF3522384F4182EE5EAE50DD6EF84C448A1A2CFFC7E23FF89B7923E211A2416A44C5855D92EA49A2EA888B1337C1FFE310DAB6E8CF6E023AA7404B025F3AF8CD77D0CDC9CF7C37A3AFBA91272919CC93BF32A76584C67D43AF029B6FC4DBAED3FF0C8335C8088F8CAA42CA8C55F8F72F43D6694AC0DFB0153E62D87D6ADEA9F53A572094E2FD40DD72377A8039D25DA2DA5C15216C1639FB88E9FA10374AC9475BE2D7A7B08878363BECC256CB4E7FD631019E28CF105B856D9A0C879445DFB0F8C03BE04E28CF8E89B1D984418462C187DBCE389B3DE8519A18E2E6C1A6F89FEB3BE2F30BFA48F515464C48545FD3281867917DBCA40EAD08D1A8B469E73703B42B72F7A588EA79018581244FEA5C4D82FC9C50EEF9BB8E650E552DB6C2ED455BD85AFE1EA761247134E9B9403BA806F6E39D15D4CDD0626970543F2AD80F35CBC2B32C1370B9C513C1D67BA22ED48B5A808EF39F4B41D964ED1132E1FB6ED9CD07F807FADAC5BFE50713930A50300BFFC8AFD5F7DB71C0D1277D24A8A07655F8A7080CC732339", 16 );


    BigInteger pubExp = new BigInteger("010001", 16);
//   BigInteger pubExp = new BigInteger("65537", 16);
    
    KeyFactory keyFactory = KeyFactory.getInstance("RSA");
    RSAPublicKeySpec pubKeySpec = new RSAPublicKeySpec(modulus, pubExp);
    RSAPublicKey key = (RSAPublicKey) keyFactory.generatePublic(pubKeySpec);
    
    String result = null;
    
    byte[] cipherText = null;
    final Cipher cipher = Cipher.getInstance("RSA");
    cipher.init(Cipher.ENCRYPT_MODE, key); //key.getPublic()
    byte[] encrypted = cipher.doFinal(text.getBytes());
    result = Base64.encodeBase64String(encrypted);
    return result;
}


   
	String encrypt_aes_ecb_pkcs5_base64(String key,  String value) {
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
            
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
            byte[] encrypted = cipher.doFinal(value.getBytes());
            System.out.println("encrypted string:"
                    + Base64.encodeBase64String(encrypted));
            return Base64.encodeBase64String(encrypted);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
