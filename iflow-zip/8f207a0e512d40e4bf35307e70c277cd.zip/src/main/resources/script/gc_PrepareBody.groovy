import com.sap.gateway.ip.core.customdev.util.Message;
import org.apache.camel.impl.DefaultAttachment
import javax.mail.util.ByteArrayDataSource
import java.util.HashMap
import groovy.json.*

def Message processData(Message message) {
    def bodyStr = message.getBody(java.lang.String);
    def jsonSlurper = new JsonSlurper();
    bodyJson = jsonSlurper.parseText(bodyStr);
    def foldername = bodyJson.foldername;
    def folderpath = bodyJson.folderpath;
    message.setProperty("folderpath", folderpath);

    message.setBody(
    '----cpi\r\nContent-Disposition: form-data; name="propertyId[0]"\r\n\r\ncmis:objectTypeId' +
      '\r\n----cpi\r\nContent-Disposition: form-data; name="propertyValue[0]"\r\n\r\ncmis:folder' +
      '\r\n----cpi\r\nContent-Disposition: form-data; name="propertyId[1]"\r\n\r\ncmis:name' +
      '\r\n----cpi\r\nContent-Disposition: form-data; name="propertyValue[1]"\r\n\r\n' +
      foldername +
      '\r\n----cpi\r\nContent-Disposition: form-data; name="cmisaction"\r\n\r\ncreateFolder' +
      "\r\n----cpi--"
    );

    message.setHeader("Content-Type", "multipart/form-data; boundary=--cpi");

    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        messageLog.addAttachmentAsString("Payload:", "folder name - " + foldername + "folder path - " + folderpath, "text/plain");
    }
    
    
    return message;
}



