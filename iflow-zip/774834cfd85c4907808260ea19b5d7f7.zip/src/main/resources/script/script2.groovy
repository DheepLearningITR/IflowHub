/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-GB/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-GB/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    //Body
    def body = message.getBody();
    
    //headers
    def headers = message.getHeaders();
    
    //get dynamic configuration entryID header
    def entryID = headers.get("dc_entryid");
    
    //read headers to construct the entryid pattern <Interface>~<Stage>~<ReceiverOrPlaceholder>~<MplId>~<Timestamp>~<RetryCount>
    //def Pid = headers.get("partnerID");
    def interfaceID = headers.get("SAP_SenderInterface")
    def receiver = headers.get("SAP_Receiver")
    def mplID = headers.get("SAP_MessageProcessingLogID")
    def timestamp = headers.get("timestamp")
    

    //check what is the caller if the custom error handling and set stage identifier
    def pipelineStepID = headers.get("pipelineStepID")
    def stage = ""
    if (pipelineStepID == "com.sap.integration.cloud.pipeline.generic.step06.outbound.processing"){
        stage = "OB"
    }
    else if (pipelineStepID == "com.sap.integration.cloud.pipeline.generic.step05.interface.determination"){
        stage = "ID"
    }
    else if (pipelineStepID == "com.sap.integration.cloud.pipeline.generic.step04.receiver.determination"){
        stage = "RD"
    }
    
    //set retry count to starting 1
    def retryCount = "1"

    //if entryID doesn't exist, create it.         
    if (entryID == null){
            
        if (stage == "ID" || stage == "OB") { //in case of interface determination or outbound processing, the receiver is known, add it to the entryID
            entryID = interfaceID + "~" + stage + "~" + receiver + "~" + mplID + "~" + timestamp + "~" + retryCount
        }
        else
            entryID = interfaceID + "~" + stage + "~" + mplID + "~" + timestamp + "~" + retryCount
            
    }
    
    /*else { //if entryID exist then increase counter by casting to Integer and back to String
        def counterString= entryID.substring(entryID.lastIndexOf("~") + 1)
        int counterInt = Integer.parseInt(counterString)
        counterInt++
        if (stage == "ID" || stage == "OB") {
            entryID = interfaceID + "~" + stage + "~" + receiver + "~" + mplID + "~" + timestamp + "~" + counterInt
        }
        else
            entryID = interfaceID + "~" + stage + "~" + mplID + "~" + timestamp + "~" + counterInt
    
    }*/
    
    message.setProperty("entryID", entryID)
    
    return message;

}