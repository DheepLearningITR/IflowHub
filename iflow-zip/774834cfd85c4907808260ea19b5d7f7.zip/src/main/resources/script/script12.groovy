import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.gateway.ip.core.customdev.util.AttachmentWrapper
import javax.mail.util.ByteArrayDataSource
import groovy.util.XmlSlurper
import javax.xml.bind.DatatypeConverter

def Message processData(Message message) {
    def body = message.getBody(java.io.InputStream)
    def xml = new XmlSlurper().parse(body)

    // Check for any <Attachment> nodes
    if (xml.Attachments?.Attachment?.size() > 0) {
        xml.Attachments.Attachment.each { attachmentNode ->
            def name = attachmentNode.AttachmentName.text()
            def contentType = attachmentNode.AttachmentContentType.text()
            def encodedContent = attachmentNode.AttachmentContent.text()

            // Decode base64
            byte[] decodedBytes = DatatypeConverter.parseBase64Binary(encodedContent)

            // Create DataSource
            def dataSource = new ByteArrayDataSource(decodedBytes, contentType)

            // Create AttachmentWrapper
            def attachment = new AttachmentWrapper(dataSource)

            // Add attachment object
            message.addAttachmentObject(name, attachment)
        }
    }
    return message
}
