import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Access message body via Reader for streaming
    def body = message.getBody(java.io.Reader)
    def properties = message.getProperties()
    def Pid = properties.get("InterfacePID")

    // Define XML parser
    def ListDataStoreEntriesAggregateResponse = new XmlSlurper().parse(body)
    
    //keep for back for now
    //def IDlist=[]
    //ListDataStoreEntriesAggregateResponse.'**'.findAll{ it.name() == 'Id' && it.text().contains(Pid)}.each { item -> IDlist  << item.text()};
    def IDlist = Pid ?
            ListDataStoreEntriesAggregateResponse.'**'.findAll { it.name() == 'Id' && it.text().contains(Pid) }*.text() :
            ListDataStoreEntriesAggregateResponse.'**'.findAll { it.name() == 'Id' && it.text() }*.text()


    //build XML
    def writer = new StringWriter()
    def builder = new MarkupBuilder(writer)
    builder.mkp.xmlDeclaration(version: "1.0", encoding: "utf-8")
    builder.DataStores {
        //iterate through
        IDlist.each {  item ->
            'Entries'{
                'Id'(item)
            }

        }
    }
    message.setBody(writer.toString())


    return message
}