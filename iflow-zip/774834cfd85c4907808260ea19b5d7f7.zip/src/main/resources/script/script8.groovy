import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import org.apache.camel.Exchange
import org.apache.camel.builder.SimpleBuilder
import groovy.xml.MarkupBuilder

def Message processData(Message message) {


	
	def properties = message.getProperties();
    def InterfacePID = properties.get("InterfacePID");
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
			messageLog.addCustomHeaderProperty("RestartJob_Interface", InterfacePID);		
    }
    
    return message;
}
