import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential
import com.sap.it.api.securestore.exception.SecureStoreException
import groovy.xml.StreamingMarkupBuilder;
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import groovy.util.XmlSlurper
import groovy.json.JsonSlurper
import groovy.xml.XmlUtil


class OAuth2TokenService {
    String tokenUrl
    String clientId
    String clientSecret

    OAuth2TokenService(String tokenUrl, String clientId, String clientSecret) {
        this.tokenUrl = tokenUrl
        this.clientId = clientId
        this.clientSecret = clientSecret
    }
    
    
    String fetchAccessToken() {
        URL url = new URL(tokenUrl)
        HttpURLConnection connection = (HttpURLConnection) url.openConnection()
        connection.requestMethod = "POST"
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        
        
        def requestBody = "grant_type=client_credentials" +
        "&client_id=" + URLEncoder.encode(clientId, "UTF-8") +
        "&client_secret=" + URLEncoder.encode(clientSecret, "UTF-8")
        
        // Write the POST data.
        connection.outputStream.withWriter("UTF-8") { writer ->
            writer << requestBody
        }
        
        // Check for a successful response.
        int responseCode = connection.responseCode
        if (responseCode != HttpURLConnection.HTTP_OK) {
        def errMsg = connection.errorStream?.text
                println("Failed to obtain token: HTTP ${responseCode}. Error: ${errMsg}")
                throw new RuntimeException("Failed to obtain token: HTTP ${responseCode}. Error: ${errMsg}")
        }
        
        // Parse the JSON response.
        def responseText = connection.inputStream.text
        def json = new JsonSlurper().parseText(responseText)
        if (json.access_token) {
            return json.access_token.toString()
        } else {
            prinln("Access token not found in the response: ${responseText}")
            throw new RuntimeException("Access token not found in the response: ${responseText}")
        }
    }
}

def Message processData(Message message) {
    
    // get tokenURL, hostname and credentials
    def headers = message.getHeaders()
    def oauth_client_credentials_alias = headers.get("customX_oauth_client_credentials_alias")
    def hostname = headers.get("customX_hostname")
    def tokenUrl = headers.get("customX_tokenUrl")
    
    //get Data Store name and generate URL
    def dataStoreName = message.getProperty("DataStoreName")
    def apiUrl = hostname + "/DataStores(DataStoreName='${dataStoreName}',IntegrationFlow='',Type='')/Entries"
    
    //get clientId and clientSecret for CI API Call maintained as User Credential 
    def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)
    def credential = secureStorageService.getUserCredential(oauth_client_credentials_alias)
    String clientId = credential.getUsername()
    String clientSecret = credential.getPassword().toString()
    
    // Create an instance of OAuth2TokenService and fetch the access token.
    def tokenService = new OAuth2TokenService(tokenUrl, clientId, clientSecret)
    String accessToken
    try {
        accessToken = tokenService.fetchAccessToken()
        println "Obtained Access Token: ${accessToken}"
    } catch (Exception e) {
        throw new RuntimeException("Error fetching access token: ${e.message}")
        System.exit(1)
    }
    
    //execute GET call with set Bearer token
    URL apiEndpoint = new URL(apiUrl)
    HttpURLConnection apiConnection = (HttpURLConnection) apiEndpoint.openConnection()
    apiConnection.requestMethod = "GET"
    apiConnection.setRequestProperty("Authorization", "Bearer " + accessToken)
    apiConnection.setRequestProperty("Accept", "application/xml")

    //check responseCode 
    int apiResponseCode = apiConnection.responseCode
    if (apiResponseCode == HttpURLConnection.HTTP_OK) {
        def apiResponseText = apiConnection.inputStream.text
        def apiXml = new XmlSlurper().parseText(apiResponseText)
        message.setBody(XmlUtil.serialize(apiXml))
    }
    
    else {
        def errorResponse = apiConnection.errorStream?.text
        message.setBody(errorResponse)
    }
    return message;
}