/*
    this groovy script determines the number of responses that would be used to push indivisual responses to process visibility
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def data = jsonSlurper.parseText(body);
    def noOfResponses = data.responses.size();
    message.setProperty("noOfResponses", noOfResponses.toString());
    message.setProperty("responses", data.responses);
    return message;
}