/*
    this groovy script determines the progess of the export
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def data = jsonSlurper.parseText(body);
    def exportStatus = data.result.status
    message.setProperty("exportStatus", exportStatus)
    if(exportStatus == "complete") {
        message.setProperty("fileId", data.result.fileId);
    }
    sleep(60000);
    return message;
}