/*
    this groovy script transforms a single survery response to a json event that can be pushed to process visibility
    
    Add responses to certain questions from the survery by using the sample code snippet 
            QID2: response.labels.QID2 ? response.labels.QID2 : '',
            Q1D3: response.labels.QID3 ? response.labels.QID3 : '',
            QID4: response.labels.QID4 ? response.labels.QID4 : '',
            Q1D5: response.values.QID5_TEXT ? response.values.QID5_TEXT : '',
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def responses = message.getProperty("responses");
    def noOfResponses = message.getProperty("noOfResponses");
    noOfResponses = noOfResponses.toInteger() - 1;
    message.setProperty("noOfResponsesInLoop", noOfResponses.toString());
    if(noOfResponses < 0) {
        return message;
    }

    def response = responses[noOfResponses];

    JsonBuilder jsonEvent = new JsonBuilder();
    def result = jsonEvent {
        processDefinitionId message.getProperty("surveryID")
        processInstanceId response.responseId
        eventType message.getProperty("surverySubmittedEventType")
        timestamp response.values.endDate.toString()
        context(
            QID2: response.labels.QID2 ? response.labels.QID2 : '',
            Q1D3: response.labels.QID3 ? response.labels.QID3 : '',
            QID4: response.labels.QID4 ? response.labels.QID4 : '',
            Q1D5: response.values.QID5_TEXT ? response.values.QID5_TEXT : '',
        )
    }
    message.setProperty("noOfResponses", noOfResponses.toString());
    message.setProperty("jsonEvent", jsonEvent.toString());
    message.setBody(jsonEvent.toString());
    message.setHeader("Content-Type", "application/json");
    return message;
}