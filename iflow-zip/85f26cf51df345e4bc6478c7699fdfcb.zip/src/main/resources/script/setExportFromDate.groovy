/*
  Determine the endDate for the survey responses and set the message body
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Date;
import java.text.SimpleDateFormat;

def Message processData(Message message) {
  simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
 
  def startDate = message.getProperty("startDate");
  if(startDate.size() != 0) {
    startDate = simpleDateFormat.parse(startDate);
    startDate = simpleDateFormat.format(startDate).toString();
  }
  
  def endDate = new Date();
  endDate = simpleDateFormat.format(endDate).toString();
  message.setProperty("endDate", endDate);
  
  messageBody = (startDate.size() != 0) ? 
    '''{ "format": "json", "startDate": "''' + startDate + '",' + '''"endDate": "''' + endDate + '"}' : 
    '''{ "format": "json", "endDate": "''' + endDate + '"}';
  
  message.setBody(messageBody);
  return message;
}