/*
    this groovy script determines the progessId that enables determining if the export is completed or not
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def data = jsonSlurper.parseText(body);
    def progressId = data.result.progressId;
    message.setProperty("progressId", data.result.progressId);
    message.setProperty("exportStatus", "inProgress");
    return message;
}