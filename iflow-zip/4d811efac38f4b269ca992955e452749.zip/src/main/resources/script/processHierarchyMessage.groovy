import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import com.sap.gateway.ip.core.customdev.util.Message;



def Message extractHierarchyInfo(Message message) {
    def body = message.getBody(String.class)

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)

    message.setProperty("Application-Interface-Key", json?.hierarchyInfo?.ApplicationInterfaceKey)
    message.setBody(JsonOutput.toJson(json?.hierarchyInfo))


    return message
}



def Message extractProductHierarchy(Message message){
    def body = message.getBody(String.class)
    if (!body){
        message.setBody("{}")
        return message
    }

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)


    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson([Product : json.ProdUnivHierProdByHierNodeType])))


    return message
}

def Message removeProductInfo(Message message){
    def body = message.getBody(String.class)

    if (!body){
        message.setBody("{}")
        return message
    }

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)

    json.remove("ProdUnivHierProdByHierNodeType")

    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(json)))

    return message
}

def Message appendHierarchyInfo(Message message){
    def body = message.getBody(String.class)
    if (!body){
        message.setBody("{}")
        return message
    }

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)

    json.ProdUnivHierProdByHierNodeType?.each {

        currentNode ->

            def metadata = json.metadata.get(currentNode.ParentNode)?:[]
            def desc = json.desc.get(currentNode.ParentNode)?:[]

            def names = []
            metadata.each{it ->

                names.add(json.names.get(it)?:it)
            }

            def result = []
            if (metadata.size() == desc.size() && metadata && desc){
                result = [metadata, names, desc].transpose()
            } else if (metadata)  {
                result = [metadata, names, metadata].transpose()
            } else {
                result = []
            }
            currentNode.put("hierarchies", result.flatten().join(","))
            currentNode.put("salesOrg", json.hierarchyInfo?.salesOrg)
            currentNode.put("startDate", json.hierarchyInfo?.startDate)
            currentNode.put("distributionChannel", json.hierarchyInfo?.distributionChannel)
            currentNode.remove("ParentNode")
            currentNode.remove("HierarchyNode")



    }

    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(json)))


    return message
}


def Message removeBracket(Message message){
    def body = message.getBody(String.class)

    if (!body || body.length() < 3){
        message.setBody("{")
        return message
    }

    body = body[0..body.size()-2] + ","
    message.setBody(body)
    return message
}

def Message removeFrontBracket(Message message){
    def body = message.getBody(String.class)

    if (!body || body.length() < 3){
        message.setBody("}")
        return message
    }

    body = body[1..body.size()-1]
    message.setBody(body)
    return message
}