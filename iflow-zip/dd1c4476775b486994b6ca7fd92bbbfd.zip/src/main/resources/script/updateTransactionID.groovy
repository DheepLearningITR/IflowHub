import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

	def map = message.getProperties();
	def value = map.get("transactionID");
	String updatedID=value;
	int len=updatedID.length();
	for(int i=len;i<13;i++){
        updatedID="0"+updatedID;	    
	    
	}
	

	message.setProperty("transactionID", updatedID);
	
	return message;
}