import com.sap.it.api.mapping.*;

def String setStatusValue(String type){
    
    if(type == 'E'){
        return "FAILED"
    }
	return "SUCCESS" 
}