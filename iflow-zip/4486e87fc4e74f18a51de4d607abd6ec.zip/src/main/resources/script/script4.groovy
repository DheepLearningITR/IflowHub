import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import java.util.ArrayList;

def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    def body = message.getBody(java.lang.String) as String
    def jsonParser = new JsonSlurper()
    def jsonObject = jsonParser.parseText(body)

    def arr = []
    def error = []
    def json
    def results = {}
    
    for(int i = 0; i < jsonObject.absence.size(); i++ ){
        try {
            
            json = {}
            json = JsonOutput.toJson(
                operation : (jsonObject.absence[i].sprps == 'X') ? 'DEL' : 'INS',
                pernr : jsonObject.absence[i].pernr,
                subty : jsonObject.absence[i].subty,
                begda : jsonObject.absence[i].begda,
                endda : jsonObject.absence[i].endda,
                beguz : (jsonObject.absence[i].beguz == null) ? '' : jsonObject.absence[i].beguz,
                enduz : (jsonObject.absence[i].enduz == null) ? '' : jsonObject.absence[i].enduz,
                externalcode : jsonObject.absence[i].zzextcode
            )
            
            arr.push(json)
        
        } catch(Exception ex) {
            // error.push(jsonObject.User.User[i].userId)
            error.push(ex.toString())
            // arr.push(json)

        }
         
        
    }
    
    message.setBody(JsonOutput.prettyPrint(arr.toString()))  
    // message.setBody(arr.toString())  
    message.setProperty("size_payload_hana", jsonObject.size())
    message.setProperty("array_tratado",  JsonOutput.prettyPrint(arr.toString()))
    // message.setProperty("array_tratado",  arr.toString())
    // messageLog.addAttachmentAsString("PayloadAhgora", JsonOutput.prettyPrint(arr.toString()), "text/json");
    // messageLog.addAttachmentAsString("PayloadBefore", arr.toString(), "text/json");
    // messageLog.addAttachmentAsString("ErrorLoop", error.toString(), "text/plain");
    
    body = message.getBody(java.lang.String) as String
    message.setProperty("length",  body.length())
   
    return message;
    
}