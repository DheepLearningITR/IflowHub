/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.commons.codec.binary.Base64;
import java.security.cert.X509Certificate;
import java.security.cert.Certificate;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;

def Message processData(Message message) {
   
     def map = message.getProperties();
     def header = message.getHeaders();
     
     String mode = map.get("mode");
     String input = map.get("epayment");     
     def submit= header.get("submit");
     def cancel= header.get("cancel");
     int j=0;
  
          
     //Deciding the name of the root node and response path based on the action and mode
     if(submit && mode.equalsIgnoreCase("Test"))
     {
     	message.setProperty("root","cfdi:getCfdiTest");
     	message.setProperty("response","/getCfdiTestResponse/getCfdiTestReturn");
     }
     else if(submit && mode.equalsIgnoreCase("Prod"))
     {
	  	message.setProperty("root","cfdi:getCfdi");
	  	message.setProperty("response","/getCfdiResponse/getCfdiReturn");
	  }
	 else if(cancel)
	 {
	 	message.setProperty("root","cfdi:cancelaCFDi");
	 	message.setProperty("response","/cancelaCFDiSignedResponse/cancelaCFDiSignedReturn");
	 }
	 else if(getStatus && mode.equalsIgnoreCase("Test"))
	 {
	 	message.setPropery("root","cfdi:getUUIDTest");
	 	message.setProperty("response","/getUUIDTestResponse/getUUIDTestReturn");
	 }
	 else if(getStatus && mode.equalsIgnoreCase("Prod"))
	 {
	 	message.setProperty("root","cfdi:getUUID");
	 	message.setProperty("response","/getUUIDResponse/getUUIDReturn");
	 }
	 
	 if(submit)
	 {
	 def alias = map.get("alias");
	 //Access the keystore and get the certificate based on the alias
	 def service = ITApiFactory.getApi(KeystoreService.class, null);
	 
    
     Certificate certs = service.getCertificate(alias);
	 X509Certificate x509certificate = (X509Certificate)certs;
	 
	 //prepare Base64 encoded format of the certificate
	 String certificate =  Base64.encodeBase64String(certs.getEncoded());
	
	 message.setHeader("certificate", certificate);
	
	 }
	 
	return message;
}

