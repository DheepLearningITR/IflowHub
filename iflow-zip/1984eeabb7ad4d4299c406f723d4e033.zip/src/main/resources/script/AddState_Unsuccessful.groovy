import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def properties = message.getProperties();
    def State_unsuccessful = properties.get("State_unsuccessful");

    def body = message.getBody(String);
    def jsonData = new JsonSlurper().parseText(body);

    jsonData.state = State_unsuccessful;

    def jsonOutput = JsonOutput.toJson(jsonData);

    message.setBody(jsonOutput);

    return message;
}
