import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def jsonPayload = message.getBody(java.lang.String) as String

    def jsonSlurper = new JsonSlurper()
    def jsonData = jsonSlurper.parseText(jsonPayload)

    // Extrahiere den Inhalt des 'root'-Elements
    def rootContent = jsonData."multimap:Messages"."multimap:Message1"."root"

    // Setze den extrahierten Inhalt als neuen Body der Nachricht
    if (rootContent) {
        message.setBody(JsonOutput.toJson(rootContent))
    } else {
        // Falls 'root' nicht existiert, behalte den ursprünglichen Payload bei
        message.setBody(jsonPayload)
    }

    return message
}