import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def properties = message.getProperties()
    def typeValue = properties.get("type")
    def baseTypeValue = properties.get("baseType")
    def typeBillingAccountValue = properties.get("type_billingAccount")
    def referredTypeBillingAccountValue = properties.get("referredType_billingAccount")

    def body = message.getBody(String)
    def jsonData = new JsonSlurper().parseText(body)

    if (jsonData instanceof List) {
        jsonData.each { entry ->
            processEntry(entry, typeValue, baseTypeValue, typeBillingAccountValue, referredTypeBillingAccountValue)
        }
    } else if (jsonData instanceof Map) {
        processEntry(jsonData, typeValue, baseTypeValue, typeBillingAccountValue, referredTypeBillingAccountValue)
    }

    def jsonOutput = JsonOutput.toJson(jsonData)
    message.setBody(jsonOutput)

    return message
}

void processEntry(def entry, typeValue, baseTypeValue, typeBillingAccountValue, referredTypeBillingAccountValue) {
    entry."@type" = typeValue
    entry."@baseType" = baseTypeValue

    if (entry.billingAccount) {
        entry.billingAccount.'@type' = typeBillingAccountValue
        entry.billingAccount.'@referredType' = referredTypeBillingAccountValue
    }
}
