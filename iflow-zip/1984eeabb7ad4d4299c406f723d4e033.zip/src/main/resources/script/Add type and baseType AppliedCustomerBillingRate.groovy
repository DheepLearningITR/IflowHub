import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def properties = message.getProperties()

    def typeValueAppliedTaxRate = properties.get("type_appliedTaxRate")
    def baseTypeValueAppliedTaxRate = properties.get("baseType_appliedTaxRate")
    def typeValueBillingAccount = properties.get("type_billingAccount")
    def referredTypeValueBillingAccount = properties.get("referredType_billingAccount")
    def typeValueCustomerBill = properties.get("type_CustomerBill")
    def referredTypeValueCustomerBill = properties.get("referredType_CustomerBill")

    def body = message.getBody(String)
    def jsonData = new JsonSlurper().parseText(body)

    if (jsonData instanceof List) {
        jsonData.each { entry ->
            processEntry(entry, typeValueAppliedTaxRate, baseTypeValueAppliedTaxRate, typeValueBillingAccount, referredTypeValueBillingAccount, typeValueCustomerBill, referredTypeValueCustomerBill)
        }
    } else if (jsonData instanceof Map) {
        processEntry(jsonData, typeValueAppliedTaxRate, baseTypeValueAppliedTaxRate, typeValueBillingAccount, referredTypeValueBillingAccount, typeValueCustomerBill, referredTypeValueCustomerBill)
    }

    def jsonOutput = JsonOutput.toJson(jsonData)
    message.setBody(jsonOutput)

    return message
}

void processEntry(def entry, typeValueAppliedTaxRate, baseTypeValueAppliedTaxRate, typeValueBillingAccount, referredTypeValueBillingAccount, typeValueCustomerBill, referredTypeValueCustomerBill) {
    if (entry.appliedTax) {
        entry.appliedTax.each { tax ->
            tax."@type" = typeValueAppliedTaxRate
            tax."@baseType" = baseTypeValueAppliedTaxRate
        }
    }
    
    if (entry.billingAccount) {
        entry.billingAccount."@type" = typeValueBillingAccount
        entry.billingAccount."@referredType" = referredTypeValueBillingAccount
    }
    

    if (entry.bill) {
        entry.bill."@type" = typeValueCustomerBill
        entry.bill."@referredType" = referredTypeValueCustomerBill
    }
}
