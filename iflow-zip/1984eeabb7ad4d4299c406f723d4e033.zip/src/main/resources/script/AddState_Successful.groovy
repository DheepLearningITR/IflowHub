import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def properties = message.getProperties();
    def State_successful = properties.get("State_successful");

    def body = message.getBody(String);
    def jsonData = new JsonSlurper().parseText(body);

    jsonData.state = State_successful;

    def jsonOutput = JsonOutput.toJson(jsonData);

    message.setBody(jsonOutput);

    return message;
}
