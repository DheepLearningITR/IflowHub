import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def jsonPayload = message.getBody(java.lang.String) as String


    def jsonSlurper = new JsonSlurper()
    def jsonData = jsonSlurper.parseText(jsonPayload)

    def rootData = jsonData["value"]
    
    if (rootData) {
        message.setBody(JsonOutput.toJson(rootData))
    } else {

        message.setBody(jsonPayload)
    }

    return message
}
