import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def properties = message.getProperties()
    def typeValue = properties.get("type")
    def referredTypeValue = properties.get("referredType")

    def body = message.getBody(String)
    def jsonData = new JsonSlurper().parseText(body)

    // Überprüfe, ob jsonData eine Liste oder ein einzelnes Objekt ist
    if (jsonData instanceof List) {
        // Behandle jsonData als Liste
        jsonData.each { entry ->
            processEntry(entry, typeValue, referredTypeValue)
        }
    } else if (jsonData instanceof Map) {
        // Behandle jsonData als einzelnes Objekt
        processEntry(jsonData, typeValue, referredTypeValue)
    }

    def jsonOutput = JsonOutput.toJson(jsonData)
    message.setBody(jsonOutput)

    return message
}

void processEntry(def entry, typeValue, referredTypeValue) {
    entry."@type" = typeValue
    entry."@referredType" = referredTypeValue

    if (entry.billingAccount) {
        entry.billingAccount.'@type' = entry.'@type'
        entry.billingAccount.'@referredType' = entry.'@referredType'
        entry.remove('@type')
        entry.remove('@referredType')
    }
}
