import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Auslesen der Properties
    def properties = message.getProperties()
    def typeValue = properties.get("type")
    def referredTypeValue = properties.get("referredType")

    def body = message.getBody(String)
    def jsonData = new JsonSlurper().parseText(body)

    // Durchlaufe jedes Element des JSON-Objekts
    jsonData.each { entry ->
        // Setze @type und @referredType auf der obersten Ebene
        entry."@type" = typeValue
        entry."@referredType" = referredTypeValue

        // Verschiebe @type und @referredType in das billingAccount-Objekt, falls vorhanden
        if (entry.billingAccount) {
            entry.billingAccount.'@type' = entry.'@type'
            entry.billingAccount.'@referredType' = entry.'@referredType'

            // Entferne @type und @referredType von der obersten Ebene
            entry.remove('@type')
            entry.remove('@referredType')
        }
    }

    def jsonOutput = JsonOutput.toJson(jsonData)
    message.setBody(jsonOutput)

    return message
}
