import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def jsonPayload = message.getBody(java.lang.String) as String
    def modifiedPayload = jsonPayload.replaceAll("@", "")
    message.setBody(modifiedPayload)
    return message
}
