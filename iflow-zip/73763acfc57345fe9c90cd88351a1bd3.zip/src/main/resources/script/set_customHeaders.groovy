import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
	    def testRun = message.getHeaders().get("testRun");
		if(testRun != null && testRun != 'false' && testRun != ''){
			messageLog.addCustomHeaderProperty("cbr_testRun", testRun);		
        }
		def jobProfileId = message.getProperties().get("jobProfileId");
		if(jobProfileId!=null){
			messageLog.addCustomHeaderProperty("cbr_jobProfileId", jobProfileId);		
        }
	}
	return message;
}
def Message extCode(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def extCode = message.getProperties().get("sfsfJobProfileExtCode");
		if(extCode != null){
			messageLog.addCustomHeaderProperty("sfsf_jobProfileExtCode", extCode);		
        }
	}
	return message;
}