import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;


def Message processData(Message message) 
    
    {

    def body = message.getBody(java.lang.String)

    def sub = { it.split("A_Incident")[1] }

    def guid = sub(body).substring(11,47)

    message.setProperty("guid", guid)
    
    return message

    }