package share.odata

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil


def Message processData(Message message) {
    //Body

    //Headers
    def body = message.getBody(java.io.Reader);
    def xs = new XmlSlurper();
    def respbody = xs.parse(body);

    def conditionContract = xs.parseText("<ConditionContract> </ConditionContract>")
    conditionContract.appendNode(respbody.CONDITIONCONTRACTNUMBEROUT)
    conditionContract.appendNode(respbody.HEADDATAOUT)
    conditionContract.appendNode(respbody.RETURN)
    message.setBody(XmlUtil.serialize(conditionContract));
    return message;
}
