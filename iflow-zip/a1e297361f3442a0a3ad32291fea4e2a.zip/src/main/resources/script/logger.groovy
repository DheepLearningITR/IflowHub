import com.sap.gateway.ip.core.customdev.util.Message
import java.util.Map
import java.util.Iterator
import javax.activation.DataHandler

 

def Message processData(Message message) {
  
  def map = message.getProperties();
  def ex = map.get("CamelExceptionCaught");
  
  if (ex instanceof org.apache.cxf.interceptor.Fault) {
    def details = ex.getDetail();    
    message.setBody(details);
  } else {
    message.setBody("unexpected exception: "+ ex.getClass().getName());
  }
  return message;
}