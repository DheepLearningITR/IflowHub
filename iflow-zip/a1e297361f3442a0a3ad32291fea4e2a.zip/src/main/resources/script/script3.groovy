import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.*;

def Message processData(Message message) {
//get Body
	def body = message.getBody(java.lang.String) as String; 
//replaceMultimap tag
	body = body.replace("urn:fhg:cloud:scim:schemas:extension:custom:2.0:User","User"); 

//set body
	message.setBody(body); 
	
	return message;
}