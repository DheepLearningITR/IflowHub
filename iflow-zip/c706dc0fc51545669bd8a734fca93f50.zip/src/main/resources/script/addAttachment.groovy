import com.sap.gateway.ip.core.customdev.util.Message;

/*def Message addMPLAttachment(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        def body = message.getBody(java.lang.String) as String
        messageLog.addAttachmentAsString("Error Message", body, "text/plain");
    }
    return message;
}*/


def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def map = message.getProperties();
    if(messageLog != null){
        def body = message.getBody(java.lang.String) as String
        messageLog.addAttachmentAsString("Error Message", body, "text/plain");
    }
    
    return message;
}