import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    
    def inputBody = new JsonSlurper().parseText(message.getBody(java.lang.String))
    
    def body = inputBody.choices[0].message.content

    message.setBody(body)

    return message
}