import com.sap.gateway.ip.core.customdev.util.Message

// Function to create the DELETE statement in SQL format based on the filename
def Message processData(Message message) {
    // Get the filename from the message headers (assuming it is passed there)
    def fileName = message.getHeaders().get("FileName")

    // Create the DELETE statement based on the filename
    def deleteStatementSql = DeleteStatement(fileName).toString()

    // Set the DELETE statement as the message body
    message.setBody(deleteStatementSql)

    return message
}

// Function to generate the DELETE statement
def DeleteStatement(String fileName) {
    def tableName = ""

    // Check if the filename contains 'dds-expense-reports' or 'dds-cards-transaction'
    if (fileName.contains("dds-expense-reports")) {
        tableName = "CONCUR_EXP_DDS_OBJ_EXPENSE_REPORT"
    } else if (fileName.contains("dds-cash-advance")) {
        tableName = "CONCUR_EXP_DDS_OBJ_CASH_ADVANCE"
    } else if (fileName.contains("dds-cards-transaction")) {
        tableName = "CONCUR_EXP_DDS_OBJ_CREDITCARD_TRANSACTIONS"
    } else if (fileName.contains("dds-attendee")) {
        tableName = "CONCUR_EXP_DDS_OBJ_ATTENDEE"
    } else if (fileName.contains("dds-cards-account")) {
        tableName = "CONCUR_EXP_DDS_OBJ_CREDITCARD_ACCOUNTS"
    } else if (fileName.contains("dds-list-item")) {
        tableName = "CONCUR_EXP_DDS_OBJ_LIST_ITEMS"
    } else if (fileName.contains("dds-spend-user")) {
        tableName = "CONCUR_EXP_DDS_OBJ_SPEND_USER"
    } else if (fileName.contains("dds-core-user")) {
        tableName = "CONCUR_EXP_DDS_OBJ_CORE_USER"
    } else if (fileName.contains("dds-core-company")) {
        tableName = "CONCUR_EXP_DDS_OBJ_CORE_USER_COMPANY"
    } else if (fileName.contains("dds-reference-expense-type")) {
        tableName = "CONCUR_EXP_DDS_OBJ_REF_EXPENSE_TYPE"
    } else if (fileName.contains("dds-reference-payment-code")) {
        tableName = "CONCUR_EXP_DDS_OBJ_REF_PAYMENT_CODE"
    } else if (fileName.contains("dds-reference-payment-type")) {
        tableName = "CONCUR_EXP_DDS_OBJ_REF_PAYMENT_TYPE"
    } else if (fileName.contains("dds-reference-spend")) {
        tableName = "CONCUR_EXP_DDS_OBJ_REF_SPEND_CATEGORY"
    } else if (fileName.contains("dds-reference-approval-status") || fileName.contains("dds-reference-payment-status"))  {
        tableName = "CONCUR_EXP_DDS_OBJ_REF_STATUS"
    } else {
        throw new IllegalArgumentException("Unsupported file type")
    };

    //DELETE statement to switch between tabels
    return """DELETE FROM "SAP_CONTENT#SAP_CONCUR_EXP_DDS"."${tableName}"
              WHERE PROCESSED_FLAG IS NULL;"""
}
