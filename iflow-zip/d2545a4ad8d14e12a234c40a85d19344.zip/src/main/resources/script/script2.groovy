/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */

import com.sap.gateway.ip.core.customdev.util.Message
import java.util.Map
import java.util.Iterator
import javax.activation.DataHandler
import java.util.Collections

import java.util.HashMap;
def Message processData(Message message) {
	Map<String, DataHandler> attachments = message.getAttachments();

    message.setProperty("found", 'false');
    def emailSub = message.getHeader("Subject",java.lang.String);
    // def rutid = emailSub.split("-")[2];
    // def devid = emailSub.split("-")[3];
    // rutid = rutid + "-" + devid;
    // rutid.replaceAll(" ","");
    def rutid = emailSub[-10..-1];
    def dataStoreName = "Chile_SII_Emails_" + rutid;
    dataStoreName.replaceAll("\\s",""); 
    message.setProperty("dataStoreName", dataStoreName);


	if (!attachments.isEmpty()) {
		
		attachments.values().each { attachment ->
		    
			if(attachment.getName() =~ message.getProperty("attachmentNamePattern") ){
			
			    message.setProperty("attName",    attachment.getName());
			  //   message.setProperty("attContent", readInputStream(attachments.get(attachment.getKey()).getInputStream()));
			    message.setProperty("attContent", attachment.getContent().toString() );
			    message.setBody(attachment.getContent());
                message.setProperty("found",             "true");
			}
		}
	}
	
	//Collection<Attachment> attachments2 = new LazyAttachmentCollection(this);
    //Map<String, DataHandler> attachments2;
    //message.setAttachments(attachments2);
	
	//message.setBody("");
	
	message.setAttachments(java.util.Collections.emptyMap());
	
	return message;
	
}