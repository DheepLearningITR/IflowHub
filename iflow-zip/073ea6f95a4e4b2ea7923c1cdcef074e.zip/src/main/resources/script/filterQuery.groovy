import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def Body = message.getBody(java.lang.String) as String;
    Body = Body.trim();
    String ODataQuery = Body.replaceAll("\n", "or ").replaceAll(" ",'%20' );
    
    def prop = message.getProperties();
    def EnableMultiCompany = prop.get("EnableMultiCompany");
    def Account = prop.get("X-Account-ID");
    def Company = prop.get("X-Company-ID");

    def ODataQueryMC;
    if (EnableMultiCompany == 'true' && Company != ''){
        ODataQueryMC = '(' + ODataQuery + ') and (FSMAccount eq \'' + Account + '\' and FSMCompany eq \'' + Company + '\')'
        ODataQuery = ODataQueryMC.replaceAll(" ",'%20' );
    }    
    
    message.setProperty("filterQuery", ODataQuery);
    message.setBody('')
    return message;
    
}