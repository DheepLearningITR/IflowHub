import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil;
import groovy.util.slurpersupport.NodeChild;

def Message processData(Message message) {
    /* This script is to log the BP IDs that are filtered out with no FSM company. */
	
    def body = message.getBody(java.lang.String)
    def query = new XmlSlurper().parseText(body)
    def messageLog = messageLogFactory.getMessageLog(message)
	
    query.BusinessPartnerSUITEBulkReplicateRequest.BusinessPartnerSUITEReplicateRequestMessage.each { bpMessage ->
        bpMessage.BusinessPartner.each { bp ->
            def internalID = bp.InternalID.text()
            if (messageLog != null) {
                messageLog.addCustomHeaderProperty("FSMCompanyNotFoundForBusinessPartner", internalID)
            }
        }
    }
    return message
}
