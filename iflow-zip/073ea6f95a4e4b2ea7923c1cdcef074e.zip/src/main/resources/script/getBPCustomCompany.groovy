import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.util.XmlParser
import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script gets BP Object details for custom company determination */
    
    def body = message.getBody(String)
    def parsedXml = new XmlSlurper().parseText(body)
    def customObjects = new XmlParser().parseText("<CustomObjects></CustomObjects>")

    parsedXml.BusinessPartnerSUITEBulkReplicateRequest.each { bpRequest ->
        //get the BP details where Custom rule type is set at the object level
        if (bpRequest.@MultiCompanyGroup.text() in ['CUSTOM', 'ATTRIBUTE']) {
            bpRequest.BusinessPartnerSUITEReplicateRequestMessage.each { bpMessage ->
                bpMessage.BusinessPartner.each { bp ->
                    bp.Role.each { role ->
                        def customObjectXml = buildCustomObjectXml(bp, role, bpRequest.@MultiCompanyGroup.text())
                        def customObjectNode = new XmlParser().parseText(customObjectXml)
                        customObjects.append(customObjectNode)
                    }
                }
            }
        }
    }

    message.setBody(XmlUtil.serialize(customObjects))
    return message
}

def String buildCustomObjectXml(bp, role, ruleType) {
    def builder = new StringBuilder()
    builder.append("<customObject>")
    builder.append("<SrvcMgmtFSMRplctnObjID>").append(bp.InternalID.text()).append("</SrvcMgmtFSMRplctnObjID>")
    builder.append("<SrvcMgmtFSMReplicationObject>BP</SrvcMgmtFSMReplicationObject>")

    if (ruleType == 'ATTRIBUTE') {
        builder.append("<SrvcMgmtFSMRplctnObjAttribute>BPROLE</SrvcMgmtFSMRplctnObjAttribute>")
        builder.append("<SrvcMgmtFSMRplctnObjAttribVal>").append(role.RoleCode.text()).append("</SrvcMgmtFSMRplctnObjAttribVal>")
    } else {
        builder.append("<SrvcMgmtFSMRplctnObjAttribute></SrvcMgmtFSMRplctnObjAttribute><SrvcMgmtFSMRplctnObjAttribVal></SrvcMgmtFSMRplctnObjAttribVal>")
    }

    builder.append("</customObject>")
    return builder.toString()
}
