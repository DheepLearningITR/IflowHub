import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {

    def body = message.getBody(String)
    def slurper = new XmlSlurper()
    def xml = slurper.parseText(body)

    def metaInfo = xml.meta.pagination
    def nextPageQuery = metaInfo.links.next.text()

    if (nextPageQuery) {
        def nextPageNumber = metaInfo.current_page.text().toInteger() + 1
        message.setProperty("query_products_page", nextPageNumber)
    } else {
        message.setProperty("has_more_products", false)
    }

    return message
}
