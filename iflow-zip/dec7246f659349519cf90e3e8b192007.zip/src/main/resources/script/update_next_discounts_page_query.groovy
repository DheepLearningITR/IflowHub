import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def body = message.getBody(String)
    def slurper = new JsonSlurper()
    def json = slurper.parseText(body)

    def metaInfo = json.meta.pagination
    def nextPageQuery = metaInfo.links.next

    if (nextPageQuery) {
        def nextPageNumber = metaInfo.current_page.toInteger() + 1
        message.setProperty("query_discounts_page", nextPageNumber)
    } else {
        message.setProperty("has_more_discounts", false)
    }

    return message
}