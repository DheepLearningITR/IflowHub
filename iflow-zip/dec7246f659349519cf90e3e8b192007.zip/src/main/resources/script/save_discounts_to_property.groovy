import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def bigCommerceDiscountsList = message.getHeader("big_commerce_discount_list", String)
    def responseBody = message.getBody(String) as String
    def jsonSlurper = new JsonSlurper()
    def existingDiscounts = []

    if (bigCommerceDiscountsList?.trim()) {
        try {
            def parsedBigCommerceDiscountsList = jsonSlurper.parseText(bigCommerceDiscountsList)
            existingDiscounts = parsedBigCommerceDiscountsList.discounts ?: []
        } catch (Exception e) {
            existingDiscounts = []
        }
    }

    def parsedResponseBody = jsonSlurper.parseText(responseBody)

    def incomingDiscountsRaw = parsedResponseBody?.data ?: []

    def incomingDiscounts = incomingDiscountsRaw.collect { discount ->
        [
                id       : discount.id,
                productId: discount.rules[0].action.cart_items.items.products[0]
        ]
    }

    existingDiscounts.addAll(incomingDiscounts)

    def accumulatedDiscountsList = [discounts: existingDiscounts]

    def builder = new JsonBuilder(accumulatedDiscountsList)
    def newDiscountsListJson = builder.toPrettyString()

    message.setHeader("big_commerce_discount_list", newDiscountsListJson)

    return message
}