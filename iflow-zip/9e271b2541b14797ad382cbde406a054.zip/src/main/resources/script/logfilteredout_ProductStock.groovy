import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil;
//import groovy.util.slurpersupport.NodeChild;

def Message processData(Message message) {
    /* This script is to log the Product Stock assignment IDs that are filtered out with no FSM company. */
	
    def body = message.getBody(java.lang.String)
    def query = new XmlSlurper().parseText(body)
    def messageLog = messageLogFactory.getMessageLog(message)
    def plant;
    def material;
    def storagelocation;
	
    query.Warehouse.each { stockMessage ->
        stockMessage.data.each { stock ->
         externalId = stock.externalId.text();
         if (messageLog != null) {
            messageLog.addCustomHeaderProperty("FSMCompanyNotFoundForWarehouse", externalId)
               
            }
        }
    }
    return message
}