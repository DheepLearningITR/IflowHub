import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
//import groovy.util.XmlParser
//import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script is to merge the custom FSM company with incoming warehouse*/    
    def body = message.getBody(String)
    def parsedXml = new XmlParser().parseText(body)
    def propmap = message.getProperties(); 

    def srcparsedXml = new XmlParser().parseText(propmap.get("customCompanyMessage"))

    parsedXml.'multimap:Message1'.SrvcMgmtFSMCompanyCstmLogic.SrvcMgmtFSMCompanyCstmLogic_Type.each { it ->
        def account = it.FSMAccount.text()
        def company = it.FSMCompany.text()

        srcparsedXml.Warehouse.each { whRequest ->        
			if (whRequest.@MultiCompanyGroup == 'CUSTOM') {
				whRequest.data.each { whMessage ->                
                    def customCompany = new XmlParser().parseText("<FSMCustomCompany>${account}|${company}</FSMCustomCompany>")
					if (whMessage.externalId.text() == it.SrvcMgmtFSMRplctnObjID.text()) {
						whMessage.FSMMultiCompany[0].append(customCompany)
					}
				}
			}
		}
	}

    message.setBody(XmlUtil.serialize(srcparsedXml))
    return message
}

