import groovy.json.JsonSlurper
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def content = jsonSlurper.parseText(body);
    def properties  = message.getProperties();
    def messageLog = messageLogFactory.getMessageLog(message);
    def multiCompFlag = properties.get("EnableMultiCompany");
    
    content.each{
        if (it.status >= 400 && it.status < 600) {
            message.setProperty("ErrorType", "FSMError");
            message.setProperty(message.getProperty("CamelSplitIndex")+'http.StatusCode', it.status)
            message.setProperty(message.getProperty("CamelSplitIndex")+'http.ResponseBody', body)
            if (it.status == 500) {
                message.setProperty(message.getProperty("CamelSplitIndex")+'http.StatusText', it.message);
            } else {
                message.setProperty(message.getProperty("CamelSplitIndex")+'http.StatusText', it.ex.message);
            }

            //log failed Products in MPL headers
            if(messageLog != null){
                if(multiCompFlag == "true"){
                   //if (it.ex.size()>0)
			        messageLog.addCustomHeaderProperty("WarehouseFailedtoUpdate", it.externalId + '|' + properties.get("X-Company-ID"));
                }
            }
            
        }
    }    
    
    return message;
}
