import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
    // Get the body of the message as a string
    def body = message.getBody(String)

    // Replace <batchChangeSet1> with </batchChangeSet1>
    body = body.replaceAll("<batchChangeSet1>", "")
    body = body.replaceAll("</batchChangeSet1>", "")

    // Replace <batchParts> with </batchParts>
    body = body.replaceAll("<batchParts>", "")
    body = body.replaceAll("</batchParts>", "")

    // Set the modified body back to the message
    body = "<batchParts> <batchChangeSet1>" + body + "</batchChangeSet1></batchParts>"
    message.setBody(body)

    return message
}