import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script is to escape spaces */
    
    def body = message.getBody(String)

    def prop = message.getProperties();
    def propvalue = prop.get("CamelSplitIndex");
    message.setProperty("customsplitIndex", propvalue + 1);
 
    return message
}