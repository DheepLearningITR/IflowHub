import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message)
{
//this script is formate the owners and orglevelIds in warehouse payload
    def body = message.getBody(java.lang.String) as String;
    def jsonParser = new JsonSlurper();
    
    body = body.replace("{\"@nil\":\"true\"}","null");
    def ownerArr = new JsonSlurper().parseText('[]')
    
    def jsonObject = jsonParser.parseText(body);
    jsonObject.Warehouse.data.each{ item ->
        
        //Format owners
        item.owners.unique().each{
            if(it != ""){
                ownerArr << [externalId: it]
            }
        }
        item.owners = ownerArr
        ownerArr = new JsonSlurper().parseText('[]')
        
        //Format orgLevelIds
        def orglvl = item?.orgLevelIds
        if (orglvl){
           def orgLevelIds = orglvl?.externalId.unique() //get unique orglevel externalIds
            def externalIdList = []
            orgLevelIds.each { extID ->
                if (extID.replaceAll("O ","") != '' && extID.replaceAll("O ","") != '*')
                    externalIdList << [ externalId: extID.replaceAll("O ","") ]
            }

            item.orgLevelIds = externalIdList
        }else{
            item.orgLevelIds = []
        }
    }
    

    def updatedBody = new JsonBuilder(jsonObject.Warehouse.data).toPrettyString()
    message.setBody(updatedBody);
    message.setProperty("RequestPayload", updatedBody);
    
    // To access FSM, company and account are required -- either their name or their ID.
    // If the IDs are configured, they are used; otherwise, the names are used.
    def accountCompany = '';
    def accountID = message.getProperty('X-Account-ID');
    def accountName = message.getProperty('X-Account-Name');
    def companyID = message.getProperty('X-Company-ID');
    def companyName = message.getProperty('X-Company-Name');
    

    if (accountID == null || accountID == '' || accountID == '<FSM_Account_ID>' || companyID == null || companyID == '' || companyID == '<FSM_Company_ID>') {
        accountCompany = 'account='+accountName+'&company='+companyName+'&';
        message.setHeader('X-Account-Name', accountName);
        message.setHeader('X-Company-Name', companyName);
    } else {
        accountCompanyUser = '';
        message.setHeader('X-Account-ID', accountID);
        message.setHeader('X-Company-ID', companyID);
    }
    message.setProperty('AccountCompany', accountCompany);
    
    return message;
}