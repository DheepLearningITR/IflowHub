import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
//import groovy.util.XmlParser
//import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script merge custom company with regular company group messages */    
    def body = message.getBody(String)
    def parsedXml = new XmlParser().parseText(body)
    def propmap = message.getProperties(); 

    def srcparsedXml = new XmlParser().parseText(propmap.get("groupedMessage"))

    parsedXml.'Warehouse'.each { prMessage ->
        srcparsedXml.append(prMessage)
    }

    message.setBody(XmlUtil.serialize(srcparsedXml))
    return message
}