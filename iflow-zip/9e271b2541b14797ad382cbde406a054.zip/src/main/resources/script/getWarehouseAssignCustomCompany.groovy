import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.util.XmlParser
import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script gets Warehouse Object details for custom company determination */
    
    def body = message.getBody(String)
    def parsedXml = new XmlSlurper().parseText(body)
    def customObjects = new XmlParser().parseText("<CustomObjects></CustomObjects>")

    parsedXml.Warehouse.each { whRequest ->
        //get the Warehouse Owner details where Custom rule type is set at the object level
        if (whRequest.@MultiCompanyGroup.text() in ['CUSTOM']) {
            whRequest.data.each { wh ->
                    def customObjectXml = buildCustomObjectXml(wh, wh, whRequest.@MultiCompanyGroup.text())
                    def customObjectNode = new XmlParser().parseText(customObjectXml)
                    customObjects.append(customObjectNode)
            }
        }
    }

    message.setBody(XmlUtil.serialize(customObjects))
    return message
}

def String buildCustomObjectXml(wh, type, ruleType) {
    def builder = new StringBuilder()
    builder.append("<customObject>")
    builder.append("<SrvcMgmtFSMRplctnObjID>").append(wh.externalId.text()).append("</SrvcMgmtFSMRplctnObjID>")
    builder.append("<SrvcMgmtFSMReplicationObject>PS</SrvcMgmtFSMReplicationObject>")
    builder.append("<SrvcMgmtFSMRplctnObjAttribute></SrvcMgmtFSMRplctnObjAttribute><SrvcMgmtFSMRplctnObjAttribVal></SrvcMgmtFSMRplctnObjAttribVal>")
    
    builder.append("</customObject>")
    return builder.toString()
}
