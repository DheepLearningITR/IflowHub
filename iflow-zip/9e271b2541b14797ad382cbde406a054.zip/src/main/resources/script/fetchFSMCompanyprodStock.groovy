import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.asdk.datastore.*
import com.sap.it.api.asdk.runtime.*

def Message processData(Message message) {
    def body = message.getBody(java.lang.String)
    def query = new XmlParser().parseText(body)
    def map = message.getProperties();
    def Warehouse_Delimiter = map.get("Warehouse_Delimiter")
    
    def valueMappingApi = ITApiFactory.getApi(ValueMappingApi.class, null)

    /*START: Logic to handle all & custom FSM Company mapping*/
    def allCompanies = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', 'PS', 'FSM', 'AccountCompany');
    if (allCompanies == 'ALLCOMPANIES') {
		def fsmCompanyList;
        def messageLog = messageLogFactory.getMessageLog(message)
        def DSservice = new Factory(DataStoreService.class).getService()
        // get the FSM Company List from data store
        def dsEntry = DSservice.get("FSMCompanyList", 'FSMCompanyList')?DSservice.get("FSMCompanyList", 'FSMCompanyList'):'NA'
		if (dsEntry != 'NA'){
			def result = new String(dsEntry.getDataAsArray())
			fsmCompanyList = new XmlParser().parseText(result)
		}else{
		    fsmCompanyList = new XmlParser().parseText("<FSMMultiCompany><FSMCompany>NA|NA</FSMCompany></FSMMultiCompany>")
		}
		
        query.data.each { stockMessage ->
            stockMessage.append(fsmCompanyList)
        }
    }else if (allCompanies == 'CUSTOM') {	
		customCompany = new XmlParser().parseText("<FSMMultiCompany><FSMCompany>CUSTOM</FSMCompany></FSMMultiCompany>")
		
        query.data.each { stockMessage ->
            stockMessage.append(customCompany)
            
        }
	/*END: Logic to handle all & custom Company logic*/
    }else{

        query.data.each { stockMessage ->
                def mcXML = new XmlParser().parseText("<FSMMultiCompany></FSMMultiCompany>")
                def fsmFromValueMap = null;

                //function to append account and company to incoming message
                def appendAccountCompany = { AcctComp ->
                    def entries = AcctComp.tokenize(":")
                    entries.each { entry ->
                        def (account, companies) = entry.split("\\|")
                        def companyList = companies.split(",")
                        
                        companyList.each { company ->
	    			        def fsmXml = new XmlParser().parseText("<FSMCompany>${account}|${company}</FSMCompany>")
	    			        mcXML.append(fsmXml)
                        }
                    }
                }
                
                plant = stockMessage.externalId.text().split(Warehouse_Delimiter)[0];
                def pStockKeyMap = "PS|||PLANT|${plant}"
                fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', pStockKeyMap, 'FSM', 'AccountCompany')
                fsmFromValueMap = fsmFromValueMap
                if(fsmFromValueMap){
	    			appendAccountCompany(fsmFromValueMap);
	    		}
                
	    		if (!mcXML.FSMCompany)
	    		{
	    			def fsmXml = new XmlParser().parseText("<FSMCompany>NA|NA</FSMCompany>")
	    			mcXML.append(fsmXml)
	    		}
                stockMessage.append(mcXML)
            
        }
    }

    def FSMCompanyData = XmlUtil.serialize(query)
    message.setBody(FSMCompanyData)
    return message
}
