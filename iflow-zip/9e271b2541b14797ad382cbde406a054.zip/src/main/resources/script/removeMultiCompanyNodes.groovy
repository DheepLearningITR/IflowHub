import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil

def Message processData(Message message) {
    /* This script is rmeove the FSM MultiCompany nodes from the output payload*/    
    def body = message.getBody(String)
    def parsedXml = new XmlParser().parseText(body)

    // Find and remove all FSMMultiCompany nodes
    parsedXml.data.each { dataNode ->        
        if (dataNode.FSMMultiCompany[0])        
            dataNode.remove(dataNode.FSMMultiCompany[0])
    }

    message.setBody(XmlUtil.serialize(parsedXml))
    return message
}

