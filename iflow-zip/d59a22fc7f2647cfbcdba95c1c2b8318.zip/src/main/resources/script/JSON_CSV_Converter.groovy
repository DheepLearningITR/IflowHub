import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {

	def body = message.getBody(String.class);
		message.setProperty("data1", body);
	def data = new JsonSlurper().parseText(body) 
	def columns = data.row*.keySet().flatten().unique()
	message.setProperty("columns", columns);

	// Wrap strings in double quotes, and remove nulls
	def encode = { e -> e == null ? '' : e instanceof String ? /"$e"/ : "$e" }
		message.setProperty("columnsecode", encode);
	
	// Add all the column names
	String payload = columns.collect { c -> encode( c ) }.join( ',' )
	payload = payload.concat('\n')
		message.setProperty("payload", payload);
	// Add all the rows
	data.row.collect { row ->
		payload = payload.concat(columns.collect { colName -> encode( row[ colName ] ) }.join( ',' ))
		payload = payload.concat('\n')
	}.join( '\n' )
	
	def dubpayload=payload;
		message.setProperty("Afterpayload", payload);


	///Logic for identifying failed records

    List<String> inputlist = new ArrayList<String>();
	List<String> outputlist = new ArrayList<String>();
	def tempstr;
	
	def map = message.getHeaders();
    map = message.getProperties();
    message.setProperty("O_ArrayData", outputlist);

	inputlist = message.getProperty("P_ArrayData");
	
	payload = payload.replace("SNo","Record No.");
	payload = payload.replace("message","Error Message");
	
		message.setProperty("AfterReplacementpayload", payload);
	
	payload.eachLine {String line ->
		outputlist.add(line);
		if(tempstr == null) {
			tempstr = line;
			tempstr = tempstr.concat('\n');
		}
	}
		message.setProperty("outputlist", outputlist);
			message.setProperty("tempstr", tempstr);
//	message.setProperty("tempstr ",tempstr);
//	message.setProperty("payload ",payload);
	
	for (i = 1; i <outputlist.size(); i++) {
        
		def temp_olist = outputlist[i].replaceAll (/"/, '')    
		message.setProperty("temp_olist ",temp_olist);
    
		for (j = 1; j <inputlist.size(); j++) {

			if(temp_olist.contains(inputlist[j])) {
			
				def a = outputlist[i].indexOf('"')
					message.setProperty("a ",a);
				def b = outputlist[i].indexOf(',')
					message.setProperty("b ",b);
				
				tempstr = tempstr + outputlist[i].substring(0,a+1) + (j) + outputlist[i].substring(b-1)+"\n";
				message.setProperty("tempstr again ",tempstr);
				//outputlist[i] = tempstr;
				
			}
		}        
    }
	tempstr.replaceAll("SNo","Record No.");
	tempstr.replaceAll("message","Error Message");
	
	//message.setProperty("O_ArrayData2", payload);
	//////////////////////////////////
	
	message.setBody(dubpayload);//payload)
		
	return message;
}
