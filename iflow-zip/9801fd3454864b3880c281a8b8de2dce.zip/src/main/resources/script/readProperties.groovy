import com.sap.it.api.mapping.*;

def String getBPGroupCode(String header, MappingContext context){
    return context.getProperty("bpGroupCode");
} 
