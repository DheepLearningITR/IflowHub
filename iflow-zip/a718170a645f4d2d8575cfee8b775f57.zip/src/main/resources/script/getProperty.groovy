import com.sap.it.api.mapping.*;

//Add MappingContext parameter to read or set headers and properties
def String getExchangeProperty(String propertyName,MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}