import com.sap.it.api.mapping.*;

//Get yMkt Tracking Id value
def String getExchangeProperty(String propertyName, MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}


