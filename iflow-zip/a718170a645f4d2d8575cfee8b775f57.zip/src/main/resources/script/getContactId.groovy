import com.sap.it.api.mapping.*;

//Get Contact Id by passing the yMktId and Contact Id
def String getContactId(String ymktId, String contactId){
    
    if(ymktId != null && !"".equals(ymktId)){
        return ymktId;
    }
	return contactId; 
}