import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import org.json.simple.*
import groovy.json.*
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    //Get Body 
    def body = message.getBody(String.class)

    //Define JSONSlurper
    def jsonSlurper = new JsonSlurper()
    def list = jsonSlurper.parseText(body)

    def stringWriter = new StringWriter()
    def peopleBuilder = new MarkupBuilder(stringWriter)		
		 
    peopleBuilder.root {
        active(list.active)
        client_id(list.client_id)
        username(list.username)
        scope(list.scope)
        sub(list.sub)
        exp(list.exp)
        iat(list.iat)
    }
        
    def xml = stringWriter.toString()    
    if(list.active == true) {
        message.setProperty("active", list.active)
    }
    message.setBody(xml)
    return message
}
