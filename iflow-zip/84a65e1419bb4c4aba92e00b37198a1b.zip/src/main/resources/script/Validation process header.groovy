import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
	
	def map = message.getHeaders()
	map.remove("X-ConsumerKey")
		
	message.setHeader("Authorization", "Basic " + 'U0FQX1BheXJvbGw6RGgxQjBOeURwTzE=')
	//message.setHeader("Authorization", "Basic " + 'U0FQX1BheXJvbGw6b0RTY3VWcnc=')
	return message

}
