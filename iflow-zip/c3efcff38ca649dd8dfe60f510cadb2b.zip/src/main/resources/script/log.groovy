import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.op.agent.mpl.*;
import groovy.transform.Field;
import groovy.json.JsonOutput;

@Field String ORIGINAL_PAYLOAD_LOG = '1. Inbound Request';
@Field String CONFIRM_RESERVATION_LOG = '2. Mapped Confirm Reservation Request';
@Field String DELETE_RESERVATION_LOG = '2. Mapped Delete Reservation Request';
@Field String OMSA_RESPONSE_LOG = '3. OMSA Response';
@Field String EXCEPTION_LOG = '3. Error Response';
@Field String POST_EXIT_LOG = 'Exit Output';

def Boolean isDebug(Message message) { 
    final MplConfiguration config = message.getProperty("SAP_MessageProcessingLogConfiguration");
    return config.getOverallLogLevel() == MplLogLevel.DEBUG;
}

def Message logOriginalRequest(Message message) { 
     processData(ORIGINAL_PAYLOAD_LOG, message);
}

def Message logConfirmReservation(Message message) { 
     processData(CONFIRM_RESERVATION_LOG, message);
}

def Message logDeleteReservation(Message message) { 
     processData(DELETE_RESERVATION_LOG, message);
}

def Message logOMSAResponse(Message message) { 
     processData(OMSA_RESPONSE_LOG, message);
}

def Message logException(Message message) { 
     processData(EXCEPTION_LOG, message);
}

def Message logExitOutput(Message message) { 
     processData(POST_EXIT_LOG, message);
}

def Message processData(String title, Message message) {
     if (isDebug(message)) {
          def body = message.getBody(java.lang.String);	
          def headers = message.getHeaders();
          def properties = message.getProperties();

          def propertiesAsString ="\n";
          properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };

          def headersAsString ="\n";
          headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };

          def messageLog = messageLogFactory.getMessageLog(message);

          if(messageLog != null) {
             try{
                 body = body ? JsonOutput.prettyPrint(body) : "";
             }catch(Exception ex){
                 //in case request payload is not in json format
             }
             messageLog.addAttachmentAsString(title , "\n Properties \n ----------   \n" + propertiesAsString +
                                                                 "\n Headers \n ----------   \n" + headersAsString +
                                                                 "\n Body \n ----------  \n\n" + body, "text/plain");
          }
     }
     return message;
}
