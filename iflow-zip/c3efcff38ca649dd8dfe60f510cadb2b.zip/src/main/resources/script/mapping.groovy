import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import com.sap.it.op.agent.mpl.*;
import java.text.SimpleDateFormat;

@Field String RESERVATION_STATUS_CONFIRMED = 'CONFIRMED';
@Field String RESERVATION_OPERATION_CONFIRM = 'CONFIRM_RESERVATION';
@Field String RESERVATION_OPERATION_DELETE = 'DELETE_RESERVATION';
@Field String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";

def Message extractProperties(Message message) {
	
	String body = message.getBody(java.lang.String);
	
	def bodyJson = new JsonSlurper().parseText(body);
	
	String operation = bodyJson.operation;
	
	//validate operation type
	if (operation != RESERVATION_OPERATION_CONFIRM && operation != RESERVATION_OPERATION_DELETE) {
		//unsupported operation exception
		throw new Exception("Unsupported reservation operation " + operation);
	}
	
	def reservationId = bodyJson.reservationId;	
	if (reservationId == null || reservationId == '') {
		throw new Exception("Reservation id is empty");
	}
	
	message.setProperty("operation", operation);	
	message.setProperty("reservationId", reservationId);	
	
	return message;
}

def Message mapRequestConfirm(Message message) {    
    
	message.setHeader("Content-Type", "application/json");		

    def omsaPayload = [:];	
	omsaPayload.reservationStatus = RESERVATION_STATUS_CONFIRMED;
	
	//Note: date should eventually come from S4HANA backend and correspond to order confirmation time, not the current time
	def sdf = new SimpleDateFormat(DATE_FORMAT);
	omsaPayload.orderConfirmedAt = sdf.format(new Date());
	
	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(omsaPayload)));  	
    
	return message;
}

def Message mapRequestDelete(Message message) {    
    message.setHeader("Content-Type", "application/json");	
    message.setBody("");
    return message;
}

