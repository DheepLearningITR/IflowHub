import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;
import groovy.json.JsonOutput;
import groovy.json.JsonSlurper;

@Field String IFLOW_ERROR_CODE = '500';
@Field String IFLOW_ERROR_TYPE = 'IFLOW_ERROR';
@Field String OMSA_ERROR_TYPE = 'OMSA_ERROR';
@Field String IFLOW_ERROR_MSG = 'A technical error occurred in the iFlow.';
@Field String IFLOW_INVALID_HOST_CODE = '404';
@Field String IFLOW_INVALID_HOST_MSG = 'The Sourcing and Availability host configured in the iFlow could not be reached.';
@Field String IFLOW_UNKNOWN_ERROR_MSG = 'An error occurred while calling Sourcing and Availability.';

@Field String ERROR_SHORTTEXT = 'ERROR'
@Field String INFO_SHORTTEXT = 'INFO'
@Field String GENERIC_ERROR_MESSAGE = 'A technical error occurred. Use the SAP Cloud Integration message ID to find additional error details.'
@Field String CPI_MSGID_TEXT = 'SAP Cloud Integration message ID: '


class ResponseMsg {
	String message
	String type
}

def Message processExceptionMessage(Message message) {
    String errorMessage = ""
    try {
        def exceptionProperty = message.getProperty('CamelExceptionCaught')
        errorMessage = exceptionProperty.message

        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (exceptionProperty.getClass().getCanonicalName().equals('org.apache.camel.component.ahc.AhcOperationFailedException')) {
            errorMessage = exceptionProperty.getResponseBody()
            errorMessage = errorMessage.replaceAll("\\P{Print}", '') ?: exceptionProperty.message
        }
    } catch(Exception ex) {}

    errorMessage = errorMessage ?: GENERIC_ERROR_MESSAGE
    message.setBody(errorMessage)
    return message
}


def Message buildErrorResponse(Message message) {
    
    message.setHeader('Content-Type', 'application/json')

    def response = [:];
    def body = message.getBody(java.lang.String) ?: GENERIC_ERROR_MESSAGE;
    def responseCode = message.getHeader("CamelHttpResponseCode", java.lang.Integer)
    

    List<ResponseMsg> respMsgs = [];
    // possible case where body is not a JSON
    try {
        body = new JsonSlurper().parseText(body);
        if (responseCode == 500) {
            respMsgs.add(new ResponseMsg(type:ERROR_SHORTTEXT, message: body.error));
        } else {
            respMsgs.add(new ResponseMsg(type:ERROR_SHORTTEXT, message: body.message));
            
            for (error in body.details) {
                respMsgs.add(new ResponseMsg(type:ERROR_SHORTTEXT, message: error.message));
            }
        }
    } catch (Exception ex) {
        respMsgs.add(new ResponseMsg(type:ERROR_SHORTTEXT, message: body));
    }


    //Add CPI MsgID to messages
    String sapMessageProcessingLogId = message.getProperty('SAP_MessageProcessingLogID') ?: ''
    respMsgs.add(new ResponseMsg(type:INFO_SHORTTEXT, message:CPI_MSGID_TEXT + sapMessageProcessingLogId));

    /* build response */
    response.messages = respMsgs;
    
    
    message.setHeader("CamelHttpResponseCode", "400");    
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(response)));

    return message;
}
