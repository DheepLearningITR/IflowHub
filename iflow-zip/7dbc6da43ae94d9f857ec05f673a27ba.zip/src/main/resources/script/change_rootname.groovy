import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;


def Message processData(Message message) {

	def body = message.getBody(String.class);

	def root_name = 'LOIROU04';
	def new_name = 'Z_LOIROU04';

	body = body.replaceAll("<$root_name>", "<$new_name>");
	body = body.replaceAll("<$root_name ", "<$new_name ");
	body = body.replaceAll("</$root_name>", "</$new_name>");

	message.setBody(body)

	return message;
}
