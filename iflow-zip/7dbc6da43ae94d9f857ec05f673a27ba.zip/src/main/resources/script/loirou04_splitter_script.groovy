import com.sap.gateway.ip.core.customdev.util.Message
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;
import groovy.xml.XmlUtil

def Message removeE1MAPAL(Message message) {
    def request = message.getProperty("originRequest"); 
    def requestNodes =  new XmlSlurper(false,false).parseText(request);
    requestNodes.depthFirst().findAll{ it.name() == 'E1MAPAL' }*.replaceNode {};
    message.setProperty("originRequest", XmlUtil.serialize(requestNodes));
    return message;
}

def Message mergePayload(Message message) {
    def splitBody = new XmlSlurper(false,false).parse(message.getBody()); 
    def request = new XmlSlurper(false,false).parseText(message.getProperty("originRequest")); 
    request.'**'.find{ it.name() == 'E1MAPLL' }.appendNode (splitBody);
    message.setBody(XmlUtil.serialize(request));
    return message;
}