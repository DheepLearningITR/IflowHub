import com.sap.gateway.ip.core.customdev.util.Message
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;
import groovy.xml.XmlUtil

def Message removeE1MARAM(Message message) {
    def request = message.getProperty("originRequest"); 
    def requestNodes =  new XmlSlurper(false,false).parseText(request);
    removeNode(requestNodes, "E1MARAM");
    message.setProperty("originRequest", XmlUtil.serialize(requestNodes));
    return message;
}

def Message removeE1MARCM(Message message) {
    def request = message.getProperty("originRequest"); 
    def requestNodes =  new XmlSlurper(false,false).parseText(request);
    removeNode(requestNodes, "E1MARCM");
    message.setProperty("originRequest", XmlUtil.serialize(requestNodes));
    return message;
}

def Message mergePayloadForE1MARAM(Message message) {
    def splitBody = new XmlSlurper(false,false).parse(message.getBody()); 
    def request = new XmlSlurper(false,false).parseText(message.getProperty("originRequest")); 
    mergeNode(request, "IDOC", splitBody);
    message.setBody(XmlUtil.serialize(request));
    return message;
}

def Message mergePayloadForE1MARCM(Message message) {
    def splitBody = new XmlSlurper(false,false).parse(message.getBody()); 
    def request = new XmlSlurper(false,false).parseText(message.getProperty("originRequest")); 
    mergeNode(request, "E1MARAM", splitBody);
    message.setBody(XmlUtil.serialize(request));
    return message;
}

def removeNode(groovy.util.slurpersupport.NodeChild node, String nodeName){
    node.depthFirst().findAll{ it.name() == nodeName }*.replaceNode {};
}

def mergeNode(groovy.util.slurpersupport.NodeChild request, String nodeName, groovy.util.slurpersupport.NodeChild splitBody){
    request.'**'.find{ it.name() == nodeName }.appendNode (splitBody);
}