import com.sap.it.api.mapping.*;

def String getIsNet(String property, MappingContext context){
    
    String isNet= context.getProperty("isNet");
    
    if(isNet.equals('true')){
         return  'true';
    }  else {
        return 'false';
    }
}