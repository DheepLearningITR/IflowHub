import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    def ReadPayload = message.getProperty("FSMHttpResponseBody")

    def jsonSlurper = new JsonSlurper()
    def FSMResponse = jsonSlurper.parseText(ReadPayload)

    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)

    xml.root {
        externalId(FSMResponse.externalId)

        FSMResponse.activities.each { activity ->
            activities {
                externalId(activity.externalId)
            }
        }
    }

    message.setBody(writer.toString())

    return message
}
