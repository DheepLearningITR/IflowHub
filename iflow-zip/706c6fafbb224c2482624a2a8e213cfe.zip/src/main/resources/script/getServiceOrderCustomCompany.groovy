import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.util.XmlParser
import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script gets Service Order Object details for custom company determination */
    
    def body = message.getBody(java.io.Reader)
    def parsedXml = new XmlSlurper().parse(body)
    def customObjects = new XmlParser().parseText("<CustomObjects></CustomObjects>")

    parsedXml.ServiceOrderNotification.each { srvMessage ->
        //get the Service order details where Custom rule type is set at the object level
        srvMessage.ServiceOrder.each {srcSO ->
            if (srvMessage.@MultiCompanyGroup.text() in ['CUSTOM', 'ATTRIBUTE']) {
                    def customObjectXml = buildCustomObjectXml(srcSO)
                    def customObjectNode = new XmlParser().parseText(customObjectXml)
                    customObjects.append(customObjectNode)
            }        
        }
    }

    message.setBody(XmlUtil.serialize(customObjects))
    return message
}

def String buildCustomObjectXml(srv) {
    def builder = new StringBuilder()
    builder.append("<customObject>")
    builder.append("<SrvcMgmtFSMRplctnObjID>").append(srv.ServiceOrder.text()).append("</SrvcMgmtFSMRplctnObjID>")
    builder.append("<SrvcMgmtFSMReplicationObject>SO</SrvcMgmtFSMReplicationObject>")
    builder.append("<SrvcMgmtFSMRplctnObjAttribute></SrvcMgmtFSMRplctnObjAttribute><SrvcMgmtFSMRplctnObjAttribVal></SrvcMgmtFSMRplctnObjAttribVal>")

    builder.append("</customObject>")
    return builder.toString()
}
