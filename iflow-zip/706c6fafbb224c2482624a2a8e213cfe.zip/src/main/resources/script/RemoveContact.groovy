import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput


def Message processData(Message message) { 
    def body = message.getBody(java.io.Reader)
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parse(body)
    def bItemContactPersonPresent = (message.getProperty("ItemContactPersonPresent") == 'true')

    // remove contact tag
    object.root.activities.each{
        if (!it.contact || it.contact?.isEmpty() || it.contact?.externalId?.isEmpty() || it.contact?.externalId == null ){
           if (bItemContactPersonPresent) {          
              it.contact = null             
           } else {
              it.remove("contact")
           }
        } 
    }

    message.setBody(JsonOutput.toJson(object.root))
    message.setProperty("RequestPayload", JsonOutput.toJson(object.root))
    return message
}
