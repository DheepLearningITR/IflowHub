import com.sap.it.api.mapping.*

def String BuildCancelItemExternalId(String itemNo, MappingContext context) {
    String ServiceOrderID = context.getHeader("ServiceOrderID")
    def result = ServiceOrderID + "/" + itemNo
    return result
}