def String GetDurationMinutes(String Quantity, String QuantityUnit){
    def result
    if ( (QuantityUnit == "HR" || QuantityUnit == "HUR" || QuantityUnit == "H") && Quantity.isFloat() ) {
        result = Math.round(Quantity.toFloat() * 60)
    } else if ( QuantityUnit == "MIN" && Quantity.isFloat() ) {
        result = Math.round(Quantity.toFloat())
    }
	return result
}