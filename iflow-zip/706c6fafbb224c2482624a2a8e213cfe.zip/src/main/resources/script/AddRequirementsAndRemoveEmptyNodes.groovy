import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser
import groovy.xml.XmlUtil
import java.time.format.DateTimeFormatter
import java.time.LocalDate

// remove empty nodes from the XML message 
def Message processData(Message message) {
    def body = message.getBody(String.class)
    def xmlBody = new XmlParser().parseText(body)

    xmlBody.depthFirst().each {
        // remove empty activities nodes
        if (it.name() == 'activities' && !it.text()) {
            it.replaceNode{}            
        }
        // remove empty reservedMaterials nodes
        if (it.name() == 'reservedMaterials' && !it.text()) {
            it.replaceNode{}            
        }
        // remove empty equipments nodes
        if (it.name() == 'equipments' && !it.externalId.text()) {
            it.replaceNode{}            
        }
    }
    
    
    if(message.getProperty('EnableQualRepl') =~ /(?i)(true|x)/){
    
        //Read OData response from S4 which contains Qualifications filled in S4
        def query_body = message.getProperty('S4ODataResponse')
        def query_root = new XmlParser().parseText(query_body)
        def formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS")
        def startDate, endDate, activeDate
        def currentDate = LocalDate.now()
        
        //Assign active qualifications as requirements at service call level
        def QualificationFlag = false
        query_root.A_ServiceOrderType?.to_Qualification?.A_SrvcOrdQualificationType.each{ Qualification->
            if(Qualification?.SrvcDocQualifnValdtyStrtDteTme.text()!=''&&Qualification?.SrvcDocQualifnValdtyEndDteTme.text()!=''){
                startDate = LocalDate.parse(Qualification?.SrvcDocQualifnValdtyStrtDteTme.text(), formatter)
                endDate = LocalDate.parse(Qualification?.SrvcDocQualifnValdtyEndDteTme.text(), formatter)
                activeDate = (currentDate.isAfter(startDate)||currentDate == startDate) && (currentDate.isBefore(endDate) || currentDate == endDate)
            }else if(Qualification?.SrvcDocQualifnValdtyStrtDteTme.text() ==''&&Qualification?.SrvcDocQualifnValdtyEndDteTme.text()==''){
               activeDate = true 
            }else{
               activeDate = false 
            }
            
            if(Qualification?.SrvcDocQualification&&Qualification?.SrvcDocQualification.text()!=''&&activeDate){
                def requirementsNode = new Node(xmlBody, 'requirements')
                def skillNode = new Node(requirementsNode, 'skill')
                new Node(requirementsNode, 'mandatory', Qualification?.SrvcDocQualifnIsMandatory.text())
                new Node(skillNode,'externalId',Qualification?.SrvcDocQualification.text())
                QualificationFlag = true
            }
        }
        if(QualificationFlag == false){
            new Node(xmlBody, 'requirements')
        }
        
        //Assign active qualifications at line item level to respective 
        query_root.A_ServiceOrderType?.to_Item?.A_ServiceOrderItemType.each{ Item->
            QualificationFlag = false
            Item.to_Qualification?.A_SrvcOrdItemQualificationType.each{ Item_Qualification->
                if(Item_Qualification?.SrvcDocQualifnValdtyStrtDteTme.text()!=''&&Item_Qualification?.SrvcDocQualifnValdtyEndDteTme.text()!=''){
                    startDate = LocalDate.parse(Item_Qualification?.SrvcDocQualifnValdtyStrtDteTme.text(), formatter)
                    endDate = LocalDate.parse(Item_Qualification?.SrvcDocQualifnValdtyEndDteTme.text(), formatter)
                    activeDate = (currentDate.isAfter(startDate)||currentDate == startDate) && (currentDate.isBefore(endDate) || currentDate == endDate)
                }else if(Item_Qualification?.SrvcDocQualifnValdtyStrtDteTme.text()==''&&Item_Qualification?.SrvcDocQualifnValdtyEndDteTme.text()==''){
                    activeDate = true
                }else{
                    activeDate = false
                }
            
                if(Item_Qualification?.SrvcDocQualification&&Item_Qualification?.SrvcDocQualification.text()!=''&&activeDate){
                    def targetNode = xmlBody.activities.find { it.temp_ItemId.text() == Item_Qualification?.ServiceDocumentItem.text() }
                    def requirementsNode = new Node(targetNode, 'requirements')
                    def skillNode = new Node(requirementsNode, 'skill')
                    new Node(requirementsNode, 'mandatory', Item_Qualification?.SrvcDocQualifnIsMandatory.text())
                    new Node(skillNode,'externalId',Item_Qualification?.SrvcDocQualification.text())
                    QualificationFlag = true
                }
            }
            
            if(QualificationFlag == false){
                def targetNode = xmlBody.activities.find { it.temp_ItemId.text() == Item.ServiceOrderItem.text() }
                new Node(targetNode, 'requirements')
            }
        }
    }
    
    message.setBody(XmlUtil.serialize(xmlBody))
    return message
}
