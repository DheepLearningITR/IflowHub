import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil

def Message processData(Message message) {
    
    def ReadPayload = message.getBody(java.io.Reader)
    def OrgBody = new XmlSlurper().parse(ReadPayload)
    def ServiceOrderPayload = message.getProperty('ServiceOrderPayload')
    def orgLevelIds = []

    if (OrgBody) {
        OrgBody.SrvcMgmtFSMOrgUnitMapping_Type.each { orgUnit ->
            def externalIdValue = orgUnit.SrvcMgmtOrgUnitID.text().replace("O ", "")
            orgLevelIds.add(externalIdValue)
        }
    }

    def serviceOrderXml = new XmlParser().parseText(ServiceOrderPayload)
    def orderDetailsNode = serviceOrderXml.OrderDetails?.getAt(0)  // Safe navigation operator to handle null

    if (orgLevelIds.size() > 0) {
        orgLevelIds.each { externalIdValue ->
            def orgLevelIdsNode = orderDetailsNode ? orderDetailsNode.appendNode('orgLevelIds') : serviceOrderXml.appendNode('orgLevelIds')
            orgLevelIdsNode.appendNode('externalId', externalIdValue)
            //add orglevels to activities
            serviceOrderXml.activities.each { act ->
                def actorglevelNode = act.appendNode('orgLevelIds')
                actorglevelNode.appendNode('externalId', externalIdValue)
            }
        }
    } else {
        // Handle the empty orgLevelIds case
        if (orderDetailsNode != null) {
            orderDetailsNode.appendNode('orgLevelIds', '')
            
        } else {
            serviceOrderXml.appendNode('orgLevelIds', '')
            serviceOrderXml.activities.each { act ->
                act.appendNode('orgLevelIds', '')
            }
        }
    }

    def updatedServiceOrderPayload = XmlUtil.serialize(serviceOrderXml)
    message.setBody(updatedServiceOrderPayload)
    return message
}
