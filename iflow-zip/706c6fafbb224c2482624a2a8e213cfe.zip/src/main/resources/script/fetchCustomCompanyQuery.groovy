import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script gets frame the query to fetch custom company */
    
    def body = message.getBody(java.io.Reader)
    def parsedXml = new XmlSlurper().parse(body)
    // Initialize maps to group conditions
    def idGroups = [:].withDefault { [] }
    
    // Group IDs by SrvcMgmtFSMRplctnObjAttribVal
    parsedXml.customObject.each { obj ->
        def objType = obj.SrvcMgmtFSMReplicationObject.text()
            if (objType == 'SO') {
                        def objId = obj.SrvcMgmtFSMRplctnObjID.text()
                        def objAttrVal = obj.SrvcMgmtFSMRplctnObjAttribVal.text()
                        
                        if (objAttrVal) {
                            idGroups[objAttrVal] << objId
                        } else {
                            idGroups['default'] << objId
                        }
                    }
                }

    // Build query parts
    def queryParts = []

    // Add grouped conditions to query parts
    idGroups.each { attrVal, ids ->
        if (attrVal == 'default') {
            queryParts << ids.collect { "SrvcMgmtFSMRplctnObjID eq '${it}'" }.join(' or ')
        } else {
            def idConditions = ids.collect { "SrvcMgmtFSMRplctnObjID eq '${it}'" }.join(' or ')
            queryParts << "(SrvcMgmtFSMRplctnObjAttribVal eq '${attrVal}' and (${idConditions}))"
        }
    }

    // Combine the queries
    def finalQuery = "(SrvcMgmtFSMReplicationObject eq 'SO' and (${queryParts.join(' or ')}))"

    message.setProperty("customCompanyquery",finalQuery);
    return message
}
