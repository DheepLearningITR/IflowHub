import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message){
    def body = message.getBody(java.io.Reader);
    def query = new XmlSlurper().parse(body);
    def FSMAccountCompany = query.@MultiCompanyGroup.text();
    
    if (FSMAccountCompany != null || FSMAccountCompany != ''){
        message.setProperty("X-Account-ID",FSMAccountCompany.split("\\|")[0]);
        message.setProperty("X-Company-ID",FSMAccountCompany.split("\\|")[1]);
    }
    
  def xml_data = XmlUtil.serialize(query);
  message.setBody(xml_data);
  
  return message;
}