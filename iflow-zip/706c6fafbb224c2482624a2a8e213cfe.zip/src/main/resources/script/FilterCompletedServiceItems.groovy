import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlParser;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def sourcePayload   = message.getProperty('SourcePayload')
    def rootSource      = new XmlParser().parseText(sourcePayload)
    def itemId = []
    def cancelledItemId = []
    def ActivitiesCategories = message.getProperty('ItemCategoriesForFSMActivities')
    def allowedCategories = ''
    def emptyServiceOrder = 'X'

    if (ActivitiesCategories != null && ActivitiesCategories !='') {
        allowedCategories = ActivitiesCategories.split("\\|")*.trim()
    }

    if (message.getProperty("ServiceOrderContainsCompletedItem") == "true") {
// find all ServiceOrderItemIds in the FSMServiceCallPayload. These are available below "activities" in field "externalId" as the second part after "/" 
        def fsmServiceCall  = message.getBody(java.io.Reader)
        def fsm             = new JsonSlurper().parse(fsmServiceCall)
        fsm?.activities.each{ node ->
            if(node?.externalId != null){
                def extId = node?.externalId?.split("/")[-1]
                itemId.add(extId)                
                if(node?.executionStage == "CANCELLED")
                    cancelledItemId.add(extId)
            }
        }
    }
    
    if (message.getProperty("ServiceOrderItemIsReleasedPresent") == "true") {
        // If a service order item <> "Released" is not replicated yet to FSM, it shall be ignored, i.e. removed from the payload.
        rootSource.ServiceOrder.Item.each{ sourceItem-> 
            // check if the service order item <> "Released"
            if ( !(sourceItem.ServiceOrderItemIsReleased.text() ==~ /(?i)(true|x)/) ) {
                // Check if the itemId is available in the list extracted from the FSMServiceCallPayload
                    if (!(sourceItem.ServiceOrderItem.text() in itemId)){
                        sourceItem.replaceNode {}
                        return false
                    }
            }
            
            // Check if the SO contains an item of an allowed category
            if (allowedCategories.contains(sourceItem.ServiceOrderItemCategory.text())) {
                emptyServiceOrder = ''
            }

            // Check for the rejection items already cancelled in FSM
            sourceItem.appendNode('FSMActivityCancelledStatus', 'false')
            if (sourceItem.ServiceOrderItemIsRejected.text() ==~ /(?i)(true|x)/ && sourceItem.ServiceOrderItem.text() in cancelledItemId){
                sourceItem.FSMActivityCancelledStatus[0].value = 'true'
            }	
        }
        
    //Backwards Compatibility
    } else {
        rootSource.ServiceOrder.Item.each{ sourceItem->    
            // If a service item <> "Released" is not replicated yet to FSM, it shall be ignored, i.e. removed from the payload.
            if (!(sourceItem.ServiceOrderItemIsReleased.text() ==~ /(?i)(true|x)/ )){                        
                // Check if the itemId is available in the list extracted from the FSMServiceCallPayload
                    if (!(sourceItem.ServiceOrderItem.text() in itemId)){
                        sourceItem.replaceNode {}
                        return false
                    }
            }
            // Check if the SO contains an item of an allowed category
            if (allowedCategories.contains(sourceItem.ServiceOrderItemCategory.text())) {
                emptyServiceOrder = ''
            }	

            // Check for the rejection items already cancelled in FSM
            sourceItem.appendNode('FSMActivityCancelledStatus', 'false')
            if (sourceItem.ServiceOrderItemIsRejected.text() ==~ /(?i)(true|x)/ && sourceItem.ServiceOrderItem.text() in cancelledItemId){
                sourceItem.FSMActivityCancelledStatus[0].value = 'true'
            }	
        }
    }

    message.setProperty('EmptyServiceOrder', emptyServiceOrder)

    String outxml = groovy.xml.XmlUtil.serialize( rootSource )
    message.setBody(outxml)
    return message
}