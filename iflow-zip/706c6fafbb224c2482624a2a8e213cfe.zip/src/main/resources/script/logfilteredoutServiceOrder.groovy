import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    /* This script is to log the service orders that are filtered out with no FSM company. */
	
    def body = message.getBody(java.io.Reader)
    def query = new XmlSlurper().parse(body)
    def messageLog = messageLogFactory.getMessageLog(message)
	
    query.ServiceOrderNotification.ServiceOrder.each { srvMessage ->        
        def internalID = srvMessage.ServiceOrder.text()
        if (messageLog != null) {
            messageLog.addCustomHeaderProperty("FSMCompanyNotFoundForServiceOrder", internalID)
        }
    }
    return message
}
