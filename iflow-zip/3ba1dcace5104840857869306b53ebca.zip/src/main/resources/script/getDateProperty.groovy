import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;

def String getDateProperty(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty(propertyName);
    return propertyValue;
}