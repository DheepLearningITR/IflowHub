import com.sap.it.api.mapping.*;

def String checkIfBlank(String costCenter, String profitCenter, String WBS, String order){
    

    if(order.isEmpty() && order.isEmpty() && profitCenter.isEmpty() && WBS.isEmpty() ){
        	return "false";
    }
    return "true";
 
}
