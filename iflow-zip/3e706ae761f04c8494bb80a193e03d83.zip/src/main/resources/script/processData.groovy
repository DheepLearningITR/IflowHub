import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap; 
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import groovy.json.*;

def Message processData(Message message)
{
    def messageBody = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def jsonObject = jsonSlurper.parseText(messageBody);
    
    def properties = message.getProperties();
	def service = ITApiFactory.getApi(SecureStoreService.class, null);
	def token_id = properties.get("token");
	def secret_id = properties.get("secret");
	def on24Url = properties.get("on24Url");
	def apiToken = service.getUserCredential(token_id);
	def apiSecret = service.getUserCredential(secret_id);
	def messageLog = messageLogFactory.getMessageLog(message);
	def headers = message.getHeaders();
	// Retrieve all the incoming headers to construct the HTTPS url to ON24
	def clientid = headers.get("provideraccountid").toString();
	def eventid = headers.get("externaleventid").toString();
	def lastruntime = headers.get("lastrundatetime").toString();

	if (apiToken == null) {
		throw new IllegalStateException("No credential found for alias "+ token_id);
	}
	if (apiSecret == null) {
		throw new IllegalStateException("No credential found for alias "+ secret_id);
	}
	// Set message headers used as incoming headers in the HTTP call
    message.setHeader("accessTokenKey",new String(apiToken.getPassword()));
	message.setHeader("accessTokenSecret",new String(apiSecret.getPassword()));
	message.setHeader("commMedium",jsonObject.commMedium);
	message.setProperty("on24Registrantsurl", on24Url +"/client/"+clientid+"/event/"+eventid+"/registrant");
	return message;

}