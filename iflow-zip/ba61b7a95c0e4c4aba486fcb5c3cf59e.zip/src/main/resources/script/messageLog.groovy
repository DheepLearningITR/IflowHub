import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processDataCreateRCBP(Message message) {
	def map = message.getProperties();
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	def property_S4ID = map.get("S4BPNumber");

	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String) as String;
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString("S4(" + property_S4ID + ")" + "_create_req", body, "text/json");
		}
	}
	return message;
}

def Message processDataUpdateRCBP(Message message) {
	def map = message.getProperties();
	def headermap = message.getHeaders();
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	def property_S4ID = map.get("S4BPNumber");
	def property_RCID = map.get("SBCustomerNumber");

	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String) as String;
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString("S4(" + property_S4ID + ")" + "_SB(" + property_RCID + ")" + "_update_req", body, "text/json");
		}
	}
	return message;
}


def Message processDataS4ConfirmIn(Message message) {
	def map = message.getProperties();
	def property_S4ID = map.get("S4BPNumber");
	def property_RCID = map.get("SBCustomerNumber");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String) as String;
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString("S4(" + property_S4ID + ")_SB(" + property_RCID + ")_confirm_msg", body, "text/xml");
		}
	}
	return message;
}
