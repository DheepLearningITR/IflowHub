import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

Message processData(Message message) {
    String deliveryDocResult = 'deliveryDocumentItemResult'
    String errorMessage = 'errorMessage'
    String statusCode = 'statusCode'
    String camelHttpResponseCode = 'CamelHttpResponseCode'
    def body = message.getBody(String) as String
    def jsonSlurper = new JsonSlurper()
    try {
        def result = jsonSlurper.parseText(body)
        def deliveryItemList = []
       
        if (result.A_ReturnsDeliveryHeader.A_ReturnsDeliveryHeaderType.to_DeliveryDocumentItem.A_ReturnsDeliveryItemType instanceof ArrayList) {
            deliveryItemList = result.A_ReturnsDeliveryHeader.A_ReturnsDeliveryHeaderType.to_DeliveryDocumentItem.A_ReturnsDeliveryItemType
        }
        else
        {
            deliveryItemList.add(result.A_ReturnsDeliveryHeader.A_ReturnsDeliveryHeaderType.to_DeliveryDocumentItem.A_ReturnsDeliveryItemType)
        }
        def deliveryItemListJson  = new JsonBuilder(deliveryItemList)
        message.setProperty(deliveryDocResult , deliveryItemListJson)
        message.setProperty(errorMessage , '')
        message.setProperty(statusCode, message.headers.get(camelHttpResponseCode).toString())
    }
    catch (Exception e)
    {
        message.setProperty(deliveryDocResult , [])
        message.setProperty(errorMessage , '')
        message.setProperty(statusCode, message.headers.get(camelHttpResponseCode).toString())
    }
    return message
}
