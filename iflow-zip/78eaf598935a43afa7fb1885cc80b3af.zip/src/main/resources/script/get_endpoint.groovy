import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {
    String body = message.getBody(String) as String
    jsonSlurper = new JsonSlurper()
    String object = jsonSlurper.parseText(body.toString())
    message.setProperty('EndpointURL', object.destinationConfiguration.URL)
    message.setProperty('CloudConnectorLocationId', object.destinationConfiguration.CloudConnectorLocationId)
    message.setProperty('client', 'sap-client=' + object.destinationConfiguration['sap-client'])
    return message
}
