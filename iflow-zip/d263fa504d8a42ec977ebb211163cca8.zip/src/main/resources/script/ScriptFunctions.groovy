/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

def Message setProperties(Message message) {
     def format = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
     def timeZone = "CET";
     Date date = new Date();
     SimpleDateFormat formatter = new SimpleDateFormat(format);
     formatter.setTimeZone(TimeZone.getTimeZone(timeZone));
     message.setProperty("Timestamp",formatter.format(date));
     def map = message.getProperties();
     def document = map.get("Document");
     if(document == 'DocumentStatus'){
        def statusid = map.get("StatusID"); 
        def IssueDate = map.get("IssueDate");
        def IssueTime = map.get("IssueTime");
        def MessageName;
        if (IssueTime){
            def IssueDateTime = IssueDate.toString() + 'T' + IssueTime.substring(0,8) + 'Z';
            message.setProperty( "IssueDateTime", IssueDateTime );
            MessageName = statusid + "_" + IssueDateTime;
       }
       else {
            MessageName = statusid + "_" + formatter.format(date); 
       }
        message.setProperty("MessageScenario", 'STATUS');
        message.setProperty("MessageID", statusid);
        message.setProperty("MessageName", MessageName );
     }
     else {
        if(document == 'Invoice')
         message.setProperty("MessageScenario", 'INVOICE');
     }
     return message;
    
}