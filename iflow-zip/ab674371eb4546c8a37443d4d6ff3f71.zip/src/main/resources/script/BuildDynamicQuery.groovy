import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

	//Properties  
	def pmap = message.getHeaders();
    def messageLog = messageLogFactory.getMessageLog(message);

   
    String personIdExternal = pmap.get("personIdExternal");
    String firstname = pmap.get("firstname");
    String lastname = pmap.get("lastname");

	String Operator = "";
	String query = "";

	
// add filter parameter for PERSON_ID_EXTERNAL
	if(personIdExternal != null && personIdExternal != "") {	
	    query = query + " personIdExternal eq ('" + personIdExternal +"')";
		message.setProperty("FILTER_PARAMETERS", query);
		Operator = 'TRUE'
	}
	
// add filter parameter for firstname
	if(firstname != null && firstname != "") 
	{ 
	    if(Operator == 'TRUE')
	    {
	        query = query + " and startswith(firstName, '" + firstname +"')";
    	} 
	    else 
    	{
	         query = query + " startswith(firstName, '" + firstname +"')";
	         Operator = 'TRUE'
    	}
    }


// add filter parameter for lastName
	if(lastname != null && lastname != "") 
	{ 
	    if(Operator == 'TRUE')
	    {
	        query = query + " and startswith(lastName, '" + lastname +"')";
    	} 
	    else 
    	{
	         query = query + " startswith(lastName, '" + lastname +"')";
	         Operator = 'TRUE'
    	}
    }    
    

		//Set FILTER_PARAMETERS
	message.setProperty("FILTER_PARAMETERS", query);
	if(messageLog != null){
		messageLog.setStringProperty("FILTER_PARAMETERS: ", query);
	}
	
	return message;
}

