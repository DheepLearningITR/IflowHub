import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def ex = message.getProperty("CamelExceptionCaught");
    if (ex!=null) {
        if (ex.getClass().getCanonicalName().equals('org.apache.cxf.binding.soap.SoapFault')) {
            message.setProperty('message', ex.getMessage());
        }
    }
    return message;
}