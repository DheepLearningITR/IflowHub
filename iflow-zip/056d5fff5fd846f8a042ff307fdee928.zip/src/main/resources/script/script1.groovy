/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import java.text.SimpleDateFormat; 
import java.util.Date;

def Message processIncomingPayload(Message message) {

    def body = message.getBody(String.class);
    JsonSlurper slurper = new JsonSlurper();
    Map parsedJson = slurper.parseText(body);
    def input;

    switch (parsedJson.scopes) {
        case "'urn:tr:onesource:auth:api:datahub'":
            input = "OK";
        default:
            input = "KO";
            break;
    }

    message.setProperty("scope_ok", input);

    if (input == "OK") {
        message.setProperty("client_id", parsedJson.client_id);
        message.setProperty("client_secret", parsedJson.client_secret);
    }

    return message;
}


def Message token_payload(Message message) {

    message.setProperty("OTPCallType", "POST");
    def jsonContext = new groovy.json.JsonSlurper().parseText('{"client_id": {}, "scopes" : {}, "grant_type" : {}, "client_secret" : {}}');

    jsonContext.client_secret = message.properties.client_secret;
    jsonContext.client_id = message.properties.client_id;
    jsonContext.scopes = "'urn:tr:onesource:auth:api:datahub'";
    jsonContext.grant_type = "client_credentials";

    def payload = new groovy.json.JsonBuilder();

    def root = payload {
        context jsonContext
    }
    message.setBody(payload.toString());
    message.setHeader("Content-Type", "application/json");
    return message;
}


def Message retrieve_token(Message message) {

    if (ex != null) {

        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {

            // save the http error response as a message attachment 
            def messageLog = messageLogFactory.getMessageLog(message);
            messageLog.addAttachmentAsString("http.ResponseBody", ex.getResponseBody(), "text/plain");

            // copy the http error response to an exchange property
            message.setProperty("http.ResponseBody", ex.getResponseBody());

            // copy the http error response to the message body
            message.setBody(ex.getResponseBody());

            // copy the value of http error code (i.e. 500) to a property
            message.setProperty("http.StatusCode", ex.getStatusCode());

            // copy the value of http error text (i.e. "Internal Server Error") to a property
            message.setProperty("http.StatusText", ex.getStatusText());

        }
    } else {

        def body = message.getBody(String.class);
        def trialbalance;
        JsonSlurper slurper = new JsonSlurper();
        Map parsedJson = slurper.parseText(body);

        if (parsedJson.success -= 'approved') {

            message.setProperty("OTPCallType", "POST");
            message.setProperty("token", parsedJson.token);
            
            def jsonContext = new groovy.json.JsonSlurper().parseText('{"name": {}, "delimiter" : {}, "year" : {}, "period" : {}}');

            Date now = new Date();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(now);

            def yearNow = calendar.get(Calendar.YEAR).toString();
            def monthNow = calendar.get(Calendar.MONTH).toString();

            jsonContext.name = 'Filename' + new SimpleDateFormat("MM/dd/yyyy HH:mm:ss") + '.csv';
            jsonContext.delimiter = ',';
            jsonContext.year = yearNow;
            jsonContext.period = monthNow;

            def payload = new groovy.json.JsonBuilder();

            def root = payload {
                context jsonContext
            }
            message.setBody(payload.toString());
            message.setHeader("Content-Type", "application/json");
            message.setHeader("Authorization", 'Bearer ' + parsedJson.token);
            return message;
        }
    }

}


def Message get_file_id(Message message) {

    if (ex != null) {

        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {

            // save the http error response as a message attachment 
            def messageLog = messageLogFactory.getMessageLog(message);
            messageLog.addAttachmentAsString("http.ResponseBody", ex.getResponseBody(), "text/plain");

            // copy the http error response to an exchange property
            message.setProperty("http.ResponseBody", ex.getResponseBody());

            // copy the http error response to the message body
            message.setBody(ex.getResponseBody());

            // copy the value of http error code (i.e. 500) to a property
            message.setProperty("http.StatusCode", ex.getStatusCode());

            // copy the value of http error text (i.e. "Internal Server Error") to a property
            message.setProperty("http.StatusText", ex.getStatusText());

        }
    } else {

        def body = message.getBody(String.class);
        def trialbalance;
        JsonSlurper slurper = new JsonSlurper();
        Map parsedJson = slurper.parseText(body);

        if (parsedJson.id != null) {

            message.setProperty("OTPCallType", "POST");
            message.setProperty("file_id", parsedJson.id);
            
            def jsonContext = new groovy.json.JsonSlurper().parseText('{"file": {}}');

            //jsonContext.file = message.properties.file_id;

            def payload = new groovy.json.JsonBuilder();

            def root = payload {
                context jsonContext
            }
            message.setBody(payload.toString());
            message.setHeader("Content-Type", "multipart/form-data");
            message.setHeader("Authorization", 'Bearer ' + message.properties.token);
            return message;
        }
    }

}