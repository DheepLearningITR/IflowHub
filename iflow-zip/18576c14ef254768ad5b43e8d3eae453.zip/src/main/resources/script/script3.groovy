import com.sap.gateway.ip.core.customdev.util.Message

def processData(Message message) {
    // Reading the Migration Cockpit Template
    def xml = message.getBody(java.lang.String)
    def document = groovy.xml.DOMBuilder.parse(new StringReader(xml))
    def workbook = document.documentElement
    def worksheet = workbook.getElementsByTagName("Worksheet")
    
    // Reading the Simple XML out of mapping
    def map = message.getProperties()
    def value = map.get("S4MapOutput")
    def doc2 = new XmlSlurper().parse(new StringReader(value))

    // Use a hash map to store worksheet data
    def worksheetData = [:]

    // Reading the worksheet names from the S4MapOutput and storing data in the map
    doc2.'*'*.name().each { worksheetName ->
        worksheetData[worksheetName] = doc2[worksheetName]
    }
    
    worksheet.each { sheet ->
        def sheetName = sheet.getAttribute("ss:Name").toString().replaceAll("[^a-zA-Z0-9]", "")
        def dataEntries = worksheetData[sheetName]
        if (dataEntries) {
            def table = sheet.getElementsByTagName("Table").item(0)
            def row = table.getElementsByTagName("Row").item(4)
            def child = row.childNodes
            def len = child.length
            def taglist = []
            def count = 0
            def rowcount = 0
            
            def dataRow = table.getElementsByTagName("Row").item(7)
            def dateList = []
            
            for (int i = 0; i < len - 1; i += 2) {
                
                def cell = row.getElementsByTagName("Cell").item(count)
                def dataNode = cell.getElementsByTagName("Data").item(0)
                def data = dataNode.getTextContent()

                taglist.add(data.toString())
                
                def cellNode = dataRow.getElementsByTagName("Cell").item(count)
                def dataNode1 = cellNode.getElementsByTagName("Data").item(0)
                def dataDate = dataNode1.getTextContent()

                if (dataDate.contains("Type: Date")) {
                    dateList.add(count)
                }
                
                count += 1
            }
            
            // Create parameter map
            def rowParameters = [
                taglist: taglist,
                count: count,
                dateList: dateList
            ]
            
            dataEntries.each { entry ->
                def newRow = document.createElement("Row")
                newRow.setAttribute("ss:AutoFitHeight", "0")
                processRowEntry(newRow, entry, document, rowParameters)
                table.appendChild(newRow)
                rowcount += 1
            }
            table.getAttributeNode("ss:ExpandedRowCount").nodeValue = "${rowcount + 10}"
        }    
    }
    def result = groovy.xml.XmlUtil.serialize(workbook)
    message.setBody(result)
    
    return message
}

def void processRowEntry(newRow, entry, document, params) {
    def taglist = params.taglist
    def count = params.count
    def dateList = params.dateList
    
    def index = 1
    for (int j = 0; j < count; j++) {
        def dataValue = entry[taglist[j]].toString()
        if (dataValue.length() > 0) {
            if (j + 1 == index) {
                def cell = document.createElement("Cell")
                def data = document.createElement("Data")
                if (dateList.contains(j)) {
                    data.setAttribute("ss:Type", "DateTime")
                } else {
                    data.setAttribute("ss:Type", "String")
                }
                data.setTextContent(dataValue)
                
                cell.appendChild(data)
                newRow.appendChild(cell)
                index += 1
            } else {
                index = j + 1
                def cell = document.createElement("Cell")
                cell.setAttribute("ss:Index", "${index}")
                def data = document.createElement("Data")
                if (dateList.contains(j)) {
                    data.setAttribute("ss:Type", "DateTime")
                } else {
                    data.setAttribute("ss:Type", "String")
                }
                data.setTextContent(dataValue)
                
                cell.appendChild(data)
                newRow.appendChild(cell)
            }
        }
    }
}
