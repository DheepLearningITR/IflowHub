import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    Reader body = message.getBody(Reader)
    def writer = new StringWriter()
    def xmlOutput = new MarkupBuilder(writer)
    Map<String, Object> headers = message.getHeaders()
    String obj = headers.get("Objname")

    def root = new XmlSlurper().parse(body)
    def worksheets = root.Worksheet.findAll { sheet ->
        String sheetName = sheet.@Name.toString().replaceAll("[^a-zA-Z0-9]+", "")
        !(sheetName in ["Introduction", "FieldList", "Documentation"])
    }

    xmlOutput."$obj" {
        worksheets.each { worksheet ->
            processWorksheet(xmlOutput, worksheet)
        }
    }

    message.setBody(writer.toString())
    return message
}

def void processWorksheet(MarkupBuilder xmlOutput, def worksheet) {
    String sheetName = worksheet.@Name.toString().replaceAll("[^a-zA-Z0-9]+", "")
    def table = worksheet.Table[0]
    def headerRow = table.Row[4]
    def dataRows = table.Row.drop(7)

    def columnNames = headerRow.Cell.Data.collect { it.toString() }
    int columnCount = columnNames.size()

    dataRows.each { dataRow ->
        xmlOutput."$sheetName" {
            processDataRow(xmlOutput, dataRow, columnNames, columnCount)
        }
    }
}

def void processDataRow(MarkupBuilder xmlOutput, def dataRow, List<String> columnNames, int columnCount) {
    int dataRowSize = dataRow.Cell.size()
    int colCount = 0

    for (int i = 0; i < dataRowSize; i++) {
        if (dataRow.Cell[i].@Index in [""]) {
            xmlOutput."${columnNames[colCount]}"(dataRow.Cell[i].Data.toString())
            colCount++
        } else {
            int index = dataRow.Cell[i].@Index.toInteger()
            for (int j = colCount; j < index - 1; j++) {
                xmlOutput."${columnNames[colCount]}"("")
                colCount++
            }
            xmlOutput."${columnNames[colCount]}"(dataRow.Cell[i].Data.toString())
            colCount++
        }
    }
    for (int i = colCount; i < columnCount; i++) {
        xmlOutput."${columnNames[i]}"("")
    }
}

