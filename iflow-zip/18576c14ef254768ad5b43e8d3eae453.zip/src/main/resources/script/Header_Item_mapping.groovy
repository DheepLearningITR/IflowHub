import com.sap.it.api.mapping.*;

def void Header_Item_mapping(String[] I_SiteID, String[] I_OwnerID, String[] I_Product, String[] I_StockID, String[] I_Restricted, String[] I_Inspection, String[] I_Consignment, String[] I_Quantity, String[] I_Quantity_Type, String[] I_AreaID, String[] I_CustodianID, String[] S_SiteID, String[] S_OwnerID, String[] S_Product,String[] S_StockID, String[] S_Restricted, String[] S_Inspection, String[] S_Consignment, String[] S_AreaID, String[] S_CustodianID, String[] S_SerialID, Output output_DocNo, Output output_ItemNo, Output output_Material, Output output_Plant, Output output_Location,           Output output_StockIndicator, Output output_Quantity, Output output_UOM, Output output_StockType, Output output_BatchNo, Output output_Customer, Output output_SerialNo, Output output_Header_DocNo, Output output_Header_Companycode){
    
    
    int Doc_No_Count = 1
    
    Map<String,String> map_DocNo_ItemNo = new HashMap<>(); // ( OwnerID, [DocNo, ItemNo] )
    
    Map<String,String> map_Inv_QuantityType = new HashMap<>(); // ( [I_SiteID, I_OwnerID, I_Product] , I_Quantity_Type )
    for(int i=0; i < I_OwnerID.length ; i++){
        map_Inv_QuantityType.put( [I_SiteID[i], I_OwnerID[i], I_Product[i]] , I_Quantity_Type[i] )
    }
    
    Map<String,String> map_SerialNo_Sheet = new HashMap<>(); // ( [S_SiteID,S_OwnerID,S_Product], <<Number>> ) <<Number>> is the how many of this key field combination is repeated in Serial Number Sheet.
    for( int i=0; i < S_OwnerID.length ; i++){
        
        // Enter Quantity for [ S_SiteID,S_OwnerID,S_Product ] combination
        def result = map_SerialNo_Sheet.get( [S_SiteID[i],S_OwnerID[i],S_Product[i]] )
        if(result == null){
            map_SerialNo_Sheet.put( [S_SiteID[i],S_OwnerID[i],S_Product[i]] , 1)
        }
        else{
            map_SerialNo_Sheet.put( [S_SiteID[i],S_OwnerID[i],S_Product[i]] , result+1)
        }
        
        
        //Store and Output Doc No and Item No
        def result1 = map_DocNo_ItemNo.get( S_OwnerID[i] )
        if(result1 == null){
            map_DocNo_ItemNo.put( S_OwnerID[i], [Doc_No_Count,10] )
            output_DocNo.addValue(Doc_No_Count)
            output_ItemNo.addValue(10)
            
            
            output_Header_DocNo.addValue(Doc_No_Count)
            output_Header_Companycode.addValue(S_OwnerID[i])
            Doc_No_Count++
            
        }
        else{
            if(result1[1]+10 > 9990){
                map_DocNo_ItemNo.put( S_OwnerID[i], [Doc_No_Count, 10])
                output_DocNo.addValue( Doc_No_Count)
                output_ItemNo.addValue( 10 )
                
                output_Header_DocNo.addValue(Doc_No_Count)
                output_Header_Companycode.addValue(S_OwnerID[i])
                Doc_No_Count++
            }
            else{
                map_DocNo_ItemNo.put( S_OwnerID[i], [result1[0], result1[1]+10 ] )
                output_DocNo.addValue( result1[0] )
                output_ItemNo.addValue( result1[1]+10 )
            }
        }
        //Material
        output_Material.addValue(S_Product[i])
        
        //Plant
        output_Plant.addValue(S_SiteID[i])
        
        //Storage Location
        output_Location.addValue(S_AreaID[i])
        
        //Special Stock Indicator and Customer
        if(S_Consignment[i].length() > 0){
            output_StockIndicator.addValue('W')
            output_Customer.addValue(S_CustodianID[i])
        }
        else{
            output_StockIndicator.addValue('')
            output_Customer.addValue('')
        }
        
        //Quantity
        output_Quantity.addValue(1)
        
        //UOM
        output_UOM.addValue( map_Inv_QuantityType.get( [S_SiteID[i], S_OwnerID[i], S_Product[i]] ) )
        
        //Stock Type
        if(S_Restricted[i].length() > 0){
            output_StockType.addValue('S')
        }
        else{
            if(S_Inspection[i].length() > 0 ){
                output_StockType.addValue('X')
            }
            else{
                output_StockType.addValue('')
            }
        }
        
        //BatchNo
        output_BatchNo.addValue(S_StockID[i])
        
        //Serail Number
        output_SerialNo.addValue(S_SerialID[i])
    }
    
    for (int i=0; i < I_OwnerID.length; i++){
        
        def result = map_SerialNo_Sheet.get( [I_SiteID[i],I_OwnerID[i],I_Product[i]])
        
        // "map_SerialNo_Sheet" will have number of time [I_SiteID,I_OwnerID,I_Product] combination are repeated in Sreial Number sheet.
        // check if the current record in Inventory is in the map_SerialNo_Sheet or not, if not then output the corresponing field values of the current record
        // if current record exists in map_SerialNo_Sheet, then check if Quantity in Inventory Sheet is same as the result for the combination [I_SiteID,I_OwnerID,I_Product] in map_DocNo_ItemNo.
        // If I_Quantity[i] is same as result then we can skip the current record in Inventory sheet. Else we enter the current record but we will decrease the Quantity of accordingly.
        
        if(result == null || (I_Quantity[i].toInteger()) != result){
            def result1 = map_DocNo_ItemNo.get( I_OwnerID[i])
            // Store and output Doc No and Item No
            if(result1 == null){
                map_DocNo_ItemNo.put( I_OwnerID[i], [Doc_No_Count,10])
                output_DocNo.addValue(Doc_No_Count)
                output_ItemNo.addValue(10)
                
                output_Header_DocNo.addValue(Doc_No_Count)
                output_Header_Companycode.addValue(I_OwnerID[i])
                Doc_No_Count++
            }
            else{
                if(result1[1]+10 > 9990){
                    map_DocNo_ItemNo.put(I_OwnerID[i], [Doc_No_Count, 10] )
                    output_DocNo.addValue(Doc_No_Count)
                    output_ItemNo.addValue(10)
                    
                    output_Header_DocNo.addValue(Doc_No_Count)
                    output_Header_Companycode.addValue(I_OwnerID[i])
                    Doc_No_Count++
                }
                else{
                    map_DocNo_ItemNo.put(I_OwnerID[i], [result1[0], result1[1]+10] )
                    output_DocNo.addValue(result1[0])
                    output_ItemNo.addValue(result1[1]+10)
                }
            }
            
            //Quantity
            if(result == null){
                output_Quantity.addValue(I_Quantity[i])
            }
            else{
                output_Quantity.addValue(I_Quantity[i].toInteger() - result)
            }
            
            //Material
            output_Material.addValue(I_Product[i])
            
            //Plant
            output_Plant.addValue(I_SiteID[i])
            
            //Storage Location
            output_Location.addValue(I_AreaID[i])
            
            //Special Stock Indicator and Customer
            if(I_Consignment[i].length() > 0){
                output_StockIndicator.addValue('W')
                output_Customer.addValue(I_CustodianID[i])
            }
            else{
                output_StockIndicator.addValue('')
                output_Customer.addValue('')
            }
            
            //UOM
            output_UOM.addValue( I_Quantity_Type[i] )
            
            //Stock Type
            if(I_Restricted[i].length() > 0){
                output_StockType.addValue('S')
            }
            else{
                if(I_Inspection[i].length() > 0 ){
                    output_StockType.addValue('X')
                }
                else{
                    output_StockType.addValue('')
                }
            }
            
            //BatchNo
            output_BatchNo.addValue(I_StockID[i])
            
            //Serail Number
            output_SerialNo.addValue('')
        }
        
    }
}