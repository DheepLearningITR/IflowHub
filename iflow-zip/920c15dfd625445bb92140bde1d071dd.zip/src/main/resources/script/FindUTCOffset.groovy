import com.sap.it.api.mapping.*;
import groovy.json.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String customFunc(String arg1){
 
def jsonSlurper = new JsonSlurper()
def timeZoneJson = getAllTimeZones();
def timeZoneList = jsonSlurper.parseText(timeZoneJson)
def timeZoneObject = timeZoneList.find {element -> element.code == arg1 }
def UtcOffset 
 
if(null != timeZoneObject) 
{ UtcOffset = convertTZToMktFormat(timeZoneObject.timeZone)
}
else {
// messageLog.setStringProperty("Logging#1", "Invalid Time zone specified for the webinar " + eventDetail.webinarKey.text() + ", please check the timezone code of the timezone table")
}
return UtcOffset;
}


/**
 * This method converts the Timezone offset to SAP Marketing Format
 * For example: If the source timestamp is GMT+13:00, then the returned value is P1300
 **/
def String convertTZToMktFormat(String sourceTimezoneOffset) {
    
    sourceTimezoneOffset = sourceTimezoneOffset.replace(":", "");
    if (sourceTimezoneOffset.length() == 3) {
      return "P0000";
    } else if (sourceTimezoneOffset.charAt(3) == '+') {
      return sourceTimezoneOffset.replace("GMT+", "P");
    } else if (sourceTimezoneOffset.charAt(3) == '-') {
      return sourceTimezoneOffset.replace("GMT-", "M");
    }
    
}

/**
 * Returns a JsonArray which contains all the Timezone mappings
 **/
def String getAllTimeZones() {
    return '[ { "timeZone": "GMT+13:00", "description": "Nukualofa", "code": "Pacific/Tongatapu" }, { "timeZone": "GMT+12:00", "description": "Fiji, Kamchatka, Marshall Is.", "code": "Pacific/Fiji" }, { "timeZone": "GMT+12:00", "description": "Auckland, Wellington", "code": "Pacific/Auckland" }, { "timeZone": "GMT+11:00", "description": "Magadan, Solomon Is., New Caledonia", "code": "Asia/Magadan" }, { "timeZone": "GMT+10:00", "description": "Vladivostok", "code": "Asia/Vladivostok" }, { "timeZone": "GMT+10:00", "description": "Hobart", "code": "Australia/Hobart" }, { "timeZone": "GMT+10:00", "description": "Guam, Port Moresby", "code": "Pacific/Guam" }, { "timeZone": "GMT+10:00", "description": "Canberra, Melbourne, Sydney", "code": "Australia/Sydney" }, { "timeZone": "GMT+10:00", "description": "Brisbane", "code": "Australia/Brisbane" }, { "timeZone": "GMT+09:30", "description": "Darwin", "code": "Australia/Darwin" }, { "timeZone": "GMT+09:30", "description": "Adelaide", "code": "Australia/Adelaide" }, { "timeZone": "GMT+09:00", "description": "Yakutsk", "code": "Asia/Yakutsk" }, { "timeZone": "GMT+09:00", "description": "Seoul", "code": "Asia/Seoul" }, { "timeZone": "GMT+09:00", "description": "Osaka, Sapporo, Tokyo", "code": "Asia/Tokyo" }, { "timeZone": "GMT+08:00", "description": "Taipei", "code": "Asia/Taipei" }, { "timeZone": "GMT+08:00", "description": "Perth", "code": "Australia/Perth" }, { "timeZone": "GMT+08:00", "description": "Kuala Lumpur, Singapore", "code": "Asia/Singapore" }, { "timeZone": "GMT+08:00", "description": "Irkutsk, Ulaan Bataar", "code": "Asia/Irkutsk" }, { "timeZone": "GMT+08:00", "description": "Beijing, Chongqing, Hong Kong, Urumqi", "code": "Asia/Shanghai" }, { "timeZone": "GMT+07:00", "description": "Krasnoyarsk", "code": "Asia/Krasnoyarsk" }, { "timeZone": "GMT+07:00", "description": "Bangkok", "code": "Asia/Bangkok" }, { "timeZone": "GMT+07:00", "description": "Hanoi, Jakarta", "code": "Asia/Jakarta" }, { "timeZone": "GMT+06:30", "description": "Rangoon", "code": "Asia/Rangoon" }, { "timeZone": "GMT+06:00", "description": "Sri Jayawardenepura", "code": "Asia/Colombo" }, { "timeZone": "GMT+06:00", "description": "Astana, Dhaka", "code": "Asia/Dhaka" }, { "timeZone": "GMT+06:00", "description": "Almaty, Novosibirsk", "code": "Asia/Novosibirsk" }, { "timeZone": "GMT+05:45", "description": "Kathmandu", "code": "Asia/Katmandu" }, { "timeZone": "GMT+05:30", "description": "Calcutta, Chennai, Mumbai, New Delhi", "code": "Asia/Calcutta" }, { "timeZone": "GMT+05:00", "description": "Islamabad, Karachi, Tashkent", "code": "Asia/Karachi" }, { "timeZone": "GMT+05:00", "description": "Ekaterinburg", "code": "Asia/Yekaterinburg" }, { "timeZone": "GMT+04:30", "description": "Kabul", "code": "Asia/Kabul" }, { "timeZone": "GMT+04:00", "description": "Baku, Tbilisi, Yerevan", "code": "Asia/Tbilisi" }, { "timeZone": "GMT+04:00", "description": "Abu Dhabi, Muscat", "code": "Asia/Muscat" }, { "timeZone": "GMT+03:30", "description": "Tehran", "code": "Asia/Tehran" }, { "timeZone": "GMT+03:00", "description": "Nairobi", "code": "Africa/Nairobi" }, { "timeZone": "GMT+03:00", "description": "Moscow, St. Petersburg, Volgograd", "code": "Europe/Moscow" }, { "timeZone": "GMT+03:00", "description": "Kuwait, Riyadh", "code": "Asia/Kuwait" }, { "timeZone": "GMT+03:00", "description": "Baghdad", "code": "Asia/Baghdad" }, { "timeZone": "GMT+02:00", "description": "Jerusalem", "code": "Asia/Jerusalem" }, { "timeZone": "GMT+02:00", "description": "Helsinki, Riga, Tallinn", "code": "Europe/Helsinki" }, { "timeZone": "GMT+02:00", "description": "Harare, Pretoria", "code": "Africa/Harare" }, { "timeZone": "GMT+02:00", "description": "Cairo", "code": "Africa/Cairo" }, { "timeZone": "GMT+02:00", "description": "Bucharest", "code": "Europe/Bucharest" }, { "timeZone": "GMT+02:00", "description": "Athens, Istanbul, Minsk", "code": "Europe/Athens" }, { "timeZone": "GMT+01:00", "description": "West Central Africa", "code": "Africa/Malabo" }, { "timeZone": "GMT+01:00", "description": "Sarajevo, Skopje, Sofija, Vilnius, Warsaw, Zagreb", "code": "Europe/Warsaw" }, { "timeZone": "GMT+01:00", "description": "Brussels, Copenhagen, Madrid, Paris", "code": "Europe/Brussels" }, { "timeZone": "GMT+01:00", "description": "Belgrade, Bratislava, Budapest, Ljubljana, Prague", "code": "Europe/Prague" }, { "timeZone": "GMT+01:00", "description": "Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna", "code": "Europe/Amsterdam" }, { "timeZone": "GMT", "description": "Greenwich Mean Time", "code": "GMT" }, { "timeZone": "GMT", "description": "Dublin, Edinburgh, Lisbon, London", "code": "Europe/London" }, { "timeZone": "GMT", "description": "Casablanca, Monrovia", "code": "Africa/Casablanca" }, { "timeZone": "GMT-01:00", "description": "Cape Verde Is.", "code": "Atlantic/Cape_Verde" }, { "timeZone": "GMT-01:00", "description": "Azores", "code": "Atlantic/Azores" }, { "timeZone": "GMT-03:00", "description": "Buenos Aires, Georgetown", "code": "America/Buenos_Aires" }, { "timeZone": "GMT-03:00", "description": "Brasilia", "code": "America/Sao_Paulo" }, { "timeZone": "GMT-03:30", "description": "Newfoundland", "code": "America/St_Johns" }, { "timeZone": "GMT-04:00", "description": "Santiago", "code": "America/Santiago" }, { "timeZone": "GMT-04:00", "description": "Caracas, La Paz", "code": "America/Caracas" }, { "timeZone": "GMT-04:00", "description": "Atlantic Time Canada", "code": "America/Halifax" }, { "timeZone": "GMT-05:00", "description": "Indiana East", "code": "America/Indianapolis" }, { "timeZone": "GMT-05:00", "description": "Eastern Time US and Canada", "code": "America/New_York" }, { "timeZone": "GMT-05:00", "description": "Bogota, Lima, Quito", "code": "America/Bogota" }, { "timeZone": "GMT-06:00", "description": "Mexico City", "code": "America/Mexico_City" }, { "timeZone": "GMT-06:00", "description": "Central Time US and Canada", "code": "America/Chicago" }, { "timeZone": "GMT-07:00", "description": "Mountain Time US and Canada", "code": "America/Denver" }, { "timeZone": "GMT-07:00", "description": "Arizona", "code": "America/Phoenix" }, { "timeZone": "GMT-07:00", "description": "US Pacific New", "code": "US/Pacific-New" }, { "timeZone": "GMT-08:00", "description": "Pacific Time US and Canada", "code": "America/Los_Angeles" }, { "timeZone": "GMT-09:00", "description": "Alaska", "code": "America/Anchorage" }, { "timeZone": "GMT-10:00", "description": "Hawaii", "code": "Pacific/Honolulu" }, { "timeZone": "GMT-11:00", "description": "Midway Island, Samoa", "code": "MIT" } ]'
}

