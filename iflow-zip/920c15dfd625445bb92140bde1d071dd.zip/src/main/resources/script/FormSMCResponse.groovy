/**
 * In this script, we form the final response to SMC based on total number of events. 
 * If the total events = 0, we send an empty list. 
 * If the total events = 1 we send the single event enclosed in a list
 * If the total events > 1 we send the whole list to SMC
 **/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonBuilder;
def Message processData(Message message) {
    def body = message.getBody(String.class);
    def pagecount = message.getProperty("pagecount");
    def messageLog = messageLogFactory.getMessageLog(message);
    message.setHeader("Content-Type", "application/json");
    message.setHeader("pagecount", pagecount);
    
    def jsonSlurper = new JsonSlurper();
     //convert the body to a json object
    def jsonObject = jsonSlurper.parseText(body.toString());
     //get the events from  json object
    def events = jsonObject.events;
    if(events != null)
    {
        def evtArray = [];
        evtArray.add(events);
        def jsonOP = JsonOutput.toJson(evtArray);
        message.setBody(jsonOP);
    }
    return message;

}