/**
 * Initialize the Resource Path for OpenConnector Call, depending on whether the lastRunTime is passed or not. 
 **/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.*;
import java.util.Date;

def Message processData(Message message) {
   def messageLog = messageLogFactory.getMessageLog(message);
   def map = message.getHeaders();
   def externalEventId = map.get("externalEventId");
   
   def meetingsQuery = "/meetings/$externalEventId"
   messageLog.setStringProperty("Logging#1", "Event ID from App. Job: $externalEventId");
   message.setProperty("resourcePath",meetingsQuery);
       return message;}
   
  