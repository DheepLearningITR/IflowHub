import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //remove the <xml> tags as this will give error while mapping
    def body = message.getBody(java.lang.String) as String;
    def newBody = body.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
    message.setBody(newBody);
    return message;
}