import com.sap.it.api.mapping.*;

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    //Body 
    def body = message.getBody();
    def statusCode ="";
    def errorContent="";
    def map = message.getProperties()
    def ex = map.get("CamelExceptionCaught")
    
    if (ex!=null) 
    {
       //Detect exception type
      def exType = ex.getClass().getCanonicalName()
      if (exType == "org.apache.camel.component.ahc.AhcOperationFailedException")
      {
        statusCode=ex.getStatusCode();
        errorContent=ex.getResponseBody()
      }
      else if (exType == "com.sap.it.rt.adapter.openconnectors.exceptions.OpenConnectorsException")
      {
        statusCode = (ex.getMessage() =~ /status code ?: ?(\d{3})/)[0][1]
        errorContent=ex.getMessage()
      }
    }

    message.setHeader("CamelHttpResponseCode",statusCode);
    message.setBody(errorContent);  
       
    return message;
}