import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def klart = message.getProperty("klart")
    def entryId = message.getProperty("LONG_ENTRY_ID") ? message.getProperty("LONG_ENTRY_ID"):message.getProperty("SHORT_ENTRY_ID")
    
    message.setHeader("ENTRY_ID", entryId+'_'+klart);
    return message;
}