import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();
       
       def map = message.getProperties();
       String value = map.get("date1");
       value = value.substring(0,10);
       Date date1 = Date.parse('yyyy-MM-dd', value)
       Date date = date1.plus(1)
       String datePart = date.format("ddMMyyyy")
       message.setProperty("absdate", datePart);
       
       String value1 = map.get("date2");
       value1 = value1.substring(0,10);
        Date date2 = Date.parse('yyyy-MM-dd', value1)
        String datePart1 = date2.format("ddMMyyyy")
       message.setProperty("consdate", datePart1);
      
       return message;
}