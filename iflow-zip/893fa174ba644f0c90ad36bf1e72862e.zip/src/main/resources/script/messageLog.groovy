import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData_RC_Customer(Message message) {
	def map = message.getProperties();
	def property_EnableErrorLogOnly = map.get("EnableErrorLogOnly");
	def property_EnableAllLog = map.get("EnableAllLog");
	if (property_EnableAllLog.toUpperCase().equals("TRUE") && (!property_EnableErrorLogOnly.toUpperCase().equals("TRUE"))  ) {
		def body = message.getBody(java.lang.String) as String;
		def customer = new XmlSlurper().parseText(body);
		def customerId = customer.Customers.customerNumber as String;
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString("SB(" + customerId + ")_SB_structure", body, "text/xml");
		}
	}
	return message;
}

def Message processData_S4_Inbound(Message message) {
	def map = message.getProperties();
	def property_EnableErrorLogOnly = map.get("EnableErrorLogOnly");
	def property_EnableAllLog = map.get("EnableAllLog");
	if (property_EnableAllLog.toUpperCase().equals("TRUE") && (!property_EnableErrorLogOnly.toUpperCase().equals("TRUE"))  ) {
	def body = message.getBody(java.lang.String) as String;
	def businessPartner = new XmlSlurper().parseText(body);
	def rcId = businessPartner.BusinessPartnerSUITEReplicateRequestMessage.BusinessPartner.InternalID as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	if (messageLog != null) {
			messageLog.addAttachmentAsString("SB(" + rcId + ")_S4_structure", body, "text/xml");
		}
	}
	return message;
}