import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.http.HttpStatus;
import groovy.json.JsonOutput;
import javax.activation.MimetypesFileTypeMap
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

def processData(Message message) {
    def pgpData = message.getBody();

    def headers = message.getHeaders();
    def folderpath = headers.get("folderpath", String);
    def mimeType = headers.get("Content-Type", String);
    def fileName = headers.get("filename", String);
    
    if(mimeType == null){
        mimeType = "application/vnd.ms-outlook";
    }

    byte[] fileContent = pgpData.getBytes();
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
     String formDataPart1 = '----cpi\r\nContent-Disposition: form-data; name="cmisaction"\r\n\r\ncreateDocument\r\n----cpi\r\nContent-Disposition: form-data; name="media"; filename="' + fileName + '"\r\nContent-Type: ' + mimeType + '\r\n\r\n';
     String formDataPart2 = '\r\n----cpi\r\nContent-Disposition: form-data; name="propertyValue[0]"\r\n\r\n' + fileName + '\r\n----cpi\r\nContent-Disposition: form-data; name="propertyId[0]"\r\n\r\ncmis:name\r\n----cpi\r\nContent-Disposition: form-data; name="propertyId[1]"\r\n\r\ncmis:objectTypeId\r\n----cpi\r\nContent-Disposition: form-data; name="propertyValue[1]"\r\n\r\ncmis:document\r\n----cpi--\r\n';
    byte[] formDataPart1Bytes = formDataPart1.getBytes();
    byte[] formDataPart2Bytes = formDataPart2.getBytes();
    outputStream.write(formDataPart1Bytes);
    outputStream.write(fileContent);
    outputStream.write(formDataPart2Bytes);
    message.setBody(outputStream);
    message.setHeader("Content-Type", "multipart/form-data; boundary=--cpi");
    return message;

}