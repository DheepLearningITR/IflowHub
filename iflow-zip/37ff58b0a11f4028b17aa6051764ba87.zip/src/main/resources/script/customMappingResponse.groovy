import com.sap.it.api.mapping.*;

//Add MappingContext parameter to read or set headers and properties
def String getExchangeProperty(String propertyName,MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}

def String getZipCode(String zip,String zip4) {
    String zip9 = zip;
    if(zip4?.trim())
    {
        zip9 = zip + "-" + zip4;
    }
    return zip9;
}

def String getTaxJurisdictionCode(String geoCode, String stateCode,MappingContext context) {
    String jcdUnifyIndicator = context.getProperty("exchangejcdunifyind");
    String taxJurisdictionCode = geoCode;
    if(jcdUnifyIndicator != null && "X".equalsIgnoreCase(jcdUnifyIndicator.trim()))
    {
        //get country + 
        taxJurisdictionCode = geoCode.substring(0,2) + stateCode + geoCode.substring(2) + "-";
    }
    return taxJurisdictionCode;
}

def String getTaxJursdictionLevel1(String defaultValue, MappingContext context) {
    String jcdUnifyIndicator = context.getProperty("exchangejcdunifyind");
    String taxJurisdictionLevel1 = defaultValue;
    if(jcdUnifyIndicator != null && "X".equalsIgnoreCase(jcdUnifyIndicator.trim()))
    {
        taxJurisdictionLevel1 = "4";
    }
    return taxJurisdictionLevel1;
}

def String getTaxJursdictionLevel2(String defaultValue, MappingContext context) {
    String jcdUnifyIndicator = context.getProperty("exchangejcdunifyind");
    String taxJurisdictionLevel2 = defaultValue;
    if(jcdUnifyIndicator != null && "X".equalsIgnoreCase(jcdUnifyIndicator.trim()))
    {
        taxJurisdictionLevel2 = "11";
    }
    return taxJurisdictionLevel2;
}


def String getTaxJursdictionLevel3(String defaultValue,MappingContext context) {
    String jcdUnifyIndicator = context.getProperty("exchangejcdunifyind");
    String taxJurisdictionLevel3 = defaultValue;
    if(jcdUnifyIndicator != null && "X".equalsIgnoreCase(jcdUnifyIndicator.trim()))
    {
        taxJurisdictionLevel3 = "0";
    }
    return taxJurisdictionLevel3;
}
def String getTaxJursdictionLevel4(String defaultValue,MappingContext context) {
    String jcdUnifyIndicator = context.getProperty("exchangejcdunifyind");
    String taxJurisdictionLevel4 = defaultValue;
    if(jcdUnifyIndicator != null && "X".equalsIgnoreCase(jcdUnifyIndicator.trim()))
    {
        taxJurisdictionLevel4 = "0";
    }
    return taxJurisdictionLevel4;
}
