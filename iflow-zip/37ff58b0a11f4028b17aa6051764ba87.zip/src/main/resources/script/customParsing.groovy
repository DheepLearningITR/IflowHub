import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import java.util.Date;
import java.text.SimpleDateFormat;

def String getCurrentYear(String arg1="")
{
    String year = "";
    try
    {
        Date date = new Date();
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
        year = yearFormat.format(date);
        return year;
    } catch(Exception e)
    {
        
    }
    return year;
}

def String getCurrentMonth(String arg1="")
{
    String month = "";
    try
    {
        Date date = new Date();
        SimpleDateFormat monthFormat = new SimpleDateFormat("MM");
        month = monthFormat.format(date);
        return month;
    } catch(Exception e)
    {
        
        
    }
    return month;
}


def String stGetZip4(String arg1, String theCountry){
    if( theCountry && !(theCountry.equalsIgnoreCase("US") || theCountry.equalsIgnoreCase("USA")) ) {
        return "";
    }
    
    def tokens = arg1.tokenize("-");
    
    if( tokens ) {
        int i = 0;
        for( item in tokens ) {
            if( i == 1 ) {
                return item;
            } else if ( i > 1 ) {
                return "";
            }
            i++;
        }
    }
    
	return "";
}

def String customGetClientNumber(String storedUsername) {
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential(storedUsername);
    if (credential == null) {
        throw new IllegalStateException("No credential found for alias '$storedUsername'");
    }
    return credential.getUsername();
}

def String customGetVKey (String storedUsername) {
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential(storedUsername);
    if (credential == null) {
        throw new IllegalStateException("No credential found for alias '$storedUsername'");
    }
    return new String(credential.getPassword());
}


def String getClientTracking(String theVersion, MappingContext context) {
    String exchangeSystName = getExchangeProperty("exchangeSystName", context);
    String exchangeSapVersion = getExchangeProperty("exchangeSapVersion", context);
    return "SAPS4HC;" + exchangeSystName + ";" + exchangeSapVersion + ";v" + theVersion + ";DetermineJurisdiction;";
}

def String stGetZip5(String arg1, String theCountry){
  
    if( theCountry == null || theCountry.trim().equals("") ) {
        throw new Exception("COUNTRY is required");
    }
    
    if( theCountry && !(theCountry.equalsIgnoreCase("US") || theCountry.equalsIgnoreCase("USA")) ) {
        return arg1;
    }
    
    def tokens = arg1.tokenize("-");
    
    if( tokens ) {
        int i = 0;
        for( item in tokens ) {
            if( i == 0 ) {
                return item;
            } else if ( i > 0 ) {
                return "";
            }
            i++;
        }
    }
    
	return "";
}

def String getExchangeProperty(String propertyName, MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}