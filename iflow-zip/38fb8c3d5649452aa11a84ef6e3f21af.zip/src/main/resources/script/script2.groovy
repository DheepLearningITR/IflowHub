/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processDataUpdateBillStatusOfBillingdoc(Message message) {
    def map = message.getProperties();
    def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
        def body = message.getBody(java.lang.String) as String;
        def billLogID = map.get("BillLogID");
        def messageLog = messageLogFactory.getMessageLog(message);
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Bill(" + billLogID + ")_billingdoc_status_update_req", body, "text/json");
        }
    }
    return message;
}

def Message processDataUpdateBillStatusOfInvoice(Message message) {
    def map = message.getProperties();
    def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
        def body = message.getBody(java.lang.String) as String;
        def billLogID = map.get("BillLogID");
        def messageLog = messageLogFactory.getMessageLog(message);
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Bill(" + billLogID + ")_invoice_status_update_req", body, "text/json");
        }
    }
    return message;
}

