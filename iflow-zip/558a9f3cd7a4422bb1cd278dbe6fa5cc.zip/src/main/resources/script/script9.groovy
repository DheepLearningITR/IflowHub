/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonBuilder;
def Message processData(Message message) {
//get the message Body  as string object
        def body = message.getBody(String.class);
        def jsonSlurper = new JsonSlurper();
         //convert the body to a json object
         def jsonObject = jsonSlurper.parseText(body.toString());
         //get the attendees from  json object
        def root = jsonObject.root;
        if(root != null)
        {
            def totalAttendees = jsonObject.root.totalattendees;
            def attendees= jsonObject.root.attendees;
            def jsonOP;
            //if there are no attendees then send empty array
            if(totalAttendees == "0")
            {
                jsonOP = [];
            }
            else
            {
                 attendees.each{
                def qustionAnswers =  it.QUESTIONANSWERS;
                if(qustionAnswers !=null)
                {
                    qustionAnswers.each
                    {
                        def answers = it.ANSWERS;
                        if(answers != null)
                        {
                            def answertext = it.ANSWERS.MKTGEVTPRTCPNTANSWTXT;
                            it.remove('ANSWERS');
                            it.put('MKTGEVTPRTCPNTANSWTXT',answertext);
                        }
                    
                    }
                }
                
                // the interaction properties in the xsd are in user readable form. we have to convert them to the technical names that SMC understands
                //here we only convert those properties that are not null or empty
                def interactions = it.interactions;
                if(interactions !=null && !interactions.isEmpty() && interactions.size() !=0)
                {
                    
                    interactions.each{
                        it.put('ID',it.InteractionContactId);
                        it.remove('InteractionContactId');
                         it.put('COMM_MEDIUM',it.CommunicationMedium);
                        it.remove('CommunicationMedium');
                        it.put('IA_TYPE',it.InteractionType);
                        it.remove('InteractionType');
                        it.put('TIMESTAMP',it.InteractionTimeStampUTC);
                        it.remove('InteractionTimeStampUTC');
                        
                    }
                }
                
                
            }
                jsonOP = JsonOutput.toJson(attendees);
                
            }
            message.setBody(jsonOP);
        }
        return message;
}