
import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat;
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonSlurper;

def Message getLineItems(Message message) {
    def mpl = messageLogFactory.getMessageLog(message)

    message.properties.RuleInput = '';
    message.properties.RuleOutput = '';
    message.properties.CurrentTime = getCurrentDateTime();
//    mpl.addAttachmentAsString('CurrentTime - ' + message.properties.CurrentTime, '', "text/plain");

    if (message.properties.LastUpdated == '') {
//        message.properties.LastUpdated = '2020-06-13T00:00:00Z';
        message.properties.LastUpdated = '2020-06-11T14:47:49Z';

        // message.properties.LastUpdated = getCurrentDateTime0();
    }
//    mpl.addAttachmentAsString('LastUpdated - ' + message.properties.LastUpdated, '', "text/plain");

    message.properties.jsonEvents = '{"Events": []}';

    String body = message.getBody(java.lang.String);
    mpl.addAttachmentAsString('1 - Ariba response ', body, "text/plain");
    
//    message.properties.aribaResponse = ;

    def jsonBody = new groovy.json.JsonSlurper().parseText(body);
//    groovy.json.internal.LazyMap jsonLineItems = new groovy.json.JsonSlurper().parseText('{"LineItems": []}');
    groovy.json.internal.LazyMap jsonApprovalRequests = new groovy.json.JsonSlurper().parseText('{"ApprovalRequests": []}');
    String approvalDate ='';

    if (jsonBody.Records.size() > 0) {
//        mpl.addAttachmentAsString('Records.size() = ' + String.valueOf(jsonBody.Records.size()), '', "text/plain");
        for (int i = 0; i < jsonBody.Records.size(); i++) {
            if (jsonBody.Records[i].ApprovalRequests != null && jsonBody.Records[i].ApprovalRequests.size() > 0 && jsonBody.Records[i].LineItems != null && jsonBody.Records[i].LineItems.size() > 0) {

                //Sorting ApprovalRequests array
                if (jsonBody.Records[i].ApprovalRequests.size() > 1) {
                    def sortedJSON = jsonBody.Records[i].ApprovalRequests.sort { a,b -> a.ActivationDate <=> b.ActivationDate}
                }

                boolean autoApproved = true;
                for (int l = 0; l < jsonBody.Records[i].ApprovalRequests.size(); l++) {
                    if (jsonBody.Records[i].ApprovalRequests[l].ApprovalRequired != null && jsonBody.Records[i].ApprovalRequests[l].ApprovalRequired) {
                        autoApproved = false;
                        break;
                    }
                }

                for (int k = 0; k < jsonBody.Records[i].ApprovalRequests.size(); k++) {
                    if (k == jsonBody.Records[i].ApprovalRequests.size() -1) {
                        approvalDate =  jsonBody.Records[i].ApprovedDate;
                    }
                    else {
                        if (jsonBody.Records[i].ApprovalRequests[k].ActivationDate != null
                                && jsonBody.Records[i].ApprovalRequests[k+1].ActivationDate != null
                                && jsonBody.Records[i].ApprovalRequests[k].ApprovalRequired == false
                                && jsonBody.Records[i].ApprovalRequests[k].ApprovedBy != null
                                && k < jsonBody.Records[i].ApprovalRequests.size() -2) {
                            approvalDate =  jsonBody.Records[i].ApprovalRequests[k+1].ActivationDate;
                        }
                    }

                    def approvalRequestElement = [
//                            PRApprovalDate: approvalDate,
//                            ApprovedDate: approvalDate,
                            PRApprovalDate: jsonBody.Records[i].ApprovedDate,
                            ApprovedDate: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].ActivationDate : null,
                            ApprovedBy: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].ApprovedBy : null,
                            TimeUpdated: null,
                            CreateDate: jsonBody.Records[i].CreateDate,
                            ERPRequisitionID: jsonBody.Records[i].ERPRequisitionID,
                            UniqueName: jsonBody.Records[i].UniqueName,
                            Requestor: jsonBody.Records[i].Requester.UniqueName,
                            StatusString: jsonBody.Records[i].StatusString,
                            TotalCost: jsonBody.Records[i].TotalCost.Amount,
                            Currency: jsonBody.Records[i].TotalCost.Currency.UniqueName,
                            ApprovalRequired: (jsonBody.Records[i].ApprovalRequests[k] != null) ? String.valueOf(jsonBody.Records[i].ApprovalRequests[k].ApprovalRequired) : null,
                            AssignedDate: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].AssignedDate : null,
                            ActivationDate: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].ActivationDate : null,
                            OrderedDate: (jsonBody.Records[i].OrderedDate != null) ? jsonBody.Records[i].OrderedDate : '1970-01-01T00:00:00Z',
                            LastUpdated: message.properties.LastUpdated,
                            ReceivedDate: jsonBody.Records[i].ReceivedDate,
                            AreOrdersStuck: (jsonBody.Records[i].AreOrdersStuck != null) ? String.valueOf(jsonBody.Records[i].AreOrdersStuck) : null,
                            EscalationDate: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].EscalationDate : null,
                            AssignedTo: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].AssignedTo : null,
                            SubmitDate: jsonBody.Records[i].SubmitDate,
                            LastModified: (jsonBody.Records[i].LastModified != null) ? jsonBody.Records[i].LastModified : null,
                            RuleName: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].RuleName.trim() : null,
                            AutoApproved: String.valueOf(autoApproved),
                            LineItems: []
                    ];
                    def jsonBldrApprovalRequest = new JsonBuilder(approvalRequestElement).toString();
                    def jsonSlrprApprovalRequest = new groovy.json.JsonSlurper().parseText(jsonBldrApprovalRequest);

                    for (int j = 0; j < jsonBody.Records[i].LineItems.size(); j++) {
                        def data = [
//                                PRApprovalDate: approvalDate,
//                                ApprovedDate: jsonBody.Records[i].ApprovedDate,
//                                PRApprovalDate: jsonBody.Records[i].ApprovedDate,
//                                ApprovedDate: approvalDate,
                                PRApprovalDate: jsonBody.Records[i].ApprovedDate,
                                ApprovedDate: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].ActivationDate : null,
                                ApprovedBy: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].ApprovedBy : null,
                                TimeUpdated: null,
                                LineItemNumber: jsonBody.Records[i].LineItems[j].NumberInCollection,
                                CreateDate: jsonBody.Records[i].CreateDate,
                                ERPRequisitionID: jsonBody.Records[i].ERPRequisitionID,
                                UniqueName: jsonBody.Records[i].UniqueName,
                                Requestor: jsonBody.Records[i].Requester.UniqueName,
                                StatusString: jsonBody.Records[i].StatusString,
                                TotalCost: jsonBody.Records[i].TotalCost.Amount,
                                MaterialCode: jsonBody.Records[i].LineItems[j]['Description.CommonCommodityCode'].UniqueName,
                                MaterialDescription: jsonBody.Records[i].LineItems[j]['Description.CommonCommodityCode'].Name,
                                AccountCategory: jsonBody.Records[i].LineItems[j].AccountCategory.UniqueName,
                                DeliveryDate: jsonBody.Records[i].LineItems[j].cus_EndDate,
                                Supplier: jsonBody.Records[i].LineItems[j].Supplier.Name,
                                SupplierId: jsonBody.Records[i].LineItems[j].Supplier.UniqueName,
                                Currency: jsonBody.Records[i].TotalCost.Currency.UniqueName,
                                Amount: jsonBody.Records[i].LineItems[j].Amount.Amount,
                                UnitofMeasure: jsonBody.Records[i].LineItems[j]['Description.UnitOfMeasure'].UniqueName,
                                PurchasingOrg : (jsonBody.Records[i].LineItems[j].PurchaseOrg != null && jsonBody.Records[i].LineItems[j].PurchaseOrg.UniqueName != null) ? jsonBody.Records[i].LineItems[j].PurchaseOrg.UniqueName : null,
                                CompanyCode: (jsonBody.Records[i].LineItems[j].SplitAccountings.GeneralLedger.CompanyCode != null && jsonBody.Records[i].LineItems[j].SplitAccountings.GeneralLedger.CompanyCode.UniqueName[0] != null) ? jsonBody.Records[i].LineItems[j].SplitAccountings.GeneralLedger.CompanyCode.UniqueName[0]: null,
                                AssignedDate: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].AssignedDate : null,
                                ActivationDate: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].ActivationDate : null,
                                OrderedDate: (jsonBody.Records[i].OrderedDate != null) ? jsonBody.Records[i].OrderedDate : '1970-01-01T00:00:00Z',
                                LastUpdated: message.properties.LastUpdated,
                                ReceivedDate: jsonBody.Records[i].ReceivedDate,
                                AreOrdersStuck: (jsonBody.Records[i].AreOrdersStuck != null) ? String.valueOf(jsonBody.Records[i].AreOrdersStuck) : null,
                                EscalationDate: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].EscalationDate : null,
                                AssignedTo: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].AssignedTo : null,
                                SubmitDate: jsonBody.Records[i].SubmitDate,
                                LastModified: (jsonBody.Records[i].LastModified != null) ? jsonBody.Records[i].LastModified : null,
                                RuleName: (jsonBody.Records[i].ApprovalRequests[k] != null) ? jsonBody.Records[i].ApprovalRequests[k].RuleName.trim() : null,
//                                ApprovalRequired: (jsonBody.Records[i].ApprovalRequests[k] != null) ? String.valueOf(jsonBody.Records[i].ApprovalRequests[k].ApprovalRequired) : null,
                                ApprovalRequired: String.valueOf(!autoApproved)
                        ]

                        def jsonBldr = new JsonBuilder(data).toString();
                        def jsonSlrpr = new groovy.json.JsonSlurper().parseText(jsonBldr);
//                        jsonLineItems.LineItems = jsonLineItems.LineItems << jsonSlrpr;
                        jsonSlrprApprovalRequest.LineItems << jsonSlrpr;
//                        jsonSlrprApprovalRequest << [LineItems: jsonSlrpr];
//                        jsonApprovalRequests.ApprovalRequests << [LineItems: jsonSlrpr];
                    }
//                    jsonApprovalRequests.ApprovalRequests.LineItems << jsonLineItems.LineItems;


                    jsonApprovalRequests.ApprovalRequests = jsonApprovalRequests.ApprovalRequests << jsonSlrprApprovalRequest;

                }

            }
        }
//        if (jsonLineItems.size() > 0) {
//            message.properties.LineItems = new JsonBuilder(jsonLineItems).toPrettyString();
//            message.properties.lineItemsSize = jsonLineItems.LineItems.size();
//            message.properties.lineItemIndex = 0;
//            message.properties.hasLineItems = 'X'
//        }
        if (jsonApprovalRequests.size() > 0) {
            message.properties.ApprovalRequests = new JsonBuilder(jsonApprovalRequests).toPrettyString()
            message.properties.ApprovalRequestsSize = jsonApprovalRequests.ApprovalRequests.size();
            message.properties.approvalRequestIndex = 0;
            message.properties.hasApprovalRequests = 'X'
        }
    }

    message.properties.allLineItemsProcessed = 'false';
    message.properties.allApprovalRequestsProcessed = 'false';

//    mpl.addAttachmentAsString('LineItems ', message.properties.LineItems, "text/plain");
    mpl.addAttachmentAsString('2 - ApprovalRequests ', message.properties.ApprovalRequests, "text/plain");
//    mpl.addAttachmentAsString('ApprovalRequests size' + String.valueOf(message.properties.ApprovalRequestsSize), '', "text/plain");

    return message;
}

def Message getApprovalRequest(Message message) {
    def mpl = messageLogFactory.getMessageLog(message)

    
    def jsonApprovalRequest = new groovy.json.JsonSlurper().parseText(message.properties.ApprovalRequests);
    // mpl.addAttachmentAsString('11111 ', message.properties.ApprovalRequests, "text/plain");

    def index = message.properties.approvalRequestIndex;



    def ruleData = [
            "RuleServiceId": "1619b968c99b4f95a0a8af29aab959b7",
//            "RuleServiceRevision": "Draft",
            "Vocabulary": [[
                                   PurchaseRequisitionApproval: [
                                        //   PRApprovalDate: (jsonApprovalRequest.ApprovalRequests[index].PRApprovalDate.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].PRApprovalDate : null,
                                        //   ApprovedDate: (jsonApprovalRequest.ApprovalRequests[index].ApprovedDate.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].ApprovedDate : null,
                                        //   AssignedDate: (jsonApprovalRequest.ApprovalRequests[index].AssignedDate.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].AssignedDate : null,
                                        //   RuleName: (jsonApprovalRequest.ApprovalRequests[index].RuleName.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].RuleName : null,
                                        //   LastUpdated: (jsonApprovalRequest.ApprovalRequests[index].LastUpdated.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].LastUpdated : null,
                                        //   ReceivedDate: (jsonApprovalRequest.ApprovalRequests[index].ReceivedDate.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].ReceivedDate : null,
                                        //   AreOrdersStuck: (jsonApprovalRequest.ApprovalRequests[index].AreOrdersStuck.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].AreOrdersStuck : null,
                                        //   StatusString: (jsonApprovalRequest.ApprovalRequests[index].StatusString.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].StatusString : null,
                                        //   OrderedDate: (jsonApprovalRequest.ApprovalRequests[index].OrderedDate.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].OrderedDate : null,
                                        //   ActivationDate: (jsonApprovalRequest.ApprovalRequests[index].ActivationDate.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].ActivationDate : null,
                                        //   ApprovalRequired: (jsonApprovalRequest.ApprovalRequests[index].ApprovalRequired.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].ApprovalRequired : null,
                                        //   ApprovedBy: "002",
                                        //   EscalationDate: (jsonApprovalRequest.ApprovalRequests[index].EscalationDate.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].EscalationDate : null,
                                        //   AssignedTo: (jsonApprovalRequest.ApprovalRequests[index].AssignedTo.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].AssignedTo : null,
                                        //   SubmitDate: (jsonApprovalRequest.ApprovalRequests[index].SubmitDate.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].SubmitDate : null,
                                        //   LastModified: (jsonApprovalRequest.ApprovalRequests[index].LastModified.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].LastModified : null,
                                        //   UniqueName: (jsonApprovalRequest.ApprovalRequests[index].UniqueName.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].UniqueName : null,
                                        //   TimeUpdated: (jsonApprovalRequest.ApprovalRequests[index].TimeUpdated.length() > 0) ? jsonApprovalRequest.ApprovalRequests[index].TimeUpdated : null
                                          PRApprovalDate: jsonApprovalRequest.ApprovalRequests[index].PRApprovalDate,
                                          ApprovedDate: jsonApprovalRequest.ApprovalRequests[index].ApprovedDate,
                                          AssignedDate: jsonApprovalRequest.ApprovalRequests[index].AssignedDate,
                                          RuleName: jsonApprovalRequest.ApprovalRequests[index].RuleName,
                                          LastUpdated: jsonApprovalRequest.ApprovalRequests[index].LastUpdated,
                                          ReceivedDate: jsonApprovalRequest.ApprovalRequests[index].ReceivedDate,
                                          AreOrdersStuck: jsonApprovalRequest.ApprovalRequests[index].AreOrdersStuck,
                                          StatusString: jsonApprovalRequest.ApprovalRequests[index].StatusString,
                                          OrderedDate: jsonApprovalRequest.ApprovalRequests[index].OrderedDate,
                                          ActivationDate: jsonApprovalRequest.ApprovalRequests[index].ActivationDate,
                                          ApprovalRequired: jsonApprovalRequest.ApprovalRequests[index].ApprovalRequired,
                                          ApprovedBy: "002",
                                          EscalationDate: jsonApprovalRequest.ApprovalRequests[index].EscalationDate,
                                          AssignedTo: jsonApprovalRequest.ApprovalRequests[index].AssignedTo,
                                          SubmitDate: jsonApprovalRequest.ApprovalRequests[index].SubmitDate,
                                          LastModified: jsonApprovalRequest.ApprovalRequests[index].LastModified,
                                          UniqueName: jsonApprovalRequest.ApprovalRequests[index].UniqueName,
                                          TimeUpdated: jsonApprovalRequest.ApprovalRequests[index].TimeUpdated
                                   ]
                           ]]
    ]

    def jsonRuleData = new JsonBuilder(ruleData).toPrettyString();
    message.setBody(jsonRuleData);
    message.properties.RuleInput = message.properties.RuleInput + jsonRuleData + ',\n';
    // mpl.addAttachmentAsString('RuleData - ' + String.valueOf(index), jsonRuleData, "text/plain");


    message.properties.currentApprovalRequest = new JsonBuilder(jsonApprovalRequest.ApprovalRequests[index]).toPrettyString();


    return message;
}

def Message checkRuleResponse(Message message) {
    def mpl = messageLogFactory.getMessageLog(message)
    String body = message.getBody(String);

    message.properties.RuleOutput = message.properties.RuleOutput + ',\n' + body;

    groovy.json.internal.LazyMap jsonEvents = new groovy.json.JsonSlurper().parseText(message.properties.jsonEvents);
    groovy.json.internal.LazyMap currentApprovalRequest = new groovy.json.JsonSlurper().parseText(message.properties.currentApprovalRequest);


    def jsonRuleResponse = new groovy.json.JsonSlurper().parseText(body);

    if (jsonRuleResponse.Result.Events != null && jsonRuleResponse.Result.Events.size() > 0) {

        for (int i = 0; i < jsonRuleResponse.Result[0].Events.size(); i++) {
            groovy.json.internal.LazyMap event =  new groovy.json.JsonSlurper().parseText( new JsonBuilder(jsonRuleResponse.Result[0].Events[i]).toPrettyString());
            for (int j = 0; j < currentApprovalRequest.LineItems.size(); j++) {
                jsonEvents = addNewEvent(jsonEvents, event, currentApprovalRequest.LineItems[j]);
            }
        }
//        groovy.json.internal.LazyMap event =  new groovy.json.JsonSlurper().parseText( new JsonBuilder(jsonRuleResponse.Result[0].Events[0]).toPrettyString());
//        jsonEvents = addNewEvent(jsonEvents, event, currentApprovalRequest.LineItems[0]);
        s1 = new JsonBuilder(jsonEvents).toPrettyString();
        message.properties.jsonEvents = s1;
    }


    message.properties.approvalRequestIndex = message.properties.approvalRequestIndex + 1;
    if (message.properties.approvalRequestIndex >= message.properties.ApprovalRequestsSize) {
        message.properties.allApprovalRequestsProcessed = 'true';
        mpl.addAttachmentAsString('3 - RuleInput', message.properties.RuleInput, "text/plain");
        mpl.addAttachmentAsString('4 - RuleOutput', message.properties.RuleOutput, "text/plain");
    }

    return message;
}


def Message allEvents(Message message) {
    def mpl = messageLogFactory.getMessageLog(message)
    mpl.addAttachmentAsString('5 - AllEvents', message.properties.jsonEvents, "text/plain");

    groovy.json.internal.LazyMap jsonEvents = new groovy.json.JsonSlurper().parseText(message.properties.jsonEvents);
    if (jsonEvents.Events.size() > 0) {
        message.properties.eventListSize = jsonEvents.Events.size();
        message.properties.eventIndex = 0;
        message.properties.hasEvents = 'X';
        message.properties.allEventsProcessed = 'false';
//        mpl.addAttachmentAsString('jsonEvents.Events.size() = ' + String.valueOf(message.properties.eventListSize), '', "text/plain");
    }

    return message;
}

def Message getEvent(Message message) {
    def mpl = messageLogFactory.getMessageLog(message)
    def jsonEvent = new groovy.json.JsonSlurper().parseText(message.properties.jsonEvents);

    String event = new JsonBuilder(jsonEvent.Events[message.properties.eventIndex]).toPrettyString();
    message.setBody(event);
//    mpl.addAttachmentAsString('event - ' + String.valueOf(message.properties.eventIndex), event as String, "text/plain");
    message.properties.eventIndex = message.properties.eventIndex + 1;

    if (message.properties.eventIndex >= message.properties.eventListSize) {
        message.properties.allEventsProcessed = 'true';
    }
    return message;
}

def groovy.json.internal.LazyMap addNewEvent(groovy.json.internal.LazyMap jsonEvents, groovy.json.internal.LazyMap ruleResponse, groovy.json.internal.LazyMap currentLineItem) {

    def date1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm").parse(ruleResponse.TimeStamp);
    sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    def data = [
            processDefinitionId: ruleResponse.ProcessDefinitionId,
            processInstanceId: ruleResponse.ProcessInstanceId + String.valueOf(currentLineItem.LineItemNumber),
            eventType: ruleResponse.EventName,
            timestamp: sdf.format(date1),
            context: [
                    CreateDate: currentLineItem.CreateDate,
                    ERPRequisitionID: currentLineItem.ERPRequisitionID,
                    AribaRequisitionId: currentLineItem.UniqueName,
                    PRID: currentLineItem.UniqueName,
                    Requestor: currentLineItem.Requestor,
                    TotalCost: currentLineItem.TotalCost,
                    MaterialCode: currentLineItem.MaterialCode,
                    MaterialDescription: currentLineItem.MaterialDescription,
                    AccountCategory: currentLineItem.AccountCategory,
                    DeliveryDate: currentLineItem.DeliveryDate,
                    Supplier: currentLineItem.Supplier,
                    SupplierId: currentLineItem.SupplierId,
                    StatusString: currentLineItem.StatusString,
                    Currency: currentLineItem.Currency,
                    Amount: currentLineItem.Amount,
                    UnitofMeasure: currentLineItem.UnitofMeasure,
                    PurchasingOrg: currentLineItem.PurchasingOrg,
                    CompanyCode: currentLineItem.CompanyCode,
                    AreOrdersStuck: currentLineItem.AreOrdersStuck,
                    ApprovalRequired: currentLineItem.ApprovalRequired
            ]
    ]
    def jsonBldr = new JsonBuilder(data).toString();
    def jsonSlrpr = new groovy.json.JsonSlurper().parseText(jsonBldr);
    jsonEvents.Events = jsonEvents.Events << jsonSlrpr;

    return jsonEvents;
}

def String getCurrentDateTime() {
//    def tzMSK = TimeZone. getTimeZone("Europe/Moscow")
    def currentDate = new Date()
    sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
//    sdf.setTimeZone(tzMSK)
    return sdf.format(currentDate)
}

def String getCurrentDateTime0() {
//    def tzMSK = TimeZone. getTimeZone("Europe/Moscow")
    def currentDate = new Date()
    sdf = new SimpleDateFormat("yyyy-MM-dd 00:00:00")
//    sdf.setTimeZone(tzMSK)
    return sdf.format(currentDate)
}