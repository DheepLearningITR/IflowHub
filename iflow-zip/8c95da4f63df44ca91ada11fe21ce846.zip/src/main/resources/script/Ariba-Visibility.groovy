import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import groovy.util.XmlSlurper;
import groovy.xml.XmlUtil;
import groovy.json.*;
import groovy.json.JsonSlurper;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message getToken(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    message.properties.AllEvents = "<?xml version='1.0' encoding='UTF-8'?><AllEvents/>";
    def body = message.getBody(java.lang.String);
    def json = new groovy.json.JsonSlurper().parseText(body);
    message.setHeader("Authorization","Bearer " + json.access_token);
    message.properties.rulesPayload = '';

    return message;
}

def Message removeInvalidCharacters(Message message) {
    String body = message.getBody(java.lang.String);
    body = body.replaceAll("\\\\u0002", " ");
    message.setBody(body);
    return message;
}

def Message saveLineItems(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String body = message.getBody(String);
    message.properties.lineItems = body;

    String lastUpdated = message.properties.LastUpdated;
    if (lastUpdated == null || lastUpdated == '') {
        message.properties.LastUpdated = '2020-06-11T14:47:49Z';
    }
    return message;
}

def Message saveLineItemsEvents(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String body = message.getBody(String);
    
    mpl.addAttachmentAsString('5 - LineItems Events', body, "text/plain");
    return message;
}

def Message saveLineItem(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String body = message.getBody(String);
    message.properties.lineItemCurrent = body;
    return message;
}

def Message setEmptyValues(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String body = message.getBody(String);
    String newBody = body.replaceAll(':"",', ':null,').replaceAll(':""}', ':null}').replaceAll(': ""', ': null');
    message.setBody(newBody);
    return message;
}

def Message checkBodySize(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String body = message.properties.jsonBody as String;

    int visibilitySizeLimitBytes = Integer.valueOf(message.properties.VisibilityPayloadSizeLimit)*1024;

    int generalListSizeBytes = body.getBytes().length;
    
    if (visibilitySizeLimitBytes >= generalListSizeBytes) {
        message.properties.generalEventListEmpty = '-';
        message.setBody(body);
    } else {
        def jsonGeneral = new groovy.json.JsonSlurper().parseText(body);
        def jsonGeneralNew = new groovy.json.JsonSlurper().parseText('{"Event": []}');
        def jsonVisibility = new groovy.json.JsonSlurper().parseText('{"Event": []}');
        
        boolean isLimitExceeded = false;
        String generalElement = '';
        String jsonjsonVisibilityAll = '';
        
        for (int i = 0; i < jsonGeneral.Event.size(); i++) {
            generalElement = new JsonBuilder(jsonGeneral.Event[i]).toPrettyString();
            jsonjsonVisibilityAll = new JsonBuilder(jsonVisibility).toPrettyString();
            
            int jsonNewSize = jsonjsonVisibilityAll.getBytes().length + generalElement.getBytes().length;
            if (!isLimitExceeded || jsonNewSize < visibilitySizeLimitBytes) {
                isLimitExceeded = true;

                jsonVisibility.Event = jsonVisibility.Event << jsonGeneral.Event[i];
            } else {
                jsonGeneralNew.Event = jsonGeneralNew.Event << jsonGeneral.Event[i];
            }
        }
        message.setBody(new JsonBuilder(jsonVisibility).toPrettyString());
        message.properties.jsonBody = new JsonBuilder(jsonGeneralNew).toPrettyString();
        message.properties.generalEventListEmpty = 'X';
    }
    message.properties.index = message.properties.index + 1;
    return message;
}

def Message prepareBody(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String body = message.getBody(String);
    String newBody = body.replaceAll(':"",', ':null,').replaceAll(':""}', ':null}').replaceAll(': ""', ': null');
    def json = new groovy.json.JsonSlurper().parseText(newBody);
    String event = new JsonBuilder(json.Event).toPrettyString();
    message.setBody(event);
    return message;
}

def Message checkEvent(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String resultStr = "<?xml version='1.0' encoding='UTF-8'?><AllEvents/>"
    String body = message.getBody(String);
    def eventsXML = new XmlSlurper().parseText(resultStr);
    def ruleResponseXML = new XmlSlurper().parseText(body);
    def approvalRequestXML = new XmlSlurper().parseText(message.properties.lineItems);

    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);

    String prId = ''
    sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    String ruleName = approvalRequestXML.RuleName;
    String currentApprover = approvalRequestXML.Approver as String;
    String approvalRequestFlag = approvalRequestXML.Flag as String;
    String eventNodes = '';
    String nodeName = '';

    ruleResponseXML.Events.each {Events ->
        def eventNode = Events;
        prId = Events.ProcessInstanceId as String;
        approvalRequestXML.LineItems.each { LineItems ->
            eventsXML.appendNode{
                Event {
                    processDefinitionId(Events.ProcessDefinitionId as String);
                    processInstanceId(prId + LineItems.LineItemNumber as String);
                    eventType(Events.EventName as String);
                    timestamp(sdf.format(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(Events.TimeStamp as String)));
                    context {
                        if (approvalRequestFlag == 'RequestHeader') {
                            CreateDate(LineItems.CreateDate as String);
                            if (LineItems.PRApprovalDate != null && LineItems.PRApprovalDate != '') {
                                ApprovedDate(sdf.format(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(LineItems.PRApprovalDate as String)));
                            }
                            if (LineItems.OrderedDate != null && LineItems.OrderedDate != '') {
                                if (LineItems.OrderedDate != '1970-01-01T00:00:00Z') {
                                    OrderedDate(sdf.format(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(LineItems.OrderedDate as String)));    
                                } else {
                                    OrderedDate('');
                                }
                            }
                            OrderID(LineItems.OrderID as String);
                            PRID(LineItems.UniqueName as String);
                            ERPRequisitionID(LineItems.ERPRequisitionID as String);
                            AribaRequisitionId(LineItems.UniqueName as String);
                            Requestor(LineItems.Requestor as String);
                            PurchasingOrg(LineItems.PurchasingOrg as String);
                        }
                        TotalCost(LineItems.TotalCost as String);
                        MaterialCode(LineItems.MaterialCode as String);
                        MaterialDescription(LineItems.MaterialDescription as String);
                        AccountCategory(LineItems.AccountCategory as String);
                        DeliveryDate(LineItems.DeliveryDate as String);
                        Supplier(LineItems.Supplier as String);
                        SupplierId(LineItems.SupplierId as String);
                        StatusString(LineItems.StatusString as String);
                        Quantity(LineItems.Quantity as String);
                        ItemCurrency(LineItems.ItemCurrency as String);
                        Amount(LineItems.Amount as String);
                        UnitofMeasure(LineItems.UnitofMeasure as String);
                        AreOrdersStuck(LineItems.AreOrdersStuck as String);
                        ApprovalRequired(LineItems.ApprovalRequired as String);
                        CompanyCode(LineItems.CompanyCode as String);
                        Approver(currentApprover);
                        if (valueMapApi != null) {
                            Region(valueMapApi.getMappedValue('Ariba', 'CompanyCode', LineItems.CompanyCode as String, 'Visibility', 'Region'));
                            
                        }
                        eventNode.children().each { node -> 
                            def nodeElement = node;
                            nodeName =  nodeElement.name();
                            if (nodeName != 'ProcessDefinitionId' && nodeName != 'ProcessInstanceId' && nodeName != 'EventName' && nodeName != 'TimeStamp') {
                                "$nodeName"(nodeElement.text());
                            }
                        }
                        eventNodes = '';
                    }
                }
            }
        }
    }
    message.properties.AllEvents += '\n' + XmlUtil.serialize(eventsXML);
    message.setBody(XmlUtil.serialize(eventsXML));
    
    return message;
}

def Message checkLineItemEvent(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String resultStr = "<?xml version='1.0' encoding='UTF-8'?><AllEvents/>"
    String body = message.getBody(String);
    def eventsXML = new XmlSlurper().parseText(resultStr);
    def ruleResponseXML = new XmlSlurper().parseText(body);
    def lineItemXML = new XmlSlurper().parseText(message.properties.lineItemCurrent);
    
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);

    String prId = ''
    sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    String ruleName = lineItemXML.RuleName;
    String currentApprover = "";
    String eventNodes = '';
    String nodeName = '';

    ruleResponseXML.Events.each {Events ->
        def eventNode = Events;
        prId = Events.ProcessInstanceId as String;
        lineItemXML.each { LineItems ->
            currentApprover = LineItems.Approver as String;
            eventsXML.appendNode{
                Event {
                    processDefinitionId(Events.ProcessDefinitionId as String);
                    processInstanceId(prId + LineItems.LineItemNumber as String);
                    eventType(Events.EventName as String);
                    timestamp(sdf.format(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(Events.TimeStamp as String)));
                    context {
                        Requestor(LineItems.Requestor as String);
                        TotalCost(LineItems.TotalCost as String);
                        MaterialCode(LineItems.MaterialCode as String);
                        MaterialDescription(LineItems.MaterialDescription as String);
                        AccountCategory(LineItems.AccountCategory as String);
                        DeliveryDate(LineItems.DeliveryDate as String);
                        Supplier(LineItems.Supplier as String);
                        SupplierId(LineItems.SupplierId as String);
                        StatusString(LineItems.StatusString as String);
                        Quantity(LineItems.Quantity as String);
                        ItemCurrency(LineItems.ItemCurrency as String);
                        Amount(LineItems.Amount as String);
                        UnitofMeasure(LineItems.UnitofMeasure as String);
                        AreOrdersStuck(LineItems.AreOrdersStuck as String);
                        ApprovalRequired(LineItems.ApprovalRequired as String);
                        CompanyCode(LineItems.CompanyCode as String);
                        Approver(currentApprover);
                        if (valueMapApi != null) {
                            Region(valueMapApi.getMappedValue('Ariba', 'CompanyCode', LineItems.CompanyCode as String, 'Visibility', 'Region'));
                        }
                        eventNode.children().each { node -> 
                            def nodeElement = node;
                            nodeName =  nodeElement.name();
                            if (nodeName != 'ProcessDefinitionId' && nodeName != 'ProcessInstanceId' && nodeName != 'EventName' && nodeName != 'TimeStamp') {
                                "$nodeName"(nodeElement.text());
                            }
                        }
                        eventNodes = '';
                    }
                }
            }
        }
    }
    message.properties.AllEvents += '\n' + XmlUtil.serialize(eventsXML)
    message.setBody(XmlUtil.serialize(eventsXML));
    return message;
}


def Message saveXslt(Message message) {
    def mpl = messageLogFactory.getMessageLog(message)
    String body = message.getBody(String);
    message.properties.ApprovalRequests = body;
    mpl.addAttachmentAsString('2 - Approval Requests', body, "text/plain");
    return message;
}

def Message saveAllEvents(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String body = message.getBody(String);

    def ruleResponseXML = new XmlSlurper().parseText(body);
    if (ruleResponseXML.Event.size() > 0) {
        message.properties.sendEvents = 'X';
    }
    message.properties.index = 0;
    mpl.addAttachmentAsString('3 - Rules Response Payload (Approval Requests)', body,"text/plain");
    return message;
}

def Message saveAllLineItemsEvents(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String body = message.getBody(String);
    def ruleResponseXML = new XmlSlurper().parseText(body);
    if (ruleResponseXML.Event.size() > 0) {
        message.properties.sendLineItemsEvents = 'X';
    }
    mpl.addAttachmentAsString('4 - Rules Response Payload (Line Items)', body,"text/plain");
    return message;
}

def Message saveAribaPayload(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String body = message.getBody(String);
    mpl.addAttachmentAsString('1 - Ariba payload', body,"text/plain");
    return message;
}


