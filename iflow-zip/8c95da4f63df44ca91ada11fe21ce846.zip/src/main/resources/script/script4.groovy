import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    def mpl = messageLogFactory.getMessageLog(message)
    String body = message.getBody(String);
    
    
    // def resp = new XmlSlurper().parseText(body);
    
    message.properties.lineItems = body
    
       mpl.addAttachmentAsString('lineItems ', message.properties.lineItems, "text/plain");
       return message;
}