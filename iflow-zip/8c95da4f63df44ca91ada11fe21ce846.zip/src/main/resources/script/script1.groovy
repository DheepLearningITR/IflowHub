
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {

    def body = message.getBody(java.lang.String);
    def json = new groovy.json.JsonSlurper().parseText(body);
    message.setHeader("Authorization","Bearer " + json.access_token);
//    def tokens = body.tokenize('\"');
//    message.setHeader("Authorization","Bearer "+tokens[5] );
    return message;
}