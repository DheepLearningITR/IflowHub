import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.DecimalFormat;

def Message processData(Message message) {
    def body = "<fields>";
    def props = message.getProperties();
    def showEligibility = props.get("ShowEligibility");
    if (showEligibility != "Do not show") {
        def index = props.get("Index").toInteger();
        def creditName = props.get("CreditName");
        def eligibility = props.get("Eligibility") == 'eligible' ? 'Eligible' : 'Ineligible';
        body += "<field" + index + "Key>" + creditName + " eligibility</field" + index + "Key>";
        body += "<field" + index + "Value>" + eligibility + "</field" + index + "Value>";
        index++;
        if (showEligibility == "Show Eligibility and Potential Tax Credit" && eligibility == "Eligible") {
            def amountStr = props.get("Amount");
            def formatter = DecimalFormat.getInstance();
            formatter.setDecimalSeparatorAlwaysShown(true);
            formatter.setMinimumFractionDigits(2);
            formatter.setMaximumFractionDigits(2);
            def amount = formatter.format(Double.parseDouble(amountStr));
            def currency = props.get("Currency");
            body += "<field" + index + "Key>Potential " + creditName + " Credit Amount</field" + index + "Key>";
            body += "<field" + index + "Value>" + currency + " " + amount + "</field" + index + "Value>";
            index++;
        }
        message.setProperty("Index", index);
    }
    body += "</fields>";
    message.setBody(body);
    return message;
}