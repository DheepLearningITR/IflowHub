import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def props = message.getProperties();
    def optout = props.get("Optout");
    if (optout == "true") {
        def fields = props.get("Fields");
        def index = props.get("Index").toInteger();
        fields += "<field" + index + "Key>Opted Out</field" + index + "Key>";
        fields += "<field" + index + "Value>Yes</field" + index + "Value>";
        message.setProperty("Fields", fields);
    }
    return message;
}