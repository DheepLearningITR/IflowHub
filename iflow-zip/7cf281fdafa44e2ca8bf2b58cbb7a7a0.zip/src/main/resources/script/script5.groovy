import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def map = message.getProperties();
    def showEligibility = map.get("ShowEligibility");
    def days = map.get("NumberOfDaysBetweenAssessments");
    def address = map.get("SuccessFactors Address");
    def credential = map.get("SuccessFactors Credentials");
    def validConfig = "yes";
    if (showEligibility != "" && showEligibility != null && !"Show Eligibility".equalsIgnoreCase(showEligibility) && !"Show Eligibility and Potential Tax Credit".equalsIgnoreCase(showEligibility) && !"Do not show".equalsIgnoreCase(showEligibility)) {
        validConfig = "no";
        message.setProperty("errorCode", "INVALID_CLOUD_PLATFORM_INTEGRATION_CONFIGURATION");
        logMessage(message, "Invalid configuration. Value of parameter 'Display Eligibility' is '" + showEligibility + "'. Acceptable values are 'Show Eligibility', 'Show Eligibility and Potential Tax Credit', 'Do not show' and blank.");
    }
    if (days == null || !days.isInteger() || days.toInteger() < 0) {
        validConfig = "no";
        message.setProperty("errorCode", "INVALID_CLOUD_PLATFORM_INTEGRATION_CONFIGURATION");
        logMessage(message, "Invalid configuration. Value of parameter 'Number of Days Between Assessments' must be an non-negative integer.");
    }
    if (address == null || address == "") {
        validConfig = "no";
        message.setProperty("errorCode", "INVALID_CLOUD_PLATFORM_INTEGRATION_CONFIGURATION");
        logMessage(message, "Invalid configuration. Value of parameter 'Success Factors Address' cannot be blank.");
    }
    if (credential == null || credential == "") {
        validConfig = "no";
        message.setProperty("errorCode", "INVALID_CLOUD_PLATFORM_INTEGRATION_CONFIGURATION");
        logMessage(message, "Invalid configuration. Value of parameter 'Success Factors Credential Name' cannot be blank.");
    }
    message.setProperty("validConfig", validConfig);
    return message;
}

def void logMessage(Message message, String text) {
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        messageLog.addAttachmentAsString("Error Message", text, "text/plain")
    }
}