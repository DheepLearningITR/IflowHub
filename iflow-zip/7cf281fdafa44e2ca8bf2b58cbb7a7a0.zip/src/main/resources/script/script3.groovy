import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
def Message processData(Message message) {
    def SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZZZZ");
    def SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    def props = message.getProperties();
    // Date from ADP doesn't have time component, and is in EST timezone
    def dt = inputFormat.parse(props.get("ScreeningSubjectAcknowledgementDate") + "T12:00:00-0400");
    message.setProperty("ScreeningSubjectAcknowledgementDate", outputFormat.format(dt));
    return message;
}