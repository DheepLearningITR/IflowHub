
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
   map = message.getProperties();
   def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    def ratePlanIds = jsonObject.ratePlan[0].id;

    def selector = " ";
    String param = "externalObjectReference.externalId eq ";
    for(int i=0; i<ratePlanIds.size(); i++){
        def ratePlanId = ratePlanIds[i]
        selector = selector + param + "'"+ratePlanId+"'";
        
        if(i<ratePlanIds.size()-1){
            selector = selector + " or";
        }
    }
    map.put("Selector",selector)
    message.setProperties(map);
       return message;
}