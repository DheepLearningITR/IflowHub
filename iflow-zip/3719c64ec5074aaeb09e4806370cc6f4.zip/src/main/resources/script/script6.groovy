/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.lang.String;
def Message processData(Message message) {
     def sbBody = message.getBody(String.class);
    def jsonParser = new JsonSlurper();
    def sbRatePlan = jsonParser.parseText(sbBody);
    def sbRatePlans = sbRatePlan.rateplan;
 
    def map = message.getProperties();
     def createdAt = map.CreatedDate;

    sbRatePlans['snapshots'].sort{ a, b -> b.effectiveAt <=> a.effectiveAt}
     def sbRatePlansJson = JsonOutput.toJson(sbRatePlans);
     
     def sbRatePlanSnapshots = jsonParser.parseText(sbRatePlansJson);
     def sbSnapshots = sbRatePlanSnapshots.snapshots; 
     def endDate;
     def baseDate;
     
       for(def sbSnapshot : sbSnapshots){
           if(sbSnapshot.effectiveAt == null){
               Calendar c = Calendar.getInstance();
               String dateFormat = "yyyy-MM-dd";
               c.setTime(new SimpleDateFormat(dateFormat).parse(createdAt));
               DateFormat dateFormat_required = new SimpleDateFormat(dateFormat);
               def converted_datetime=dateFormat_required.format(c.getTime());
               sbSnapshot.put("effectiveAt", converted_datetime); 
               baseDate = createdAt;
           }
           
               if(endDate == null)
               {
                   if(baseDate == null)
                     baseDate = sbSnapshot.effectiveAt;
                   Calendar c = Calendar.getInstance();
                   String dateFormat = "yyyy-MM-dd";
                   c.setTime(new SimpleDateFormat(dateFormat).parse(baseDate));
                   c.add(Calendar.YEAR, 1);
                   DateFormat dateFormat_required = new SimpleDateFormat(dateFormat);
                   def converted_datetime=dateFormat_required.format(c.getTime());
                   sbSnapshot.put("endDate", converted_datetime); 
               }
              else{
                  sbSnapshot.put("endDate", endDate); 
               }
                endDate = sbSnapshot.effectiveAt;
           
       }
       
       sbRatePlanSnapshots.put("snapshots",sbSnapshots);
       def sbFinalRatePlansJson = JsonOutput.toJson(sbRatePlanSnapshots);
       message.setBody(sbFinalRatePlansJson);
       return message;
    
}