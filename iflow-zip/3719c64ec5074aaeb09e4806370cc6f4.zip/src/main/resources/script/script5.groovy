/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.lang.String;


def Message processData(Message message) {
    
     def sbFinalBody = message.getBody(String.class);
     def map = message.getProperties();
     def sbBody = map.SBRatePlanPayload;
    
     def productCode = map.ProductCode;
     def unitOfMeasure = map.Unit;
     def jsonParser = new JsonSlurper();
     def sbRatePlanBody = jsonParser.parseText(sbFinalBody);
     def sbRatePlans = sbRatePlanBody.sbFinalRatePlan.responses;
     


    def sbRateplanMk = jsonParser.parseText(sbBody);
    def sbRatePlansMk = sbRateplanMk.sbRatePlan;
     for(def sbRatePlanMkId :sbRatePlansMk){
      for(def sbFinalRateplans:sbRatePlans){
          if( sbRatePlanMkId.id == sbFinalRateplans.id ){
              sbFinalRateplans.body.put("marketId", sbRatePlanMkId.marketId);
               sbFinalRateplans.body.put("productCode",productCode);
               sbFinalRateplans.body.put("unitOfMeasure",unitOfMeasure);
               sbFinalRateplans.body.put("createdAt",sbRatePlanMkId.createdAt);
              
            }
        }
    }
    def sbPayload = JsonOutput.toJson(sbRatePlanBody);
    
    
      
    sbRatePlanBody = jsonParser.parseText(sbPayload);
    sbRatePlans = sbRatePlanBody.sbFinalRatePlan.responses;
    
    for(def sbRatePlan:sbRatePlans){
        def snapBody =  sbRatePlan.body;
    snapBody['snapshots'].sort{ a, b -> b.effectiveAt <=> a.effectiveAt}
    def sbSnapshots = snapBody.snapshots; 

     def endDate;
     def baseDate;
     
      for(def sbSnapshot : sbSnapshots){
          if(sbSnapshot.effectiveAt == null){
           String result = ZonedDateTime.parse(sbRatePlan.body.createdAt)
                              .truncatedTo(ChronoUnit.DAYS)
                                 .format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
            
             sbSnapshot.put("effectiveAt",result ); 
              baseDate = result;
          }
           
              if(endDate == null)
              {
                 if(baseDate == null)
                     baseDate = sbSnapshot.effectiveAt;
                 
                  Calendar c = Calendar.getInstance();
                  String dateFormat = "yyyy-MM-dd";
                  c.setTime(new SimpleDateFormat(dateFormat).parse(baseDate));
                  c.add(Calendar.YEAR, 1);
                  DateFormat dateFormat_required = new SimpleDateFormat(dateFormat);
                  def converted_datetime=dateFormat_required.format(c.getTime());
                  
                  
                  def currentDate = new Date( ).format( 'yyyy-MM-dd' ); 
                  if (converted_datetime <= currentDate){
                  c.setTime(new SimpleDateFormat(dateFormat).parse(currentDate));
                  c.add(Calendar.YEAR, 1);
                  dateFormat_required = new SimpleDateFormat(dateFormat);
                  converted_datetime=dateFormat_required.format(c.getTime());
                  }
                  
                  sbSnapshot.put("endDate", converted_datetime); 
              }
              else{
                  sbSnapshot.put("endDate", endDate); 
              }
                endDate = sbSnapshot.effectiveAt;
           
      }
      sbRatePlan.put("snapshots",sbSnapshots);
     
     
  }
  
  
   def sbFinalRatePlansJson = JsonOutput.toJson(sbRatePlanBody);
       message.setBody(sbFinalRatePlansJson);
   
    
   return message;
}