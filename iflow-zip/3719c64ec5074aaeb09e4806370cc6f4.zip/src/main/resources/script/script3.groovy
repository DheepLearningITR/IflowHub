import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
   def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    def ratePlanIds = jsonObject.id;

  String ratePlanBody = "{"+'"'+"requests"+'"'+":"+"[";
    for(int i=0; i<ratePlanIds.size(); i++){
          def ratePlanId = ratePlanIds[i]
         ratePlanBody = ratePlanBody + "{"+'"' + "id" + '"' +":" ;
        ratePlanBody =  ratePlanBody + '"'+ ratePlanId+'"'+",";
        ratePlanBody += '"' + "method" + '"' +":" + '"' + "GET" + '"'+",";
        ratePlanBody = ratePlanBody + '"' + "url" + '"' +":" ;
        ratePlanBody =  ratePlanBody + '"'+ ratePlanId+'"';
        ratePlanBody += "}";
        if(i<ratePlanIds.size()-1){
            ratePlanBody += ",";
        }
    }
    ratePlanBody +="]"+"}";
  message.setBody(ratePlanBody);
       return message;
}