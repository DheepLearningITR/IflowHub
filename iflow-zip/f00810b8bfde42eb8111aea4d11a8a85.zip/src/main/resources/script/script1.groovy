
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

/********************************************/
/***  Read SAP CPQ Credentials from SCPI  ***/
/********************************************/
    
def Message processData(Message message) {
  
     def messageLog = messageLogFactory.getMessageLog(message);
     messageLog.setStringProperty("Info1", "ReadLoginCredentials Script Called...!");

    def properties = message.getProperties() as Map<String, Object>;
	def credName = properties.get("credentialName");
	
	 if (credName == null){
       throw new IllegalStateException("No credential found for alias " + credName);
    }
	
	def service = ITApiFactory.getApi(SecureStoreService.class, null);
	def credential = service.getUserCredential(credName);
	
    if (credential == null){
       throw new IllegalStateException("No credential found for alias " + credName);
    }
    
    messageLog.setStringProperty("Info2", "SAP CPQ Credentials Retrieved from SCPI!");
    
    String userName = credential.getUsername();
    String password = new String(credential.getPassword());
   
    message.setProperty("username", userName);
    message.setProperty("password", password);
  
   return message;
  
}