import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import java.util.*;
import java.text.SimpleDateFormat;

def Message processData(Message message) {

    def body = message.getBody(String.class);
    def params = [
       "username" : message.getProperties().get('username'),
       "password" : message.getProperties().get('password'),
       "domainName" : message.getProperties().get('domainName'),
       "externalQuoteId" : message.getProperties().get('externalQuoteId'),
       "feedback" : message.getProperties().get('feedback'),
    ];
    def result = map(body,params);
    message.setBody(result);
    return message;
}


def String map(String message, def params) {
    def sourceMessage = new XmlParser().parseText(message);
    def targetMessage = new XmlParser().parseText(getPerformCartActionTemplate());
    def ns = new groovy.xml.Namespace("http://webcominc.com/")

    targetMessage[ns.username][0].value = params.username +"#"+ params.domainName;
    targetMessage[ns.password][0].value = params.password;
    targetMessage[ns.compositeCartId][0].value =  params.externalQuoteId;
     
    targetMessage[ns.xDoc][0].ACTION[0].NAME[0].value = "Accept Proposal";
    
    def result = XmlUtil.serialize(targetMessage);
    return result;
}

///----------------------------------------------------------------------------------
/// XML Templates


def getPerformCartActionTemplate() {
    return '''
    <web:performCartAction xmlns:web="http://webcominc.com/">
        <web:username></web:username>
        <web:password></web:password>
        <web:compositeCartId></web:compositeCartId>
        <web:xDoc>
            <ACTION>
	        	<NAME></NAME>
		    </ACTION>
        </web:xDoc>
    </web:performCartAction>
    '''.stripMargin();
}



 