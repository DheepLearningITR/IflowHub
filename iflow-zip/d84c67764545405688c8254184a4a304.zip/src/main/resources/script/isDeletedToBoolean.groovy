import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def isDeletedToBoolean(Message message) {
    
    def body = message.getBody(String)
    def messageJson = new JsonSlurper().parseText(body)
    def shipmentMaterials = messageJson.data.salesOrder.shipmentMaterials

    for (shipmentMaterial in shipmentMaterials) {

        def isDeleted = shipmentMaterial.isDeleted
        
        if(isDeleted.equals("true")) {
            shipmentMaterial.isDeleted = "X"
        } else if (isDeleted.equals("false")) {
            shipmentMaterial.isDeleted = ""
        }

    }

    def messageBodyJson = JsonOutput.toJson(messageJson)
    message.setBody(messageBodyJson)

    return message

}