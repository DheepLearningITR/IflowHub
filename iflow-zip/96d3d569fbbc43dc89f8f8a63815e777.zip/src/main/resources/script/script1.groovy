/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-IN/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-IN/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {

    def originalBodyString = message.getBody(java.io.Reader);
    def rootJson = new JsonSlurper().parse(originalBodyString)
    def queryString
    String sapClient = message.getProperty("sapClient")
    message.setHeader("SAP_ApplicationID", rootJson.messageHeader.id)
    
    def S4QuotationId = rootJson.messageRequests[0].body.receiverDisplayId
    message.setProperty("S4QuotationId",S4QuotationId)
    
    if("ACCEPTED".equals(rootJson.messageRequests[0].body.acceptanceStatus)){
        
        queryString = "ServiceQuotation=\'" + S4QuotationId + "\'&sap-client=$sapClient"
        message.setProperty("customQuery",queryString)
        message.setProperty("httpMethod","POST")
        message.setBody(null)
    }else{
        queryString = "?sap-client=$sapClient"
        message.setProperty("httpMethod","PATCH")
        message.setProperty("query", queryString)
        
        Node outputBody = new NodeBuilder().A_ServiceQuotation{
            A_ServiceQuotationType{
                ServiceQuotationIsRejected("X")
                SrvcQuotationRejectionReason(rootJson.messageRequests[0].body.rejectionReason)
            }
        }
        message.setBody(groovy.xml.XmlUtil.serialize(outputBody))
    }

    return message;
}