import com.sap.gateway.ip.core.customdev.util.Message
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.NodeList

Message processData(Message message) {
    // Get the body as InputStream and parse it
    def body = message.getBody(java.io.InputStream)
    def builderFactory = DocumentBuilderFactory.newInstance()
    def builder = builderFactory.newDocumentBuilder()
    def document = builder.parse(body)
    
    // Normalize XML structure
    document.getDocumentElement().normalize()

    // Get the <Query> node
    def queryNode = document.getElementsByTagName("Query").item(0)

    // Read attributes
    def select = queryNode.getAttribute("select")
    def top = queryNode.getAttribute("top")
    def refIDs = queryNode.getAttribute("refIDs")

    // Read all <Condition> nodes inside <Query>
    NodeList conditionNodes = queryNode.getElementsByTagName("Condition")
    def conditions = []

    for (int i = 0; i < conditionNodes.getLength(); i++) {
        def condition = conditionNodes.item(i)
        def column = condition.getAttribute("column")
        def value = condition.getTextContent()

        // Check if value is numeric; otherwise quote it
        if (value.isNumber()) {
            conditions.add("${column} eq ${value}")
        } else {
            conditions.add("${column} eq '${value}'")
        }
    }

    // Join all conditions with 'and'
    def filterPart = conditions.join(' and ')

    // Build only the OData query parameters, without table name
    def queryString = "\$filter=${filterPart}&\$select=${select}&\$top=${top}"

    // Set the query string as a property
    message.setProperty("QRY_Query", queryString)

    return message
}
