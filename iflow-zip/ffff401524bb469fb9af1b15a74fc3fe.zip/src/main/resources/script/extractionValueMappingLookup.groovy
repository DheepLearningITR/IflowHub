// This script is a extended extractionValueMapping.groovy script
// =============================================================================================
// History:
// 2024-05-24 SAP [GS] - Enable mapping in both direction by distinction, if the mapping should 
//											 be in extraction step or assembly step.
// =============================================================================================

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message) {   
	def headers                = message.getHeaders();
	def properties             = message.getProperties();
	def valueMapApi            = ITApiFactory.getApi(ValueMappingApi.class, null);    
	def evmName                = properties.get("SAP_B2B_EVM_Name");
	def sourceParameters       = properties.get("SAP_B2B_EVM_SourceParameters");
	def sourceExtAssParams     = [];
	def sourceParamSet         = [];
	def sourceInArray          = [];
	def sourceInCombinations   = []; 
	def conditions             = properties.get("SAP_B2B_EVM_Conditions");
	def conditionKeys          = "";
	def conditionsArray        = [];
	def conditionCombinations  = []; 
	def targetParameters       = properties.get("SAP_B2B_EVM_TargetParameters");
	def targetExtAssParams     = [];
	def targetParamSet         = [];
	def targetType             = "";
	def matchingArray		       = [];
    
	if (evmName != null && sourceParameters != null && targetParameters != null) {
		evmName = evmName.trim();
		
		// Selection of one or more source values from one or more source parameters.
		if (sourceParameters != null) {
			// Check, if the evmName has "Assembly" or "Extraction" and returns the corresponding set of source parameters
			if (evmName.contains("#Extraction")) {
				sourceExtAssParams =  sourceParameters.tokenize('#') as String[];
				sourceParamSet =  sourceExtAssParams[0].tokenize(',') as String[];
				for(i=0; i < sourceParamSet.size(); i++) {
			    try {
				    sourceInArray[i] = [headers.get(sourceParamSet[i]).trim(), '*'];
			    } catch (Exception e) {
			        break;
			    }
				}
			} else if (evmName.contains("#Assembly")) {
				sourceExtAssParams =  sourceParameters.tokenize('#') as String[];
				sourceParamSet =  sourceExtAssParams[1].tokenize(',') as String[];
				for(i=0; i < sourceParamSet.size(); i++) {
			    try {
				    sourceInArray[i] = [properties.get(sourceParamSet[i]).trim(), '*'];
			    } catch (Exception e) {
			        break;
			    }
				}				
			} else {
				sourceParamSet =  sourceParameters.tokenize(',') as String[];
				for(i=0; i < sourceParamSet.size(); i++) {
			    try {
				    sourceInArray[i] = [headers.get(sourceParamSet[i]).trim(), '*'];
			    } catch (Exception e) {
			        break;
			    }
				}
			}
			// Create array with all possible combinations with wildcards
			sourceInCombinations = GroovyCollections.combinations(sourceInArray);
			message.setProperty("SAP_B2B_EVM_SourceCombinations",sourceInCombinations);
		} else {
			throw new IllegalStateException("Mandatory source exchange header parameters not provided.");
		}

		// Checking of condition keys. Condition keys could be one or more key values pairs in where the key
		// represents a defined camel exchange header parameter.
		if (conditions != null) {
			// Check, if the conditions has "Assembly" or "Extraction". If yes, just set the <name>#Extraction or <name>#Assembly as condition.
			if (conditions.contains("#Assembly") || conditions.contains("#Extraction")) {
    		conditionCombinations.add(conditions);
    		targetType = conditions.substring(conditions.indexOf('#') + 1);
			} else if (conditions.contains(":")) {
				def conditionSet =  conditions.tokenize(',') as String[];
				for(i=0; i < conditionSet.size(); i++)  {
					String[] conditionPair = conditionSet[i].split(":");
					def conditionParam = conditionPair[0].trim();
					conditionsArray[i] = [conditionParam + ':' + headers.get(conditionParam).trim(), conditionParam + ':*'];
				}
				// Create array with all possible combinations with wildcards
				conditionCombinations = GroovyCollections.combinations(conditionsArray);
			} else {
				conditionCombinations.add(conditions);
			}
		} else {
			// Set condition keys to NA = Not Applicable, if the key parameter is not set.
			conditionCombinations.add('NA');
		}
		// message.setProperty("SAP_B2B_EVM_ConditionCombinations",conditionCombinations);
		
		// Get the set of target camel exchange header parameters in where the 
		// target values should be written.
		if (targetParameters != null){
			targetParameters = targetParameters.trim();
		} else {
			throw new IllegalStateException("Mandatory target exchange header parameters not provided.");
		}

		// Check all kind of combinations value/wild card at each parameter, 
		// if there is an entry in the extraction value mapping is available:

		for (i=0; i < conditionCombinations.size(); i++) {
			// If conditions is not an array, just set the condition values
			if (conditionCombinations[i] == 'NA' || conditions.contains("#Assembly") || conditions.contains("#Extraction") || conditionCombinations[i] == conditions) {
				conditionKeys = conditionCombinations[i];
			} else {
				conditionKeys = conditionCombinations[i].join(',');
			}

			for (y=0; y < sourceInCombinations.size(); y++) {
				def sourceValues = sourceInCombinations[y].join(',');
				def targetValueSet = valueMapApi.getMappedValue(evmName, sourceParameters, sourceValues, conditionKeys, targetParameters); 
				def valueMap = "ValueMap (" + evmName + ", " + sourceParameters + ", " + sourceValues + ", " + conditionKeys + ", "  + targetParameters + ")";
				matchingArray.add(valueMap);
				message.setProperty("SAP_B2B_EVM_MatchingArray",matchingArray);
				
				if (targetValueSet) {
					message.setProperty("SAP_B2B_EVM_ValueMap",valueMap);
					if(targetType == "Assembly") {
						targetExtAssParams =  targetParameters.tokenize('#') as String[];
						targetParamSet =  targetExtAssParams[0].tokenize(',') as String[];
					} else if(targetType == "Extraction") {
						targetExtAssParams =  targetParameters.tokenize('#') as String[];
						targetParamSet =  targetExtAssParams[1].tokenize(',') as String[];
					} else {
						targetParamSet =  targetParameters.trim().split(",") as String[];
					}
					String[] targetValues =  targetValueSet.trim().split(",");
					
					
					// Write values from target side to corresponding target parameters
					for (i=0;i < targetParamSet.size();i++) {
						if (targetValues[i] == "NA") {
							targetValues[i] = targetValues[i].replace("NA", "");
						} else if (targetValues[i].contains("\${") && targetType == "Extraction") {
							targetValues[i] = targetValues[i].replace("\${", "").replace("}", "");
							targetValues[i] = properties.get(targetValues[i]);
						} else if (targetValues[i].contains("\${") && targetType != "Extraction") {
							targetValues[i] = targetValues[i].replace("\${", "").replace("}", "");
							targetValues[i] = headers.get(targetValues[i]);
						} else {
							targetValues[i] = targetValues[i];
						}
					}
					message.setProperty("SAP_B2B_EVM_ParamaterSet",targetParamSet);
					// Set camel header with finally set parameter values
					for (i=0;i < targetParamSet.size();i++) {
						if(targetType == "Extraction") {
							message.setProperty(targetParamSet[i],targetValues[i]);
    				} else {
    					message.setHeader(targetParamSet[i],targetValues[i]);
    				}
					}
					break;
				}
			}
		}
	} 
    return message;
}