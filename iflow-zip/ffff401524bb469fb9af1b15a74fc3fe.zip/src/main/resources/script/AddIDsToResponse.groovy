import com.sap.gateway.ip.core.customdev.util.Message
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.NodeList
import org.xml.sax.InputSource
import java.io.StringReader
import java.io.StringWriter
import javax.xml.transform.TransformerFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

def Message processData(Message message) {
    // Get refIDs from property (e.g., "241 424")
    def refIDs = message.getProperty("refIDs")?.split(" ")

    // Get body as string
    def responseXml = message.getBody(String)

    // Parse the XML response
    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance()
    def dBuilder = dbFactory.newDocumentBuilder()
    def inputSource = new InputSource(new StringReader(responseXml))
    Document responseDoc = dBuilder.parse(inputSource)
    responseDoc.getDocumentElement().normalize()

    // Extract value from <EarliestMinDeliverySize>
    NodeList nodeList = responseDoc.getElementsByTagName("EarliestMinDeliverySize")
    def extractedValue = (nodeList != null && nodeList.getLength() > 0) ? nodeList.item(0).getTextContent() : ""

    // Build output XML
    Document outputDoc = dBuilder.newDocument()
    Element rootElement = outputDoc.createElement("values")
    outputDoc.appendChild(rootElement)

    refIDs.each { refID ->
        Element entryElement = outputDoc.createElement("entry")
        entryElement.setAttribute("id", refID)
        entryElement.setTextContent(extractedValue)
        rootElement.appendChild(entryElement)
    }

    // Convert Document to String
    def transformer = TransformerFactory.newInstance().newTransformer()
    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes")
    transformer.setOutputProperty(OutputKeys.INDENT, "yes")
    def writer = new StringWriter()
    transformer.transform(new DOMSource(outputDoc), new StreamResult(writer))

    // Set new body
    message.setBody(writer.toString())
    return message
}
