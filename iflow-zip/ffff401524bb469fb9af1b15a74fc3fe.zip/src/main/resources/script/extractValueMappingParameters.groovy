import com.sap.gateway.ip.core.customdev.util.Message;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;
import java.nio.charset.StandardCharsets;

def Message processData(Message message) {
    def body = message.getBody(String) as String;

    def dbFactory = DocumentBuilderFactory.newInstance();
    def dBuilder = dbFactory.newDocumentBuilder();
    def doc = dBuilder.parse(new ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8)));
    doc.getDocumentElement().normalize();

    Node queryNode = doc.getElementsByTagName("Query").item(0);
    def tableValue = queryNode.getAttributes().getNamedItem("table")?.getTextContent();

    if (tableValue == null || !tableValue.contains("%%")) {
        throw new IllegalStateException("Missing or malformed table attribute");
    }

    def parts = tableValue.split("%%");
    if (parts.size() < 4) {
        throw new IllegalStateException("Expected 4 sections in table attribute, got: " + parts.size());
    }

    def evmName = parts[0];
    def sourceParams = parts[1];
    def rawConditionParam = parts[2];
    def targetParams = parts[3];

    def validConditions = []

    // Nur setzen, wenn das Format Name:Value oder Name1:Value1,Name2:Value2 erkannt wird
    if (rawConditionParam?.contains(":")) {
        def conditionPairs = rawConditionParam.split(",")
        conditionPairs.each { pair ->
            def splitPair = pair.split(":")
            if (splitPair.size() == 2) {
                def conditionName = splitPair[0].trim()
                def conditionValue = splitPair[1].trim()

                if (conditionValue) {
                    message.setHeader(conditionName, conditionValue)
                    validConditions << pair.trim()
                }
            }
        }
    }

    // Nur setzen, wenn mindestens eine gültige Condition vorhanden ist
    if (!validConditions.isEmpty()) {
        message.setProperty("SAP_B2B_EVM_Conditions", validConditions.join(","))
    } else {
        message.setProperty("SAP_B2B_EVM_Conditions", rawConditionParam)
    }
    
    def conditionColumn = doc.getElementsByTagName("Condition").item(0)?.getAttributes()?.getNamedItem("column")?.getTextContent()
    if (conditionColumn != null && !conditionColumn.isEmpty()) {
        message.setHeader(sourceParams, conditionColumn)
    }
    
    if (sourceParams?.contains(",")) {
    def sourceParamList = sourceParams.split(",").collect { it.trim() }
    def combinedHeaderValue = message.getHeader(sourceParams, String)

    if (combinedHeaderValue != null) {
        def sourceValues = combinedHeaderValue.split(",").collect { it.trim() }

        if (sourceValues.size() == sourceParamList.size()) {
            for (int i = 0; i < sourceParamList.size(); i++) {
                message.setHeader(sourceParamList[i], sourceValues[i])
            }
            // Header löschen
            message.setHeader(sourceParams, null)
        } else {
            throw new IllegalStateException("Mismatch between source parameter names and header values count.")
        }
    }
}

    message.setProperty("SAP_B2B_EVM_Name", evmName);
    message.setProperty("SAP_B2B_EVM_SourceParameters", sourceParams);
    message.setProperty("SAP_B2B_EVM_TargetParameters", targetParams);

    return message;
}