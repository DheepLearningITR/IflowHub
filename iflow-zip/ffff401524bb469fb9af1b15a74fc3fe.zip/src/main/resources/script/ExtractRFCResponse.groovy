import com.sap.gateway.ip.core.customdev.util.Message
import java.io.ByteArrayInputStream
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.xpath.XPathFactory
import javax.xml.xpath.XPath
import org.w3c.dom.Node
import org.w3c.dom.NodeList

def Message processData(Message message) {
    
    String body = message.getBody(String)
    
    // XPath from Property (e.g. //RETURN/item/MESSAGE/text())
    String xpathExpr = message.getProperty("QRY_Select")
    
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance()
    factory.setNamespaceAware(true)
    def builder = factory.newDocumentBuilder()
    def xmlDoc = builder.parse(new ByteArrayInputStream(body.getBytes("UTF-8")))
    
    XPath xPath = XPathFactory.newInstance().newXPath()
    def expr = xPath.compile(xpathExpr)
    
    //Convert the Nodes so that XML elements retain after XPath evaluation 
    Node node = (Node) expr.evaluate(xmlDoc, javax.xml.xpath.XPathConstants.NODE)
    String result = nodeToString(node)
    
    message.setProperty("QRY_Result", result)
    
    return message
}

String nodeToString(Node node) {
    StringBuilder sb = new StringBuilder()
    if (node != null) {
        sb.append("<").append(node.getNodeName()).append(">")
        Node child = node.getFirstChild()
        while (child != null) {
            if (child.getNodeType() == Node.ELEMENT_NODE) {
                sb.append(nodeToString(child))
            } else if (child.getNodeType() == Node.TEXT_NODE) {
                sb.append(child.getTextContent())
            }
            child = child.getNextSibling()
        }
        sb.append("</").append(node.getNodeName()).append(">")
    }
    return sb.toString()
}