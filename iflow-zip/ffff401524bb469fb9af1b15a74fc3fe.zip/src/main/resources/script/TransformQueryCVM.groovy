import com.sap.gateway.ip.core.customdev.util.Message
import javax.xml.parsers.DocumentBuilderFactory

def Message processData(Message message) {
    // XML aus Body laden
    def body = message.getBody(java.io.InputStream)
    def factory = DocumentBuilderFactory.newInstance()
    def builder = factory.newDocumentBuilder()
    def doc = builder.parse(body)
    doc.getDocumentElement().normalize()

    // <Query>-Element holen
    def queryNode = doc.getElementsByTagName("Query").item(0)

    // Attribut "table" auslesen und splitten
    def table = queryNode.getAttribute("table") ?: ""
    def tableFields = table.split("%%")
    if (tableFields.length != 4) {
        throw new IllegalArgumentException("Expected 4 fields in table=..., got: ${tableFields.length}")
    }

    def sourceAgency     = tableFields[0].trim()
    def sourceIdentifier = tableFields[1].trim()
    def targetAgency     = tableFields[2].trim()
    def targetIdentifier = tableFields[3].trim()

    // <Condition column="..."/> lesen
    def conditionNode = queryNode.getElementsByTagName("Condition").item(0)
    if (conditionNode == null) {
        throw new IllegalArgumentException("No <Condition> element found.")
    }

    def conditionValue = conditionNode.getAttribute("column")?.trim()
    if (!conditionValue) {
        throw new IllegalArgumentException("Condition 'column' attribute is empty.")
    }

    // Properties setzen für extractionValueMapping.groovy
    message.setProperty("SAP_B2B_EVM_Name", sourceAgency)
    message.setProperty("SAP_B2B_EVM_SourceParameters", sourceIdentifier)
    message.setProperty("SAP_B2B_EVM_Conditions", targetAgency)
    message.setProperty("SAP_B2B_EVM_TargetParameters", targetIdentifier)

    // Header für SourceParameter setzen (Pflicht für Value Mapping!)
    message.setHeader(sourceIdentifier, conditionValue)

    return message
}