import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    
    // Properties auslesen
    String dbTable = message.getProperty("QRY_DbTable")   // z. B. BAPI_PO_GETDETAIL
    
    // Body parsen
    String body = message.getBody(String)
    def xml = new XmlSlurper(false, false).parseText(body)
    
    // Wert aus Condition/@column holen (mit unescape)
    String rawColumn = xml.Query.Condition.@column.toString()
    String unescaped = rawColumn.replaceAll("&lt;", "<").replaceAll("&gt;", ">")
    
    // Neuen Payload bauen
    String newBody = "<${dbTable}>${unescaped}</${dbTable}>"
    
    // Body ersetzen
    message.setBody(newBody)
    return message
}
