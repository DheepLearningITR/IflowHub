//===============================================================
// This script is a dynamic header to property matched mapping                                               
//                                                               
// History:                                                       
// 2025-07-21 [SAP-MÖ] - Script initially created                   
//=============================================================== 
import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {

    def paramName = message.getProperty("SAP_B2B_EVM_TargetParameters")  
    def targetValue

    if (paramName?.contains(",")) {
        // Wenn paramName ein Komma enthält, benutze QRY_Select als Header
        def selectHeader = message.getProperty("QRY_Select")
        targetValue = message.getHeader(selectHeader, String)
    } else {
        // Ansonsten normal
        targetValue = message.getHeader(paramName, String)
    }

    message.setProperty("CVM_TargetValue", targetValue)

    return message
}