import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.util.*;
import groovy.xml.*;
import org.codehaus.*;
import java.util.HashMap;

def Message processData(Message message) {
                
                // get a map of properties
                def map = message.getProperties();
                
                // get an exception java class instance
                def ex = map.get("CamelExceptionCaught");
                if (ex!=null) {
                                if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
                                           
                                                def errorResponse=ex.getResponseBody();
                                                def jsonSlurper = new JsonSlurper();
                                                def errorDetails = jsonSlurper.parseText(errorResponse);
                                                message.setProperty("errorMessage",errorDetails.error.code + "." + errorDetails.error.message);
                                                message.setProperty("statusCode",ex.getStatusCode());

                                                
                                }
                }

                return message;
}