import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
def Message processData(Message message) {
 	def body = message.getBody(java.lang.String);
    message.setProperty("InputJSONPayload",body);
    return message;
}