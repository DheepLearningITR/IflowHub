import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    def body_json= message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def output = jsonSlurper.parseText(body_json);
    message.setProperty("workflowInstanceId",output.id)
    return message;
}