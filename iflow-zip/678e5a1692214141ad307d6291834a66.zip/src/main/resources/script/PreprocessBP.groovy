import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import groovy.util.slurpersupport.NodeChild;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message){
    def body = message.getBody(java.lang.String);
    def query = new XmlSlurper().parseText(body);
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    def organizationExist = false;
    query.IDOC.each{
        if(it.E101CRMXIF_PARTNER_COMPLEX.E101BUS_EI_CENTRAL_DATA.E101BUS_EI_BUPA_CENTRAL.E101US_EI_BUPA_CENTRAL_DATA.E101US_EI_BUPA_CENTRAL_MAIN.CATEGORY.text()=="2") {
            def isNodeOrganization = false;
            it.E101CRMXIF_PARTNER_COMPLEX.E101BUS_EI_CENTRAL_DATA.E101BUS_EI_ROLES.E101BUS_EI_BUPA_ROLES.each {
                def fromValueMap = valueMapApi.getMappedValue('CRMBPRole', 'RoleCode', it.E101BUS_EI_ROLE_DATA.ROLECATEGORY.text(), 'FSMPartner', 'PartnerType');
                if (fromValueMap != null){
                    if(fromValueMap.toLowerCase().equals("bp")){
                        isNodeOrganization = true;
                        organizationExist = true;
                    }
                }    
            }
            if(!isNodeOrganization)
                it.replaceNode {};
        }
        else
            it.replaceNode {};
  }
  if(organizationExist)
    message.setProperty("OrganizationExists","exists");
  def valid_data = XmlUtil.serialize(query);
  message.setBody(valid_data);
  return message;
}