import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {

    ex = message.getHeader("CamelHttpResponseCode", java.lang.String)
 	
 	if (ex != null && !ex.matches("200|403")){
 	    throw new GetEDRdataAddressException(String.format("Code returned for Get EDR dataAddress request was: HTTP %s!", ex))
 	}
 	
 	return message
 	
}

class GetEDRdataAddressException extends Exception {
  GetEDRdataAddressException(String errorText){
      super(errorText)
  }
}