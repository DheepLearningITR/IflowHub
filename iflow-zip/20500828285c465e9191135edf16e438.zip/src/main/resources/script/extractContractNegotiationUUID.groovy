import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
def Message processData(Message message) {

 	def body = message.getBody(java.lang.String)
 	def enableLogging = message.getProperties().get("enableLogging")
    def messageLog = messageLogFactory.getMessageLog(message)
    if(enableLogging.toUpperCase().equals("TRUE") && messageLog != null){
	    messageLog.addAttachmentAsString("ExtractContractNegotiationUUID payload", body , "application/json")
	}
	
    def contractResponse = new JsonSlurper().parseText(body)."@id"
    
	
	if (contractResponse != null && !contractResponse .trim().isEmpty()){
	    message.setProperty("contractNegotiationUUID", contractResponse)
        return message
    }
    
    throw new ContractNegotiationException("Value of contractNegotiationUUID could not be empty!")
}

class ContractNegotiationException extends Exception {
  ContractNegotiationException(String errorText){
      super(errorText)
  }
}