import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
import java.time.Instant
import java.time.Duration

def Message processData(Message message) {

 	def body = message.getBody(java.lang.String) as String
    
    def contractConfirmed = false
	def contractNegotiationState = ''
	def startTimeStamp = message.getProperty("contractWaitStartTime")	
    def contractConfirmationWaitTime = String.valueOf('300').toLong()
	def contractConfirmationPollingInterval = String.valueOf('1000').toLong()
		
	def startTime = Instant.parse(startTimeStamp)
    
    def endTime = Instant.now()
    
    def duration = Duration.between(startTime, endTime).getSeconds()
	
	if(duration > contractConfirmationWaitTime){
        throw new ContractConfirmationNotSuccessfulException('Configured max wait time interval for Contract Confirtamtion exceeded!')
	}
    
    if(body != null && !body.trim().isEmpty()){
        contractNegotiationState = new JsonSlurper().parseText(body)."state"
        
        if (contractNegotiationState == "FINALIZED") {
            contractConfirmed = true           
        }
        else {
            contractConfirmed = false     
            sleep(contractConfirmationPollingInterval)
        }
        
        message.setHeader('contractConfirmed', contractConfirmed)
        return message
    }
    
    throw new ContractConfirmationNotSuccessfulException('Payload from Contract Confirtamtio request cannot be empty!')
    
}

class ContractConfirmationNotSuccessfulException extends Exception {
  ContractConfirmationNotSuccessfulException(String errorText){
      super(errorText)
  }
}