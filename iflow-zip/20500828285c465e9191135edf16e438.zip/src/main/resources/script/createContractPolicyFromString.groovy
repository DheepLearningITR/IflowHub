import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.json.JsonOutput

def Message processData(Message message) {
    
    def input = new JsonSlurper().parse(message.getBody(Reader))
    
    def policyString = message.getProperty("contractNegotiationPolicy")
    def assetId = message.getProperty("assetId")
    def consumerBPN = message.getProperty("providerBPN")
    def offerId = message.getProperty("offerId")
    
    if (policyString !=null && !policyString.trim().isEmpty()){
        
        try {
            def policyJson = new JsonSlurper().parseText(policyString)
            input.atcontext << "https://w3id.org/tractusx/policy/v1.0.0"
            input.atcontext << "http://www.w3.org/ns/odrl.jsonld"
            def finalPolicy = replaceAttributeValuesInJson(policyJson,consumerBPN,assetId,offerId)
            input << finalPolicy
        }
        
        catch (Exception e){
            throw new ContractNegotiationPolicyException(Strin.format("Could not set policy for Initiate EDR Negotiation request! Reason is %s", e.getMessage()))
        }
    }
    
    else {
        throw new ContractNegotiationPolicyException("Could not set policy for Initiate EDR Negotiation request! Policy is null or empty!")
    }
    
    message.setBody(JsonOutput.toJson(input))
    
    return message
}

def replaceAttributeValuesInJson(input,consumerBPN,assetId,offerId) {
    
    def changes = [
            'atid': offerId,
            'target': assetId,
            'assigner': consumerBPN
    ]
    
    def output
    
    if (input instanceof Map) {
        output = (input as Map).collectEntries { key, value -> [(changes[key] ? key : key) : value instanceof Map ? replaceAttributeValuesInJson(value,consumerBPN,assetId,offerId) : (changes[key]) ? (changes[key]) : value] }
            
    } else {
        input
    }
    
    return output
}

class ContractNegotiationPolicyException extends Exception {
  ContractNegotiationPolicyException(String errorText){
      super(errorText)
  }
}