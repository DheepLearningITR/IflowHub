import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
def Message processData(Message message) {

 	def body = message.getBody(java.lang.String) as String
    def enableLogging = message.getProperties().get("enableLogging")
    def messageLog = messageLogFactory.getMessageLog(message)
    if(enableLogging.toUpperCase().equals("TRUE") && messageLog != null){
		messageLog.addAttachmentAsString("Get Catalogue Response", body, "text/xml")
	}
    def catalogs = ''
    def contract = ''
	def offerId = ''
	def assetId = ''
	def catalogueResponse = []
    catalogs = new JsonSlurper().parseText(body)
	
	catalogueResponse = catalogs."dcat:dataset"
	
	if (catalogueResponse != null && !(catalogueResponse instanceof List)){
	    assetId = catalogueResponse."@id"
        offerId = catalogueResponse."odrl:hasPolicy"."@id"
	    message.setProperty("offerId", offerId)
	    message.setProperty("assetId", assetId)
        message.setBody("<root/>")
        return message
	}
	
	throw new ContractOfferNotFoundException("Catalogue query result did not return any or exactly one contract offer id!")
    
}

class ContractOfferNotFoundException extends Exception {
  ContractOfferNotFoundException(String errorText){
      super(errorText)
  }
    
}
