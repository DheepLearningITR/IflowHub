import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.json.JsonOutput

def Message processData(Message message) {
    
    def input = new JsonSlurper().parse(message.getBody(Reader))
    
    def replacedJson = replaceCharactersInJson(input)

    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(replacedJson)))
    
    return message
    
}
//As JSON-LD is not supported in graphical mapping on Cloud Integration we have to replace all "at" escape characters back to @
//Format all number attributes as Integer instead of Strings 
def Map replaceCharactersInJson(input) {
    
    
    def output
    
    if (input instanceof Map) {
        output = (input as Map).collectEntries { key, value -> [(key.replaceAll('^at', '@')) : value instanceof Map ? replaceCharactersInJson(value) : value instanceof String && value.matches("^\\d+\$") ? Integer.valueOf(value) : value] }
    } else if (input instanceof List) {
        input.collect { replaceCharactersInJson(it) }
    } else {
        input
    }
    
    return output
}
