import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
import java.time.Instant
import java.time.Duration

def Message processData(Message message) {

 
    def enableLogging = message.getProperties().get("enableLogging")
    def messageLog = messageLogFactory.getMessageLog(message)
    def assetID = ''
    def providerBPN = ''
    def transferProcessId = ''
    def checkEDRcacheWaitStartTimeIsSet = false
    
    def checkEDRcacheWaitStartTime = message.getProperty("checkEDRcacheWaitStartTime")
    //periodically poll for token again if EDC cache hasnt got a new edr yet
    def sleepTimeInterval = message.getProperty('edrTokenRefreshWaitTime').toLong()
    
    if (checkEDRcacheWaitStartTime != null && !checkEDRcacheWaitStartTime.trim().isEmpty()){
        checkEDRcacheWaitStartTimeIsSet = true
        def startTimeStamp = checkEDRcacheWaitStartTime	
        
        //these two parameters are only needed if calling iflow calls Check EDR Cache Process in a loop
        //wait max 5 mins for EDC cache to get an edr
        def checkEDRcacheWaitTime = String.valueOf('60').toLong()
        
	    def startTime = Instant.parse(startTimeStamp)
    
        def endTime = Instant.now()
    
        def duration = Duration.between(startTime, endTime).getSeconds()
        
        if(duration > checkEDRcacheWaitTime){
            throw new CheckERDCacheException('Configured max wait time interval for Check EDR Cache process exceeded, value of transferProcessId is null!')
        }
    }
    
    parseEdrCacheResponse(message, checkEDRcacheWaitStartTimeIsSet, transferProcessId, sleepTimeInterval)
    
    return message
   
}

def String parseEdrCacheResponse(Message message, Boolean checkEDRcacheWaitStartTimeIsSet, String transferProcessId, Long sleepTimeInterval) {
   def body = message.getBody(java.lang.String) as String
   
   if (body != null && !body.trim().isEmpty()) {
   
       def edrCacheResponse = new JsonSlurper().parseText(body)
       assetId = message.getProperty("assetId")
       providerBPN = message.getProperty("providerBPN")
        	
       Closure filterExpression = { it."assetId" == assetId && it."providerId" == providerBPN }
       def filterlistcachedEDR = edrCacheResponse.findAll (filterExpression)
       def latestEDR = filterlistcachedEDR.max{it."createdAt"}
    
       if(latestEDR != null && latestEDR.containsKey("transferProcessId")) {
          transferProcessId = latestEDR."transferProcessId"
       }else {
           
          //only needed if calling iflow calls Check EDR Cache Process in a loop
          if (checkEDRcacheWaitStartTimeIsSet == true){
             sleep(sleepTimeInterval)
          }
        }
        
       message.setProperty("transferProcessId", transferProcessId)
       message.setBody("<root/>")
       
       return message
   }
   
    throw new CheckERDCacheException('Payload from Check EDR Cache response cannot be empty!')
}

class CheckERDCacheException extends Exception {
  CheckERDCacheException(String errorText){
      super(errorText)
  }
}
