import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {

    //pause thread for 3 ms
	def sleepTimeInterval = message.getProperty('edrTokenRefreshWaitTime').toLong()
	sleep(sleepTimeInterval)
	
	return message
}