import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
import java.time.Instant
def Message processData(Message message) {

 	def body = message.getBody(java.lang.String) as String
    def enableLogging = message.getProperties().get("enableLogging")
    def messageLog = messageLogFactory.getMessageLog(message)
    def tokenExpired = false
	
    def payloadAsJson
   
    payloadAsJson = new JsonSlurper().parseText(body)
    def edr = payloadAsJson."authorization"
    def sleepTimeInterval = message.getProperty('edrTokenRefreshWaitTime').toLong()
    
    if ( edr !=null && ! edr.trim().isEmpty()){
        message.setHeader('Authorization',  edr)
        message.setHeader("CustomCamelHttpResponseCode", "200")
        //check if edr is expired
        String[] chunks = edr.split("\\.")
        def edrAsJson = new JsonSlurper().parseText(decode(chunks[1]))
        def currentTimeStamp = Instant.now().plusMillis(sleepTimeInterval)
        if (currentTimeStamp.isAfter(Instant.ofEpochSecond(Long.valueOf(edrAsJson."exp")))) {
            //throw new EDRExpiredException("Authorization token already expired!")
            //pause thread for 3 ms and set http code to 403
	        
	        sleep(sleepTimeInterval)
            message.setHeader("CustomCamelHttpResponseCode", "403")
        }
        
    } else {
        throw new EDRNotFoundException("Response payload does not contain any authorization token!")
    }
    
    return message
}

private static String decode(String encodedString) {
    return new String(encodedString.decodeBase64())
}

class EDRExpiredException extends Exception {
  EDRExpiredException(String errorText){
      super(errorText)
  }
}

class EDRNotFoundException extends Exception {
  EDRNotFoundException(String errorText){
      super(errorText)
  }
}
