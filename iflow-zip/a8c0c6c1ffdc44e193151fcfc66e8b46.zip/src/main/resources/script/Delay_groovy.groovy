import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.nio.charset.StandardCharsets;

def Message processData(Message message) {
		
	sleep(1000); 

	return message;
}