import com.sap.it.api.mapping.*;

def String getBP_UUID(String id, MappingContext context){
    String value = context.getProperty(id);
    value = value.replaceAll("-","");
	return value;
}
