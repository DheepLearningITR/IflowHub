import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message){
    
    def body = message.getBody(java.lang.String) as String;
    def map = message.getProperties();
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    
   if(jsonObject.data[0])
   {

   boolean isKeyPresent_CP = jsonObject.get("data").get(0).keySet().contains("contact");
    
     if(isKeyPresent_CP)
    {
        message.setProperty("resource","Contact");
        message.setProperty("dto","Contact.16");
    }
    else
    {
    message.setProperty("resource","false");
    }
    return message;
    
   }
   else
   
   message.setProperty("resource","false");
   return message;
}
