import com.sap.it.api.mapping.*;


def String getBP_Id(String id, MappingContext context){
   String value = context.getProperty(id);
	return value; 
}
