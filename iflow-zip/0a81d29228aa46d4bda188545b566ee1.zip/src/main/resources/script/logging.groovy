/*
Script from https://blogs.sap.com/2020/09/13/sap-cpi-a-guide-to-mpl-search/
*/

import java.util.HashMap;
import com.sap.gateway.ip.core.customdev.util.Message;


// Start of Processing

def Message logStart(Message message) {
    logCustomHdrProp(message, "CustomLog", "IDOC triggered from S95");
    return message;
}

// Processing Logs

def Message log_PasXRequest(Message message) {
    logCustomHdrProp(message, "CustomLog", "Request to PAS-X completed successfully")
    return message;
}

def Message log_PasXRequestFailed(Message message) {
    logCustomHdrProp(message, "CustomLog", "Request to PAS-X failed")
    return message;
}

// End of Processing

def Message logEnd(Message message) {
    logCustomHdrProp(message, "CustomLog", "IDOC execution completed successfully");
    return message;
}

// Exceptions

def Message logErr_PasxReq(Message message) {
    logCustomHdrProp(message, "CustomLog", "Error encountered while connecting with PAS-X or processing IDoc")
    logException(message, message.getProperty("exception_msg"))
    return message;
}

def Message logErr_DetMapping(Message message) {
    logCustomHdrProp(message, "CustomLog", "A mapping for Idoc type " + message.getHeader("SapIDocTransferId", java.lang.String) + " cannot be found")
    logCustomHdrProp(message, "CustomLog", "Error encountered while determining the mapping to use")
    logException(message, message.getProperty("exception_msg"))
    return message;
}

def Message logErr_Mapping(Message message) {
    logCustomHdrProp(message, "CustomLog", "Error encountered while performing mapping program -" + message.getHeader("MappingProgramName", java.lang.String))
    logException(message, message.getProperty("exception_msg"))
    return message;
}

// Add Exception in Headers

def Message logException(Message message, String exception) {
    message.setHeader("exception_msg", exception)
    logCustomHdrProp(message, "CustomLog", "Exception Message: " + exception)
    logCustomHdrProp(message, "CustomLog", "Stopping interface due to error")
    return message
}

// Custom Log Writer

def Message logCustomHdrProp(Message message, String propName, String propValue) {
    def messageLog = messageLogFactory.getMessageLog(message)
    
    if (propName.equals('CustomLog')) {
        if (message.getProperty("customLogCounter") >= 0) {
            def counter = message.getProperty("customLogCounter") + 1
            messageLog.addCustomHeaderProperty(propName + "_" + counter.toString().padLeft(3, '0'), propValue)
            message.setProperty("customLogCounter", counter)
        }
        // for first custom log entry
        else {
            message.setProperty('customLogCounter', 0)
            messageLog.addCustomHeaderProperty(propName + "_000", propValue)
        }
    }
    else {
        messageLog.addCustomHeaderProperty(propName, propValue)
    }
    return message
} 