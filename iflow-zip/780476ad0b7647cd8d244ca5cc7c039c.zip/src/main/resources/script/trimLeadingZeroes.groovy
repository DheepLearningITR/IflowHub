import com.sap.it.api.mapping.*;
import java.lang.String;

def String trimLeadingZeroes(String input){
	return input.replaceFirst("^0+", "");
}