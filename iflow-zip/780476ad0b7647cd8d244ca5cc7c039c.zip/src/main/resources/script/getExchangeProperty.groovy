import com.sap.it.api.mapping.*;

def String getExchangeProperty(String name, MappingContext context){
	return context.getProperty(name);
}