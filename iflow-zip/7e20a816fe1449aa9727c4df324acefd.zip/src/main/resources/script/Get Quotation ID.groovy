
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(String.class);
       message.setProperty("ems_body", body);
       def root = new JsonSlurper().parseText(body);
       
       quotation_id = "'" + root.data.ServiceQuotation + "'"
       
       message.setProperty("quotation_id", quotation_id);
       return message;
}