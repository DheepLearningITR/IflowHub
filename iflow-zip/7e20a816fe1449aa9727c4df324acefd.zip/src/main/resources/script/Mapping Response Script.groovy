import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput;
import groovy.json.JsonSlurper;
import java.time.Instant;
import java.text.SimpleDateFormat

def Message processData(Message message) {
        
        def map = message.getProperties();
        def ems_root = new JsonSlurper().parseText(map.get("ems_body"));
        def s4_quotation_root = new XmlParser().parseText(map.get("s4_body"));
        //Read the BP get response from S4 and parse it
        def s4_bp_data = new XmlParser().parseText(message.getBody(String.class));
        
        SimpleDateFormat InstantFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        SimpleDateFormat s4_ValidityDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        s4_ValidityDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        
        String ValidityStartDateTime = "";
        if(s4_quotation_root.entry[0].content.'m:properties'.'d:SrvcQtanValidityStartDateTime'.text().trim() != "0"){
        ValidityStartDateTime = new Date().parse("yyyyMMddHHmmss", s4_quotation_root.entry[0].content.'m:properties'.'d:SrvcQtanValidityStartDateTime'.text().trim()).format("yyyy-MM-dd'T'HH:mm:ss'Z'")
        }
        
        String ValidityEndDateTime = "";
        if(s4_quotation_root.entry[0].content.'m:properties'.'d:SrvcQtanValidityEndDateTime'.text().trim() != "0"){
        ValidityEndDateTime = new Date().parse("yyyyMMddHHmmss", s4_quotation_root.entry[0].content.'m:properties'.'d:SrvcQtanValidityEndDateTime'.text().trim()).format("yyyy-MM-dd'T'HH:mm:ss'Z'")
        }
        
        String status = "";
        if(s4_quotation_root.entry[0].content.'m:properties'.'d:ServiceQuotationIsReleased'.text().trim()== "X"){
            status = "RELEASED";
        }
        else if(s4_quotation_root.entry[0].content.'m:properties'.'d:ServiceQuotationIsAccepted'.text().trim()== "X"){
            status="ACCEPTED";
        }
        else if(s4_quotation_root.entry[0].content.'m:properties'.'d:ServiceQuotationIsRejected'.text().trim()== "X"){
            status="REJECTED";
        }
        
        def root = [
                messageHeader : [
                        id : UUID.randomUUID().toString(),
                        senderCommunicationSystemDisplayId : map.get("senderCommSysDisplayId"),
                        receiverCommunicationSystemDisplayId : map.get("receiverCommSysDisplayId"),
                        creationDateTime: Instant.now().toString()
                ],
                messageRequests : [[
                        messageHeader : [
                                id: UUID.randomUUID().toString(),
                                messageEntityName: "sap.crm.eventbridgeservice.entity.inboundEvent",
                                actionCode: "CREATE"
                        ],
                        body : [
                                eventId: ems_root.id,
                                eventType: ems_root.type,
                                sourceObjectType : "10004",
                                eventTime: ems_root.time,
                                objectAttributes: [
                                        [
                                                "key": "ID",
                                                "value": s4_quotation_root.entry[0].content.'m:properties'.'d:ServiceQuotation'.text().trim()
                                        ],
                                        [
                                                "key": "Description",
                                                "value": s4_quotation_root.entry[0].content.'m:properties'.'d:ServiceQuotationDescription'.text().trim()
                                        ],
                                        [
                                                "key": "SoldToParty",
                                                "value": s4_quotation_root.entry[0].content.'m:properties'.'d:SoldToParty'.text().trim()
                                        ],
                                        [
                                                "key": "BusinessPartnerCategory",
                                                "value": s4_bp_data.content.'m:properties'.'d:BusinessPartnerCategory'.text().trim()
                                        ],
                                        [
                                                "key": "UUID",
                                                "value": s4_quotation_root.entry[0].content.'m:properties'.'d:ServiceQuotationUUID'.text().trim()
                                        ],
                                        [
                                                "key": "ValidityStartDateTime",
                                                "value": ValidityStartDateTime
                                        ],
                                        [
                                                "key": "ValidityEndDateTime",
                                                "value": ValidityEndDateTime
                                        ],
                                        [
                                                "key": "Status",
                                                "value": status
                                        ]
                                ]
                        ]
                ]]
        ]
        
        def root_out = JsonOutput.toJson(root)
        message.setBody(JsonOutput.prettyPrint(root_out.toString()))
        message.setProperty("mappedData",root_out)
        message.setHeader("SAP_ApplicationID", root.messageHeader.id);
       
       return message;
}