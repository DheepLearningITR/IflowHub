import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.ArrayList;
import java.lang.*;
import com.sap.it.api.mapping.*;
import groovy.json.*
import java.text.SimpleDateFormat

def Message processData(Message message) {
    
    Date currentdate = new Date(); 

    message.setHeader("Content-Type", "application/json" + "; charset=utf-8" );
    
    def jsonBody = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def jsonObj = jsonSlurper.parseText(jsonBody);
    
    def dataResults = [];
    
    def displayPaidInvoices = message.getProperty("displayPaidInvoices");
    
    //Open invoice
    def openSegment = [:]
    openSegment.name = "open";
    openSegment.y = 0;
    
    //Overdue invoice
    def overdueSegment = [:]
    overdueSegment.name = "overdue";
    overdueSegment.y = 0;
    
    //Paid invoice
    def paidSegment = [:]
    paidSegment.name = "paid";
    paidSegment.y = 0;
    
    //new ext data 
    def extData = [:];
    extData.open = [];
    extData.overdue = [];
    if(displayPaidInvoices.equalsIgnoreCase("true")){
        extData.paid = [];
    }
    
    jsonObj.get("messageResponses").get(0).get("body").get("extData").each{ val ->
        if(val.isCleared.equals("true") && displayPaidInvoices.equalsIgnoreCase("true")){
            paidSegment.y = paidSegment.y + 1;
            extData.paid.push(val);
            
        }else{
            if(Date.parse("yyyy-MM-dd'T'HH:mm:ss",val.netDueDate).compareTo(currentdate)==-1){
                overdueSegment.y = overdueSegment.y + 1;
                extData.overdue.push(val); 
            }else{
                openSegment.y = openSegment.y + 1;    
                extData.open.push(val);    
            }
        }
     
    }
    
    jsonObj.get("messageResponses").get(0).get("body").put("extData",extData);  
    
    if(displayPaidInvoices.equalsIgnoreCase("false")){                                                             
        jsonObj.get("messageResponses").get(0).get("body").total = openSegment.y + overdueSegment.y;
    }
    
    dataResults.push(openSegment);
    dataResults.push(overdueSegment);
    dataResults.push(paidSegment);
     
    jsonObj.get("messageResponses").get(0).get("body").put("data",dataResults);
    def newBody = JsonOutput.toJson(jsonObj);
    message.setBody(newBody);
    return message;
}