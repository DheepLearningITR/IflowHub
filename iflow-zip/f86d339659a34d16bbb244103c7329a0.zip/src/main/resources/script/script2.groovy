import java.text.SimpleDateFormat
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Calendar;
def Message processData(Message message) {

    def properties = message.getProperties();
    
    noOfDays = properties.get("noOfDays");
    value = properties.get("cutoffDateTime");
    
    def cutoffDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'", value).format("yyyy-MM-dd'T'HH:mm:ss");
    
    def sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
    def newCutoffDate =  sdf1.parse(cutoffDate);                            //Convert from string to date and subtract with number of days
    
    newCutoffDate = newCutoffDate - noOfDays.toInteger();
    
    def sdf2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
    def finalCutOffDate = sdf2.format(newCutoffDate);                              //Convert from date to string
    
    message.setProperty("cutoffDateTime", finalCutOffDate);
   
    return message;
}