import com.sap.gateway.ip.core.customdev.util.Message;

import java.util.HashMap; 

import com.sap.it.api.ITApiFactory;

import com.sap.it.api.securestore.SecureStoreService;
import groovy.json.*;
import com.sap.it.api.securestore.UserCredential;

def Message processData(Message message)

{
    def messageBody = message.getBody(String.class);
    def messageLog = messageLogFactory.getMessageLog(message);
    def properties = message.getProperties();
    def jsonSlurper = new JsonSlurper();
    def jsonObject = jsonSlurper.parseText(messageBody);
    String clientDetails = new JsonBuilder(jsonObject).toString();
    messageLog.setStringProperty("jsonObject", clientDetails);
    // Retrieve secure store attributes using token & secret properties to set as headers.
	def service = ITApiFactory.getApi(SecureStoreService.class, null);
	def token_id = properties.get("token");
	def secret_id = properties.get("secret");
	def on24Url = properties.get("on24Url");
	// Get the credentials using the token_id and secret_id
	def apiToken = service.getUserCredential(token_id);
	def apiSecret = service.getUserCredential(secret_id);

	if (apiToken == null) {

		throw new IllegalStateException("No credential found for alias "+ token_id);

	}
	if (apiSecret == null) {

		throw new IllegalStateException("No credential found for alias "+ secret_id);

	}
	def url = on24Url +"/client/"+jsonObject.clientid+"/timezones"
	
   
   //set the ON24 url to fetch the timezones
    message.setProperty("on24TimezoneUrl", url);
	// Set the headers for further calls
    message.setHeader("accessTokenKey",new String(apiToken.getPassword()));
	message.setHeader("accessTokenSecret",new String(apiSecret.getPassword()));
	message.setHeader("clientId",jsonObject.clientid);
	message.setHeader("mktarea",jsonObject.mktarea);
		message.setHeader("mediaType",jsonObject.mediaType);

	return message;

}