importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(com.sap.it.api.msglog.MessageLogFactory);
importClass(com.sap.it.api.msglog.MessageLog);
importClass(java.util.HashMap);
importClass(java.text.SimpleDateFormat);
importClass(java.util.TimeZone);
function processData(message) {
    var body = message.getBody( new java.lang.String().getClass() );
    var events = JSON.parse(body).events;
    var headers = message.getHeaders();
    var timez = message.getProperty("timezones");
   // var lastruntime = headers.get("lastrundatetime").toString();
    var messageLog =  messageLogFactory.getMessageLog(message);
    var skippedEvents = [];
    var result = [];
    var delta = headers.get("delta"); // Retrieve headers [ 'delta', 'mktarea' ] 
    var mktarea = headers.get("mktarea")+"";
    result = events.filter(function(event){
         // Legacy data gets filtered out which do not have basic details [ 'livestart', 'lastmodified']
        if(event.livestart != undefined && event.lastmodified != undefined)
        { // Check for delta condition
            return true;
        }
        else
        {
            skippedEvents.push(event.eventid);
            return false;
        }
        });
        
    
    var totalPageCount = JSON.parse(body).pagecount; // Retrieve and pass on the pagecount as response header for Marketing Cloud to handle pagination
    var totalevents = JSON.parse(body).totalevents;// Retrieve and pass on the totalevents as response header 
    messageLog.setStringProperty("skippedEvents", skippedEvents);
    message.setProperty("pagecount", totalPageCount);
    message.setProperty("totalevents", totalevents);
    message.setBody(JSON.stringify(result));
    return message;
}

