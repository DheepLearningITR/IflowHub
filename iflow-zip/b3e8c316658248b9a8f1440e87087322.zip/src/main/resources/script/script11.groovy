import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonBuilder;
def Message processData(Message message) {
    def body = message.getBody(String.class);/*.replace("][", ",")*/
    def pagecount = message.getProperty("pagecount");
    
    message.setHeader("Content-Type", "application/json");
    message.setHeader("pagecount", pagecount);
    
    //remove the unnecessary root elements and set the message body
    def jsonSlurper = new JsonSlurper();
         //convert the body to a json object
         def jsonObject = jsonSlurper.parseText(body.toString());
         //get the events from  json object
        def root = jsonObject.root;
        if(root != null)
        {
            def totalEvents = jsonObject.root.totalevents;
            def events= jsonObject.root.events;
            def jsonOP;
            //if there are no events then send empty array
            if(totalEvents == "0" || totalEvents == "0.0")
            {
                jsonOP = [];
            }
            //if there is only 1 event then enclose it in an array.
            else if(totalEvents == "1" || totalEvents == "1.0")
            {
                def evtArray = [];
                evtArray.add(events);
                jsonOP = JsonOutput.toJson(evtArray);
                
            }
            else
            {
                jsonOP = JsonOutput.toJson(events);
                
            }
            message.setBody(jsonOP);
        }
    return message;

}