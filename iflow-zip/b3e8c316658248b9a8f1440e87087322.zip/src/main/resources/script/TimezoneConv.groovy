import com.sap.it.api.mapping.*;
import groovy.json.*;
import groovy.json.JsonBuilder;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/
def String customFunc(String displaytimezonecd, MappingContext context){
    def timez = context.getProperty("timezones");
  
    def timezoneOffset= "";
    def jsonSlurper = new JsonSlurper();
    //convert the body to a json object
    def jsonObject = jsonSlurper.parseText(timez);
        
    def timezones = jsonObject.timezones;
    for(timezone in timezones)
    {
        
            if(timezone.value == displaytimezonecd) {
                def fullTimezone = timezone.label.substring(1,timezone.label.indexOf(timezone.value)-2).split(" ");
                if(fullTimezone.size() == 1) {
                    timezoneOffset = "+00:00";
                } else {
                    timezoneOffset = fullTimezone[1];
                    if(timezoneOffset.length() == 5) {
                        timezoneOffset = timezoneOffset.substring(0,1)+"0"+timezoneOffset.substring(1);
                    }
                }
                timezoneOffset = timezoneOffset.substring(0,1) == "+" 
                            ? timezoneOffset.replace(":","").replace("+","P") 
                            : timezoneOffset.replace(":","").replace("-","M");   
            }
        
    }
    return timezoneOffset;
    
}