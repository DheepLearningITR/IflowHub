import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    def map = message.getProperties();
    def headers = message.getHeaders();
    def statusCode = headers.get("CamelHttpResponseCode")
    
    def ex = map.get("CamelExceptionCaught")
    if (ex!=null) {
        def code = ""
        def msg = ""
        // if thrown by the OData adapter
        if (ex.getClass().getCanonicalName().equals("com.sap.gateway.core.ip.component.odata.exception.OsciException")) {
            code = "${statusCode}"
            msg = message.getBody()
        } else {
            // special status code for non-API errors
            code = "588"
            msg = ex.getMessage()
        }

        data = [
                messageResponses: [[
                    error: [
                        code: code,
                        message: "error!",
                        details: [[
                            code: code,
                            message: msg]
                            ]
                    ]
                ]]
            ]
            
        def json = new JsonBuilder(data)
        message.setBody(json.toPrettyString())
    }
    

    message.setHeader("CamelHttpResponseCode", "200")
    return message
}