import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder


def Message processData(Message message) {
    def body = message.getBody(String.class);
    
    def object = new JsonSlurper().parseText(body);
    def newBody = object.mergedresponse[0]

    message.setBody(new JsonBuilder(newBody).toPrettyString())
      
    return message
}