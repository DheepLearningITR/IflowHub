import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    
    def body = message.getBody(String.class) as String;
    def jsonSlurper = new JsonSlurper();
    def invoices = jsonSlurper.parseText(body);
    if(!invoices){
        message.setBody('{"mergedResponses": [ { } ] }')
    }
    
    def logLevel = message.getProperty("LogLevel")
    if (logLevel != "4"){
        return message
    }
    def fileName = message.getProperty("FileName")
    
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
        messageLog.addAttachmentAsString(fileName, body, "text/plain")
     }
    return message;
}