import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def logLevel = message.getProperty("LogLevel")
    if (logLevel != "4"){
        return message
    }
    
    def body = message.getBody(java.lang.String) as String
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
        messageLog.setStringProperty("Logging#1", "Printing Response Payload As Attachment")
        messageLog.addAttachmentAsString("FinalResponsePayload:", body, "text/plain")
     }
    return message;
}