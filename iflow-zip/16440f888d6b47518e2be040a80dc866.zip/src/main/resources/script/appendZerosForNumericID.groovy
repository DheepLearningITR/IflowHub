import com.sap.it.api.mapping.*;



def String appendZerosForNumericID(String productID){
    
    try{
        Long id = Long.parseLong(productID);
        def expectedLength = 18;
        def idLength = productID.length();
        def countZeros = expectedLength - idLength;
        
        for(int i = 0; i< countZeros;i++){
            productID = "0" + productID;
        }
        
    } catch(NumberFormatException e){
        return productID;
    }
    
	return productID 
}