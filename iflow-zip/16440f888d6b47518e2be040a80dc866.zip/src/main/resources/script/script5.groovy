import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.UUID; 
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.*;
import javax.xml.bind.DatatypeConverter;


//Set MessageId(SOAP Header)
def Message processData(Message message) {
    
    def messageId = UUID.randomUUID().toString().toUpperCase();
    message.setProperty("UUID", messageId);
    def Id = messageId.replaceAll("-","");
    message.setProperty("ID",Id);
    
    def now = new Date();
    def creationDateTime =  now.format("yyyy-MM-dd", TimeZone.getTimeZone('UTC'))+"T"+now.format("HH:mm:ss", TimeZone.getTimeZone('UTC'))+"Z";

    message.setProperty("CreationDateTime",creationDateTime);
    
    
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.setStringProperty("Info1", "Remove xml tag if exist..");
    String payload = message.getBody(java.lang.String)
  
  if(payload.contains("?xml")){
	messageLog.setStringProperty("Info1", "Removing xml tag..");
	int i = payload.indexOf('>');
	payload = payload.substring(i+1);
	message.setBody(payload);
  }
  message.setHeader("Content-Type", "text/xml");
    return message;
}