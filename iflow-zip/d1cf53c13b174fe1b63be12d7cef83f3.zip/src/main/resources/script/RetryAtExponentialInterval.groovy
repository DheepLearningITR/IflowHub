/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

def Message processData(Message message) {
    //Body 
      def body = message.getBody();
      def root = new XmlSlurper().parseText(new String(body));
      
    //   RetryInterval
      int[] retryInterval = [1, 2, 4, 8, 16, 32, 64, 120, 180, 240, 300, 360, 420, 480, 540, 600, 660, 720, 780, 840, 900, 960, 1020, 1080, 1140, 1200, 1260, 1320, 1380, 1440];
       
      //Properties 
      map = message.getProperties();
      currentTimeStamp = map.get("currentTime");
       
      def retryIntervalIndex = -1;
      def retryTimeStamps = [];
       
      root.message.children().each { node ->
          retryIntervalIndex++;
          retryTimeStamps.add(node);
        }
        
      retryTimeStamps.sort();
       
      def datePattern = "dd-MM-yyyy HH:mm:ss";
      def retryTime = new SimpleDateFormat(datePattern).parse(retryTimeStamps[0].toString());
      def currentTime = new SimpleDateFormat(datePattern).parse(currentTimeStamp);
       
      long duration = currentTime.getTime() - retryTime.getTime();
      long minutes = TimeUnit.MILLISECONDS.toMinutes(duration);
       
      if(minutes >= retryInterval[retryIntervalIndex]){
          message.setProperty("Retry", "true");
        //   message.setProperty("retryIntervalIndex", retryIndex + 1);
      } else {
          message.setProperty("Retry", "false");
      }
      
      
    //   message.setProperty("Body", new String(body));
      return message;
}