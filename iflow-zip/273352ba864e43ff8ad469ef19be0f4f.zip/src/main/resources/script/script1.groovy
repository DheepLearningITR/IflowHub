import com.sap.gateway.ip.core.customdev.util.Message
import java.util.Map
import org.w3c.dom.Node
import groovy.util.XmlSlurper 
import groovy.xml.XmlUtil

def Message propagateSoapFault(Message message) {
	try {	
		def map = message.getProperties()
		def ex = map.get("CamelExceptionCaught")
		if (ex!=null) {
			String stringEnvelope = '''<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Header/>'''
			stringEnvelope += '''<soap:Body><soap:Fault><faultcode/><faultstring/><detail/></soap:Fault></soap:Body></soap:Envelope>'''
			def xmlEnvelope = new XmlSlurper().parseText(stringEnvelope)
			xmlEnvelope.Body.Fault.faultstring = ex.getMessage()
			if (ex instanceof org.apache.cxf.interceptor.Fault) {
				String stringDetail = ex.getDetail() as String
				xmlEnvelope.Body.Fault.faultcode = ex.getFaultCode().toString()
				if (stringDetail!=null) {
    				def xmlDetail = new XmlSlurper().parseText(stringDetail)
				    xmlDetail.'*'.each{ node -> xmlEnvelope.Body.Fault.detail.appendNode(node) }
				}
				message.setBody(XmlUtil.serialize(xmlEnvelope))
			} else {
                if (ex.getCause()!=null) {
				    xmlEnvelope.Body.Fault.faultcode = ex.getCause().getClass().getCanonicalName()
                } else {
    				xmlEnvelope.Body.Fault.faultcode = ex.getClass().getCanonicalName()
                }
			}
			message.setBody(XmlUtil.serialize(xmlEnvelope))
		}
	} catch (Exception ex01) {
		String exBody = '''<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Header/>'''
			exBody += '<soap:Body><soap:Fault><faultcode>SCPI_GENERAL</faultcode><faultstring>'
			exBody += XmlUtil.escapeXml(ex01.getMessage())
	        StringWriter ex01Sw = new StringWriter();
            ex01.printStackTrace(new PrintWriter(ex01Sw));
			exBody += XmlUtil.escapeXml(ex01Sw.toString())
			exBody += '</faultstring></soap:Fault></soap:Body></soap:Envelope>'
			message.setBody(exBody)
	}
	return message
}