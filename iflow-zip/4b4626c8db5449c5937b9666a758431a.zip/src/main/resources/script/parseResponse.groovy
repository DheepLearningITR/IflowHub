import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;

def Message processData(Message message) {

  def payload = message.getBody(String.class);
  def messageLog = messageLogFactory.getMessageLog(message)

  //Set Headers
	message.setHeader("Authorization", "Bearer" + context.getPropery(Access_token));

     
return message;

}


def String getProperty(String property_name, MappingContext context) {

    def propValue= context.getPropery(property_name);

    return propValue;

}