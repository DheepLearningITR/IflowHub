import com.sap.it.api.mapping.*;

def String getProductDescription(String productDescTextField, String value, MappingContext context)
{
	def descriptionTextId = "0001";

    if(productDescTextField != null && 
	productDescTextField.trim().length() > 0 && 
	value != null && 
	value.trim().length() > 0 &&
	productDescTextField == descriptionTextId){
		
		return value;
		   
    }
 	
	return "";
}