/*
Delay Message
 */
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    
    def sleepTime = Integer.parseInt(message.getProperty("SleepTime"))
    
    sleep(sleepTime * 1000)
    
    return message
}

def Message addAttachment(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message)
    String messageBody = message.getBody(String)

    messageLog.addAttachmentAsString("Exception", messageBody, "application/xml")
    
    return message
    
}