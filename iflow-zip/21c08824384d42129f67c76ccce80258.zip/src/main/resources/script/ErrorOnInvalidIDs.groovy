import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	throw (new Exception("External Code(s) for Employee Time Data (sourceGenericObjectExternalCode) and/or Data Replication Proxy objects (externalCode) are invalid. They must not be longer than 32 characters. Please change IDs in SAP SuccessFactors"));	
}

