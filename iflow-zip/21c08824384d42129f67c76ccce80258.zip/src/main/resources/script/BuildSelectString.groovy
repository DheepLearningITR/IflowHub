import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	//Properties  
	def map = message.getProperties();
	countrySpecificFields = map.get("ENABLE_COUNTRY_SPECIFIC_FIELDS");
	
	if (null != countrySpecificFields && countrySpecificFields.toUpperCase().equals("TRUE")) {
	    message.setProperty("SELECT_STRING", "\$select=userId,replicationContentType,legalEntity,externalCode,sourceGenericObjectExternalCode,dataReplicationProxyStatus,allowReplicationInCorrectionPhase,employeeTimeNav/startDate,employeeTimeNav/quantityInHours,employeeTimeNav/quantityInDays,employeeTimeNav/externalCode,employeeTimeNav/endDate,employeeTimeNav/approvalStatus,employeeTimeNav/timeTypeNav/externalCode,employeeTimeNav/countryExtensionDEU/continuedPayCreditedDays,employeeTimeNav/countryExtensionDEU/identicalSicknessGroup,employeeTimeNav/countryExtensionDEU/overlappingSicknessGroup,employeeTimeNav/countryExtensionDEU/continuedPayEndDate,employeeTimeNav/countryExtensionDEU/paySupplementStartDate,employeeTimeNav/countryExtensionDEU/paySupplementEndDate,employeeTimeNav/countryExtensionDEU/sicknessCertificateStartDate,employeeTimeNav/countryExtensionESP/identicalSicknessGroup,employeeTimeNav/countryExtensionESP/originalAbsence,employeeTimeNav/countryExtensionMEX/identicalSicknessGroup,employeeTimeNav/countryExtensionMEX/referenceNumber,employeeTimeNav/countryExtensionMEX/daysAlreadyCumulatedForSameSickness,employeeTimeNav/countryExtensionCOL/identicalSicknessGroup,employeeTimeNav/countryExtensionDEU/electronicSicknessCertificateExclusionReason&\$expand=employeeTimeNav,employeeTimeNav/timeTypeNav,employeeTimeNav/countryExtensionDEU,employeeTimeNav/countryExtensionESP,employeeTimeNav/countryExtensionMEX,employeeTimeNav/countryExtensionCOL");
	} else {
		message.setProperty("SELECT_STRING", "\$select=userId,replicationContentType,legalEntity,externalCode,sourceGenericObjectExternalCode,dataReplicationProxyStatus,allowReplicationInCorrectionPhase,employeeTimeNav/startDate,employeeTimeNav/quantityInHours,employeeTimeNav/quantityInDays,employeeTimeNav/externalCode,employeeTimeNav/endDate,employeeTimeNav/approvalStatus,employeeTimeNav/timeTypeNav/externalCode&\$expand=employeeTimeNav,employeeTimeNav/timeTypeNav");
	}
	
	return message;
}

