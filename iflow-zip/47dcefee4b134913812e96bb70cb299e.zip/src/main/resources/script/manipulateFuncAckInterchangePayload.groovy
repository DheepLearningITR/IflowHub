import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.regex.Pattern;

// History: 
// 2024-04-10 SAP [MÖ] - Take Properties from TPA
// 2024-03-20 SAP [MÖ] - Decision route for UCI segment
// 2024-02-19 SAP [MÖ] - Further extensions for UNB segment AND UCI segment
// 2024-02-13 SAP [MÖ] - Take Interchange Control Number from Func Ack Number Range
// 2024-02-12 SAP [MÖ] - Initial creation to truncate UNB segment

def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String) as String;
    // /Remove unwanted new lines
    def body_temp = body.replace("\n", "");

    def headers   = message.getHeaders();
	def uciModification = message.getProperty("SAP_EDI_EDIFACT_Functional_Acknowledgment_Interchange_UCI_Modification");
    def ediSyntaxIdentifier = headers.get("EDI_Syntax_Identifier");
    def ediFuncSyntaxIdentifier = message.getProperty("SAP_EDIFACT_Functional_Ack_Syntax_Identifier");
    def ediSyntaxVersionNumber = headers.get("EDI_Syntax_Version_Number");
    def ediSenderId = headers.get("EDI_Sender_ID");
    def ediSenderIdQualifier = headers.get("EDI_Sender_ID_Qualifier");
    def ediFuncSenderIdQualifier = message.getProperty("SAP_EDIFACT_Functional_Ack_Sender_ID_Qualifier");
    def ediReceiverId = headers.get("EDI_Receiver_ID");
    def ediReceiverIdQualifier = headers.get("EDI_Receiver_ID_Qualifier");
    def ediFuncReceiverIdQualifier = message.getProperty("SAP_EDIFACT_Functional_Ack_Receiver_ID_Qualifier");
    def ediInterchangeControlNumber = headers.get("SAP_EDI_Interchange_Control_Number");
    def ediSenderMessageReferenceNumber = headers.get("SAP_EDI_REC_Sender_Message_Reference_Number");

    
    if (ediFuncSyntaxIdentifier != null) {
        ediSyntaxIdentifier = ediFuncSyntaxIdentifier;

    }
        if (ediFuncSenderIdQualifier != null) {
        ediSenderIdQualifier = ediFuncSenderIdQualifier;

    }
        if (ediFuncReceiverIdQualifier != null) {
        ediReceiverIdQualifier = ediFuncReceiverIdQualifier;

    }
    
    def compsiteSeparator, dataElementSeparator, decimalSeparator, releaseCharacter, repet, segmentSeparator;
        try {
          // read meta from message which should work if UNA segment present
          (_, compsiteSeparator, dataElementSeparator, decimalSeparator, releaseCharacter, repet, segmentSeparator) = (body_temp =~ (/UNA([^A-Z])([^A-Z])([^A-Z])([^A-Z])([^A-Z])?([^A-Z])/))[0]
        } catch (Exception e) {
          // when reading from UNA fails, assume default meta
          (_, compsiteSeparator, dataElementSeparator, decimalSeparator, releaseCharacter, repet, segmentSeparator) = ["", ":", "+", ".", "?", "", "'"];  

        }
    def originalReleaseCharacter = releaseCharacter;
        
        // Construct regex
        segmentSeparator = "\\" + segmentSeparator;                 // '
        releaseCharacter = "\\" + releaseCharacter;                 // ?
        compsiteSeparator = "\\" + compsiteSeparator;               // :
        dataElementSeparator = "\\" + dataElementSeparator;         // +
        any_separator = dataElementSeparator + compsiteSeparator + segmentSeparator;
        
        //Get the Date and the time from UNB segment
    def ediTimeZone="";   
        try {
            ediTimeZone = (body_temp =~ /UNB${dataElementSeparator}[A-Z]{4}${compsiteSeparator}[0-9]{1}${dataElementSeparator}[^A-Z]{1,35}${compsiteSeparator}[A-Z0-9]{1,4}${dataElementSeparator}[^A-Z]{1,35}${compsiteSeparator}[A-Z0-9]{1,4}${dataElementSeparator}([0-9]{6})/)[0][1];
            message.setHeader("SAP_EDI_REC_Set_Timezone", ediTimeZone);
        } catch (Exception e) {
            message.setHeader("SAP_EDI_REC_Set_Timezone", ediTimeZone);
        }
        def ediTimeOfPreparation = "";
        try {
            ediTimeOfPreparation = (body_temp =~ /UNB${dataElementSeparator}[A-Z]{4}${compsiteSeparator}[0-9]{1}${dataElementSeparator}[^A-Z]{1,35}${compsiteSeparator}[A-Z0-9]{1,4}${dataElementSeparator}[^A-Z]{1,35}${compsiteSeparator}[A-Z0-9]{1,4}${dataElementSeparator}[0-9]{6}${compsiteSeparator}([0-9]{4})/)[0][1];
            message.setHeader("SAP_EDI_REC_Timepreparation", ediTimeOfPreparation);
        } catch (Exception e) {
            message.setHeader("SAP_EDI_REC_Timepreparation", ediTimeOfPreparation);
        }
        
        body = body.replace("'", "'\n");
        
        
        def unb_segment = "";
        
        unb_segment= "UNB" + "+" + ediSyntaxIdentifier +":" + ediSyntaxVersionNumber + "+" + ediSenderId + ":" + ediSenderIdQualifier +"+"+ ediReceiverId + ":" + ediReceiverIdQualifier + "+" + ediTimeZone + ":" +  ediTimeOfPreparation + "+" + ediInterchangeControlNumber +"'"
        
        body = body.replaceAll("UNB.*", unb_segment);
        
        if (uciModification == "true"){
        def uci_first_value = "";
        try {
            uci_first_value = (body_temp =~ /UCI${dataElementSeparator}([a-zA-Z0-9]{1,35})/)[0][1]; 
        } catch (Exception e) {
        }
        def uci_second_value = "";
        try {
            uci_second_value = (body_temp =~ /UCI${dataElementSeparator}[a-zA-Z0-9]{1,35}${dataElementSeparator}([a-zA-Z0-9]{1,35})/)[0][1]; 
        } catch (Exception e) {
        }   
         uci_segment = "UCI"+ "+" + uci_first_value + "+" + uci_second_value+ ":"+ ediReceiverIdQualifier +"+"+ ediSenderId + ":" + ediSenderIdQualifier + "+" + "7" + "'"
         body = body.replaceAll("UCI.*", uci_segment);
            
        }

       body = body.replace("'\n", "'");

       
    
    message.setBody(body);
    
    return message;
}
