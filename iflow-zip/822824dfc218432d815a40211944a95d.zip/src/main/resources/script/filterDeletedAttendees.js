/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
       //body
      var body = message.getBody( new java.lang.String().getClass() );
      var jsonBody = JSON.parse(body);
      var result = jsonBody.attendees.filter(function(attendee){
          if (attendee.userstatus == "deleted")
            return false;
          else
            return true;
          
      });
      jsonBody.attendees = result;
      jsonBody.totalattendees = result.length;
      message.setBody(JSON.stringify(jsonBody));
     return message;
}