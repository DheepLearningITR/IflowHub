import com.sap.gateway.ip.core.customdev.util.Message
import org.json.JSONObject
import org.json.XML

def Message processData(Message message) {
  def body = message.getBody(String.class)
  JSONObject attributeGroup = (XML.toJSONObject(body)).attributeGroup
  StringBuilder filterQuery = new StringBuilder("")

  if (attributeGroup.opt("id")) {
    message.setProperty("operation", "PUT")
    filterQuery.append("/").append(attributeGroup.id)
  } else {
    message.setProperty("operation", "POST")
  }

  if (attributeGroup.attributes instanceof JSONObject) {
    attributeGroup.put("attributes", [attributeGroup.attributes])
  }

  if (attributeGroup.descriptions instanceof JSONObject) {
    attributeGroup.put("descriptions", [attributeGroup.descriptions])
  }

  attributeGroup.remove("id")
  message.setProperty("attributeGroupID", filterQuery)
  message.setProperty("payload", attributeGroup.toString(2))
  return message
}