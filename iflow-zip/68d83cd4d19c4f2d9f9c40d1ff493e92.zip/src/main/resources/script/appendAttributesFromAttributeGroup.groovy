import com.sap.gateway.ip.core.customdev.util.Message
import org.json.JSONArray
import org.json.JSONObject

def Message processData(Message message) {

  JSONObject attributeGroupsResponse = new JSONObject(message.getBody(String.class))
  JSONObject payload = new JSONObject(message.getProperty("payload"))
  JSONArray attributes = payload.attributes
  Set attributesIdSet = []
  attributes.each {
    attribute ->
      attributesIdSet.add(attribute.id)
  }
  if (attributeGroupsResponse.has("attributes")) {
    attributeGroupsResponse.attributes.each {
      attribute ->
        attributesIdSet.add(attribute.id)
    }
  }

  JSONArray allAttributes = new JSONArray()
  attributesIdSet.each { id ->
        allAttributes.put(new JSONObject('''{"id": "''' + id + '''"}'''))
  }
  payload.put("attributes", allAttributes)
  message.setProperty("payload", payload.toString(2))

  return message
}