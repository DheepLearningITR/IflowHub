import com.sap.gateway.ip.core.customdev.util.Message
import org.json.JSONArray
import org.json.JSONObject

def Message processData(Message message) {
  String body = message.getBody(String.class)
  JSONArray attributeResponse = new JSONArray(body)
  String templateStr = message.getProperty("template").toString()

  for (attribute in attributeResponse) {
    StringBuilder toBeReplaced = new StringBuilder()
    StringBuilder withThis = new StringBuilder()
    toBeReplaced.append("\"internalId\":\"").append(attribute.internalId)
    withThis.append("\"id\": \"").append(attribute.id)
    templateStr = templateStr.replaceAll(toBeReplaced.toString(), withThis.toString())
  }

  JSONObject templateJson = new JSONObject(templateStr)

  message.setProperty("invalidAttributeIsThere", false)
  def invalidAttribute = []
  for (attributeGroup in templateJson.attributeGroups) {
    for (attribute in attributeGroup.attributes) {
      if (attribute.opt("internalId")) {
        invalidAttribute.add(attribute.internalId)
      }
    }
  }

  if (!invalidAttribute.isEmpty()) {
    message.setProperty("invalidAttributeIsThere", true)
    StringBuilder invalidAttributeStr = new StringBuilder()
    invalidAttribute.each {
      it ->
        invalidAttributeStr.append(it).append(', ')
    }
    message.setProperty("InvalidAttribute", invalidAttributeStr.substring(0, invalidAttributeStr.length() - 2))
  }

  // Prepate filterQuery for Template
  StringBuilder templateFilterQuery = new StringBuilder()
  templateFilterQuery.append('''?$filter=''' + "internalId eq '").append(templateJson.internalId).append("'")

  message.setProperty("templateFilterQuery", templateFilterQuery)
  message.setProperty("templateExternalID", templateJson.internalId)
  message.setProperty("template", templateJson)

  return message
}