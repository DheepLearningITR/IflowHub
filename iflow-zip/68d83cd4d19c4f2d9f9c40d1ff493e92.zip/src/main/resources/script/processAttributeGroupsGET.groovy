import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import org.json.JSONArray
import org.json.JSONObject
import org.json.XML

def Message processData(Message message) {

  JSONArray attributeGroupsResponse = new JSONArray(message.getBody(String.class))
  JSONArray attributeGroupsJson = message.getProperty("template").attributeGroups

  // Set default AttributeId
  attributeGroupsJson.each {
    attributeGroup ->
      attributeGroup.put("templateId", message.getProperty("templateID"))
    attributeGroup.put("id", " ")
  }

  // Prepare Set to get attributes and append for PUT operation

  // Append Attribute Group ID
  attributeGroupsResponse.each {
    attributeGroupResponse ->
      attributeGroupsJson.each {
        JSONObject attributeGroup ->
          if (attributeGroupResponse.internalId == attributeGroup.internalId) {
            attributeGroup.put("id", attributeGroupResponse.id)
          }
      }
  }

  Set idsToDelete = []
  attributeGroupsJson.each {
    JSONObject attributeGroup ->
      if (attributeGroup.id == " ") {
        idsToDelete.add(attributeGroup.internalId)
      }
  }

  // Setting up XML for Splitter
  JSONObject attributeGroupsObj = new JSONObject().put("attributeGroup", attributeGroupsJson)
  StringBuilder attributeGroupsXMLStr = new StringBuilder()
  attributeGroupsXMLStr.append(XML.toString(attributeGroupsObj, "attributeGroups"))
  def attributeGroupsXML = XmlUtil.serialize(attributeGroupsXMLStr.toString())
  message.setProperty("attributeGroupsXML", attributeGroupsXML)

  // Set Properties for error handling
  message.setProperty("isAttributeGroupCreatedInFlow", false)
  if (!idsToDelete.isEmpty()) {
    message.setProperty("isAttributeGroupCreatedInFlow", true)
  }
    
  if (!message.getProperty("isTemplateCreatedInFlow")){
    message.setProperty("isAttributeGroupCreatedInFlow", false)    
  }
  message.setProperty("idsToDelete", idsToDelete)

  return message
}