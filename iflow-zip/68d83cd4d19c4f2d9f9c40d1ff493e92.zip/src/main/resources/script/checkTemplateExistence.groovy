import com.sap.gateway.ip.core.customdev.util.Message
import org.json.JSONArray
import org.json.JSONObject

def List addJsonObjToArr(Object object) {
  def arr = []
  for (obj in object) {
    arr.add(obj)
  }
  return arr
}

def Message processData(Message message) {

  JSONArray templateResponse = new JSONArray(message.getBody(String.class))

  if (templateResponse.isEmpty()) {
    message.setProperty("isTemplateCreatedInFlow", true)

    JSONObject templatePayload = message.getProperty("template")
    JSONObject templatePayloadForAIN = new JSONObject()
    templatePayloadForAIN.put("internalId", templatePayload.internalId)
    templatePayloadForAIN.put("descriptions", addJsonObjToArr(templatePayload.descriptions))
    templatePayloadForAIN.put("type", "4")
    message.setProperty("equipmentTemplateCreatePayload", templatePayloadForAIN.toString(4))
  } else {
    message.setProperty("templateID", templateResponse[0]["id"])
  }

  return message
}