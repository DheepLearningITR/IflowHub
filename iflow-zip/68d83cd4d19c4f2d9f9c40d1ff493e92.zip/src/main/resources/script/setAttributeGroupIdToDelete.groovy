import com.sap.gateway.ip.core.customdev.util.Message
import org.json.JSONArray
import org.json.JSONObject

def Message processData(Message message){

    JSONArray createdAttributeGroups = new JSONArray(message.getBody(String.class))

    StringBuilder idsToDelete = new StringBuilder()
    createdAttributeGroups.each {JSONObject attributeGroup->
        idsToDelete.append(attributeGroup.id + "\n")
    }
    message.setProperty("idsToDelete", idsToDelete.toString().stripIndent())
    println(idsToDelete)
    return message
}