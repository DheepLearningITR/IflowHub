import com.sap.gateway.ip.core.customdev.util.Message
import org.json.JSONArray

def Message processData(Message message) {
  JSONArray templateResponse = new JSONArray(message.getBody(String.class))
  message.setProperty("templateID", templateResponse[0]["id"])

  JSONArray attributeGroups = message.getProperty("template").attributeGroups
  Set attributeGroupInternalIdSet
  attributeGroupInternalIdSet = []

  for (attributeGroup in attributeGroups) {
    attributeGroupInternalIdSet += attributeGroup.internalId.toString()
  }

  StringBuilder attributeGroupsFilterQuery = new StringBuilder()

  attributeGroupsFilterQuery.append('''?$filter= ''')

  attributeGroupInternalIdSet.each {
    internalId ->
      attributeGroupsFilterQuery.append("internalId eq '").append(internalId).append("' or ")
  }

  message.setProperty("attributeGroupFilterQuery", attributeGroupsFilterQuery.substring(0, attributeGroupsFilterQuery.length() - 3))

  return message
}