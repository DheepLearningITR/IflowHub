import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message)
{
    throw new Exception("Invalid Attributes in Request")  
}