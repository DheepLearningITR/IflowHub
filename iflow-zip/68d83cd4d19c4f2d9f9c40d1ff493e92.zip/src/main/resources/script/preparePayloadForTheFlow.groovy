import com.sap.gateway.ip.core.customdev.util.Message
import org.json.JSONArray
import org.json.JSONObject
import org.json.XML

def static getArrayOf(Object obj) {
  if (obj instanceof JSONObject) {
    JSONArray arr = new JSONArray()
    arr.put(obj)
    return arr
  }
  
  return new JSONArray(obj)
}

def Message processData(Message message) {
    
  def body = message.getBody(String.class)
  def templateJson = XML.toJSONObject(body).root.template
  
  JSONArray attributeGroupsArr = getArrayOf(templateJson.opt("attributeGroups"))

  Set allAttributesInternalIdSet = []

  for (attributeGroup in attributeGroupsArr) {
    def attributesSet = getArrayOf(attributeGroup.attributes) as Set
    for (attribute in attributesSet) {
      allAttributesInternalIdSet += attribute.internalId
    }
  }

  def filterQuery = new StringBuilder().append('?$filter= ')
  
  for (attributeInternalID in allAttributesInternalIdSet) {
    filterQuery.append("internalId eq '").append(attributeInternalID).append("' or ")
  }
  
  filterQuery = filterQuery.substring(0, filterQuery.length() - 3)

  templateJson.put("attributeGroups", attributeGroupsArr)

  message.setProperty("attributeFilterQuery", filterQuery.toString())
  message.setProperty("template", templateJson)
  message.setProperty("isTemplateCreatedInFlow", false)
  message.setProperty("isAttributeGroupCreatedInFlow", false)
  
  return message
}