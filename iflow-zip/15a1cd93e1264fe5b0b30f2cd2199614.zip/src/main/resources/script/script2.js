importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
            var body = message.getBody();
            var date = Number(new Date());
            message.setProperty("Timestamp", date);
            message.setProperty("AccessToken", body);
     return message;
}