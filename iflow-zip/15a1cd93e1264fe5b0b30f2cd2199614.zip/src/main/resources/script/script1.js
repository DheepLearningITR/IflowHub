importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
		    //properties
            map = message.getProperties();
            value = map.get("Timestamp");
            value_int = Number(value);
            var dateold = new Date(value_int);
            var datenew = new Date();
            datenew.setMinutes(datenew.getMinutes() - 90);
            if (datenew<dateold){
                message.setProperty("TokenExp", "false");
            }
            else{
                message.setProperty("TokenExp", "true");
            }
     return message;
}