import com.sap.gateway.ip.core.customdev.util.Message

def processData(Message message) {
    // Check if the message body is XML
    def isXMLBody = isValidXMLBody(message)

    // Set the property to indicate if the body is XML
    message.setProperty('UseXsltHandling', isXMLBody.toString().capitalize())


    // Based on a HashMap return which XSLT to call
    if(isXMLBody){
        HashMap<String, String> xsltMap = [
                "Init"           : "HandleInitResponse.xsl",
                "CreateBatches"  : "HandleCreateBatchesResponse.xsl",
                "Fetch"          : "HandleFetchResponse.xsl",
                "PostFilter"     : "",
                "Mapping"        : "",
                "PostData"       : "HandlePostDataResponse.xsl",
                "Close"          : "HandleCloseResponse.xsl",
                "PostProcessing" : "HandleProcessPostedResponse.xsl"
        ]
        if(xsltMap.get(message.getProperty("Stage")) != ""){
            message.setProperty('XSLTExceptionHandling', "mapping/${xsltMap.get(message.getHeader("Stage",String))}")
        }else{
            message.setProperty('UseXsltHandling', "False")
        }

    }else{
        message.setBody("<Root/>")
    }

    return message
}

def boolean isValidXMLBody(Message message) {
    def body = message.getBody(java.io.Reader)
    try {
        new XmlSlurper().parse(body)
        return true
    } catch (Exception e) {
        return false
    }
}