import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;

def Message addMessagesToAttachment(Message message) {
    def properties = message.getProperties();
    String status = properties.get("Status") ?: '';
    def trace = properties.get("DetailedTraceLog");
    
    if ((status == "NoData") || (trace != null && trace.toUpperCase() == "TRUE")) {
        String noDataMessage = "There was no data in the system to transfer."
        def messageLog = messageLogFactory.getMessageLog(message);
            if (messageLog != null) {
                messageLog.addCustomHeaderProperty('No Data Message', noDataMessage)
            }
    }
    
    return message;
}