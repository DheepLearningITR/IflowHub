import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    // Get the JSON data from the DataToWrite property
    def jsonString = message.getBody(java.io.Reader)

    // Parse the JSON
    def slurper = new JsonSlurper()
    def data = slurper.parse(jsonString)

    // Get the mapping configuration from headers
    def IBPFieldList = message.getHeaders().get("IBPFieldList")
    String FieldMap = message.getHeaders().get("FieldMap")

    // Split the fields and create the FieldMap
    def IBPFieldListArray = IBPFieldList.split(",")
    HashMap<String,String> FieldMapReverse = [:]
    def FieldHashMap = [:]
    List<String> fieldsToAdd = []
    FieldMap.split(",").each {
        def parts = it.split(":")
        if(parts.size() > 1 ){
            FieldMapReverse.put((parts[1]), parts[0])
            FieldHashMap.put((parts[0]), parts[1])
        }
    }

    IBPFieldListArray.each { it ->
        def tmpVal = FieldMapReverse.get(it);
        if(tmpVal == null){
            fieldsToAdd.add(it as String)
        }
    }
    
    if( data.ITEMS != null && data.ITEMS.size() != 0){
        data.ITEMS[0].each {key, value -> fieldsToAdd.remove(key)}
    
        // Process each item in the ITEMS array
        data.ITEMS.each { item ->
            // Apply field mapping
            FieldHashMap.each { source, target ->
                if(source.matches('^\".*\"$')){
                    item[target] = source.substring(1,source.size() - 1)
                } else if (item.containsKey(source)) {
                    item[target] = item.remove(source)
                }
            }
    
            fieldsToAdd.each{item.put(it,'')}
    
            // Remove fields not in IBPFieldList
            item.keySet().removeAll { !(it in IBPFieldListArray) }
        }
    }

    // Convert the modified data back to JSON
    def json = new JsonBuilder(data);
    String newJsonData = json.toPrettyString();

    // Set the modified JSON as the new body
    message.setBody(newJsonData)

    return message
}