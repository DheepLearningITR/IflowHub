import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.LinkedHashMap;

def Message processData(Message message) {

    mergeHeaders(message);

    List<String> mandatoryParameters = ["ERPDestination","DestinationforSAPIBP","DestinationforSAPIBP","PlanningArea","Extractor","BatchCommand","BatchName","TypeOfData","IBPFieldList","BatchKey"];
    if(message.getHeader("TypeOfData",String).toUpperCase() == 'KEYFIGURES'){
        mandatoryParameters.add("TimeDisaggregationLevel")
    }
    else if(message.getHeader("TypeOfData",String).toUpperCase() == 'MASTERDATA'){
        mandatoryParameters.addAll("MasterDataPrefix","MasterDataType")
    }
    else{
        throw new InvalidParameterException("TypeOfData parameter must have the value MasterData or KeyFigures");
    }

    mandatoryParameterValidation(message,mandatoryParameters);

    validateFieldMap(message.getHeader("FieldMap",String))

    List<String> extensions = ["MappingExtensionID","PostFetchFilterExtensionID"]
    extensions.each {   validateExtensionID(message, it)}

    return message
}

def mergeHeaders(Message message){
    //Headers
    def headers = message.getHeaders();
    LinkedHashMap<String,Object> newHeaders = [:];
    Set<String> keys = headers.keySet();

    for (String key : keys) {
        if (key.startsWith('Default_')) {
            def newHeaderName = key.substring(key.indexOf('_') + 1);
            def newHeader = headers.get(newHeaderName);
            def defaultHeader = key.startsWith('Default_') ? null : headers.get('Default_' + newHeaderName);
            if ( (newHeader == '-keep default-' || newHeader == null )
                    && ( defaultHeader == '-keep default-' || defaultHeader == null ) )
            {
                newHeaders.put(newHeaderName,headers.get(key));
            }
            newHeaders.put(key,null);
        }
    }

    Set headerSet = newHeaders.entrySet();
    Iterator it = headerSet.iterator();
    while (it.hasNext()) {
        def header = it.next();
        message.setHeader(header.key,header.value);
    }
    headers = message.getHeaders();
    headers.findAll{it.value instanceof String ? it.value.matches(/^-copy from .+-$/) : false}.each {
        def sourceHeader = it.value.substring(11,it.value.length()-1);
        message.setHeader(it.key,headers.get(sourceHeader));
    }
}

def validateFieldMap(String fieldMap){
    if(!fieldMap.matches("(?<=(^))(?:(?:[^:\\n\\r,]+|(?:\"(?:[^\":\\n\\r,]+|\"\")*\")):(?:[^:\\n\\r,]+|(?:\"(?:[^\":\\n\\r,]+|\"\")*\"))+(?:,|\$))+(?=(\$))")){
        throw new InvalidParameterException("Field Map parameter is invalid");
    }
}

def mandatoryParameterValidation(Message message,List<String> mandatoryParameters){
    def headerMap = message.getHeaders()

    def mandatoryParametersWithoutValues = []

    mandatoryParameters.each { it ->
        def currItem = headerMap.get(it).toString();

        if(currItem == null || currItem == '' ){
            mandatoryParametersWithoutValues.add(it)
        }
    }

    if(mandatoryParametersWithoutValues.size() > 0){
        throw new MandatoryParameterException("Mandatory Parameter(s) ${mandatoryParametersWithoutValues.join(',')} do(es) not have value(s)")
    }

}

class MandatoryParameterException extends Exception {
    //Custom exception for mandatory parameters
    MandatoryParameterException(String message) {
        super(message);
    }
}

class InvalidParameterException extends Exception {
    //Custom exception for mandatory parameters
    InvalidParameterException(String message) {
        super(message);
    }
}

// The validation is based on the https://help.sap.com/docs/cloud-integration/sap-cloud-integration/configure-processdirect-receiver-adapter
// Simple expressions should already be evaluated
def validateExtensionID(Message message, String extensionID) {
    if (extensionID) {
        def extensionIDValue = message.getHeader(extensionID, String)
        if (!(extensionIDValue == null || extensionIDValue == '' ||extensionIDValue.matches('^/?[A-Za-z0-9_-]+$'))) {
            throw new InvalidParameterException("${extensionID} parameter with value ${extensionIDValue} is not a well formatted extension ID");
        }
    }
}



