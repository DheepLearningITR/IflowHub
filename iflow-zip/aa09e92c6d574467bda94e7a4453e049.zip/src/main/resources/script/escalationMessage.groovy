import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;


def Message giveEscalationMessage(Message message) {
    //Throw a custom exception and set an escalation message based on status and the existence of fetch messages
    def messageLog = messageLogFactory.getMessageLog(message);
    def bodyAsString = message.getBody(java.lang.String);
    def properties = message.getProperties();
    def headers = message.getHeaders();
    String correlationID = headers.get("SAP_MplCorrelationId") ?: '';
    String fetchMessages = properties.get("FetchMessages") ?: '';
    String initMessages = properties.get("InitMessages") ?: '';

    if (messageLog != null) {
        String status = getStatus(message)
        String escalationMessage = "There was a error during the read process, check the logs for Correlation ID: " + correlationID + " "
        if (initMessages != '') {
            try {
                //Expectation is that the status is the worst one so we rethrow the worst message type
                escalationMessage = getFirstInitMessageWithTypeMatchingStatus(message, status)
            }
            catch (Exception e) {
                throw new Exception(e.getMessage());
            }
            throw new InitException(escalationMessage);
        }
        else if (fetchMessages != '') {
            try {
                //Expectation is that the status is the worst one so we rethrow the worst message type
                escalationMessage = getFirstFetchMessageWithTypeMatchingStatus(message, status)
            }
            catch (Exception e) {
                throw new Exception(e.getMessage());
            }
            throw new AddonFetchException(escalationMessage);
        }
        else {
            switch (status) {
                //Finished case is only executed when the method is called from the first status check, 
                //so it should not cause problems when called after fetch messages
                case "Finished":
                    escalationMessage = "The fetch process finished there is no more data in the system"
                    break
            }
            messageLog.addCustomHeaderProperty("Escalation message", escalationMessage);
            messageLog.addAttachmentAsString('Body before escalation:', bodyAsString, 'text/xml')
            throw new Exception(escalationMessage);
        }

    }
    messageLog.addAttachmentAsString('Body before error', bodyAsString, 'text/xml')
    return message;
}

def String getStatus(Message message) {
    //Returns the status of the iflow property has a higher priority compared to body
    String status = message.getProperty('Status') ?: ''
    if (status != '') {
        return status
    } else {
        def parsedBody = new XmlSlurper().parse(message.getBody(java.io.Reader));
        return parsedBody?.@Status?.text()
    }
}

def String getFirstFetchMessageWithTypeMatchingStatus(Message message, String status) {
    //Get the first message with the given type
    def parsedFetchMessages = new XmlSlurper().parseText("<Messages>" + (message.getProperty('FetchMessages') as String)  + "</Messages>")
    def firstFetchMessageWithTypeMatchingStatus = parsedFetchMessages?.'**'?.find { it -> it.name() == 'Message' && it.@Type.text() == status && it.text() != "" }

    return firstFetchMessageWithTypeMatchingStatus.text()
}

public class AddonFetchException extends Exception {
    //Custom exception for fetch
    public AddonFetchException(String message) {
        super(message);
    }
}

def String getFirstInitMessageWithTypeMatchingStatus(Message message, String status) {
    //Get the first message with the given type
    def parsedInitMessages = new XmlSlurper().parseText("<Messages>" + (message.getProperty('InitMessages') as String)  + "</Messages>")
    def firstInitMessageWithTypeMatchingStatus = parsedInitMessages?.'**'?.find { it -> it.name() == 'Message' && it.@Type.text() == status && it.text() != "" }

    return firstFetchMessageWithTypeMatchingStatus.text()
}

public class InitException extends Exception {
    //Custom exception for init
    public InitException(String message) {
        super(message);
    }
}