import com.sap.gateway.ip.core.customdev.util.Message;
import org.apache.camel.StreamCache;

def Message processData(Message message) {
	// Fix for Camel 3.x: 
	// originalPayload is initialized with the content of ${in.body} at the start of the iFlow.
	// It is an instance of InputStreamCache. Due to the handling of this object in Camel 3.x,
	// and the processing of the message body content in the iFlow, 
	// the stream pointer must be reset to the start of the stream in order to retrieve the contents of originalPayload.
    def cachedBodyContent = message.getProperty("originalPayload");
    if(cachedBodyContent instanceof StreamCache){
        cachedBodyContent.reset();
    }
    return message;
}
