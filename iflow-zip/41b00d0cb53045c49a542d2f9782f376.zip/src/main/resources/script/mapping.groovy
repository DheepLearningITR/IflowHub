import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import java.net.URI;
import com.sap.it.op.agent.mpl.*;

@Field String FIELD_EXTERNAL_ID_TYPE_CODE = "externalIdTypeCode";
@Field String EXTERNAL_ID_TYPE_CODE_ERPCUSTOMER_202 = "202";
@Field String EXTERNAL_ID_TYPE_CODE_ERPCUSTOMER_203 = "203";
@Field String FIELD_EXTERNAL_SYSTEM_ID = "externalSystemId";
@Field String EXTERNAL_ID_TYPE_CODE_ORDER_ID = "sap.c4.distributed-order-management.order.id";
@Field String EXTERNAL_ID_TYPE_CODE_ORDER_DISPLAY_ID = "sap.c4.distributed-order-management.order.displayId";
@Field String EXTERNAL_ID_TYPE_CODE_ITEM_ID = "sap.c4.distributed-order-management.order.item.id";
@Field String EXTERNAL_ID_TYPE_CODE_ITEM_NUMBER = "sap.c4.distributed-order-management.order.item.number";
@Field String ITEM_TYPE_SUBSCRIPTION = 'SUBSCRIPTION';

//Payment method - Central Order
//API - https://api.sap.com/api/OrderManagement/resource
@Field String CO_PAYMENT_METHOD_INVOICE = "INVOICE";
@Field String CO_PAYMENT_METHOD_CARD = "PAYMENT_CARD";
@Field String CO_PAYMENT_METHOD_EXTERNAL = "EXTERNAL_PAYMENT";

//Payment method - Subscription Billing
//API - https://api.sap.com/api/Subscription_APIs/resource
@Field String SB_PAYMENT_METHOD_INVOICE = "Invoice";
@Field String SB_PAYMENT_METHOD_CARD = "Payment Card";
@Field String SB_PAYMENT_METHOD_EXTERNAL = "External Card";

class ExternalObjectReference {
    String externalId
    String externalIdTypeCode
    String externalSystemId
}

class Product {
	String id
	String code
}

class Item {
    String itemId
    String lineNumber
    List<ExternalObjectReference> externalObjectReferences
    Product product
    String numberOfWaiverPeriods
    RatePlan ratePlan
}

class Snapshot {
    String effectiveDate
    List<Item> items
}

class RatePlan {
    String id
}

def Message mapPayload(Message message) {
	
    String body = message.getBody(java.lang.String);
    
	if(body != null && body.trim()) {
		message.setHeader("Content-Type", "application/json");
		def bodyJson = new JsonSlurper().parseText(body);
		
		String fulfillmentRequestId = bodyJson.fulfillmentRequestId;		
	 
		def sbPayload = [:];
		def externalObjectReferenceCustomer = [:];

		def customerNumber = bodyJson.customer.fulfillmentSystemReference.id;
		externalObjectReferenceCustomer.externalId = customerNumber;
		externalObjectReferenceCustomer.externalSystemId = bodyJson.customer.fulfillmentSystemReference.systemId;
		externalObjectReferenceCustomer.externalIdTypeCode = is10Numeric(customerNumber) ? EXTERNAL_ID_TYPE_CODE_ERPCUSTOMER_203 : EXTERNAL_ID_TYPE_CODE_ERPCUSTOMER_202;
		
		sbPayload.customer = [:];
		sbPayload.customer["externalObjectReference"] = externalObjectReferenceCustomer;

		sbPayload.market = [:];
		sbPayload.market["id"] = bodyJson.market.marketId;
		
		List<ExternalObjectReference> extObjRefs = [];
		
		String endpointURL = message.getHeaders().get("CamelHttpUrl");
		def extSystemTenantSubdomain = URI.create(endpointURL).getHost();

		extObjRefs.add(new ExternalObjectReference(externalId:fulfillmentRequestId, externalIdTypeCode:EXTERNAL_ID_TYPE_CODE_ORDER_ID, externalSystemId:extSystemTenantSubdomain));
		def displayId = bodyJson.orderDisplayId;
		extObjRefs.add(new ExternalObjectReference(externalId:displayId, externalIdTypeCode:EXTERNAL_ID_TYPE_CODE_ORDER_DISPLAY_ID, externalSystemId:extSystemTenantSubdomain));
		sbPayload["externalObjectReferences"] = extObjRefs;
		
		sbPayload.payment = [:];
		sbPayload.payment["paymentMethod"] = mapCOtoSBPaymentMethod(bodyJson.payment[0].method);
		sbPayload.payment["paymentCardToken"] = bodyJson.payment[0].cardToken;
		
		List<Snapshot> snapshots = [];
		List<Item> items = [];
		
		// retrieve the first item of type SUBSCRIPTION
		def SBItem = null;
		for (def orderItem : bodyJson.orderItems) {
			if (orderItem.itemType == ITEM_TYPE_SUBSCRIPTION) {
				SBItem = orderItem;
				break;
			}
		}
		// if no SUBSCRIPTION item found, do not map
		if (SBItem == null) {
			message.setBody(""); // empty message sent to SB
			return message;
		}
		
		String itemId = SBItem.fulfillmentRequestItemId;
		String lineNumber = SBItem.lineNumber;

		List<ExternalObjectReference> extObjRefsItem = [];
		extObjRefsItem.add(new ExternalObjectReference(externalId:itemId,externalIdTypeCode:EXTERNAL_ID_TYPE_CODE_ITEM_ID, externalSystemId:extSystemTenantSubdomain));
		extObjRefsItem.add(new ExternalObjectReference(externalId:lineNumber,externalIdTypeCode:EXTERNAL_ID_TYPE_CODE_ITEM_NUMBER, externalSystemId:extSystemTenantSubdomain));

		Boolean useCodeToIdentifyProduct = message.getProperties().get("useCodeToIdentifyProduct").toBoolean();
		String productIdentifier = SBItem.product.fulfillmentSystemReference.id;
		Product product = useCodeToIdentifyProduct ? new Product(id:null,code:productIdentifier) : new Product(id:productIdentifier,code:null);
		String numberOfWaiverPeriods = SBItem.aspectsData.subscriptionItem.numberOfWaiverPeriods;
		String ratePlanId = SBItem.price.aspectsData.subscriptionItemPrice.pricingStrategy.id;
		RatePlan ratePlan = new RatePlan(id:ratePlanId);
			
		Item item = new Item(
			itemId:itemId,
			lineNumber:lineNumber,
			externalObjectReferences:extObjRefsItem,
			product:product,
			numberOfWaiverPeriods:numberOfWaiverPeriods,
			ratePlan: ratePlan
		)
		
		items.add(item);

		String validFrom = SBItem.aspectsData.subscriptionItem.validFrom;
		snapshots.add(new Snapshot(effectiveDate:validFrom, items:items));
		sbPayload["snapshots"] = snapshots;

		sbPayload["validFrom"] = validFrom;
		sbPayload["validUntil"] = SBItem.aspectsData.subscriptionItem.validTo;
		sbPayload["contractTerm"] = mapContractTerm(SBItem.aspectsData.subscriptionItem.contractTerm);
		sbPayload["renewalTerm"] = SBItem.aspectsData.subscriptionItem.renewalTerm;
		sbPayload["cancellationPolicy"] = SBItem.aspectsData.subscriptionItem.cancellationPolicy;
		sbPayload["overwriteContractTerm"] = SBItem.aspectsData.subscriptionItem.overwriteContractTerm;
		
		message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(sbPayload)));
	}
    return message;
}

def Boolean is10Numeric(String text) {
    return (text.length() == 10 && text.isInteger());
}

def String mapCOtoSBPaymentMethod(String COPaymentMethodInput) {        
    switch(COPaymentMethodInput) {
        case CO_PAYMENT_METHOD_INVOICE:
            return SB_PAYMENT_METHOD_INVOICE;       
        case CO_PAYMENT_METHOD_CARD:
            return SB_PAYMENT_METHOD_CARD;
        case CO_PAYMENT_METHOD_EXTERNAL:
            return SB_PAYMENT_METHOD_EXTERNAL;                  
        default:
            return COPaymentMethodInput;
    }       
}

def Map mapContractTerm(Map contractTerm) {
    if (contractTerm == null) { 
    	return null; 
    }
    	
  	if (contractTerm.period != null) {
	  	return ["period":contractTerm.period];
	}
  	
  	if (contractTerm.endDate != null) {
	  	return ["endDate":contractTerm.endDate];
	}
		
	return null;
}
