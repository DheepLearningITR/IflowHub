import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.op.agent.mpl.*;
import java.util.HashMap;
import groovy.transform.Field;
import groovy.json.JsonOutput;
import groovy.xml.XmlUtil;

@Field String ORDER_SERVICE_ORIGINAL_PAYLOAD_LOG = '1. Inbound Order';
@Field String SB_MAPPED_PAYLOAD_LOG = '2. Outbound Order';
@Field String EXIT_OUTPUT = '2.1. Exit Output';
@Field String SB_RESPONSE_JSON = '3. SB Response';
@Field String SB_EX_RESPONSE_JSON = '3. SB Exception Response';
@Field String IFLOW_EX_MESSAGE = '2. Exception Details';
@Field String IFLOW_JSON_RESPONSE_LOG = '4. iFlow Response';
@Field String IFLOW_JSON_EXCEPTION_RESPONSE_LOG = '4. iFlow Error Response';

def Boolean isDebug(Message message) { 
     final MplConfiguration config = message.getProperty("SAP_MessageProcessingLogConfiguration");
     return config.getOverallLogLevel() == MplLogLevel.DEBUG;
}

def Message logOriginalRequest(Message message) {
     processData(ORDER_SERVICE_ORIGINAL_PAYLOAD_LOG, message);
}

def Message logExceptionMessage(Message message) {
     processData(IFLOW_EX_MESSAGE, message);
}

def Message logMappedSBPayloadJson(Message message) {
     processData(SB_MAPPED_PAYLOAD_LOG, message);
}

def Message logExitOutput(Message message) {
     processData(EXIT_OUTPUT, message);
}

def Message logSBResponseJson(Message message) {
     processData(SB_RESPONSE_JSON, message);
}

def Message logSBExceptionResponseJson(Message message) {
     processData(SB_EX_RESPONSE_JSON, message);
}

def Message logiFlowJsonExceptionResponse(Message message) {
     processData(IFLOW_JSON_EXCEPTION_RESPONSE_LOG, message);
}

def Message logiFlowJsonResponse(Message message) {
     processData(IFLOW_JSON_RESPONSE_LOG, message);
}

def Message processData(String title, Message message) {
     if (isDebug(message)) {
          def body = message.getBody(java.lang.String);	
          def headers = message.getHeaders();
          def properties = message.getProperties();

          def propertiesAsString ="\n";
          properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };

          def headersAsString ="\n";
          headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };

          def messageLog = messageLogFactory.getMessageLog(message);

          if(messageLog != null) {
             try{
                 body = body ? JsonOutput.prettyPrint(body) : "";
             }catch(Exception ex){
                 //in case request payload is not in json format
             }
             messageLog.addAttachmentAsString(title , "\n Properties \n ----------   \n" + propertiesAsString +
                                                                 "\n Headers \n ----------   \n" + headersAsString +
                                                                 "\n Body \n ----------  \n\n" + body, "text/plain");
          }
     }
     return message;
}
