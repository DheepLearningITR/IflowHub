import com.sap.gateway.ip.core.customdev.util.Message
import groovy.transform.Field
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

@Field String ERROR_SHORTTEXT = 'ERROR'
@Field String INFO_SHORTTEXT = 'INFO'
@Field String GENERIC_ERROR_MESSAGE = 'A technical error occurred. Use the SAP Cloud Integration message ID to find additional error details.'
@Field String CPI_MSGID_TEXT = 'SAP Cloud Integration message ID: '

class ResponseMsg {
    String type
    String message
}

def Message processExceptionMessage(Message message) {
    String errorMessage = ""
    try {
        def exceptionProperty = message.getProperty('CamelExceptionCaught')
        errorMessage = exceptionProperty.message

        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (exceptionProperty.getClass().getCanonicalName().equals('org.apache.camel.component.ahc.AhcOperationFailedException')) {
            errorMessage = exceptionProperty.getResponseBody()
            errorMessage = errorMessage.replaceAll("\\P{Print}", '') ?: exceptionProperty.message
        }
    } catch(Exception ex) {}

    errorMessage = errorMessage ?: GENERIC_ERROR_MESSAGE
    message.setProperty("isError", true)
    message.setBody(errorMessage)
    return message
}

def Message buildResponse(Message message) {
    message.setHeader('Content-Type',   'application/json')

    def response = [:]
    String documentDisplayId = ''
    String subscriptionId = ''
    String sapMessageProcessingLogId = message.getProperty('SAP_MessageProcessingLogID') ?: ''
    def body = message.getBody(java.lang.String) ?: GENERIC_ERROR_MESSAGE
    boolean isError = message.getProperty("isError") ?: false
    def jsonSlurper = new JsonSlurper()

    // possible case where body is not a JSON
    try {
        body = jsonSlurper.parseText(body)
        documentDisplayId = body.documentNumber ?: ''
        subscriptionId = body.subscriptionId ?: ''
    } catch (Exception ex) {}

    List<ResponseMsg> respMsgs = []
    //Add CPI MsgID to messages
    respMsgs.add(new ResponseMsg(type:INFO_SHORTTEXT, message:CPI_MSGID_TEXT + sapMessageProcessingLogId))
    if (isError) {
        respMsgs.add(new ResponseMsg(type:ERROR_SHORTTEXT, message: body))
		message.setHeader("CamelHttpResponseCode", "400");
    }
    else if (!subscriptionId.trim()) { // if no order created
        respMsgs.add(new ResponseMsg(type:ERROR_SHORTTEXT, message:GENERIC_ERROR_MESSAGE))
		message.setHeader("CamelHttpResponseCode", "400");
    }

    /* build response */
    response.messages = respMsgs
	if (subscriptionId) {
		response.documentId = subscriptionId
	}
	if (documentDisplayId) {
		response.documentDisplayId = documentDisplayId
	}    

    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(response)))

    return message
}