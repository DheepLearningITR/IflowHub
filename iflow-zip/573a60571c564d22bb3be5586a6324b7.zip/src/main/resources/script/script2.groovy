import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
	def body = message.getProperty('ORIGINAL_EVENT')
    def messageLog = messageLogFactory.getMessageLog(message)
    def workflowModel = message.getProperty('WORKFLOW_MODEL')
    def initiateWorkflow = message.getProperty('INITIATE_WORKFLOW')

    def jsonSlurper = new JsonSlurper()
    def jsonObjectInput = jsonSlurper.parseText(body)
    if (jsonObjectInput instanceof java.util.Collection && jsonObjectInput.size() > 0) {
        jsonObjectInput = jsonObjectInput[0]
    }
    def jsonObjectOutput = [:]
    
    def processAutomationApiHost = message.getProperty('PROCESS_AUTOMATION_API_HOST')
    def workflowUpdateUrl;
    message.setProperty('WORKFLOW_INSTANCES_URL', workflowUpdateUrl)
    
    def businessKey = message.getProperty("BUSINESS_KEY");
    
    if (initiateWorkflow) {
        jsonObjectOutput['definitionId'] = workflowModel
        workflowUpdateUrl = processAutomationApiHost + '/public/workflow/rest/v1/workflow-instances'
    } else {
        jsonObjectOutput['definitionId'] = 'waitForEcAction'
        jsonObjectOutput['workflowDefinitionId'] = workflowModel
        jsonObjectOutput['businessKey'] = businessKey
        workflowUpdateUrl = processAutomationApiHost + '/public/workflow/rest/v1/messages'
    }
    message.setProperty('WORKFLOW_UPDATE_URL', workflowUpdateUrl)
    
    if (jsonObjectInput.data.eventReason) {
        // Just pass the whole input data object as 'ecJobInfo' in workflow context
        jsonObjectOutput['context'] = [
            'businessKey': businessKey,
            'ecJobInfo': jsonObjectInput.data
        ];
    } else {
        jsonObjectOutput['context'] = [
            'businessKey': businessKey,
            'eventTime': jsonObjectInput.data.activityProcessedAt,
            'ecWorkflowRequestId': jsonObjectInput.data.workflowRequestId,
            'ecWorkflowStatus': jsonObjectInput.data.status?.code,
            'ecWorkflowCurrentStep': jsonObjectInput.data.currentStepId
        ]
    }

    def jsonOutput = JsonOutput.toJson(jsonObjectOutput)
    message.setBody(jsonOutput)
    
    def enablePayloadLogging = message.getProperty("ENABLE_PAYLOAD_LOGGING");
    if (messageLog != null && "true".equalsIgnoreCase(enablePayloadLogging)) {
        def loopCount = message.getProperty('ODM_EVENT_LOOP_INDEX');
	    messageLog.addAttachmentAsString('Output message ' + loopCount, JsonOutput.prettyPrint(jsonOutput), 'application/json')
    }
    return message
}