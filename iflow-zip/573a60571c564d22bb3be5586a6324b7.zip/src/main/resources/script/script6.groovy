import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
	def body = message.getBody(java.lang.String)
    
    def jsonSlurper = new JsonSlurper()
    def jsonObjectInput = jsonSlurper.parseText(body)
    
    if (jsonObjectInput.ecWorkflowInformation && jsonObjectInput.ecWorkflowInformation.completedAt != null) {
        // EC part of the workflow is already completed => skip the event
        message.setProperty('SKIP_EVENT', true)
    } else {
        message.setProperty('SKIP_EVENT', false)
        message.setProperty('INITIATE_WORKFLOW', false)
    }
    return message
}