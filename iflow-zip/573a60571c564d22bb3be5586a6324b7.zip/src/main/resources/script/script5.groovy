import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
	def body = message.getBody(java.lang.String)
	def messageLog = messageLogFactory.getMessageLog(message)
	def enablePayloadLogging = message.getProperty("ENABLE_PAYLOAD_LOGGING");
	def allowDuplicateBTPInstances = "true".equalsIgnoreCase(message.getProperty("ALLOW_DUPLICATE_BTP_INSTANCES"));
	
    if (messageLog != null && "true".equalsIgnoreCase(enablePayloadLogging))	{
        def loopCount = message.getProperty('ODM_EVENT_LOOP_INDEX');
	    messageLog.addAttachmentAsString("Workflow API response " + loopCount, body, 'application/json')
    }

    def jsonSlurper = new JsonSlurper()
    def jsonObjectInput = jsonSlurper.parseText(body)
    def workflowInstanceId = null
    def errorOrSuspend = false;
    def completedOrCanceled = false;
    if (jsonObjectInput.isEmpty()) {
        // No workflow instance does exist yet
        message.setProperty('INITIATE_WORKFLOW', true)
    } else {
        for (def workflow : jsonObjectInput) {
            // There is at least one workflow instance with status RUNNING
            if (workflow.status == 'RUNNING' && workflow.completedAt == null) {
                workflowInstanceId = workflow.id
                break
            } else if (workflow.status == 'ERRONEOUS' || workflow.status == 'SUSPENDED') {
                errorOrSuspend = true
            } else if (workflow.status == 'COMPLETED' || workflow.status == 'CANCELED') {
                completedOrCanceled = true;
            }
        }
    }
    if (workflowInstanceId != null) {
        // If there is an active workflow instance, we need to check via the context endpoint if the EC workflow has been completed already
        message.setProperty('WORKFLOW_INSTANCE_ID', workflowInstanceId)
        
        def processAutomationApiHost = message.getProperty('PROCESS_AUTOMATION_API_HOST')
        def workflowInstanceContextUrl = processAutomationApiHost + '/public/workflow/rest/v1/workflow-instances/' + workflowInstanceId + '/context'
        message.setProperty('WORKFLOW_INSTANCE_CONTEXT_URL', workflowInstanceContextUrl)
    } else {
        if (errorOrSuspend) {
            // If there is no active workflow but only one with error or suspend state, skip this event as the workflow has to be resumed first
            message.setProperty('SKIP_EVENT', true)    
        } else {
            if (completedOrCanceled && !allowDuplicateBTPInstances) {
                message.setProperty('SKIP_EVENT', true)
            } else {
              // No active instance
              message.setProperty('INITIATE_WORKFLOW', true)
            }
        }
    }
    return message
}