 import com.sap.gateway.ip.core.customdev.util.Message;
 import java.util.HashMap;
 import java.util.UUID;
 import java.time.format.DateTimeFormatter;
 import java.time.LocalDateTime
 import java.time.ZoneOffset;
 import java.time.format.DateTimeFormatter
 import groovy.json.JsonSlurper;
 
def Message processData(Message message) {
    String body = message.getBody(java.lang.String);
 	def eventList = new JsonSlurper().parseText(body);
    
	message.setProperty('ODM_EVENT_COUNT', eventList.size());
	message.setProperty('ODM_EVENT_LOOP_INDEX', 0);
	message.setProperty('ODM_WORKFLOW_EVENTS', body); 

	def messageLog = messageLogFactory.getMessageLog(message);
	def enablePayloadLogging =  message.getProperty('ENABLE_PAYLOAD_LOGGING');
	if (messageLog != null  && "true".equalsIgnoreCase(enablePayloadLogging)){ 
        messageLog.addAttachmentAsString("Cloud Integration Events", body, "text/plain");
	}
	message.setHeader('Content-Type', 'application/json');
    return message;
}