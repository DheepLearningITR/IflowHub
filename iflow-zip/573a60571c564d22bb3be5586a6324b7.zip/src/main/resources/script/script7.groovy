import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
	def body = message.getBody(java.lang.String)
    def messageLog = messageLogFactory.getMessageLog(message)
    def enablePayloadLogging = message.getProperty("ENABLE_PAYLOAD_LOGGING");
    if (messageLog != null && "true".equalsIgnoreCase(enablePayloadLogging))	{
        def loopCount = message.getProperty('ODM_EVENT_LOOP_INDEX');
	    messageLog.addAttachmentAsString("Event " + loopCount , body, 'application/json')
    }

    def processAutomationApiHost = message.getProperty('PROCESS_AUTOMATION_API_HOST')
    if (processAutomationApiHost == null || processAutomationApiHost.isEmpty()) {
        throw new Exception('Please maintain external parameter PROCESS_AUTOMATION_API_HOST');
    }
    def workflowInstancesUrl = processAutomationApiHost + '/public/workflow/rest/v1/workflow-instances'
    message.setProperty('WORKFLOW_INSTANCES_URL', workflowInstancesUrl)
    
    def jsonSlurper = new JsonSlurper()
    def jsonObjectInput = jsonSlurper.parseText(body)
    if (jsonObjectInput instanceof java.util.Collection && jsonObjectInput.size() > 0) {
        jsonObjectInput = jsonObjectInput[0]
    }
    def ecWorkflowRequestId = jsonObjectInput.data.workflowRequestId
    def ecEventReason = jsonObjectInput.data.eventReason
    if (ecEventReason) {
        def userId = jsonObjectInput.data.userId;
        def seqNumber = jsonObjectInput.data.seqNumber;
        def startDate = jsonObjectInput.data.startDate.replace("-", "");
        def businessKey = ecEventReason + "_" + userId + "_" + startDate + "_" + seqNumber;
        message.setProperty('BUSINESS_KEY', businessKey)
    } else {
        message.setProperty('BUSINESS_KEY', ecWorkflowRequestId)   
    }
    message.setProperty('ORIGINAL_EVENT', body)
    message.setProperty('WORKFLOW_MODEL', "cross_system_workflow");
    return message
}