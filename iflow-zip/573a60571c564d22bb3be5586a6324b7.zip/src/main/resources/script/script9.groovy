import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)

    def body = message.getBody(java.lang.String);
    def enablePayloadLogging = message.getProperty("ENABLE_PAYLOAD_LOGGING");
    if ("true".equals(enablePayloadLogging) && messageLog != null)	{
	    messageLog.addAttachmentAsString("SuccessFactors Event" , body, 'application/json')
    }
    
    def jsonSlurper = new JsonSlurper()
    def jsonObjectInput = jsonSlurper.parseText(body)
    def uniqueId = jsonObjectInput.data.id
    def ecWorkflowRequestId = uniqueId.substring(uniqueId.indexOf(':') + 1)
    
    def convertedBody = [ 'data': [ 'workflowRequestId': ecWorkflowRequestId ] ]
    message.setBody(JsonOutput.toJson(convertedBody));
    return message;
}