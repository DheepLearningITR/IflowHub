import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

def Message processData(Message message) {
    def loopCount = message.getProperty('ODM_EVENT_LOOP_INDEX');
	def totalCount = message.getProperty('ODM_EVENT_COUNT');
	String odmEvents =  message.getProperty('ODM_WORKFLOW_EVENTS');
	
	def messageLog = messageLogFactory.getMessageLog(message);
    if (totalCount != null && loopCount != null && loopCount < totalCount && odmEvents != null && !odmEvents.isEmpty() ) {
        def eventList = new JsonSlurper().parseText(odmEvents);
        def odmEvent = eventList.get(loopCount);

        String singleEventPayload = JsonOutput.toJson(odmEvent);
		   
        loopCount++;
        message.setProperty('ODM_EVENT_LOOP_INDEX', loopCount);
 
        message.setHeader('Content-Type', 'application/json');
	    message.setBody(singleEventPayload);
	    
	    message.setProperty('WORKFLOW_INSTANCE_CONTEXT_URL', "");
	    message.setProperty('WORKFLOW_INSTANCE_ID', null);
	    message.setProperty('INITIATE_WORKFLOW', "");
	    message.setProperty('SKIP_EVENT', "");
    } else {
        message.setProperty('ODM_EVENT_LOOP_INDEX', 1);
    }
    return message;
}