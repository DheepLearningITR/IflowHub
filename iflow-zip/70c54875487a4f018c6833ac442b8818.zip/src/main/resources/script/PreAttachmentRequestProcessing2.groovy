/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def headers = message.getHeaders();
    def cookie = headers.get("Set-Cookie");
    def csrf = headers.get("x-csrf-token");
    StringBuffer bufferedCookie = new StringBuffer();
    for (Object item : cookie)
    {
        bufferedCookie.append(item + "; ");
    }
    message.setHeader("Cookie", bufferedCookie.toString());
    message.setHeader("x-csrf-token", csrf)
    
    def attachments = message.getProperty("attachments")
    message.setBody(attachments)
    
    // Store file names for error processing later
    def object = new JsonSlurper().parseText(attachments)
    def totalAttachments = object.attachmentRequestDtos.size
    def set = new HashSet()
    for (int i = 0; i < totalAttachments; i++) {
        set.add(object.attachmentRequestDtos[i].slug + "<")
    }
    message.setProperty("allFiles", set)
    
    return message;
}