/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;

import java.nio.charset.StandardCharsets

def Message processData(Message message) {
    currentResquest = message.getBody(String.class)

    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(currentResquest);
    
    // Cache requestBody for attachments processing later
    def attachments = object.messageRequests[0].body
    message.setProperty("attachments", new JsonBuilder(attachments).toPrettyString());
    
    // paymentAdviceAccount needs to be cached because attachment API requires a specific format
    def paymentAdviceAccount = object.messageRequests[0].body.value.paymentAdviceAccount
    message.setProperty("paymentAdviceAccount", paymentAdviceAccount)
    
    message.setHeader("Accept-Language", object.messageRequests[0].body.value.acceptLanguage)
    
    // request body has attachment data and paymentAdvice data for posting
    object.messageRequests[0].body = object.messageRequests[0].body.value
    def paymentAdviceBody = new JsonBuilder(object).toPrettyString()
    message.setBody(paymentAdviceBody)
    
    return message;
}