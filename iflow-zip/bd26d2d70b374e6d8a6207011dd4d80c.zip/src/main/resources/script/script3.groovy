import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;

/* Script to set qualified b2b unit ID i.e. BP with category code 2 and role as CRM000 (Sold to party) */
 
def Message processData(Message message) {
	def body = message.getBody();
	def messageLog = messageLogFactory.getMessageLog(message);
	def map = message.getProperties();
	
	map.put("qualifiedB2BUnitId","");
	if (body) {
	    def completeXml= new XmlSlurper().parseText(body);
	    def companyInfo = completeXml.BusinessPartnerSUITEReplicateRequestMessage.BusinessPartner;
	    def qualifiedB2BUnitId = "";
	    companyInfo.each { node -> 
	    	def b2bUnitId = node.InternalID.text();
	    	def categoryCode = node.CategoryCode.text();
	    	if(categoryCode=="2"){
	    	    def roles = node.Role;
	    	    roles.each { role ->
	    	    	def currentRole = role.RoleCode.text();
	    	    	if (currentRole == "CRM000"){
	    	    		qualifiedB2BUnitId = b2bUnitId;
	    	    		map.put("qualifiedB2BUnitId",qualifiedB2BUnitId);
	    	    	}
	    	    }
	    	}
	    }
	    
	    if(messageLog != null && map.get("enableLogs").toBoolean()){
	        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
	        messageLog.addAttachmentAsString("Qualified B2BUnit:", map.get("qualifiedB2BUnitId") , "text/plain");
     	}
	}
	map.put("requestBody",body);
	return message;
}