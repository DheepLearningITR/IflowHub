import com.sap.it.api.mapping.*;

//Add MappingContext parameter to read or set headers and properties

def String getContactPersonGorup(String header,MappingContext context)
{

    String customerNumber = context.getHeader("CustomerNumber");
    customerNumber = customerNumber.toString();

    String contactPersonFunction = header;
//    String contactPersonFunction = context.getHeader("ContactPersonFunction");
    contactPersonFunction = contactPersonFunction.toString();

   if( contactPersonFunction == '02'){

       return new StringBuilder()
                .append( customerNumber )
                .append( ',' )
                .append( 'b2badmingroup'  )
                .append( ',' )
                .append( 'b2bcustomergroup' )
                .toString()

    } else if( contactPersonFunction == '01'){

        return new StringBuilder()
                .append( customerNumber )
                .append( ',' )
                .append( 'b2badmingroup'  )
                .toString()

    } else  if( contactPersonFunction == '11'){

        return new StringBuilder()
                .append( customerNumber )
                .append( ',' )
                .append( 'b2bcustomergroup' )
                .toString()
    }else{
        return new StringBuilder()
                .append( customerNumber )
                .toString()
    }

}