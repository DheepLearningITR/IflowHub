import groovy.json.JsonSlurper;
import com.sap.gateway.ip.core.customdev.util.Message;


def Message convert(Message msg) {
    String jsonStr = msg.getBody(java.lang.String) as String
    def map = msg.getProperties()
    String regNo = map.get("RegNo")
    String enableAttachments = map.get("EnableAttachments")
    String xmlStr = jsonToXmlConverter(jsonStr)
    msg.setBody(xmlStr)
    if(enableAttachments == 'X') {
        def logger = messageLogFactory.getMessageLog(msg);
        if(logger != null) {
	        logger.addAttachmentAsString("RawJSON-" + regNo , jsonStr, "text/json")
	        logger.addAttachmentAsString("ConvertedXML-" + regNo, xmlStr, "text/xml")
        }
    }
    return msg
}

String jsonToXmlConverter(String str) {
    def addPreTag = {
        StringBuilder buf, String key ->
            buf.append("<")
            buf.append(key)
            buf.append(">")

    }
    def addPostTag = {
        StringBuilder buf, String key ->
            buf.append("</")
            buf.append(key)
            buf.append(">\n ")
    }
    def jsonSlurper = new JsonSlurper()
    def map = jsonSlurper.parseText(str)
    def builder = new StringBuilder()
    builder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
    private_converter(map, builder, addPreTag, addPostTag)
    return builder.toString()
}


def private_converter(Map map, StringBuilder buf, def addPreTag, def addPostTag) {
    def keys = map.keySet().toList();
    for (key in keys) {    //walk through every key-value pair of the json formatted string
        def val = map[key]
        if (val instanceof List) { //if the value is a list, then for each item of the list, append the XML with the string like "<key>item</key>"
            if(val.size() == 0 ) {
                addPreTag.call(buf, key)
                addPostTag.call(buf, key)
                continue
            }
            for (piece in val) {
                addPreTag.call(buf, key)
                if (piece instanceof Map) { 
                    private_converter(piece, buf, addPreTag, addPostTag) 
                } else {
                    buf.append(piece)
                }
                addPostTag.call(buf, key)
            }
        } else {
            addPreTag.call(buf, key)
            if (val instanceof Map) {
                private_converter(val, buf, addPreTag, addPostTag)
            } else if (key == "DATAXML"){
                String invoice = (val =~ /^<\?xml.*\?>([\S\s]*)/)[0][1]  //remove the XML header
                String encoded = invoice.getBytes("UTF-8").encodeBase64().toString()
                buf.append(encoded)
            } else {
                buf.append(val)
            }
            addPostTag.call(buf, key)
        }
    }
}