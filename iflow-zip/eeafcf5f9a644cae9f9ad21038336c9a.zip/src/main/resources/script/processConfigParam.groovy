import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory; 
import com.sap.it.api.securestore.SecureStoreService; 
import com.sap.it.api.securestore.UserCredential; 


def Message processData(Message message) {
    def map = message.getProperties()
    String periodStr = map.get("Period")
    String fromDateStr = map.get("FromDate")
    String toDateStr = map.get("ToDate")
    String registry = map.get("Registry")
    String enableAttachments = map.get("EnableAttachments")
    
    String fromParam
    String toParam
        
    if (fromDateStr != "" && toDateStr != "") {
        fromParam = fromDateStr
        toParam = toDateStr
    } else {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd")
        Calendar calendar = Calendar.getInstance()
        Date from, to
        Integer period = periodStr == "" ? 7 : Integer.valueOf(periodStr)
        if (period <= 0)
            period = 7
            
        if(fromDateStr != "") {
            from = dateFormat.parse(fromDateStr)
            calendar.setTime(from)
            calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + period - 1)
            to = calendar.getTime()
        } else {
            to = toDateStr == "" ? new Date() : dateFormat.parse(toDateStr)
            calendar.setTime(to)    
            calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) - period + 1)
            from = calendar.getTime()
        }
        fromParam = dateFormat.format(from).toString()
        toParam = dateFormat.format(to).toString()
    }
    
    StringBuilder sbuilder = new StringBuilder()
    
    if(enableAttachments == "X") {
        def messageLog = messageLogFactory.getMessageLog(message)

        sbuilder.append("config params:\n")
        sbuilder.append("   Period: ").append(periodStr == "" ? "null" : periodStr).append("\n")
        sbuilder.append("   FromDate: ").append(fromDateStr == "" ? "null" : fromDateStr).append("\n")
        sbuilder.append("   ToDate: ").append(toDateStr == "" ? "null" : toDateStr).append("\n")
        sbuilder.append("   Registry: ").append(registry == "" ? "null" : registry).append("\n")
    
        sbuilder.append("\ndetermined param for http request MY_LIST to smartbill:\n")
        sbuilder.append("   FromDate: ").append(fromParam).append("\n")
        sbuilder.append("   ToDate: ").append(toParam).append("\n")
    
        message.setProperty("ToDate", toParam)
        message.setProperty("FromDate", fromParam)
        if(messageLog != null)
            messageLog.addAttachmentAsString("ProcessConfigParam", sbuilder.toString(), "text/plain")
    }
    
    def secureService = ITApiFactory.getApi(SecureStoreService.class, null); 
    String[] regNoSet = registry.split("[^0-9]+")
    sbuilder.delete(0, sbuilder.length())
    sbuilder.append("<items>")
    for(String regNo : regNoSet) {
        String CredentialName = "edoc_kr_smartbill_token_" + regNo;
        def credential = secureService.getUserCredential(CredentialName); 
        if (credential == null) { throw new IllegalStateException("No credential found for alias" + CredentialName ); }
        String token = new String(credential.getPassword());
        sbuilder.append("<item>").append("<RegNo>").append(regNo).append("</RegNo>").append("<AuthToken>").append(token).append("</AuthToken>").append("</item>")
    }
    sbuilder.append("</items>")
    message.setBody(sbuilder.toString())
    
    return message
}