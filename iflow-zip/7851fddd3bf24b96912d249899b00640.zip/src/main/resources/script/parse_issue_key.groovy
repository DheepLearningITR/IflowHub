import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {
    def body = message.getBody(String)
    if (!body) {
        message.setProperty("ScriptError_PayloadMissing", "Payload is empty")
        throw new Exception("Empty JSON payload")
    }

    def json
    try {
        json = new JsonSlurper().parseText(body)
    } catch (Exception e) {
        message.setProperty("ScriptError_JsonParsingFailed", "JSON parsing error: " + e.message)
        throw new Exception("Failed to parse JSON: " + e.message, e)
    }

    def fields = json?.resource?.fields
    def workItemId = json?.resource?.workItemId
    def newState = (fields?.get("System.State"))?.newValue
    def oldState = (fields?.get("System.State"))?.oldValue
    String triggeringState = message.getProperty("TriggeringState")
    
    
    //Check if ticket is moved to the trigger state
    boolean shouldUpdate = (newState?.toLowerCase() == triggeringState.toLowerCase() && oldState?.toLowerCase() != triggeringState.toLowerCase())
    message.setProperty("shouldUpdateTransport", shouldUpdate)
    
    //Parse Ticket ID
    if (workItemId != null) {
        message.setProperty("externalTicketIds", workItemId.toString())
    } else {
        message.setProperty("ScriptWarning_WorkItemIdMissing", "Missing 'workItemId' in payload.")
    }

    return message
}
