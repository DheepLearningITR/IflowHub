import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

import java.text.SimpleDateFormat
import java.util.Date

//////////////////// log ////////////////////////////
def Message log01(Message message) {processLog("log01", message)}
def Message log02(Message message) {processLog("log02", message)}
def Message log03(Message message) {processLog("log03", message)}
def Message log04(Message message) {processLog("log04", message)}
def Message log05(Message message) {processLog("log05", message)}
def Message log06(Message message) {processLog("log06", message)}
def Message log07(Message message) {processLog("log07", message)}
def Message log08(Message message) {processLog("log08", message)}
def Message log09(Message message) {processLog("log09", message)}
def Message log10(Message message) {processLog("log10", message)}

def Message processLog(String prefix, Message message) {
	def headers = message.getHeaders()
	def properties = message.getProperties()
	def body = message.getBody(java.lang.String) as String
	def messageLog = messageLogFactory.getMessageLog(message)

	def str = ""
	headers.each{ header ->
		messageLog.setStringProperty("header." + header.getKey().toString(), header.getValue().toString())
		 str = str + "header.${header.getKey()}:${header.getValue()}\r\n"
	 }
	properties.each{ property ->
		messageLog.setStringProperty("property." + property.getKey().toString(), property.getValue().toString())
		 str = str + "property.${property.getKey()}:${property.getValue()}\r\n"
	 }
	 
	if(messageLog != null){
		messageLog.addAttachmentAsString(prefix, str + body, "text/plain")
	 }
	return message
}



/////////////////////////////////////////////////////
def Message init(Message message) {

	def map = message.getProperties()
	CharSequence pageSize = map.get("Ymkt_PageSize")
	
	def topCount = pageSize.toInteger()
	def skipCount = 0 
	message.setProperty("topCount", topCount.toString())
	message.setProperty("skipCount", skipCount.toString())
	
	def lastGoodRunDateStr = map.get("lastGoodRunDate")
	def runBeginDateStr	   = map.get("BeginRunDate")
	def runEndDateStr	   = map.get("EndRunDate")
	
	Date currentDate
	Date endDate
	if (runBeginDateStr != null && runBeginDateStr != '') { 
		currentDate = Date.parse("yyyy-MM-dd", runBeginDateStr ) 
	}
	else {
		if (lastGoodRunDateStr != null && lastGoodRunDateStr != '') {
			currentDate = Date.parse("yyyy-MM-dd", lastGoodRunDateStr).plus(1)
		}
		else{
			currentDate = new Date().minus(1)
		}
	}

	if (runEndDateStr != null && runEndDateStr != '') { 
		endDate = Date.parse("yyyy-MM-dd", runEndDateStr ) 
	}
	else {
		endDate = new Date().minus(1)
	}
	
	if (endDate.minus(currentDate) < 0) {
		message.setProperty("hasMoreDays", 'false')
	}
	else {
		message.setProperty("hasMoreDays", 'true')
	}
		
	message.setProperty("currentDate", currentDate.format("yyyy-MM-dd"))
	message.setProperty("endDate", endDate.format("yyyy-MM-dd"))

	return message
}


def Message dayCounter(Message message) {
	
		def map = message.getProperties()
		Date currentDate = Date.parse("yyyy-MM-dd", map.get("currentDate"))
		message.setProperty("currentDateTime1", "'" + currentDate.format("yyyy-MM-dd") + "T00:00:00Z'" )
		message.setProperty("currentDateTime2", "'" + currentDate.format("yyyy-MM-dd") + "T23:59:59Z'" )
		
		def skipCount = 0
		message.setProperty("skipCount", skipCount.toString())
	
		return message
	}
	

def Message dayEnd(Message message) {
	
		def map = message.getProperties()
		def currentDate = Date.parse("yyyy-MM-dd", map.get("currentDate")).plus(1)
		message.setProperty("currentDate", currentDate.format("yyyy-MM-dd"))
		
		def endDate = Date.parse("yyyy-MM-dd", map.get("endDate"))
		if (endDate.minus(currentDate) < 0) {
			message.setProperty("hasMoreDays", 'false')
		}
		else {
			message.setProperty("hasMoreDays", 'true')
		}
		
		return message
	}

	
def Message pageEnd(Message message) {
	
		def map = message.getProperties()
		def skipCountStr = map.get("skipCount")
		def topCountStr = map.get("topCount")

		if ( message.getBodySize() < 20 ) { 								//  </Interactions>   rough estimate.
			message.setProperty("hasMoreRecords", 'false')
		}
		else {
			message.setProperty("hasMoreRecords", 'true')
			message.setProperty("skipCount", (skipCountStr.toInteger() + topCountStr.toInteger()).toString())
		}
		
		return message
	}
		
	
