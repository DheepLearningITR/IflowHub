import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import java.security.*

import groovy.xml.*


// Retrieve ContactUUID from the incoming message and construct batch request
def Message setBatchRequest(Message message){
	
	def body = message.getBody(java.lang.String)
	def map = message.getProperties()
	def IDOriginStr = map.get("ContactIDOrigin")
	
	def originFilter = ")+and+InteractionContactAdditionalOrigin+eq+'" + IDOriginStr + "'"
	
	def contactUUIDs = new XmlSlurper().parseText( body ).'**'.findAll{ it.name() == 'InteractionContactUUID' }*.text()
	message.setProperty( "contactUUIDCount", contactUUIDs.unique().size() )
	
	def filterStr = ""
	contactUUIDs.unique().inject(""){ filerStr, contactUUID ->
		filterStr +=  "ContactUUID+eq+guid'${contactUUID}'+or+"
	}

	filterStr = ( filterStr.length() == 0 ) ? "" : "&\$filter=(" + filterStr.substring( 0, filterStr.length() - 4 ) + originFilter

	assert contactUUIDs.size() != 0
		
	String batchRequest = '''--batchtest\r
Content-Type: application/http\r
Content-Transfer-Encoding: binary\r
\r
\r
'''
	batchRequest = batchRequest + "GET AdditionalIDs?\$top=${contactUUIDs.size()}&\$select=ContactUUID,InteractionContactAdditionalExternalID${filterStr} HTTP/1.1\r"
	batchRequest += '''\r
\r
'''
	batchRequest += '''
--batchtest--'''

	body = batchRequest
	message.setBody( body )
	message.setHeader("Content-Type", "multipart/mixed; boundary=batchtest")
	return message

}


// Parse the HTTP batch response and construct XML message based on the structure definition of AdditionalID
def Message processBatchContacts(Message message) {

   def xmlBlocks = []
   def additionalIDs = []
   def body = message.getBody(java.lang.String)
   body.split('HTTP/1.1').each{ block ->
   if ( block.substring(1,4) == '200' && block.lastIndexOf('>')!= -1 && block.indexOf('<')!= -1){
	   xmlBlocks <<  block.substring(block.indexOf('<'), block.lastIndexOf('>')+1)
	   }
   }
   
   xmlBlocks.each{ xmlBlock ->
	   new XmlSlurper().parseText(xmlBlock).declareNamespace(
		   m:'http://schemas.microsoft.com/ado/2007/08/dataservices/metadata',
		   d:'http://schemas.microsoft.com/ado/2007/08/dataservices').entry.each{ e ->
		   def additionalID = [:]
		   e.content.properties.children().each{
			   additionalID.put( it.name(), it.text() )
		   }
		   additionalIDs << additionalID
	   }
   }

   def xml = new StreamingMarkupBuilder().with{ binder->
	   binder.bind { binding ->
		   AddtionalIDs {
			   additionalIDs.each{ additionalID ->
				   AdditionalID {
					   additionalID.each{
						   binding."${it.key}"(it.value)
					   }
				   }
			   }
		   }
	   }
   }
   
   body = ""
   message.setBody( body + xml.toString() )
   return message
}


// Take the InteractionContactAdditionalExternalID from first part of XML, to add an additional column aside InteractionContactUUID in interaction xml, serialize only Interaction part of XML
def Message addCustomerID(Message message) {

	def body = message.getBody(java.lang.String)

	//hash the value of InteractionContactAdditionalExternalID when construct the map
	def map = message.getProperties()
	def algorithmStr = map.get("HashAlgorithm")
	def additionalIDs = [:]
	
	
	def xmlslurper = new XmlSlurper()
	xmlslurper.parseText(body).'**'.findAll{ node-> node.name() == 'AdditionalID' }.each{ e->
	   additionalIDs.put( e.ContactUUID.text(), hash(e.InteractionContactAdditionalExternalID.text(), algorithmStr) )
	}
	
	//find InteractionContactUUID, add CustomerID with the hashed value from InteractionContactAdditionalExternalID
	def xml = xmlslurper.parseText(body).'**'.find{ node -> node.name() == 'Interactions' }
	xml.'**'.findAll{node -> node.name() == 'InteractionContactUUID'}.each{ e ->
	  e.parent().appendNode{
		  'CustomerID' "${additionalIDs[e.text()]}"
	  }
	}
	
	message.setBody( XmlUtil.serialize(xml) )
	
	return message
}



def hash(String input, String algorithm) {
	
	if (algorithm == "" || algorithm == null) {
		return input
	}
	else{
		MessageDigest sha = MessageDigest.getInstance(algorithm)
		byte[] digest = sha.digest(input.getBytes())
		def encodingDigest = digest.encodeHex()
	}
	
}
	