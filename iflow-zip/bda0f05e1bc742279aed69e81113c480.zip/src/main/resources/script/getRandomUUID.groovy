import com.sap.it.api.mapping.*;
import java.util.UUID;


def String getRandomUUID(String arg1){
		return UUID.randomUUID().toString()
}