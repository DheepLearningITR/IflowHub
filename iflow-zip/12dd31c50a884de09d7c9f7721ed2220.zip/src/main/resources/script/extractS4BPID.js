/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

 * 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
importClass(com.sap.it.api.exception.ITApiRuntimeException);

function processData(message) {
    //properties
    map = message.getProperties();
    var s4BusinessSystemId = map.get("S4SystemID");
    message.setProperty("contractAccountExist", false);
    
    //body
    var body = message.getBody(new java.lang.String().getClass());
    var customer = JSON.parse(body);
    var externalObjectReference = customer.externalObjectReferences;
    var marketList = customer.markets;
    var S4BPExist = false;
    var marketId = map.get("MarketID");
    
    for (var item in externalObjectReference) {
        if (externalObjectReference[item].externalSystemId == s4BusinessSystemId && externalObjectReference[item].externalIdTypeCode == "201") {
            message.setProperty("S4BPID", externalObjectReference[item].externalId);
            S4BPExist = true;
            //Set default value for market PriceType.
            message.setProperty("MarketPriceType", "Net");
        }
        else if (externalObjectReference[item].externalSystemId == s4BusinessSystemId && externalObjectReference[item].externalIdTypeCode == "211") {
        	message.setProperty("contractAccountID", externalObjectReference[item].externalId);
        	message.setProperty("contractAccountExist", true);
        }
    }
    
    for(var index in marketList){
    	if(marketList[index].marketId == marketId) {
    		message.setProperty("MarketPriceType", marketList[index].priceType);
    		break;
    	}
    }
    //When not found
    if(S4BPExist == false){
    	var customerId = map.get("RCCustomerNumber");
    	var billLogID = map.get("billLogID");
    	throw new ITApiRuntimeException("Not found S4HANA BP number for Subscription Billing customer (" + customerId + ") in bill (" + billLogID + ").");
    }
    
    return message;
}