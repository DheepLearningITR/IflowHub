/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
    //body
    var body = message.getBody();
    var subscriptionsBody = JSON.parse(body);
    var subscriptions = subscriptionsBody.root.subscriptions;
    var entitlement = {};
    var entitlementBody = {};
    
    // for(var i=0; i<subscriptions.length; i++) {
    var subscription = subscriptions[0];
    if (subscription) {
        entitlement['SourceSystem'] = 'SAPSBTEMP2';
        entitlement['CustomerID'] = subscription.customer.id;
        entitlement['DocumentNumber'] = subscription.documentNumber;
        entitlement['Item'] = [];
        
        var snapshot = subscription.snapshots[0];
        var items = snapshot.items;
        for (var j=0; j<items.length; j++) {
            var entitlementItem = {};
            var item = items[j];
            entitlementItem['ItemNumber'] = item.lineNumber;
            entitlementItem['OfferingID'] = item.product.code;
            entitlementItem['UoM'] = 'EA';
            entitlementItem['ItemValidFrom'] = subscription.validFrom.substr(0, 4) + subscription.validFrom.substr(5, 2) + subscription.validFrom.substr(8, 2);
            if (subscription.validUntil) {
                entitlementItem['ItemValidTo'] = subscription.validUntil.substr(0, 4) + subscription.validUntil.substr(5, 2) + subscription.validUntil.substr(8, 2);
            } else {
                entitlementItem['ItemValidTo'] = '99991231';
            }
            var subscriptionParameters = item.subscriptionParameters;
            for (var k=0; k<subscriptionParameters.length; k++) {
                entitlementItem[subscriptionParameters[k].code] = subscriptionParameters[k].value;
            }
            if (!entitlementItem['Quantity']) {
                entitlementItem['Quantity'] = '1';
            }
            entitlement['Item'].push(entitlementItem);
        }
        // }
        
        entitlementBody["Inbound_Interface_Entitlement_Generation"] = {
            "Inbound_Interface_Entitlement_Generation": entitlement
        }
    }
    body = JSON.stringify(entitlementBody);
    message.setBody(body);

    return message;
}