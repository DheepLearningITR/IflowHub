import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
    //Body
    String mapBody = message.getBody(java.lang.String) as String;
    
    //Parse JSON Message
    def jsonSlurper = new JsonSlurper();
    Object jsonDataObject = jsonSlurper.parseText(mapBody);
 
    //Get and set Business Get Manager ID
    def userId = "";
    
    if (jsonDataObject.totalResults == 0){
    }else{
        userUUID = jsonDataObject.id;
        userUUID = userUUID.toString();
        userUUID = userUUID.replaceAll("\\[", "").trim();
        userUUID = userUUID.replaceAll("\\]", "").trim();
        message.setProperty("prop_IAS_userUUID", userUUID);
    }
    return message;
}

