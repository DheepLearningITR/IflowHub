import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
	 
def Message processData(Message message) {
	   
    def body = message.getBody(String.class);
    
    def pmap = message.getProperties();
   
//Retrieve Data from XML    
    def parseXML = new XmlParser().parseText(body);	 
    
    def prop_action = "${parseXML.item.action.text()}";
    message.setProperty("prop_action", prop_action);

    def prop_persNo = "${parseXML.item.sysUser.text()}";
    message.setProperty("prop_persNo", prop_persNo);

    def prop_lastName = "${parseXML.item.lastName.text()}";
    message.setProperty("prop_lastName", prop_lastName);

    def prop_firstName = "${parseXML.item.firstName.text()}";
    message.setProperty("prop_firstName", prop_firstName);
    
    def prop_eMail = "${parseXML.item.eMail.text()}";
    message.setProperty("prop_eMail", prop_eMail);

    def prop_SNCName = "${parseXML.item.SNCName.text()}";
    message.setProperty("prop_SNCName", prop_SNCName);    

    def prop_mngtUser = "${parseXML.item.mngtUser.text()}";
    message.setProperty("prop_mngtUser", prop_mngtUser);       

    def prop_posID = "${parseXML.item.posID.text()}";
    message.setProperty("prop_posID", prop_posID);   
    
    def prop_prevPosID = "${parseXML.item.prevPosID.text()}";
    message.setProperty("prop_prevPosID", prop_prevPosID);       

    def empStatus = "${parseXML.item.empStatusID.text()}";
    
    if(empStatus == "3"){
        message.setProperty("prop_empStatus", "A");
        message.setProperty("prop_reasonCode", "HRUserRequestCreation");
    }else{
        message.setProperty("prop_empStatus", "D");
        message.setProperty("prop_reasonCode", "HRUserRequestTermination");
    }
 
    
    
    return message;
	 
}


