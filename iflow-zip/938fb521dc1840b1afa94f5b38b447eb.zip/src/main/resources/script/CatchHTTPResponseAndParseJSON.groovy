import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;                        


def Message processData(Message message) {

    
                // get a map of iflow properties
                def map = message.getProperties();
                def mapHeader = message.getHeaders();
                // get an exception java class instance
                def ex = map.get("CamelExceptionCaught");
                if (ex!=null){

              // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
                    if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")){

                        // save the http error response as a message attachment 
                        def messageLog = messageLogFactory.getMessageLog(message);
                        messageLog.addAttachmentAsString("IAS Error Response", ex.getResponseBody(), "text/plain");
                        message.setBody(ex.getResponseBody());
                        
                        def jsonSlurper = new JsonSlurper();
                        Object jsonDataObject = jsonSlurper.parseText(ex.getResponseBody());
                       
                        def IAS_Detail = jsonDataObject.detail;
                        IAS_Detail = IAS_Detail.toString();
                        message.setProperty("prop_IAS_Detail", IAS_Detail); 

                    }
                }

    return message;
}