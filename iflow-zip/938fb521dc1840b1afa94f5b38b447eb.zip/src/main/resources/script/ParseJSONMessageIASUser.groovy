import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
    //Body
    String mapBody = message.getBody(java.lang.String) as String;
    
    //Parse JSON Message
    def jsonSlurper = new JsonSlurper();
    Object jsonDataObject = jsonSlurper.parseText(mapBody);
 
    //Get and set Business Get Manager ID
    def userId = "";
    
    if (jsonDataObject.totalResults == 0){
        message.setProperty("prop_IAS_userId", "");
    }else{
        userId = jsonDataObject.Resources."urn:ietf:params:scim:schemas:extension:sap:2.0:User".userId;
        userId = userId.toString();
        userId = userId.replaceAll("\\[", "").trim();
        userId = userId.replaceAll("\\]", "").trim();
        message.setProperty("prop_IAS_userId", userId);
        
        userUUID = jsonDataObject.Resources.id;
        userUUID = userUUID.toString();
        userUUID = userUUID.replaceAll("\\[", "").trim();
        userUUID = userUUID.replaceAll("\\]", "").trim();        
        message.setProperty("prop_IAS_userUUID", userUUID);
    }
    return message;
}

