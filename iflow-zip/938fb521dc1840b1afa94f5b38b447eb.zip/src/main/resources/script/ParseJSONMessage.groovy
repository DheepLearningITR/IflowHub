import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
    //Body
    String mapBody = message.getBody(java.lang.String) as String;
    
    //Parse JSON Message
    def jsonSlurper = new JsonSlurper();
    Object jsonDataObject = jsonSlurper.parseText(mapBody);

    
    //Set message
    message.setProperty("message", jsonDataObject.message);
    
    //Set messageCode
    if (jsonDataObject.accessRequestId == null || jsonDataObject.accessRequestId == ""){
            message.setProperty("messageCode", jsonDataObject.messageCode);
    }else{ 
            message.setProperty("messageCode","200");
    }

    return message;
}