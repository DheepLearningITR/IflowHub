import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
    //Body
    String mapBody = message.getBody(java.lang.String) as String;
    
    //Parse JSON Message
    def jsonSlurper = new JsonSlurper();
    Object jsonDataObject = jsonSlurper.parseText(mapBody);
 
    //Get and set Business Rule AccessID
    def accessId2 = "";
    accessId2 = jsonDataObject.Result.Access.name;
    accessId2 = accessId2.toString();
    accessId2 = accessId2.replaceAll("\\[", "").trim();
    accessId2 = accessId2.replaceAll("\\]", "").trim();
    message.setProperty("prop_accessId_prevPosID", accessId2);

    //Get and set Business Rule Type
    def type2 = "";
    type2 = jsonDataObject.Result.Access.type;
    type2 = type2.toString();
    type2 = type2.replaceAll("\\[", "").trim();
    type2 = type2.replaceAll("\\]", "").trim();
    message.setProperty("prop_type_prevPosID", type2);    
    
    return message;
}