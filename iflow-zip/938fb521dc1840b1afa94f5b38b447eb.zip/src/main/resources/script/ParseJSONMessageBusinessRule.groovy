import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
    //Body
    String mapBody = message.getBody(java.lang.String) as String;
    
    //Parse JSON Message
    def jsonSlurper = new JsonSlurper();
    Object jsonDataObject = jsonSlurper.parseText(mapBody);
 
    //Get and set Business Rule AccessID
    def accessId = "";
    accessId = jsonDataObject.Result.Access.name;
    accessId = accessId.toString();
    accessId = accessId.replaceAll("\\[", "").trim();
    accessId = accessId.replaceAll("\\]", "").trim();
    message.setProperty("prop_accessId_PosID", accessId);

    //Get and set Business Rule Type
    def type = "";
    type = jsonDataObject.Result.Access.type;
    type = type.toString();
    type = type.replaceAll("\\[", "").trim();
    type = type.replaceAll("\\]", "").trim();
    message.setProperty("prop_type_PosID", type);    
    
    return message;
}