import com.sap.it.api.mapping.*;

def String getBPRelationIDFn(String P1,String P2, MappingContext context) {
         String value = context.getProperty("InternalID-Read") as String;
         if(value == null || value.length()<=0)
         {
             value = context.getProperty("BusinessPartnerRelationship-RelationshipBusinessPartnerInternalID-Read") as String;
         }
         return value;
}