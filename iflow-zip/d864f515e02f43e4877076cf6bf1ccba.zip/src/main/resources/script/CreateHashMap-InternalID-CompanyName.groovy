
/* Sample XML
<root xmlns:ns3="http://sap.com/xi/SAPGlobal20/Global">
   <Organisation>
      <InternalID>1000030</InternalID>
      <CompanyName>Bike World (Atlanta)</CompanyName>
   </Organisation>
   <Organisation>
      <InternalID>1000000</InternalID>
      <CompanyName>ASD Organic Limited</CompanyName>
   </Organisation>
   <Organisation>
      <InternalID>1000020</InternalID>
      <CompanyName>Water Org Company</CompanyName>
   </Organisation>
</root>
*/


import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.*;

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader);
    HashMap<Integer, String> hmap = new HashMap<Integer, String>();
    def Root = new XmlSlurper().parse(body);
    Root.Organization.each{
    try{
        hmap.put(it.InternalID.text().toString(), it.CompanyName.text().toString());
    }catch(Exception ex){
        //put relevant exception handling here
    }
    }
    message.setProperty("organizationMap", hmap);
    return message;
}