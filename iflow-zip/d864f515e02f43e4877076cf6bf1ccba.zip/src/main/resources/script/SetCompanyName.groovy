/* -- Sample XML which will be parsed in this script --
<?xml version="1.0" encoding="UTF-8"?>
<root xmlns:ns3="http://sap.com/xi/SAPGlobal20/Global">
  <Organisation>
    <InternalID>1000033</InternalID>
    <CompanyName>Delbonte Industries</CompanyName>>
    <CompanyName/>
  </Organisation>
  <Organisation>
    <InternalID>1000030</InternalID>
    <CompanyName>Bike World (Atlanta)</CompanyName>
  </Organisation>
</root>
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {	
	def body = message.getBody(java.lang.String) as String;
	def properties = message.getProperties() as Map<String, Object>;
	def internalID = properties.get("BusinessPartnerInternalID-Read");
	def totalCount = properties.get("companyNameCount");
	def root = new XmlSlurper().parseText(body);
    for(int i = 0;i<totalCount;i++) {
        if(root.Organisation[i].InternalID == internalID) {
            message.setProperty("companyName", root.Organisation[i].CompanyName);
            break;
        }
    }
	return message;
}