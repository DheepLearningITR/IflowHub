import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	def itemList = []
	//def deliveryItems=[]
	
	
	if (!object.A_OutbDeliveryHeader.isEmpty()) {
	    itemList = object.A_OutbDeliveryHeader.A_OutbDeliveryHeaderType;
		
		if (!isCollectionOrArray(itemList)) {
			itemList = [itemList].toArray();
		}
	}
	
	itemList.each { record ->
	   if(null!=record.DeliveryDocument){
            message.setProperty(record.DeliveryDocument,record.ShipToParty)
	    }
		
	}
    return message
}
//Returns true if object is an array
boolean isCollectionOrArray(object) {
    [Collection, Object[]].any {
        it.isAssignableFrom(object.getClass())
    }
}
