import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    
    def logger = message.getProperty("EnableLog");
	logs = logger.toLowerCase()
	//message.setProperty("isDeliverySTO", 'false');
	
    
    if(logs=="true"){
        def exceptionMsg = message.getProperty("CamelExceptionCaught")
        def messageLog = messageLogFactory.getMessageLog(message)
        messageLog.addAttachmentAsString("Cannot fetch material information ",exceptionMsg.getMessage(),"text/plain")
        
        
        //messageLog.setStringProperty("materialDocumentDetailsLog", "Printing MaterialDetails")
        //messageLog.addAttachmentAsString("ResponsePayload_materialDocumentDetailsLog: ", logMsg, "text/plain");
        
         }
    
	
    return message
}




