import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
    
def Message processData(Message message) {
def totalCount =  message.getProperty("MatTotalCount")
def matExitFlag = false
def skipVal = message.getProperty("MatSkipVal");
def topVal = message.getProperty("MatTopVal");
def skipValTemp=topVal.toInteger()+skipVal.toInteger()
    
if(skipValTemp.toInteger() >= totalCount.toInteger()){
    matExitFlag=true;
    
}
skipVal=skipValTemp.toString()
message.setProperty("matExitFlag",matExitFlag);
message.setProperty("MatSkipVal", skipVal);


return message;
}