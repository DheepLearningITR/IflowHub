import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	def itemList = []
	message.setProperty("isInboundDel","T")
	
	//def deliveryItems=[]
	
	
	if (!object.A_InbDeliveryHeader.isEmpty()) {
	    itemList = object.A_InbDeliveryHeader.A_InbDeliveryHeaderType;
		
		if (!isCollectionOrArray(itemList)) {
			itemList = [itemList].toArray();
		}
	}else{
	    message.setProperty("isInboundDel","F")
	}
	
	itemList.each { record ->
	   if(null!=record.DeliveryDocument){
	       String isInboundDel="IN"
            message.setProperty(record.DeliveryDocument.concat(isInboundDel),record.DeliveryDocumentBySupplier)
	    }
		
	}
    return message
}
//Returns true if object is an array
boolean isCollectionOrArray(object) {
    [Collection, Object[]].any {
        it.isAssignableFrom(object.getClass())
    }
}
