import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def body = message.getBody(String.class);
   
    String json = JsonOutput.toJson(body)
    JsonSlurper slurper = new JsonSlurper()
   

     def result = slurper.parseText(json)
     def logger = message.getProperty("EnableLog");
	 logs = logger.toLowerCase()
	 
     def logItems=['postingDocumentNumber','materialDocumentNumber','materialCode','postingDate','plant','returnableMaterialQuantity','movementType','deliveryNoteItemNumber','externalDeliveryNoteNumber','storageLocation','unloadingPoint','customerCode']
     def errorLogMessages=['message']
     def errorLogCodes=['code']

     def errorItems=[]
     def erroCodes=[]
     def logMsg="";
     def errorLogMsg=""
     //def matList=getMaterialList()
     

     //message.setProperty("matList",matList)
     def materialDocumentTemp= message.getProperty("materialDocumentList")
     def materialDocumentList=[]
     println("List="+materialDocumentTemp)
    
      //String[] lines = result.split("\n");
      String[] lines = result.split("\n");
      
       int count=0;
      lines.each {line->
        if (line.startsWith('{"@context"')) {
            if(logs){
                count=count+1
                String countVal=count.toString();
                logMsg=logMsg.concat("Record No:").concat(countVal).concat("\n")
                def tempLog=fetchResponseLogs(line,logItems)
                logMsg=logMsg.concat(tempLog);
                logMsg=logMsg.concat("Result:").concat("Record Posted Sucessfully").concat("\n\n");     
                materialDocumentList.add(fetchErrorMaterialList(tempLog))

                
            }
           
    
        }else{
            if(line.indexOf("error")>0){
                
                
                 if(line.indexOf("404")>0|| line.indexOf("403")>0 || line.indexOf("401")>0 || line.indexOf("500")>0 || line.indexOf("502")>0){
                    throw new Exception(errorLogMessages)
                }
                //count=count+1
                //String countVal=count.toString();
                //errorLogMsg=errorLogMsg.concat("Record No:").concat(countVal).concat("\n")
                //errorLogMsg=errorLogMsg.concat(fetchErrorResponseLogs(line,errorLogItems));
                //errorLogMsg=errorLogMsg.concat("Result:").concat("Failure").concat("\n\n");
                errorItems.add(fetchErrorResponseLogs(line,errorLogMessages))
                erroCodes.add(fetchErrorResponseLogs(line,errorLogCodes))
                
            }
            
        }
    
}
    materialDocumentList=materialDocumentList.unique()
    def commons = materialDocumentTemp.intersect(materialDocumentList)
    def difference = materialDocumentTemp.minus(materialDocumentList)
    
   println("MatList==="+materialDocumentList)
   println("Difference="+difference)
   //println("errorItem="+errorItems)
   int errCount=0
   def inventoryDoc="inventory document"
   errorItems.each{errorItem->
   def inventoryocumeNo=difference.get(errCount)
   def errorCodes=erroCodes.get(errCount)
   errCount=errCount+1
   String countVal=errCount.toString();
   errorLogMsg=errorLogMsg.concat("Record No:").concat(countVal).concat("\n")
   errorLogMsg=errorLogMsg.concat(errorCodes)
   errorLogMsg=errorLogMsg.concat(fetchErrorMsg(errorItem,inventoryDoc,inventoryocumeNo))
   errorLogMsg=errorLogMsg.concat("Result:").concat("Failure").concat("\n\n");
   
   
   }
    def messageLog = messageLogFactory.getMessageLog(message);
    def propertyMap = message.getProperties()
    //Read logger from the Message Properties
    //def logger = message.getProperty("Logger");
    //logs = logger
    //if(logs=="true"||logs.equals("true")){
        logMsg=logMsg+errorLogMsg
        if(messageLog != null && (null!=logMsg && ""!=logMsg )){
        messageLog.setStringProperty("postingDocumentLog", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("ResponsePayload_postingDocumentLog: ", logMsg , "text/plain");
    }
         //}
    return message
}

def String fetchResponseLogs(String string,def logItems){
    String logMsg="";
    def items=[];
     logItems.each{logItem->
     int index=string.indexOf(logItem);
     
        if(index>0){
            String docString=""
            String tempString=string.substring(index);
            def checkValue=tempString.substring(tempString.indexOf(':')+1,tempString.indexOf(':')+2)
            if(!checkValue.toString().isInteger()){
                docString=tempString.substring(tempString.indexOf(':"')+2,tempString.indexOf('",'))
            }else{
                docString=tempString.substring(tempString.indexOf(':')+1,tempString.indexOf(','))
           
            }
            
            
            
            //String docString=tempString.substring(tempString.indexOf(':"')+2,tempString.indexOf('",'))
            logMsg=logMsg.concat(logItem).concat(":").concat(docString).concat("\n");
        }
        
    
     }
     return logMsg
}

def String fetchErrorResponseLogs(String string,def logItems){
    String logMsg="";
     logItems.each{logItem->
     int index=string.indexOf(logItem);
           
        if(index>0){
            String docString=""
            if(logItem.equals("message")){
                int detailsIndex=string.indexOf("details")
                if(detailsIndex>0){
                String tempString=string.substring(detailsIndex);
                tempString=tempString.substring(tempString.indexOf('[')+1,tempString.indexOf(']'))
                def jsonSlurper = new JsonSlurper();
                def object = jsonSlurper.parseText(tempString);                    
                docString=object.message
                }else{
                    String tempString=string.substring(string.indexOf("message")+9,string.indexOf("}"));
                    
                    docString=tempString
                }
            }else{
                String tempString=string.substring(index);
                def checkValue=tempString.substring(tempString.indexOf(':')+1,tempString.indexOf(':')+2)
         
                if(!checkValue.toString().isInteger()){
                    docString=tempString.substring(tempString.indexOf(':"')+2,tempString.indexOf('",'))
                }else{
                    docString=tempString.substring(tempString.indexOf(':')+1,tempString.indexOf(','))
            
                }
            }
         
         logMsg=logMsg.concat(logItem).concat(":").concat(docString).concat("\n");
        }

     }
     return logMsg
}


def String fetchErrorMaterialList(String string){
    def matDocNo=""
    int index=0;
    String matDocNum="materialDocumentNumber"
    //materialDocumentList.each{materialDocument->
        //println("materialDocument="+materialDocument)
        index=string.indexOf(matDocNum)
        if(index>0){
            String tempString=string.substring(index)
            matDocNo=tempString.substring(tempString.indexOf(':')+1,tempString.indexOf("\n"))
        }
    return matDocNo

}

def String fetchErrorMsg(String msg,String inventoryDoc,String inventoryDocNo){
    def errorMsg=""
    int index=0
    index=msg.indexOf(inventoryDoc)
    if(index>0){
        
        String tempString= msg.substring(0,index).concat(" "+inventoryDoc)
        tempString=tempString.concat(" ("+inventoryDocNo).concat(")")
        println(tempString)
        errorMsg=tempString.concat(msg.substring(index+inventoryDoc.length()))

    }else{
        errorMsg = msg
    }
    return errorMsg
}




