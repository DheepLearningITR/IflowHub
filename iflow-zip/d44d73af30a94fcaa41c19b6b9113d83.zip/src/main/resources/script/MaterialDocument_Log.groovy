import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    def logMsg="";
    def messageLog = messageLogFactory.getMessageLog(message);
	def itemList = []
	int count=0;
	String delvDocRec=""
	def logger = message.getProperty("EnableLog");
	logs = logger.toLowerCase()
	//message.setProperty("isDeliverySTO", 'false');
	def isRecordPresent='false'
	if (!object.A_MaterialDocumentItem.isEmpty()) {
	    itemList = object.A_MaterialDocumentItem.A_MaterialDocumentItemType;
		
		if (!isCollectionOrArray(itemList)) {
			itemList = [itemList].toArray();
		}
		isRecordPresent='true'
	}
    
	
	itemList.each { record ->
	    def logMsgTemp="";
	    count=count+1
        def sequenceNo = count
	    sequenceNo = sequenceNo.toString()
	    logMsgTemp = "Material Document Record : ".concat(sequenceNo)
        String itemLog="";
		String material=""
        String postingDate=""
        String plant=""
        String qnty=""
		String materialDocumentNumber=""
        if(record.Material!=null ){
		    material=record.Material
		    material="\n Material:".concat(material)
		}
		if(record.MaterialDocument!=null ){

		    materialDocumentNumber=record.MaterialDocument
		    materialDocumentNumber="\n MaterialDocumentNumber:".concat(materialDocumentNumber)
		}
		if(record.Plant!=null ){
            plant=record.Plant
		    plant="\n Plant:".concat(plant)
		}
		if(record.QuantityInBaseUnit!=null){
            qnty=record.QuantityInBaseUnit
            qnty="\n QuantityInBaseUnit:".concat(qnty)
        }
		if(record.to_MaterialDocumentHeader.A_MaterialDocumentHeaderType.PostingDate!=null ){
            //postingDate=Date.parse("yyyy-MM-dd'T'HH:mm:ss",record.to_MaterialDocumentHeader.A_MaterialDocumentHeaderType.PostingDate)
            postingDate=record.to_MaterialDocumentHeader.A_MaterialDocumentHeaderType.PostingDate
		    postingDate="\n Posting Date:".concat(postingDate)
		}

	    itemLog = material.concat(materialDocumentNumber).concat(plant).concat(qnty).concat(postingDate)
	    logMsgTemp = logMsgTemp.concat(itemLog)
	    if(count>1){
	    logMsg=logMsg.concat("\n\n").concat(logMsgTemp)  
	    }else{
	        logMsg=logMsgTemp
	    }
	    
	   
	}
     message.setProperty("isRecordPresent", isRecordPresent);
	message.setBody(body)

    if(messageLog != null && itemList.size()>0 && logs=="true"){
        messageLog.setStringProperty("materialDocumentDetailsLog", "Printing MaterialDetails")
        messageLog.addAttachmentAsString("ResponsePayload_materialDocumentDetailsLog: ", logMsg, "text/plain");
        
         }
    
	
    return message
}



//Returns true if object is an array
boolean isCollectionOrArray(object) {
    [Collection, Object[]].any {
        it.isAssignableFrom(object.getClass())
    }
}

