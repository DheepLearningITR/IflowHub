import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
	def plants = message.getProperty("Plants");
	def movementTypes = message.getProperty("MovementTypes");
	def sapClient=message.getProperty("SAPClient");
	def materialsFrom = message.getProperty("MaterialsFrom");
	def vendorExclList=message.getProperty("VenodorExclusion")
	def custGoodsRec = message.getProperty("CustGoodsRec");
	def timLag = message.getProperty("TimeLag");
	int timeLapse = timLag.toInteger()
	String exclusionMsg="Specify the list of STO vendors, for which records can be excluded"
	
	def currentDate=Date.parse("yyyy-MM-dd'T'HH:mm:ss",message.getProperty("queryLastRunTime"))
	 use (groovy.time.TimeCategory) {
  
        //currentDate= currentDate-15.seconds
        currentDate= currentDate-timeLapse.seconds
    }
    def lastSyncDate = currentDate.format('yyyy-MM-dd');
	def lastSyncTime_HH = currentDate.format('HH');
	def lastSyncTime_mm = currentDate.format('mm');
	def lastSyncTime_ss = currentDate.format('ss');
	int lasthour=Integer.parseInt(lastSyncTime_HH)
	def lastSyncTime="PT"+lastSyncTime_HH+"H"+lastSyncTime_mm+"M"+lastSyncTime_ss+"S"
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    String materialSelect="";
    def materialCodelist=""
    if(materialsFrom=='RPM'||materialsFrom.equals('RPM')){
        materialCodelist=object.MaterialMasterGeneralData.MaterialMasterGeneralData.materialCode
    }else{
        materialCodelist=object.A_Product.A_ProductType.Product
    }
    
    
   
	String filterCriteria = "(";
	if(object != null) {
	    materialSelect = "Material,Plant,QuantityInBaseUnit,EntryUnit,Customer,Supplier,GoodsMovementType,InventoryStockType,MaterialDocument,MaterialDocumentItem,Delivery,DeliveryItem,IssuingOrReceivingPlant,StorageLocation,UnloadingPointName,IsAutomaticallyCreated,InventoryUsabilityCode,to_MaterialDocumentHeader/DocumentDate,to_MaterialDocumentHeader/PostingDate,to_MaterialDocumentHeader/CreationDate,to_MaterialDocumentHeader/CreationTime,to_MaterialDocumentHeader/ReferenceDocument,to_MaterialDocumentHeader/MaterialDocumentHeaderText,to_MaterialDocumentHeader/MaterialDocumentYear,to_SerialNumbers/SerialNumber"    
	    
	    if(custGoodsRec=='X'){
	    materialSelect = "Material,Plant,QuantityInBaseUnit,EntryUnit,Customer,Supplier,GoodsMovementType,InventoryStockType,MaterialDocument,MaterialDocumentItem,Delivery,DeliveryItem,IssuingOrReceivingPlant,IsAutomaticallyCreated,InventoryUsabilityCode,StorageLocation,UnloadingPointName,GoodsRecipientName,to_MaterialDocumentHeader/DocumentDate,to_MaterialDocumentHeader/PostingDate,to_MaterialDocumentHeader/CreationDate,to_MaterialDocumentHeader/CreationTime,to_MaterialDocumentHeader/ReferenceDocument,to_MaterialDocumentHeader/MaterialDocumentHeaderText,to_MaterialDocumentHeader/MaterialDocumentYear,to_SerialNumbers/SerialNumber"    
	    }
	    
	    
	    if(null != materialCodelist){
	          if (!isCollectionOrArray(materialCodelist)) {
			        materialCodelist = [materialCodelist].toArray();
		    }
	        filterCriteria=filterCriteria.concat(prepareMaterialCodeFilter(materialCodelist))
	   }
	    
		
		if(null != plants) {
			filterCriteria=filterCriteria+") ";
			filterCriteria=filterCriteria.concat(preparePlantFilter(plants))
			//filterCriteria=filterCriteria+")";
		} 
		
		if(!vendorExclList.equals(exclusionMsg) && !vendorExclList.isEmpty()){
		    filterCriteria=filterCriteria+") ";
		    filterCriteria=filterCriteria.concat(prpeareVendorExclusionFilter(vendorExclList))    
		}
		
		if(null != movementTypes && "" !=movementTypes) {
			filterCriteria=filterCriteria+") ";
			filterCriteria=filterCriteria.concat(prepareMovementTypeFilter(movementTypes))
			
			//filterCriteria=filterCriteria+")";
		} else {
			filterCriteria=filterCriteria+")";
		}
		
		
		
		String dateTime=filterCurrentTimeRecords(lastSyncDate,lastSyncTime)
		//String dateTime=filterCurrentTimeRecords(lastSyncDate)
		
		if(null!=dateTime &&""!=dateTime){
			filterCriteria=filterCriteria.concat(dateTime)
			filterCriteria=filterCriteria+")";
		}else{
			filterCriteria=filterCriteria+"))";
		}
		
		 
		
		
		//filterCriteria=filterCriteria.concat(filterCurrentTimeRecords(lastSyncDate,lastSyncTime))
		if(!sapClient.equals("Define SAP Client")&&(null!=sapClient && !sapClient.isEmpty())){
		    sapClient ="&sap-client=".concat(sapClient)
            //message.setProperty("sapClient",sapClient)
        }else{
            sapClient=""
        }
		println("materialFilter==="+filterCriteria)
		if(null!=sapClient&&!sapClient.isEmpty()){
		  filterCriteria=filterCriteria.concat(sapClient)
		}
		message.setProperty("materialFilter", filterCriteria);
		message.setProperty("materialSelect", materialSelect);
	}
	
	
    return message
}


def String prepareMovementTypeFilter(String movementType) {
		String[] movementTypes = movementType.split(',');
		String movementTypeFilter = "and (";
		
		int count=0
		movementTypes.each { record ->
			String tempPayload
			if (count==0) {
				tempPayload = "(GoodsMovementType eq '"
			} else {
				tempPayload = " or (GoodsMovementType eq '"
			}
			tempPayload = tempPayload + record.trim() +"'"+")"
			movementTypeFilter=movementTypeFilter.concat(tempPayload)
			count++
		}
		
		movementTypeFilter=movementTypeFilter.concat(")")
		
	return movementTypeFilter;
}

def String filterCurrentTimeRecords(def lastSyncDate,def lastSyncTime){
	
	String equalDtStr = " and ((to_MaterialDocumentHeader/CreationDate eq datetime'"
	String gtDtStr = " to_MaterialDocumentHeader/CreationDate gt datetime'"
    String latestDate = equalDtStr
	String latestSyncTime= " and to_MaterialDocumentHeader/CreationTime gt time'";
	lastSyncDate=Date.parse("yyyy-MM-dd",lastSyncDate).format("yyyy-MM-dd'T'HH:mm:ss");
	latestDate=latestDate+lastSyncDate
	latestSyncTime=latestSyncTime+lastSyncTime
	latestDate=latestDate+"'"+latestSyncTime+"')"
	latestDate =latestDate + " or (" + gtDtStr + lastSyncDate+"'))"
	
	//latestDate=latestDate+"')"
	return latestDate;
    
}

def String prepareMaterialCodeFilter(def materialCodelist) {
		//String[] materialCode = materialCodelist.split(',');
		String materialCodeFilter = "(";
		
		int count=0
		materialCodelist.each { record ->
			String tempPayload
			if (count==0) {
				tempPayload = "(Material eq '"
			} else {
				tempPayload = " or (Material eq '"
			}
			record=record.replaceAll("'","''")
			record=record.replaceAll("%","%25")
			record=record.replaceAll("&","%26")
			record=record.replaceAll("#","%23")
			record=record.replaceAll("\\+","%2B")
			record=record.replaceAll("\\?","%3F")
			record=record.replaceAll("\\\\","%2F")
			record=record.replaceAll("\\[","%5B")
			record=record.replaceAll("\\]","%5D")
			record=record.replaceAll(";","%3B")
			tempPayload = tempPayload + record.trim() +"'"+")"
			materialCodeFilter=materialCodeFilter.concat(tempPayload)
			count++
		}
	return materialCodeFilter;
}


def String preparePlantFilter(String plants) {
		String[] plantCodes = plants.split(',');
		String plantFilter = "and (";
		
		int count=0
		plantCodes.each { record ->
			String tempPayload
			if (count==0) {
				tempPayload = "(Plant eq '"
			} else {
				tempPayload = " or (Plant eq '"
			}
			tempPayload = tempPayload + record.trim() +"'"+")"
			plantFilter=plantFilter.concat(tempPayload)
			count++
		}
		
		//plantFilter=plantFilter.concat(")")
		
	return plantFilter;
}

//Returns true if object is an array
boolean isCollectionOrArray(object) {
    [Collection, Object[]].any {
        it.isAssignableFrom(object.getClass())
    }
}

// preparing the exclusionList of the vendors provided 

def String prpeareVendorExclusionFilter(String vendors) {
	String[] vendorCodes = vendors.split(',');
	String vendorFilter = "and (";
	
	int count=0
	vendorCodes.each { record ->
	    String tempPayload
	    if (count==0) {
				tempPayload = "(Supplier ne '"
			} else {
				tempPayload = " and (Supplier ne '"
			}
			tempPayload = tempPayload + record.trim() +"'"+")"
			vendorFilter=vendorFilter.concat(tempPayload)
			count++
		
	}
		
	return vendorFilter;
}