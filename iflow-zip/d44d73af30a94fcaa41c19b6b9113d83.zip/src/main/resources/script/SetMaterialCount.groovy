import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) { 
    
    int matTotalCount=0;
    int matTopVal=0;
    //def materialsFrom = message.getProperty("MaterialsFrom");
    String maxCount = message.getProperty("MaterialCount");
    String threshold = message.getProperty("CountThreshold");
    def exitFlag = message.getProperty("exitFlag")
    def isRecordPresent='false'
    int thresholdCount=threshold.toInteger();
    def isInteger=isValidCount(message.getBody(java.lang.String))
    String saveLastSyncDateFlag = false
    if(isInteger ){
        matTotalCount=message.getBody(java.lang.String).toInteger()
        if(matTotalCount>0){
            isRecordPresent='true'
        }else{
            if(exitFlag == true){
                    
                    saveLastSyncDateFlag = true
                    }
        }
        
        
          //if(matTotalCount>thresholdCount){
          //    throw new Exception("Cannot fetch material information. The value fetched from source system is more than the threshold limit of "+threshold)
          //}  
        
          
        int max = maxCount.toInteger()
        if(matTotalCount>=max){
            matTopVal=maxCount.toInteger()
        }else{
            matTopVal = matTotalCount
        }
        
    }
    message.setProperty("SaveLastSyncDateFlag",saveLastSyncDateFlag)
	message.setProperty("MatTotalCount",matTotalCount.toString())
	message.setProperty("MatSkipVal", "0");
	message.setProperty("MatTopVal",matTopVal.toString());
	message.setProperty("isRecordPresent", isRecordPresent);
	message.setBody("")
    return message;
   
    
}

def isValidCount(value) {""
     //if(!value.toString().isInteger()){
        //throw new Exception("Cannot fetch material information. Please verify the URL for the Material Master Source , URL might be incorrect")
    //}
    value.toString().isInteger()
}
