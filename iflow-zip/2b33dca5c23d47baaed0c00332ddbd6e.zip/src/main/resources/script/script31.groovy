import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    def parsed = new XmlParser().parseText(body);
    parsed.Items.findAll { it.ParentItemId.text() != '0' }*.replaceNode{};
    message.setBody(XmlUtil.serialize(parsed));
    return message;
}
