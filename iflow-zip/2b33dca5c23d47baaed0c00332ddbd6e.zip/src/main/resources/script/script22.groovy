
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();
      
      
       //Properties 
       def map = message.getProperties();
       def quoteId = map.get("quoteId");
       def editQuoteId = map.get("newQuoteId");
       
       if(null != quoteId && !quoteId.equals("")){
           message.setProperty("quoteId", quoteId);
       }else if(null != editQuoteId && !editQuoteId.equals("")){
           message.setProperty("quoteId", editQuoteId);
       }
       
       return message;
}