import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import javax.xml.bind.DatatypeConverter;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

def Message processData(Message message) {
    
    def headers = message.getHeaders() as Map<String, Object>;
    def map = message.getProperties();
    def cpqCredentials = map.get("cpqCredentials");
    def domain = map.get("sapCpqDomain");
    
  def service = ITApiFactory.getApi(SecureStoreService.class, null);
  def credential = service.getUserCredential(cpqCredentials);
  
  if (credential == null){
    String error = "No credential found for alias" + cpqCredentials;
    throw new IllegalStateException(error);
  }
  
  String user = credential.getUsername();
  String password = new String(credential.getPassword());

  String authString = user+"#"+domain+":"+password;
  String encoded = authString.bytes.encodeBase64().toString();
 
   message.setProperty("authorization","Basic "+encoded);
   
  return message;
  
}
