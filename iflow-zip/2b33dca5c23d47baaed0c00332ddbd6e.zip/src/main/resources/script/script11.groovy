import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {	

    def body = new HashMap<String,String>();
	def properties = message.getProperties() as Map<String, Object>;
	
	def newRevision = properties.get("");
    body.put("NewRevisionName",newRevision)
   
   message.setBody(JsonOutput.toJson(body));

	
	
	return message;
}