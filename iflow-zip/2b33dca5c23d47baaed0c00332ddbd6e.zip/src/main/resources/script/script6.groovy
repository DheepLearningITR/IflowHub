/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
        jsonObject = jsonObject.get("Quote");
    
    // Handling Header Parsing
     def involvedParties = jsonObject.get("InvolvedParties");
    def customFields = jsonObject.get("CustomFields");
    jsonObject.put("InvolvedParties",involvedParties.get("element"));
    
    //handling CustomFields parsing
    def headerCustomFields = jsonObject.get("CustomFields");
    if(headerCustomFields != "" && null != headerCustomFields){
        if (customFields?.get("element")) {
            def customFieldsArray = customFields.get("element") instanceof List ? customFields.get("element") : [customFields.get("element")]
            jsonObject.put("CustomFields", customFieldsArray);
        } 
        
    }else {
        jsonObject.put("CustomFields", []);
    }
    
 
    def headerCommentsSection = jsonObject.get("Comments");
    
    def headerInvolvedPartiesSection = jsonObject.get("InvolvedParties");
    
    
    if(headerInvolvedPartiesSection != "" && null != headerInvolvedPartiesSection){
    
        if(headerInvolvedPartiesSection instanceof java.util.Map){
            def array = [];
            array.push(headerInvolvedPartiesSection);
            jsonObject.put("InvolvedParties", array);
        }
    }else{
        def array = [];
        jsonObject.put("InvolvedParties", array);
    }
    
    if(headerCommentsSection != "" && null != headerCommentsSection){
    
    def quoteComments = headerCommentsSection.get("QuoteComment");
    jsonObject.put("Comments", quoteComments);
        if(quoteComments instanceof java.util.Map){
            def array = [];
            array.push(quoteComments);
            jsonObject.put("Comments", array);
        }
    }else{
        def array = [];
        jsonObject.put("Comments", array);
    }
    
    // Handling Item Level Parsing
    
     def itemSection = jsonObject.get("Items");
     def items = itemSection.get("element");
     
     jsonObject.put("Items",items);
    if(items instanceof java.util.Map){
            def array = [];
            array.push(items);
            jsonObject.put("Items", array);
        }
    
  
      def list = jsonObject.get("Items");
     
       for(int i=0;i<list.size();i++){
           def item = list.get(i);// map
           
           def itemCommentsSection = item.get("Comments");
           if(itemCommentsSection != "" && null != itemCommentsSection){
               def itemComments = itemCommentsSection.get("element");
           
           item.put("Comments",itemComments);
           
           if(itemComments instanceof java.util.Map){
                def array = [];
                array.push(itemComments);
                item.put("Comments", array);
            }
          }else{
                def array = [];
                item.put("Comments", array);
            }
    
       }
   
    jsonObject.put("Items",list)
    
    
    
    //println(JsonOutput.toJson(jsonObject));
    
    message.setBody(JsonOutput.toJson(jsonObject))
    return message;
}