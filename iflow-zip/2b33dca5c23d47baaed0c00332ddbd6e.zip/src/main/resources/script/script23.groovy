import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String
    def properties = message.getProperties() as Map<String, Object>;
    def payload = properties.get("originalJsonPayload");
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(payload);
    def comments = jsonObject.get("Comments");
    
    message.setBody(JsonOutput.toJson(comments));
    return message;
}