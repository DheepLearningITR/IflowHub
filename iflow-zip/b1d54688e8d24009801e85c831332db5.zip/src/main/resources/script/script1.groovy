/*
   The integration developer needs to create the method processData
   This method takes Message object of package com.sap.gateway.ip.core.customdev.util
   which includes helper methods useful for the content developer:
   The methods available are:
    public java.lang.Object getBody()
   public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties)
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders)
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {

        def body = message.getBody(String.class);
        def jsonSlurper = new JsonSlurper();
        def requestPayload = jsonSlurper.parseText(body);
        def httpmethod = message.getHeaders();

        if ( httpmethod.get("CamelHttpMethod").equals("PATCH") ) {
                def map = message.getHeaders();
                def queryPath = map.get("CamelHttpPath");
                def countOpRemove = 0;
                def countOpAdd    = 0;
                def countOpTotal  = 0;
                requestPayload.id = queryPath.replaceAll('-', "").toUpperCase();
                message.setProperty("inPatchReplaceAll","false");
                message.setProperty("p_roleguid",requestPayload.id.trim());
                
                requestPayload.Operations.each {
                        countOpTotal++;
                        def Operation = it.op;
                        def path = it.path;

                        it.remove('$ref');
                        // Special case: where in patch replace all members are coming
                        if ( Operation.equals("remove") && path.equals("members") ) { 
                                countOpRemove++; // either line 62 countOpRemove++ or this line
                                def jsonOP = JsonOutput.toJson(requestPayload);
                                message.setBody(jsonOP);
                                message.setProperty("inPatchReplaceAll","true");
                                return message;
                        }

                        if ( Operation.equals("remove") && !path.equals("members") ) {
                                countOpRemove++;
                                path = path.substring(path.indexOf("\"") + 1);
                                path = path.substring(0, path.indexOf("\""));
                                def builder = new JsonBuilder() // Create a value object which is not coming incase of remove operation
                                              builder {
                                        value path
                                }
                                def value2 = [];
                                value2.add(builder.content);
                                it.value = value2;
                        }

                        if ( Operation.equals("remove") || Operation.equals("add")) { // to handel unknow Op cases , need to find better way
                                it.value[0].remove('$ref'); // in remove case this segment will not come
                                def memberid = it.value[0].value;
                                it.value[0].value = memberid.replaceAll('-', "").toUpperCase();

                        }

                };

                countOpAdd = countOpTotal - countOpRemove;
                message.setProperty("countOpAdd",countOpAdd );
                message.setProperty("countOpRemove",countOpRemove);
                def jsonOP = JsonOutput.toJson(requestPayload);
                message.setBody(jsonOP);
        }

        return message;
}