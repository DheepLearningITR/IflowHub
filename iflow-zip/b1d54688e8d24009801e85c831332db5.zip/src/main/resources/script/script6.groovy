/*
   The integration developer needs to create the method processData
   This method takes Message object of package com.sap.gateway.ip.core.customdev.util
   which includes helper methods useful for the content developer:
   The methods available are:
    public java.lang.Object getBody()
   public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties)
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders)
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

        def headers = message.getHeaders();
        def headerResponseCode = headers.get("CamelHttpResponseCode").toString();

        if ( !headerResponseCode.equals("500") ) {
                def map = message.getProperties();
                def ex = map.get("CamelExceptionCaught");
                
                if ( ex != null ) {
                        if (ex.getClass().getCanonicalName().equals("com.sap.it.xml.validator.exception.XSDSchemaValidationException")) {
                                message.setHeader("CamelHttpResponseCodeOriginal", "400"); // If request in not valid SCIM payload
                                message.setBody("");
                        }

                        if ( ex.getClass().getCanonicalName().equals("javax.script.ScriptException")) {
                                message.setHeader("CamelHttpResponseCodeOriginal", "400"); // invalid payload exception
                                message.setBody("");
                        }

                        else if (headerResponseCode.equals("202")) {
                                try {
                                        def body = message.getBody(String.class);
                                        def errorbody = new XmlSlurper().parseText(body);

                                        if (errorbody.batchChangeSetResponse.batchChangeSetPartResponse[0].statusCode.text().equals("500")) {
                                                message.setHeader("CamelHttpResponseCodeOriginal", "404"); // invalid group id in put call
                                                message.setBody("");
                                        }
                                        else
                                        {
                                                // this case is for remove all via PATCH request // 200 internal code
                                                message.setHeader("CamelHttpResponseCodeOriginal", "204"); // 204 all delete successfull
                                                message.setBody("");
                                        }
                                }
                                catch(Exception exr) {
                                        message.setHeader("CamelHttpResponseCodeOriginal", "400");
                                        message.setBody("");
                                }
                                
                        }
                        else{
                                def body = "";
                                message.setHeader("CamelHttpResponseCodeOriginal", "400"); // If request in not valid SCIM payload
                                message.setBody(body);
                        }
                }
        }
        else{
                message.setBody("");
                message.setHeader("CamelHttpResponseCodeOriginal", "404");
        }

        return message;
}