importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
    var map = message.getHeaders();
    
    var prp = message.getProperties();
    var isScimResponseRequired = prp.get("isScimResponseRequired");
    
     var query = "";
                                
    if (isScimResponseRequired.equals("true")) {
             query = '$select=ObjectID,ETag,ID,Description,languageCode,CurrentVersionNumberID,languageCodeText,Name,languageCode1,languageCode1Text,CreationDateTime,EntityLastChangedOn,IdentityBusinessRoleAssignedBusinessUser/BusinessRoleUUID,IdentityBusinessRoleAssignedBusinessUser/BusinessRoleID,IdentityBusinessRoleAssignedBusinessUser/UserUUID,IdentityBusinessRoleAssignedBusinessUser/UserID,IdentityBusinessRoleAssignedBusinessUser/ParentObjectID,IdentityBusinessRoleAssignedBusinessUser/EmployeeUUID,IdentityBusinessRoleAssignedBusinessUser/UserName&$expand=IdentityBusinessRoleAssignedBusinessUser';
    }
    else{
                     query = '$select=ObjectID,ETag,ID,Description,languageCode,CurrentVersionNumberID,languageCodeText,Name,languageCode1,languageCode1Text,CreationDateTime,EntityLastChangedOn,IdentityBusinessRoleAssignedBusinessUser/BusinessRoleUUID,IdentityBusinessRoleAssignedBusinessUser/BusinessRoleID,IdentityBusinessRoleAssignedBusinessUser/UserUUID,IdentityBusinessRoleAssignedBusinessUser/UserID,IdentityBusinessRoleAssignedBusinessUser/ParentObjectID,IdentityBusinessRoleAssignedBusinessUser/EmployeeUUID,IdentityBusinessRoleAssignedBusinessUser/UserName';
    }

    var queryPath = map.get("CamelHttpQuery");
    var doubleQuote = "%22";
    var singleQuote = "%27";
    if (queryPath) {
        
        if (queryPath.toLowerCase().indexOf('filter='.toLowerCase()) != -1) {
            var queryParam = queryPath.replace("displayName", "ID");
            var filterParam = queryParam.replaceAll(doubleQuote,singleQuote); // Replace " with '
             if (filterParam)
            {
                message.setProperty("p_queryParam", query+'&'+'$' + filterParam);
            }
            else{
                message.setProperty("p_queryParam", query);
            }
        } else if ((queryPath.toLowerCase().indexOf('startIndex='.toLowerCase()) != -1) || (queryPath.toLowerCase().indexOf('count='.toLowerCase()) != -1)) {
            var queryParam = "";
            var pagingParam = queryPath.replace("startIndex", "skip").replace("count", "top");
            var tokenValues = pagingParam.split('&');
             for (x in tokenValues) {
                if (tokenValues[x].startsWith("skip")) {
                    var skipIndex = parseInt(tokenValues[x].substring(5));
                     message.setProperty("p_startIndex", tokenValues[x].substring(5));
                    if (skipIndex <= 1)
                        skipIndex = 1;
                    tokenValues[x] = "skip=" + (skipIndex - 1);
                }
                queryParam += ((queryParam === "") ? "" : '&') + '$' + tokenValues[x];
                if (tokenValues[x].startsWith("top")) {
                    message.setProperty("p_itemsPerPage", tokenValues[x].substring(4));
                }
            }
            if (queryParam)
            {
                message.setProperty("p_queryParam", query+'&'+queryParam);
            }
            else{
                message.setProperty("p_queryParam", query);
            }
        }
        else{
               message.setProperty("p_isQueryValid","false");
            }
    } else {
        var queryPath = map.get("CamelHttpPath");
        var guid_pattern = new RegExp('[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}');
          if (guid_pattern.test(queryPath) === true)
             {
            var objectID = queryPath.replaceAll("-","").toUpperCase();
            message.setProperty("p_queryParam", query);
            message.setProperty("p_roleguid", objectID);
            message.setProperty("p_odataread", "true");
            }
            else if (queryPath.equals("/Groups")){
              message.setProperty("p_queryParam", query);
              message.setProperty("p_odataread","false");
        }
            else
            {
              message.setProperty("p_isQueryValid","false");
            }
        }
       
    return message;
}