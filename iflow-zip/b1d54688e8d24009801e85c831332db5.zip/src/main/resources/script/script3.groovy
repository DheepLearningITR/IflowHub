/*
   The integration developer needs to create the method processData
   This method takes Message object of package com.sap.gateway.ip.core.customdev.util
   which includes helper methods useful for the content developer:
   The methods available are:
    public java.lang.Object getBody()
   public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties)
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders)
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

        def headers = message.getHeaders();
        def headerResponseCode = headers.get("CamelHttpResponseCode").toString();
        
        if (!headerResponseCode.equals("500") ) {
                try {
                        def body = message.getBody(String.class);
                        def errorbody = new XmlSlurper().parseText(body);
                        map = message.getProperties();
                        if (errorbody.batchChangeSetResponse.batchChangeSetPartResponse[0].statusCode.text().equals("500")) {

                                def countOpAdd    = map.get("countOpAdd");
                                def countOpRemove = map.get("countOpRemove");

                                if ( countOpRemove > 0 &&  countOpAdd == 0 ) {
                                        message.setHeader("CamelHttpResponseCodeOriginal", "404");
                                }
                                else if ( countOpRemove == 0 &&  countOpAdd > 0 ) {
                                        message.setHeader("CamelHttpResponseCodeOriginal", "409"); 
                                }
                                else {
                                        message.setHeader("CamelHttpResponseCodeOriginal", "409"); 
                                }

                                message.setBody("");
                              
                        }

                        else if (errorbody.batchChangeSetResponse.batchChangeSetPartResponse[0].statusCode.text().equals("204") ) {
                                message.setHeader("CamelHttpResponseCodeOriginal", "204");
                        }

                        else if (errorbody.batchChangeSetResponse.batchChangeSetPartResponse[0].statusCode.text().equals("202")) {
                                message.setHeader("CamelHttpResponseCodeOriginal", "202");
                        }
                        else{
                                def map = message.getProperties();
                                def ex = map.get("CamelExceptionCaught");
                                if (ex!=null) {
                                        if (ex.getClass().getCanonicalName().equals("com.sap.it.xml.validator.exception.XSDSchemaValidationException") || ex.getClass().getCanonicalName().equals("javax.script.ScriptException") ) {
                                                message.setHeader("CamelHttpResponseCodeOriginal", "400"); // If request in not valid SCIM payload
                                                message.setBody("");
                                        }
                                }
                                else{
                                        message.setHeader("CamelHttpResponseCodeOriginal", "404");
                                        message.setBody("");
                                }
                        }

                }
                catch(Exception ex) {
                        message.setHeader("CamelHttpResponseCodeOriginal", "400");
                        message.setBody("");
                }
        }

        else {
                message.setBody("Content Not Found");
                message.setHeader("CamelHttpResponseCodeOriginal", "404"); // some case C4C sending html response code with 500 error

        }
        return message;
}