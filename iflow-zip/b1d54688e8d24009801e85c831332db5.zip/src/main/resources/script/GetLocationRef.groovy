import com.sap.it.api.mapping.*;
def String getLocation(String objectID, MappingContext context){
    String lv_path = context.getHeader("CamelHttpUrl");
    String hostURL = lv_path.substring(0, lv_path.indexOf("/http/Groups"));
    return hostURL + "/http/Groups/" + objectID;
    
}
def String getUserReference(String objectID, MappingContext context){
    String lv_path = context.getHeader("CamelHttpUrl");
    String hostURL = lv_path.substring(0, lv_path.indexOf("/http/Groups"));
    return hostURL + "/http/Users/" + objectID;
    
}
def String getTotalGroupCount(String localCount, MappingContext context){
    
        if (context.getHeader("GroupCount"))
            return context.getHeader("GroupCount");
        else
            return localCount;
        
}

def String getItemsPerPage(String arg1, MappingContext context){
        return context.getProperty("p_itemsPerPage");
}

def String getStartIndex(String arg1, MappingContext context){
        return context.getProperty("p_startIndex");
}