importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
    var body = String(message.getBody( new java.lang.String().getClass()));
    //create json from string object
    body = JSON.parse(body);
    
    var messsageLog = messageLogFactory.getMessageLog(message); 
    
    messsageLog.addAttachmentAsString("Log message", body, "application/json"); 
     
    return message;
}