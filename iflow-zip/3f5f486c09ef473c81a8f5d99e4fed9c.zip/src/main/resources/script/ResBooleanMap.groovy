import com.sap.it.api.mapping.*;

def String resBoolean(String input) {
    if (input == "X") {
        return "true"
    } else if (input == "") {
        return "false"
    }
    
    return input
}
