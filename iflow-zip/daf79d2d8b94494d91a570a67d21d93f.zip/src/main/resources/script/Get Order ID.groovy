
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(String.class);
       message.setProperty("ems_body", body);
       def root = new JsonSlurper().parseText(body);
       
       order_id = "'" + root.data.ServiceOrder + "'"
       
       message.setProperty("order_id", order_id);
       return message;
}