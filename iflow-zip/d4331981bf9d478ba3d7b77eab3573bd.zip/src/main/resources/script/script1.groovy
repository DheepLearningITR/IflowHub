import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message) {
	
	def pmap = message.getProperties();
	def messageLog = messageLogFactory.getMessageLog(message);
	
	String enableLogging = pmap.get("ENABLE_LOGGING");
	String query = pmap.get("QUERY");
	String entity = pmap.get("ENTITY");
	String ECCompany = pmap.get("ECCOMPANY");
	String ECCredentials = pmap.get("SFSF_EC_CREDENTIALS");
    String ECURL = pmap.get("SFSF_EC_URL");
	
	// Prepare string for MPL attachment content
	String queryParameters = "";
	queryParameters = "ENABLE_LOGGING = " + enableLogging;
	queryParameters = queryParameters + "\nQUERY = " + query;
	queryParameters = queryParameters + "\nENTITY = " + entity;
	queryParameters = queryParameters + "\nECCOMPANY = " + ECCompany;
	
	// Log parameters	
	if (messageLog != null) {
		messageLog.addAttachmentAsString("Query Parameters", queryParameters, "text/plain");
	}

	if(enableLogging != null && enableLogging.toUpperCase().equals("TRUE")){
		def body = message.getBody(java.lang.String) as String;
		if(messageLog != null){
			messageLog.addAttachmentAsString("Payload ERP Query", body, "text/xml");
		}
	}
	
	// multiple EC one ERP handling
    if(ECCompany != null && !ECCompany.equals("")){
        
        // check if properties are configured correctly
        if(ECURL != null && ECURL.equals("\${property.ADDRESS_SFSF}") && ECCredentials != null && ECCredentials.equals("\${property.CREDENTIALS_SFSF}")) {
            
            def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
            String mappedValue = valueMapApi.getMappedValue('ERP', 'ECCompany', ECCompany, 'EC', 'URL; SFSF Credentials; HTTP Credentials');
            
            if(mappedValue != null && !mappedValue.equals("")) {
                String[] mappedValueArray;
                mappedValueArray = mappedValue.split(';');
                
                message.setProperty("ADDRESS_SFSF", mappedValueArray[0].trim());
                message.setProperty("CREDENTIALS_SFSF", mappedValueArray[1].trim());
            }else {
                throw new Exception("Configuration Error: No entry in value mapping \"Mapping of Employee Central Instance ID to Enable Connection of Multiple Employee Central Instances\" found for value " + ECCompany + "    ");
            }
        } else {
            throw new Exception("Configuration Error: Please enter \${property.ADDRESS_SFSF} in the address field and \${property.CREDENTIALS_SFSF} in the credentials field to be able to use the Multiple Employee Central Instances feature");
        }
    } 
    
    // Initialize Loop Counter and set property
	Integer loopCounter = 0;
	message.setProperty("loopCounter", loopCounter);
	
	//create ID & UUID for Notifications
	String UUID = java.util.UUID.randomUUID().toString();
	String ID = UUID.replaceAll("-", "").toUpperCase();
	
	message.setProperty("START_NOTIFICATION_UUID", UUID);
	message.setProperty("START_NOTIFICATION_ID", ID);
	
	UUID = java.util.UUID.randomUUID().toString();
	ID = UUID.replaceAll("-", "").toUpperCase();
	
	message.setProperty("END_NOTIFICATION_UUID", UUID);
	message.setProperty("END_NOTIFICATION_ID", ID);
	
	return message;
}