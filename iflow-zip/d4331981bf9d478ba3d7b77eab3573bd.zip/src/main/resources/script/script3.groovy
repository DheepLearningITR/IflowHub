import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	def pmap = message.getProperties();
	def messageLog = messageLogFactory.getMessageLog(message);
	
	String enableLogging = pmap.get("ENABLE_LOGGING");
	
	Integer loopCounter = message.getProperty("loopCounter");
	
	String body = message.getBody(java.lang.String) as String;
	
	//log payload after mapping
	if(enableLogging != null && enableLogging.toUpperCase().equals("TRUE")){
		if(messageLog != null){
			messageLog.addAttachmentAsString("Payload " + loopCounter.toString() + " After Mapping", body, "text/xml");
		}
	}	
	
	return message;
}