import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.json.JsonOutput;


def Message parseHeaders(Message message) {

	def map = message.getHeaders();

    def sfsfTagFound = map.get("sfsfTagFound");
	message.setProperty("sfsfTagFound", sfsfTagFound);
	
    def testRun = map.get("testRun");
	message.setProperty("testRun", testRun);	

	//used to clear hashmap global variables
	def emptyHmap = new HashMap<String, String>();
	emptyHmap.put('null','');
	message.setProperty("emptyHmap", emptyHmap);
	
	return message;
}

def Message process_creates(Message message) {
	
	def body = message.getBody(java.lang.String);
	def map = message.getProperties();
    HashMap<String, String> hmapTag = map.get("hmap_sfsfTags"); 

	//def sumCreate = 0;
	def Root = new XmlParser().parseText(body);
    Root.attribute.each{r->
        def cbrId = 'cbr_'+r.id[0].text();
        if(hmapTag != null && hmapTag.containsKey(cbrId)){
            r.replaceNode{}; //remove, already exists
        }else{
            r.id[0].value = cbrId; //with prefix cbr_
        }
    }
    
    message.setProperty("hmap_sfsfTags","");      //clear processed data
    message.setBody(XmlUtil.serialize(Root));
 
	return message;
}

def Message filter_tagNames(Message message) {
	
	def body = message.getBody(java.lang.String);
	def map = message.getProperties();
	HashMap<String, String> hmapTexts = map.get("hmap_sfsfTagTexts"); 

    Set<String> duplicateTags = new HashSet<>();
    def sumDuplicateTags = 0;
    //def sumDuplicateTagTexts = 0;
    //List<String> duplicateTagTexts = [];

	def sumCreateTags = 0;
	def Root = new XmlParser().parseText(body);
    Root.file.each{
        it.attribute.each{r->
            def duplicateFound = false;
            def cbrId = r.id[0].text();
    
            //Talent Competency NOT FOUND in SFSF Tag, check for duplicates, otherwise CREATE
            if(hmapTexts){
                //check for Duplicates = DIFFERENT ID, SAME Name
                def name = 'en_US-'+r.translation_en_US[0].title.text().trim().toLowerCase(); 
                String duplicateId = hmapTexts.get(name);
                if(duplicateId!=null && cbrId!=duplicateId){
                    //Duplicate found, remove Skill
                    r.replaceNode{};
                    duplicateTags.add(cbrId+':'+name.replace(',', '%2C')+'|'+duplicateId);
                    sumDuplicateTags++;
                    duplicateFound = true;
                }
                /* TagText Translations allow duplicates as of 20250116
                else{
                    //check for duplicate Translations. remove translation node if duplicate is found
                    name = 'de_DE-'+r.translation_de_DE[0].title.text().trim().toLowerCase();
                    duplicateId = hmapTexts.get(name);
                    if(duplicateId!=null && cbrId!=duplicateId){
                        //duplicate Text found, remove Translation Node
                        r.translation_de_DE.replaceNode();  
                        duplicateTagTexts.add(cbrId+':'+name+'|'+duplicateId);
                        sumDuplicateTagTexts++;
                    }
                }*/
            }
            
            if(duplicateFound == false){
                //NO duplicates found, create Tag
                r.operation[0].value = "CREATE"
                sumCreateTags = sumCreateTags + 1; //counter
                r.findAll { it.name().startsWith('translation_') }.each { t ->
                    // Locate the <description> element within each translation node
                    // Truncate the description text
                    if(t.description[0]){
                        t.description[0].value = format_desc(t.description[0].text());
                    }
                }                
            }        
        }
    }
    
    message.setProperty("talentJobsPayload","");  //clear processed data
    message.setBody(XmlUtil.serialize(Root));
    message.setProperty("sumCreateTags",sumCreateTags.toString());
    message.setProperty("sumDuplicateTags",sumDuplicateTags.toString());
    message.setProperty("duplicateTags",duplicateTags.toString());
    //message.setHeader("sumDuplicateTagTexts",sumDuplicateTagTexts.toString());
    //message.setHeader("duplicateTagTexts",JsonOutput.toJson(duplicateTagTexts.toSet()).toString());    
	return message;
}

def Message gather_filenames(Message message) {
	def body = message.getBody(java.lang.String);
	def root = new XmlSlurper().parseText(body);
    
    List<String> files = [
        "filenameINSTags",
        "filenameINSTagTexts",
        "filenameUPDTags",
        "filenameUPDTagTexts"
    ];

    files.each { file ->
        Set<String> filenames = new HashSet<>();
        def elements = root."$file";
        elements.each(){
            def fname = it.text().trim();
            if(fname && fname != '[]'){
                filenames.add(fname)
            }
        }
        if(!filenames.isEmpty()){
            message.setHeader(file, JsonOutput.toJson(filenames));
        }
    }    
    
    return message;
}

def Message get_duplicateTags(Message message) {
    def body = message.getBody(String);
    def root = new XmlSlurper().parseText(body);
    
    // Check if root is empty or has no children
    if (root.children().size() > 0) {    
    
        // Collect all sumCreate values and calculate total sum
        def sumCreateTags = root.'**'.findAll { it.name() == 'sumCreateTags' }*.text()*.toInteger().sum();
        message.setHeader("sumCreateTags", sumCreateTags);
        
        // Collect all sumDuplicateTags values and calculate total sum
        def sumDuplicateTags = root.'**'.findAll { it.name() == 'sumDuplicateTags' }*.text()*.toInteger().sum();
        message.setHeader("sumDuplicateTags", sumDuplicateTags);    
        
        //collect all duplicate tags from ALL splits
        Set<String> duplicateTags = extractSetFromXml(root, 'duplicateTags')
        message.setHeader("duplicateTags", JsonOutput.toJson(duplicateTags).toString());
        
    }

    return message;
}

// Reusable method to extract and clean up sets from XML nodes
Set<String> extractSetFromXml(def xml, String tagName) {
    
    Set<String> resultSet = new HashSet<>();
    xml.'**'.findAll { it.name() == tagName }.each { node ->
        def content = node.text().trim();
        if (content != '[]'){ 
            
            if(content.startsWith("[") && content.endsWith("]")) {
                content = content[1..-2]; // remove square brackets
                
                content.split(',').each { item ->
                    def trimmed = item.trim();
                    if (trimmed) {
                        trimmed = trimmed.replace('%2C', ','); //decode commas
                        resultSet.add(trimmed);
                    }
                }
            }
        }
    }
    return resultSet;
}

def String format_desc(description){
    String descr = description;
    descr = descr.replaceAll(/\/n/, "\n");  //replace with actual new line
    descr = descr.replaceAll ('"','\\\\\\"'); //escape double quotes
    descr = descr.take(4000);  //4000 char limit    
    return descr;
}

