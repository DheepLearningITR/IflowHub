import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

	def messageLog = messageLogFactory.getMessageLog(message);
	def body = message.getBody(java.lang.String) as String;
	def pmap = message.getProperties();
	def count = pmap.get("counter");
	int value = count.toInteger();
	def flag = pmap.get("log_enabled");
	if (messageLog != null && flag.equals("Y")) {
			messageLog.addAttachmentAsString(value+"_IncomingJSONLog", body.toString(), "text/xml");
	}
	value = value + 1;
	message.setProperty("counter",value);
	
	return message;
}