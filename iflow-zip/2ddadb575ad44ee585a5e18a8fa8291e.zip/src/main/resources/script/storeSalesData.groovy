import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

def Message processData(Message message) {
    def default_payload = message.getBody(java.lang.String) as String;
    message.setProperty("SALESDATA",default_payload);
    return message
}
