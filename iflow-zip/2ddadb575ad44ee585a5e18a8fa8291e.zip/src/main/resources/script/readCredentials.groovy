
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import javax.xml.bind.DatatypeConverter;
import groovy.util.slurpersupport.GPathResult;
import com.sap.it.api.mapping.*;

/********************************************/
/***  Read S/4HANA Credentials from SCPI  ***/
/********************************************/
    
def Message processData(Message message) {
  
     def messageLog = messageLogFactory.getMessageLog(message);
     messageLog.setStringProperty("Info1", "LoginDetails Script Called...!");

    def salesData = processXMLData(message.getProperty('SALESDATA'))
    def credName = salesData.SAPCpiOutboundOrder.sapCpiConfig.SAPCpiOutboundConfig.username.text();
	
	def service = ITApiFactory.getApi(SecureStoreService.class, null);
	def cpiCredential = service.getUserCredential(credName);
	
    if (cpiCredential == null){
       throw new IllegalStateException("No cpiCredential found for alias " + credName);
    }
    
    messageLog.setStringProperty("Info2", "S/4HANA cpi Credentials Retrieved from SCPI!");
    
   
    def credentials = cpiCredential.getUsername() + ":" + new String(cpiCredential.getPassword());
    def byteContent = credentials.getBytes("UTF-8");
   
    // Construct the login authorization in Base64
    def auth = DatatypeConverter.printBase64Binary(byteContent);
    message.setHeader("Authorization", "Basic " + auth);
  
   return message;
  
}

def  GPathResult processXMLData(String message) {
	return new XmlSlurper().parseText(message)
}
