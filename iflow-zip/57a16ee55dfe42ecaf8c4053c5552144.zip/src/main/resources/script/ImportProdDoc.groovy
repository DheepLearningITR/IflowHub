/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.lang.String;
import com.sap.it.api.mapping.*;
import org.json.JSONObject; 
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import java.text.SimpleDateFormat;

def String getTimeStamp(){
   //"yyyy-MM-dd'T'HH:mm:ss.SSSZ"
   return new Date().format("yyyy-MM-dd'T'HH:mm:ss",TimeZone.getTimeZone('GMT+2'))
}

def String formatDateJSON2XML(String jsonDate) {

    def timestamp = jsonDate.replaceAll(/\D/, '') as Long

    def date = new Date(timestamp)
    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
    sdf.setTimeZone(TimeZone.getTimeZone('GMT+2'))
    return sdf.format(date)
}

def Message handleRequestToImport(Message message) {
    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body); 
    
    def queryString="" as String;
     
    // Destination configuration name on BTP for IBP Instance
    if (input.IBPDestination == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPDestination", input.IBPDestination);
    }
    
    // Credentials used for the IBP instance
    if (input.IBPCredentials == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPCredentials", input.IBPCredentials);
    }
    
    // Planning area used in the IBP instance
    if (input.IBPPlanningArea == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPPlanningArea", input.IBPPlanningArea);
    } 
    
     // Planning area version ID used in the IBP instance
    if (input.IBPPAVersionID == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPPAVersionID", input.IBPPAVersionID);
    } 
    
    // S4HC Logical System in BTP
    if (input.S4HC_LogicalSystem == null) {
         message.setHeader("S4HC_LogicalSystem", "SIM");
    } else {
        message.setHeader("S4HC_LogicalSystem", input.S4HC_LogicalSystem);
    }
    
    // S4HC Destination on BTP or Cloud connector
    if (input.S4H_DEST == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("S4H_DEST", input.S4H_DEST);
    }
    
    // S4HC Stock API Path - part of the GET URL
    if (input.S4H_PATH == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("S4H_PATH", input.S4H_PATH);
    }
    
  
    // S4HC Credentials on BTP
    if (input.S4H_Credentials == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("S4H_Credentials", input.S4H_Credentials);
    }
    
    // direct Commit
    if (input.IBP_Commit == null) {
         message.setHeader("IBP_Commit", false);
    } else {
        message.setHeader("IBP_Commit", input.IBP_Commit);
    }
    
    // IBP Transaction ID
    if (input.IBPTransactionID == null) {
         message.setHeader("IBPTransactionID", '');
    } else {
        message.setHeader("IBPTransactionID", input.IBPTransactionID);
    }
    
    // OData $top parameter
    if (input.S4H_QUERY_TOP == null) {
        message.setHeader("inputsAvailable", false);
    } else {
        message.setHeader("S4H_QUERY_TOP", input.S4H_QUERY_TOP);
    }
    
    // OData $skip paramter
    if (input.S4H_QUERY_SKIP == null) {
         message.setHeader("S4H_QUERY_SKIP", 0);
    } else {
        message.setHeader("S4H_QUERY_SKIP", input.S4H_QUERY_SKIP);
    }
    
    // API Query - part of the URL
    if (input.S4H_QUERY == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        def topIndex = input.S4H_QUERY.indexOf("\$top=")
        if (topIndex != -1) {
            message.setHeader("specify $top seperately please", false);
            return message;
        }
        def skipIndex = input.S4H_QUERY.indexOf("\$skip=")
        if (skipIndex != -1) {
            message.setHeader("specify $skip seperately please", false);
            return message;
        }
        message.setHeader("S4H_QUERY", input.S4H_QUERY);
    }
    
    // IBP Service
    if (input.IBP_SERVICE == null) {
         message.setHeader("IBP_SERVICE", "");
    } else {
        message.setHeader("IBP_SERVICE", input.IBP_SERVICE);
    }
    
    // IBP Service Endpoint
    if (input.IBP_ENDPOINT == null) {
         message.setHeader("IBP_ENDPOINT", "");
    } else {
        message.setHeader("IBP_ENDPOINT", input.IBP_ENDPOINT);
    }

    message.setProperty("CurrentTS", getTimeStamp())
    message.setProperty("iFlowId", "WRITE_IBP_USING_ODATA");
    
    message.setHeader("inputsAvailable", true);
    return message;
} 


def Message prepareForIBP (Message message) {
    
    def headerMap = message.getHeaders();
    JSONObject writeObject = new JSONObject();
    
    writeObject.put("IBPDestination",     headerMap.get("IBPDestination"));
    writeObject.put("IBPCredentials",     headerMap.get("IBPCredentials"));
    writeObject.put("IBPPlanningArea",    headerMap.get("IBPPlanningArea"));
    writeObject.put("IBPPAVersionID",     headerMap.get("IBPPAVersionID")); 
    writeObject.put("S4HC_LogicalSystem", headerMap.get("S4HC_LogicalSystem")); 
    writeObject.put("S4HC_isSimulation",  headerMap.get("S4HC_isSimulation")); 
    writeObject.put("IBP_Commit",         headerMap.get("IBP_Commit"));
    writeObject.put("IBPTransactionID",   headerMap.get("IBPTransactionID"));
    writeObject.put("S4H_QUERY_TOP",      headerMap.get("S4H_QUERY_TOP"));
    writeObject.put("S4H_QUERY_SKIP",     headerMap.get("S4H_QUERY_SKIP"));
    writeObject.put("S4H_DEST",           headerMap.get("S4H_DEST")); 
    writeObject.put("S4H_Credentials",    headerMap.get("S4H_Credentials")); 
    writeObject.put("S4H_PATH",           headerMap.get("S4H_PATH"));
    writeObject.put("S4H_QUERY",          headerMap.get("S4H_QUERY"));
    writeObject.put("IBP_SERVICE",        headerMap.get("IBP_SERVICE"));
    writeObject.put("IBP_ENDPOINT",       headerMap.get("IBP_ENDPOINT"));          

    def body = message.getBody(java.io.Reader);
    def s4hc_response = new JsonSlurper().parse(body); 
    
    def results =  s4hc_response.d.results;
    def count = s4hc_response.d.__count;
    message.setHeader('S4H_COUNT',count.toInteger());
    writeObject.put("S4H_COUNT", count.toInteger());

    def collectedResults = results.collect { Item ->
        def material = Item.Material
        if (material) {
            return [
            "IBPProdnDocType" : "PRODORD",
            "IBPProdnDocExt" : Item.ManufacturingOrder,
            "IBPProdnProductID": Item.Material,
            "IBPProdnLocationID": Item.Plant,
            "IBPProdnPlannedDateTime": formatDateJSON2XML(Item.MfgOrderPlannedStartDate),
            "IBPProdnOrderedQuantity": new BigDecimal(41).setScale(3, BigDecimal.ROUND_HALF_UP),
            "IBPProdnProductBaseUnit": Item.ProductionUnit,
            "IBPPDStrucProdnVers": Item.ProductionVersion, 
            "IBPProdnDocIsFixed": true,
            "IBPProdnGoodsReceiptDateTime": "2024-09-30T23:00:00Z",
            "IBPProdnReceiptQuantity": new BigDecimal(41).setScale(3, BigDecimal.ROUND_HALF_UP),
            "IBPReceiptIsPlngRlvt": true
            ]
        }
    }.findAll { it != null }
    
    def itemsJson = new JsonBuilder(collectedResults)
    writeObject.put("S4HC_Response",  itemsJson);
    
    def newBody = writeObject.toString() as String;
    
    message.setBody(newBody);    
    
    return message;
} 

def Message handleRequest ( Message message) { return message }
