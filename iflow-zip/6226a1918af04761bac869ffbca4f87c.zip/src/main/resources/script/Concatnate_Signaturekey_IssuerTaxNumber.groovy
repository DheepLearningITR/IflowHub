import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Map;
import java.util.List;
import java.util.HashMap;
import groovy.transform.Field;
import java.lang.Exception;
import java.text.Normalizer;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import java.net.URI;

public interface PeruMessageProperty {
	
	String IssuerTaxNumber         = 'IssuerTaxNumber';
	String keyAliasSuffix          = 'keyAliasSuffix';
	String addTaxidtoKeyAlias      = 'addTaxidtoKeyAlias';
	String privateKeyAlias         = 'privateKeyAlias';

};

public interface PeruExceptionPrefix {
	String config  = 'Peru integration flow configuration error: ';
	String process = 'Peru integration flow processing error: '
};

public interface PeruBoolean {
	String Yes = 'yes';	
	String No  = 'no';	
};


// aliases

@Field addTaxidAliasMap = 
[
	(PeruBoolean.Yes) : [  "YES" ],
	(PeruBoolean.No) : [  "NO" ]
];

def String getNormalizedName( String alias, Map map ) {
    	
	def aliasLc = Normalizer.normalize( alias ? alias : "", Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "").toLowerCase();
    return map.find{ prop -> prop.key.equalsIgnoreCase( aliasLc) ||  prop.value.contains( aliasLc ) }?.key;
}

def Message setupConfiguration( Message message ) {
    
    
def props = message.getProperties();

def props_header = message.getHeaders();
def IssuerTaxNumber = props_header.get("IssuerTaxNumber");
	
//Add dynamic private key alias
//    def IssuerTaxNumber = props.get( PeruMessageProperty.IssuerTaxNumber );
    def kSuffix = props.get( PeruMessageProperty.keyAliasSuffix );	
    def addtaxid = props.get( PeruMessageProperty.addTaxidtoKeyAlias );	
    def addtaxid_normalized = ' ';
    
   
   addtaxid_normalized = getNormalizedName( addtaxid, addTaxidAliasMap );
    
    if ( addtaxid_normalized == '' )
		throw new Exception( PeruExceptionPrefix.config + 'Add IssuerTaxNumber to private key Alias cannot be empty');
    
   if( addtaxid_normalized == PeruBoolean.No ) {

     message.setProperty( PeruMessageProperty.privateKeyAlias, kSuffix ); 
      }
      else{
      
     message.setProperty( PeruMessageProperty.privateKeyAlias, kSuffix + '_' + IssuerTaxNumber.toLowerCase()  ); //TAX_ID
      }
      
      return message;
}
