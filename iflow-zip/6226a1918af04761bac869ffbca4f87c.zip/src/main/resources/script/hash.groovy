import com.sap.gateway.ip.core.customdev.util.Message;
import java.lang.*;
import groovy.xml.*;
import org.apache.jmeter.threads.*;
import org.codehaus.groovy.runtime.*;
import org.apache.commons.codec.digest.*;
 import static org.apache.commons.codec.digest.MessageDigestAlgorithms.SHA_256;


def Message processData(Message message) {
    def sha256 = new DigestUtils(SHA_256).digestAsHex(message.getBody(byte[].class));
    message.setHeader('HashZippedSignedFile',sha256);
    return message;
}