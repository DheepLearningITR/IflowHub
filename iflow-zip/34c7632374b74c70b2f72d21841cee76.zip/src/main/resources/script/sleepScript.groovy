
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	
	Thread.sleep(5*60*1000); //sleep for 5 minutes
	return message;
}

