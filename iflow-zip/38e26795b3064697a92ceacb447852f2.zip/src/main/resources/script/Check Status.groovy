import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    //This script is to check S4 status and set the activity ID
    def hdr = message.getHeaders()
    def S4response = hdr.get("sap-messages") as String;
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(S4response)
    def responseParts = jsonResult.findAll { it.code == "EAM_FSM_MORDER_REPL/049" }
    def PMOrderID, OperationID, ActivityExternalId
    if (responseParts){
        if (responseParts.message[0].contains("PMOrder:") && responseParts.message[0].contains("Operation:")){
            PMOrderID = responseParts.message[0].split(',')[0].split(':')[1]
            OperationID = responseParts.message[0].split(',')[1].split(':')[1]
            ActivityExternalId = PMOrderID + '/' + OperationID
            message.setProperty("PMOrderID",PMOrderID)
            message.setProperty("OperationID",OperationID)
        }
    }
    
    if (!PMOrderID && !OperationID){
        message.setProperty("S4error",S4response)
    }else{
        message.setProperty("ActivityExternalId",ActivityExternalId)
    }
    
    return message;
}
