import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

// process message
def Message processData(Message message) { 
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)

    if (jsonResult.data?.serviceCall?.activity?.equipment?.objectCategory == null || jsonResult.data?.serviceCall?.activity?.equipment?.objectCategory == '')
        jsonResult.data?.serviceCall?.activity?.equipment?.objectCategory = 'EQ'
            
    // Replace null values with empty strings and remove empty arrays
    replaceNullsAndRemoveEmptyArrays(jsonResult)

    jsonResult.data?.serviceCall?.activity?.remove("lastChanged")
    jsonResult.data?.remove("updatedProperty")
    jsonResult.data?.serviceCall?.activity?.remove("orgLevelIds")
    jsonResult.data?.serviceCall?.activity?.remove("contact")
    jsonResult.data?.serviceCall?.activity?.remove("address")
    jsonResult.data?.serviceCall?.activity?.remove("serviceProduct")
    jsonResult.data?.serviceCall?.activity?.remove("createPerson")
    jsonResult.data?.serviceCall?.activity?.reservedMaterials.each { RM ->
        RM.remove("orgLevelIds")
        RM.remove("udfValues")
    }
    jsonResult.data?.serviceCall?.activity?.remove("attachments")
    jsonResult.data?.serviceCall?.activity?.remove("udfValues")
    jsonResult.data?.serviceCall?.activity?.remove("requirements")
    jsonResult.data?.serviceCall?.activity?.remove("type")
    jsonResult.data?.serviceCall?.activity?.remove("statusChangeReason")
    jsonResult.data?.serviceCall?.activity?.remove("workflowStep")
    jsonResult.data?.serviceCall?.activity?.remove("sourceActivity")
    
    //add objectId and objectType node
    jsonResult["objectId"] = jsonResult.data?.serviceCall?.activity?.id
    jsonResult["objectType"] = (jsonResult.eventType == "servicecall.created")?"SERVICECALL":"ACTIVITY"
    
    //adjust region node
    def regionCode = jsonResult.data?.serviceCall?.activity?.region?.code
    if(regionCode)
        jsonResult.data?.serviceCall?.activity?.region = regionCode

    def updatedJsonString = JsonOutput.toJson(jsonResult)
    //set OData url prefix path to UpdateMaintenanceOrderOper
    message.setProperty("createpathprefix",'SAP__self.CreateMaintenanceOrderOper')
    message.setProperty("S4HRequestPayload",JsonOutput.prettyPrint(updatedJsonString))
    message.setProperty("ActivityId",jsonResult.data?.serviceCall?.activity?.id)
    
    message.setBody(JsonOutput.prettyPrint(updatedJsonString))
    return message
}

// Recursive function to replace all null values with empty strings and remove empty arrays
def replaceNullsAndRemoveEmptyArrays(obj) {
    if (obj instanceof Map) {
        def keysToRemove = [] // List to track empty arrays
        obj.each { key, value ->
            if (value == null || value == 'null' || value == '') {
                //obj[key] = ""
                keysToRemove.add(key) // Mark empty array for removal
            } else if (value instanceof List && value.isEmpty()) {
                keysToRemove.add(key) // Mark empty array for removal
            } else {
                replaceNullsAndRemoveEmptyArrays(value)
            }
        }
        // Remove the keys after iteration
        keysToRemove.each { key ->
            //obj.remove(key)
            obj.remove(key)
        }
    } else if (obj instanceof List) {
        def itemsToRemove = [] // List to track null and empty arrays
        obj.each { item ->
            if (item == null || item == 'null' || item == '' || (item instanceof List && item.isEmpty())) {
                itemsToRemove.add(item) // Mark for removal
            } else {
                replaceNullsAndRemoveEmptyArrays(item)
            }
        }
        // Remove the items after iteration
        itemsToRemove.each { item ->
            obj.remove(item)
        }
    }
}
