import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def pmOrderID = message.getProperty("PMOrderID")
    def operationID = message.getProperty("OperationID")
    def httpCode = message.getHeader("CamelHttpResponseCode", String)

    if (httpCode != "200" || !pmOrderID || !operationID) {
        throw new Exception("The Integration flow cannot be processed further as there is an issue while fetching the Plant Maintenance Order Id or Operation Id. Please check the ResponseLog Attachment for details");
    }

   return message;
}
