import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

// check if the activity already created in S4HANA
def Message processData(Message message) { 
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)
    message.setProperty("ExistsinS4","false")

    if (jsonResult.data[0].activity.externalId)
        message.setProperty("ExistsinS4","true") 

    return message
}