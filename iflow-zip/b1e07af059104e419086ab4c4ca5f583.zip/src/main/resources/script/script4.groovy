/*
 * This Script will build a query filter to get WO available in EC. Using this filter , it will query all WO corresponding to each CW which is
 * Active in EC and also include future dated WO.
 * And also it will store the current payload in property "reqArrived" this will be used after API call(request call).
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.List;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def map = message.getProperties();
	def len = map.get("length");
    def AllSecurityIds = map.get("AllSecurityId");
    String[] SecId = AllSecurityIds.split(" ");
    String str = "";
    String separator = "";
    int i=Integer.parseInt(len.get(1));
    for(; i<SecId.length; i++){
        
        if(str.size() > 3900){
            break;
        }
        str += separator+"personIdExternal eq '" + SecId[i]+"'";
        separator = " or ";
        
    }
	if(i == SecId.length){
	    len.set(1,"-1");
	}
	else{
	    len.set(1,String.valueOf(i));
	}
	message.setProperty("QueryFilterEmp",str);
	return message;
}

