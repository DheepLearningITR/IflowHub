import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.List;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def map = message.getProperties();
	
	def workOrders = map.get("WorkOrdersProperty");
	workOrders.add(body);
    return message;
}