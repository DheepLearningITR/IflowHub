import com.sap.it.api.mapping.*;


def String getProperty(String property_name, MappingContext context) {

    def propValue= context.getProperty(property_name);
    return propValue;

}

def String delLeadingZeros(String input_string, MappingContext context) {

    def propValue = input_string.replaceFirst('^0+(?!$)', '');
    return propValue;

}