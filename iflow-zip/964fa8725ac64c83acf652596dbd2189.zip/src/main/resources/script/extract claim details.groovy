import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import java.util.Date;
import java.text.SimpleDateFormat
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.ITApiFactory;
def Message processData(Message message) {
    def valueMapService = ITApiFactory.getApi(ValueMappingApi.class, null);
    def valueFSCMVersion   = 'FSCM_' + message.getProperty("com.sap.hybris.fscm.FSCM_Version");
    def valueHybrisVersion = 'FSA_' + message.getProperty("com.sap.hybris.fscm.FSA_Version");
    //Body 
   def body = message.getBody(java.lang.String) as String;

    def jsonSlurper = new groovy.json.JsonSlurper()
    def object = jsonSlurper.parseText(body)
    
    def builder = new groovy.json.JsonBuilder()
    
    ////subclaims
    def list = object.ClaimInquirySet.ClaimInquiry_Type.to_Subclaims.SubclaimInquiry_Type

    def Subclaims = []

    list.eachWithIndex { it, i ->
        def emptyMap = [:]
        emptyMap.subclaimNumber = it.InsurClmSubclm
        emptyMap.type = [:]
        emptyMap.type.code = it.InsurClmSubclmType
        emptyMap.status = [:]
        emptyMap.status.code = valueMapService.getMappedValue(valueFSCMVersion, "SubclaimStatusCode", it.InsurClmLifeCycSts, valueHybrisVersion, "SubclaimStatusCode");
        emptyMap.claimant = [:]
        emptyMap.claimant.externalId = it.InsurClmClaimantID
        emptyMap.claimant.name = it.InsurClmClaimantName
        Subclaims.add(emptyMap)
    }
   /* builder {
   //     claimNumber object.A_InsurClmClaimInquirySet.ClaimInquiry_Type.InsuranceClaim
   //     subClaims (
   //         Subclaims
   //     )
//}

    // For Testing, putting everything in the body
    message.setBody(JsonOutput.prettyPrint(builder.toString()));

    // Set the Property for all Subclaims
    message.setProperty("Subclaims", jsonSlurper.parseText(builder.toString()).subClaims);
    */
    
    ////payments
    list = object.ClaimInquirySet.ClaimInquiry_Type.to_Payments.SubclaimPayment_Type

    def Payments = []

    list.eachWithIndex { it, i ->
        def emptyMap = [:]
        // payments
        emptyMap.code = it.InsurClmPayt
        emptyMap.subclaimNumber = it.InsurClmSubclm
        emptyMap.payee = it.InsuranceClaimPayeeName
        emptyMap.amount = it.InsurClmSubclmPaytTotAmount
        //emptymap.transactionDate = it.InsurClmPaytPostgDte 
        emptyMap.paymentType = [:]
        emptyMap.paymentType.code = valueMapService.getMappedValue(valueFSCMVersion, "PaymentType", it.InsurClmPaytCat, valueHybrisVersion, "PaymentType");
        emptyMap.paymentMethod = [:]
        emptyMap.paymentMethod.code = valueMapService.getMappedValue(valueFSCMVersion, "PaymentMethod", it.InsurClmPaytMethod, valueHybrisVersion, "PaymentMethod");
        emptyMap.transactionDate = it.InsurClmPaytPostgDte
        emptyMap.currency = [:]
        emptyMap.currency.isocode = it.InsurClmPaymentCurrency
        Payments.add(emptyMap)
    }

    builder {
        claimNumber object.ClaimInquirySet.ClaimInquiry_Type.InsuranceClaim
        subClaims (
            Subclaims
        )
        payments (
            Payments
        )
    }

    // For Testing, putting everything in the body
    message.setBody(JsonOutput.prettyPrint(builder.toString()));
    
    def subClaimsJson =  new groovy.json.JsonBuilder(jsonSlurper.parseText(builder.toString()).subClaims)

    // Set the Property for all Subclaims
    message.setProperty("Subclaims", subClaimsJson.toString());
        
    def paymentsJson =  new groovy.json.JsonBuilder(jsonSlurper.parseText(builder.toString()).payments)
    
    message.setProperty("Payments",  paymentsJson.toString());
    
    return message;
    
    
    
    
}