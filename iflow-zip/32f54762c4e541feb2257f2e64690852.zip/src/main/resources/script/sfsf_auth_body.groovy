import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    //Properties
    def properties = message.getProperties();
    resourceType = properties.get("resourceType");
    userType = properties.get("userType");
    companyId = properties.get("companyId");
    userId = properties.get("userId");
    SFSFBasicCredentials = properties.get("SFSFBasicCredentials");


    payload = [
            "grant_type": "client_credentials",
            "scope": [
                    "userId": userId,
                    "companyId": companyId,
                    "userType": userType,
                    "resourceType": resourceType
            ]
    ]

    def json = new groovy.json.JsonBuilder(payload);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString())
    message.setBody(bodyPayload);
    
    def headers = message.getHeaders();
    message.setHeader("Authorization", SFSFBasicCredentials);
    
    return message;
}