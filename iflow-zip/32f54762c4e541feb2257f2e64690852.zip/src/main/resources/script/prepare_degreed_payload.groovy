import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.net.URLEncoder;
def Message processData(Message message) {
    //Properties
    def properties = message.getProperties();
    
    revision_date = properties.get("revision-date");
    content_type_id = properties.get("content-type-id");
    component_id = properties.get("component-id");
    user_id = properties.get("UserID");
    required_date = properties.get("completionDate")
    cpnt_classification = properties.get("cpnt_classification")
    
    def f_req_date = ""
    def books_list = ["AUDIO SUMMARY", "AUDIO BOOK", "BOOK", "BOOK SUMMARY"]
    def article_list = ["BRIEF", "DOC", "INFORMAL", "LINKED CONTENT", "SOP", "SYSTEM_QUICKGUIDE_ENTITY", "TASK"]
    def course_list = ["CHANNEL", "VIRT", "CURRICULA", "PROGRAM", "CLASS", "COURSE", "MOOC", "OJT", "ONLINE", "SELF", "SYSTEM_PROGRAM_ENTITY", "SYSTEM_COLLECTION_ENTITY", "SYSTEM_EXTERNAL_ENTITY"]
    def event_list = ["OTHER"]
    def video_list = ["VIDEO"]
    def assessment_list = ["CERT", "EXAM", "JPM"]
    def content_id = ""
    
    if(books_list.contains(content_type_id)){
        content_type = "book"
    }
    else if(article_list.contains(content_type_id)){
        content_type = "article"
    }
    else if(event_list.contains(content_type_id)){
        content_type = "event"
    }
    else if(course_list.contains(content_type_id)){
        content_type = "course"
    }
    else if(video_list.contains(content_type_id)){
        content_type = "video"
    }
    else if(assessment_list.contains(content_type_id)){
        content_type = "assessment"
    }
    else{
        content_type = "course" // Course is the default content type
    }
    
    if(cpnt_classification != "PROGRAM"){
        content_id = component_id + ":" + content_type_id + ":" + revision_date;
    }
    else{
        content_id = component_id
    }
    
    if(required_date){
        def r_date = Long.valueOf(required_date)
        def format_req_date = new Date(r_date)
        def f_date = format_req_date.format("YYYY-MM-dd HH:mm:ss.SSSSSSS")
        f_req_date = f_date.replace(" ", "T")
    }
    
    payload = [
    "data": [
          "type": "completions",
          "attributes": [
               "user-id": user_id,
               "user-identifier-type": "EmployeeId",
               "content-id": content_id,
               "content-id-type": "ExternalId",
               "content-type": content_type,
               "completed-at": f_req_date
                        ]
            ]
        ]
    
    
    def json = new groovy.json.JsonBuilder(payload);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString());
    message.setBody(bodyPayload);
    return message;
}
