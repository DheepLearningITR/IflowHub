import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    HashMap<String, String> token = new HashMap<String, String>();
    HashMap<String, String> t1_token = new HashMap<String, String>();
    HashMap<String, String> t2_token = new HashMap<String, String>();
    HashMap<String, String> tokenDegreed = new HashMap<String, String>();
    HashMap<String, String> expireDateDegreed = new HashMap<String, String>();
    message.setHeader("token", token);
    message.setHeader("t1_token", t1_token);
    message.setHeader("t2_token", t2_token);
    message.setHeader("tokenDegreed", tokenDegreed);
    message.setHeader("expireDateDegreed", expireDateDegreed);
    return message;
}