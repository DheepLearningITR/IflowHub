import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Variables in cache
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("tokenDegreed");
    
    HashMap<String, String> t1CacheData = map.get("t1_token");
    HashMap<String, String> t2CacheData = map.get("t2_token");

    //Properties
    def properties = message.getProperties();
    
    // Set variables
    def headerParam = "application/json";
    def auth_value = "Bearer " + cacheData.get("tokenDegreed");
    
    def t1_auth_value = "Bearer " + t1CacheData.get("t1_token");
    def t2_auth_value = "Bearer " + t2CacheData.get("t2_token");
    def no_auth_code = "false"
    
    message.setHeader("accept",headerParam);
    message.setHeader("content-type",headerParam);
   // message.setHeader("Authorization",auth_value);
   //def messageLog = messageLogFactory.getMessageLog(message);
   
   // messageLog.addAttachmentAsString("Country of Employww", country, "text/plain");
    def gat_enabled = properties.get("is_GAT_enabled")
    if (gat_enabled == 'true') {
        def country = properties.get("Country")
        def tenant1 = properties.get("tenantCountryList1")
        def tenant2 = properties.get("tenantCountryList2")
        
        def tenantList1 = tenant1.split(',')
        def tenantList2 = tenant2.split(',')
        
        if (country in tenantList1) {
            message.setHeader("Authorization",t1_auth_value);
           // messageLog.addAttachmentAsString("T1 auth is enabled", t1_auth_value, "text/plain");
        }
        else if (country in tenantList2) {
            message.setHeader("Authorization",t2_auth_value);
          //  messageLog.addAttachmentAsString("T2 auth is enabled", t2_auth_value, "text/plain");
        }
        else {
            no_auth_code = "true"
        }
        
    }
    
    
    else {
        message.setHeader("Authorization",auth_value);
       // messageLog.addAttachmentAsString("Default Token is enabled", auth_value, "text/plain");
    }
    
    message.setProperty("no_auth_code", no_auth_code)
    return message;
}