import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("token");

    //Properties
    def properties = message.getProperties();
    def user_id = properties.get("UserID")

    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.setStringProperty("Logging#1", "Printing variables")
        messageLog.addAttachmentAsString(" headers", cacheData.get("token"), "text/plain");
     }
    return message;
}
