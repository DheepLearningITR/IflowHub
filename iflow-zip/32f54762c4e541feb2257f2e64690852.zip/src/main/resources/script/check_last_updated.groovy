/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Date;
def Message processData(Message message) {

    //Properties
    def properties = message.getProperties();
    def wasUpdated = "false";
    def isFirstRun = properties.get("isFirstRun")
    
    if (isFirstRun == 'true') {
        wasUpdated = "true";
    }
    else if (properties.get("iFlowLastExecutionDate") && properties.get("last_update_timestamp")) {
        def stringLastRun = properties.get("iFlowLastExecutionDate").replace("T", " ").replace("Z", "");
        def stringLastModify1 = properties.get("last_update_timestamp").replace("T", " ").replace("Z", ""); // General
        
    
        if (stringLastRun.length() > 0) {
            def format = "yyyy-MM-dd HH:mm:ss.SSS";
            def stringLastRunDate = new Date().parse(format, stringLastRun);
            // Timestamp format
            def stringLastModifyTimeStamp = Long.valueOf(stringLastModify1);
            def stringLastModifyDate1 = new Date(stringLastModifyTimeStamp);
            // def stringLastModifyDate1 = new Date().parse(format, stringLastModify1);

    
            if (stringLastModifyDate1 > stringLastRunDate) {
                wasUpdated = "true";
            };
        };
    }

    message.setProperty("updated", wasUpdated);
    return message;
}
