import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {

    def body =message.getBody(java.lang.String).replaceAll("@","");
    def jsonSlurper = new JsonSlurper();
    def list = jsonSlurper.parseText(body);
    list.element.each{
        it.remove('odata.context:odata.metadataEtag');
    }
    def jsonOP = JsonOutput.toJson(list)
    message.setBody(jsonOP);
    return message;
}