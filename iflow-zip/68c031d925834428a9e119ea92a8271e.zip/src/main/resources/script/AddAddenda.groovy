import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.*;

def Message processData(Message message) {
    
  def map = message.getProperties();
  def isaddenda =  map.get("isaddenda");
  def isaddendaV4 =  map.get("isaddendaV4");
  if(isaddenda || isaddendaV4){
     
  String body = message.getBody(java.lang.String ) as String;
  String addenda = map.get("addenda");
  String mainxml = map.get("responsexml");
  String fragment = "<Addenda>" + addenda + "</Addenda>";
  def bodyNode     = new XmlParser().parseText(mainxml);
  def fragmentNode = new XmlParser().parseText(fragment);
  bodyNode.append(fragmentNode);
  message.setBody(XmlUtil.serialize(bodyNode));
  }
  
  return message;
  
}



