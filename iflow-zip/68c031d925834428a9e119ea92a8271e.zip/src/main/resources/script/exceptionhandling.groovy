/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;


def Message processData(Message message) {
def map = message.getProperties();
def ex = map.get("CamelExceptionCaught");
def code;
def error;
   
if (ex!=null) {
	def body = message.getBody();
	
	error = ex.getMessage().replace("\"", "").replace("\'", "")
	code = ex.getFaultCode()

	}

if (ex.getMessage().contains('ClaveProdServ')){
    error = 'The value of attribute ClaveProdServ on element cfdi:Concepto is not valid with respect to its type, c_ClaveProdServ.'
}
else if (ex.getMessage().contains('FraccionArancelaria')){
    error = 'The value of attribute FraccionArancelaria on element cce11:Mercancia is not valid with respect to its type, c_FraccionArancelaria.'
}

	def str = ""
    int len = error.length()
if (len > 255)
{ 
    Num = len/255
    int count = 0;
    while(count <= Num)
    {
        int index = (count+1)*255
        int start = count*255
        if (index<=len)
        {
        str = str + '<ns0:Error noIdentificacion="'+code+'" descripcion="'+error.substring(start,index)+'"></ns0:Error>'
        }
        else
        {
          str = str + '<ns0:Error noIdentificacion="" descripcion="'+error.substring(start,len)+'"></ns0:Error>'  
        }
        count++
        code = ""
    }
    
}
else
{
    str = '<ns0:Error noIdentificacion="'+code+'" descripcion="'+error+'"></ns0:Error>'
}
    message.setProperty("errorlog",str);
	return message;
}


