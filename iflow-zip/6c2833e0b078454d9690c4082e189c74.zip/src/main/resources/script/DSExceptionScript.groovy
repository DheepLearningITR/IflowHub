import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

	// get a map of iflow properties
	def map = message.getProperties();

	//Get Headers 
	def hmap = message.getHeaders();
	
	String csvdata = "{\"row\": [";
	
	
	//Setting the timestamp
	def now = new Date();
	message.setProperty("timestamp", now.format("yyyyMMddHHmmss", TimeZone.getTimeZone('UTC')));
	
	//deriving the exception type
	String exceptionDetailErrorMsg = message.getProperty("CamelExceptionCaught");
	def exceptionMessage = message.getProperty("CamelFailureEndpoint");
	def xsderror,deserializeError,artifactError
	if(null != exceptionDetailErrorMsg){		
		dataStoreIdNotFound = exceptionDetailErrorMsg.contains("No identifier provided in header SapDataStoreId for GET operation") ;
		dataStoreDataFound = exceptionDetailErrorMsg.contains("No message found") ;
	}

	if(dataStoreIdNotFound){
	    exceptionDetailErrorMsg = exceptionDetailErrorMsg.substring(exceptionDetailErrorMsg.indexOf(":")+2);
	    exceptionDetailErrorMsg = exceptionDetailErrorMsg.trim();
		message.setProperty("dsExceptionOccurred","false");
        message.setProperty("FailureMessage", "Unable to find the required entry in the Data Store.");
        csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + exceptionDetailErrorMsg + "\"}]}"; 
    } else if (dataStoreDataFound){
	    exceptionDetailErrorMsg = exceptionDetailErrorMsg.substring(exceptionDetailErrorMsg.indexOf(":")+2);
	    exceptionDetailErrorMsg = exceptionDetailErrorMsg.trim();
		message.setProperty("dsExceptionOccurred","false");
        message.setProperty("FailureMessage", "No message found.");
        csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + exceptionDetailErrorMsg + "\"}]}"; 
    
    }
    else {
        message.setProperty("dsExceptionOccurred","true");
		
		// get an exception java class instance
		def ex = map.get("CamelExceptionCaught");
		if (ex!=null) {

			// an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
			if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {

				// save the http error response as a message attachment 
				def messageLog = messageLogFactory.getMessageLog(message);
				messageLog.addAttachmentAsString("http.ResponseBody", ex.getResponseBody(), "text/plain");

				// copy the http error response to an iflow's property
				if(ex.getResponseBody() != null)  {
				    message.setProperty("FailureMessage", ex.getResponseBody());
				}
				else {
				    message.setProperty("FailureMessage", hmap.get("Www-Authenticate"));
				}

				csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + detailErrorMsg + "\"}]}"; 
			}  else {
				message.setProperty("FailureMessage", ex);
				csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + ex + "\"}]}"; 
		    }
		}
		else {
				message.setProperty("FailureMessage", "Unknown Error, please contact your system administrator.");

				csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + "Unknown Error, please contact your system administrator." + "\"}]}"; 
		}
	}
	message.setBody(csvdata);
	
	return message;
}