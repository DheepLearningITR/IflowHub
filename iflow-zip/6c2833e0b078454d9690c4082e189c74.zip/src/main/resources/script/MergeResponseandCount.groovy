import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

Message processData(Message message) {
    def propertiesMap = message.getProperties()
    def deleteErrorPayload = propertiesMap.get('deleteErrorPayload')
    def createUpdateErrorPayload = propertiesMap.get('createUpdateErrorPayload')
	def jsonSlurper = new JsonSlurper()

    def jsonObj1 = jsonSlurper.parseText(deleteErrorPayload)
    def jsonObj2 = jsonSlurper.parseText(createUpdateErrorPayload)

    // Merge the Errors arrays from both JSON objects
    def mergedErrors = jsonObj1.Errors + jsonObj2.Errors

    // Create the merged JSON structure
    def mergedJson = [Errors: mergedErrors]

    // Build the final JSON string
    def jsonBuilder = new JsonBuilder(mergedJson)
    String resultJson = jsonBuilder.toPrettyString()

    message.setBody(resultJson)
    
    def totalFailure = convertStringtoInt(propertiesMap.iFailure) + convertStringtoInt(propertiesMap.iDelFailure)
    def totalSuccess = convertStringtoInt(propertiesMap.iSuccess) + convertStringtoInt(propertiesMap.iDelSuccess)
    def totalCount = convertStringtoInt(propertiesMap.iTotal) + convertStringtoInt(propertiesMap.iDelTotal)


	message.setProperty('iTotalCount', totalCount )	
	message.setProperty('iTotalSuccess', totalSuccess)
	message.setProperty('iTotalFailure', totalFailure)
	
	def bIsDeleteError = propertiesMap.isDeleteError
    def bIsCreateUpdateError = propertiesMap.isCreateUpdateError

    bIsDeleteError = (bIsDeleteError.toString().toLowerCase() == 'true') 
    bIsCreateUpdateError = (bIsCreateUpdateError.toString().toLowerCase() == 'true')
        message.setProperty('isError', 'false')
    if (bIsDeleteError || bIsCreateUpdateError) {
        message.setProperty('isError', 'true')
    } 

    return message
}

int convertStringtoInt(value){
	def counter_var;
	if(value == null || value == "" || value == 0)
    { 
       counter_var = 0       
    } else if (value.getClass().getName().equals("java.lang.String") ) {
       counter_var = value.replaceAll('"', '').trim()
    }
    else 
    {		
	   counter_var = value as Integer
		
    }
	return counter_var;	
}
