import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
  
    
    def headers = message.getHeaders();
    message.setProperty("bpExecutionStatus", "false");
    
    String replicationStatus = headers.get("ReplicationStatus");
    if(replicationStatus == "Completed" ) {
        message.setProperty("bpExecutionStatus", "true");
    }
   
    return message;
}