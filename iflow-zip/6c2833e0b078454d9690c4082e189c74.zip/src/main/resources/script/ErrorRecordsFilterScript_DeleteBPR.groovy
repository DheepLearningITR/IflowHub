import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

Message processData(Message message) {
    def body = message.getBody(String)
    def output
    message.setProperty('isDeleteError', 'true')

    //Setting the timestamp
    def now = new Date()
    message.setProperty('timestamp', now.format('yyyyMMddHHmmss', TimeZone.getTimeZone('UTC')))
    
    if(body.contains("SkipMessage"))
	{
	  body = [];
	}
	
	String completePayload = "{\"rows\":";	
	completePayload = completePayload + body + "}"
    output = getErrorResponse(completePayload, message)

    if(!completePayload.contains("Error"))
	{
	  message.setProperty("isDeleteError", "false");
	}
	
	message.setProperty("deleteErrorPayload",output)
	message.setBody(output)
	
    return message
}

String getErrorResponse(String response, Message message) {
    def jsonSlurper = new JsonSlurper()
    def records
    int iDelSuccess = 0,iDelTotal = 0, iDelFailure = 0
    def errorJson = jsonSlurper.parseText('{}')
    errorJson['Errors'] = []

    def jsonObject = jsonSlurper.parseText(response)

	jsonObject.rows.each { entry ->                
                if ("$entry".contains('Error') || "$entry".contains('ERROR')) {
                   iDelFailure = iDelFailure + 1                   
                   errorJson.Errors.push(entry)
                } 
                if ("$entry".contains('Success') || "$entry".contains('SUCCESS')) {
                  iDelSuccess = iDelSuccess + 1
                }
                 
             }
    
    message.setProperty('iDelSuccess', iDelSuccess)
    message.setProperty('iDelFailure', iDelFailure)
    iDelTotal = iDelSuccess + iDelFailure
    message.setProperty('iDelTotal', iDelTotal)
    records = JsonOutput.toJson(errorJson)
    return records
}
