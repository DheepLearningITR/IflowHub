import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

Message processData(Message message) {
    def body = message.getBody(String)
    def output
    message.setProperty('isCreateUpdateError', 'true')

    //Setting the timestamp
    def now = new Date()
    message.setProperty('timestamp', now.format('yyyyMMddHHmmss', TimeZone.getTimeZone('UTC')))
    
   	if(body.contains("SkipMessage"))
	{
	  body = "";
	}

    //parsing error message
    output = getErrorResponse(body, message)
    if (!body.contains('error')) {
        message.setProperty('isCreateUpdateError', 'false')
    }
    
    message.setProperty('createUpdateErrorPayload',output)
    message.setBody(output)

    return message
}

String getErrorResponse(String response, Message message) {
    def jsonSlurper = new JsonSlurper()
    def errMsg, errObj, records
    int iSuccess = 0,iTotal = 0, iFailure = 0
    def errorJson = jsonSlurper.parseText('{}')
    errorJson['Errors'] = []

    response.split('HTTP/1.1').each { unit ->
        if ("$unit".contains('201 Created') || "$unit".contains('200 OK')) {
            iSuccess = iSuccess + 1
        }
        if (!"$unit".contains('201 Created') && !"$unit".startsWith('--changeset')) {
            if (!"$unit".contains('200 OK') && !"$unit".startsWith('--changeset')) {
                def startIndex = "$unit".indexOf('{\"error\"')
                def endIndex = "$unit".indexOf('--changeset')
                if (endIndex == -1) {
                    endIndex = "$unit".indexOf('--batch')
                }
                if (startIndex != -1 && endIndex != -1) {
                    errMsg = "$unit".substring(startIndex, endIndex).trim()
                    errObj = jsonSlurper.parseText(errMsg.toString().replaceAll('@', ''))
                    errorJson.Errors.push(errObj)
                    iFailure = iFailure + 1
                }
            }
        }
    }

    //iSuccess = iSuccess / 2
    message.setProperty('iSuccess', iSuccess)
    message.setProperty('iFailure', iFailure)
    iTotal = iSuccess + iFailure
    message.setProperty('iTotal', iTotal)
    records = JsonOutput.toJson(errorJson)
    return records
}
