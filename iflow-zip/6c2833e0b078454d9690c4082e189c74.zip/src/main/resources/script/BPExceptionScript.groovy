import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

	// get a map of iflow properties
	def map = message.getProperties();

	//Get Headers 
	def hmap = message.getHeaders();
	
	String csvdata = "{\"row\": [";
	
	
	//Setting the timestamp
	def now = new Date();
	message.setProperty("timestamp", now.format("yyyyMMddHHmmss", TimeZone.getTimeZone('UTC')));
	
	//deriving the exception type
	String detailErrorMsg = message.getProperty("CamelExceptionCaught");
	def exceptionMessage = message.getProperty("CamelFailureEndpoint");
	def xsderror,deserializeError,artifactError
	if(null != detailErrorMsg){
		deserializeError = detailErrorMsg.contains("Could not deserialize request payload");
	    artifactError = detailErrorMsg.contains("NoArtifactDecriptorFoundForArtifactName");
	}

	if(artifactError){
	    detailErrorMsg = detailErrorMsg.substring(detailErrorMsg.indexOf("]:")+2);
	    detailErrorMsg = detailErrorMsg.trim();
        message.setProperty("FailureMessage", "Please check the Configuration");
        csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + detailErrorMsg + "\"}]}"; 
    }
	else if (deserializeError){
		message.setProperty("FailureMessage", "Unable to process the file as it contains errors.");	
		def sdeserializeError = "Could not deserialize request payload";
		csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + sdeserializeError + "\"}]}"; 
	}
	else {
		
		// get an exception java class instance
		def ex = map.get("CamelExceptionCaught");
		if (ex!=null) {

			// an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
			if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {

				// save the http error response as a message attachment 
				def messageLog = messageLogFactory.getMessageLog(message);
				messageLog.addAttachmentAsString("http.ResponseBody", ex.getResponseBody(), "text/plain");

				// copy the http error response to an iflow's property
				if(ex.getResponseBody() != null)  {
				    message.setProperty("FailureMessage", ex.getResponseBody());
				}
				else {
				    message.setProperty("FailureMessage", hmap.get("Www-Authenticate"));
				}

				csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + detailErrorMsg + "\"}]}"; 
			}  else {
				message.setProperty("FailureMessage", "Unknown Error, please contact your system administrator.");
				csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + "Unknown Error, please contact your system administrator." + "\"}]}"; 
		    }
		}
		else {
				message.setProperty("FailureMessage", "Unknown Error, please contact your system administrator.");

				csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + "Unknown Error, please contact your system administrator." + "\"}]}"; 
		}
	}
	message.setBody(csvdata);
	
	return message;
}
