import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
       sleep(300000);
       return message;
}