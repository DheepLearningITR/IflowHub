import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    def body = message.getBody(String) as String
    message.setProperty('original_payload', body)
    
    message.setProperty('bpExecutionStatus', 'false')
    
    return message
}
