import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser

Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def parser = new XmlParser()
    def root = parser.parseText(body)

    //  check 'BusinessPartnerRelationshipSUITEReplicateRequestMessage' exists and return
    def node = root.'**'.findAll { it.name() == 'BusinessPartnerRelationshipSUITEReplicateRequestMessage'}
    int len = node.size()
    if (len != 0) {
        message.setProperty('payloadHasData', 'true')
    } else {
        message.setProperty('payloadHasData', 'false')
    }
    return message
}
