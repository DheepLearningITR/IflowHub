import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
	def body = message.getBody(java.lang.String);
	def jsonSlurper = new JsonSlurper();
	def jsonInputPayload = jsonSlurper.parseText(body.toString());
	def modifiedInputJson = jsonInputPayload.row; 
		
	// Prepare Message Header
	message.setHeader('Content-Type', "application/json")
	
	
	message.setBody(JsonOutput.toJson(modifiedInputJson));
	
    return message;
}