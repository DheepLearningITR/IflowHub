import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

	// Init map to store error messages
	Map<String, Set<String>> errorTextToAssignmentIdMap = [:]
    message.setProperty("ErrorMessagesMap", errorTextToAssignmentIdMap)

	message.setProperty("ErrorCount", 5)

    // Number of records to be process
    def lineNo = 0;
    
    //body
    def body = message.getBody(String.class)
        body.eachLine {
        lineNo++} 
     
     message.setProperty("totalCount",lineNo-1);


    return message;
}

def Message initBody(Message message) {
    def body = "";
    message.setBody(body) 
    return message;
}

