import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import com.sap.esb.datastore.DataStore;
import com.sap.esb.datastore.Data;
import org.osgi.framework.*;

def Message parseTimeEventResponse(Message message) {
    
	//Body
	def body = message.getBody(String.class)
	def jsonParser =new JsonSlurper()
	def jsonObject = jsonParser.parseText(body)

	//Headers
	def headers = message.getHeaders();
	def httpCode = headers.get("CamelHttpResponseCode")

    //Properties
	def mapProperty = message.getProperties();
	def payload = mapProperty.get("processingPayload")
	def errorMessagesMap = mapProperty.get("ErrorMessagesMap")

	if(httpCode == 400 || httpCode == 401){

        throw new Exception(body)
		
	} else {
		// Process Failed Entries from Response
		def responseFailed  = jsonObject['failedTimeEvents']
// 		Map<String, Set<String>> errorTextToAssignmentIdMap = [:] 
        Map<String, Set<String>> errorTextToAssignmentIdMap = errorMessagesMap
		
		if(responseFailed.size() > 0){
		
		    //get payload
		    def jsonArray = jsonParser.parseText(payload)
		    
		    // Processing output message for XM
    		responseFailed.each { entry ->
                String id = entry.id
                String assignmentId = findAssignmentIdForId(jsonArray, id)
        
                String errorText = entry.errorText
                if (!errorTextToAssignmentIdMap.containsKey(errorText)) {
                    errorTextToAssignmentIdMap[errorText] = new LinkedHashSet<>()
                }
                errorTextToAssignmentIdMap[errorText].add(assignmentId)
            }  
            
            message.setProperty("ErrorMessagesMap",errorTextToAssignmentIdMap)

    		def resultString = errorTextToAssignmentIdMap.collect { errorText, assignmentIds ->
                "$errorText - Assignment Ids: ${assignmentIds.join(', ')}"}.join('\n')
            message.setProperty("XMErrorMessage", resultString)    
                

    		// Filter error json entries for output file
    		List<Map<String, Object>> filteredJsonErrorEntries = responseFailed.collect { entry ->
                String id = entry.id
                Map<String, Object> matchingNode = jsonArray.find { node -> node.id == id.toString() }

                // Create a new map by combining the matchingNode and errorText
                matchingNode + [errorText: entry.errorText]
            }
            
            def jsonBuilder = new JsonBuilder(filteredJsonErrorEntries)
            def jsonString = jsonBuilder.toPrettyString()

    		
    		procesErrorForDatastore(message, jsonString)
		}
	}

	return message;
}

def findAssignmentIdForId(arrayList, id) {
    arrayList.find { entry -> entry.id == id }?.assignmentId
}

def procesErrorForDatastore(Message message, String errorJsonString ) {

	def parsedJsonBody = new JsonSlurper().parseText(errorJsonString)	
	
    //Properties
	def mapProperty = message.getProperties();
	def messageId = mapProperty.get('SAP_MessageProcessingLogID')
	def iflowId = mapProperty.get('ifl_name')

	//Get CamelContext and from that the DataStore instance
	def camelCtx = message.exchange.getContext()
	DataStore dataStore = (DataStore)camelCtx.getRegistry().lookupByName(DataStore.class.getName())
	
	try {
    	//Read from Datastore params => (DatastoreName, EntryId)
    	def dsEntry = dataStore.get("TimeEventErrorProcessing",iflowId, "FailedTimeEvents")
    	//Get datastore entry payload as String
    	def storedPayload = new String(dsEntry.getDataAsArray())
        def storedjsonPayload = new JsonSlurper().parseText(storedPayload)
        
    	def mergedData = storedjsonPayload + parsedJsonBody

        // Convert merged list back to JSON string
        def jsonBuilder = new JsonBuilder(mergedData)
        def mergedJsonString = jsonBuilder.toPrettyString()
        
    	//Define headers and payload/body as byte[]
    	Map<String, Object> headers = ["SAP_MessageProcessingLogID":messageId]
    	def newPayload = mergedJsonString.getBytes("UTF-8")
    	
    	//Create datastore payload/data
    	Data dsData = new Data("TimeEventErrorProcessing", iflowId, 
    	                       "FailedTimeEvents", newPayload, headers, messageId, 0)
    	
    	//Write dsData element to the data store
    	dataStore.put(dsData, true, false, 13824000000, 90552000000)
    	
	} catch (com.sap.esb.datastore.MessageNotFoundException ex){
	    
    	//Define headers and payload/body as byte[]
    	Map<String, Object> headers = ["SAP_MessageProcessingLogID":messageId]
    	def payload = errorJsonString.getBytes("UTF-8")
    	
    	//Create datastore payload/data
    	Data dsData = new Data("TimeEventErrorProcessing", iflowId, 
    	                       "FailedTimeEvents", payload, headers, messageId, 0)
    	
    	//Write dsData element to the data store
    	//params => (DataInstance, overwriteEntry, encrypt, alertPeriodInMs, expirePeriodInMs)
    	dataStore.put(dsData, true, false, 13824000000, 90552000000)
	
	}

}

def Message parseException(Message message) {
    //Body
	def body = message.getBody(String.class)

    def now = new Date().getTime()
	message.setProperty("now", now);

    //Properties
	def mapProperty = message.getProperties();
	def exceptionMessage = mapProperty.get("CamelExceptionCaught")
	def escapedStr = escapeSpecialChars(exceptionMessage.toString())
    message.setProperty("XMErrorMessage", escapedStr) 

    return message;
}

def escapeSpecialChars(String str) {
    return str.replace("\\", "\\\\")
              .replace("\b", "\\b")
              .replace("\f", "\\f")
              .replace("\n", "\\n")
              .replace("\r", "\\r")
              .replace("\t", "\\t")
              .replace("\"", "\\\"")
              .replace("/", "\\/");
}
