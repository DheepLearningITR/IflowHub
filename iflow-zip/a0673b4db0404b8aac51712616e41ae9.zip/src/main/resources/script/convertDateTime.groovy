import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Date;

def Message setCurrentTimeEpoch(Message message) {
	
	//Now
    def now = new Date().getTime()
	message.setProperty("now", now);
	return message;
}
