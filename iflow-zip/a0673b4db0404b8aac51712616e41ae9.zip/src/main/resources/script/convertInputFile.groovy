import com.sap.gateway.ip.core.customdev.util.Message;
import org.apache.commons.csv.CSVFormat
import org.apache.commons.csv.CSVParser
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message convertXmlToJson(Message message) {
    //Body
    def body = message.getBody(String.class)
    def xml = new XmlSlurper().parseText(body)
    
    // Create a list to store the timeevent objects
    def timeevents = []
    xml.timeevent.each {
        // Create a map for each timeevent
        def timeevent = [:]
        timeevent.id = it.id.text()
        timeevent.assignmentId = it.assignmentId.text()
        timeevent.terminalId = it.terminalId.text()
        timeevent.typeCode = it.typeCode.text()
        timeevent.timestamp = it.timestamp.text()
        
        // Add the timeevent to the list
        timeevents << timeevent
    }
    
    def json = JsonOutput.toJson(timeevents)
    
    message.setBody(json)
    return message
}

def Message convertJsontoCsv(Message message) {
    
    def count = 0
    //Body
	def body = message.getBody(String.class)

    if (body?.trim()) {
        // Load and parse JSON
        def payload = new JsonSlurper().parseText(body)
        
        //Init
        message.setBody("");
        
        if(!payload.isEmpty()){
            
            //Count Error
            count = payload.size()
            // Initialize CSV output
            def csv = payload[0].keySet().join(",") + "\n"
            
            // Add rows to CSV
            payload.each { item ->
                csv += item.values().join(",") + "\n"
            }
            message.setBody(csv);    
        }
    

    }
    message.setProperty("FinalErrorCount",count);
    return message;
}

