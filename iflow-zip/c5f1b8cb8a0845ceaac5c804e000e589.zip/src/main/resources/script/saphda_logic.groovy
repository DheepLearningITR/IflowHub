import com.sap.it.api.mapping.*;
import org.json.JSONObject;
import org.json.JSONException;
import groovy.json.JsonBuilder
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

def Message handleRequestBody(Message message) {
    //Body
    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body)
    //Headers
    //def headers = message.getHeaders();
    //def value = headers.get("oldHeader");
    //message.setHeader("oldHeader", value + " modified");
    //message.setHeader("newHeader", "newHeader");
    //Properties
    //def properties = message.getProperties();
    //value = properties.get("oldProperty");
    //message.setProperty("oldProperty", value + " modified");


    def saphda_calmonth_from = URLEncoder.encode(input.calmonthFrom,StandardCharsets.UTF_8.name())
    message.setProperty("saphda_calmonth_from", saphda_calmonth_from);
    message.setProperty("saphda_current_calmonth", saphda_calmonth_from);

    def saphda_calmonth_to = URLEncoder.encode(input.calmonthTo,StandardCharsets.UTF_8.name())
    message.setProperty("saphda_calmonth_to", saphda_calmonth_to);
    
    def modelID = URLEncoder.encode(input.modelID,StandardCharsets.UTF_8.name())
    message.setProperty("saphda_modelID", modelID);
    
    def saphda_transactionID = UUID.randomUUID().toString().replace("-", "");
    message.setProperty("saphda_transactionID", saphda_transactionID);
    
    return message;
}

def Message semanticPartition(Message message) {

    def propMap = message.getProperties()
    def saphda_current_calmonth = propMap.get("saphda_current_calmonth")
    def saphda_calmonth_from = propMap.get("saphda_calmonth_from")
    def saphda_calmonth_to = propMap.get("saphda_calmonth_to")
    def saphda_cc_date = propMap.get('saphda_cc_date')
    def saphda_cc_date_json = new JsonSlurper().parse(new StringReader(saphda_cc_date))
    def saphda_cc_date_array = saphda_cc_date_json.get("value")

    def nextmonth = '000000'

    saphda_cc_date_array.any { f ->
        if ( f.CALMONTH > saphda_current_calmonth &&
                nextmonth == '000000' &&
                f.CALMONTH <= saphda_calmonth_to &&
                f.CALMONTH >= saphda_calmonth_from ) {
            nextmonth = f.CALMONTH

        } else if ( nextmonth == '000000' && saphda_calmonth_to == saphda_calmonth_from ) {
            nextmonth = saphda_calmonth_to
        }
    }

    nextmonth = URLEncoder.encode(nextmonth,StandardCharsets.UTF_8.name())
    message.setProperty("saphda_current_calmonth",nextmonth)

    return message;
}

def String convertDate(String arg1){

    Date date = Date.parse( 'yyyyMM', arg1 )
    String converted_datetime = date.format( 'yyyy-MM-dd\'T\'HH:mm:ss' )

    return converted_datetime;
}

def BigDecimal convertKyf(arg1){

    BigDecimal f
    try {
        f = new BigDecimal(arg1).setScale(7, java.math.RoundingMode.HALF_UP);
    } catch (Exception e) {
        f = 0
    }
    return f;
}

def Message transform(Message message) {

    Reader body = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(body)
    def result_array = input.get("value")

    def propMap = message.getProperties()
   
    def saphda_ipb_credential = propMap.get('saphda_ipb_credential')
    def saphda_ibp_url = propMap.get('saphda_ibp_url')
    def saphda_ibp_planningarea = propMap.get('saphda_ibp_planningarea')
    def saphda_current_calmonth = propMap.get("saphda_current_calmonth")
    def saphda_calmonth_from = propMap.get("saphda_calmonth_from")
    def saphda_calmonth_to = propMap.get("saphda_calmonth_to")
    def commit_val = propMap.get('saphda_commit')
    if ( saphda_current_calmonth >= saphda_calmonth_to || saphda_current_calmonth == '000000' ) {
        message.setProperty("saphda_commit",'true')
        commit_val = "true"
    }

    def saphda_cc_country_curr = propMap.get('saphda_cc_country_curr')
    def saphda_cc_country_curr_json = new JsonSlurper().parse(new StringReader(saphda_cc_country_curr))
    HashMap<String, String> saphda_cc_curr_map = new HashMap<String, String>();
    saphda_cc_country_curr_json.value.each { item -> saphda_cc_curr_map.put(item.ID,item.currency);}
    HashMap<String, String> saphda_cc_country_map = new HashMap<String, String>();
    saphda_cc_country_curr_json.value.each { item -> saphda_cc_country_map.put(item.ID,item.Country);}

    def saphda_transactionID = propMap.get("saphda_transactionID");

    def data_raw = result_array.collect {
        [
                "PERIODID3_TSTAMP"      : convertDate(it.Date),
                "PRDID"                 : it.SAP_ALL_PRODUCT,
                "CURRID"                : saphda_cc_curr_map.getOrDefault(it.SAP_ALL_COMPANY_CODE,'#'),
                "CUSTID"                : it.SAP_ALL_CUSTOMER.padLeft(10,'0'),
                "SALESSPEND"            : convertKyf(it.AMOUNT)
        ]
    }

    def data_sum = data_raw 
            .groupBy {
                [ 
                  it.PERIODID3_TSTAMP,
                  it.PRDID,
                  it.CURRID,
                  it.CUSTID
                ]
            }

    def data_sum2 = data_sum.collectEntries {
        [(it.key): [
                PERIODID3_TSTAMP        : it.value.PERIODID3_TSTAMP.first(),
                PRDID                   : it.value.PRDID.first(),
                CURRID                  : it.value.CURRID.first(),
                CUSTID                  : it.value.CUSTID.first(),
                SALESSPEND              : it.value.sum { it.SALESSPEND }]]
    }

    def builder = new JsonBuilder();
    builder {
        "hostName" saphda_ibp_url
        "credentialsName" saphda_ipb_credential
        "planningArea" saphda_ibp_planningarea
        "commit" commit_val.toString()
        "oData" "true"
        'fieldsString' 'PERIODID3_TSTAMP,PRDID,CURRID,CUSTID,SALESSPEND'
        'transactionId' saphda_transactionID

        sacPayload data_sum2.collect {
            [
                    "PERIODID3_TSTAMP"  : it.key[0],
                    "PRDID"             : it.key[1],
                    "CURRID"            : it.key[2],
                    "CUSTID"            : it.key[3],
                    "SALESSPEND"        : it.value.SALESSPEND.toPlainString()
            ]
        }
    }

    def prettyBody = builder.toPrettyString()
    
    message.setBody(prettyBody);

    return message;
}

def Message catch_camels(Message message){

    def map  = message.getProperties();
    def ex   = map.get("CamelExceptionCaught");
    def exceptionText;

    if (ex != null)
    {
        exceptionText    = ex.getMessage();
        def messageLog   = messageLogFactory.getMessageLog(message);
        messageLog.addAttachmentAsString("Exception", exceptionText,"application/text");

        // copy the http error response body as a property
        message.setProperty("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());

        try {

            def mp = [
                    "IBP Host" :  message.getProperty('saphda_ibp_url'),
                    "IBP credentials" :  message.getProperty('saphda_ipb_credential'),
                    "Status" : "error",
                    "stepStatus" : "error",
                    "current/nextmonth" :  message.getProperty('saphda_current_calmonth'),
                    "Message" :  exceptionText
            ];

            def ibpCommitStatus = new JSONObject(mp).toString();

            message.setProperty("http.response", ibpCommitStatus);

            message.setBody(ibpCommitStatus);

        } catch (JSONException e) {
            message.setBody(e);
        }
    }
    return message;
}

