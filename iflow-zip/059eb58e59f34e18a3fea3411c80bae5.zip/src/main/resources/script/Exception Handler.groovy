import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonException;

def Message processData(Message message) {
    // get a map of properties
    def map = message.getProperties();
    // get an exception java class instance
    def cException = map.get("CamelExceptionCaught");
    def headers = message.getHeaders();
    def errorMessage;
    def statusCode;
    def errorJsonBody;
    if (cException != null) {
        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (cException.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
            def jsonResponseBody = cException.getResponseBody();
            if (jsonResponseBody != null) {
                //When there is a response from ETA
                def parser = new JsonSlurper();
                try {
                    def responseBody = parser.parseText(jsonResponseBody);
                    if(responseBody.error != null) {
                        //errorMessage = responseBody.error.details[0].message;
                        errorMessage = "Refer the Message Id " + headers.get("SAP_MessageProcessingLogID");
                        statusCode = responseBody.error.code;
                        try {
                            statusCode as Double //If statusCode is not a number return generic code 100
                            }catch (e) {
                                statusCode = "100";
                            }
                        message.setProperty("errorBody",jsonResponseBody);
                    }
                } catch (JsonException parserException) {
                }
            }
            if (errorMessage == null) {
                //When there is no response body or when the response body is not in ETA standard error structure
                //errorMessage = cException.getStatusText();
                errorMessage = "Refer the Message Id " + headers.get("SAP_MessageProcessingLogID");
                statusCode = cException.getStatusCode();
                try {
                    statusCode as Double //If statusCode is not a number return generic code 100
                    }catch (e) {
                        statusCode = "100";
                    }
                errorJsonBody = '{"errorMessage"' + ':"'+errorMessage+'"' + ',' + '"statusCode"' + ':"'+statusCode+'"' + "}";;
                message.setProperty("errorBody",errorJsonBody);
            }
        } else {
            //Exception from iFlow
            //errorMessage = cException.getMessage();
            //statusCode = 'CPI';
            errorMessage = "Refer the Message Id " + headers.get("SAP_MessageProcessingLogID");
            statusCode = "100";
            errorJsonBody = '{"errorMessage"' + ':"'+errorMessage+'"' + ',' + '"statusCode"' + ':"'+statusCode+'"' + "}";;
            message.setProperty("errorBody",errorJsonBody);
        }
    } else {
        //Fallback
        //errorMessage = "Internal Server Error";
        //statusCode = "CPI";
        errorMessage = "Refer the Message Id " + headers.get("SAP_MessageProcessingLogID");
        statusCode = "100";
        errorJsonBody = '{"errorMessage"' + ':"'+errorMessage+'"' + ',' + '"statusCode"' + ':"'+statusCode+'"' + "}";;
        message.setProperty("errorBody",errorJsonBody);
    }
    message.setProperty("errorMessage", errorMessage);
    message.setProperty("statusCode", statusCode);
    return message;
}

