import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import java.util.ArrayList;


def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);

    def body = message.getBody(java.lang.String) as String
    def jsonParser = new JsonSlurper()
    def jsonObject = jsonParser.parseText(body)


    message.setProperty("length",  body.length())

    def map = message.getProperties()
    int i = map.get("i").toInteger()
    
    int count
    
    def array_1000 = []
    def json = {}    
    
        // for(count = map.get("i").toInteger(); count < jsonObject.size() - i; count++){
            
           
        //   try {
        //         if (jsonObject[count].dataAdmissao == null){
        //             json = JsonOutput.toJson(
        //             matricula : jsonObject[count].matricula,
        //             departamento : jsonObject[count].departamento,
        //             // hierarquia_1n : jsonObject[count].hierarquia_1n,
        //             cargo : jsonObject[count].cargo,
        //             regimeTrabalho : jsonObject[count].regimeTrabalho,
        //             nome : jsonObject[count].nome,
        //             dataNascimento : jsonObject[count].dataNascimento,
        //             sexo : jsonObject[count].sexo,
        //             cpf : jsonObject[count].cpf,
        //             rg : jsonObject[count].rg,
        //             ctps : jsonObject[count].ctps,
        //             pis : jsonObject[count].pis,
        //             // cod_escala_padrao : jsonObject[count].cod_escala_padrao,
        //             carga_horaria : jsonObject[count].carga_horaria,
        //             registra_ponto : jsonObject[count].registra_ponto,
        //             // estado : jsonObject[count].estado,
        //             login_saml : jsonObject[count].login_saml,
        //             // municipio : jsonObject[count].municipio,
        //             matricula_chefia : jsonObject[count].matricula_chefia,
        //             nome_chefia : jsonObject[count].nome_chefia,
        //             //dataDemissao : jsonObject[count].dataDemissao,
        //             centroCusto : jsonObject[count].centroCusto,
        //             //email : jsonObject[count].email,
        //             cod_empresa : jsonObject[count].cod_empresa,
        //             // diretoria : jsonObject[count].diretoria,
        //             // area_rh : jsonObject[count].area_rh,
        //             // filial : jsonObject[count].filial,
        //             // cnpj : jsonObject[count].cnpj,
        //             // rg_uf : jsonObject[count].rg_uf,
        //             // ctps_serie : jsonObject[count].ctps_serie,
        //             // ctps_uf : jsonObject[count].ctps_uf,
        //             // ctps_emissao : jsonObject[count].ctps_emissao,
        //             // cod_cargo : jsonObject[count].cod_cargo,
        //             // cod_departamento : jsonObject[count].cod_departamento,
        //             // rg_emissao : jsonObject[count].rg_emissao,
        //             razao_social_sindicato : jsonObject[count].razao_social_sindicato,
        //             bandeira_unidade : jsonObject[count].bandeira_unidade,
        //             // situacao : jsonObject[count].situacao,
        //             // titulo_eleitor : jsonObject[count].titulo_eleitor,
        //             telefone : jsonObject[count].telefone,
        //             nome_empresa : jsonObject[count].nome_empresa,
        //             // conta_banco : jsonObject[count].conta_banco,
        //             endereco_completo : jsonObject[count].endereco_completo,
        //             // salario : jsonObject[count].salario,
        //             email_chefia : jsonObject[count].email_chefia,
        //             // nome_mae : jsonObject[count].nome_mae,
        //             // nome_pai : jsonObject[count].nome_pai,
        //             // dependente : jsonObject[count].dependente,
        //             nome_social : jsonObject[count].nome_social,
        //             // cidade_nascimento : jsonObject[count].cidade_nascimento,
        //             // marital_status : jsonObject[count].marital_status,
        //             cod_estabelecimento : jsonObject[count].cod_estabelecimento,
        //             cod_sindicato : jsonObject[count].cod_sindicato,
        //             // zona_eleitoral : jsonObject[count].zona_eleitoral,
        //             // secao : jsonObject[count].secao,
        //             // escolaridade : jsonObject[count].escolaridade,
        //             h_base_mensal : jsonObject[count].h_base_mensal,
        //             h_base_semanal : jsonObject[count].h_base_semanal,
        //             // data_vencimento_exp45 : jsonObject[count].data_vencimento_exp45,
        //             // data_vencimento_exp90 : jsonObject[count].data_vencimento_exp90
                    
        //             )
        //         } else {
        //             json = JsonOutput.toJson(
        //             matricula : jsonObject[count].matricula,
        //             dataAdmissao : jsonObject[count].dataAdmissao,
        //             departamento : jsonObject[count].departamento,
        //             // hierarquia_1n : jsonObject[count].hierarquia_1n,
        //             cargo : jsonObject[count].cargo,
        //             regimeTrabalho : jsonObject[count].regimeTrabalho,
        //             nome : jsonObject[count].nome,
        //             dataNascimento : jsonObject[count].dataNascimento,
        //             sexo : jsonObject[count].sexo,
        //             cpf : jsonObject[count].cpf,
        //             rg : jsonObject[count].rg,
        //             ctps : jsonObject[count].ctps,
        //             pis : jsonObject[count].pis,
        //             // cod_escala_padrao : jsonObject[count].cod_escala_padrao,
        //             carga_horaria : jsonObject[count].carga_horaria,
        //             registra_ponto : jsonObject[count].registra_ponto,
        //             // estado : jsonObject[count].estado,
        //             login_saml : jsonObject[count].login_saml,
        //             // municipio : jsonObject[count].municipio,
        //             matricula_chefia : jsonObject[count].matricula_chefia,
        //             nome_chefia : jsonObject[count].nome_chefia,
        //             //dataDemissao : jsonObject[count].dataDemissao,
        //             centroCusto : jsonObject[count].centroCusto,
        //             //email : jsonObject[count].email,
        //             cod_empresa : jsonObject[count].cod_empresa,
        //             // diretoria : jsonObject[count].diretoria,
        //             // area_rh : jsonObject[count].area_rh,
        //             // filial : jsonObject[count].filial,
        //             // cnpj : jsonObject[count].cnpj,
        //             // rg_uf : jsonObject[count].rg_uf,
        //             // ctps_serie : jsonObject[count].ctps_serie,
        //             // ctps_uf : jsonObject[count].ctps_uf,
        //             // ctps_emissao : jsonObject[count].ctps_emissao,
        //             // cod_cargo : jsonObject[count].cod_cargo,
        //             // cod_departamento : jsonObject[count].cod_departamento,
        //             // rg_emissao : jsonObject[count].rg_emissao,
        //             razao_social_sindicato : jsonObject[count].razao_social_sindicato,
        //             bandeira_unidade : jsonObject[count].bandeira_unidade,
        //             // situacao : jsonObject[count].situacao,
        //             // titulo_eleitor : jsonObject[count].titulo_eleitor,
        //             telefone : jsonObject[count].telefone,
        //             nome_empresa : jsonObject[count].nome_empresa,
        //             // conta_banco : jsonObject[count].conta_banco,
        //             endereco_completo : jsonObject[count].endereco_completo,
        //             // salario : jsonObject[count].salario,
        //             email_chefia : jsonObject[count].email_chefia,
        //             // nome_mae : jsonObject[count].nome_mae,
        //             // nome_pai : jsonObject[count].nome_pai,
        //             // dependente : jsonObject[count].dependente,
        //             nome_social : jsonObject[count].nome_social,
        //             // cidade_nascimento : jsonObject[count].cidade_nascimento,
        //             // marital_status : jsonObject[count].marital_status,
        //             cod_estabelecimento : jsonObject[count].cod_estabelecimento,
        //             cod_sindicato : jsonObject[count].cod_sindicato,
        //             // zona_eleitoral : jsonObject[count].zona_eleitoral,
        //             // secao : jsonObject[count].secao,
        //             // escolaridade : jsonObject[count].escolaridade,
        //             h_base_mensal : jsonObject[count].h_base_mensal,
        //             h_base_semanal : jsonObject[count].h_base_semanal,
        //             // data_vencimento_exp45 : jsonObject[count].data_vencimento_exp45,
        //             // data_vencimento_exp90 : jsonObject[count].data_vencimento_exp90     
        
        //             )   
        //         }
         
        //         array_1000.push(json)
                
        //     } catch(Exception ex) {
        //         // error.push(jsonObject.User.User[i].userId)
        //     }             
            
        // }
    
    // message.setBody(JsonOutput.prettyPrint(array_1000.toString()))
    // messageLog.addAttachmentAsString("PayloadAhgora", JsonOutput.prettyPrint(array_1000.toString()), "text/json");
    
    i += 5000
    message.setProperty("i", i)
    
    return message;
}