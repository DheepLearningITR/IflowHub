import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import java.util.ArrayList;

def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    def body = message.getBody(java.lang.String) as String
    def jsonParser = new JsonSlurper()
    def jsonObject = jsonParser.parseText(body)

    def arr = []
    def error = []
    def json
    def results = {}
    def errorJson
    
    // messageLog.addAttachmentAsString("SFSFResponse", JsonOutput.prettyPrint(body), "text/json");
    
    def map_prop = message.getProperties()
    
    for(int i = 0; i < jsonObject.PerPerson.PerPerson.size(); i++ ){
        try {
            
            def l_person = jsonObject.PerPerson.PerPerson[i]
            
            def l_matricula = ''
            def l_pis = ''
            def l_email = ''
            def l_name = ''
            def l_rg = ''
            def l_dataAdmissao = ''
            def l_dataDemissao = ''
            def l_cargo = ''
            def l_departamento = ''
            def l_sexo = ''
            def l_cpf = ''
            def l_centroCusto = ''
            def l_dataNascimento = ''
            def l_login_saml = ''
            def l_matricula_chefia = ''
            def l_ctps = ''
            def l_cnpj = ''
            def l_regimeTrabalho = ''
            
            try {
                l_matricula = l_person.personalInfoNav.PerPersonal.personIdExternal
            } catch(Exception ex) {
            } 

            try {
                l_dataAdmissao = Date.parse("yyyy-MM-dd", l_person.employmentNav.EmpEmployment.jobInfoNav.EmpJob.companyEntryDate.replace("T00:00:00.000", "")).format("dd/MM/yyyy")
            } catch(Exception ex) {
            }     
            
            try {
                l_dataDemissao = Date.parse("yyyy-MM-dd", l_person.employmentNav.EmpEmployment.endDate.replace("T00:00:00.000", "")).format("dd/MM/yyyy")
            } catch(Exception ex) {
            }                 

            try {
                l_cargo = l_person.employmentNav.EmpEmployment.jobInfoNav.EmpJob.jobTitle
            } catch(Exception ex) {
            }    

            try {
                l_departamento = l_person.employmentNav.EmpEmployment.jobInfoNav.EmpJob.department
            } catch(Exception ex) {
            }

            try {
                l_centroCusto = l_person.employmentNav.EmpEmployment.jobInfoNav.EmpJob.costCenter
            } catch(Exception ex) {
            }

            try {
                l_dataNascimento = Date.parse("yyyy-MM-dd", l_person.dateOfBirth.replace("T00:00:00.000", "")).format("dd/MM/yyyy")
            } catch(Exception ex) {
            }

            try {
                l_login_saml = l_person.userAccountNav.UserAccount.username
            } catch(Exception ex) {
            }

            try {
                // l_name = l_person.personalInfoNav.PerPersonal.formalName
                l_name = l_person.personalInfoNav.PerPersonal.firstName + ' ' + l_person.personalInfoNav.PerPersonal.lastName
            } catch(Exception ex) {
            }
            
            try {
                l_email = l_person.emailNav.PerEmail.emailAddress
            } catch(Exception ex) {
            }
            
            try {
                l_pis = l_person.employmentNav.EmpEmployment.empWorkPermitNav.EmpWorkPermit.findAll { map -> map.documentTypeNav.PicklistOption.externalCode == map_prop.get('external_code_pis') }.documentNumber
                l_pis = l_pis.toString().substring(1, l_pis.toString().length() - 1)
                // l_pis = l_person.employmentNav.EmpEmployment.empWorkPermitNav.EmpWorkPermit.documentNumber
            } catch(Exception ex) {
                if (l_person.employmentNav.EmpEmployment.empWorkPermitNav.EmpWorkPermit.documentTypeNav.PicklistOption.externalCode == map_prop.get('external_code_pis')){
                    l_pis = l_person.employmentNav.EmpEmployment.empWorkPermitNav.EmpWorkPermit.documentNumber
                }
            }
            
            try {
                l_rg = l_person.employmentNav.EmpEmployment.empWorkPermitNav.EmpWorkPermit.findAll { map -> map.documentTypeNav.PicklistOption.externalCode == map_prop.get('external_code_rg') }.documentNumber
                l_rg = l_rg.toString().substring(1, l_rg.toString().length() - 1)
            } catch(Exception ex) {
                if (l_person.employmentNav.EmpEmployment.empWorkPermitNav.EmpWorkPermit.documentTypeNav.PicklistOption.externalCode == map_prop.get('external_code_rg')){
                    l_rg = l_person.employmentNav.EmpEmployment.empWorkPermitNav.EmpWorkPermit.documentNumber
                }
            }
            
            try {
                l_cpf = l_person.nationalIdNav.PerNationalId.nationalId
                
            } catch(Exception ex) {
            }
            
            try {
                l_sexo = l_person.personalInfoNav.PerPersonal.gender
            } catch(Exception ex) {
            }
            
            
            try {
                l_ctps = l_person.employmentNav.EmpEmployment.empWorkPermitNav.EmpWorkPermit.findAll { map -> map.documentTypeNav.PicklistOption.externalCode == map_prop.get('external_code_ctps') }.documentNumber
                l_ctps = l_ctps.toString().substring(1, l_ctps.toString().length() - 1)
            } catch(Exception ex) {
                if (l_person.employmentNav.EmpEmployment.empWorkPermitNav.EmpWorkPermit.documentTypeNav.PicklistOption.externalCode == map_prop.get('external_code_ctps')){
                    l_ctps = l_person.employmentNav.EmpEmployment.empWorkPermitNav.EmpWorkPermit.documentNumber
                }                
            }
            
            try {
                l_nome_chefia = l_person.employmentNav.EmpEmployment.jobInfoNav.EmpJob.managerUserNav.User.defaultFullName
            } catch(Exception ex) {
            }
            
            try {
                l_matricula_chefia = l_person.employmentNav.EmpEmployment.jobInfoNav.EmpJob.managerUserNav.User.empId
            } catch(Exception ex) {
            }             
            
            try {
                l_regimeTrabalho = l_person.employmentNav.EmpEmployment.jobInfoNav.EmpJob.employmentTypeNav.PicklistOption.externalCode
                if (l_regimeTrabalho == 'PW'){
                    l_regimeTrabalho = 'CLT'
                } else {
                    // l_regimeTrabalho = 'estagiario'
                    l_regimeTrabalho = 'CLT'
                }
            } catch(Exception ex) {
            }

            try {
                l_cnpj = l_person.employmentNav.EmpEmployment.jobInfoNav.EmpJob.User.managerUserNav.empId
            } catch(Exception ex) {
            }              
            
         
            json = {}
            json = JsonOutput.toJson(
                matricula : l_matricula,
                pis : l_pis,
                nome : l_name,
                dataAdmissao : (l_dataAdmissao == '') ? 'delete' : l_dataAdmissao,
                dataDemissao : (l_dataDemissao == '') ? 'delete' : l_dataDemissao,
                ctps : l_ctps,
                cargo : l_cargo,
                departamento : l_departamento,
                sexo : l_sexo,
                email : l_email,
                cpf : l_cpf,
                rg : l_rg,
                // cnpj : l_cnpj,
                centroCusto : l_centroCusto,
                regimeTrabalho : l_regimeTrabalho,
                dataNascimento : l_dataNascimento,
                login_saml : l_login_saml,
                matricula_chefia: l_matricula_chefia,
                nome_chefia : l_nome_chefia,
            )
            
            arr.push(json)
        
        } catch(Exception ex) {
            errorJson = {}
            errorJson = JsonOutput.toJson(
                // personId : jsonObject.PerPerson.PerPerson[i].personId,
                error : ex.toString()
            )
            error.push(errorJson)
        }
         
        
    }
    
    message.setBody(JsonOutput.prettyPrint(arr.toString())) 
    message.setProperty("size_payload_hana", arr.size())
    message.setProperty("array_tratado",  JsonOutput.prettyPrint(arr.toString()))
    // messageLog.addAttachmentAsString("PayloadAHGORA", JsonOutput.prettyPrint(arr.toString()), "text/json");
    
    if (error.size > 0){
        // messageLog.addAttachmentAsString("ErrorMapping", JsonOutput.prettyPrint(error.toString()), "text/json");   
    }
   
    return message;
    
}