import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Date;

def Message processData(Message message) {
    
       def map = message.getProperties();
       def zdias = map.get("zdias");
       
       def data_de_hoje = new Date()
       
       def data_tratada = data_de_hoje - zdias.toInteger()
       
       message.setProperty("data_de_hoje", data_de_hoje.format("yyyyMMdd"))
       message.setProperty("data_tratada", data_tratada.format("yyyyMMdd"))
       
       return message;
}