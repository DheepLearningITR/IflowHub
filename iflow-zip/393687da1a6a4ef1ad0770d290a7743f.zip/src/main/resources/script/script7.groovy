import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message)
 {
	def messageLog = messageLogFactory.getMessageLog(message);
    def body = message.getBody();
    def jsonSlurper = new JsonSlurper();
    def list = jsonSlurper.parseText(body);
    
    list.each(){ dataSet ->
        (dataSet.dataAdmissao == 'delete') ? dataSet.remove('dataAdmissao') : dataSet.dataAdmissao;
        (dataSet.dataDemissao == 'delete') ? dataSet.remove('dataDemissao') : dataSet.dataDemissao;
        (dataSet.sexo == '') ? dataSet.remove('sexo'): dataSet.sexo;
    }
    
    def jsonOP = JsonOutput.toJson(list)
    
    message.setBody(jsonOP);
    // messageLog.addAttachmentAsString("PayloadAHGORA", JsonOutput.prettyPrint(jsonOP), "text/json");
    return message;
}