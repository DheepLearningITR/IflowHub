import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
    def body = message.getBody(java.lang.String) as String
    def jsonParser = new JsonSlurper()
    def jsonObject = jsonParser.parseText(body)
    
    jsonObject.remove('company')
    jsonObject.remove('message')
    
    def json_unique = new JsonBuilder(jsonObject).toPrettyString()
    
    def unique = jsonObject.unique
    
    // messageLog.addAttachmentAsString("UniqueCode", JsonOutput.prettyPrint(json_unique), "text/json");
    message.setProperty("unique",  unique)

    return message;

    
}