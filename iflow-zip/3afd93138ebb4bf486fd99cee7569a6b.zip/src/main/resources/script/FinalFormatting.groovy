import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.util.*;
import java.util.HashMap;

def Message processData(Message message) { 

	def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	
	if(object != ""){
    	object.result.each{ item -> 
            if (!isCollectionOrArray(item.texts)) {      
        		//Converting Record to an array  
        		if(item.texts == ""){
        		    item.texts = [];
        		}else{
        		    item.texts = [item.texts].toArray();    
        		}
        	}
        	if (!isCollectionOrArray(item.cndnTypeBlankTexts)) {    
        		//Converting Record to an array  
        		if(item.cndnTypeBlankTexts == ""){
        		    item.cndnTypeBlankTexts = [];
        		}else{
        		    item.cndnTypeBlankTexts = [item.cndnTypeBlankTexts].toArray();    
        		}
        	}
        }
	}else{
	    def array = [
	        result: []
	    ]
	    object = array;
	}
	results = JsonOutput.toJson( object );
    message.setBody(results);
    return message;
}

//Returns true if object is an array
boolean isCollectionOrArray(object) {
    
	[Collection, Object[]].any {        
		it.isAssignableFrom(object.getClass())    
	}

}