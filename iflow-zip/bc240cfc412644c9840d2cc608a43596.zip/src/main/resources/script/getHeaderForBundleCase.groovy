import com.sap.it.api.mapping.*;

import com.sap.it.api.mapping.MappingContext;

def String getHeaderForBundleCase(String header_name, MappingContext context) {

    def containServiceBundle = context.getProperty("ContainServiceBundle");
    def headValue;
    if( containServiceBundle == 'X' ){
         headValue= context.getProperty("ServiceOrderId");
    }
   
    return headValue;

}