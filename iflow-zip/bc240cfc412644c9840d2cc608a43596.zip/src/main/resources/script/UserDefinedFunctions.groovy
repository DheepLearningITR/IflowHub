import com.sap.gateway.ip.core.customdev.util.Message
import java.util.*
import com.sap.it.api.mapping.*
import com.sap.it.api.mapping.MappingContext

//This method returns value of a property, expects one input prop_name i.e. name of the property to be retrieved
def String getProperty(String prop_name, MappingContext context) {
    return context.getProperty(prop_name)
}

// Return value of property prop_name or default_value if property is empty or does not exist
def String getPropertyOrDefault(String prop_name, String default_value, MappingContext context) {
    String value = context.getProperty(prop_name)
    if (value) {
        return value
    } else {
        return default_value
    }
}

// Return value of property prop_name or null if property is empty or does not exist
def String getPropertyOrNull(String prop_name, MappingContext context) {
    String value = context.getProperty(prop_name)
    if (value) {
        return value
    } else {
        return null
    }
}

// Generic date/time conversion from ISO string to epoch time in milliseconds
// ISO string time is expected to be UTC, suffixes like 'Z' or '.000' are ignored
def String convIsoDateTimeToEpoch(String isoDateTime) {
    if ( isoDateTime != null && isoDateTime != '' ) {
        String pattern = "yyyy-MM-dd'T'HH:mm:ss"
        Date epochtime = Date.parse(pattern, isoDateTime)
        return epochtime.getTime()
    } else {
        return ''
    }
}