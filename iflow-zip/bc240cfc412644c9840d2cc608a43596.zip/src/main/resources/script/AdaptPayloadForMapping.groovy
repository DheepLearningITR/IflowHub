import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def jsonSlurper = new JsonSlurper()
    def bodyJson = jsonSlurper.parseText(body) as Map

    // get external ids from message header
    def serviceOrder = message.getHeaders().get("ServiceOrder") ?: ''
    def serviceOrderItem = message.getHeaders().get("ServiceOrderItem") ?: ''
    def serviceOrderBundleItem = message.getHeaders().get("ServiceOrderBundleItem") ?: ''
    def serviceOrderParentItem = message.getHeaders().get("ParentServiceOrderItem") ?: ''
    def eventType = message.getHeaders().get("EventType") ?: ''

    message.setProperty("ServiceOrderId", serviceOrder)

    if (serviceOrderBundleItem) {
        message.setProperty("ServiceBundleId", serviceOrderBundleItem)
        message.setProperty("ContainServiceBundle","X")              
        //Get Executing Employee for mapping
        if ( bodyJson.data.serviceCall.activity.expenses[0] ) {
            def executingEmployee = bodyJson.data.serviceCall.activity.expenses[0].createPerson.externalId
            message.setProperty("ExecutingEmployee", executingEmployee)
        } else if ( bodyJson.data.serviceCall.activity.timeEfforts[0] ) {
            def executingEmployee = bodyJson.data.serviceCall.activity.timeEfforts[0].createPerson.externalId
            message.setProperty("ExecutingEmployee", executingEmployee)
        } else if ( bodyJson.data.serviceCall.activity.materials[0] ) {
            def executingEmployee = bodyJson.data.serviceCall.activity.materials[0].createPerson.externalId
            message.setProperty("ExecutingEmployee", executingEmployee)
        }
    } else {
        message.setProperty("ContainServiceBundle", "")
    }

    message.setProperty("ServiceOrderItemId", serviceOrderItem)
    
    //Set property ActivityId
    message.setProperty("ActivityId", bodyJson.data.serviceCall.activity.unifiedIdentifier.id)
     
    bodyJson = bodyJson.data.serviceCall.activity
    bodyJson = JsonOutput.toJson(bodyJson)
    body = '{"activity" : ' + bodyJson + '}'
    message.setProperty("ActivityPayload",body)
    message.setBody(body)

    return message
}