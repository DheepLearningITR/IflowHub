import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;

def String GetMaterialItemId(String externalid,  MappingContext context){
    
//	def containServiceBundle = context.getProperty("ContainServiceBundle");
//    def materialId;
//    if( containServiceBundle == 'X' ){
//         materialId = externalid.split('/')[2] as String;
//    }else{
//	     materialId = externalid.split('/')[1] as String;
//    }
   
//    return materialId;

    return externalid.split('/')[1] as String;

}