import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;

def String getServiceBundleId(String header_name, MappingContext context) {
    
    def containServiceBundle =  context.getProperty("ContainServiceBundle");
    def serviceOrderItemId ;
    if (containServiceBundle == 'X' ){
        serviceOrderItemId = context.getProperty("ServiceBundleId");
    }

    return serviceOrderItemId;

}