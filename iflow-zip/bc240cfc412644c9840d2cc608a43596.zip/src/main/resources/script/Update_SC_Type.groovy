import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;

def String Update_SC_Type(String arg1, MappingContext context){
	
  	def ServiceOrderType = context.getProperty("ServiceOrderType") as String;

    if (ServiceOrderType == "RPO1") {
        return "RPC1"
    } else if (ServiceOrderType == "RPO2") {
        return "RPC2"
    } else if (ServiceOrderType == "SVO1") {
        return "SVC1"
    } else {
        return "SVC2"   
    }
}