import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    def containSrvBundle = message.getProperty("ContainServiceBundle");
    if(containSrvBundle == ''){
        //Remove service bundle structure in the XML
        def xmlBody = new XmlSlurper().parseText(body);
        def result = xmlBody.A_ServiceConfirmationType.to_Item.A_ServiceConfirmationItemType[0].replaceNode{ };
        def output = XmlUtil.serialize(xmlBody);
        message.setBody(output);
        
    }
    
    return message;
}