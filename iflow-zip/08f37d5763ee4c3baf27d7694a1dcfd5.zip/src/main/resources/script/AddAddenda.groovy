import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.*;

def Message processData(Message message) {
    
  def map = message.getProperties();
  def isaddenda =  map.get("isaddenda");
  if(isaddenda){
     
  String body = message.getBody(java.lang.String ) as String;
  String addenda = map.get("addenda");
  String mainxml = map.get("xmlcontent");
  String fragment = "<Addenda>" + addenda + "</Addenda>";
  def bodyNode     = new XmlParser().parseText(mainxml);
  def fragmentNode = new XmlParser().parseText(fragment);
  bodyNode.append(fragmentNode);
  message.setBody(XmlUtil.serialize(bodyNode));
  }
  
  return message;
  
}



