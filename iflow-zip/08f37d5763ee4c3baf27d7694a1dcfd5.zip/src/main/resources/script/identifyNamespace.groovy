import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message)
{

  def map = message.getProperties();
  def submitv2= map.get("submitv2");
  def cancelv2= map.get("cancelv2");
  def getstatusv2 = map.get("getstatusv2")
  def submitv3= map.get("submitv3");
  def cancelv3= map.get("cancelv3");
  def getstatusv3 = map.get("getstatusv3");
  def submitv4= map.get("submitv4");
  def submitv5= map.get("submitv5");
  def submitv6= map.get("submitv6");
  def submitv7= map.get("submitv7");
  def cancelv4= map.get("cancelv4");
  def getstatusv4 = map.get("getstatusv4");
  if(submitv2 || cancelv2 || getstatusv2)
     {
     	message.setProperty("namespace","\"http://www.sap.com/eDocument/Mexico/CFDI/v1.0\"");
     }
  else if(submitv4 || cancelv4 || getstatusv4)
     {
     	message.setProperty("namespace","\"http://www.sap.com/eDocument/Mexico/CFDI/v4.0\"");
     }
  else if(submitv5)
     {
     	message.setProperty("namespace","\"http://www.sap.com/eDocument/Mexico/CFDI/v4.1\"");
     } 
  else if(submitv6)
     {
     	message.setProperty("namespace","\"http://www.sap.com/eDocument/Mexico/CFDI/v4.2\"");
     } 
  else if(submitv7)
     {
     	message.setProperty("namespace","\"http://www.sap.com/eDocument/Mexico/CFDI/v5\"");
     }

  return message;

}