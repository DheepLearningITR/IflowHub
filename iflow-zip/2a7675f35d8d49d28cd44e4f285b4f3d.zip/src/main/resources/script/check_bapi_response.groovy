import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.util.*;
import groovy.xml.*;
import org.codehaus.*;
import java.util.HashMap;

def Message processData(Message message) {

     def body_xml= message.getBody(java.lang.String) as String;
	 Node root = new XmlParser().parseText(body_xml);
     try{
     def field1=root.RETURN2.item[0].MESSAGE.text();
     message.setHeader("errorMessage", field1);
     message.setHeader("errorExists", "true");
     }
     catch(Exception e)
     {
          message.setHeader("errorMessage", "");
     }
     return message;
}

