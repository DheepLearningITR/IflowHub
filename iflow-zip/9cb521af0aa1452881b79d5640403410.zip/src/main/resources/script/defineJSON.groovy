import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonBuilder;


def Message buildSurveyJSON(Message message) {
//get the message Body  as string object
        def body = message.getBody(String.class);
        def jsonSlurper = new JsonSlurper();
         //convert the body to a json object
         def jsonObject = jsonSlurper.parseText(body.toString());
         //get the survey from  json object
        def root = jsonObject.root;
        if(root != null)
        {
            
            def surveys= jsonObject.root.surveys;
            def jsonOP;
            //if there are no surveys then return []
            if(surveys == [""])
            {
                jsonOP = [];
            }
            //return all the surveys in a json array
            else
            {
                jsonOP = JsonOutput.toJson(surveys);
            }
            message.setBody(jsonOP);
        }
        return message;
}

def Message buildPollJSON(Message message) {
//get the message Body  as string object
        def body = message.getBody(String.class);
        def jsonSlurper = new JsonSlurper();
         //convert the body to a json object
         def jsonObject = jsonSlurper.parseText(body.toString());
         //get the survey from  json object
        def root = jsonObject.root;
        if(root != null)
        {
            
            def polls= jsonObject.root.polls;
            def jsonOP;
            //if there are no surveys then return []
            if(polls == [""])
            {
                jsonOP = [];
            }
            //return all the surveys in a json array
            else
            {
                jsonOP = JsonOutput.toJson(polls);
            }
            message.setBody(jsonOP);
        }
        return message;
}