import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
def Message processData(Message message) {

    def body  = message.getBody(java.lang.String) as String;

    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("Error:", body, "text/plain");
    message.setBody(" ");
    return message;
}

def Message logger(Message message) {

    def body  = message.getBody(java.lang.String) as String;

    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("GTW Survey Response:", body, "text/plain");
    message.setBody(" ");
    return message;
}

def Message logPoll(Message message) {

    def body  = message.getBody(java.lang.String) as String;

    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("GTW Poll Response:", body, "text/plain");
    message.setBody(" ");
    return message;
}

def Message logSurvey(Message message) {

    def body  = message.getBody(java.lang.String) as String;

    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("Log Payload", body, "text/plain");
    message.setBody(" ");
    return message;
}