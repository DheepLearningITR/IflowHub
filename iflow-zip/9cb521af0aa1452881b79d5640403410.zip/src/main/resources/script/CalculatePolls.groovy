import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.*;
import groovy.xml.*;
import groovy.json.*

def Message getPollResponsesCount(Message message) {
    //Body 

    def body = message.getBody(String.class)   
    def jsonBody = new JsonSlurper().parseText(body)
    
    def noOfSurveys = 0;
    if(body != null && body)
    {    
        noOfSurveys = jsonBody.responses.size()
    }
    
    message.setProperty("noOfPolls", noOfSurveys)
    return message;
}