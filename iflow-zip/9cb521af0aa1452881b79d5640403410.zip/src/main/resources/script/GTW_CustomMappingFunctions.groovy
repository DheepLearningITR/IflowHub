import com.sap.it.api.mapping.*;
import groovy.json.*
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
    
//Get the externalizable parameter value by passing the externalizable property name & mapping context 
def String getExchangeProperty(String propertyName,MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}

def String getHeader(String headerName,MappingContext context) {
    String headerValue = context.getHeader(headerName);
    return headerValue;
}

def String deleteWhitespaces(String inputString) {
    def outputString = inputString.replaceAll("\\s+","")
    return outputString
}

def String md5Hash(String Question) {
    //def md5hash = value.md5()
    
def md5 = ''

    MessageDigest digest = MessageDigest.getInstance('MD5')
    digest.update(Question.bytes, 0, Question.length())
    md5hash = new BigInteger(1, digest.digest()).toString(16)

    return md5hash
}

def String createPollIDTimestamp(String SessionID,String Timestamp,MappingContext context) {
    
    def trimTimestamp = Timestamp.replaceAll("[^0-9]", "")

    def pollID = SessionID + "_" + trimTimestamp

    if(pollID.size() > 32) {
        def outPollID = pollID.substring(0,32)
        return outPollID
    } else {
        def outPollID = pollID
        return outPollID
    }
}

def String createPollID(String SessionID,String Question,MappingContext context) {
    
    def trimQuestion = Question.replaceAll("[^a-zA-Z0-9]", "")

    def pollID = SessionID + "_" + trimQuestion

    if(pollID.size() > 32) {
        def outID = pollID.substring(0,32)
        return outID
    } else {
        def outID = pollID
        return outID
    }
}

def String createQuestionID(String SessionID,String Question,MappingContext context) {
    
    def trimQuestion = Question.replaceAll("[^a-zA-Z0-9]", "")

    def questionID = SessionID + "_" + trimQuestion
    return questionID
    /*if(questionID.size() > 32) {
        def outQuestion = questionID.substring(0,32)
        return outQuestion
    } else {
        def outQuestion = questionID
        return outQuestion
    }*/
}

def String concatAnswers(String answer1, String answer2, String answer3 ,String answer4 ,String answer5 ,MappingContext context) {
    
    //def trimQuestion = Question.replaceAll("[^a-zA-Z0-9]", "")

    def concatAnswer = answer1 + ", " + answer2 + ", " + answer3 + ", " + answer4 + ", " + answer5
    return concatAnswer
    /*
    if(questionID.size() > 32) {
        def outQuestion = questionID.substring(0,32)
        return outQuestion
    } else {
        def outQuestion = questionID
        return outQuestion
    }*/
}
