import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
import java.text.DateFormat;  
import java.text.SimpleDateFormat; 


def Message getAttributesToProperty(Message message) {
    // Get MessageBody
    def body = message.getBody(String.class)   
    def sessionResponse = new JsonSlurper().parseText(body)
    def sessionKey = sessionResponse.sessionKey[0]
    def webinarID = sessionResponse.webinarID[0]

    message.setProperty("sessionKey",sessionKey)
    message.setProperty("webinarID",webinarID)
    
    return message
}

def Message TEST(Message message) {
   
   def map = message.getProperties();   
   def body = message.getBody()
   def jsonSlurper = new JsonSlurper();
   def sessionResponse = jsonSlurper.parseText(body);
   def sessionKey = sessionResponse.sessionKey;
   
   message.setProperty("totalAttendees",size);
   
   def messageLog = messageLogFactory.getMessageLog(message);
   def newAttendeeList = jsonSlurper.parseText('{"attendees": ""}')
   newAttendeeList.attendees = attendeeList
   message.setBody(JsonOutput.toJson(newAttendeeList))

   return message;
}

def Message generateGTWPath(Message message) {
    // Generate the resource path to read the sessions for the input meeting
       def map = message.getHeaders();
       def id = map.get("externaleventid");
       def resourcePath = "/meetings/" + id + "/sessions";
       message.setProperty("resourcePath", resourcePath);
       message.setProperty("externaleventID", id);
       
       return message;
}

def Message generateGTWAttendeesPath(Message message) {

    def json_body  = message.getBody();
    def jsonSlurper = new JsonSlurper();
    def attendeeSession = jsonSlurper.parseText(json_body);    
    def sessionID = 0;
   
    def messageLog = messageLogFactory.getMessageLog(message);
    
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    Date minStartTime, minEndTime, currentStartTime, currentEndTime;
    if(null != attendeeSession && attendeeSession.size() > 0) {
        attendeeSession.each{
            
            minStartTime = dateFormat.parse(it.startTime)
            minEndTime = dateFormat.parse(it.endTime)
            
            if((null == currentStartTime || null == currentEndTime)) {
                currentStartTime = dateFormat.parse(it.startTime);
                currentEndTime = dateFormat.parse(it.endTime);
                sessionID = it.sessionKey;
            }
//            else if(minStartTime.before(currentStartTime) && minEndTime.before(currentEndTime)) {
            else if(currentStartTime.before(minStartTime) && currentEndTime.before(minEndTime)) {                
                currentStartTime = minStartTime
                currentEndTime = minEndTime
                sessionID = it.sessionKey;
            }
        }
        def map = message.getHeaders();
        def id = map.get("externaleventid");
        def resourcePath = "/meetings/" + id + "/sessions/" + sessionID + "/attendees";
        messageLog.setStringProperty("Logging#1", "Session with minimum start time: " + sessionID);
        message.setProperty("sessionKey",sessionID);
        message.setProperty("resourcePath", resourcePath);      
        message.setProperty("noSessions","false");
        messageLog.setStringProperty("Logging#2", "Resource Path: " + resourcePath);
    }
    else {
        messageLog.setStringProperty("Logging#1", "No Sessions found");
        message.setProperty("noSessions","true");
    }
    return message;
}