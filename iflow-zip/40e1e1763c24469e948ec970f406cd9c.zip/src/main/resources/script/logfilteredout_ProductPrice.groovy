import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil;
import groovy.util.slurpersupport.NodeChild;

def Message processData(Message message) {
    /* This script is to log the Condition Records that are filtered out with no FSM company. */
	
    def body = message.getBody(java.lang.String)
    def query = new XmlSlurper().parseText(body)
    def messageLog = messageLogFactory.getMessageLog(message)
	
    query.SalesPricingConditionRecordReplicationBundleRequest.SalesPricingConditionRecord.each { price ->
            def conditionRecord = price.ConditionRecord.text()
            if (messageLog != null) {
                messageLog.addCustomHeaderProperty("FSMCompanyNotFoundForConditionRecord", conditionRecord)
            }
    }
    return message
}
