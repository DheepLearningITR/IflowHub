import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil

def Message processData(Message message) {
    /* This script merge custom company with regular company group messages */    
    def body = message.getBody(String)
    def parsedXml = new XmlParser().parseText(body)
    def propmap = message.getProperties(); 

    def srcparsedXml = new XmlParser().parseText(propmap.get("groupedMessage"))

    parsedXml.'n0:SalesPricingConditionRecordReplicationBundleRequest'.each { ppMessage ->
        srcparsedXml.append(ppMessage)
    }

    message.setBody(XmlUtil.serialize(srcparsedXml))
    return message
}