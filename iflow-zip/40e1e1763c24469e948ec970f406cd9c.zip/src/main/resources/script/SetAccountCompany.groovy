import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {


    return message;
}