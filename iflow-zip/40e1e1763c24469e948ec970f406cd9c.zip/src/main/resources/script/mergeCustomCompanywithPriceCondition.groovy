import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
//import groovy.util.XmlParser
//import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script is to merge the custom FSM company with incoming Price Condition*/    
    def body = message.getBody(String)
    def parsedXml = new XmlParser().parseText(body)
    def propmap = message.getProperties(); 

    def srcparsedXml = new XmlParser().parseText(propmap.get("customCompanyMessage"))

    parsedXml.'multimap:Message1'.SrvcMgmtFSMCompanyCstmLogic.SrvcMgmtFSMCompanyCstmLogic_Type.each { it ->
        def account = it.FSMAccount.text()
        def company = it.FSMCompany.text()

        srcparsedXml.'n0:SalesPricingConditionRecordReplicationBundleRequest'.each { ppRequest -> 
			if (ppRequest.@MultiCompanyGroup == 'CUSTOM') {
				ppRequest.SalesPricingConditionRecord.each { ppMessage ->                
                    def customCompany = new XmlParser().parseText("<FSMCustomCompany>${account}|${company}</FSMCustomCompany>")
					if (ppMessage.ConditionRecord.text().replaceFirst("^0*","") == it.SrvcMgmtFSMRplctnObjID.text()) {
						ppMessage.FSMMultiCompany[0].append(customCompany)
					}
				}
			}
		}
	}

    message.setBody(XmlUtil.serialize(srcparsedXml))
    return message
}

