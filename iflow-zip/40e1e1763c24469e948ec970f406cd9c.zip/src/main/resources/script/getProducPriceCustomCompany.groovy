import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.util.XmlParser
import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script gets Price Condition Object details for custom company determination */
    
    def body = message.getBody(String)
    def parsedXml = new XmlSlurper().parseText(body)
    def customObjects = new XmlParser().parseText("<CustomObjects></CustomObjects>")

    parsedXml.SalesPricingConditionRecordReplicationBundleRequest.each { ppRequest ->    
        //get the Price Condition details where Custom rule type is set at the object level
        if (ppRequest.@MultiCompanyGroup.text() in ['CUSTOM']) {
            ppRequest.SalesPricingConditionRecord.each { pp ->
                    def customObjectXml = buildCustomObjectXml(pp, pp, ppRequest.@MultiCompanyGroup.text())
                    def customObjectNode = new XmlParser().parseText(customObjectXml)
                    customObjects.append(customObjectNode)
            }
        }
    }

    message.setBody(XmlUtil.serialize(customObjects))
    return message
}

def String buildCustomObjectXml(pp, type, ruleType) {
    def builder = new StringBuilder()
    builder.append("<customObject>")
    builder.append("<SrvcMgmtFSMRplctnObjID>").append(pp.ConditionRecord.text().replaceFirst("^0*","")).append("</SrvcMgmtFSMRplctnObjID>")
    builder.append("<SrvcMgmtFSMReplicationObject>PP</SrvcMgmtFSMReplicationObject>")
    builder.append("<SrvcMgmtFSMRplctnObjAttribute></SrvcMgmtFSMRplctnObjAttribute><SrvcMgmtFSMRplctnObjAttribVal></SrvcMgmtFSMRplctnObjAttribVal>")
    
    builder.append("</customObject>")
    return builder.toString()
}
