import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import groovy.util.slurpersupport.NodeChild;

def Message processData(Message message){
    // To access FSM, company and account are required -- either their name or their ID.
    // If the IDs are configured, they are used; otherwise, the names are used.
        def body = message.getBody(java.lang.String);
        def query = new XmlSlurper().parseText(body)
        def FSMAccountCompany = query.@MultiCompanyGroup.text();
    
        if (FSMAccountCompany != null || FSMAccountCompany != ''){
            message.setProperty('X-Account-ID',FSMAccountCompany.split("\\|")[0]);
            message.setProperty('X-Company-ID',FSMAccountCompany.split("\\|")[1]);
            message.setProperty('OriginalPayload', body);
        }
    
    return message
}
