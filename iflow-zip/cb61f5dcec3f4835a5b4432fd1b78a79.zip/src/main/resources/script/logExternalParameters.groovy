import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	//Properties  
	def pmap = message.getProperties();
    def messageLog = messageLogFactory.getMessageLog(message);

    String replicationTargetSystem = pmap.get("REPLICATION_TARGET_SYSTEM");
    String enableLogging = pmap.get("ENABLE_LOGGING");
    String fullTransmissionStartDate = pmap.get("FULL_TRANSMISSION_START_DATE");
    String lastModifiedDate = pmap.get("LAST_MODIFIED_DATE");
    String company = pmap.get("COMPANY");
    String companyTerritoryCode = pmap.get("COMPANY_TERRITORY_CODE");
    String employeeClass = pmap.get("EMPLOYEE_CLASS");
    String contingentWorkers = pmap.get("CONTINGENT_WORKERS");
    String personIdExternal = pmap.get("PERSON_ID_EXTERNAL");
    String userId = pmap.get("USER_ID");
    String externalCostCenterIDUsage = pmap.get("EXTERNAL_COST_CENTER_ID_USAGE");
    String multipleJobEvents = pmap.get("MULTIPLE_JOB_EVENTS");
    String enableNotification = pmap.get("ENABLE_NOTIFICATION");
    String customMDFObjects = pmap.get("CUSTOM_MDF_OBJECTS");
    String processVariant = pmap.get("PROCESS_VARIANT");
    String userSetLastModifiedDateTime = pmap.get("USER_SET_LAST_MODIFIED_DATE_TIME");
    String pushURL = pmap.get("SFSF_EC_PUSH_URL");
    String enableTimeDependentEmployeeSelection = pmap.get("ENABLE_TIME_DEPENDENT_EMPLOYEE_SELECTION");
    String matchingEmploymentsOnly = pmap.get("MATCHING_EMPLOYMENTS_ONLY");
    String initiateFullLoad = pmap.get("INITIATE_FULL_LOAD");
    String proxyType = pmap.get("SAP_ERP_proxyType_2");
    String ERPEndpointURL = pmap.get("SAP_ERP_ENDPOINT_URL");
    
    //initialize user ID
    if(userId == null){
    	userId = "";
    	message.setProperty("USER_ID", userId);
    }
    
    if(personIdExternal == null){
       personIdExternal = ""; 
    }
    
    //mask user id and person id external if payload logging is not enabled 
    if(enableLogging != null && !enableLogging.toUpperCase().equals("TRUE")){
        if(!userId.equals("")){
            userId = "****";
        }
        if(!personIdExternal.equals("")){
            personIdExternal = "****";
        }
    }
    
    // Prepare string for MPL attachment content
 	String externalParameters;
 	externalParameters = "REPLICATION_TARGET_SYSTEM = " + replicationTargetSystem;
 	externalParameters = externalParameters + "\nENABLE_LOGGING = " + enableLogging;
 	externalParameters = externalParameters + "\nFULL_TRANSMISSION_START_DATE = " + fullTransmissionStartDate;
 	externalParameters = externalParameters + "\nCOMPANY = " + company;
 	externalParameters = externalParameters + "\nCOMPANY_TERRITORY_CODE = " + companyTerritoryCode;
 	externalParameters = externalParameters + "\nEMPLOYEE_CLASS = " + employeeClass;
 	externalParameters = externalParameters + "\nCONTINGENT_WORKERS = " + contingentWorkers;
 	externalParameters = externalParameters + "\nPERSON_ID_EXTERNAL = " + personIdExternal;
 	externalParameters = externalParameters + "\nUSER_ID = " + userId;
 	externalParameters = externalParameters + "\nEXTERNAL_COST_CENTER_ID_USAGE = " + externalCostCenterIDUsage;
 	externalParameters = externalParameters + "\nMULTIPLE_JOB_EVENTS = " + multipleJobEvents;
 	externalParameters = externalParameters + "\nENABLE_NOTIFICATION = " + enableNotification;
 	externalParameters = externalParameters + "\nCUSTOM_MDF_OBJECTS = " + customMDFObjects;
 	externalParameters = externalParameters + "\nPROCESS_VARIANT = " + processVariant;
 	externalParameters = externalParameters + "\nUSER_SET_LAST_MODIFIED_DATE_TIME = " + userSetLastModifiedDateTime;
 	externalParameters = externalParameters + "\nSFSF_EC_PUSH_URL = " + pushURL;
 	externalParameters = externalParameters + "\nENABLE_TIME_DEPENDENT_EMPLOYEE_SELECTION = " + enableTimeDependentEmployeeSelection;
 	externalParameters = externalParameters + "\nMATCHING_EMPLOYMENTS_ONLY = " + matchingEmploymentsOnly;
 	externalParameters = externalParameters + "\nINITIATE_FULL_LOAD = " + initiateFullLoad;
 	externalParameters = externalParameters + "\nPROXY_TYPE = " + proxyType;
 	externalParameters = externalParameters + "\nERP_ENDPOINT_URL = " + ERPEndpointURL;
 	
 	// Log parameters	
 	if (messageLog != null) {
 		messageLog.addAttachmentAsString("Externalized Parameters", externalParameters, "text/plain");
 	}
	
	return message;
}

