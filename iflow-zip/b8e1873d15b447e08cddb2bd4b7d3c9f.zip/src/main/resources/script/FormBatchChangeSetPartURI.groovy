import com.sap.it.api.mapping.*;

//This method forms the Contact Origin Data URI
def String customFunc(String arg1, String arg2){
	return "ContactOriginData(ContactID='"+arg1+"',ContactOrigin='"+arg2+"')";
}