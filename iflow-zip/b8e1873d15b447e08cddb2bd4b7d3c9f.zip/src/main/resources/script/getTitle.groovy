import com.sap.it.api.mapping.*;

def String getTitle(String title){
switch(title)
{
    case "ms":
        title = "0001";
        break;
     case "mr":
        title = "0002";
        break;
	case "miss":
        title = "0001";
        break;
	case "mrs":
        title = "0001";
        break;
     default:
            title = "";
            break;
}
	return title; 
}