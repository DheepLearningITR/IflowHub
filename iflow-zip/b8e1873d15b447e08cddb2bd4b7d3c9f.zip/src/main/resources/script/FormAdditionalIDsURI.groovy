import com.sap.it.api.mapping.*;

//This method forms the AdditionalIDs URI for the email
def String getEmailAdditionalIDsDtls(String contactID, String contactOrigin, String emailAddress){
    
	return "AdditionalIDs(ContactID='"+contactID+"',ContactOrigin='"+contactOrigin+"',ContactAdditionalOrigin='EMAIL',ContactAdditionalID='"+emailAddress+"')";
}

//This method forms the AdditionalIDs URI for the phone
def String getPhoneAdditionalIDsDtls(String contactID, String contactOrigin, String phone){
    
	return "AdditionalIDs(ContactID='"+contactID+"',ContactOrigin='"+contactOrigin+"',ContactAdditionalOrigin='PHONE',ContactAdditionalID='"+phone+"')";
}

//This method forms the AdditionalIDs URI for the mobile
def String getMobileAdditionalIDsDtls(String contactID, String contactOrigin, String mobile){
    
	return "AdditionalIDs(ContactID='"+contactID+"',ContactOrigin='"+contactOrigin+"',ContactAdditionalOrigin='MOBILE',ContactAdditionalID='"+mobile+"')";
}

//This method forms the ContactOriginDeleteAdditionalIDs URI
def String getContactOriginDeleteAdditionalIDs(String contactOrigin, String contactID){
    
	return "ContactOriginDeleteAdditionalIDs?ContactOrigin='"+contactOrigin+"'&ContactID='"+contactID+"'";
}