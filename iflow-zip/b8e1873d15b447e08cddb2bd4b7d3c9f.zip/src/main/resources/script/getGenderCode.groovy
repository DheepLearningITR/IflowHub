import com.sap.it.api.mapping.*;

//Get the Gender code by passing the Gender name.
def String customFunc(String genderCode){
switch(genderCode)
{
    case "MALE":
        genderCode = "1";
        break;
     case "FEMALE":
        genderCode = "2";
        break;
     default:
            genderCode = "";
            break;
}
	return genderCode; 
}