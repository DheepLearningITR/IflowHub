import com.sap.it.api.mapping.*;

def String getAdditionalOrigin(String emailAddress, String phone, String mobile){
    
    def additionalOrigin = ""
    
    if(emailAddress?.trim()){
        additionalOrigin = "EMAIL"
    }
    else if(phone?.trim()){
        additionalOrigin = "PHONE"
    }
    else if(mobile?.trim()){
        additionalOrigin = "MOBILE"
    }
    
	return additionalOrigin
}

def String getAdditionalID(String emailAddress, String phone, String mobile){
    
    def additionalID = ""
    
    if(emailAddress?.trim()){
        additionalID = emailAddress
    }
    else if(phone?.trim()){
        additionalID = phone
    }
    else if(mobile?.trim()){
        additionalID = mobile
    }
    
    return additionalID
}

