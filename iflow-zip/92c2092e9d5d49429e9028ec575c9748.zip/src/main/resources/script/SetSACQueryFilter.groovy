import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    
    String body = message.getBody(java.lang.String) as String
	def messageLog = messageLogFactory.getMessageLog(message)
	HashMap propertyMap = message.getProperties()
	String logMPLAttachment = propertyMap.get("p04_MPL_Log_Switch")

	//Read extension params
	String companyCode = propertyMap.get("p01_SAP_ALL_COMPANY_CODE")
	String jobClassification = propertyMap.get("p02_SAP_HR_USER_JOBCLASSIFICATION")
	String hrPosition = propertyMap.get("p03_SAP_HR_POSITION")

	//Variables
	StringBuffer sacQueryFilter = new StringBuffer()
		
	//Set static query filters
	sacQueryFilter.append("Version eq 'public.Detailed_Plan' and Audit eq 'MANUAL' and Plan_Level eq 'PL4' and SAP_HR_USER_EMPLOYEE eq '#' and SAP_HR_COSTTYPE eq '#'")
    
    /** Set dynamic quey filters */
    if(!companyCode.trim().isEmpty() && (!companyCode.trim().startsWith("<<") || !companyCode.trim().endsWith(">>"))) {
    	sacQueryFilter.append(" and SAP_ALL_COMPANY_CODE eq '" + companyCode + "'")
    }    
    
    if(!jobClassification.trim().isEmpty() && (!jobClassification.trim().startsWith("<<") || !jobClassification.trim().endsWith(">>"))) {
    	sacQueryFilter.append(" and SAP_HR_USER_JOBCLASSIFICATION eq '" + jobClassification + "'")
    }
    
    if(!hrPosition.trim().isEmpty() && (!hrPosition.trim().startsWith("<<") || !hrPosition.trim().endsWith(">>"))) {
    	sacQueryFilter.append(" and SAP_HR_POSITION eq '" + hrPosition + "'")
    }	

	/** Log and set SAC OData Query filter to a property */
	messageLog.addAttachmentAsString("SAC OData Main Query Filter = ", sacQueryFilter.toString(), "text/xml")
	message.setProperty("SACMainQueryFilter", sacQueryFilter.toString())  
	
	return message
}