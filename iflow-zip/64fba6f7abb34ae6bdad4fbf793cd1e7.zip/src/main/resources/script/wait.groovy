import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    sleep(500); 
    return message; 
}