
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper; 


def Message processData(Message message) {
    
    def properties = message.getProperties(); 
    
     def jsonbody = message.getBody(java.io.Reader); 
    // def jsonSlurper = new JsonSlurper()
    def response = new JsonSlurper().parse(jsonbody); 
    def results = response.d.results; 
    
    def inname = properties.get("aname"); 
    def inpackageid = properties.get("apackageid"); 
    def ihttpmethod = properties.get("ahttpmethod"); 
    
        
    def packageid = ""; 
    def vmname = "";
    def vmid = ""; 
    def action = "create"; 
    def vmversion = '1.0.0'; 
    def newVersion = '1.0.0';  
    def sflag = false; 
    
    
   
   // could take filter in consideration 
    for (item in results) {
       if (!sflag) {
        packageid = item.PackageId.toString(); 
        vmname =  item.Name.toString();
        vmid = item.Id.toString();
        vmversion = item.Version.toString();
       
        if (inname.toUpperCase().equals(vmname.toUpperCase())) {
            action = "update"; 
            sflag = true; 
            break; 
        }
     
        packageid = "";
        vmname = "";
        vmid = ""; 
        vmversion = "";
        
       }
    }
    
    
    switch(action){
        case "update":
           
           try{
            def parts = vmversion.split('\\.');
            def major = parts[0];
            def minor = parts[1];
            def patch = parts[2];
            patch = patch.toInteger() + 1;
            newVersion = major + '.' + minor + '.' + patch;
           } catch (Exception ex) {
                def messageLog = messageLogFactory.getMessageLog(message)
                    if (messageLog != null) {
                        messageLog.addCustomHeaderProperty("Additional information:", "VM found but in Draft Mode"); 
                        message.setProperty("acancel","true");
                    }
                return message; 
           }
            break; 
        default: 
            packageid = inpackageid; 
            vmid = inname;
            vmversion = '1.0.0';
            break; 
    }

    
    message.setProperty("aaction",action);
    message.setProperty("aname",inname);
    message.setProperty("apackageid",inpackageid);
    message.setProperty("avmversion",vmversion); 
    message.setProperty("avmnewversion",newVersion); 
    message.setProperty("avmid",vmid);
    

    return message;
}