
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;
import groovy.util.*
import java.util.zip.*
import javax.xml.*
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import java.security.MessageDigest; 



def Message processData(Message message) {
   def properties = message.getProperties(); 
   def inname = properties.get("aname"); 
   def inpayload = properties.get("payload"); 
  
   def vm_name = inname; 

   def filesToBeWritten = ["META-INF/MANIFEST.MF", ".project", "metainfo.prop","value_mapping.xml"];
   
   String manifest = "Manifest-Version: 1.0\n" +
                     "Bundle-SymbolicName: " +vm_name+"; singleton:=true\n"+
                     "Bundle-Name: "+vm_name+"\n"+
                     "Bundle-Version: 1.0.0\n"+
                     "Bundle-ManifestVersion: 2\n"+
                     "Bundle-Activator: com.sap.xi.mapping.camel.valmap.ValueMappingActivato\n r\n"+
                     "SAP-ArtifactTrait: \n"+
                     "SAP-NodeType: IFLMAP\n"+
                     "Import-Package: com.sap.xi.mapping.camel.valmap\n"+
                     "SAP-BundleType: ValueMapping\n"+
                     "Import-Service: "; 

    String metainfo = "#Store metainfo properties\n"+
                      "#Mon Feb 27 14:10:05 UTC 2023\n"+ 
                      "description=\\\n"+
                      "source=sender"+
                      "target=receiver"; 

// create Projectinfo XML
    def projectinfo = new Node(null, 'projectDescription');
    new Node(projectinfo,'name',vm_name)
    new Node(projectinfo,'comment','')
    new Node(projectinfo,'projects','')
    
    buildSpec = new Node(projectinfo,'buildSpec')
        buildCommand = new Node(buildSpec,'buildCommand')
            new Node(buildCommand,'name','org.eclipse.jdt.core.javabuilder')
            new Node(buildCommand,'arguments','')
    natures = new Node(projectinfo,'natures')
        new Node(natures,'nature','org.eclipse.jdt.core.javanature')
        new Node(natures,'nature','com.sap.ide.ifl.project.support.project.nature')
        new Node(natures,'nature','com.sap.ide.ifl.valmap')
// create Projectinfo XML

// create XML based on dynamic input 
    def value_mapping = new Node(null, 'vm',[version:'2.0']);
    def request = new XmlSlurper().parseText(inpayload); 
    def hash = "";
    def val = ""; 
    def list = []; 
    
    
   for(item in request.items) {
    for (item1 in item.items) {
       val = item.sourceagency.toString()+item.sourceidentifier.toString()+item1.source.toString()+item.targetagency.toString()+item.targetidentifier.toString()+item1.target.toString(); 
       hash =   MessageDigest.getInstance("MD5").digest(val.bytes).encodeHex().toString(); 
       group = new Node(value_mapping,'group',[id:hash]);

      senderentry = new Node(group,'entry')
      new Node(senderentry,'agency',item.sourceagency.toString())
      new Node(senderentry,'schema',item.sourceidentifier.toString())
      new Node(senderentry,'value',item1.source.toString())
        
      receiverentry = new Node(group,'entry')
      new Node(receiverentry,'agency',item.targetagency.toString())
      new Node(receiverentry,'schema',item.targetidentifier.toString())
      new Node(receiverentry,'value',item1.target.toString())
     }
    }
   
    // group = new Node(value_mapping,'group',[id:'b1045d5e0e3cf8ef3fe22c92120880a1']);
    //     senderentry = new Node(group,'entry')
    //     new Node(senderentry,'agency','SenderAgency')
    //     new Node(senderentry,'schema','Attribute1')
    //     new Node(senderentry,'value','Value1')
        
    //     receiverentry = new Node(group,'entry')
    //     new Node(receiverentry,'agency','ReceiverAgency')
    //     new Node(receiverentry,'schema','Attribute1')
    //     new Node(receiverentry,'value','Value1')
// after xml is finished save to byte array 
//  xml = groovy.xml.XmlUtil.serialize(value_mapping); 

  
// create Zipfile   
   byte[] bytestream = new byte[1024];
   ByteArrayOutputStream zipBytes = new ByteArrayOutputStream()
   ZipOutputStream zipFile = new ZipOutputStream(zipBytes)  
  
    filesToBeWritten.eachWithIndex{ it, i -> 
       try {
        ZipEntry zipEntry = new ZipEntry(it);
        zipFile.putNextEntry(zipEntry);
        switch(it) {
                case "META-INF/MANIFEST.MF":
                    bytestream = manifest; 
                    break; 
               case ".project":
                   bytestream = groovy.xml.XmlUtil.serialize(projectinfo);   
                    break;
               case "metainfo.prop":
                    bytestream = metainfo; 
                    break;
               case "value_mapping.xml":
                    bytestream = groovy.xml.XmlUtil.serialize(value_mapping);    
                    break;
                }
        }
           catch(Exception ex) {
           //   be happy 
       }
         zipFile.write(bytestream);
         zipFile.closeEntry();  
    }
      
    zipFile.close();
    message.setBody(zipBytes.toByteArray());
    // message.setProperty("aList",list); 
    return message;

}