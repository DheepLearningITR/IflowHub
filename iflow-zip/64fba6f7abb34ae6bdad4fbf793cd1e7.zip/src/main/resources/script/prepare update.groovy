
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;
import groovy.util.*;

def Message processData(Message message) {
  def properties = message.getProperties();
  def inpayload = properties.get("payload"); 
  def inurl = properties.get("ENV_URL"); 
  def vmid = properties.get("avmid"); 

  def request = new XmlSlurper().parseText(inpayload); 
  def val = "";
  def upload = new Node(null, 'payload');

  for(item in request.items) {
    for (item1 in item.items) {
         val = inurl+'/api/v1/UpsertValMaps?Id=%27'+vmid+
         '%27&Version=%27active%27&SrcAgency=%27'+item.sourceagency.toString()+
         '%27&SrcId=%27'+item.sourceidentifier.toString()+
         '%27&TgtAgency=%27'+item.targetagency.toString()+
         '%27&TgtId=%27'+item.targetidentifier.toString()+
         '%27&SrcValue=%27'+item1.source.toString()+
         '%27&TgtValue=%27'+item1.target.toString()+'%27&IsConfigured=false'; 
       new Node(upload,'url',val); 
     }
    }
  
  xml = groovy.xml.XmlUtil.serialize(upload); 
  
  message.setBody(xml);
  return message;
}