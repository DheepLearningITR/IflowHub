
import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.json.JsonSlurper
import groovy.json.JsonOutput


def Message formatNames(Message message) {
    def body = message.getBody(String.class)?:""
    
    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)
    
    
    def names = [:]
    
    json.ProdUnivHierNodeByHierIDType?.each {
        currentNode ->
            
            
            names.put(currentNode?.HierarchyNode,currentNode?.ProdUnivHierarchyNode)
    
        
    }
    
    def result = [names: names]

    result = JsonOutput.prettyPrint(JsonOutput.toJson(result))?.trim()
    
    message.setBody(result)
    return message
    
}



def Message joinMetadataDesc(Message message){
    
    String hierarchies = message.getProperty("hierarchies")
    String hierarchiesDesc = message.getProperty("hierarchiesDesc")
    
    def body = message.getBody(String.class)?:""
    
    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)
    
    def metadata = hierarchies?.split(",")
    def desc = hierarchiesDesc?.split(",")
    
    if (!metadata){
        metadata = []
    }
    
    if (!desc){
        desc = []
    }
    
    def names = []
    metadata.each{it -> 
        
        names.add(json.names.get(it)?:it)
    }
    
    def result = []
    if (metadata.size() == desc.size() && metadata && desc){
        result = [metadata, names, desc].transpose()
    } else if (metadata)  {
        result = [metadata, names, metadata].transpose()
    } else {
        result = []
    }
    
    message.setProperty("hierarchyStructures", result.flatten().join(","))
    message.setBody("")

    return message
}



def Message append(Message message) {
    
    def currentNode = message.getProperty("currentNode")
    def currentNodeDesc = message.getProperty("currentNodeDesc")
    def hierarchies = message.getProperty("hierarchies")
    def hierarchiesDesc = message.getProperty("hierarchiesDesc")
    
    if ("empty".equals(hierarchies)){
        hierarchies = currentNode
    } else {
        hierarchies = currentNode + "," + hierarchies
    }
    
    if ("empty".equals(hierarchiesDesc)){
        hierarchiesDesc = currentNodeDesc
    } else {
        hierarchiesDesc = currentNodeDesc + "," + hierarchiesDesc 
    }
   
    message.setProperty("hierarchies", hierarchies)
    message.setProperty("hierarchiesDesc", hierarchiesDesc)
    
    return message;
}