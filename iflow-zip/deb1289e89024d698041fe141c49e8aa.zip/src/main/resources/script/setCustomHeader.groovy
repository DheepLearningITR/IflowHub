/*==============================================================================
This Script Reads Ids from input body and set them as custom Headers 
================================================================================
*/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.*;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) 
{
    def messageLog = messageLogFactory.getMessageLog(message);
    def body = message.getBody(java.lang.String) as String;

    if(messageLog != null)
    {
        def doc = new XmlSlurper().parseText(body);
        String Ids = ""; 

        // Loop over all <records> elements in the parent node
        doc.records.each { record ->

            // Extract 'Unique Id' and append it to 'Ids'
            def purchaseRequisitionId = record.PurchaseRequisitionId.text();
            if (purchaseRequisitionId) {
                Ids += purchaseRequisitionId + "\n";
            }

            def purchaseRequisitionLineItemId = record.PurchaseRequisitionLineItemId?.text();
            if (purchaseRequisitionLineItemId) {
                Ids += purchaseRequisitionLineItemId + "\n";
            }

            def approvalId = record.ApprovalId?.text();
            if (approvalId) {
                Ids += approvalId + "\n";
            }

            def purchaseOrderId = record.PurchaseOrderId?.text();
            if (purchaseOrderId) {
                Ids += purchaseOrderId + "\n";
            }

            def purchaseOrderLineItemId = record.PurchaseOrderLineItemId?.text();
            if (purchaseOrderLineItemId) {
                Ids += purchaseOrderLineItemId + "\n";
            }

            def goodsReceiptId = record.GoodsReceiptId?.text();
            if (goodsReceiptId) {
                Ids += goodsReceiptId + "\n";
            }

            def goodsReceiptLineItemId = record.GoodsReceiptLineItemId?.text();
            if (goodsReceiptLineItemId) {
                Ids += goodsReceiptLineItemId + "\n";
            }

            def invoiceId = record.InvoiceId?.text();
            if (invoiceId) {
                Ids += invoiceId + "\n";
            }

            def invoiceLineItemId = record.InvoiceLineItemId?.text();
            if (invoiceLineItemId) {
                Ids += invoiceLineItemId + "\n";
            }

            def userId = record.UserId?.text();
            if (userId) {
                Ids += userId + "\n";
            }

            def materialId = record.MaterialId?.text();
            if (materialId) {
                Ids += materialId + "\n";
            }
            
        }

        // Add the collected Ids as a custom header
        messageLog.addCustomHeaderProperty("Ids", Ids.trim());
    }

    return message;
}
