import com.sap.it.api.mapping.*;


def String getexternalSalesDocumentId(String P1,MappingContext context){
	return context.getHeader("externalSalesDocumentId");
}