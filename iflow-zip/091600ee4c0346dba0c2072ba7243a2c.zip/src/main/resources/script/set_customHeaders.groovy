import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def compCode = message.getProperties().get("compExtCode");
		if(compCode != null){
			messageLog.addCustomHeaderProperty("sfsf_competencyExtCode", compCode);		
        }
        def roleExtCode = message.getProperties().get("roleExtCode");
		if(roleExtCode != null){
			messageLog.addCustomHeaderProperty("sfsf_roleExtCode", roleExtCode);		
        }
	}
	return message;
}

def Message mappingCode(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
		def mapCode = message.getProperties().get("roleCompExtCode");
		if(mapCode!=null){
			messageLog.addCustomHeaderProperty("sfsf_roleCompExtCode", mapCode);		
        }
	}
	return message;
}