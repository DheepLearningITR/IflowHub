import com.sap.gateway.ip.core.customdev.util.Message;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import groovy.transform.Field;

@Field final List<String> SALES_ARRAY_FIELDS = ["billingDocs", "materialDocs", "logItems"].asImmutable();
@Field final List<String> FINANCIAL_ARRAY_FIELDS = ["confirmation", "logItems"].asImmutable();

def Message fixSalesArrayFields(Message message) throws IOException {
    def body = message.getBody(java.lang.String) as String;
    def fixedJson = fixJson(body, SALES_ARRAY_FIELDS);
    message.setBody(fixedJson);
    return message;
}

def Message fixFinancialArrayFields(Message message) throws IOException {
    def body = message.getBody(java.lang.String) as String;
    def fixedJson = fixJson(body, FINANCIAL_ARRAY_FIELDS);
    message.setBody(fixedJson);
    return message;
}

def String fixJson(String element, List<String> fields) throws IOException {
    ObjectMapper mapper = new ObjectMapper();
    JsonNode rootNode = mapper.readTree(element);

    for(String field : fields) {
        change(rootNode, field);
    }

    return rootNode.toString();
}

def void change(JsonNode parent, fieldName) {
    if (parent.has(fieldName) && !parent.get(fieldName).isArray()) {
        JsonNode old = parent.get(fieldName);
        parent.putArray(fieldName).add(old);
    }

    for (JsonNode child : parent) {
        change(child, fieldName);
    }
}