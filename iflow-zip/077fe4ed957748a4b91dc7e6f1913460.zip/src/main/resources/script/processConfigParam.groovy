import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory; 
import com.sap.it.api.securestore.SecureStoreService; 
import com.sap.it.api.securestore.UserCredential; 
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.*;


def Message processConfigParam(Message msg) {
    //set FromDate ToDate
    
    def map = msg.getProperties()
    String periodStr = map.get("Period")
    String fromDateStr = map.get("FromDate")
    String toDateStr = map.get("ToDate")
    String registry = map.get("SearchComRegNoSet")
    String enableAttachments = map.get("EnableAttachments")
    
    Map<String, String> tranDate = new HashMap<>()
    msg.setProperty("tranDate", tranDate)
    
    String fromParam
    String toParam
        
    if (fromDateStr != "" && toDateStr != "") {
        fromParam = fromDateStr
        toParam = toDateStr
    } else {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd")
        Calendar calendar = Calendar.getInstance()
        Date from, to
        Integer period = periodStr == "" ? 30 : Integer.valueOf(periodStr)
        if (period <= 0)
            period = 30
            
        if(fromDateStr != "") {
            from = dateFormat.parse(fromDateStr)
            calendar.setTime(from)
            calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + period - 1)
            to = calendar.getTime()
        } else {
            to = toDateStr == "" ? new Date() : dateFormat.parse(toDateStr)
            calendar.setTime(to)    
            calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) - period + 1)
            from = calendar.getTime()
        }
        fromParam = dateFormat.format(from).toString()
        toParam = dateFormat.format(to).toString()
    }

    msg.setProperty("ToDate", toParam)
    msg.setProperty("FromDate", fromParam)
    
    
    //set RegNo AuthToken Type
    String sendComRegNo = msg.getProperties().get('SendComRegNo') as String
    def secureService = ITApiFactory.getApi(SecureStoreService.class, null); 
    String CredentialName = "edoc_kr_smartbill_token_" + sendComRegNo;
    def credential = secureService.getUserCredential(CredentialName); 
    if (credential == null) { throw new IllegalStateException("No credential found for alias" + CredentialName ); }
    String token = new String(credential.getPassword());
    msg.setProperty("AuthToken", token)

    String[] regNoSet = registry.split("[^0-9]+")
    StringBuilder sbuilder = new StringBuilder()
    sbuilder.delete(0, sbuilder.length())
    sbuilder.append("<items>")

    for(String regNo : regNoSet) {
        sbuilder.append("<item>").append("<RegNo>").append(regNo).append("</RegNo>").append('<Type>').append('AR').append('</Type>').append("</item>")
        sbuilder.append("<item>").append("<RegNo>").append(regNo).append("</RegNo>").append('<Type>').append('AP').append('</Type>').append("</item>")
    }
    sbuilder.append("</items>")
    msg.setBody(sbuilder.toString())
    return msg 
}