import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.*;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    Map<String, String> tranDate = message.getProperties().get('tranDate')
    StringBuilder builder = new StringBuilder()
    String enableLog = message.getProperties().get('EnableAttachment') as String
    def jsonSlurper = new JsonSlurper()
    def map = jsonSlurper.parseText(body)
    def list = map['ResultDataSet']['Table']
    def counter = 0
    builder.append('<group>')
    for(item in list) {
        if(counter == 100){
            builder.append('</group>/n<group>')
            counter = 0
        }
        counter++
        builder.append('<i>').append(item['ISSUE_ID']).append('</i>')
        tranDate.put(item['ISSUE_ID'], item['DTI_SDATE'])
    }
    builder.append('</group>')
    
    message.setBody(builder.toString())
    def messageLog = messageLogFactory.getMessageLog(message);
    if(enableLog == 'X' && messageLog != null)
	{
	    //messageLog.addAttachmentAsString("IssueID Groups", builder.toString(), "application/xml");
    }
    return message;
}