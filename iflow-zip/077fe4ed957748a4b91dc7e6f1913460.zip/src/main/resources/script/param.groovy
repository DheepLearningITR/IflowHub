import com.sap.gateway.ip.core.customdev.util.Message;



def Message genIssueIDS(Message message) {
    def body = message.getBody()
    String log = message.getProperties().get("EnableAttachment") as String;
    String[] res = body.split("<\\D+>")
    StringBuilder builder = new StringBuilder()
    builder.append('[')
    for(int i = 1; i < res.length; i++) {
        builder.append('"').append(res[i]).append('"')
        if(i < res.length -1)
            builder.append(',') 
    }
    builder.append(']')
    message.setProperty("IssueIDs", builder.toString())
    
    def messageLog = messageLogFactory.getMessageLog(message);
    if(log.equals("X") && messageLog != null)
	{
	    //messageLog.addAttachmentAsString("IssueIDs", builder.toString(), "text/plain");
    }
    return message;
}

