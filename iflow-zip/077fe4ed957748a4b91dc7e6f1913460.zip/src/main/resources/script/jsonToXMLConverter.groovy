import groovy.json.JsonSlurper;
import com.sap.gateway.ip.core.customdev.util.Message;


def Message convert(Message msg) {
    String jsonStr = msg.getBody(java.lang.String) as String
    String enableLog = msg.getProperties().get("EnableAttachment") as String
    def messageLog = messageLogFactory.getMessageLog(msg);
    if(enableLog == 'X' && messageLog != null) {
	    //messageLog.addAttachmentAsString("json", jsonStr, "application/json")
    }
    String xmlStr = jsonToXmlConverter(jsonStr, msg)
    msg.setBody(xmlStr)
    if(enableLog == 'X' && messageLog != null) {
	    //messageLog.addAttachmentAsString("xml", xmlStr, "application/xml")
    }
    return msg
}


String jsonToXmlConverter(String str, Message msg) {
    def addPreTag = {
        StringBuilder buf, String key ->
            buf.append("<")
            buf.append(key)
            buf.append(">")

    }
    def addPostTag = {
        StringBuilder buf, String key ->
            buf.append("</")
            buf.append(key)
            buf.append(">\n ")
    }
    def jsonSlurper = new JsonSlurper()
    Map map = (Map)jsonSlurper.parseText(str)
    def builder = new StringBuilder()
    builder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
    private_converter(msg, map, builder, addPreTag, addPostTag)
    return builder.toString()
}


def private_converter(Message msg, Map map, StringBuilder buf, def addPreTag, def addPostTag) {
    def keys = map.keySet().toList();
    char[] date  = null
    String issueid = null
    for (key in keys) {    //walk through every key-value pair of the json formatted string
        def val = map[key]
        if (val instanceof List) { //if the value is a list, then for each item of the list, append the XML with the string like "<key>item</key>"
            if(val.size() == 0 ) {
                addPreTag.call(buf, key)
                addPostTag.call(buf, key)
                continue
            }
            for (piece in val) {
                addPreTag.call(buf, key)
                if (piece instanceof Map) {
                    private_converter(msg,piece, buf, addPreTag, addPostTag)
                } else {
                    buf.append(piece)
                }
                addPostTag.call(buf, key)
            }
        } else {
            addPreTag.call(buf, key)
            if (val instanceof Map) {
                private_converter(msg, val, buf, addPreTag, addPostTag)
            } else if(key == 'ISSUE_ID') { //enhancement for transfer date
                issue_id = val
                buf.append(val)
            } else if (key == "DTI_MSG"){
                String invoice = (val =~ /^<\?xml.*\?>([\S\s]*)/)[0][1]  //remove the XML header
                String encoded = invoice.getBytes("UTF-8").encodeBase64().toString()
                buf.append(encoded)
            }  else {
                buf.append(val)
            }
            addPostTag.call(buf, key)
            if(key ==  'ISSUE_ID') {
                Map<String, String> tranDate = msg.getProperties().get("tranDate") as HashMap<String, String>
                String dateStr = tranDate.get(issue_id)
                if(date == null)
                    date = new char[8]
                int j = 0
                for(int i = 0; i < 10; i++) {
                    if(i == 4 || i == 7)
                        continue
                    date[j++] = dateStr.charAt(i)
                }
                buf.append('<DTI_SDATE>').append(String.valueOf(date)).append("</DTI_SDATE>")
            }
        }
    }
}