import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

def Message processData(Message message) 
{
	def properties = message.getProperties();
	String type = properties.get("Type") as String;
	def log = properties.get('EnableAttachment') as String;
	String fileName = properties.get("FileName") as String;
	Map<String, String> record = properties.get("Record") as Map<String,String>;
// 	if(type.equals(record.get(fileName))) {
// 	    message.setProperty("NewInvoice","false");
// 	} else {
// 	    message.setProperty("NewInvoice","true");
// 	    record.put(fileName, type);
// 	}
	
	def comRegNo = properties.get("SearchComRegNo") as String;
	String dataStore = "OS_" + ( type.equals("AP")? "AP_" : "AR_" ) + comRegNo;
	message.setProperty("DataStore", dataStore);

	if(log.equals("X")) {
	    logData(message, fileName);
	}

	return message;
} 

def Message logData(Message message,String fileName) {
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null)
	{
	    //messageLog.addAttachmentAsString(fileName, body, "application/xml");
    }
    return message;
}