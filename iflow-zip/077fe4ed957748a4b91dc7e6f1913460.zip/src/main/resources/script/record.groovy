import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;
import java.io.*;
import java.util.concurrent.ConcurrentHashMap;

def Message readRecord(Message message) 
{
    String body = message.getBody(java.lang.String) as String;
    //logData(body, message)
    Map<String, String> record;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(body == null || body.length() == 0) {
        record = new ConcurrentHashMap<>();
    } else {
        record = (Map<String, String>) deSerialize(body);
    }
    message.setProperty("Record", record);
    return message;
        
} 

def Message writeBack(Message message) {
    def map = message.getProperties()
    String str = serialize(map.get("Record"))
    message.setBody(str)
    //logData(str, message)
    return message;
}

def Object deSerialize(String str) throws Exception {
    ByteArrayInputStream byteIn = new ByteArrayInputStream(str.getBytes("ISO-8859-1"));
    ObjectInputStream objIn = new ObjectInputStream(byteIn);
    Object obj =objIn.readObject();
    return obj;
}

def String serialize(Object obj) throws Exception {
    ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
    ObjectOutputStream objOut = new ObjectOutputStream(byteOut);
    objOut.writeObject(obj);
    String str = byteOut.toString("ISO-8859-1");
    return str;
}

def Message logData(String str, Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def enableLog = message.getProperties().get('EnableAttachment') as String
    if(enableLog == 'X' && messageLog != null)
	{
	    messageLog.addAttachmentAsString("LoadfromDB_hashset", str, "text/plain");
    }
    return message;
}