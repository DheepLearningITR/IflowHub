import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.xml.XmlUtil;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

def Message prepareSOAPRequest(Message message) {
  def properties = message.getProperties()
  def languagesList = properties.get("Language")
  def dimensionsList = properties.get("UnitOfMeasureDimensions")

  def languagesXml = languagesList ? "<IT_LANGUAGES>${languagesList.split(',').collect { "<item>${it}</item>" }.join()}</IT_LANGUAGES>" : ""
  def dimensionsXml = dimensionsList ? "<IT_DIMENSIONS>${dimensionsList.split(',').collect { "<item>${it}</item>" }.join()}</IT_DIMENSIONS>" : ""

        def xml = """
<urn:COD_GET_UNIT_OF_MEASURES xmlns:urn="urn:sap-com:document:sap:rfc:functions">
    ${languagesXml}
    ${dimensionsXml}
</urn:COD_GET_UNIT_OF_MEASURES>
"""

  def resultXml = XmlUtil.serialize(xml)
  message.setBody(resultXml)
  return message;
}

def Message enrichJsonOutputAndSplitIntoChunks(Message message) {
  //Body 
  def body = message.getBody(java.io.Reader);

  JsonSlurper slurper = new JsonSlurper()
  Map parsedJson = slurper.parse(body)

  parsedJson.messageRequests.each {

    // Convert string to boolean or integer 
    it.body.isInternationalSystemUnit = Boolean.parseBoolean(it.body.isInternationalSystemUnit)
    
    it.body.numberOfDecimals = Integer.parseInt(it.body.numberOfDecimals)
    
    it.body.numerator = Integer.parseInt(it.body.numerator)
    
    it.body.numeratorExponent10 = Integer.parseInt(it.body.numeratorExponent10)
    
    it.body.denominator = Integer.parseInt(it.body.denominator)
    
    it.body.offset = Double.parseDouble(it.body.offset)
  }

  //Split into chunks of 100
  def messageRequests = parsedJson.messageRequests
  def chunkSize = 100
  def chunks = messageRequests.collate(chunkSize)

  // Wrap chunks inside a new JSON array
  def outputJsonArray = []
  chunks.each {
    chunk ->

      def chunkJson = [
        messageHeader: parsedJson.messageHeader,
        messageRequests: chunk
      ]

    outputJsonArray << chunkJson
  }

  // Convert to JSON
  def bundledJson = [bundledJson: outputJsonArray]
  def responseBody = JsonOutput.toJson(bundledJson)

  message.setBody(responseBody)

  return message;
}


def Message prepareResponseMessage(Message message) {

  def body = message.getBody(java.io.Reader)
  def responsePayload = new JsonSlurper().parse(body).bundledJson

  responsePayload.messageRequests.each { request ->
    def requestBody = request.body
    requestBody.numberOfDecimals = requestBody.numberOfDecimals.toInteger()
    requestBody.numerator = requestBody.numerator.toInteger()
    requestBody.isInternationalSystemUnit = requestBody.isInternationalSystemUnit.toBoolean()
    requestBody.numeratorExponent10 = requestBody.numeratorExponent10.toInteger()
    requestBody.denominator = requestBody.denominator.toInteger()
    requestBody.offset = requestBody.offset.toBigDecimal() // or toInteger() if offset is always a whole number
}

  responsePayload.messageHeader.id = UUID.randomUUID().toString()
  responsePayload.messageHeader.creationDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))

  def enrichedResponsePayload = JsonOutput.toJson(responsePayload)

  message.setBody(enrichedResponsePayload)
  return message
}
