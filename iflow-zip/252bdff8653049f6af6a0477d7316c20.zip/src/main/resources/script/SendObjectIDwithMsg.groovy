import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
     //Get Body and parse it.
       def body = message.getBody(java.lang.String)as String;
       def parsedBody = new JsonSlurper().parseText(body);
       def msg = "Response has been successfully mapped with Object ID ";
       def finalMsg;
       
        if(parsedBody.d.results != null){
          finalMsg = msg + parsedBody.d.results.ObjectID;
        }else{
           finalMsg = body;
        }
        
        message.setBody(finalMsg);
        return message;
       
}