import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def parsedObj = new JsonSlurper().parseText(body);
	def finalObj = new JsonSlurper().parseText('{}');
	
	//Creating Origin Payload Exchange Property for Extension
	JsonBuilder builderA = new JsonBuilder(parsedObj);
	message.setProperty("originPayload",JsonOutput.prettyPrint(builderA.toString()));
	
	String filterString;
	String FinalString;
	
	parsedObj.each{
	    //Creating Exchange Property called endpoint
	    if(it.getKey() == "endPoint"){
	        message.setProperty("endpoint",it.getValue());
	    }
	    
	   //Creating Exchange Property called action 
	   if(it.getKey() == "actionCode"){
	        message.setProperty("actionCode",it.getValue());
	    }
	   
	   //Creating Exhange Property called payLoad for Update Case
	   if(it.getKey() == "payLoad"){
	       
	       def tempPayload = new JsonSlurper().parseText('{}');
	       tempPayload << it.getValue();
	       
	       JsonBuilder builder = new JsonBuilder(tempPayload);
           String convPayload = JsonOutput.prettyPrint(builder.toString());
	        message.setProperty("payLoad",convPayload);    
	   }
	   
	   //Creating Exhange Property called Key fields for Update Case
	   if(it.getKey() == "keyFields"){
	       it.getValue().each{
                if(filterString == null){
                    filterString =  it.getKey() + ' eq ' + "'" + it.getValue() + "'" + ' and '
                }else{
                    filterString = filterString + it.getKey() + ' eq ' + "'" + it.getValue() + "'" + ' and '
                }
            }
            
            if(filterString != null){
                FinalString = filterString.substring(0,filterString.lastIndexOf(" and "))
            }
            
	        message.setProperty("keyFilterString",FinalString);
	    }
	}
	finalObj <<[parsedObj.payLoad];

	JsonBuilder builder = new JsonBuilder(finalObj);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
    message.setBody(jsonBody);
	
	return message;
	
}