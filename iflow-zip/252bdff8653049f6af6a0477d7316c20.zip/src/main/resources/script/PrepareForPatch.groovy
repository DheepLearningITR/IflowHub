import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def parsedBody = new JsonSlurper().parseText(body);
	String ObjectID;
	
	// Reading the Property
    def map = message.getProperties();
    String payload = map.get('payLoad') as String;
    def FinalPayload = new JsonSlurper().parseText(payload);	
    
	if(parsedBody.d.results.size()){
	    parsedBody.d.results.each{
            it.remove('__metadata');
            if(ObjectID == null){
                ObjectID = it.ObjectID;
            }
        }
        message.setProperty("patchObjectID",ObjectID);
	}else{
	    // No Record found
         message.setProperty("patchObjectID",'');
	}
    
    JsonBuilder builder = new JsonBuilder(FinalPayload);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
    message.setBody(jsonBody);
	return message;
}