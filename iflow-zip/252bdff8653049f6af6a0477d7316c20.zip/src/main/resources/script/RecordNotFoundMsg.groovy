import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
     //Get Body and parse it.
       def body = message.getBody(java.lang.String)as String;
       def parsedBody = new JsonSlurper().parseText(body);
	   
	//Reading the Exchange properties
	   def map = message.getProperties();
	   String keyValues = map.get('keyFilterString') as String;
	   
	   def msg = "Survey Response update could not be performed as there is no record found for the key values " + keyValues 
		
       message.setBody(msg);
       return message;
       
}