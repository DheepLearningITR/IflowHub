import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {

   // Reading the Property
    // def map = message.getProperties();
    // String ObjectID = map.get('patchObjectID') as String;
    
    def msg = "Survey response has been successfully updated"; // to Object ID" + ObjectID;

    message.setBody(msg);
    return message;
       
}