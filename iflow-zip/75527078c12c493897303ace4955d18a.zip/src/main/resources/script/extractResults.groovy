import com.sap.gateway.ip.core.customdev.util.Message



Message countProcessedFinal(Message message){
    def body = message.getBody(String.class)
    
    if (body?.isNumber()){
        message.setProperty("totalProcessedFinal",""+(Integer.parseInt(message.getProperty("totalProcessedFinal"))+ Integer.parseInt(body)))
    }
    
    return message
}


def Message buildFilter(Message message) {


    def body = message.getBody(String.class)
    def xml = new XmlSlurper().parseText(body)

    
    def filter = ""
    xml?.A_SalesOrderType?.ReferenceSDDocument?.each {
        it ->  
            if (filter) filter = filter + " or SalesQuotation eq '" + it + "'"
            else filter = "SalesQuotation eq '" + it + "'"
    }
    
    
    message.setProperty("filter", filter)

    return message
}