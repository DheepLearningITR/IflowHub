import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def error = message.getBody(java.lang.String) as String;
    throw new Exception(error);
}
