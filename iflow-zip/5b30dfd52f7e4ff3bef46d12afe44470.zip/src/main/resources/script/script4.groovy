import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import java.util.ArrayList;

def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
    def body = message.getBody(java.lang.String) as String
    def jsonParser = new JsonSlurper()
    def map = message.getProperties()
    
    
    int sIndex = map.get("index").toInteger()
    def sPayload = map.get("payload")
    def jsonObject = jsonParser.parseText(sPayload)
    
    // messageLog.addAttachmentAsString("PayloadAHGORA", JsonOutput.prettyPrint(body), "text/json");
    
    def operation = jsonObject.request.ausencias[sIndex].operation
    def pernr = jsonObject.request.ausencias[sIndex].pernr
    message.setProperty("operation",  operation)
    message.setProperty("pernr",  pernr)
    message.setProperty("cod",  jsonObject.request.ausencias[sIndex].cod)
    
    def arr = []
    def json
    json = {}
    json = JsonOutput.toJson(
        pernr : (jsonObject.request.ausencias[sIndex].pernr == null ) ? '' : jsonObject.request.ausencias[sIndex].pernr,
        subty : (jsonObject.request.ausencias[sIndex].subty == null ) ? '' : jsonObject.request.ausencias[sIndex].subty,
        begda : jsonObject.request.ausencias[sIndex].begda,
        endda : jsonObject.request.ausencias[sIndex].endda,
        beguz : jsonObject.request.ausencias[sIndex].beguz,
        enduz : jsonObject.request.ausencias[sIndex].enduz,
        operation : jsonObject.request.ausencias[sIndex].operation,
        cod : jsonObject.request.ausencias[sIndex].cod,
        externalcode : (jsonObject.request.ausencias[sIndex].externalcode == null ) ? '' : jsonObject.request.ausencias[sIndex].externalcode
    )
    
    arr.push(json)
    
    message.setBody(JsonOutput.prettyPrint(arr.toString().substring(1, arr.toString().toString().length() - 1)))
    
    sIndex = sIndex + 1
    
    message.setProperty("index",  sIndex)  
    
    return message;
    
}