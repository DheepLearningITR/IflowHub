import com.sap.it.api.mapping.*;

def void concatValues(String[] is, Output output, MappingContext context) {
    if(is.length > 0){
        String s = "";
        int i;
        for(i=0;i<is.length-1;i++){
           s= s+is[i]+"\n";
        }
        s= s+is[i];
        output.addValue(s);
    }
}