import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil;
import groovy.util.slurpersupport.NodeChild;

def Message processData(Message message) {
    /* This script is to log the Product IDs that are filtered out with no FSM company. */
	
    def body = message.getBody(java.lang.String)
    def query = new XmlSlurper().parseText(body)
    def messageLog = messageLogFactory.getMessageLog(message)
	
    query.ProductMDMBulkReplicateRequestMessage.ProductMDMReplicateRequestMessage.each { productMessage ->
        productMessage.Product.each { prod ->
            def internalID = prod.ProductInternalID.text()
            if (messageLog != null) {
                messageLog.addCustomHeaderProperty("FSMCompanyNotFoundForProduct", internalID)
            }
        }
    }
    return message
}
