package settle.clearing

import groovy.xml.StreamingMarkupBuilder
//import groovy.xml.XmlSlurper
import groovy.util.slurpersupport.GPathResult
import groovy.xml.XmlUtil
import com.sap.gateway.ip.core.customdev.util.Message
import java.time.LocalDateTime


String toSettleClearing(settlement, creditMemoRespList) {
    def mkpBuilder = new StreamingMarkupBuilder()

    mkpBuilder.encoding = 'utf-8'

    def clearingXml = mkpBuilder.bind { bld ->
        mkp.xmlDeclaration()
        mkp.declareNamespace(ns_func: 'urn:sap-com:document:sap:rfc:functions')

        ns_func.FINS_JE_CLEARING {
            buildClearingHeader(bld, settlement)
            buildClearingItems(bld, settlement, creditMemoRespList)
        }
    }

    return XmlUtil.serialize(clearingXml)
}

void buildClearingHeader(builder, settlement) {
    builder.IS_CLEARING_HEADER {
        BUKRS(settlement.companyCode[0].text())
        BLART('AB')

        def now = LocalDateTime.now()
        BLDAT(now)
        BUDAT(now)
        WAERS(settlement.currency[0].text())
    }
}

BigDecimal convertStrToBigDec(String strVal) {
    // In groovy empty string or null will be convert to false.
    return strVal?.trim() ? new BigDecimal(strVal) : BigDecimal.ZERO
}

void buildClearingItems(builder, settlement, creditMemoRespList) {
    // Refer: https://wiki.one.int.sap/wiki/display/Eureka/Settling+Process+Workflow
    //      : https://wiki.one.int.sap/wiki/display/Eureka/Settlement+Software+Design+Document

    // Left pad 0 to 10. Refer: https://github.tools.sap/CIC/claims-settlement/blob/f2b34ac04984d099a10e6df5c7111b1351d767fe/claims-settlement-core/src/main/java/com/sap/s4hana/eureka/business/claimssettlement/core/apiservice/apiimpl/clearing/ClearingSettlementBeforeAction.java#L52
    def claimingAccountId = settlement.planningAccount.text().padLeft(10, '0')

    builder.IT_APAR_ITEM_TO_BE_CLRD {
        // From residual item
        buildClearingItemFromResidualItem(builder, claimingAccountId, settlement)

        // From credit memo
        buildClearingItemFromCreditMemo(builder, claimingAccountId, creditMemoRespList)
    }
}

void buildClearingItemFromResidualItem(builder, claimingAccountId, settlement) {
    def residualItem = settlement.residualItemRef

    builder.item {
        BUKRS(residualItem.companyCode.text())
        KOART('D')
        KONKO(claimingAccountId)
        GJAHR(residualItem.fiscalYear.text())
        BELNR(residualItem.accountingDocument.text())
        BUZEI(residualItem.accountingDocumentItem.text())

        def claimApproveAmt = convertStrToBigDec(settlement.netAmount.amount.text())
        def residualItemAmt = convertStrToBigDec(residualItem.amountInTransactionCurrency.text())
        if (settlement.remainingAmount.text() == "0" || settlement.remainingAmount.text() == null) {
            ODAMTDC('')
            ODREASONCODE('')
        } else {
            ODAMTDC(settlement.remainingAmount.text())
            ODREASONCODE(settlement.remainingAmountReasonCode.text())
        }
    }
}

void buildClearingItemFromCreditMemo(builder, claimingAccountId, creditMemoRespList) {
    def allCreditMemo = []
    for (nodeName in ['T_BKPF', 'T_BSEG']) {

        creditMemoRespList.collect({ it.'**'.find({ it.name() == nodeName })?.item }).each {
                if (it) {
                    allCreditMemo += it   
                }
            }
    }

    def pickedCreditMemo = allCreditMemo.collect({
        [
                'accountType'      : it.KOART?.text(),
                'accountingDoc'    : it.BELNR?.text(),
                'accountingDocItem': it.BUZEI?.text(),
                'companyCode'      : it.BUKRS?.text(),
                'fiscalYear'       : it.GJAHR?.text()
        ]
    }).findAll({ it.values().every({ v -> (boolean) v }) })
    // Only pick out these item, which's accountType is 'D'. Refer: https://github.tools.sap/CIC/claims-settlement/blob/63302258d9144e50223a9bcc39d6b0304b0be7c6/claims-settlement-core/src/main/java/com/sap/s4hana/eureka/business/claimssettlement/core/apiservice/apiimpl/creditmemo/CreditMemoDoBaseAfterAction.java#L60
            .findAll({ it.accountType.toUpperCase() == 'D' })
            .collect()

    for (creditMemo in pickedCreditMemo) {
        builder.item {
            BUKRS(creditMemo.companyCode)
            KOART('D')
            KONKO(claimingAccountId)
            GJAHR(creditMemo.fiscalYear)
            BELNR(creditMemo.accountingDoc)
            BUZEI(creditMemo.accountingDocItem)
            odamtdc('')
            odreasoncode('')
        }
    }
}

def getSettlementAndLastCreditMemo(msgBody) {
    def settlement = msgBody.bo
    def lastCreditMemoResponseList = msgBody.trans.tran.findAll({ it.@api == 'CreditMemo' })
            .groupBy { it.@callOrder.toInteger() }
            .max { it.key }
            .value
            .collect({ it.response })

    return [settlement, lastCreditMemoResponseList]
}

String appendRequestResponseInto(origBody, req, resp, docTran) {
    def mkpBuilder = new StreamingMarkupBuilder()

    mkpBuilder.encoding = 'utf-8'

    def appendMsgXml = mkpBuilder.bind { bld ->
        mkp.xmlDeclaration()

        message {
            // append original bo
            origBody.bo.build(bld)

            // append documentTransactions
            for (documentTransactions in origBody.documentTransactions) {
                documentTransactions.build(bld)
            }

            if (null != docTran) {
                if (docTran instanceof String) {
                    mkp.yieldUnescaped(docTran.replaceFirst(/<\?xml.+\?>/, ''))
                } else {
                    docTran.build(bld)
                }
            }

            // append current tran
            trans {
                for (tran in origBody.trans.tran) {
                    tran.build(bld)
                }

                if (null != req && null != resp) {
                    def apiName = 'Clearing'
                    def curCallOrder = origBody.trans.tran.findAll({ it.@api == apiName }).size()

                    tran(api: apiName, callOrder: curCallOrder) {
                        request {
                            body(req)
                        }
                        response(resp)
                    }
                }
            }
        }
    }

    return XmlUtil.serialize(appendMsgXml)
}

enum ResponseStatus {
    needRetry,
    blockError,
    accept
}

/**
 * Return a boolean value indicate whether need retry for current settle clearing response
 *
 * Refer:
 *   https://wiki.one.int.sap/wiki/pages/viewpage.action?spaceKey=Eureka&title=Settling+Process+Workflow
 *   https://github.tools.sap/CIC/claims-settlement/blob/215f42bb27fa65fd31f9d539bf77d5c18c249b03/claims-settlement-core/src/main/java/com/sap/s4hana/eureka/business/claimssettlement/core/claimssettlement/domain/bo/ClaimsSettlement.java#L472
 */
def handleResponseNeedRetry(resp) {
    def jeIdNode = resp.'ET_JE_ID'
    def messageNode = resp.'ET_MESSAGE'

    if (jeIdNode.item.size() > 0) {
        def firstItem = jeIdNode.item[0]
        def itemFields = [
                firstItem.BUKRS?.text(), // company code
                firstItem.GJAHR?.text(), // fiscal year
                firstItem.BELNR?.text()  // accounting document
        ]

        if (itemFields.every { it?.size() > 0 }) {
            def clearingDT = LocalDateTime.now()
            def docTran = responseToDocumentTransaction(itemFields[2], itemFields[0], itemFields[1], clearingDT)

            return [ResponseStatus.accept, docTran, 'successfully settled']
        }
    }

    // if there is no jeIdNode and no messageNode, it will happened when the call is not happened to S4
    if (jeIdNode.item.size() == 0 && messageNode.item.size() == 0) {
        return [ResponseStatus.needRetry, null, '']
    }

    def messageNumberList = messageNode.item.collect { it.NUMBER?.text() }
    def errMsg = messageNode.item.collect({ it.MESSAGE?.text()?.trim() }).join(', ')

    def retryErrNumbers = ['302', '287'] // CLEARING_TECHNICAL_PROBLEM, CLEARING_LOCK_BLOCK
    if (retryErrNumbers.any { it in messageNumberList }) {
        return [ResponseStatus.needRetry, null, errMsg]
    }

    return [ResponseStatus.blockError, null, errMsg]
}

String responseToDocumentTransaction(accountingDoc, companyCode, fiscalYear, clearingDT) {
    // Build documentTransaction
    def mkpBuilder = new StreamingMarkupBuilder();

    mkpBuilder.encoding = 'utf-8'

    def docTranXml = mkpBuilder.bind { bld ->
        mkp.xmlDeclaration()

        bld.documentTransactions {
            bld.documentNumber(accountingDoc)
            bld.documentType('CLEARING_ACCOUNTING_DOCUMENT')
            bld.fiscalYear(fiscalYear)
            bld.createdOn(clearingDT)
            bld.companyCode(companyCode)
        }
    }

    return XmlUtil.serialize(docTranXml)
}

String toClaimsSettlementCallback(origBody, settleStatus, settleErrMsg) {
    def mkpBuilder = new StreamingMarkupBuilder();

    mkpBuilder.encoding = 'utf-8'

    if ('ERROR' == settleStatus && settleErrMsg != null && settleErrMsg.length() > 0) {
        StringBuffer finalMessages = new StringBuffer("Failed to clear the A/R Open Item in SAP S/4HANA. \n");
        finalMessages.append(settleErrMsg)
        settleErrMsg = finalMessages.toString();
    }

    def callbackXml = mkpBuilder.bind { bld ->
        mkp.xmlDeclaration()

        bld.root {
            mkp.comment("the settle process")

            def settlement = origBody.bo

            bld.settlementUUID(settlement.settlementUUID.text())
            bld.timestamp(LocalDateTime.now())
            bld.status(settleStatus)

            origBody.documentTransactions.build(bld)

            bld.message(settleErrMsg)
        }
    }

    return XmlUtil.serialize(callbackXml)
}

//region Call in CPI

/**
 * Step(0)
 *
 * */
def sleepBetweenEachCall(Message msg) {
    // get the retry times & setting
    def propMap = msg.getProperties()
    def retryTime = propMap.getOrDefault('retryTime', 0)
    def isExpDelay = propMap.getOrDefault('isExpDelay', 'F')
    def errorRetryInterval = Integer.parseInt(propMap.getOrDefault('retryInterval', '30').toString())

    // sleep given time
    if (retryTime > 0) {
        def obj = new Object()
        if (isExpDelay in ['T', 't', 'True', 'true', 'TRUE']) {
            obj.sleep((2**retryTime) * 1000)
        } else {
            obj.sleep(errorRetryInterval*1000)
        }
    }

    // set back the retry time
    msg.setProperty('retryTime', ++retryTime)

    return msg
}

class MsgWrapper {

    Message msg;
    XmlSlurper xmlSlp;

    MsgWrapper(Message msg) {
        this.msg = msg
        this.xmlSlp = new XmlSlurper()
    }

    def getMsg() {
        return msg
    }

    GPathResult getRequest() {
        return xmlSlp.parseText(msg.getProperty('request') as String)
    }

    void setRequest(String request) {
        msg.setProperty('request', request)
    }

    GPathResult getResponse() {
        return xmlSlp.parseText(msg.getProperty('response') as String)
    }

    void setResponse(String response) {
        msg.setProperty('response', response)
    }

    GPathResult getOrigBody() {
        return xmlSlp.parseText(msg.getProperty('origBody') as String)
    }

    void setOrigBody(String origBody) {
        msg.setProperty('origBody', origBody)
    }

    String getSettleStatus() {
        return msg.getProperty('settleStatus') as String
    }

    void setSettleStatus(String status) {
        msg.setProperty('settleStatus', status)
    }

    String getSettleErrMsg() {
        return msg.getProperty('settleErrMsg') as String
    }

    void setSettleErrMsg(String status) {
        msg.setProperty('settleErrMsg', status)
    }

    boolean getNeedRetry() {
        return 'T' == (msg.getProperty('needRetry') as String)
    }

    void setNeedRetry(boolean needRetry) {
        msg.setProperty('needRetry', needRetry ? 'T' : 'F')
    }

    void setTenantId(String tenantId) {
        msg.setProperty('X-Tenant-ID', tenantId)
    }

    String getTenantId() {
        return msg.getProperty('X-Tenant-ID') as String
    }

    void setStepInfo(String step) {
        msg.setProperty('stepInfo', step)
    }

    String getStepInfo() {
        return msg.getProperties().getOrDefault('stepInfo', null) as String
    }

    GPathResult getBody() {
        return xmlSlp.parseText(msg.getBody(String.class) as String)
    }

    void setBody(String body) {
        msg.setBody(body)
    }
}

def setupMessage(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.origBody = msg.getBody(String)
    msgWrapper.tenantId = msg.getHeader('X-Tenant-ID', String)
    msgWrapper.settleStatus = 'SETTLED'
    msgWrapper.settleErrMsg = 'successfully settled'
    msgWrapper.needRetry = false
    return msg
}


/**
 * Step (1)
 *
 * */
def transferSettleClearingRequest(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'prepare clearing request'

    // get the whole body and saved into a property 'origBody'
    msgWrapper.origBody = msg.getBody(String)
    msgWrapper.tenantId = msg.getHeader('X-Tenant-ID', String)

    // fetch the settlement BO and call toSettleClearing
    def (settlement, creditMemoResp) = getSettlementAndLastCreditMemo(msgWrapper.body)
    def clearingRequest = toSettleClearing(settlement, creditMemoResp)
    msgWrapper.body = (clearingRequest)

    // keep the request payload into a property 'request'
    msgWrapper.request = clearingRequest

    // set the property 'needRetry'
    msgWrapper.needRetry = true

    return msg
}

/**
 * Step (2)
 * */
def mergeSettleClearingResponse(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'merge clearing response into orig-body'

    // get the response from message body & keep the response payload into property 'response'
    msgWrapper.response = msg.getBody(String)

    // get the whole body from property 'origBody' & original request from property 'request'
    // generate the whole internal payload and set it into message body
    def appendedBody = appendRequestResponseInto(msgWrapper.origBody, msgWrapper.request, msgWrapper.response, null)
    msgWrapper.body = appendedBody
    msgWrapper.origBody = appendedBody

    return msg
}

/**
 * Step (3)
 *
 * */
def handleClearingResponseForRetry(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'calc clearing response for needRetry'

    def (responseStatus, documentTransaction, errMsg) = handleResponseNeedRetry(msgWrapper.response)

    // merge current documentTransaction
    if (responseStatus == ResponseStatus.accept && null != documentTransaction) {
        def appendBody = appendRequestResponseInto(msgWrapper.origBody, null, null, documentTransaction)

        msgWrapper.origBody = appendBody
        msgWrapper.body = appendBody
    }

    // set the property 'needRetry' & 'settleStatus'
    msgWrapper.settleStatus = (responseStatus == ResponseStatus.accept ? 'SETTLED' : 'ERROR')
    msgWrapper.settleErrMsg = errMsg
    msgWrapper.needRetry = (responseStatus == ResponseStatus.needRetry)

    return msg
}

def transferToClaimsSettlementCallback(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'prepare callback message'

    msgWrapper.body = toClaimsSettlementCallback(msgWrapper.origBody, msgWrapper.settleStatus, msgWrapper.settleErrMsg)
    msg.setHeader('X-Tenant-ID', msgWrapper.tenantId)

    return msg
}

/**
 * Log all these message part
 *
 * */
def logFormatStr(String body, boolean compactXml) {
    if (body.startsWith('<?xml')) {
        if (!compactXml) {
            return XmlUtil.serialize(new XmlSlurper().parseText(body))
        } else {
            return body.replaceAll(/>\s+</, '><').trim()
        }
    }

    return body
}

def logFormatHeaderOrProperty(Map<String, Object> headerOrProperty) {
    def allStringValKeys = headerOrProperty.findAll({ it.value instanceof String }).collect({ it.key })
    allStringValKeys = allStringValKeys.sort()

    def maxKeyLen = allStringValKeys.collect({ it.size() }).max()
    return allStringValKeys.collect({ "${it.padRight(maxKeyLen)} : ${logFormatStr(headerOrProperty.get(it), true)}" }).join('\n')
}

def logAllOfMessage(Message msg) {
    // get log execute times
    def propMap = msg.getProperties()

    def printLogTimes = propMap.getOrDefault('printLogTimes', new HashMap<String, Integer>()) as Map<String, Integer>
    def msgWrapper = new MsgWrapper(msg)

    // get Header, Property & Body
    def headers = logFormatHeaderOrProperty(msg.getHeaders())
    def properties = logFormatHeaderOrProperty(msg.getProperties())
    def body = logFormatStr(msg.getBody(java.lang.String) as String, false)

    def stepTime = msgWrapper.stepInfo ? printLogTimes.getOrDefault(msgWrapper.stepInfo, 0) : 0
    def stepName = msgWrapper.stepInfo ? "${msgWrapper.stepInfo} ($stepTime)" : ''
    def globalStepTime = printLogTimes.getOrDefault('_GlobalStepTime', 0)
    def messageLog = messageLogFactory.getMessageLog(msg)
    if (messageLog != null)
    {
        def logText = '--------------------- Header ---------------------\n' + headers
        logText += '\n-------------------- Property --------------------\n' + properties
        logText += '\n---------------------- Body ----------------------\n' + body
        messageLog.addAttachmentAsString("Log ($globalStepTime) at $stepName:", logText, "text/plain")
    }

    if (msgWrapper.stepInfo) {
        printLogTimes.put(msgWrapper.stepInfo, ++stepTime)
    }
    printLogTimes.put('_GlobalStepTime', ++globalStepTime)
    msg.setProperty('printLogTimes', printLogTimes)

    return msg
}
