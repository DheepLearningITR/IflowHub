import groovy.json.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(String.class);
       def jsonSlurper = new JsonSlurper()
       def list = jsonSlurper.parseText(body)
       def token="Bearer "+list.access_token.toString();
       //Headers 
       def map = message.getHeaders();
       message.setHeader("Authorization", token);
      
       return message;
}