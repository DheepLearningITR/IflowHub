import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

def Message processData(Message message) {
    


//Credentials // the same user credentials needs to be avaliable in secure material.
//def user = "YOUR_UserCredentials";
def user = message.getProperty("COPIN_USER");// externalise to provide different name configured in other instances on transport
message.setHeader("Content-type", "application/x-www-form-urlencoded");

//service to get the credentials
def service = ITApiFactory.getApi(SecureStoreService.class, null);

//get user credential
def userCred = service.getUserCredential(user);
if (userCred == null){
throw new IllegalStateException("No User credential found for alias" + user);
}

String username = userCred.getUsername();
String password = new String(userCred.getPassword());


//store password parameters i.e password client id and client secret delimited with * symbol as mentioned on respective security artifact
String[] entry = password.split("\\*"); 
password = entry[0].trim();// retrive password
client_id = entry[1].trim(); // retrive cleint Id
client_secret = entry[2].trim(); // retrive Client_secret


//HTTP Parameters value
String grant_type = "password"; // Service Now grant type

//Query
def query = "";
query = query + "client_id=" + client_id + "&";
query = query + "client_secret=" + client_secret + "&";
query = query + "grant_type=" + grant_type + "&";
query = query + "username=" + username + "&";
query = query + "password=" + password;

message.setBody(query);


return message;
}