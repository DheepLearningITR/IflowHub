
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
def Message processData(Message message) {

    def map = message.getProperties();
    Integer configuredTimeInMinutes = map.get("lastChangedTime").toInteger();
    def configuredTimeInMiliSeconds = configuredTimeInMinutes * 60000
    Date newDate=new Date()
    def dateInMilisecs = newDate.getTime() - configuredTimeInMiliSeconds
    DateFormat dateFormat_required = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")
    DateFormat timeFormat_required = new SimpleDateFormat("'PT'HH'H'mm'M'ss'S'")
 
    def outputDate=dateFormat_required.format(dateInMilisecs);
    def outputTime=timeFormat_required.format(dateInMilisecs)
 
    message.setProperty("TargetDate",outputDate.toString())
    message.setProperty("TargetTime",outputTime.toString())
    return message
}