import groovy.json.JsonBuilder
import com.sap.it.api.mapping.*;
import org.json.JSONObject;
import org.json.JSONException;
import java.nio.charset.StandardCharsets
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher
import java.util.regex.Pattern
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.time.LocalDate
import java.time.format.DateTimeFormatter

def Message CustomerSalesOrg(Message message) {

    HashMap<String, String> map = new HashMap<String, String>();
    map.put("USCU_S17","1710");
    map.put("USCU_S16","1710");    
    map.put("USCU_S15","1710");
    map.put("USCU_S14","1710");
    map.put("USCU_S13","1710");
    map.put("USCU_S12","1710");

    
    message.setProperty("saphda_CustomerSalesorg", map);

    return message;
}

def Message topskip(Message message) {
    def propMap = message.getProperties()
    def CamelLoopIndex = propMap.get("CamelLoopIndex")
    //def QueryParameters = propMap.get("QueryParameters")
    def saphda_chunck = propMap.get("saphda_chunck")
    def maxLines = propMap.get('saphda_maxLines')
    
    def calc = saphda_chunck.toInteger() * CamelLoopIndex.toInteger()
    //QueryParameters = QueryParameters + '&$skip=' + calc.toString()
    //message.setProperty("QueryParameters",QueryParameters)
    message.setProperty("saphda_skip",calc)
    
    if ( ( calc + saphda_chunck ) > maxLines ) {
        message.setProperty("saphda_chunck", maxLines - calc )
    }
    
    return message;

}

def Message catch_camels(Message message){

    def map  = message.getProperties();
    def ex   = map.get("CamelExceptionCaught");
    def exceptionText;

    if (ex != null) {
        exceptionText    = ex.getMessage();
        def messageLog   = messageLogFactory.getMessageLog(message);
        messageLog.addAttachmentAsString("Exception", exceptionText,"application/text");

        // copy the http error response body as a property
        message.setProperty("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());

        try {

            def mp = [
                    "jobStatus": "ERROR",
                    "jobStatusDescription": exceptionText,
                    "modelID" : message.getProperty('saphda_modelID'),
                    "current/nextmonth" :  message.getProperty('saphda_current_calmonth')
            ];

            def ibpCommitStatus = new JSONObject(mp).toString();

            message.setProperty("http.response", ibpCommitStatus);

            message.setBody(ibpCommitStatus);

        } catch (JSONException e) {
            message.setBody(e);
        }
    }
    return message;
}

def Message checkStatus(Message message) {

    Reader body = message.getBody(Reader)

    def input = new JsonSlurper().parse(body)

    message.setProperty("jobStatus", input.jobStatus);
    message.setProperty("failedNumberRows", input.additionalInformation.failedNumberRows);

    if (input.jobStatus != 'COMPLETED') {
        sleep(1000);
    }

    return message;
}

def Message clearBody(Message message) {
    //Body
    def body = message.getBody();
    message.setBody("");
    return message;
}

def Message handleRequestBody(Message message) {

    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body)

   def numberOfProcessingMonth = input.numberOfProcessingMonth
    if ( numberOfProcessingMonth instanceof Integer ) {
        saphda_numberOfProcessingMonth = numberOfProcessingMonth
    } else if ( numberOfProcessingMonth == null ) {
        saphda_numberOfProcessingMonth = 18
    } else {
        saphda_numberOfProcessingMonth = Integer.parseInt(numberOfProcessingMonth)
    }

    DateTimeFormatter pattern = DateTimeFormatter.ofPattern("yyyyMM");
    def now = LocalDate.now()
    def saphda_calmonth_from = now.format(pattern)
    now = now.plusMonths(saphda_numberOfProcessingMonth)
    def saphda_calmonth_to = now.format(pattern)
    
    message.setProperty("saphda_calmonth_from", convertDateLong(saphda_calmonth_from));

    message.setProperty("saphda_calmonth_to", convertDateLong(saphda_calmonth_to))

    def modelID = URLEncoder.encode(input.modelID,StandardCharsets.UTF_8.name())
    message.setProperty("saphda_modelID", modelID);
    
    def maxLines = input.maxLines
    if ( maxLines instanceof Integer ) {
        saphda_maxLines = maxLines
    } else if ( maxLines == null ) {
        saphda_maxLines = 99999999
    } else {
		saphda_maxLines = Integer.parseInt(maxLines)
    }      
    
    message.setProperty("saphda_maxLines", saphda_maxLines); 
    
    
    def saphda_chunck2 = input.chunckSize
    if ( saphda_chunck2 instanceof Integer ) {
        saphda_chunck = saphda_chunck2
    } else if ( saphda_chunck2 == null ) {
        saphda_chunck = 30000    
    } else {
		saphda_chunck = Integer.parseInt(saphda_chunck2)
    }       
    message.setProperty("saphda_chunck", saphda_chunck);
   
   
    return message;
}

def String convertDate(String arg1){

    Pattern pattern = Pattern.compile("\\d+")
    Matcher matcher = pattern.matcher(arg1)

    String converted_datetime =  ""
    if (matcher.find()) {
        def arg1_long = Long.valueOf(matcher.group())
        Date result_date = new Date( arg1_long );
        DateFormat simple = new SimpleDateFormat(
                "yyyyMM");
        converted_datetime = simple.format(result_date);
    }

    return converted_datetime;
}

def String convertDateLong(String arg1){

    Pattern pattern = Pattern.compile("\\d+")
    Matcher matcher = pattern.matcher(arg1)

    String converted_datetime =  ""
    if (matcher.find()) {
        Date result_date = Date.parse("yyyyMM", arg1)
        DateFormat simple = new SimpleDateFormat(
                'yyyy-MM-dd\'T\'00:mm:ss');
        converted_datetime = simple.format(result_date);
    }

    return converted_datetime;
}

def BigDecimal convertKyf(arg1){

    BigDecimal f = 0
    try {
        f = new BigDecimal(arg1).setScale(7, java.math.RoundingMode.HALF_UP);
    } catch (Exception e) {
        f = 0
    }
    return f;

}

def Message transform(Message message) {

    def propMap = message.getProperties()
    //Reader body = message.getBody(Reader)
    //def input = new JsonSlurper().parse(body)
    def SalesOrgCompcodeProp = propMap.get("saphda_SalesOrgCompcode")
    Map SalesOrgCompcodeMap= new JsonSlurper().parseText(SalesOrgCompcodeProp)
    HashMap<String, String> map = new HashMap<String, String>();
    //map.d.results.each { item -> map.put(item.SalesOrganization,item.CompanyCode);}
    SalesOrgCompcodeMap.d.results.each { item -> map.put(item.SalesOrganization,item.CompanyCode);}

    def ribp = propMap.get("saphda_ibp_response")
    Map ibpdata = new JsonSlurper().parseText(ribp)
    def result_array = ibpdata.get("d").get("results")

    def TreeMap<String,HashMap> CustomerSalesorgMap = propMap.get("saphda_CustomerSalesorg");

    def SapAllCustomerProp = propMap.get("saphda_SapAllCustomer")
    Map SapAllCustomerMap= new JsonSlurper().parseText(SapAllCustomerProp)
    HashMap<String, String> SapAllCustomerMapping = new HashMap<String, String>();
    SapAllCustomerMap.value.each { item -> SapAllCustomerMapping.put(item.ID,item.Distribution_Channel);}

    def maxLines = propMap.get('saphda_maxLines')
    def skip = propMap.get('saphda_skip')
        def chunksize = propMap.get('saphda_chunck')
    commit_val = false
    def count = ibpdata.get("d").get("__count").toInteger()
    if ( count <= ( skip.toInteger() + chunksize.toInteger() ) || maxLines.toInteger() <= ( skip.toInteger() + chunksize.toInteger() ) ) {
        message.setProperty("saphda_commit",'true')
        commit_val = true
    }

    
    def data_array = []
    for (int i = 0; i < result_array.size(); i++) {
        def it = result_array[i]
        def compcode = map.getOrDefault(CustomerSalesorgMap.getOrDefault(it.CUSTID,"#"),"#")
        def salesorg = CustomerSalesorgMap.getOrDefault(it.CUSTID, "#")
        def customer = it.CUSTID
        def plant = it.LOCID
        def prod = it.PRDID
        
        data_array.add([
                "Version": "public.Supply Chain Forecast",
                "Date": convertDate(it.PERIODID3_TSTAMP),
                "SAP_ALL_CUSTOMER": it.CUSTID,
                "SAP_ALL_COMPANY_CODE": compcode,
                "SAP_ALL_SALESORGANISATION": salesorg,
                "SAP_ALL_PRODUCT": it.PRDID,
                "SAP_FI_XPA_GLAccount": "41000000",
                "SAP_SCM_CNR_DriverType": "baseLine",
                "SAP_SCM_CNR_RiskOpportunity":"#",
                "SAP_FI_IFP_QUANTITY_UNIT": it.UOMTOID,
                "SAP_ALL_PLANT": it.LOCID,
                "SAP_ALL_DISTRIBUTIONCHANNEL": SapAllCustomerMapping.getOrDefault(it.CUSTID,"#"),
                "QUANTITY" : ( convertKyf( it.COMBINEDFINALDEMAND ) - convertKyf( it.SALESSPENDIMPACT ) - convertKyf( it.MARKETINGSPENDIMPACT ) ) * -1 

        ])
        data_array.add([
                "Version": "public.Supply Chain Forecast",
                "Date": convertDate(it.PERIODID3_TSTAMP), 
                "SAP_ALL_CUSTOMER": it.CUSTID,
                "SAP_ALL_COMPANY_CODE": compcode,
                "SAP_ALL_SALESORGANISATION": salesorg,
                "SAP_ALL_PRODUCT": it.PRDID,
                "SAP_FI_XPA_GLAccount": "41000000",
                "SAP_SCM_CNR_DriverType": "salesactivityLift",
                "SAP_SCM_CNR_RiskOpportunity":"#",
                "SAP_FI_IFP_QUANTITY_UNIT": it.UOMTOID,
                "SAP_ALL_PLANT": it.LOCID,
                "SAP_ALL_DISTRIBUTIONCHANNEL": SapAllCustomerMapping.getOrDefault(it.CUSTID,"#"),
                "QUANTITY" : ( convertKyf( it.SALESSPENDIMPACT ) ) * -1
        ])
        data_array.add([
                "Version": "public.Supply Chain Forecast",
                "Date": convertDate(it.PERIODID3_TSTAMP),
                "SAP_ALL_CUSTOMER": it.CUSTID,
                "SAP_ALL_COMPANY_CODE": compcode,
                "SAP_ALL_SALESORGANISATION": salesorg,
                "SAP_ALL_PRODUCT": it.PRDID,
                "SAP_FI_XPA_GLAccount": "41000000",
                "SAP_SCM_CNR_DriverType": "mktcampaignLift",
                "SAP_SCM_CNR_RiskOpportunity":"#",
                "SAP_FI_IFP_QUANTITY_UNIT": it.UOMTOID,
                "SAP_ALL_PLANT": it.LOCID,
                "SAP_ALL_DISTRIBUTIONCHANNEL": SapAllCustomerMapping.getOrDefault(it.CUSTID,"#"),
                "QUANTITY" : ( convertKyf( it.MARKETINGSPENDIMPACT ) ) * -1
        ])
    }

    def builder = new JsonBuilder()
    def result_array2 = []
    result_array2.add("Data": data_array)
    builder(result_array2[0])

    def prettyBody = builder.toPrettyString()

    message.setBody(prettyBody);

    return message;
}


def Message setJobName(Message message) {

    Reader body = message.getBody(Reader)

    def input = new JsonSlurper().parse(body)

    def properties = message.getProperties();
    
    saphda_jobname = properties.get("saphda_jobname");
    if ( saphda_jobname == 'initial' ) {
        message.setProperty("saphda_jobname", input.jobID);
    }
    
    value = properties.get("body");    
    message.setBody(value);

    return message;
}