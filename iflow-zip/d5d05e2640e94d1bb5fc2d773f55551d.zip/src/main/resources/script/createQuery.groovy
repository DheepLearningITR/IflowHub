import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

def Message processData(Message message) 
{	
	StringBuffer str = new StringBuffer();
	def last_sync = pMap.get("last_sync");
	last_sync = last_sync.substring(0,last_sync.size()-5)+"Z";
	str.append(" last_modified_on>to_datetime('" + last_sync  + "') ");
        def val = str.toString();
	message.setProperty("query",val);
	return message;
}