import com.sap.it.api.mapping.*;
import org.joda.time.Chronology;
import org.joda.time.LocalDate;
import org.joda.time.chrono.IslamicChronology;
import org.joda.time.chrono.ISOChronology;


def String Hijri_to_Gregorian(String arg1){
        Chronology iso = ISOChronology.getInstanceUTC();
        Chronology hijri = IslamicChronology.getInstanceUTC();
        String[] separated = arg1.split("-");
        LocalDate inHijri = new LocalDate(Integer.parseInt(separated[0]), Integer.parseInt(separated[1]), Integer.parseInt(separated[2]),hijri);
        LocalDate inISO = new LocalDate(inHijri.toDateTimeAtStartOfDay(),iso);
	return inISO; 
}