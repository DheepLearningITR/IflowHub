import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
def Message processData(Message message) {
    def bodyString = message.getBody(java.lang.String) as String;
    def oXML = new XmlParser().parseText(bodyString);
    oXML.appendNode("candidateId", message.getProperty('candidateId')); 
    message.setBody(XmlUtil.serialize(oXML));
    return message;

}