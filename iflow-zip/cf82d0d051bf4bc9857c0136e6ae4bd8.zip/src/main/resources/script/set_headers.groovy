import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
String password;
def service = ITApiFactory.getApi(SecureStoreService.class, null);
def credential = service.getUserCredential(message.getProperty("Key_Name")); 
        if (credential == null)
        { throw new IllegalStateException("No credential found for alias ${message.getProperty('Key_Name')}");             
        }
        else{
            password= new String(credential.getPassword());
            }

        //store it in property which can be used in later stage of your integration process.
        message.setHeader("ApiKey", password);
        message.setHeader("Content-Type","application/json");
       return message;
}