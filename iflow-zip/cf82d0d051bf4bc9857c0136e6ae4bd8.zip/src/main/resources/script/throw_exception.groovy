import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    throw new Exception("Error: Person from assessmentOrderId ${message.getProperty('assessmentOrderId')} not found in Third Party Service");
       return message;
}