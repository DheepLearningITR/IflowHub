import com.sap.it.api.mapping.*;
import org.joda.time.Chronology;
import org.joda.time.LocalDate;
import org.joda.time.chrono.IslamicChronology;
import org.joda.time.chrono.ISOChronology;


def String Gregorian_to_Hijri(String arg1){
        Chronology iso = ISOChronology.getInstanceUTC();
        Chronology hijri = IslamicChronology.getInstanceUTC();
        String[] separated = arg1.split("-");
        LocalDate inISO = new LocalDate(Integer.parseInt(separated[0]), Integer.parseInt(separated[1]), Integer.parseInt(separated[2]),iso);
        LocalDate inHijri = new LocalDate(inISO.toDateTimeAtStartOfDay(),hijri);
	return inHijri; 
}