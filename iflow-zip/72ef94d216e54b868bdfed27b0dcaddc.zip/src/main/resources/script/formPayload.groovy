import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.util.*;
import groovy.xml.*;
import org.codehaus.*;
import java.util.HashMap;

def Message processData(Message message) {
     
     // Read Response Body
     def body_json=  message.getProperty("InputJSONString") as String;
     def jsonSlurper = new JsonSlurper();
     def inputPayload = jsonSlurper.parseText(body_json);
     def builder = new JsonBuilder();
     def result = [
         DebitMemoRequestType: inputPayload.targetType.targetType.code,
         SalesOrganization: inputPayload.parentID.salesOrganization.salesOrganization,
         DistributionChannel: inputPayload.parentID.distributionChannel.distributionChannel,
         OrganizationDivision: inputPayload.parentID.division.salesDivision,
         SoldToParty: "",
         PurchaseOrderByCustomer: inputPayload.parentID.externalReference
     ]

     result.SoldToParty = inputPayload.parentID.soldToParty != null ? inputPayload.parentID.soldToParty.customerCode : "";
     
     if(inputPayload.parentID.containsKey("combineItems") && inputPayload.parentID.combineItems.size() > 0 ) {
         if(inputPayload.parentID.combineItems[0].containsKey("referenceDocumentNumber")){
            result.ReferenceSDDocument = inputPayload.parentID.combineItems[0].referenceDocumentNumber;
         }
     }
     
     if(inputPayload.parentID.containsKey("combineItems") && inputPayload.parentID.combineItems.size() > 0 ) {
         result.to_Item = [];
         inputPayload.parentID.combineItems.each{ item ->
            if(item.containsKey("confirmationStatus_code") && item.confirmationStatus_code == "REL"){
                def Material = '', 
                    RequestedQuantity = '',
                    ReferenceSDDocument = '', 
                    ReferenceSDDocumentItem = '';
                    DebitMemoRequestItem = '';
                
                DebitMemoRequestItem = (item.containsKey("itemNumber") && item.itemNumber != null) ? item.itemNumber : "";
                  
                if(inputPayload.targetType.useReferenceMaterial){
                    Material = (item.containsKey("referenceMaterial") && item.referenceMaterial != null) ? item.referenceMaterial.materialCode : "";
                    if(item.containsKey("referenceDocumentNumber") && item.referenceDocumentNumber != null){
                        ReferenceSDDocument = item.referenceDocumentNumber;
                        ReferenceSDDocumentItem = item.referenceDocumentLineItemNumber;
                    }
                } else {
                    Material = (item.containsKey("complaintMaterial") && item.complaintMaterial != null) ? item.complaintMaterial.materialCode : "";
                }
                
                RequestedQuantity = (item.containsKey("complaintQuantity") && item.complaintQuantity != null) ? item.complaintQuantity : "";
                
                
                def items = [
                    Material: Material,
                    DebitMemoRequestItem: DebitMemoRequestItem,
                    RequestedQuantity: RequestedQuantity,
                    ReferenceSDDocument: ReferenceSDDocument,
                    ReferenceSDDocumentItem: ReferenceSDDocumentItem
                ]
                if(inputPayload.parentID.itemCategory.containsKey("creditDebitAmountEnteredManually") && inputPayload.parentID.itemCategory.creditDebitAmountEnteredManually){
                    items.to_PricingElement = [
                        ConditionType: inputPayload.parentID.itemCategory.conditionType,
                        ConditionRateValue: '',
                        ConditionQuantity: '1',
                        ConditionQuantitySAPUnit: 'EA'
                    ]
                    if(inputPayload.parentID.containsKey("adjustmentValue")){
                        items.to_PricingElement.ConditionRateValue = inputPayload.parentID.adjustmentValue;
                    }
                }
                result.to_Item.push(items);
            }
         }
     }
     results = JsonOutput.toJson( result );
     message.setBody(results);
     return message;
}

