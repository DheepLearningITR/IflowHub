/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-GB/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-GB/index.html */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import static java.nio.charset.StandardCharsets.UTF_8

Message processData(Message message) {
    //Body
    body = message.getBody(String)

    jsonSlurper = new JsonSlurper()
    lbnAsset = jsonSlurper.parseText(body)

    map = message.getProperties()
    cxUuid = map.get('cxuuid')
    bpn_withAasPrefix = map.get('bpn')

    mapH = message.getHeaders()
    batchId = mapH.get('m_batchId')
    serialId = mapH.get('m_serialId')
    customerProductId = mapH.get('m_customerProductId')
    cpEndpoint = mapH.get('control-plane-endpoint')
    provider_control_plane = mapH.get('provider-control-plane')
    edc_bpn = mapH.get("edc-bpn")
    bpnAuthorized = mapH.get("edc-bpn_known")

    partInstanceValue = ""
    if(batchId != ""){
        partInstanceValue = batchId
    }
    else if(serialId != ""){
        partInstanceValue = serialId
    }

  //  aasid = toBase64UrlEncoded( bpn_withAasPrefix + "/" + cxUuid ) not based64Encoded anymore
    aasid = bpn_withAasPrefix + "/" + cxUuid
    customerPartId_snippet = "" //empty string
    if(customerProductId != "" && bpnAuthorized == 'true') {
        //fill snippet
        customerPartId_snippet =
        """{ 
            \"name\": \"customerPartId\",
            \"value\": \"""" + customerProductId + """\",  
            \"externalSubjectId\": {
                \"type\": \"ExternalReference\",
                \"keys\": [
                    {
                        \"type\": \"GlobalReference\",
                        \"value\": \"""" + edc_bpn + """\"
                    }
                ]
            }
        },
        """
    }

    partInstanceId_snippet = ""
    assetKindGlobalAsset_snippet = ""
    if(bpnAuthorized == 'true' ){
        assetKindGlobalAsset_snippet = """
    \"assetKind\": \"Instance\",
    \"globalAssetId\": \"""" + cxUuid + """\","""

    partInstanceId_snippet =
        """{
            \"name\": \"partInstanceId\",
            \"value\": \"""" + partInstanceValue + """\",
            \"externalSubjectId\": {
                \"type\": \"ExternalReference\",
                \"keys\": [
                    {
                        \"type\": \"GlobalReference\",
                        \"value\": \"""" + edc_bpn + """\"
                    }
                ]
            }       
        },
        """
    }

    aasMessage = """{""" +
    assetKindGlobalAsset_snippet + """
    \"id\": \"""" + aasid  + """\",
    \"specificAssetId\": [
        """ + partInstanceId_snippet + customerPartId_snippet +
            """{
            \"name\": \"manufacturerPartId\",
            \"value\": \"""" + lbnAsset.partTypeInformation.manufacturerPartId + """\",
            "externalSubjectId": {
		        "type": "ExternalReference",
		        "keys": [
			        {
				        "type":"GlobalReference",
				        "value":"PUBLIC_READABLE"
			        }
		        ]
	        }
        }
    ]"""
    if (body.length() >  0) {
        //we expect only one partType
        aasMessage = addSubModelDescriptors(aasMessage, cxUuid, bpn_withAasPrefix, provider_control_plane, cpEndpoint)
    }
    //msessage should stay open and be closed in part2 script3.groovy
    /*   aasMessage +=
       """
   }""";
   */
    message.setBody(aasMessage)
    return message
}

String addSubModelDescriptors(String aasMessage, String cxUuid, String bpn_withAasPrefix, String provider_control_plane, String cpEndpoint) {
    smId = toBase64UrlEncoded( bpn_withAasPrefix + "/SerialPart/" + cxUuid )
    //Fill in Infomrmation from LBN
    aasMessage += "," + """
    \"submodelDescriptors\": [
        {
            \"endpoints\": [""" +
            //min 1 item
            """
                {
                    \"interface\": \"SUBMODEL-3.0\", 
                    \"protocolInformation\": { 
                        \"href\": \"""" + provider_control_plane + """/http/api/v3.0/serial_part/""" + smId  + """/submodel\",
                        \"endpointProtocol\": \"HTTP\", 
                        \"endpointProtocolVersion\": [\"1.1\"], 
                        \"subprotocol\": \"DSP\",
                        \"subprotocolBody\": \"id=""" + cxUuid + """;dspEndpoint=""" + cpEndpoint + """\",
                        \"subprotocolBodyEncoding\": \"plain\",
                        \"securityAttributes\": [ 
                            { 
                                \"type\": \"NONE\", 
                                \"key\": \"NONE\", 
                                \"value\": \"NONE\" 
                            } 
                        ] 
                    } 
                }
            ],
            \"id\": \"""" + smId + """\",
            \"semanticId\": {
                \"keys\": [
                    {
                        \"type\": \"ConceptDescription\",
                        \"value\": \"urn:bamm:io.catenax.serial_part:1.0.1#SerialPart\"
                    }
                ],
                \"type\": \"ExternalReference\"
            }
        }"""
    //    ]""" let submodelDescriptors open and close it in part 2 Script3.groovy
    aasMessage
}

//base64UrlEncode based on base64Encode
String toBase64UrlEncoded( String str){
    def strBytes = str.getBytes(UTF_8)
    //encodeBase64Url() not available on BTP
    s_out = strBytes.encodeBase64().toString()
    s_out = s_out.replaceAll("/","_").replace("+", "-").replace("=","")
    return s_out
}
