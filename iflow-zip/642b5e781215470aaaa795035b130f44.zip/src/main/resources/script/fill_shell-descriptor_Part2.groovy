/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-GB/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-GB/index.html */
import com.sap.gateway.ip.core.customdev.util.Message

import static java.nio.charset.StandardCharsets.UTF_8

Message processData(Message message) {
    //Body
    body = message.getBody(String)

    map = message.getProperties()
    cxUuid = map.get('cxuuid')

    mapH = message.getHeaders()
    bpn_withAasPrefix = mapH.get('edc-bpn')
    cpEndpoint = mapH.get('control-plane-endpoint')
    provider_control_plane = mapH.get('provider-control-plane')

    aasMessage = ''
    if (body.length() >  0) {
        //we expect only one assembly
        aasMessage = addSubModelDescriptors(aasMessage, cxUuid, bpn_withAasPrefix, provider_control_plane, cpEndpoint)
    }

    aasMessage +=
            """
}"""
    message.setBody(aasMessage)
    return message
}

String addSubModelDescriptors(String aasMessage, String cxUuid, String bpn_withAasPrefix, String provider_control_plane, String cpEndpoint) {
    smId = toBase64UrlEncoded( "urn:aas:" + bpn_withAasPrefix + "/SingleLevelBomAsBuilt/" + cxUuid )

    //Fill in Infomrmation from LBN
    aasMessage += "," + """
        {
            \"endpoints\": [""" +
            //min 1 item
            """
                {
                    \"interface\": \"SUBMODEL-3.0\", 
                    \"protocolInformation\": { 
                        \"href\": \"""" + provider_control_plane + """/http/api/v3.0/single_level_bom_as_built/""" + smId  + """/submodel\",
                        \"endpointProtocol\": \"HTTP\", 
                        \"endpointProtocolVersion\": [\"1.1\"], 
                        \"subprotocol\": \"DSP\",
                        \"subprotocolBody\": \"id=""" + cxUuid + """;dspEndpoint=""" + cpEndpoint + """\",
                        \"subprotocolBodyEncoding\": \"plain\", 
                        \"securityAttributes\": [ 
                            { 
                                \"type\": \"NONE\", 
                                \"key\": \"NONE\", 
                                \"value\": \"NONE\" 
                            } 
                        ]
                    } 
                }
            ],
            \"id\": \"""" + smId + """\",
            \"semanticId\": {
                \"keys\": [
                    {
                        \"type\": \"ConceptDescription\",
                        \"value\": \"urn:bamm:io.catenax.single_level_bom_as_built:1.0.0#SingleLevelBomAsBuilt\"
                    }
                ],
                \"type\": \"ExternalReference\"
            }
        }
    ]"""
    return aasMessage
}

//base64UrlEncode based on base64Encode
String toBase64UrlEncoded( String str){
    def strBytes = str.getBytes(UTF_8)
    //encodeBase64Url() not available on BTP
    s_out = strBytes.encodeBase64().toString()
    s_out = s_out.replaceAll("/","_").replace("+", "-").replace("=","")
    return s_out
}