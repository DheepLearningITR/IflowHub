import com.sap.it.api.mapping.*;
import java.util.UUID;

def String GetEmployeeObjectID(String arg1, MappingContext context) {
  String lv_ObjectID = context.getHeader("EmpObjectID");
  return lv_ObjectID;
}

def String GetEmpObjectUUID(String arg1, MappingContext context) {
  String lv_ObjectUUID = context.getHeader("CamelHttpPath");
  String lv_ObjectID = lv_ObjectUUID.replaceAll("-", "");
  context.setProperty("p_userguid", lv_ObjectID.toUpperCase()); // needed for READ call after Update
  return lv_ObjectID.toUpperCase();
}

def String getLocation(String objectID, MappingContext context) {
  String lv_path = context.getHeader("CamelHttpUrl");
  String hostURL = lv_path.substring(0, lv_path.indexOf("/http/Users"));
  String userLocationURI = hostURL + "/http/Users/" + objectID;
  return userLocationURI.replace("http:", "https:")

}

def String includeGroupInfoInUser(String arg1, MappingContext context) {

  String includeGroupInfoInUser = context.getProperty("p_IncludeGroupInfoInUser")
  HashMap < String, String > businessRoles = context.getProperty("businessRoles")
  if (includeGroupInfoInUser.equals("true") && businessRoles)
    return "true"
  else
    return "false"
}

def String getTotalUserCount(String arg1, MappingContext context) {

  if (context.getHeader("UserCount"))
    return context.getHeader("UserCount")
  else
    return arg1;

}

def String getItemsPerPage(String arg1, MappingContext context) {
  return context.getProperty("p_itemsPerPage");
}

def String getStartIndex(String arg1, MappingContext context) {
  return context.getProperty("p_startIndex");
}

def String GetBusinessRoleID(String arg1, MappingContext context) {
  if (context.getProperty("businessRoles")) {
    HashMap < String, String > businessRoles = context.getProperty("businessRoles")
    String roleId = businessRoles.get(arg1)
    return UUID.fromString(roleId.substring(0, 8) + "-" + roleId.substring(8, 12) + "-" + roleId.substring(12, 16) + "-" + roleId.substring(16, 20) + "-" + roleId.substring(20, 32))
  } else
    return ""
}

def String getGroupLocation(String arg1, MappingContext context) {
    String lv_path = context.getHeader("CamelHttpUrl")
    String hostURL = lv_path.substring(0, lv_path.indexOf("/http/Users"))
    String groupLocationURI = hostURL + "/http/Groups/" + arg1
    return groupLocationURI.replace("http:", "https:")

}