import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

def Message savePayloadToLog(Message message) {
    
    def payload = message.getBody(String.class)   
    def messageLog = messageLogFactory.getMessageLog(message)
    def properties = message.getProperties()
    
    String logger = properties.get("p_Logger")
    
    if(logger.equals("true"))
        {
            messageLog.addAttachmentAsString("Source Payload", payload, "text/xml")
        }
     
    return message
}

//Check if Mandatory userName, familyName and givenName are present and if userName length should be <= 40 characters
def Message isPayloadValid(Message message) {
    
    def body = message.getBody(String)
    def userroot = new XmlSlurper().parseText(body)
    
	def fname =  userroot.name.givenName
	def lname = userroot.name.familyName
	def userName = userroot.userName
	
	boolean isPayloadValid = true
	
	if(userName.text()) {
		if (userName.text().size() > 40) {
			isPayloadValid = false
		}
	}
	else
	    isPayloadValid = false	
	    
	if (isPayloadValid)
			if (!lname.text() || !fname.text())
				isPayloadValid = false	

	if (!isPayloadValid)
		message.setProperty("p_isPayloadValid","false")
      
    return message
}
/*
For SCIM compliance do the following:
1. Replace extension attribute with urn:ietf:params:scim:schemas:extension:enterprise:2.0:User
2. Convert totalResults, itemsPerPage, startIndex to Integer
3. Convert attribute active to boolean and primary attribute for address, email and phone nos. Replace ref with $ref for groups 
4. If the message does not have any resource create an empty Resources array and count (itemsPerPage) > 0
*/
def Message enrichExtension(Message message) {

  def body = message.getBody(String)
  JsonSlurper slurper = new JsonSlurper()
  Map parsedJson = slurper.parseText(body)
  
  if (parsedJson.totalResults) parsedJson.totalResults = Integer.parseInt(parsedJson.totalResults as String) 
  if (parsedJson.itemsPerPage) parsedJson.itemsPerPage = Integer.parseInt(parsedJson.itemsPerPage as String) 
  if (parsedJson.startIndex) parsedJson.startIndex = Integer.parseInt(parsedJson.startIndex as String) 
  
  try {
    if (parsedJson.Resources.size() > 0) {
      parsedJson.Resources.each {
        it.put("urn:ietf:params:scim:schemas:extension:enterprise:2.0:User", it.remove("extension"))
        if (it.extensionUserUuid) {
            if(it.extensionUserUuid.userUuid) {
                it.put("urn:ietf:params:scim:schemas:extension:sap:2.0:User", it.remove("extensionUserUuid"))
                it.get("schemas").add("urn:ietf:params:scim:schemas:extension:sap:2.0:User")
            }
            else{
                it.remove("extensionUserUuid");
            }
        }
        else{
            it.remove("extensionUserUuid");
        }
        if (it.active) 
            it.active = Boolean.parseBoolean(it.active as String) 
        
        if (it.emails) 
            it.emails.each {
                if (it.primary) 
                    it.primary = Boolean.parseBoolean(it.primary as String)
        }
        
        if (it.addresses) 
            it.addresses.each {
                if (it.primary) 
                    it.primary = Boolean.parseBoolean(it.primary as String)
        }
        
        if (it.groups)
            it.groups.each{
                if (it.ref) {
                    it.$ref = it.ref
                    it.remove("ref")
                    }
        }

      }
    }
  }
  
  catch(NullPointerException ignored) {
    if (parsedJson.active) 
        parsedJson.active = Boolean.parseBoolean(parsedJson.active as String)
        
    if (parsedJson.emails) 
        parsedJson.emails.each {
            if (it.primary) 
                it.primary = Boolean.parseBoolean(it.primary as String)
    }
    
    if (parsedJson.addresses) 
        parsedJson.addresses.each {
            if (it.primary) 
                it.primary = Boolean.parseBoolean(it.primary as String)
    }
    //replace ref with $ref
    if (parsedJson.groups)
        parsedJson.groups.each{
                if (it.ref) {
                    it.$ref = it.ref
                    it.remove("ref")
                }
    }
    
    if (parsedJson.extension) parsedJson.put("urn:ietf:params:scim:schemas:extension:enterprise:2.0:User", parsedJson.remove("extension"))
        if (parsedJson.extensionUserUuid) {
        if(parsedJson.extensionUserUuid.userUuid) {
            parsedJson.put("urn:ietf:params:scim:schemas:extension:sap:2.0:User", parsedJson.remove("extensionUserUuid"))
            parsedJson.get("schemas").add("urn:ietf:params:scim:schemas:extension:sap:2.0:User")

        }
        else{
            parsedJson.remove("extensionUserUuid")
     }
    }
    //Create an empty resource array if no resource is available in input 	
    if (!parsedJson.id && parsedJson.itemsPerPage) parsedJson.Resources = []

  }
  
  def respbody = JsonOutput.toJson(parsedJson)
  message.setBody(respbody)
  return message
}


//Store all business Roles
def Message storeAllGroupIds(Message message) {
    
    def body = message.getBody(String)
    def roleCollection = new XmlSlurper().parseText(body)
    
	 HashMap<String, String> businessRoles = new HashMap<>()
     for (role in roleCollection.IdentityBusinessRole)
        businessRoles.put(role.ID.text(),role.ObjectID.text())
            
    message.setProperty("businessRoles", businessRoles)        
      
    return message;
}
//
def Message calculateUserValidityEndDateAndFormatUserId(Message message){
    def map = message.getHeaders();
    def queryPath = map.get("CamelHttpPath");
    def formattedUUID = queryPath.replaceAll("-","");
    def objectID = formattedUUID.toUpperCase();
    message.setProperty("p_ObjectID", objectID);
    
    //Set User Validity End Date
    def userValidityEndDate = LocalDateTime.now().minusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"))
    message.setProperty("p_UserValidityEndDate",userValidityEndDate);

    return message;
}
