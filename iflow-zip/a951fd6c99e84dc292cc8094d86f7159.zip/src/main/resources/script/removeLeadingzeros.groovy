import com.sap.it.api.mapping.*;
def String removeLeadingzeros(String arg1){
    if(arg1.isNumber()){
        arg1 = arg1.replaceFirst("^0+(?!\$)", "");
    }
	return arg1 ;
}
