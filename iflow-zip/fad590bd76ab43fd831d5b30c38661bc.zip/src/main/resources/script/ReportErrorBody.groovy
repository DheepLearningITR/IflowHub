import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
    // Fetch message properties and initialize error body string.
    def properties = message.getProperties()
    def errorBody = ''

    // Check for any exceptions and add exception details to the error body.
    def exception = properties.get('CamelExceptionCaught')
    if (exception) {
        errorBody = 'ERROR: ErrorSendingEmail' + "\n"
        errorBody += 'Error in Send Email Notification Subprocess' + "\n"
        def exceptionProperties = exception.getProperties()
        errorBody += "Exception Class: " + exceptionProperties.get("class") + "\n"
        errorBody += "Message: " + exceptionProperties.get("message") + "\n"
    }

    // Check 'AttachExceptionError' property and attach ErrorDetails if condition met.
    def attachError = properties.getOrDefault("AttachExceptionError", "No").toLowerCase()
    if (["yes", "x", "true"].contains(attachError)) { // Condition Updated
        def messageLog = messageLogFactory.getMessageLog(message)
        if (messageLog != null) {
            messageLog.addAttachmentAsString('ErrorDetails', errorBody, 'text/plain')
        }
    }

    // Setting the error body string as the new message body.
    message.setBody(errorBody)

    return message
}