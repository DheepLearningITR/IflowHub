import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Base64;
import java.nio.ByteBuffer;
def Message processData(Message message) {
    def bodyBuffer = message.getBody(java.nio.ByteBuffer);
    byte[] bytes = bodyBuffer.array();
    String encodedBody = Base64.getEncoder().encodeToString(bytes);
    def prepareBody = '<ns1:getDocPdfResponse xmlns:ns1=\"http://www.sap.com/eDocument/Egypt/eInvoice/v1.0\">';
    prepareBody = prepareBody.concat('<ns1:docPdf>').concat(encodedBody).concat('</ns1:docPdf>').concat('</ns1:getDocPdfResponse>');
    message.setBody(prepareBody);
    return message;
}