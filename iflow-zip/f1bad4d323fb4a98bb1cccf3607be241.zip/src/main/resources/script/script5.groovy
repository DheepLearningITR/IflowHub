import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonException;

def Message processData(Message message) {
// Message header
    def headers = message.getHeaders();
    def errorMessage = "", statusCode = "";
//Generic error message
    errorMessage = "Refer the Message Id " + headers.get("SAP_MessageProcessingLogID");
    statusCode = "500";
    message.setProperty("errorMessage", errorMessage);
    message.setProperty("statusCode", statusCode);
    return message;
}
