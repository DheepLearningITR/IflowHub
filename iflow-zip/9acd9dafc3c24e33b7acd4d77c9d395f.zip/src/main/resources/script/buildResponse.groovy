import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;
import groovy.json.JsonOutput;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;

@Field String ERROR_SHORTTEXT = 'ERROR';
@Field String SUCCESS_SHORTTEXT = 'SUCCESS';
@Field String WARNING_SHORTTEXT = 'WARNING';
@Field String INFO_SHORTTEXT = 'INFO';

@Field String WARNING_NO_MESSAGES = 'Message list could not be retrieved.';
@Field String UNKNOWN_ERROR = 'An unknown error occurred.';
@Field String CPI_MSGID_TEXT = 'SAP Cloud Integration message ID: ';

class ResponseMsg {
	String type
	String message
}

def Message buildConfirmationResponse(Message message) {
	def headers = message.getHeaders();
	headers.put("Content-Type",   "application/json");
	
	def properties = message.getProperties();
	def response = [:];
	response["documentNumber"] = properties.get("salesOrderId");
	response["fulfillmentRequestId"] = properties.get("externalDocumentId");
	response["fulfillmentSystemId"] = properties.get("fulfillmentSystemId");

	List<ResponseMsg> respMsgs = [];
	try {
		def messageList = properties.get("messageList");
		int length = messageList.getLength();
		for (i = 0; i < length; i++) {
			respMsgs.add(convertS4Message((Element)messageList.item(i)));
		}
	} catch (Exception ex) {
		respMsgs.add(new ResponseMsg(type:WARNING_SHORTTEXT,message:WARNING_NO_MESSAGES));
		String exceptionText = 'Exception: ' + ex.getMessage();
		respMsgs.add(new ResponseMsg(type:WARNING_SHORTTEXT,message:exceptionText));
	}

	//Add CPI MsgID to messages
	respMsgs.add(new ResponseMsg(type:INFO_SHORTTEXT,message:CPI_MSGID_TEXT + properties.get("SAP_MessageProcessingLogID")));

	if (respMsgs.size() > 0){
		response["messages"] = respMsgs;
	}

	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(response)));
	return message;
}

def Message buildExceptionDetails(Message message) {

	def properties = message.getProperties();

	String errorMessage = "";
	def exceptionProperty;

	def response = [:];
	List<ResponseMsg> respMsgs = [];

	try {
		exceptionProperty = properties.get("CamelExceptionCaught");

		// an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
		if (exceptionProperty.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
			errorMessage = exceptionProperty.getResponseBody();
		}

		if (!errorMessage.trim()) {
			errorMessage = exceptionProperty.message;
		}
	} catch (Exception ex) {

	}

	errorMessage = (errorMessage.trim()) ? errorMessage.replaceAll("\\P{Print}", "") : UNKNOWN_ERROR;

	respMsgs.add(new ResponseMsg(type:ERROR_SHORTTEXT,message:errorMessage));

	//Add CPI MsgID to messages
	respMsgs.add(new ResponseMsg(type:INFO_SHORTTEXT,message:CPI_MSGID_TEXT + properties.get("SAP_MessageProcessingLogID")));

	response["messages"] = respMsgs;

	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(response)));
	return message;
}

def ResponseMsg convertS4Message(def msg){
	String severity = msg.getElementsByTagName("SeverityCode").item(0).getTextContent();
	String msgType = "";
	switch(severity) {
		case '1':
			msgType = SUCCESS_SHORTTEXT;
			break;
		case '2':
			msgType = WARNING_SHORTTEXT;
			break;
		case '3':
			msgType = ERROR_SHORTTEXT;
			break;
		default:
			msgType = INFO_SHORTTEXT;
			break;
	}
	String retMessage = msg.getElementsByTagName("Note").item(0).getTextContent();
	return new ResponseMsg(type:msgType,message:retMessage);
}
