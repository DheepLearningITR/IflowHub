/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
    
def Message processData(Message message) {
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    //Body 
    def body = message.getBody();
    def jsonSlurper = new JsonSlurper();
    def subscriptionsBody = jsonSlurper.parseText(body);

    def map = message.getProperties();
    def sourceSystem = map.get("SourceSystem");
   
    def subscriptions = subscriptionsBody.root.subscriptions;
    def entitlements = [];
    def root = [:];
    
    def subscription = [:];
    for (def i=0; i<subscriptions.size(); i++ ) {
        def entitlement = [:];
        def entitlementBody = [:];
        subscription = subscriptions[i];
        if (subscription) {
            entitlement['SourceSystem'] = sourceSystem;
            entitlement['CustomerID'] = subscription.customer.id;
            entitlement['DocumentNumber'] = subscription.documentNumber;
            entitlement['DocumentType'] = 'Subscription';
            entitlement['Item'] = [];
            entitlement['Status'] = subscription.status.replaceAll(' ', '_').toUpperCase();
            if (entitlement['Status'] == 'CANCELED') {
                entitlement['Status'] = 'CANCELLED';
            }
            
            def snapshot = subscription.snapshots[0];
            def items = snapshot.items;
            for (def j=0; j<items.size(); j++) {
                def entitlementItem = [:];
                def item = items[j];
                entitlementItem['ItemNumber'] = item.lineNumber;
                entitlementItem['OfferingID'] = item.product.code;
                entitlementItem['UoM'] = 'EA';
                entitlementItem['ItemValidFrom'] = getDateFromTimezone(subscription.validFrom, subscription.market.timeZone);
                if (subscription.validUntil) {
                    entitlementItem['ItemValidTo'] = getDateFromTimezone(subscription.validUntil, subscription.market.timeZone);
                } else {
                    entitlementItem['ItemValidTo'] = '99991231';
                }
                
                def subscriptionParameters = item.subscriptionParameters;
                def entitlementAttribute = '';
                for (def k=0; k<subscriptionParameters.size(); k++) {
                    entitlementAttribute = valueMapApi.getMappedValue('SAP Subscription Billing', 'Subscription Parameter', subscriptionParameters[k].code, 'SAP Entitlement Management', 'Interface Field');
                    if (entitlementAttribute != '' && entitlementAttribute != null) {
                        if (!entitlementItem[entitlementAttribute]) {
                            entitlementItem[entitlementAttribute] = subscriptionParameters[k].value;
                        }
                    } else {
                        if (!entitlementItem[subscriptionParameters[k].code]) {
                            entitlementItem[subscriptionParameters[k].code] = subscriptionParameters[k].value;
                        }
                    }
                }
                if (!entitlementItem['Quantity']) {
                    entitlementItem['Quantity'] = '1';
                }
                entitlement['Item'].push(entitlementItem);
            }
            
            entitlementBody['Inbound_Interface_Entitlement_Generation'] = [:];
            entitlementBody['Inbound_Interface_Entitlement_Generation']['Inbound_Interface_Entitlement_Generation'] = entitlement;
    
        }
        entitlements.push(entitlementBody);
    }

    root['entitlements'] = entitlements;

    body = JsonOutput.toJson(root);
    message.setBody(body);

    return message;
}

def String getDateFromTimezone(String inputDate, String timeZone) {
    def inputDateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    
    def outputDateFormat = "yyyyMMdd";
    def outputTZ = TimeZone.getTimeZone(timeZone);
    
    def date = Date.parse(inputDateFormat, inputDate);
    def convertedDate = date.format(outputDateFormat, outputTZ);
    return convertedDate;
}