/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
	def bodyFailed = "";
	def bodySucceed = "";
	def map = message.getProperties();
	def messageLog = messageLogFactory.getMessageLog(message);
	if (messageLog != null) {
	    if(map.get("FailedSubscriptions")) {
	        bodyFailed = "{\"FailedSubscriptions\":[" + map.get("FailedSubscriptions") + "]}";
	        messageLog.addAttachmentAsString("Failed subscriptions", bodyFailed, "text/json");
	    }
	    if(map.get("SucceedSubscriptions")) {
    	    bodySucceed = "{\"SucceedSubscriptions\":[" + map.get("SucceedSubscriptions") + "]}"
    		messageLog.addAttachmentAsString("Succeed subscriptions", bodySucceed, "text/json");
	    }
	}

    return message;
}

def Message logAllFailureResult(Message message) {
    def props = message.getProperties();
	def property_ENABLE_MPL_LOGGING = props.get("EnableLog");
	
    def body = message.getBody(java.lang.String) as String;
    if(body.length() == 0) {
        message.setBody("empty");
        message.setProperty("FailedIDs","nullData");
    } else {
        if("TRUE".equalsIgnoreCase(property_ENABLE_MPL_LOGGING)){
            body = '<Failure>' + body + '</Failure>';
            def messageLog = messageLogFactory.getMessageLog(message);
            if (messageLog != null) {
                messageLog.addAttachmentAsString("All subscriptions - failure", body, "text/xml");
            }
        }
    }
	   
    return message;
}

def Message logAllSuccessResult(Message message) {
    def props = message.getProperties();
	def property_ENABLE_MPL_LOGGING = props.get("EnableLog");
	if("TRUE".equalsIgnoreCase(property_ENABLE_MPL_LOGGING)){
	    
	    def body = message.getBody(java.lang.String) as String;
        if(body.length() > 0){
            body = '<Success>' + body + '</Success>';
            def messageLog = messageLogFactory.getMessageLog(message);
	        if (messageLog != null) {
                messageLog.addAttachmentAsString("All subscriptions - success", body, "text/xml");
	        }
        }
	   
	}
    return message;
}