import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processDataGetBillIDs(Message message) {
    def map = message.getProperties();
    def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
        def body = message.getBody(java.lang.String) as String;
        def messageLog = messageLogFactory.getMessageLog(message);
        if (messageLog != null) {
            messageLog.addAttachmentAsString("SB_get_transfer_bills_response", body, "text/xml");
        }
    }
    return message;
}

def Message processDataContAcctResponse(Message message) {
    def map = message.getProperties();
    def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
    def body = message.getBody(java.lang.String) as String;
    def billLogID = map.get("billLogID");
    def BPID = map.get("RCCustomerNumber");
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
            messageLog.addAttachmentAsString("Bill(" + billLogID + ")_cont_acct_BP(" + BPID + ")_return_msg", body, "text/xml");
        }
    }
    return message;
}

def Message processDataCreateBITResponse(Message message) {
    def map = message.getProperties();
    def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
    def body = message.getBody(java.lang.String) as String;
    def billLogID = map.get("billLogID");
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
            messageLog.addAttachmentAsString("Bill(" + billLogID + ")_return_msg", body, "text/xml");
        }
    }
    return message;
}

def Message processDataUpdateBillStatusOfBillingdoc(Message message) {
    def map = message.getProperties();
    def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
    def body = message.getBody(java.lang.String) as String;
    def billLogID = map.get("billLogID");
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
            messageLog.addAttachmentAsString("Bill(" + billLogID + ")_billingdoc_status_update_req", body, "text/json");
        }
    }
    return message;
}

def Message processDataUpdateBillStatusOfInvoice(Message message) {
    def map = message.getProperties();
    def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
    def body = message.getBody(java.lang.String) as String;
    def billLogID = map.get("billLogID");
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
            messageLog.addAttachmentAsString("Bill(" + billLogID + ")_invoice_status_update_req", body, "text/json");
        }
    }
    return message;
}