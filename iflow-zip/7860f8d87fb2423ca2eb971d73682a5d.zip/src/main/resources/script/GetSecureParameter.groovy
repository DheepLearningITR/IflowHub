import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.net.URLEncoder;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
def Message processData(Message message) {
	def body = message.getBody();
	map = message.getProperties();
	def credential_Id_name = map.get("CredentialClientIDName");
	def credential_Secret_name = map.get("CredentialClientSecretName");
	def service =  ITApiFactory.getApi(SecureStoreService.class, null);
	
	def credential_Id = service.getUserCredential(credential_Id_name);
// 	String password_Id = URLEncoder.encode(new String("sb-revenue-cloud!b2115|revenue-cloud!b1532"), "UTF-8");
    String password_Id = URLEncoder.encode(new String(credential_Id.getPassword()), "UTF-8");
	
	def credential_Secret = service.getUserCredential(credential_Secret_name);
// 	String password_Secret = URLEncoder.encode(new String("PLMGpmB2srSPdYuwFtbEj+m7agg="), "UTF-8");
    String password_Secret = URLEncoder.encode(new String(credential_Secret.getPassword()), "UTF-8");

	message.setProperty("KFP_RC_ClientId",password_Id);
	message.setProperty("KFP_RC_ClientSecret",password_Secret);
	return message;
}
