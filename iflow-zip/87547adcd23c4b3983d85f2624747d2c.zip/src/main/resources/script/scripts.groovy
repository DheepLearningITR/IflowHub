import com.sap.gateway.ip.core.customdev.util.Message;

def Message createQuery(Message message) {
   
    def headers = message.getHeaders();
    def lang = headers.get("language")
    
    if (lang.length() == 0 ){
        lang = "EN"
        message.setProperty("P_Language",lang)
    }
    
    message.setProperty("P_CustomQuery", "sap-language="+lang)
    
    return message
}