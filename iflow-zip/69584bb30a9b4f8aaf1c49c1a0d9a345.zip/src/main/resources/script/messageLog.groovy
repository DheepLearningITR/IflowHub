import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message payload_RC_bpRelationship(Message message) {
	def map = message.getProperties();
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
		def body = message.getBody(java.lang.String) as String;
		def customerNumberInRC = map.get("customerBPIdInRC") as String;
		def contactNumberInRC = map.get("contactBPIdInRC") as String;
		def customerNumberInS4 = map.get("customerBPIdInS4") as String;
		def contactNumberInS4 = map.get("contactBPIdInS4") as String;
		def messageLog = messageLogFactory.getMessageLog(message);

		if (messageLog != null) {
			messageLog.addAttachmentAsString("S4Relatinship(" + customerNumberInS4 + "_" + contactNumberInS4 + ")_SB(" + customerNumberInRC+"_" + contactNumberInRC + ")_update_req", body, "text/json");
		}
	}
	return message;
}

def Message get_RC_customer_failed(Message message) {
	def map = message.getProperties();
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
		def customerNumberInS4 = map.get("customerBPIdInS4") as String;
		def contactNumberInS4 = map.get("contactBPIdInS4") as String;
		def body = "The replationship cannot be replicated since business partner " + customerNumberInS4 + " cannot be found in SAP Subscription Billing.";
		def messageLog = messageLogFactory.getMessageLog(message);

		if (messageLog != null) {
			messageLog.addAttachmentAsString("S4Relatinship(" + customerNumberInS4 + "_" + contactNumberInS4 + ")_get_SB_customer_failed", body, "text/plain");
		}
	}
	return message;
}

def Message get_RC_contact_failed(Message message) {
	def map = message.getProperties();
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
		def customerNumberInS4 = map.get("customerBPIdInS4") as String;
		def contactNumberInS4 = map.get("contactBPIdInS4") as String;
		def body = "The replationship cannot be replicated since business partner " + contactNumberInS4 + " cannot be found in SAP Subscription Billing.";
		def messageLog = messageLogFactory.getMessageLog(message);

		if (messageLog != null) {
				messageLog.addAttachmentAsString("S4Relatinship(" + customerNumberInS4 + "_" + contactNumberInS4 + ")_get_SB_contact_failed", body, "text/plain");
		}
	}
	return message;
}

def Message nonCorporateCustomerNotSupported(Message message) {
	def map = message.getProperties();
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
		def customerNumberInS4 = map.get("customerBPIdInS4") as String;
		def contactNumberInS4 = map.get("contactBPIdInS4") as String;
		def body = "The relationship will not be replicated. Only customer-contact relationships of a business partner of the category Organization can be replicated to SAP Hybris Revenue Cloud.";
		def messageLog = messageLogFactory.getMessageLog(message);

		if (messageLog != null) {
				messageLog.addAttachmentAsString("S4Relatinship(" + customerNumberInS4 + "_" + contactNumberInS4 + ")_skip_non_corporate_customer", body, "text/plain");
		}
	}
	return message;
}

def Message LogRelationshipDeleteRequest(Message message) {
	def map = message.getProperties();
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
		def customerNumberInRC = map.get("customerBPIdInRC") as String;
		def contactNumberInRC = map.get("contactBPIdInRC") as String;
		def customerNumberInS4 = map.get("customerBPIdInS4") as String;
		def contactNumberInS4 = map.get("contactBPIdInS4") as String;
		def body = "The delete request will be sent to SAP Hybris Revenue Cloud.";
		def messageLog = messageLogFactory.getMessageLog(message);

		if (messageLog != null) {
				messageLog.addAttachmentAsString("S4Relatinship(" + customerNumberInS4 + "_" + contactNumberInS4 + ")_SB(" + customerNumberInRC+"_" + contactNumberInRC + ")_delete_req", body, "text/plain");
		}
	}
	return message;
}