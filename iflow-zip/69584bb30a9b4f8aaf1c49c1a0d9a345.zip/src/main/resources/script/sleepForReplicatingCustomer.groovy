import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;


def Message sleepSeconds(Message message) {
	Thread.sleep(30000);
	return message;
}
