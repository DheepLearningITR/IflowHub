/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.UUID; 
import java.lang.String;
import com.sap.it.api.mapping.*;

def Message setLogCustomHeaders(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
	
	if(messageLog != null){
	    def headers = message.getHeaders();
	    def ibpReads = headers.get("IBPReads");
	    def properties = message.getProperties()
	    def messageCounter = properties.get("MessageCounter")
	    messageCounter = messageCounter != null ? messageCounter : '' 
	    
	    //def readOffset = headers.get("IBPReadOffset1");
	    if(ibpReads != null){
    	    def xmlReads = new XmlSlurper().parse(new StringReader(ibpReads));
    	    
    	    xmlReads.children()?.@Key.each { } collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Read Key", it2) };	
    	    xmlReads.children()?.@Destination.each { } collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Destination", it2) };	
    	    xmlReads.children()?.@UUID.findAll {it.text() != ''} collect{ messageLog.addCustomHeaderProperty('IBP Read UUID', it.text()) }; 
	    }

        messageLog.addCustomHeaderProperty(messageCounter + ' ExceptionMessage', headers.get('ExceptionMessage'))
        messageLog.addAttachmentAsString(messageCounter + ' ExceptionStackTrace',headers.get('ExceptionStackTrace'),'text/xml')

	    
	}

	
	return message;
}

def Message addBodyToLog(Message message){
    
    
    	/*add message body to logs in case of an exception.*/
	def bodyAsString = message.getBody(java.lang.String);
	def properties = message.getProperties()
	def messageCounter = properties.get("MessageCounter") as String
	messageCounter = messageCounter != null ? messageCounter : '' 
	def messageLog = messageLogFactory.getMessageLog(message);
	
	if(messageLog != null){
	    messageLog.addAttachmentAsString(messageCounter + ' Latest message body', bodyAsString, 'text/xml');
	}
    return message;
}


def Message addResultsToLog(Message message) {

	def headers = message.getHeaders();
	def ibpMessages = headers.get("FetchMessages");
	def messageLog = messageLogFactory.getMessageLog(message);
	def properties = message.getProperties()
	def messageCounter = properties.get("MessageCounter") as String
	messageCounter = messageCounter != null ? messageCounter : '' 

	def messageTruncated = false;
	if (ibpMessages != null) {
        if(messageLog != null){
            messageLog.addAttachmentAsString(messageCounter + " FetchMessages",ibpMessages,'text/xml')
        }
	}
	return message;
}

def Message notAllPackageOK(Message message){
    def messageLog = messageLogFactory.getMessageLog(message);
	
	if(messageLog != null){
	    def headers = message.getHeaders();
    	def ibpReads = headers.get("IBPReads");
        messageLog.addCustomHeaderProperty('Escalation Message', 'Not all packages OK')
        messageLog.addAttachmentAsString("FetchMessages",headers.get('FetchMessages'),'text/xml')
        
        if(ibpReads != null){
        	def xmlReads = new XmlSlurper().parse(new StringReader(ibpReads));
        	    
            xmlReads.children()?.@Key.each { } collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Read Key", it2) };	
            xmlReads.children()?.@Destination.each { } collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Destination", it2) };	
            xmlReads.children()?.@UUID.findAll {it.text() != ''} collect{ messageLog.addCustomHeaderProperty('IBP Read UUID', it.text()) }; 
        }
	}
    return message
}
