/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.lang.String;
import com.sap.it.api.mapping.*;


def Message logMessages(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
	
	if(messageLog != null){
	    def messages = '';
	    def headers = message.getHeaders();
        def status = ''
        def body = message.getBody(java.io.Reader);
 	    def xmlReadPackages = new XmlSlurper().parse(body);
 	    xmlReadPackages?.'**'.findAll {it.name() == 'FETCHMESSAGES' }.each { it2 -> messages = "${messages}${it2.text()}\n" };//&& it.child[1].text() != ''
 	    //xmlReadPackages?.'**'.findAll {it.name() == 'MESSAGE' && it.text() != ''} collect{it.text()}.each { it2 -> messages = "$messages ${it2}\n"};
 	    def obj = xmlReadPackages.'**'.find(){ it-> it.name() == 'FETCHSTATUS' && !['FETCH_DATA','FINISHED'].contains(it.text()) }
 	    if (obj != null){ message.setHeader('FetchStatus',obj.text()) }     //.each {it2 -> status = "${it2.text();${status}}"}
 	    
 	    message.setHeader('FetchMessages',messages)

	}
	return message;
}

def String mapAbapMessageTypeToString(String abapMessageType) {
    switch (abapMessageType) {
        case 'A': return 'Abort';
        case 'E': return 'Error';
        case 'W': return 'Warning';
        case 'I': return 'Information';
        case 'S': return 'Success';
        default: return abapMessageType;
    }
}
