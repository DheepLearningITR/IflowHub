/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.lang.String;
import com.sap.it.api.mapping.*;


def Message addLogToHeader(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
	
	if(messageLog != null){
	    def messages = '';
	    def headers = message.getHeaders();
	    def properties = message.getProperties()
	    def messageCounter = properties.get("MessageCounter") as String
 
        def body = message.getBody(java.io.Reader);
 	    def xmlReadPackages = new XmlSlurper().parse(body);
 	    xmlReadPackages?.'**'.findAll {it.name() == 'item' }.each { it2 -> messages = "$messages [${mapAbapMessageTypeToString(it2.TYPE.text())}] ${it2.MESSAGE.text()}\n" };//&& it.child[1].text() != ''
 	    //xmlReadPackages?.'**'.findAll {it.name() == 'MESSAGE' && it.text() != ''} collect{it.text()}.each { it2 -> messages = "$messages ${it2}\n"};
 	    def status = xmlReadPackages.'**'.find(){ it-> it.name() == 'EV_QUERY_STATUS' }.text()
 	    message.setHeader('FetchStatus', status)
 	    
 	    if(messageCounter != null){
 	         message.setHeader('FetchMessages',"Fetch Status: ${status} Message Number: ${messageCounter}\n" + messages)
 	    }
 	    else{
 	         message.setHeader('FetchMessages',"Fetch Status: ${status}\n" + messages)
 	    }


	}
	return message;
}

def String mapAbapMessageTypeToString(String abapMessageType) {
    switch (abapMessageType) {
        case 'A': return 'Abort';
        case 'E': return 'Error';
        case 'W': return 'Warning';
        case 'I': return 'Information';
        case 'S': return 'Success';
        default: return abapMessageType;
    }
}
