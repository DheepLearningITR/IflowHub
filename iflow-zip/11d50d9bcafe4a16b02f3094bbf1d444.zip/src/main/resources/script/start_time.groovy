import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.time.TimeCategory; 
import groovy.time.TimeDuration;


def Message SetStartTime(Message message) {
    
    Date start = new Date();
    
    message.setHeader("start_time", start);
    
    return message;
}


def Message SetMapStartTime(Message message) {
    
    Date startTime = new Date();
    
    message.setHeader("map_start_time", startTime);
    
    return message;
}

