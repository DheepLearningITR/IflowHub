import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.time.TimeCategory; 
import groovy.time.TimeDuration;


def Message SetStopTime(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    def headers = message.getHeaders();
    
    Date stop = new Date();
    def start_time = headers.get("start_time");
    def map_start_time = headers.get("map_start_time");

    TimeDuration runtime = TimeCategory.minus( map_start_time,start_time );
    TimeDuration runtimeMapping = TimeCategory.minus( stop,map_start_time );

    String result = headers.get("IBPFetchDataPackageRuntime") + "Fetch Start: " + start_time.toString() +" Fetch Stop: " + map_start_time.toString() + " Fetch Runtime: " + runtime.toString() + "Map Start: " + map_start_time.toString() +" Map Stop: " + stop.toString() + " Map Runtime: " + runtimeMapping.toString();

    message.setHeader("IBPFetchDataPackageRuntime", result);

    return message;
}