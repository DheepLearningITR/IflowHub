/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import javax.activation.DataHandler
def Message processData(Message message) {
    //Body 
       def body = message.getBody(String.class);
      
    //Properties 
       map = message.getProperties();
       JsonSlurper slurper = new JsonSlurper();
       Map parsedJson = slurper.parseText(body);
       if(parsedJson.d !=null)
       {
       parsedJson.d.remove('__metadata')
       }
       def payload = new groovy.json.JsonBuilder()
       if(parsedJson.d !=null)
       {
       def root = payload {
              processDefinitionId map.get("processDefinitionId") 
              processInstanceId  map.get("processInstanceId")
              eventType  map.get("eventType")
              timestamp  map.get("timestamp")
              context(
                       parsedJson.d
                       
                     )
                          }
       }
       else
       {
           def root = payload {
              processDefinitionId map.get("processDefinitionId") 
              processInstanceId  map.get("processInstanceId")
              eventType  map.get("eventType")
              timestamp  map.get("timestamp")
                              }
       }
       
       message.setBody(payload.toString());
       message.setHeader("Content-Type","application/json");
       
       def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment");
        messageLog.addAttachmentAsString("ResponsePayload:", payload.toString(), "text/plain");
     }
    return message;
}
