/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import javax.activation.DataHandler


def Message processData(Message message) {
       def body =message.getBody(String.class);
       JsonSlurper slurper = new JsonSlurper();
       Map parsedJson = slurper.parseText(body);
       
       //Retrieve processDefinitionId & contextEnity attributes from rules response
       def processDefinitionId = parsedJson.Result[0].ContextPathforRetrieval.BusinessObjectKey;
       String contextEntity = parsedJson.Result[0].ContextPathforRetrieval.ContextPathURL;
       
       //Set processDefinitionId and ContextEntity as exchange parameters
   
       
      //Properties 
       map = message.getProperties();
       def s4event=map.get("s4event")
       message.setProperty("processDefinitionId", processDefinitionId);
       if (contextEntity != null)
       {
       message.setProperty("contextEntity", contextEntity);
       }
       
       //def value = map.get("processDefinitionId");
       //Prepare to call the API to retrieve context for Business Object
    
    //	def body =message.getBody(String.class);
        //JsonSlurper slurper = new JsonSlurper();
        Map s4eventJson = slurper.parseText(s4event);
        String InstanceID = s4eventJson.data."$processDefinitionId";
       
       //Replace processInstanceId with the Business Object instance
       if (contextEntity != null)
       {
       String relativepath=map.get("contextEntity");
       relativepath=relativepath.replaceAll('processInstanceId',InstanceID.toString())
       message.setProperty("relativeURL", relativepath);
       }
        message.setProperty("processInstanceId", InstanceID);
    
        def propertyMap = message.getHeaders();
        message.setHeader("Accept","application/json");
           
       
       return message;
}