import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Payload", body, "text/plain");
		}
	}
	return message;
}

def Message validateRequest(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("FacileValidateRequest", body, "text/plain");
		}
	}
	return message;
}

def Message validateResponse(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("FacileValidateResponse", body, "text/plain");
		}
	}
	return message;
}

def Message DTERequest(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("FacileDTERequest", body, "text/plain");
		}
	}
	return message;
}

def Message DTEResponse(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("FacileDTEResponse", body, "text/plain");
		}
	}
	return message;
}

def Message DTEPDFResponse(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("FacileDTEPDFResponse", body, "text/plain");
		}
	}
	return message;
}


def Message logSAPResp(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Response to SAP", body, "text/plain");
		}
	}
	return message;
}
