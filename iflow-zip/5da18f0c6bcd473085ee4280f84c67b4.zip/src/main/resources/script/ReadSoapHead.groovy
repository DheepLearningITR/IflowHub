package script

import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def xmlSlurper = new XmlSlurper()

    def body= message.getBody(Reader)
    def parsedXMLBody= xmlSlurper.parse(body)
    def propertyMap = message.getProperties()

    String lbnDocumentRootName 		= ""
    try{
        lbnDocumentRootName = parsedXMLBody.name().localPart
    } catch (ignored) {
        lbnDocumentRootName = parsedXMLBody.name()
    }

    if (lbnDocumentRootName != "" && lbnDocumentRootName != null) {
        message.setProperty("lbnDocumentRootName",lbnDocumentRootName)
    }

    if (lbnDocumentRootName == null || lbnDocumentRootName == ""){
        throw new IllegalStateException("Received DocumentRootName does not has a valid element");
    }

    //-------------------------------------------------------------------------
    // LBN IDs | Docment Id
    //-------------------------------------------------------------------------
    // LBN IDs must be maintaind:
    // Receiver (Mostly Carrier): Carrier BP 	-> BP Identification -> ID Type = "LBN001"
    // Sender (Always Shipper/Ordering Party) 	-> Purchasing Organization used -> TA ppome Org. Data -> assigned BP -> maintain Identification -> ID Type = "LBN001" of the assigned BP
    String lbnReceiver             = (parsedXMLBody.MessageHeader.RecipientParty.StandardID.find{ StandardID -> StandardID.@schemeAgencyID == "310" }).toString()
    String lbnSender               = (parsedXMLBody.MessageHeader.SenderParty.StandardID.find{ StandardID -> StandardID.@schemeAgencyID == "310" }).toString()
    String lbnRecipientSystemID    = (parsedXMLBody.MessageHeader.RecipientBusinessSystemID).toString()

    String lbnPassport = propertyMap.get("lbn-passport");
    message.setHeader("sap-passport", lbnPassport);
    
    //-------------------------------------------------------------
    // Set Message Headers - Monitoring
    //-------------------------------------------------------------
    if (lbnSender != "" && lbnSender != null) {
        message.setHeader("SAP_Sender", lbnSender)
    }

    if (lbnReceiver != "" && lbnReceiver != null) {
        message.setHeader("SAP_Receiver", lbnReceiver)
    }

    if (lbnDocumentRootName != "" && lbnDocumentRootName != null) {
        message.setHeader("SAP_MessageType", lbnDocumentRootName)
    }

    if (lbnRecipientSystemID != "" && lbnRecipientSystemID != null) {
        message.setHeader("SAP_RecipientSystemID", lbnRecipientSystemID)
    }
    message.setProperty("lbnLogging", true)
    return message;
}


