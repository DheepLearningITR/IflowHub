package script

import com.sap.it.api.mapping.ValueMappingApi
import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService

def Message processData(Message message) {
    def headerMap = message.getHeaders()
    def recipientSystemID = headerMap.get("SAP_RecipientSystemID")
    def messageType = headerMap.get("SAP_MessageType")

    // verify the value mapping is configured for recipient system and Message type
    String inputValue = recipientSystemID + ":" + messageType
    def valueMappingService = ITApiFactory.getService(ValueMappingApi.class, null)
    def mappedValue = valueMappingService.getMappedValue("Target System", "Message Type", inputValue, "Destination", "Url")
    if (mappedValue != null) {
        message.setProperty("lbnB2BUrl", mappedValue)
    } else {
        throw new Exception("Destination url is not configured for "+recipientSystemID+" system with message type "+messageType)
    }

    // verify if recipient credentials is configured
    def credentialAlias = recipientSystemID + "_" + "credential"
    def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)
    def credential = secureStorageService.getUserCredential(credentialAlias)
   
    if (credential != null){
        message.setProperty("credentials", credentialAlias);
    } else {
        throw new Exception("No Credentials uploaded for "+recipientSystemID+ " in security materials");
    }

    return message
}
