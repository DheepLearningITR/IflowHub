/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.camel.Exchange;
import java.io.IOException;
def Message setNameSpace(Message message) {

    //Properties 
       properties = message.getProperties();
	   def document = properties.get("document");
    //Define namespace	
	   if ( document == 'Invoice' ) {
 	    namespace = '"http://www.sap.com/eDocument/Portugal/Invoice/v1.0"';
 	    endpoint = '/async/plain/ProcessDocument/country/PT/Invoice/false';
	   }
	   else {
	    if (document == 'CreditNote')
	    namespace = '"http://www.sap.com/eDocument/Portugal/CreditNote/v1.0"';
 	    endpoint = '/async/plain/ProcessDocument/country/PT/Credit_Note/false';
	   }
       message.setProperty('namespace', namespace);
    //Properties 
       properties = message.getProperties();
    //Headers
       headers = message.getHeaders();
       mode = headers.get("Mode");
       if (!mode){
        query = headers.get("CamelHTTPQuery");
        def params = URLEncodedUtils.parse( new URI ( '?' + query), 'UTF-8' );
        if ( params )
          mode = params.find { it -> it.getName().equalsIgnoreCase( "mode" ) }?.getValue();
          message.setHeader( 'Mode', params.find { it -> it.getName().equalsIgnoreCase( "mode" ) }?.getValue() );
       }  
           
       if(mode == 'TEST') {
        api_url = headers.get("TEST_API_URL");
       }
       else {
        if(mode == 'PROD') 
       api_url = headers.get("PROD_API_URL");
       else
        throw new Exception( "Communication Mode: " + mode + " is Wrong; Only 'TEST' or 'PROD' are allowed");
        }

   //Set Desitnation URLs
        message.setProperty( 'TokenURL', api_url + '/Account/token' );
        message.setProperty( "SendInvoiceURL", api_url + endpoint );
    return message;
}

def Message getUserCredential(Message message) {

    //Headers
       headers = message.getHeaders();
    //Properties 
       properties = message.getProperties();

       VATNO = properties.get("VATNO");
     def userCredentialName = VATNO + "_" + mode;   
	//Access the Service Provider credentials
	   def credservice = ITApiFactory.getApi(SecureStoreService.class, null);
	   def credential = credservice.getUserCredential(userCredentialName);
       String userName = credential.getUsername();
       String password = new String(credential.getPassword());
    //Set User credentials to Properties
	   message.setProperty('user', userName);
	   message.setProperty('password', password);       
    return message;
}

def Message getAuthorizationToken(Message message) {
    //Properties
       def properties = message.getProperties();
       def value = properties.get("Token");
       message.setHeader("Authorization", "Bearer " + value);
       return message;
}

def Message getException(Message message) {
	
	def map = message.getProperties();
	try{	
	def ex = map.get("CamelExceptionCaught");
	if (ex!=null){
    	message.getProperties().put("statusCode", ex.getStatusCode());
		if (ex instanceof org.apache.cxf.interceptor.Fault) {
			message.getProperties().put("statusCode", ex.getFaultCode());
			if (ex.getCause() instanceof org.apache.cxf.transport.http.HTTPException)
				message.getProperties().put("message", ex.getCause().getMessage());
				message.getProperties().put("statusCode", ex.getCause().getResponseCode());
		}	
	}
	} catch (Exception ex01) {}
    return message;
    
}