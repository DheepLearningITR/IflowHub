import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String);
    
    message.setProperty("InputJSONString",body);
     message.setProperty("original_payload",body);

    
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body.toString());
    def root = object.value;
   

    def identifier =  message.getHeader("queryParameter",java.lang.String)
    message.setHeader("identifier",identifier);
    return message;
}