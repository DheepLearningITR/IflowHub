import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.util.*;
import groovy.xml.*;
import org.codehaus.*;
import java.util.HashMap;

def Message processData(Message message) {
      //   message.setHeader("CamelHttpResponseCode",'200');
        // message.setHeader("httpstatuscodes",'OK');
         message.setHeader("result","");
         message.setHeader("errorMessage", "");
         
   
     return message;
}
