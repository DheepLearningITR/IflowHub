import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

  def Message processData(Message message) {
    def body = message.getProperty("InputJSONString");

    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body)

    def builder = new JsonBuilder()
    
    def items = object.A_CustomerReturnItemType.collect { item ->

    // Create a new map for the modified item without "Customer Return Item" and "Customer Return" attributes
    def modifiedItem = [
        'method': 'PATCH',
        'uri': "A_CustomerReturnItem(CustomerReturn='"+item.DocumentIdentifier+"',CustomerReturnItem='"+item.ItemNumber+"')",
        'A_CustomerReturnItem': [
            'A_CustomerReturnItemType': item.findAll { key, _ -> key != 'DocumentIdentifier' && key != 'ItemNumber' }
        ]
    ]
    modifiedItem
    }

    def output = [
      'batchParts': [
        'batchChangeSet': [
          [
            'batchChangeSetPart': items
          ]
        ]
      ]
    ]
    
    builder(output)
    
    String finalPayload = builder.toPrettyString()
    message.setBody(finalPayload)
    
    return message
  }