import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {

  def messageBody = message.getBody(java.lang.String);

  // Parse the JSON string
  def jsonSlurper = new JsonSlurper()
  def json = jsonSlurper.parseText(messageBody)

  def batchChangeSetPartResponse = json.batchPartResponse.batchChangeSetResponse.batchChangeSetPartResponse
  
  // Check if the JSON response is not an array and convert it into a single-element array if needed
  def jsonArray = checkAndConvertToArray(batchChangeSetPartResponse)

  // Extract "sap-message" and "statusCode" values for each element in "batchChangeSetPartResponse"
  jsonArray.each {
    response ->
    def body = response.body
    if (body) {
      // Remove backslashes from the XML string
      def cleanedXmlString = body.replace('\\', '')
      
      def xml = new XmlSlurper().parseText(cleanedXmlString)
      def messageContent = xml.message.text()
      messageContent = message.getHeader("identifier",java.lang.String)+": "+messageContent
      message.setHeader("errorMessage", messageContent);
      message.setHeader("result", "Failed");
      
    } else if (response.headers.'sap-message') {
      def sapMessage = response.headers.'sap-message'
      
      def cleanedXmlString = sapMessage.replace('\\', '')
      
      def xml = new XmlSlurper().parseText(cleanedXmlString)
      def messageContent = xml.message.text()
      message.setHeader("result", messageContent);
    }

    if (response.statusCode) {
      def statusCode = response.statusCode
      message.setHeader("statusCode", statusCode);
    }
  }

  return message;
}

def checkAndConvertToArray(value) {
    if (value instanceof List) {
        // If value is already an array, return as is
        return value
    } else {
        // If value is not an array or a map, convert it to a single-element array
        return [value]
    }
}

