import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
import groovy.xml.*
def Message processData(Message message) {
   
    
   def body= message.getProperty("InputJSONString");
    
	def newBody="{\"A_CustomerReturnItemType\":["+body +"]}";

  message.setBody( newBody);
    return message;
}