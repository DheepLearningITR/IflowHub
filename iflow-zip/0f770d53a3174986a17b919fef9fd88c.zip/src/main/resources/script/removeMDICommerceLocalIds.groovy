import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String);
    def rootNode = new XmlSlurper().parseText(body);
    
        rootNode.Product.value.localIds.each{it->
         if(it.context.application == "MDI" || it.context.application == "Commerce")
        it.replaceNode{};
        }
        
        message.setBody(XmlUtil.serialize(rootNode));

       return message;
}