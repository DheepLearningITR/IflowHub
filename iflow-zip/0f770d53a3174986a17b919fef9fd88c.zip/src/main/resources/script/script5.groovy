import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil

def Message processData(Message message) {
  def body = message.getBody(java.lang.String) as String;

  body = body.replaceAll("<multimap:Messages", "");
  body = body.replaceAll("xmlns:multimap=", "");
  body = body.replaceAll("\"http://sap.com/xi/XI/SplitAndMerge\">", "");
  body = body.replaceAll("<multimap:Message1>", "");
  body = body.replaceAll("</multimap:Message1>", "");
  body = body.replaceAll("</multimap:Messages>", "");
  body = body.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();

  message.setBody(body);
  return message;
}