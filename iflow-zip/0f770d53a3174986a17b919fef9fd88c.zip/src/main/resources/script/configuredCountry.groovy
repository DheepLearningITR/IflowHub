import com.sap.it.api.mapping.*;

def String configuredCountry(String arg1, MappingContext context){
	def country = context.getProperty(arg1);
    return country;

}