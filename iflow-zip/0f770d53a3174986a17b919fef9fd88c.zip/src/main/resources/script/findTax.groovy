import com.sap.it.api.mapping.*;
import java.util.HashMap;
import groovy.xml.XmlUtil

def String taxCodeForGivenCountry(String arg, String Country){
   def tax;
   def payload = new XmlSlurper().parseText(arg);
   payload.each{it->
   
   if(it.country.code.text() == Country){
   tax = it.taxType.code.text();
   break;
   }


}
   return '';
}