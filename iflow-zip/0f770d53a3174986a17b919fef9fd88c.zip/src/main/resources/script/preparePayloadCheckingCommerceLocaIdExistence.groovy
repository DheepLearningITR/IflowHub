import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String);
       def map = message.getProperties();
    def rootNode = new XmlSlurper().parseText(body);
    def localIdExists;
    
       rootNode.Product.value.each{it-> 
         
             it.localIds.each{its->
             
             if(its.context.application == "Commerce")
             localIdExists = true;
             }
             
             if(localIdExists == true)
             it.replaceNode{};
             
             localIdExists = '';
       }
             
    
        // XmlUtil.serialize(rootNode);
        
        // if(rootNode == null)
        // map.idExists = 'false';
        
        message.setBody( XmlUtil.serialize(rootNode));
        map.test = rootNode;

       return message;
}