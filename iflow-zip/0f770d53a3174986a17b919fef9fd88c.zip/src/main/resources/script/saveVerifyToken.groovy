import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
def Message processData(Message message) {
       def body = message.getBody(java.lang.String) as String;
       def map = message.getProperties();
       String value,token;
       String[] values;
      
    //   def jsonParser = new JsonSlurper();
    //   def payload = jsonParser.parseText(body);
       
    //   map.moreEventsToken = payload.hasMoreEvents;
       
    //   if(payload.value[0] != null){
           
           if(map.verifyOdataNextLink){
                value = map.verifyOdataNextLink;
                map.moreEventsToken = true;
           }
           else{

                 if(map.verifyOdataDeltaLink){
                   value = map.verifyOdataDeltaLink;
                   map.moreEventsToken = false;
                   }
                }
                
    if(value)
     values = value.split('=');
     map.values = values;
    //  if(values[1])
     token = values[1];    
                
       
       
       map.verifyQuery = '$deltatoken=' +token;
       if (map.moreEventsToken == false){
       map.verifyToken = token;
       }
       map.verifyOdataNextLink = '';
       map.verifyOdataDeltaLink = '';

       return message;
}