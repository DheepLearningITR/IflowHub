import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String);
    def rootNode = new XmlSlurper().parseText(body);

   rootNode.batchChangeSet.each{it->
   
   if(it.batchChangeSetPart.Products.Product.sapPlant == null)
   it.replaceNode{};
   }
   
   message.setBody(XmlUtil.serialize(rootNode));
   
   return message;
}
