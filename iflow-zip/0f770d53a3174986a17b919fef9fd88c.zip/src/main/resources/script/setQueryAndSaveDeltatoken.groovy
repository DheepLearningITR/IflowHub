import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil

 def Message processData(Message message) {

      def body = message.getBody(java.lang.String) as String;
      def map = message.getProperties();
     def  rootNode = new XmlSlurper().parseText(body);
     String[] values;
 
      String value,token;
//removeEmptyPlants

    
        rootNode.Product.value.each{it->
         if(it.instance.plants == "" )
          it.instance.plants.replaceNode{};
        
         if(it.instance.salesAspect.salesTaxes == "" )
        it.instance.salesAspect.salesTaxes.replaceNode{};
        
         if(it.instance.description == "" )
          it.instance.description.replaceNode{};
          
         if(it.instance.name == "" )
          it.instance.name.replaceNode{};
        
        if(it.instance.salesAspect.salesDistributionChains == "" )
        it.instance.salesAspect.salesDistributionChains.replaceNode{};
        
        
 }
        
        message.setBody(XmlUtil.serialize(rootNode));


 //extractQueryParameters      
           if(map.odataNextLink){
                value = map.odataNextLink;
                 map.moreEvents = true;
           }
      
           else{

           if(map.odataDeltaLink){
           value = map.odataDeltaLink;
           map.moreEvents = false;
           }
              }
      
     if(value)
     values = value.split('=');
     map.values = values;
     
     token = values[1];



      map.deltaToken = token;
      
      map.query = '$deltatoken=' +token;
      map.odataNextLink = '';
      map.odataDeltaLink = '';

      
      return message;
}