import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String) as String;
       def map = message.getProperties();
      
       def template = '''<batchChangeSetPart>
			<method>POST</method>
			<SAPExternalIds>
				<SAPExternalId>
					<integrationKey></integrationKey>
					<application>MDI</application>
					<tenantId>MDI</tenantId>
					<versionId></versionId>
					<externalId>df7a4419-c37f-4d70-b798-16ec32c86354</externalId>
					<item>
						<Product>
							<integrationKey></integrationKey>
							<code>Mint</code>
							<catalogVersion>
								<CatalogVersion>
									<integrationKey></integrationKey>
									<version>Staged</version>
									<catalog>
										<Catalog>
											<integrationKey></integrationKey>
											<id>Default</id>
										</Catalog>
									</catalog>
								</CatalogVersion>
							</catalogVersion>
						</Product>
					</item>
				</SAPExternalId>
			</SAPExternalIds>
		</batchChangeSetPart>'''
		
    def batch = '''<batchParts><batchChangeSet></batchChangeSet></batchParts>'''
    def catalog = map.Catalog;
    def payload = new XmlSlurper().parseText(body);
    def batchPayload = new XmlSlurper().parseText(batch);
    def templatePayload = new XmlSlurper().parseText(template);
    def catalogPayload  =  new XmlSlurper().parseText(catalog);
    String id,code,version,xml,xml1;

    payload.Product.value.each{it->
   
    if(it.instance.displayId){
                                 code = it.instance.displayId.text();
                                 
                                 catalogPayload.SAPProductSalesAreaToCatalogMapping.each{it2->

    
                                 if(it2.salesOrganization == it.instance.salesAspect.salesDistributionChains.salesOrganization.id.text() 
                                    && it2.distributionChannel == it.instance.salesAspect.salesDistributionChains.distributionChannel.code.text()){
                                     id = it2.catalogVersion.CatalogVersion.catalog.Catalog.id.text();
                                      version = it2.catalogVersion.CatalogVersion.version.text();
                                     }
                                else{
                                 if(!id)
                                 id = map.CatalogId; 
                                 if(!version)
                                 version = map.CatalogVersion;
                                  }
                                  }
                                  if(!id)
                                 id = map.CatalogId; 
                                 if(!version)
                                 version = map.CatalogVersion;
                                
                                  if(it.localIds){ 
                                                    it.localIds.each{

                                                    templatePayload.SAPExternalIds.SAPExternalId.application = it.context.application.text();
                                                    templatePayload.SAPExternalIds.SAPExternalId.tenantId = it.context.tenant.text();
                                                    templatePayload.SAPExternalIds.SAPExternalId.externalId = it.localId.text();
                                                    templatePayload.SAPExternalIds.SAPExternalId.item.Product.code = code;
                                                    templatePayload.SAPExternalIds.SAPExternalId.item.Product.catalogVersion.CatalogVersion.version = version;
                                                    templatePayload.SAPExternalIds.SAPExternalId.item.Product.catalogVersion.CatalogVersion.catalog.Catalog.id = id;
            
                                                    xml = XmlUtil.serialize(templatePayload);
                                                    batchPayload.batchChangeSet.appendNode(xml);
        }
    }
                                                    templatePayload.SAPExternalIds.SAPExternalId.application = "MDI";
                                                    templatePayload.SAPExternalIds.SAPExternalId.tenantId = "MDI";
                                                    templatePayload.SAPExternalIds.SAPExternalId.externalId = it.instance.id.text();
                                                    templatePayload.SAPExternalIds.SAPExternalId.item.Product.code = code;
                                                    templatePayload.SAPExternalIds.SAPExternalId.item.Product.catalogVersion.CatalogVersion.version = version;
                                                    templatePayload.SAPExternalIds.SAPExternalId.item.Product.catalogVersion.CatalogVersion.catalog.Catalog.id = id;
    
                                                    xml = XmlUtil.serialize(templatePayload);
                                                    batchPayload.batchChangeSet.appendNode(xml);

}
version ='';
id='';
}
 if(batchPayload.batchChangeSet == null)
 map.batchExists = false;
 xml1 = batchPayload;
 xml1 = xml1.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
 message.setBody(xml1);
 return message;
}





   

 




		
