import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    def reqPayload = body.replace("@odata","odata");

    message.setBody(reqPayload); 

      
      return message;
}