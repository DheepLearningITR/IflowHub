import com.sap.it.api.mapping.*;
import java.util.HashMap;
import groovy.xml.XmlUtil

def String taxType(String Country, MappingContext context){
    
    def taxes = context.getProperty("payload");
    def payload = new XmlSlurper().parseText(taxes);
    def value;
    
 
    payload.Product.value.instance.salesAspect.salesTaxes.each{it->
    
    if(it.country.code.text() == Country)
    value =  it.taxType.code.text();
    
    }
    
    
    return value;
	
}
