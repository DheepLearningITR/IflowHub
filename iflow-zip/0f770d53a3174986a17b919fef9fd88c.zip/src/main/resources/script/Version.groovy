import com.sap.it.api.mapping.*;
import java.util.HashMap;
import groovy.xml.XmlUtil

def String version(String sales,String division, MappingContext context){

    def catalogPayload = context.getProperty("Catalog");
    def catalogVersion;
    def payload  =  new XmlSlurper().parseText(catalogPayload);

    if(sales && division){
    payload.SAPProductSalesAreaToCatalogMapping.each{it->
    
    if(it.salesOrganization == sales && it.distributionChannel == division)
        catalogVersion = it.catalogVersion.CatalogVersion.version.text();
    }}
         
    if(catalogVersion == null)
    catalogVersion = context.getProperty("CatalogVersion");
    
   
	return catalogVersion; 
}
