import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.json.JsonBuilder


def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    def jsonParser = new JsonSlurper();
    def payload = jsonParser.parseText(body);
    def valPayload = payload.value;
    
    def jsonValue = JsonOutput.toJson(valPayload);
    String bodyStr = """{
    	"@odata.context": "\$delta",
    	"value": ${jsonValue}
    }""";
    message.setBody(bodyStr);
    
    return message;
    
}


