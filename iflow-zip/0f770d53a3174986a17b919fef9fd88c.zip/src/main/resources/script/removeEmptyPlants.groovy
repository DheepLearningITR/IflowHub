import com.sap.it.api.mapping.*;
import java.util.HashMap;
import groovy.xml.XmlUtil

def String removeEmptyPlants(String arg){
 
 	def payload = new XmlSlurper().parseText(arg);

    if(payload.plant.size() != 0){
    	return true; 
    }
    else
    {
        return false;
    }
}


