import com.sap.it.api.mapping.*;


def String changeTokenGenerate(String arg1){
    
    def var = UUID.randomUUID();
	return var; 
}
