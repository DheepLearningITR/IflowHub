import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil
def Message processData(Message message) {

       def body = message.getBody();
       def codeList = [] as Set;
       
       def map = message.getProperties();
       
       def payload = map.mdiProductPayload;
       def fiPayload = '''<root><Product></Product></root>''';
       def finalPayload = new XmlSlurper().parseText(fiPayload);
       def rootNode = new XmlSlurper().parseText(body);
       def reqPayload = new XmlSlurper().parseText(payload);
       def mdiPayload = map.reqPayload;

 
        rootNode.batchChangeSetResponse.batchChangeSetPartResponse.each { it ->  
            if(it.body.code.text() != null){
            def codeValue = it.body.code.text();
            codeList.add(codeValue);
            }
        }
        
        
        def size = codeList.size();
   
      for(def i=0;i<size;i++){

    reqPayload.Product.value.each{ it->

      if(it.instance.displayId.text() == codeList[i])
      finalPayload.Product.appendNode(it);
    }}
    
      def xml = XmlUtil.serialize(finalPayload);
      message.setBody(xml);

      return message;
}
