import com.sap.it.api.mapping.*;

def String configuredVersion(String arg1, MappingContext context){
	def version = context.getProperty(arg1);
    return version;

}