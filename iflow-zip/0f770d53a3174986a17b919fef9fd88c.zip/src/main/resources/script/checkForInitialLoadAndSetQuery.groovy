import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

       def body = message.getBody();
       def map = message.getProperties();
       def value = map.nextDeltaTokenLV;
       def verify = map.verifyTokenLV;


               if(value)
               {
                    if(map.token)
                     {
                     map.query =  '$deltatoken=' +map.token;

                     }
                    
                    else
                    {
                     map.query = '$deltatoken=' +value ;

                    }
               }
               else
               {
                 if(map.token)
                     {
                     map.query =  '$deltatoken=' +map.token;

                     }
               }
               
               if(map.initialLoad == 'true')
               map.query = '';

           if(verify)
           map.verifyQuery = '$deltatoken=' +verify;
           else
           map.verifyQuery = map.query;
      
       return message;
}