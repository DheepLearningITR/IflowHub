import com.sap.it.api.mapping.*;
import java.util.HashMap;
import groovy.xml.XmlUtil

def String taxCountry(String sales,String division, MappingContext context){

    def catalogPayload = context.getProperty("Catalog");
    def taxCountry;
    def payload  =  new XmlSlurper().parseText(catalogPayload);

    if(sales && division){
    payload.SAPProductSalesAreaToCatalogMapping.each{it->
    
    if(it.salesOrganization == sales && it.distributionChannel == division)
        taxCountry = it.taxClassCountry.Country.isocode.text();
    }}
         
    if(taxCountry == null)
    taxCountry = context.getProperty("DefaultCountry");
    
    
   
	return taxCountry; 
}
