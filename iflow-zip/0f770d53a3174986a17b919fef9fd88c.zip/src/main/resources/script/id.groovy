import com.sap.it.api.mapping.*;
import java.util.HashMap;
import groovy.xml.XmlUtil

def String id(String sales, String division,MappingContext context){
    def catalogPayload= context.getProperty("Catalog");
    
   def payload  =  new XmlSlurper().parseText(catalogPayload);
    def catalogId;
    
    if(sales && division){
    payload.SAPProductSalesAreaToCatalogMapping.each{it->
    
    if(it.salesOrganization == sales && it.distributionChannel == division)
     catalogId = it.catalogVersion.CatalogVersion.catalog.Catalog.id.text();
    }}
    
    if(catalogId == null)
    catalogId = context.getProperty("CatalogId");

	return catalogId; 
}

