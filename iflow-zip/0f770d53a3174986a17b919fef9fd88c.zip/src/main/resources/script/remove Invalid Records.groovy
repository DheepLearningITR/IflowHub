import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput


def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    def reqPayload = body.replace("@odata","odata");

    // message.setBody(reqPayload); 

//remove rejected events
    def jsonParser = new JsonSlurper();
    def productObject = jsonParser.parseText(reqPayload);
    def defaultObject = jsonParser.parseText(reqPayload);
    
    if(productObject.value != null){
    def values = productObject.value;
    def validLogs = values.findAll{ it.event != 'rejected' && it.instance != null && it.instance.displayId != null }
    productObject.value = validLogs;
    message.setBody(JsonOutput.toJson(productObject)); 
    }
    
    // //DefaultSalesArea
    // if(defaultObject.value != null){
    // def nullValues = defaultObject.value;
    // def nullSalesArea = nullValues.findAll{ it.event != 'rejected' && it.instance != null && it.instance.displayId != null && it.instance.salesAspect.salesDistributionChains == null }
    // defaultObject.value = nullSalesArea;
    // message.setProperty("defaultSalesAreaProducts",defaultObject)
    // }
    return message;
    
}
