import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;

Message processData(Message message) {
    def body = message.getBody(String)

    // Parse JSON
    def json = new JsonSlurper().parseText(body)

    // Convert count to integer if it's a string
    if (json.count instanceof String) {
        json.count = json.count.toInteger()
    }

    // Return modified JSON
    def newJson = new JsonBuilder(json).toPrettyString()
    message.setBody(newJson)
    return message
}
