import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.op.agent.mpl.*;
import groovy.transform.Field;
import groovy.json.JsonOutput;

@Field String ORIGINAL_PAYLOAD_LOG = '1. Inbound Request';
@Field String SOURCING_PAYLOAD_LOG = '2. Mapped Sourcing Request';
@Field String SOURCING_RESPONSE_LOG = '3. Sourcing Response';
@Field String SOURCING_ERROR_RESPONSE_JSON = '3. Sourcing Error Response';
@Field String IFLOW_JSON_RESPONSE_LOG = '4. iFlow Response';
@Field String IFLOW_JSON_ERROR_RESPONSE_LOG = '4. iFlow Error Response';
@Field String EXIT_OUTPUT_JSON_LOG = 'Exit Output';

def Boolean isDebug(Message message) { 
     final MplConfiguration config = message.getProperty("SAP_MessageProcessingLogConfiguration");
     return config.getOverallLogLevel() == MplLogLevel.DEBUG;
}

def Message logOriginalRequest(Message message) { 
     processData(ORIGINAL_PAYLOAD_LOG, message);
}

def Message logSourcingJsonRequest(Message message) { 
     processData(SOURCING_PAYLOAD_LOG, message);
}

def Message logSourcingJsonResponse(Message message) { 
     processData(SOURCING_RESPONSE_LOG, message);
}

def Message logSourcingJsonErrorResponse(Message message) {
     processData(SOURCING_ERROR_RESPONSE_JSON, message);
}

def Message logiFlowJsonResponse(Message message) { 
     processData(IFLOW_JSON_RESPONSE_LOG, message);
}

def Message logiFlowJsonErrorResponse(Message message) { 
     processData(IFLOW_JSON_ERROR_RESPONSE_LOG, message);
}

def Message logPostExitOutput(Message message) { 
     processData(EXIT_OUTPUT_JSON_LOG, message);
}

def Message processData(String title, Message message) {
     if (isDebug(message)) {
          def body = message.getBody(java.lang.String);	
          def headers = message.getHeaders();
          def properties = message.getProperties();

          def propertiesAsString ="\n";
          properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };

          def headersAsString ="\n";
          headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };

          def messageLog = messageLogFactory.getMessageLog(message);

          if(messageLog != null) {
             try{
                 body = body ? JsonOutput.prettyPrint(body) : "";
             }catch(Exception ex){
                 //in case request payload is not in json format
             }
             messageLog.addAttachmentAsString(title , "\n Properties \n ----------   \n" + propertiesAsString +
                                                                 "\n Headers \n ----------   \n" + headersAsString +
                                                                 "\n Body \n ----------  \n\n" + body, "text/plain");
          }
     }
     return message;
}
