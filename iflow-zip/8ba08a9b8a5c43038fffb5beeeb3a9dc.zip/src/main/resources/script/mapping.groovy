import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import com.sap.it.op.agent.mpl.*;

@Field String DELIVERY_OPTION = "DeliveryOption";
@Field String STATUS_PENDING = "PENDING";

@Field String WARNING_SHORTTEXT = 'WARN';
@Field String INFO_SHORTTEXT = 'INFO';
@Field String CPI_MSGID_TEXT = 'SAP Cloud Integration message ID: '

/***** For OMSA payload *****/
class ServiceCode {
    String id
}

class SourcingItem {    	
    String referenceId
	SourcingProduct product
    BigDecimal quantity
    UnitOfMeasure unitOfMeasure
}

class SourcingProduct {
    String id
}

class UnitOfMeasure {
    String salesUnitCode
}

/***** For OMF response *****/
class Shipment {
    FulfillmentSite fulfillmentSite
    Delivery delivery
    List<ShipmentItem> items
}

class FulfillmentSite {
    String id
    String dropshipId
}

class Delivery {
    String deliveryOption
    String expectedDeliveryDate
}

class ShipmentItem {
    String referenceId
    ShipmentProduct product
    Quantity quantity
}

class ShipmentProduct {
    ExternalSystemReference externalSystemReference
}

class ExternalSystemReference {
    String externalSystemId
    String externalId
}

class Quantity {
    BigDecimal value
    String unit
}

class ResponseMsg {
	String message
	String type
}


def Message mapRequest(Message message) {
    message.setHeader("Content-Type", "application/json");	
	def body_json = new JsonSlurper().parseText(message.getBody(java.lang.String));

	def omsaPayload = [:];		

	omsaPayload.strategy = [:];
	omsaPayload.strategy["id"] = body_json.strategyId;
	
	List<SourcingItem> sourcingItems = [];
	for(shipment in body_json.shipments) {
	    //omsa expects all the items together
	    for(item in shipment.items) {		
    		SourcingItem sourcingItem = new SourcingItem(
    			referenceId:item.referenceId, product:new SourcingProduct(id:item.product.externalSystemReference.externalId), 
    			quantity:item.quantity.value, unitOfMeasure:new UnitOfMeasure(salesUnitCode:item.quantity.unit));
    		sourcingItems.add(sourcingItem);
    		
	    }
	}
	
	omsaPayload["items"] = sourcingItems;

    omsaPayload.deliveryFilter = [:]
    List<ServiceCode> serviceCodes = [];
    
    //We take only the first delivery Option because omsa does not support multiple delivery options
    serviceCode = new ServiceCode(id:body_json.shipments[0].delivery.deliveryOption)

    serviceCodes.add(serviceCode);
	omsaPayload.deliveryFilter["serviceCodes"] = serviceCodes;
	
	omsaPayload.destination = [:];
	
	//We take only the first country code because all the country codes in the shipments are the same
	omsaPayload.destination["isoCode3166-1"] = body_json.shipments[0].delivery.address.countryCode;
	omsaPayload.destination["postalCode"] = body_json.shipments[0].delivery.address.postalCode;

	omsaPayload.reservation = [:];
	omsaPayload.reservation["status"] = STATUS_PENDING;
	
	message.setProperty(DELIVERY_OPTION, serviceCode.id);
	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(omsaPayload)));    

    return message;
}

def Message mapResponse(Message message) {
	message.setHeader("Content-Type", "application/json");
	def body_json = new JsonSlurper().parseText(message.getBody(java.lang.String));
	
	List<Shipment> shipments = [];
	
	// if OMSA response shipments are empty, return trace messages from OMSA + iflow ID
	if (body_json.shipments == null || body_json.shipments.size < 1) {
	  	def response = [:];
	  	List<ResponseMsg> respMsgs = [];
	  	
	  	for(omsa_message in body_json.trace.warnings) {
	  		respMsgs.add(new ResponseMsg(type:WARNING_SHORTTEXT, message: omsa_message.message));
	  	}
	  
	    // Add CPI MsgID to messages
    	String sapMessageProcessingLogId = message.getProperty('SAP_MessageProcessingLogID') ?: '';
    	respMsgs.add(new ResponseMsg(type:INFO_SHORTTEXT, message:CPI_MSGID_TEXT + sapMessageProcessingLogId));

    	response.messages = respMsgs;
    	message.setHeader("CamelHttpResponseCode", "400");    
	    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(response)));
	    return message;
							
	}
	
	def sourcingResponse = [:];
	
	def reservation = body_json.reservation;

	sourcingResponse.reservation = [:];
	sourcingResponse.reservation["id"] = reservation.id;
	
	for(omsaShipment in body_json.shipments) {		
		List<ShipmentItem> shipmentItems = [];
		for(item in omsaShipment.items) {			
			ShipmentItem shipmentItem = new ShipmentItem(referenceId:item.referenceId, 
			product:new ShipmentProduct(externalSystemReference:new ExternalSystemReference(externalId:item.product.id)), 
			quantity:new Quantity(value:item.quantity, unit:item.unitOfMeasure.salesUnitCode));			
			shipmentItems.add(shipmentItem);
		}		
		
		String deliveryOptionFromRequest = message.getProperty(DELIVERY_OPTION);
		
		Shipment shipment = new Shipment(delivery:new Delivery(deliveryOption:deliveryOptionFromRequest), 
		fulfillmentSite:new FulfillmentSite(id:omsaShipment.site.id), items:shipmentItems);
		
		shipments.add(shipment);
	}
	sourcingResponse["shipments"] = shipments;

	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(sourcingResponse)));
    
    return message;
}
