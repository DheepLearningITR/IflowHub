import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
	    def testRun = message.getProperties().get("testRun");
		if(testRun!=null && testRun!='' && testRun!='false'){
			messageLog.addCustomHeaderProperty("cbr_testRun", testRun);		
        }
        def cbrJobProfileType = message.getProperties().get("cbrJobProfileType");
		if(cbrJobProfileType!=null){
			messageLog.addCustomHeaderProperty("cbrJobProfileType", cbrJobProfileType);		
        }
        def sfsfAttributeTag = message.getProperties().get("sfsfAttributeTag");
		if(sfsfAttributeTag!=null){
			messageLog.addCustomHeaderProperty("sfsf_AttributeTag", sfsfAttributeTag);		
        }
        def sfsfAttributeType = message.getProperties().get("sfsfAttributeType");
		if(sfsfAttributeType!=null){
			messageLog.addCustomHeaderProperty("sfsf_AttributeType", sfsfAttributeType);		
        }
	}
	return message;
}

def Message cbrJobProfIdList(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def cbrJobProfIdList = message.getProperties().get("cbrJobProfIdList");
		if(cbrJobProfIdList!=null && cbrJobProfIdList!=''){
			messageLog.addCustomHeaderProperty("cbr_jobProfExtIds", cbrJobProfIdList);		
        }
	}
	return message;
}

