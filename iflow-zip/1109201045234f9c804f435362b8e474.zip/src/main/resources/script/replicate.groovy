import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonOutput;

def Message validate(Message message) {

    def headers = message.getHeaders();
    def properties = message.getProperties();
    
    // Extract specific headers with defaults if necessary
    def cbrJobArchitecture = headers.get("cbrJobArchitecture");
    def cbrJobProfIds = headers.get("cbrJobProfileIds");
    def cbrJobProfileType = headers.get("cbrJobProfileType");
    def sfsfDeactivateTags = headers.get("sfsfDeactivateTags") ?: "false";
    def sfsfDeactivateAttributes = headers.get("sfsfDeactivateAttributes") ?: "false";
    def testRun = headers.get("testRun") ?: "false";
    def sfsfCompanyId = headers.get("sfsfCompanyId");
    def mapCBRCompetency2SFSFTag = headers.get("mapCBRCompetency2SFSFTag") ?: "false";
    def sfsfAttributeTag = properties.get("sfsfAttributeTag");

    def errors = []; // Unified error list
    
    // Validate IFLOW PARAMETERS --------------------
    def mandatoryParams = [
        "sfsfCompanyId"
    ]
    mandatoryParams.each { key ->
        if (!headers[key]?.trim()) {
            errors.add(["errorCode": "[SAP-IS] MISSING_IFLOW_PARAM", "errorMessage": key]);
        }
    }
    
    // Validate HEADERS --------------------
    def mandatoryHeaders = [
        "cbrJobArchitecture",
        "cbrJobProfileType"
    ]
    
    mandatoryHeaders.each { key ->
        if (!headers[key]?.trim()) {
            errors.add(["errorCode": "[SAP-IS] MISSING_HDR", "errorMessage": key]);
        }
    }    

    // Validate VM CONFIG ---------------------
    if(sfsfCompanyId){
        def configMappings = [
            "SFTP_Address"                       : "cbrInt_SuccessFactors_SFTP:Address",
            "SAP_FtpAuthMethod"                  : "cbrInt_SuccessFactors_SFTP:Authentication",         
            "SFTP_Source_Directory"              : "cbrInt_SuccessFactors_SFTP_TIH:SourceDirectory", 
            "SFTP_Source_Fname_TagTexts"         : "cbrInt_SuccessFactors_SFTP_TIH:SourceFile_TagTexts", 
            "SFTP_Source_Fname_Tags"             : "cbrInt_SuccessFactors_SFTP_TIH:SourceFile_Tags", 
            "SFTP_Target_Directory"              : "cbrInt_SuccessFactors_SFTP_TIH:TargetDirectory", 
            "SFTP_Target_FnamePrefix_TagTexts"   : "cbrInt_SuccessFactors_SFTP_TIH:TargetFilePrefix_TagTexts", 
            "SFTP_Target_FnamePrefix_Tags"       : "cbrInt_SuccessFactors_SFTP_TIH:TargetFilePrefix_Tags", 
            "SFTP_Target_FileSize"               : "cbrInt_SuccessFactors_SFTP_TIH:TargetFileSize"        
        ];
        
        if(properties["SAP_FtpAuthMethod"]=='user' || properties["SAP_FtpAuthMethod"]=='dual'){
            configMappings.put("SFTP_Credential","cbrInt_SuccessFactors_SFTP:Credential");
        }
        if(properties["SAP_FtpAuthMethod"]=='key'){
            configMappings.put("SFTP_UserName","cbrInt_SuccessFactors_SFTP:UserName");
            configMappings.put("SFTP_PrivateKeyAlias","cbrInt_SuccessFactors_SFTP:PrivateKeyAlias");
        }        
        
        configMappings.each { property, vmconfig ->
            if (!properties[property]?.trim()) {
                errors.add(["errorCode": "[SAP-IS] MISSING_VMCONFIG", "errorMessage": "${vmconfig}"]);
            }
        }
    }

    // If there are any errors, set the error response and return
    if (!errors.isEmpty()) {
        def errorJson = JsonOutput.toJson(["errors": errors]);
        message.setProperty("errorJson", errorJson);
        throw new IllegalArgumentException(errorJson); // Exit with all errors
    }

    def get_sfsfTags = false;
    if(sfsfAttributeTag){ 
        get_sfsfTags = true;
    }else if(mapCBRCompetency2SFSFTag == "true"){
        get_sfsfTags = true;
    }
    
    message.setProperty("get_sfsfTags",get_sfsfTags);

    //check JobProfile Sections VM Config if it includes Competency
    def mapCompetencies = false;
    def sfsfJPsections = properties.get("sfsfJobProfileSections")?:"";
    if(sfsfJPsections.contains('competency')){
        mapCompetencies = true;
    }
    message.setProperty("mapCompetencies",mapCompetencies);

    // Set properties for further processing
    message.setProperty("cbrJobArchitecture", cbrJobArchitecture);
    message.setProperty("cbrJobProfileIds", cbrJobProfIds);
    message.setProperty("cbrJobProfileType", cbrJobProfileType);
    message.setProperty("sfsfDeactivateTags", sfsfDeactivateTags);
    message.setProperty("sfsfDeactivateAttributes", sfsfDeactivateAttributes);
    message.setProperty("sfsfAttributeType", 'COMPETENCY');
    message.setProperty("testRun", testRun);
    message.setProperty("mapCBRCompetency2SFSFTag", mapCBRCompetency2SFSFTag);

	//used to clear hashmap global variables
	def emptyHmap = new HashMap<String, String>();
	emptyHmap.put('null','');
	message.setProperty("emptyHmap", emptyHmap);

    return message;
}

def Message build_listJobProf(Message message) {
    
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
    def cbrJobProfIds = map.get("cbrJobProfIds");
	def Root = new XmlSlurper().parse(body);    
    
    // Find and count the number of Job Profiles
    def sumJobProf = Root.data.id.size();
    message.setProperty("sumJobProf", sumJobProf); 
    
    //create list only if sycnhing for specific jobs!
    if(cbrJobProfIds){
	    def jobProfList = ''; 
	
        Root.data.each{
            if(jobProfList == ''){
                jobProfList = it.id.toString();
            }else{
                jobProfList = jobProfList + ',' + it.id.toString();
            }
        }
        //list of Roles being synched!
        message.setProperty("cbrJobProfIdList", jobProfList); 
    }
	return message;
}

def Message build_hmapCompetencies(Message message) {
	
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
	HashMap<String, String> hmapCompetencies = map.get("hmap_cbrCompetencies"); 
	if( hmapCompetencies == null ){
	    hmapCompetencies = new HashMap<String, String>();	
	}
	
    def skillIds_str = '';
	def Root = new XmlSlurper().parse(body);
    Root.attribute.each{
        skillIds_str = '';
        it.skillIds.skillId.each{ j ->
            if(skillIds_str==''){
                skillIds_str = j.toString();
            }else{
                skillIds_str = skillIds_str + '|' + j.toString();
            }
        }
        //hmapCompetencies.put('cbr_'+it.id.toString(),skillIds_str);
        hmapCompetencies.put(it.id.toString(),skillIds_str);
    }
	message.setProperty("hmap_cbrCompetencies", hmapCompetencies);
	return message;
}
