import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    def location = message.getHeader("location_id", String);
    def body = message.getBody(java.io.Reader)
    def xml = new XmlSlurper().parse(body)
    boolean locationIsPresent = false;

    def locationById = xml.'**'.find { it.name() == 'node' && it.id.text() == location }
    if (locationById) {
        locationIsPresent = true;
    }

    message.setProperty("location_present", locationIsPresent);


    return message;
}