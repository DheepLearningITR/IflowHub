import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def map = message.getProperties()
    def logException = map.get("ExceptionLogging")?.equalsIgnoreCase("true") // Determine if logging is enabled

    if (logException) {
        def ex = map.get("CamelExceptionCaught")
        if (ex != null) {
            handleException(message, map)
        } else {
            handleMessageBody(message, map)
        }
    }

    return message
}

def handleException(Message message, def map) {
    def ex = map.get("CamelExceptionCaught")
    def s4HanaCloudProductID = map.get("s4hana_product_id") ?: ""
    def attachID = s4HanaCloudProductID ? "Error Details for SAP S/4HANA Cloud Product ID '${s4HanaCloudProductID}'" : "Error Details"
    def errordetails = s4HanaCloudProductID ? "The process with SAP S/4HANA Cloud Product ID '${s4HanaCloudProductID}' failed due to the following error: ${ex.toString()}" : "The process failed due to the following error: ${ex.toString()}"

    addAttachment(message, attachID, errordetails)
}

def handleMessageBody(Message message, def map) {
    def messageBody = message.getBody(String)
    def s4HanaCloudProductID = map.get("s4hana_product_id") ?: ""
    def attachID = s4HanaCloudProductID ? "Error Details for SAP S/4HANA Cloud Product ID '${s4HanaCloudProductID}'" : "Error Details"
    def errordetails = "Message Content: \n${messageBody}"

    addAttachment(message, attachID, errordetails)
}

def addAttachment(Message message, String attachID, String errorMessage) {
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        messageLog.addAttachmentAsString(attachID, errorMessage, "text/plain")
    }
}