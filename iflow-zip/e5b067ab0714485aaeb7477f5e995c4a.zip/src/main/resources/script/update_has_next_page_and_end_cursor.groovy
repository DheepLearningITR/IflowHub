import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    def body = message.getBody(String)

    def xmlSlurper = new XmlSlurper().parseText(body)

    def hasNextPage = xmlSlurper.data.locations.pageInfo.hasNextPage.text().toBoolean()
    def endCursor = xmlSlurper.data.locations.pageInfo.endCursor.text()

    if (hasNextPage) {
        message.setProperty("lastNode", endCursor)
    } else {
        message.setProperty("hasNextPage", false)
    }

    return message
}