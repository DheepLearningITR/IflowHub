import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;
def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def xml = new XmlSlurper().parse(body)

    def shopifyQuanityString = message.getProperty("shopify_current_quantity")
    Integer shopifyQuanityInt = shopifyQuanityString?.isInteger() ? shopifyQuanityString.toInteger() : 0;

    def s4QuanityString = message.getProperty("s4_quantity")
    Integer s4QuanityInt = s4QuanityString?.isInteger() ? s4QuanityString.toInteger() : 0;

    Integer newQuantity = s4QuanityInt - shopifyQuanityInt;

    message.setProperty("new_quantity", newQuantity);


    boolean locationExistForInventory = false;
    def inventoryLevel = xml.data.productVariant.inventoryItem.inventoryLevel
    def quantity = inventoryLevel.quantities.quantity.text()

    if (inventoryLevel.size() > 0 && !quantity.isEmpty()) {
        locationExistForInventory = true;
    }


    message.setProperty("location_exist_for_inventory", locationExistForInventory)

    return message;
}