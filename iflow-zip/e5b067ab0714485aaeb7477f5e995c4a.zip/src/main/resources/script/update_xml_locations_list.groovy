import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.util.XmlSlurper;
import groovy.xml.StreamingMarkupBuilder

Message processData(Message message) {
    def shopifyLocationsList = message.getProperty("shopify_locations_list") ?: "<root></root>"

    def currentResponse = message.getBody(String)
    def xmlSlurper = new XmlSlurper().parseText(currentResponse)

    def combinedXmlSlurper = new XmlSlurper().parseText(shopifyLocationsList)

    def locationsToAppend = xmlSlurper.data.locations

    combinedXmlSlurper.appendNode(locationsToAppend)

    def builder = new StreamingMarkupBuilder()
    def resultXml = builder.bind { mkp.yield combinedXmlSlurper }

    message.setProperty("shopify_locations_list", XmlUtil.serialize(resultXml))

    return message
}