import com.sap.it.api.mapping.*;
def String removeLeadingzeros(String arg1){
    if(arg1.isNumber()){
        arg1 = arg1.replaceFirst("^0+(?!\$)", "");
    }
	return arg1 ;
}

def String customSubString(String input, String fieldName, MappingContext context ){
    def cache = getCachedList(fieldName, context);
    String start = cache.get(0);
    String count = cache.get(1);
    def startIndex = Integer.parseInt(start);
    def countValue = Integer.parseInt(count);
    def endIndex = startIndex+countValue <= input.length() ? startIndex+countValue : input.length();
    return input.substring(startIndex, endIndex);
}

def String createCache(String fieldName, String offset, String length, MappingContext context){
    def cache = context.getProperty("sendResponseToUICache");
    if(cache == null){
        cache = new HashMap<String, List<String>>();
    }
    List<String> listEntries = new ArrayList<>();
    listEntries.add(offset);
    listEntries.add(length);
    cache.put(fieldName, listEntries);
    context.setProperty("sendResponseToUICache", cache);
    return fieldName;
}

def List<String> getCachedList(String fieldName,MappingContext context){
    def cache = context.getProperty("sendResponseToUICache");
    return cache.get(fieldName);
}