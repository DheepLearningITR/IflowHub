import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;


def Message processData(Message message) {
  //Body 
  def body = message.getBody(String.class);
  JsonSlurper slurper = new JsonSlurper();
  Map parsedJson = slurper.parseText(body);
  
  if (parsedJson.TABLES.DATA.item instanceof ArrayList) {
        // scheduleElements is an array
        message.setProperty("isArray", true);
    } else {
         message.setProperty("isArray", false);
    }

    message.setProperty("json", parsedJson);
 
  return message;

}