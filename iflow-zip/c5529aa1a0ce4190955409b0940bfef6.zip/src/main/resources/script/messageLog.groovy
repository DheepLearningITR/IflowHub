import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processDataCreateRCBP(Message message) {
    def map = message.getProperties();
    def property_ENABLE_MPL_LOGGING = map.get("EnableLog");
    def property_S4ID = map.get("S4ID");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
        def body = message.getBody(java.lang.String) as String;
        def messageLog = messageLogFactory.getMessageLog(message);
        if (messageLog != null) {
            messageLog.addAttachmentAsString("S4(" + property_S4ID + ")" + "_create_customer_req", body, "text/json");
        }
    }
    return message;
}

def Message processDataUpdateRCBP(Message message) {
    def map = message.getProperties();
    def property_ENABLE_MPL_LOGGING = map.get("EnableLog");
    def property_S4ID = map.get("S4ID");
    def property_RCID = map.get("RCID");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
        def body = message.getBody(java.lang.String) as String;
        def messageLog = messageLogFactory.getMessageLog(message);
        if (messageLog != null) {
            messageLog.addAttachmentAsString("S4(" + property_S4ID + ")" + "_SB(" + property_RCID + ")" + "_update_customer_req", body, "text/json");
        }
    }
    return message;
}

/*
def Message processDataS4businessPartner(Message message) {
    map = message.getProperties();
    property_ENABLE_ERROR_ONLY_LOGGING = map.get("ENABLE_ERROR_ONLY_LOGGING");
    property_ENABLE_MPL_LOGGING = map.get("ENABLE_MPL_LOGGING");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
        def body = message.getBody(java.lang.String) as String;
        def root = new XmlSlurper().parseText(body);
        def businessPartnerId = root.BusinessPartners.rcCustomerData.externalObjectReferences.find{ externalObjectReferences -> externalObjectReferences.externalIdTypeCode == '201' }.externalId as String;
        def messageLog = messageLogFactory.getMessageLog(message);

        if (messageLog != null) {
            messageLog.addAttachmentAsString("[After Mapping]BP_Payload_S4( " + businessPartnerId + " )", body, "text/xml");
        }
    }
    return message;
}
*/


def Message processDataS4ConfirmIn(Message message) {
    def map = message.getProperties();
    def property_S4ID = map.get("S4ID");
    def property_RCID = map.get("RCID");
    def property_ENABLE_MPL_LOGGING = map.get("EnableLog");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
        def body = message.getBody(java.lang.String) as String;
        def messageLog = messageLogFactory.getMessageLog(message);
        if (messageLog != null) {
            messageLog.addAttachmentAsString("S4(" + property_S4ID + ")_SB(" + property_RCID + ")_confirm_msg", body, "text/xml");
        }
    }
    return message;
}


def Message nonRelatedRolesCustomerNotSupported(Message message) {
    def map = message.getProperties();
    def property_ENABLE_MPL_LOGGING = map.get("EnableLog");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
        def property_S4ID = map.get("S4ID") as String;
        def body = "The Buinsess Partner(" + property_S4ID + ") would not be replicated to SAP Subscription Billing. Please ensure BP has at least one of FLCU01 (Customer) and FLCU00 (Customer (Financial Accounting)) Business Partner roles.";
        def messageLog = messageLogFactory.getMessageLog(message);

        if (messageLog != null) {
                messageLog.addAttachmentAsString("S4(" + property_S4ID + ")_skip_non_related_customer", body, "text/plain");
        }
    }
    return message;
}