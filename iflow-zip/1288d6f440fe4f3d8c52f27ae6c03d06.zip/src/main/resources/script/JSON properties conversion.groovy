/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def jsonDataObject = jsonSlurper.parseText(body);
    
    if(jsonDataObject.d.to_SubscriptionItem != null && jsonDataObject.d.to_SubscriptionItem.results != null){
        jsonDataObject.d.to_SubscriptionItem.results.each{
            it.SubscrpnContrAutoRnwlIsActv = convertToBoolean(it.SubscrpnContrAutoRnwlIsActv);
        };
    }
    
    if(jsonDataObject.d != null && jsonDataObject.d.SubscrpnContrAutoRnwlIsActv != null){
        jsonDataObject.d.SubscrpnContrAutoRnwlIsActv = convertToBoolean(jsonDataObject.d.SubscrpnContrAutoRnwlIsActv);
    }
    
    if(jsonDataObject.d != null && jsonDataObject.d.to_Configurations == ""){
        jsonDataObject.d.remove("to_Configurations")
    }
    
    // new nodes to remove
    if(jsonDataObject.d != null && jsonDataObject.d.to_SalesItem == ""){
        jsonDataObject.d.remove("to_SalesItem")
    }
    if(jsonDataObject.d != null && jsonDataObject.d.to_BundleItem == ""){
        jsonDataObject.d.remove("to_BundleItem")
    }
    if(jsonDataObject.d != null && jsonDataObject.d.to_ServiceContractItem == ""){
        jsonDataObject.d.remove("to_ServiceContractItem")
    }

    message.setBody(new JsonBuilder(jsonDataObject).toPrettyString());
    return message;
}

def Object convertToBoolean(Object inputValue){
    if (inputValue.equals("true")) {
        return true;
    } else {
        return false;
    }
}