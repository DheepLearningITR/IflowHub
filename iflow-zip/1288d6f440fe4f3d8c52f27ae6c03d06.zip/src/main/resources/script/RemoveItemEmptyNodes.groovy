/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {
       //Body 
    def body = message.getBody(java.lang.String) as String;
    
    // remove empty nodes as S4 doesn't accept it
    // list of nodes: https://api.sap.com/api/OP_API_BUS_SOLUTION_QUOTATION_SRV_0001/resource/post_A_BusinessSolutionQuotation
    String XML = body;
    
    XML = XML.replaceAll("<to_SubscriptionItem/>", "")
    XML = XML.replaceAll("<to_SubscriptionItem></to_SubscriptionItem>", "")
    
    //emtpy to_PriceElement
    XML = XML.replaceAll("<to_PriceElement/>", "")
    XML = XML.replaceAll("<to_PriceElement></to_PriceElement>", "")
    
    XML = XML.replaceAll("<to_Configurations/>", "")
    XML = XML.replaceAll("<to_Configurations></to_Configurations>", "")
    
    XML = XML.replaceAll("<to_ReferenceObject/>", "")
    XML = XML.replaceAll("<to_ReferenceObject></to_ReferenceObject>", "")
    
    XML = XML.replaceAll("<to_Text/>", "")
    XML = XML.replaceAll("<to_Text></to_Text>", "")
    
    XML = XML.replaceAll("<to_ServiceOrder/>", "")
    XML = XML.replaceAll("<to_ServiceOrder></to_ServiceOrder>", "")
    
    XML = XML.replaceAll("<to_SalesOrder/>", "")
    XML = XML.replaceAll("<to_SalesOrder></to_SalesOrder>", "")
    
    XML = XML.replaceAll("<to_VarConfignStructureNode/>", "")
    XML = XML.replaceAll("<to_VarConfignStructureNode></to_VarConfignStructureNode>", "")
    
    XML = XML.replaceAll("<to_BusinessSolutionQuotation/>", "")
    XML = XML.replaceAll("<to_BusinessSolutionQuotation></to_BusinessSolutionQuotation>", "")
    
    XML = XML.replaceAll("<to_ProductList/>", "")
    XML = XML.replaceAll("<to_ProductList></to_ProductList>", "")
    
    XML = XML.replaceAll("<to_ServiceContract/>", "")
    XML = XML.replaceAll("<to_ServiceContract></to_ServiceContract>", "")
    
    XML = XML.replaceAll("<to_SrvcContrReferenceObject/>", "")
    XML = XML.replaceAll("<to_SrvcContrReferenceObject></to_SrvcContrReferenceObject>", "")
    
    XML = XML.replaceAll("<to_DateParameters/>", "")
    XML = XML.replaceAll("<to_DateParameters></to_DateParameters>", "")
    
    XML = XML.replaceAll("<to_NumericParameters/>", "")
    XML = XML.replaceAll("<to_NumericParameters></to_NumericParameters>", "")
    
    XML = XML.replaceAll("<to_StringParameters/>", "")
    XML = XML.replaceAll("<to_StringParameters></to_StringParameters>", "")
    
    XML = XML.replaceAll("<to_SubscriptionContract/>", "")
    XML = XML.replaceAll("<to_SubscriptionContract></to_SubscriptionContract>", "")
    
    XML = XML.replaceAll("<to_TableParameters/>", "")
    XML = XML.replaceAll("<to_TableParameters></to_TableParameters>", "")
    
    XML = XML.replaceAll("<to_TechnicalResource/>", "")
    XML = XML.replaceAll("<to_TechnicalResource></to_TechnicalResource>", "")
    
    XML = XML.replaceAll("<to_TechnicalResourceWithSlot/>", "")
    XML = XML.replaceAll("<to_TechnicalResourceWithSlot></to_TechnicalResourceWithSlot>", "")
    
    XML = XML.replaceAll("<to_TableParameters/>", "")
    XML = XML.replaceAll("<to_TableParameters></to_TableParameters>", "")
    
    
    message.setBody(XML)
    return message;
}