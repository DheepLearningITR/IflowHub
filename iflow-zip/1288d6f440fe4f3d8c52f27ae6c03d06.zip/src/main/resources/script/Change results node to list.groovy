
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    //Body
    def body = message.getBody();

    def transformed = transformResultsToArray(body);

    message.setBody(transformed);
    return message;
}


def transformResultsToArray(jsonString) {
    def jsonSlurper = new JsonSlurper()
    def data = jsonSlurper.parse(jsonString)
    // Recursive function to traverse and transform the JSON structure
    def transformedData = transformNode(data)
    def jsonBuilder = new JsonBuilder(transformedData)
    return jsonBuilder.toPrettyString()
}

def transformNode(nodeItem) {
    if (nodeItem instanceof Map) {
        // Check each key in the map
        nodeItem.each { key, value ->
            if (key == 'results') {
                // Convert results to array if it's not already one
                if (!(value instanceof List)) {
                    if (value != null) {
                        nodeItem[key] = [value] // Wrap object in array
                    } else {
                        nodeItem[key] = [] // Handle null case with empty array
                    }
                    println "Transformed 'results' node to array"
                }
            } else {
                // Recursively process nested structures
                if (value instanceof Map || value instanceof List) {
                    nodeItem[key] = transformNode(value)
                }
            }
        }
    } else if (nodeItem instanceof List) {
        // Process each element in the array
        nodeItem = nodeItem.collect { item ->
            if (item instanceof Map || item instanceof List) {
                transformNode(item)
            } else {
                item
            }
        }
    }
    return nodeItem
}