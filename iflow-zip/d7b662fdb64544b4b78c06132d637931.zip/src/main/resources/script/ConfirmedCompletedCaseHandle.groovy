import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(String.class) as String
    body = body.replaceFirst("confirmed","confirmedCompleted")
    return message
}