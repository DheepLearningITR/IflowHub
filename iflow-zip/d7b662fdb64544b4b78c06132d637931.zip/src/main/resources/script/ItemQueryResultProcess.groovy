package script
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import com.sap.it.api.ITApiFactory
import com.sap.it.api.ITApi
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {
    def valueMappingService = ITApiFactory.getApi(ValueMappingApi.class, null)

    def body = message.getBody(String.class)
    def payLoad = message.getProperty("originalPayload")

    def xmlParser = new XmlParser()
    def xmlResult = xmlParser.parseText(body)

    def jsonParser = new JsonSlurper()
    def jsonResult = jsonParser.parseText(payLoad)

    def isUnplannedCase = false
    def isActivityConfirmedCompleted = false

    def eventType = jsonResult.eventType
    if (eventType == "activity.confirmedcompleted") {
        isActivityConfirmedCompleted = true
        payLoad = payLoad.replaceFirst("confirmedcompleted","confirmed")
    }
    
    def materialFSMList = jsonResult.data.serviceCall.activity.materials as List
    if ( !materialFSMList.is(null) && materialFSMList.size() > 0) {
        materialFSMList = materialFSMList.grep{
            it -> it.reservedMaterials.size() == 0
        }.collect{
            it -> it.item.externalId
        }
    }

    def expenseFSMList = jsonResult.data.serviceCall.activity.expenses
    if ( !expenseFSMList.is(null) && expenseFSMList.size() > 0) {
        expenseFSMList = expenseFSMList.type.code as List
        expenseFSMList = expenseFSMList.collect{
            item ->
                valueMappingService.getMappedValue('Activity', 'Expensetype', item.toString(), 'ServiceConfirmationItem', 'Expensetype')
        }
    }

    if (materialFSMList != null && materialFSMList.size() > 0){
        isUnplannedCase = true
    } else {
        if (expenseFSMList == null || expenseFSMList.size() == 0){
            isUnplannedCase = false
        } else {
            def productS4PlannedList = xmlResult.A_ServiceOrderItemType.Product as List
            if (productS4PlannedList == null || productS4PlannedList.size() == 0) isUnplannedCase = true
            else {
                productS4PlannedList = productS4PlannedList.collect{ item -> item.text()} as List
                if (productS4PlannedList.containsAll(expenseFSMList)) isUnplannedCase = false
                else isUnplannedCase = true
            }
        }
    }
    
    message.setProperty("isActivityConfirmedCompleted",isActivityConfirmedCompleted)
    message.setProperty("isUnplannedCase",isUnplannedCase)
    message.setBody(payLoad)
    return message
}
