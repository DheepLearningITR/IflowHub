import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;


def Message processData(Message message) {
	def body = message.getBody(String.class);
	def parseJSON = new JsonSlurper().parseText(body)
	
	
	def tenantcode = parseJSON.tenant.code
	def systemname = parseJSON.system.name
	def executionversion = parseJSON.execution.version
	def executiontype = parseJSON.execution.type
	def executionmonitoringstartat = parseJSON.execution.monitoringStartAt.replaceAll(" ","T")
	def executionmonitoringendat = parseJSON.execution.monitoringEndAt.replaceAll(" ","T")
	def executionmonitoringexecutedat = parseJSON.execution.executedAt.replaceAll(" ","T")
	def new_body = ""
	def salida = ""
	
	// Tenants
	
	def messageOverviewsuccess = parseJSON.messageOverview.success
	def messageOverviewcancelled = parseJSON.messageOverview.cancelled
	def messageOverviewdelivering = parseJSON.messageOverview.delivering
	def messageOverviewerror = parseJSON.messageOverview.error
	def messageOverviewholding = parseJSON.messageOverview.holding
	def messageOverviewtoBeDelivered = parseJSON.messageOverview.toBeDelivered
	def messageOverviewwaiting = parseJSON.messageOverview.waiting
	def messageOverviewnumberDays = parseJSON.messageOverview.numberDays
	def channelOverviewerror = parseJSON.channelOverview.error
	def channelOverviewinactive = parseJSON.channelOverview.inactive
	def channelOverviewsuccessful = parseJSON.channelOverview.successful
	def channelOverviewstopped = parseJSON.channelOverview.stopped
	def channelOverviewunknown = parseJSON.channelOverview.unknown
	def channelOverviewunregistered = parseJSON.channelOverview.unregistered
	def jobOverviewcancelled = parseJSON.jobOverview.cancelled
	def jobOverviewcompleted = parseJSON.jobOverview.completed
	def jobOverviewerror = parseJSON.jobOverview.error
	def BPMOverviewinprogress = parseJSON.BPMOverview.inprogress
	def BPMOverviewcanceled = parseJSON.BPMOverview.canceled
	def BPMOverviewcompleted = parseJSON.BPMOverview.completed
	def BPMOverviewfailed = parseJSON.BPMOverview.failed
	def BPMOverviewinerror = parseJSON.BPMOverview.inerror
	def BPMOverviewsupended = parseJSON.BPMOverview.supended
	
	def date = parseJSON.execution.monitoringStartAt;
	message.setProperty("url_date", date.substring(0,10));
	message.setHeader("Content-Type","application/x-ndjson");

	
	new_body = 	"{" +
	"    \"execution.executedAt\": \"" + executionmonitoringexecutedat + "\"," +
	"    \"execution.monitoringEndAt\": \"" + executionmonitoringendat + "\"," +
	"    \"execution.monitoringStartAt\": \"" + executionmonitoringstartat + "\"," +
	"    \"execution.type\": \"" + executiontype + "\"," +
	"    \"execution.version\": \"" + executionversion + "\"," +
	"    \"messageOverview.success\": " + messageOverviewsuccess + "," +
	"    \"messageOverview.cancelled\": " + messageOverviewcancelled + "," +
	"    \"messageOverview.delivering\": " + messageOverviewdelivering + "," +
	"    \"messageOverview.error\": " + messageOverviewerror + "," +
	"    \"messageOverview.holding\": " + messageOverviewholding + "," +
	"    \"messageOverview.toBeDelivered\": " + messageOverviewtoBeDelivered + "," +
	"    \"messageOverview.waiting\": " + messageOverviewwaiting + "," +
	"    \"messageOverview.numberDays\": " + messageOverviewnumberDays + "," +
	"    \"channelOverview.error\": " + channelOverviewerror + "," +
	"    \"channelOverview.inactive\": " + channelOverviewinactive + "," +
	"    \"channelOverview.successful\": " + channelOverviewsuccessful + "," +
	"    \"channelOverview.stopped\": " + channelOverviewstopped + "," +
	"    \"channelOverview.unknown\": " + channelOverviewunknown + "," +
	"    \"channelOverview.unregistered\": " + channelOverviewunregistered + "," +
	"    \"jobOverview.cancelled\": " + jobOverviewcancelled + "," +
	"    \"jobOverview.completed\": " + jobOverviewcompleted + "," +
	"    \"jobOverview.error\": " + jobOverviewerror + "," +
	"    \"BPMOverview.inprogress\": " + BPMOverviewinprogress + "," +
	"    \"BPMOverview.canceled\": " + BPMOverviewcanceled + "," +
	"    \"BPMOverview.completed\": " + BPMOverviewcompleted + "," +
	"    \"BPMOverview.failed\": " + BPMOverviewfailed + "," +
	"    \"BPMOverview.inerror\": " + BPMOverviewinerror + "," +
	"    \"BPMOverview.supended\": " + BPMOverviewsupended + "," +
	"    \"system.name\": \"" + systemname + "\"," +
	"    \"tenant.code\": \"" + tenantcode + "\"," +
		"}" ;
	def resultJSON = new JsonSlurper().parseText(new_body)
	def jsonFormateado = JsonOutput.toJson(resultJSON)
	salida = salida + "{\"index\":{\"_index\": \"bplus-sappo-overview-" + date.substring(0,10) + "\"}}\r\n" + jsonFormateado + "\r\n"
	
	// Canales
	parseJSON.channelsDetail.each{ cd ->
		
		def status = cd.status
		def channelSapId = cd.channelSapId
		def channelName =  cd.channelName
		def channelComponent =  cd.channelComponent
		def channelParty = cd.channelParty
		
		if ((cd.detail != null) && (!cd.detail.equals("")))
			{
				byte[] decoded_sdn = cd.detail.decodeBase64()
				String decoded = new String(decoded_sdn)
				decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
				cd.detail = decoded
			}
		
		def detail = cd.detail

		
		new_body = 	"{" +
				"    \"execution.executedAt\": \"" + executionmonitoringexecutedat + "\"," +
				"    \"execution.monitoringEndAt\": \"" + executionmonitoringendat + "\"," +
				"    \"execution.monitoringStartAt\": \"" + executionmonitoringstartat + "\"," +
				"    \"execution.type\": \"" + executiontype + "\"," +
				"    \"execution.version\": \"" + executionversion + "\"," +
				"    \"channelsDetail.status\": \"" + status + "\"," +
				"    \"channelsDetail.channelSapId\": \"" + channelSapId + "\"," +
				"    \"channelsDetail.channelName\": \"" + channelName + "\"," +
				"    \"channelsDetail.channelComponent\": \"" + channelComponent + "\"," +
				"    \"channelsDetail.channelParty\": \"" + channelParty + "\"," +
				"    \"channelsDetail.detail\": \"" + detail + "\"," +
				"    \"system.name\": \"" + systemname + "\"," +
				"    \"tenant.code\": \"" + tenantcode + "\"," +
					"}" ;
		resultJSON = new JsonSlurper().parseText(new_body)
		jsonFormateado = JsonOutput.toJson(resultJSON)
    	salida = salida + "{\"index\":{\"_index\": \"bplus-sappo-channels-" + date.substring(0,10) + "\"}}\r\n" + jsonFormateado + "\r\n"

		
	}
	
	
	// BPMs
	parseJSON.bpmsDetail.each{ bd ->
		
		def id = bd.id
		def title = bd.title
		def updated =  bd.updated.replaceAll(" ","T")
		def category =  bd.category
		def link = bd.link
		def instanceId = bd.instanceId
		def name = bd.name
		def subject =  bd.subject
		def startDate =  bd.startDate.replaceAll(" ","T")
		def endDate = bd.endDate.replaceAll(" ","T")
		def modelId = bd.modelId
		def definitionId = bd.definitionId
		def parentProcessInstanceId =  bd.parentProcessInstanceId
		def processInitiatorName =  bd.processInitiatorName
		
		new_body = 	"{" +
				"    \"execution.executedAt\": \"" + executionmonitoringexecutedat + "\"," +
				"    \"execution.monitoringEndAt\": \"" + executionmonitoringendat + "\"," +
				"    \"execution.monitoringStartAt\": \"" + executionmonitoringstartat + "\"," +
				"    \"execution.type\": \"" + executiontype + "\"," +
				"    \"execution.version\": \"" + executionversion + "\"," +
				"    \"BPMsDetail.id\": \"" + id + "\"," +
				"    \"BPMsDetail.title\": \"" + title + "\"," +
				"    \"BPMsDetail.updated\": \"" + updated + "\"," +
				"    \"BPMsDetail.category\": \"" + category + "\"," +
				"    \"BPMsDetail.link\": \"" + link + "\"," +
				"    \"BPMsDetail.instanceId\": \"" + instanceId + "\"," +
				"    \"BPMsDetail.name\": \"" + name + "\"," +
				"    \"BPMsDetail.subject\": \"" + subject + "\"," +
				"    \"BPMsDetail.startDate\": \"" + startDate + "\"," +
				"    \"BPMsDetail.endDate\": \"" + endDate + "\"," +
				"    \"BPMsDetail.modelId\": \"" + modelId + "\"," +
				"    \"BPMsDetail.definitionId\": \"" + definitionId + "\"," +
				"    \"BPMsDetail.status\": \"" + errorCategory + "\"," +
				"    \"BPMsDetail.parentProcessInstanceId\": \"" + parentProcessInstanceId + "\"," +
				"    \"BPMsDetail.rootProcessInstanceId\": \"" + rootProcessInstanceId + "\"," +
				"    \"BPMsDetail.processInitiatorName\": \"" + processInitiatorName + "\"," +
				"    \"system.name\": \"" + systemname + "\"," +
				"    \"tenant.code\": \"" + tenantcode + "\"," +
					"}" ;
		resultJSON = new JsonSlurper().parseText(new_body)
		jsonFormateado = JsonOutput.toJson(resultJSON)
    	salida = salida + "{\"index\":{\"_index\": \"bplus-sappo-bpms-" + date.substring(0,10) + "\"}}\r\n" + jsonFormateado + "\r\n"		
	}
	
	parseJSON.certificatesDetail.each{ cd ->
		
		def alias = cd.alias
		//def keystoreView = cd.keystoreView
		//def keytype =  cd.keytype
		//def keysize =  cd.keysize
		def validNotBefore = cd.validNotBefore.replaceAll(" ","T")
		def validNotAfter = cd.validNotAfter.replaceAll(" ","T")
		//def serialNumber = cd.serialNumber
		//def signatureAlgorithm =  cd.signatureAlgorithm
		//def version =  cd.version
		//def fingerprintSha1 =  cd.fingerprintSha1
		//def fingerprintSha256 =  cd.fingerprintSha256
		//def fingerprintSha512 =  cd.fingerprintSha512
		//def type =  cd.type
		//def owner = cd.owner
		//def lastModifiedBy =  cd.lastModifiedBy.replaceAll(" ","T")
		//def lastModifiedTime =  cd.lastModifiedTime.replaceAll(" ","T")
		//def createdBy =  cd.createdBy
		//def createdTime =  cd.createdTime.replaceAll(" ","T")
		//def status =  cd.status
		//def relatedIflows =  cd.relatedIflows
		
		if ((cd.subjectDN != null) && (!cd.subjectDN.equals("")))
			{
				byte[] decoded_sdn = cd.subjectDN.decodeBase64()
				String decoded = new String(decoded_sdn)
				decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
				cd.subjectDN = decoded
			}
			if ((cd.issuerDN != null) && (!cd.issuerDN.equals("")))
			{
				byte[] decoded_idn = cd.issuerDN.decodeBase64()
				String decoded = new String(decoded_idn)
				decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
				cd.issuerDN = decoded
			}
		
		def subjectDN =  cd.subjectDN
		def issuerDN =  cd.issuerDN

		
		new_body = 	"{" +
				"    \"execution.executedAt\": \"" + executionmonitoringexecutedat + "\"," +
				"    \"execution.monitoringEndAt\": \"" + executionmonitoringendat + "\"," +
				"    \"execution.monitoringStartAt\": \"" + executionmonitoringstartat + "\"," +
				"    \"execution.type\": \"" + executiontype + "\"," +
				"    \"execution.version\": \"" + executionversion + "\"," +
				"    \"certificatesDetail.alias\": \"" + alias + "\"," +
				"    \"certificatesDetail.issuerDN\": \"" + issuerDN + "\"," +
				"    \"certificatesDetail.subjectDN\": \"" + subjectDN + "\"," +
				"    \"certificatesDetail.validNotAfter\": \"" + validNotAfter + "\"," +
				"    \"certificatesDetail.validNotBefore\": \"" + validNotBefore + "\"," +
				"    \"system.name\": \"" + systemname + "\"," +
				"    \"tenant.code\": \"" + tenantcode + "\"," +
					"}" ;
		resultJSON = new JsonSlurper().parseText(new_body)
		jsonFormateado = JsonOutput.toJson(resultJSON)
    	salida = salida + "{\"index\":{\"_index\": \"bplus-sappo-certificates-" + date.substring(0,10) + "\"}}\r\n" + jsonFormateado + "\r\n"		

		
	}
	
	// JObs
	parseJSON.jobsDetail.each{ jd ->
		
		def status = jd.status
		def name = jd.name
		def returnCode =  jd.returnCode
		def node =  jd.node
		def user = jd.user
		def startAt = jd.startAt.replaceAll(" ","T")
		def endAt = jd.endAt.replaceAll(" ","T")

		
		new_body = 	"{" +
				"    \"execution.executedAt\": \"" + executionmonitoringexecutedat + "\"," +
				"    \"execution.monitoringEndAt\": \"" + executionmonitoringendat + "\"," +
				"    \"execution.monitoringStartAt\": \"" + executionmonitoringstartat + "\"," +
				"    \"execution.type\": \"" + executiontype + "\"," +
				"    \"execution.version\": \"" + executionversion + "\"," +
				"    \"jobsDetail.status\": \"" + status + "\"," +
				"    \"jobsDetail.name\": \"" + name + "\"," +
				"    \"jobsDetail.returnCode\": \"" + returnCode + "\"," +
				"    \"jobsDetail.node\": \"" + node + "\"," +
				"    \"jobsDetail.user\": \"" + user + "\"," +
				"    \"jobsDetail.startAt\": \"" + startAt + "\"," +
				"    \"jobsDetail.endAt\": \"" + endAt + "\"," +
				"    \"system.name\": \"" + systemname + "\"," +
				"    \"tenant.code\": \"" + tenantcode + "\"," +
					"}" ;
		resultJSON = new JsonSlurper().parseText(new_body)
		jsonFormateado = JsonOutput.toJson(resultJSON)
    	salida = salida + "{\"index\":{\"_index\": \"bplus-sappo-jobs-" + date.substring(0,10) + "\"}}\r\n" + jsonFormateado + "\r\n"		
		
	}
	
	// mensajes
	parseJSON.messagesDetail.each{ md ->
		
		def flowParty = md.flowParty
		def flowReceiverParty = md.flowReceiverParty
		def flowComponent =  md.flowComponent
		def flowReceiverComponent =  md.flowReceiverComponent
		def flowInterfaceName = md.flowInterfaceName
		def flowInterfaceNamespace = md.flowInterfaceNamespace
		def status = md.status
		def startTimeAt =  md.startTimeAt.replaceAll(" ","T")
		def scenario =  md.scenario
		def direction = md.direction
		def errorCategory = md.errorCategory
		def errorCode = md.errorCode
		def errorLabel =  md.errorLabel
		def node =  md.node
		def refToMessageId = md.refToMessageId
		def protocol = md.protocol
		def qualityOfService = md.qualityOfService
		def receiverInterface = md.receiverInterface
		def receiverInterfaceNamespace =  md.receiverInterfaceNamespace
		def retries =  md.retries
		def size = md.size
		def timesFailed = md.timesFailed
		def example = md.example
		
		if ((md.detail != null) && (!md.detail.equals("")))
			{
				byte[] decoded_sdn = md.detail.decodeBase64()
				String decoded = new String(decoded_sdn)
				decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
				md.detail = decoded
			}
		
		def detail = md.detail

		
		new_body = 	"{" +
				"    \"execution.executedAt\": \"" + executionmonitoringexecutedat + "\"," +
				"    \"execution.monitoringEndAt\": \"" + executionmonitoringendat + "\"," +
				"    \"execution.monitoringStartAt\": \"" + executionmonitoringstartat + "\"," +
				"    \"execution.type\": \"" + executiontype + "\"," +
				"    \"execution.version\": \"" + executionversion + "\"," +
				"    \"messagesDetail.flowParty\": \"" + flowParty + "\"," +
				"    \"messagesDetail.receiverParty\": \"" + flowReceiverParty + "\"," +
				"    \"messagesDetail.flowComponent\": \"" + flowComponent + "\"," +
				"    \"messagesDetail.flowReceiverComponent\": \"" + flowReceiverComponent + "\"," +
				"    \"messagesDetail.flowInterfaceName\": \"" + flowInterfaceName + "\"," +
				"    \"messagesDetail.flowInterfaceNamespace\": \"" + flowInterfaceNamespace + "\"," +
				"    \"messagesDetail.status\": \"" + status + "\"," +
				"    \"messagesDetail.startTimeAt\": \"" + startTimeAt + "\"," +
				"    \"messagesDetail.scenario\": \"" + scenario + "\"," +
				"    \"messagesDetail.direction\": \"" + direction + "\"," +
				"    \"messagesDetail.errorCategory\": \"" + errorCategory + "\"," +
				"    \"messagesDetail.errorCode\": \"" + errorCode + "\"," +
				"    \"messagesDetail.errorLabel\": " + errorLabel + "," +
				"    \"messagesDetail.node\": \"" + node + "\"," +
				"    \"messagesDetail.refToMessageId\": \"" + refToMessageId + "\"," +
				"    \"messagesDetail.protocol\": \"" + protocol + "\"," +
				"    \"messagesDetail.qualityOfService\": \"" + qualityOfService + "\"," +
				"    \"messagesDetail.receiverInterface\": \"" + receiverInterface + "\"," +
				"    \"messagesDetail.receiverInterfaceNamespace\": \"" + receiverInterfaceNamespace + "\"," +
				"    \"messagesDetail.retries\": \"" + retries + "\"," +
				"    \"messagesDetail.size\": \"" + size + "\"," +
				"    \"messagesDetail.timesFailed\": \"" + timesFailed + "\"," +
				"    \"messagesDetail.detail\": \"" + detail + "\"," +
				"    \"system.name\": \"" + systemname + "\"," +
				"    \"tenant.code\": \"" + tenantcode + "\"," +
					"}" ;
		resultJSON = new JsonSlurper().parseText(new_body)
		jsonFormateado = JsonOutput.toJson(resultJSON)
    	salida = salida + "{\"index\":{\"_index\": \"bplus-sappo-messages-" + date.substring(0,10) + "\"}}\r\n" + jsonFormateado + "\r\n"		
		
	}
	salida = salida + "\r\n"
	
	message.setBody(salida)
	return message;
}