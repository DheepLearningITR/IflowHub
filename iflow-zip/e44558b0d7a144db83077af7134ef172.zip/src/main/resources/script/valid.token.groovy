import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.json.simple.*
import groovy.json.*
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    //Get Body 
    def body = message.getBody(String.class);
	def map = message.getProperties();
	def etime = map.get("etime");
    //Define JSONSlurper

    def stringWriter = new StringWriter()
    
    
        def peopleBuilder = new MarkupBuilder(stringWriter)
        def currentdate = new Date()
        peopleBuilder.root {

                token("valid")
                expiry(etime.toString())
                //expiry(${date:now:yyyy-MM-dd})
        }
        def xml = stringWriter.toString()    
	   
    message.setBody(xml);
    return message;
}
