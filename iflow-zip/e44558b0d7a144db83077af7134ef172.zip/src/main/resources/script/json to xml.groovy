import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.json.simple.*
import groovy.json.*
import groovy.xml.MarkupBuilder
import groovy.time.*

def Message processData(Message message) {
    //Get Body 
    def body = message.getBody(String.class);

    //Define JSONSlurper
    def jsonSlurper = new JsonSlurper()
    def list = jsonSlurper.parseText(body)

    def stringWriter = new StringWriter()
        def peopleBuilder = new MarkupBuilder(stringWriter)
        //String token = list.token_type +" " + list.access_token
        def currentdate = new Date()
		def expiry = new Date()
		def epoch = list.oracle_token_attrs_retrieval.exp

		def utcSeconds = list.oracle_token_attrs_retrieval.exp
		def d = new Date(0) // The 0 there is the key, which sets the date to the epoch
		d.setSeconds(utcSeconds); 
		def diff = d.getTime() - currentdate.getTime()
		def diff_as_date = new Date(diff) 
		def hour = diff_as_date.getHours() // hours
		def mins = diff_as_date.getMinutes() // minutes
		def sec = diff_as_date.getSeconds() // seconds		
		 
        peopleBuilder.root {
            	successful(list.successful)
            	oracle_token_attrs_retrieval(list.oracle_token_attrs_retrieval)
            	exp(d)
            	duration(hour+":"+ mins+ ":"+sec)
            	prn(list.oracle_token_attrs_retrieval.prn)
                error(list.error)
                error_description(list.error_description)
        }
        def xml = stringWriter.toString()    
     
    message.setBody(xml);
    return message;
}
