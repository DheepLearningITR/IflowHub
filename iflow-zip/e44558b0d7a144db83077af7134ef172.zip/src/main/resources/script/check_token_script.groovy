importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {	
//properties
	map = message.getProperties();
	var etime = map.get("token_time");
	var edate = map.get("token_date");	
//Calucuate the expiry date and time 	
	var expiry = new Date(edate);
        expiry.setTime(expiry.getTime()+parseInt(etime)*1000);  	
	var currentdate = new Date();
//set indicator to start new flow to fectch new token	
	if(currentdate > expiry){
		message.setProperty("Expire", "X");
	}     
	return message;
}
