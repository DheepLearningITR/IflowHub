import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
	    def testRun = message.getProperties().get("testRun");
		if(testRun!=null && testRun!='' && testRun!='false'){
			messageLog.addCustomHeaderProperty("cbr_testRun", testRun);		
        } 
        def cbrJobArchitecture = message.getProperties().get("cbrJobArchitecture");
		if(cbrJobArchitecture!=null){
			messageLog.addCustomHeaderProperty("cbr_JobArchitecture", cbrJobArchitecture);		
        }
        def sfsfFamilyContext = message.getProperties().get("sfsfFamilyContext");
		if(sfsfFamilyContext!=null){
			messageLog.addCustomHeaderProperty("sfsf_FamilyContext", sfsfFamilyContext);		
        }        
	}
	return message;
}

def Message cbrJobFamilyIds(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def cbrJobFamilyIdList = message.getProperties().get("cbrJobFamilyIdIdList");
		if(cbrJobFamilyIdList!=null && cbrJobFamilyIdList!=''){
			messageLog.addCustomHeaderProperty("cbr_JobFamilyIdIds", cbrJobFamilyIdIdList);		
        }
	}
	return message;
}

