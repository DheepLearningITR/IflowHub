import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.json.JsonOutput;

//resynch logic
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

def Message validate(Message message) {

    def headers = message.getHeaders();
    def properties = message.getProperties();    
    def sfsfCompanyId = properties.get("sfsfCompanyId");
    def cbrLastSynchDateTime = headers.get("cbrLastSynchDateTime");
    
    def errors = []; // Unified error list
    
    // Validate IFLOW PARAMETERS --------------------
    def mandatoryParams = [
        "sfsfCompanyId",
        "processDirect_jobFamilyCreate",
        "processDirect_jobFamilyUpdate"
    ]
    mandatoryParams.each { key ->
        if (!properties[key]?.trim()) {
            errors.add(["errorCode": "[SAP-IS] MISSING_IFLOW_PARAM", "errorMessage": key]);
        }
    }
    
    // Validate HEADERS --------------------
    
    // Extract specific headers with defaults if necessary
    def cbrJobArchitecture = headers.get("cbrJobArchitecture");
    def testRun = headers.get("testRun") ?: "false";    
    def sfsfFamilyContext = headers.get("sfsfFamilyContext");    
    
    def mandatoryHeaders = [
        "cbrJobArchitecture",
        "sfsfFamilyContext"
    ]
    
    mandatoryHeaders.each { key ->
        if (!headers[key]?.trim()) {
            errors.add(["errorCode": "[SAP-IS] MISSING_HDR", "errorMessage": key]);
        }
    }    

    // Validate VM CONFIG ---------------------
    if(sfsfCompanyId){
        def configMappings = [
            "sfsfAddress"            : "cbrInt_SuccessFactors_API:Address",
            "sfsfCredential"         : "cbrInt_SuccessFactors_API:Credential",        
            "sfsfJobProfileTemplate" : "cbrInt_SuccessFactors_JobProfileTemplate:TemplateId", 
        ];
        
        configMappings.each { property, vmconfig ->
            if (!properties[property]?.trim()) {
                errors.add(["errorCode": "[SAP-IS] MISSING_VMCONFIG", "errorMessage": "${vmconfig}"]);
            }
        }
    }

    // If there are any errors, set the error response and return
    if (!errors.isEmpty()) {
        def errorJson = JsonOutput.toJson(["errors": errors]);
        message.setProperty("errorJson", errorJson);
        throw new IllegalArgumentException(errorJson); // Exit with all errors
    }

    //Validation passed!  ---------------------
    if(cbrLastSynchDateTime){
        //truncate time to only include seconds: e.g. '2025-12-10T14:05:31.807480Z'
        cbrLastSynchDateTime = Instant.parse(cbrLastSynchDateTime).truncatedTo(ChronoUnit.SECONDS).toString();
    }


    // Set properties for further processing
    message.setProperty("cbrLastSynchDateTime", cbrLastSynchDateTime);    
    message.setProperty("cbrJobArchitecture", cbrJobArchitecture);
    message.setProperty("sfsfFamilyContext", sfsfFamilyContext);  
	message.setProperty("testRun", testRun);

    return message;
}

def Message build_hmapSFSFJobFamily(Message message) {
	
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
	HashMap<String, String> hmapJobFamily = map.get("hmap_sfsfJobFamily"); 
	if( hmapJobFamily == null ){
	    hmapJobFamily = new HashMap<String, String>();	
	}

    def dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
	def Root = new XmlSlurper().parse(body);
    	Root.FamilyEntity.each{
    	    if(it.cust_cbrJobFamilyId.toString()!=null && it.cust_cbrJobFamilyId.toString()!=''){
    	        
                //convert to UTC format: e.g. 2025-03-19T10:58:17.000 >> 2025-03-19T10:58:17Z
        	    def sfsfModDateTime = LocalDateTime.parse(it.lastModifiedDateTime.toString(), dateFormat);
        	    def sfsfModDateTimeUTC = sfsfModDateTime.toInstant(ZoneOffset.UTC); // Convert to UTC    	        
    	        
    	        //cbrJobFamilyId filled!
        	    hmapJobFamily.put(it.cust_cbrJobFamilyId.toString(),it.externalCode.toString()+'|'+sfsfModDateTimeUTC.toString()); 
    	    }
    	}
	message.setProperty("hmap_sfsfJobFamily", hmapJobFamily);
	return message;
}

def Message process(Message message) {
	
	def body = message.getBody(java.lang.String);
	def map = message.getProperties();
	def mapping_jobFamilyUpdate = map.get("mapping_jobFamilyUpdate");
	def mapping_jobFamilyCreate = map.get("mapping_jobFamilyCreate");
	def sfsfJobProfileTemplate = map.get("sfsfJobProfileTemplate");
	HashMap<String, String> hmapJobFamily = map.get("hmap_sfsfJobFamily"); 
	if(hmapJobFamily==null){
	    hmapJobFamily = new HashMap<String, String>();
	}

    def cbrLastSynchDateTime = map.get('cbrLastSynchDateTime');	
    def cbrLastSynchDateTimeInst = null;
    if(cbrLastSynchDateTime){
        cbrLastSynchDateTimeInst = Instant.parse(cbrLastSynchDateTime); //convert to Instant
    }

	def sumCreate = 0;
	def sumUpdate = 0;
	def parser = new XmlParser();
	def Root = parser.parseText(body);
    Root.children.each{r->

        //ModifiedDateTime in UTC
        def cbrUpdatedAtInst = null; 
        if(r.updatedAt[0].text()){
            //truncate time to only include seconds: e.g. '2025-12-10T14:05:31.807480Z'
            def cbrUpdatedAt = Instant.parse(r.updatedAt[0].text()).truncatedTo(ChronoUnit.SECONDS).toString();
            cbrUpdatedAtInst = Instant.parse(cbrUpdatedAt); //convert to Instant
        }

        if(hmapJobFamily.containsKey(r.id[0].text())){
            //found, detect changes based on last modified date and last synch date
            
            def changeDetected = false;
            String sfsfJobFam = hmapJobFamily.get(r.id[0].text());
            def (sfsfJobFamilyExtCode,sfsfModDateTime) = sfsfJobFam.split("\\|");
            
            if(cbrLastSynchDateTime){
                def sfsfModDateTimeInst = Instant.parse(sfsfModDateTime); //convert to Instant
                if(sfsfModDateTimeInst.isAfter(cbrLastSynchDateTimeInst)){
                    //compare sfsfJobProfile modified date with last sync date. Resynch if sfsfJP has been modified AFTER last synch date
                    changeDetected = true;
                }else if(cbrUpdatedAtInst.isAfter(cbrLastSynchDateTimeInst)){
                    //cobrainer Job Family/Cluster has been changed after the last synch
                    changeDetected = true;
                }
            }else{
                //synch all if lastsynchdate is not sent
                changeDetected = true;
            }
            
            if(changeDetected == true){
                sumUpdate++;
                //append new nodes
                r.appendNode("status",[:],'UPDATE');
                r.appendNode("mapping_jobFamilyUpdate",[:],mapping_jobFamilyUpdate);
                r.appendNode("sfsfExternalCode",[:],sfsfJobFamilyExtCode)                
            }else{
                //no changes detected
                r.replaceNode { };
            }
        }else{
            //not found using CBR Id, CREATE FAMILY in SFSF
            sumCreate++; //counter
            r.appendNode("status",[:],'CREATE');
            r.appendNode("sfsfJobProfileTemplate",[:],sfsfJobProfileTemplate);
            r.appendNode("mapping_jobFamilyCreate",[:],mapping_jobFamilyCreate);
        }
    }
    
    message.setProperty("talentPayload","");                //clear processed data
    message.setProperty("hmap_sfsfJobFamily","");           //clear processed data
    message.setBody(XmlUtil.serialize(Root));
    message.setProperty("sumCreate",sumCreate.toString());
    message.setProperty("sumUpdate",sumUpdate.toString());
	return message;
}
