package com.sap.s4hana.eureka.business.tenantlcmplus.core.domain.service

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonOutput;
import org.w3c.dom.NodeList;
import java.util.*
import groovy.xml.*;
import java.time.LocalDateTime;
import groovy.util.XmlParser;
import java.time.Clock

def Message printOutLog(Message message) {
    //Headers
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null)
    {
        messageLog.addAttachmentAsString("out Log current Payload:", body, "text/plain");
        messageLog.addAttachmentAsString("out Log current headers:", message.getHeaders() as String, "text/plain");
        messageLog.addAttachmentAsString("Log current transRootNode:", message.getProperty("transNodeStr"), "text/plain");
    }

    return message;
}

def Message printInitLog(Message inputMessage) {
    //Body

    //Headers
    def headers = inputMessage.getHeaders() as String;
    def body = inputMessage.getBody(java.lang.String) as String;
    def properties = inputMessage.getProperties() as String;
    def messageLog = messageLogFactory.getMessageLog(inputMessage);

    if(messageLog != null)
    {
        messageLog.addAttachmentAsString("Log init Payload:", body, "text/plain");
        messageLog.addAttachmentAsString("Log init headers:", headers, "text/plain");
        messageLog.addAttachmentAsString("Log init properties:", properties, "text/plain");
    }
    
    def parser = new XmlParser()
    def dom = parser.parseText(body)
    
    inputMessage.setProperty("I_CONTINUE", "T") 

    def settleClearingAccountingDocNumList = dom.bo.root.docFlow.findAll({ it.documentType.text() == 'CLEARING_ACCOUNTING_DOCUMENT' }).collect({it->it.documentNumber?.text()})
    if( dom.bo.root.claimType == "INVOICE" || settleClearingAccountingDocNumList == null || settleClearingAccountingDocNumList.size() == 0 ){
       messageLog.addAttachmentAsString("settleClearingAccountingDocNumList is empty", properties as String, "text/plain");
       inputMessage.setProperty("I_CONTINUE", "F")
       LocalDateTime utcDateTime = LocalDateTime.now(Clock.systemUTC())
       XmlSlurper xmlSlurper = new XmlSlurper()
       def rootXml = xmlSlurper.parseText("<?xml version=\"1.0\" encoding=\"UTF-8\"?><root></root>")

       def flowBodyXml = xmlSlurper.parseText(body)
        rootXml.appendNode {
          settlementUUID(flowBodyXml.bo.root.settlementUUID.text())
          timestamp(utcDateTime)
          status("CANCELLED")
          message("cancel settlement successfully")
        }
       rootXml.appendNode(flowBodyXml.documentTransactions)
       inputMessage.setBody(XmlUtil.serialize(rootXml))

       return inputMessage
    }

    return inputMessage;
}



def Message printExLog(Message message) {

    def headers = message.getHeaders() as String;
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties();
    def messageLog = messageLogFactory.getMessageLog(message);
    def ex = properties.get("CamelExceptionCaught");
    if(messageLog != null)
    {
        messageLog.addAttachmentAsString("main process exception Log current Payload:", body, "text/plain");
        messageLog.addAttachmentAsString("main process exception Log current headers:", headers, "text/plain");
        messageLog.addAttachmentAsString("exception output details:", ex.toString(), "text/plain");
    }

    return message;
}

def Message prepareRequest(Message message) {
    //Body
    def body = message.getBody(java.lang.String) as String;
    def parser = new XmlParser()
    def dom = parser.parseText(body)
    stashTrans(dom, message)
    def createdOn = ''
    def fiscalYear = ''
    def companyCode = ''
    def documentNumber = ''
    def docFlow = dom.bo.root.docFlow
    if(docFlow != null) {
        for(def docNode : docFlow) {
            if(docNode.documentType.text() == 'CLEARING_ACCOUNTING_DOCUMENT') {
                createdOn = docNode.createdOn.text()
                fiscalYear = docNode.fiscalYear.text()
                companyCode = docNode.companyCode.text()
                documentNumber = docNode.documentNumber.text()
            }
        }
    }
    if('' == createdOn && '' == fiscalYear && '' == companyCode &&'' == documentNumber) {
        return message
    }
    if (''== createdOn) {
        createdOn = LocalDateTime.now().toString()
    }
    def requestParams = "ClearingAccountingDocument='%s'&ClearingDocFiscalYear='%s'&CompanyCode='%s'&DeactivateOpenCorrespondence=false&DocumentDate=datetime'%s'&ReversalPostingDate=datetime'%s'&ReversalReason='01'"
    //requestParams = String.format(requestParams, documentNumber, fiscalYear, companyCode, createdOn, LocalDateTime.now().toString())
    requestParams = String.format(requestParams, documentNumber, fiscalYear, companyCode, createdOn, createdOn)
    message.setHeader("requestParams", requestParams)
    return message
}


def void stashTrans(Node dom, Message message) {
    Node transNode = dom.trans[0];
    message.setProperty("transNodeStr",XmlUtil.asString(transNode));
}


def Message prepareDocTransAndIsRetry(Message message) {
    def headers = message.getHeaders();
    def camelHttpResponseCode = headers.get("CamelHttpResponseCode");
    if (camelHttpResponseCode == null) {
        return message;
    }
    message.setProperty("transactionsTimestamp", LocalDateTime.now())
    if (camelHttpResponseCode >= 200 && camelHttpResponseCode < 300) {
        message.setProperty("isRetry", false);
        addDocumentTransactions(message, "N/A", "N/A", "N/A");
        return message;
    }
    def body = message.getBody(java.lang.String) as String;
    def parser = new XmlParser()
    StringBuilder messageBuilder = new StringBuilder()
    if(body == null || body.trim().length() == 0){
         messageBuilder.append("Unable to reset and reverse the clearing SAP S/4HANA. \n")
         messageBuilder.append("empty response body")
         errorMessage = messageBuilder.toString()
         message.setProperty("errorMsg", errorMessage);
         return message
    }
 
    if (camelHttpResponseCode == 400) {
        def dom = parser.parseText(body)
        def code = dom.code.text();
        if ('FS/601'.equals(code) || 'FS/604'.equals(code)) {
            message.setProperty("isRetry", false);
            addDocumentTransactions(message, "N/A", "N/A", "N/A");
            return message;
        }
    }
    
    String errorMessage = body
    if(errorMessage != null && errorMessage.trim().length() > 0){
        messageBuilder.append("Unable to reset and reverse the clearing SAP S/4HANA. \n")
        
         String trimXMLErrorMessage = errorMessage
                .replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "")
                .replaceAll("<[^>]+>", "")
                .replaceAll("\\r|\\n", "")
                .replaceAll("\\s+", " ");
        messageBuilder.append(trimXMLErrorMessage)
        errorMessage = messageBuilder.toString()
    }
    message.setProperty("errorMsg", errorMessage);
    return message;
}

def Message sleepForSeconds(Message message) {

    //Properties
    def properties = message.getProperties();
    def sleepTime = properties.get("sleepTime") as Integer;
    def retryCount = properties.get("retryCount") as Integer;

    if(retryCount != 0){
        new Object().sleep(sleepTime*1000);
    }

    return message;
}

def void addDocumentTransactions(Message message, String documentNumberValue, String fiscalYearValue, String companyCodeValue) {
    def strXml = new StringWriter();
    def mb = new MarkupBuilder(strXml);
    def properties = message.getProperties();
    def documentTypeValue = properties.get("documentType") as String;
    mb.documentTransactions{
        documentType(documentTypeValue)
        documentNumber(documentNumberValue)
        fiscalYear(fiscalYearValue)
        createdOn(LocalDateTime.now())
        companyCode(companyCodeValue)
    }
    message.setProperty("documentTransactionsNode", strXml.toString());
}


def Message prepareDefaultDocTrans(Message message) {
    def strXml = new StringWriter();
    def mb = new MarkupBuilder(strXml);
    def properties = message.getProperties();
    def documentTypeValue = properties.get("documentType") as String;
    mb.documentTransactions{
        documentType(documentTypeValue)
        documentNumber("N/A")
        fiscalYear("N/A")
        createdOn(LocalDateTime.now())
        companyCode("N/A")
    }
    message.setProperty("documentTransactionsNode", strXml.toString());
    return message;
}


def Message prepareCallTrans(Message message) {
    def bodyVal = message.getBody(java.lang.String) as String;
    def properties = message.getProperties()
    def headers = message.getHeaders()

    def parser = new XmlParser()

    def transRootNodeStr = properties.get("transNodeStr");
    def transRootNode

    if(transRootNodeStr == null){
        transRootNode = new Node(null, "trans")
    }else{
        transRootNode = parser.parseText(transRootNodeStr)
    }


    def requestParams = headers.get("requestParams")
    def retryNum = properties.get("retryCount") as Integer

    message.setProperty("retryCount", retryNum + 1)

    def documentType = properties.get("documentType") as String
    Map attributes = new HashMap();
    attributes.put("api", documentType)
    attributes.put("callOrder", retryNum)

    def tranNode = new Node(transRootNode, "tran", attributes)

    def requestNode = new Node(tranNode, "request")

    def paramsNode = new Node(requestNode, "params")
    def bodyNode = new Node(requestNode, "body")
    paramsNode.setValue(requestParams)

    if(bodyVal != null){
        def dom = parser.parseText(bodyVal)
        def responseNode = new Node(tranNode, "response")
        responseNode.append(dom)  
    }


    message.setProperty("transNodeStr", XmlUtil.asString(transRootNode));

    return message;
}
