import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def properties = message.getProperties();
    
    //incrementar contador
    def resultRecords = properties.get("resultRecords");
    def valueCount = properties.get("count");
    def rfxEvent = resultRecords[valueCount];
    
    //count insertion
    def valueInsertedCount = properties.get("insertedCount");
    valueInsertedCount = valueInsertedCount + 1;
    message.setProperty("insertedCount", valueInsertedCount);

     // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    
    def db_schema = properties.get('Database_Schema_Name');
    
    //eventState: 
    //  - PendingSelectionState -> 6
    //  - ClosedState -> 7
    //  - CancelledState -> 8
    def stepFlow = 'DRAFT';
    if (rfxEvent.EventState == 6) {
        stepFlow = 'NEW';
    }
    else if (rfxEvent.EventState == 7) {
        stepFlow = 'CLOSED';
    }
    else if (rfxEvent.EventState == 8) {
        stepFlow = 'CANCELLED';
    }
    
    sqlStatement.root {
        sqlStatement.InsertStatement {
            sqlStatement.app_sourcing_events(action: 'INSERT') {
                sqlStatement.table(db_schema + '.APP_SOURCING_EVENTS')
                sqlStatement.access {
                    sqlStatement.INTERNAL_ID(rfxEvent.InternalId)
                    sqlStatement.TITLE(rfxEvent.Title)
                    sqlStatement.STATUS(rfxEvent.Status)
                    sqlStatement.EVENT_STATE(rfxEvent.EventState)
                    sqlStatement.DESCRIPTION(rfxEvent.Description)
                    sqlStatement.EVENT_TYPE(rfxEvent.EventType)
                    if (rfxEvent.DocumentId) {
                        sqlStatement.DOCUMENT_ID(rfxEvent.DocumentId.InternalId)
                    }
                    sqlStatement.OWNER_NAME(rfxEvent.Owner.Name)
                    sqlStatement.IS_TEST(rfxEvent.IsTest)
                    sqlStatement.ACTIVE(rfxEvent.Active)
                    sqlStatement.TIME_UPDATED(rfxEvent.TimeUpdated)
                    sqlStatement.LAST_MODIFIED(rfxEvent.LastModified)
                    sqlStatement.TIME_CREATED(rfxEvent.TimeCreated)
                    sqlStatement.CREATEDAT((new Date()).format( 'yyyy-MM-dd HH:mm:ss' ))
                    sqlStatement.CREATEDBY(properties.get('Extension_User'))
                    sqlStatement.STEP_FLOW(stepFlow)
                    sqlStatement.HAS_TEMPLATE_OBJECT(rfxEvent.TemplateObject != null)
                }
            }
        }
    };
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('RFX SQL Insert', writer.toString(), 'text/plain');
    
    message.setBody(writer.toString());
  
    return message;
}