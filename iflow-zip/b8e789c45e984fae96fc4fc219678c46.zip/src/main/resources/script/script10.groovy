import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def properties = message.getProperties();
    
    def pageToken = properties.get("pageToken");
    
    if (pageToken == '') {
        message.setProperty("hasPageToken", '0');
    } 
    else {
        message.setProperty("hasPageToken", '1');
    }

    return message;
}