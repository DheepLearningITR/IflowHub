import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();
    
    def jsonSlurper = new JsonSlurper();
    def apiResult = jsonSlurper.parse(body);
    
    def properties = message.getProperties();
    message.setProperty("count", 0);
    message.setProperty("totalResult", apiResult.Records.size);
    message.setProperty("resultRecords", apiResult.Records);
    
    message.setProperty("hasResults", apiResult.Records.size > 0 ? '1' : '0');
    
    def executionLog = properties.get('executionLog');
    def pageToken = properties.get("pageToken");
    executionLog = executionLog + 'Total Results in API-Token-' + pageToken + ': ' + apiResult.Records.size + '. ';
    message.setProperty("executionLog", executionLog);
    
    if (apiResult.PageToken) {
        message.setProperty("pageToken", apiResult.PageToken);
    }
    else {
        message.setProperty("pageToken", '');
    }
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('RFX SQL Insert', apiResult.toString(), 'text/plain');
    
    return message;
}