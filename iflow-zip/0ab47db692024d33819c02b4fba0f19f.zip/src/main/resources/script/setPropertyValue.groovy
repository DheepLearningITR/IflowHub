import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {
      def body = new JsonSlurper().parseText(message.getBody(String));
      message.setProperty("ServiceConfirmation", body.ServiceConfirmation)
       return message;
}