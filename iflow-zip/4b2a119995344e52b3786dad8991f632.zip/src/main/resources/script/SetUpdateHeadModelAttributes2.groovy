import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.Field
import java.net.URLEncoder

// Define the update body format for Signavio model
@Field static String SIGNAVIO_MODEL_UPDATE_BODY_FORMAT = 'parent=%s&name=%s&description=%s&comment=%s&json_xml=%s'

def Message processData(Message message) {
    // Parse the message body into a JSON object
    def body = message.getBody()
    def jsonModel = new JsonSlurper().parse(body)

    // Fetch the properties required to format the update body for Signavio model
    def jsonXML = URLEncoder.encode(message.getProperty('signavioHeadProcessModel'), "UTF-8")
    def parent = URLEncoder.encode(message.getProperty('signavioHeadProcessParent'), "UTF-8")
    def name = URLEncoder.encode(message.getProperty('signavioHeadProcessName'), "UTF-8")
    def description = URLEncoder.encode(message.getProperty('signavioHeadProcessDescription'), "UTF-8")
    def comment = URLEncoder.encode(message.getProperty('signavioComment'), "UTF-8")

    // Format the update body for Signavio model using extractor properties and predefined format
    def signavioUpdateBody = String.format(SIGNAVIO_MODEL_UPDATE_BODY_FORMAT, parent, name, description, comment, jsonXML)

    // Set the formatted Signavio update body as the new message body
    message.setBody(signavioUpdateBody)

    return message;
}