import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import com.google.gson.Gson

def Message processData(Message message) {
    // Parse the message body into JSON 
    def json = new JsonSlurper().parseText(message.getBody(String));

    // Set the properties of the message based on the parsed JSON
    message.setProperty('signavioPublishedProcessModel', new Gson().toJson(json));
    message.setProperty('signavioPublishedProcessName', message.getProperty('processName'));
    message.setProperty('signavioPublishedProcessDescription',json.properties.documentation);
   
    // Extract the 'calmCustomSolutionProcessId' header and 'fieldCALMCustomSolutionProcessId' property
    def calmCustomSolutionProcessId = message.getHeader('calmCustomSolutionProcessId', String);
    def calmSolutionField = message.getProperty("fieldCALMCustomSolutionProcessId");
	
	// Get the 'cloudALMDiagramLink' property and 'fieldCALMCustomSolutionProcessLink' property
    def cloudALMDiagramLink = message.getProperty("cloudALMDiagramLink");
	def calmLinkField = message.getProperty("fieldCALMCustomSolutionProcessLink");
    
    // Update the 'calmsolution' and 'calmlink' attributes using the 'calmCustomSolutionProcessId' and 'cloudALMDiagramLink' values
    def updatedSignavioPublishedProcessModel = new JsonSlurper().parseText(message.getProperty('signavioPublishedProcessModel'));
    updatedSignavioPublishedProcessModel.properties[calmSolutionField] = calmCustomSolutionProcessId;
	updatedSignavioPublishedProcessModel.properties[calmLinkField] = cloudALMDiagramLink;

	// Create a comment referencing the 'calmCustomSolutionProcessId' and set it as the 'signavioComment' property in the message
    message.setProperty('signavioComment', "Created due to a new CALM ID (${calmCustomSolutionProcessId})");

    // Convert the updated model back into a JSON string and assign it to the 'signavioPublishedProcessModel' message property
    message.setProperty('signavioPublishedProcessModel', new Gson().toJson(updatedSignavioPublishedProcessModel));

    return message;
}