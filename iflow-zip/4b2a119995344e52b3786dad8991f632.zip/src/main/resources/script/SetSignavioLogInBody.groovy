import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential

def Message processData(Message message) {
    // Retrieve 'signavioCredential' and 'signavioTenantId' properties from the message
    def credentialName = message.getProperty("signavioCredential")
    def signavioTenantId = message.getProperty("signavioTenantId")
    
    // Get the secure store service
    SecureStoreService secureStoreService = ITApiFactory.getService(SecureStoreService.class, null)

    // Fetch the user credential from the secure store
    UserCredential userCredential = secureStoreService.getUserCredential(credentialName)

    // Retrieve the username from the fetched credential
    def username = userCredential.getUsername().toString()

    // Retrieve and URL encode the password from the fetched credential
    def password = new String(userCredential.getPassword())
    password = java.net.URLEncoder.encode(password, "UTF-8")
    
    // Format and set the request body for the Signavio token retrieval
    message.setBody("tokenonly=true&name=" + username + "&password=" + password + "&tenant=" + signavioTenantId)

    return message;
}