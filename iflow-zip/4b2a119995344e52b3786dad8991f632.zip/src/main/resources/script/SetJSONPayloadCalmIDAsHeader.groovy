import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {
    // Parse the message body into a JSON object
    def json = new JsonSlurper().parseText(message.getBody(String))
    
    // Get the field name from the 'fieldCALMCustomSolutionProcessId' properties
    String fieldNameCalmId = message.getProperty("fieldCALMCustomSolutionProcessId");
    
    // Check if the JSON object contains the specified field name
    if (json.properties.containsKey(fieldNameCalmId)) {
        // Extract the calmId property from the JSON object using the configured field name and set it as a header in the message
        message.setHeader('calmCustomSolutionProcessId', json.properties[fieldNameCalmId])
    } else {
        // Log the error message if the field is missing
        def messageLog = messageLogFactory.getMessageLog(message);
        if (messageLog != null) {
            messageLog.setStringProperty("Error", "Field '${fieldNameCalmId}' not found in JSON.");
        }
        // Throw an exception to trigger the exception subprocess
        throw new RuntimeException("Field '${fieldNameCalmId}' not found in JSON.");
    }

    // Retrieve the 'processDescription' property from the message
    String processDescription = message.getProperty("processDescription");

    // Split the 'processDescription' into a list of strings at every line-break
    List<String> descriptionArray = processDescription.split("\\r?\\n");

    // Join the list of strings into a single string where each element is separated by '\n'
    processDescription = descriptionArray.join("\\n");

    // Update the 'processDescription' property of the message with the reformatted description
    message.setProperty("processDescription", processDescription);
    
    return message;
}