import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def Message processData(Message message) {
    def xmlString = message.getBody(String)
    // Escaping double quotes
    xmlString = xmlString.replaceAll('\"', '\\\\\"')

    message.setProperty('processSVG', xmlString)
    return message
}