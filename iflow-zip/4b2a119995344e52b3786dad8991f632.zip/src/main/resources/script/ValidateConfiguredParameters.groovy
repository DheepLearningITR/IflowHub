import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Fetch message properties
    def properties = message.getProperties()

    // If 'signavioCredential' property is not set, throw an Exception
    if (!properties.get("signavioCredential")) {
        throw new Exception("'Credential Name' is not configured.")
    }

    // If 'signavioHostLink' property is not set, throw an Exception
    if (!properties.get("signavioHostLink")) {
        throw new Exception("'Signavio Host Link' is not configured.")
    }

    // If 'signavioTenantId' property is not set, throw an Exception
    if (!properties.get("signavioTenantId")) {
        throw new Exception("'Signavio Workspace ID' is not configured.")
    }

    return message;
}