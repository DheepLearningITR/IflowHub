import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Fetch properties and headers from the message.
    def properties = message.getProperties()
    def headers = message.getHeaders()

    // Get the message log of this message.
    def messageLog = messageLogFactory.getMessageLog(message)

    // Check whether to add logs or not. Also get exception if present.
    def addToLogFlag = ["yes", "x", "true"].contains(properties.getOrDefault("errorLogAttachments", "No").toLowerCase())
    def exception = properties.get('CamelExceptionCaught')

    // If exception is of type AhcOperationFailedException, get status code, status text, response body, and add them to message properties.
    // If required, also add them to message log.
    if (exception?.getClass()?.getCanonicalName()?.equals('org.apache.camel.component.ahc.AhcOperationFailedException')) {
        message.setProperty('http.StatusCode', exception.getStatusCode())
        message.setProperty('http.StatusText', exception.getStatusText())
        message.setProperty('http.ResponseBody', exception.getResponseBody())
        if (addToLogFlag && messageLog) {
            messageLog.addAttachmentAsString('Response Body', exception.getResponseBody(), 'text/plain')
        }
    }
    
    // Build email body based on properties and headers.
    def emailBody = buildEmailBody(properties, headers)
    // Set this built body to the message.
    message.setBody(emailBody)

    // If required, add headers, detailed error info, original and request payloads to message log.
    if (addToLogFlag && messageLog) {
        def headersText = ''
        headers.each { k, v -> headersText += "${k}: ${v}" + "\n" }
        messageLog.addAttachmentAsString('Headers', headersText, 'text/plain')

        def detailErrorInfo = emailBody
        detailErrorInfo += "Exception Stacktrace: " + properties.get("exceptionStacktrace") + "\n"
        messageLog.addAttachmentAsString('Detailed Error Infomation', detailErrorInfo, 'text/plain')

        if (properties.get("OriginalPayload")) {
            messageLog.addAttachmentAsString('Original Payload', properties.get("OriginalPayload"), 'text/plain')
        }

        if (properties.get("RequestPayload")) {
            messageLog.addAttachmentAsString('Request Payload', properties.get("RequestPayload"), 'text/plain')
        }
    }

    return message
}

// Utility function to build email body based on properties and headers.
def static String buildEmailBody(properties, headers) {
    def emailBody = '<table>'
    emailBody += "<tr><td><b>Integration Flow Name:</b></td><td>" + properties.get("IFlowName") + "</td></tr>"
    emailBody += "<tr><td><b>Message Processing Log ID:</b></td><td>" + properties.get("SAP_MessageProcessingLogID") + "</td></tr>"
    emailBody += "<tr><td><b>Message Processing Log Correlation ID:</b></td><td>" + headers.get("SAP_MplCorrelationId") + "</td></tr>"
    emailBody += "<tr><td><b>Timestamp:</b></td><td>" + properties.get("CamelCreatedTimestamp") + "</td></tr>"
    emailBody += "<tr><td><b>Process-ID:</b></td><td>" + properties.get("signavioProcessId") + "</td></tr>"
    emailBody += "<tr><td><b>Revision-ID:</b></td><td>" + properties.get("signavioRevisionId") + "</td></tr>"
    emailBody += "<tr><td><b>Exception Message:</b></td><td>" + properties.get("exceptionMessage") + "</td></tr>"
    
    if(properties.get("http.ResponseBody") != null) {
        emailBody += "<tr><td><b>Response body:</b></td><td>" + properties.get("http.ResponseBody") + "</td></tr>"
    }
    
    emailBody += '</table>'
    return emailBody
}