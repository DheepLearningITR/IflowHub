import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
	
    def body = message.getBody(String);
	def bodyJSON = new JsonSlurper().parseText(body);
	
	def date = bodyJSON.execution.monitoringStartAt;
	message.setProperty("url_date", date.substring(0,10));
	message.setHeader("Content-Type","application/x-ndjson");

	def salida = "[\r\n";
	def MetaData = "";
	def CommonEventData = 
				" \"execution.executedAt\":\"" + bodyJSON.execution.executedAt + "\","+ 
				" \"execution.monitoringEndAt\":\"" + bodyJSON.execution.monitoringEndAt + "\","+ 
				" \"execution.monitoringStartAt\":\"" + bodyJSON.execution.monitoringStartAt + "\","+ 
				" \"execution.type\":\"" + bodyJSON.execution.type + "\","+ 
				" \"execution.version\":\"" + bodyJSON.execution.version + "\","+ 
				
				" \"system.name\":\"" + bodyJSON.system.name + "\","+ 
				" \"tenant.code\":\"" + bodyJSON.tenant.code + "\"," ;
	
    def resultJSON ;
    def jsonFormateado;
    
	
	////////////////////////////////////////////////
    //////////////////// Summary ///////////////////
	////////////////////////////////////////////////

	MetaData = "{ \"index\":\"sappo_summary\"," + 
				" \"source\":\"sappo_summary\"," + 
				" \"sourcetype\":\"_json\"," + 
				" \"event\":\r\n" ;
				
	def EventDataTenant = "{" + CommonEventData +
				" \"messageOverview.success\": \"" + bodyJSON.messageOverview.success + "\"," +
				" \"messageOverview.cancelled\": \"" + bodyJSON.messageOverview.cancelled + "\"," +
				" \"messageOverview.delivering\": \"" + bodyJSON.messageOverview.delivering + "\"," +
				" \"messageOverview.error\": \"" + bodyJSON.messageOverview.error + "\"," +
				" \"messageOverview.holding\": \"" + bodyJSON.messageOverview.holding + "\"," +
				" \"messageOverview.toBeDelivered\": \"" + bodyJSON.messageOverview.toBeDelivered + "\"," +
				" \"messageOverview.waiting\": \"" + bodyJSON.messageOverview.waiting + "\"," +
				" \"messageOverview.numberDays\": \"" + bodyJSON.messageOverview.numberDays + "\"," +
				
				" \"jobOverview.cancelled\": \"" + bodyJSON.jobOverview.cancelled + "\"," +
				" \"jobOverview.completed\": \"" + bodyJSON.jobOverview.completed + "\"," +
				" \"jobOverview.error\": \"" + bodyJSON.jobOverview.error + "\"," +
				
				" \"channelOverview.error\": \"" + bodyJSON.channelOverview.error + "\"," +
				" \"channelOverview.inactive\": \"" + bodyJSON.channelOverview.inactive + "\"," +
				" \"channelOverview.successful\": \"" + bodyJSON.channelOverview.successful + "\"," +
				" \"channelOverview.stopped\": \"" + bodyJSON.channelOverview.stopped + "\"," +
				" \"channelOverview.unknown\": \"" + bodyJSON.channelOverview.unknown + "\"," +
				" \"channelOverview.unregistered\": \"" + bodyJSON.channelOverview.unregistered + "\"," +
				
				" \"BPMOverview.inprogress\": \"" + bodyJSON.BPMOverview.inprogress + "\"," +
				" \"BPMOverview.canceled\": \"" + bodyJSON.BPMOverview.canceled + "\"," +
				" \"BPMOverview.completed\": \"" + bodyJSON.BPMOverview.completed + "\"," +
				" \"BPMOverview.failed\": \"" + bodyJSON.BPMOverview.failed + "\"," +
				" \"BPMOverview.inerror\": \"" + bodyJSON.BPMOverview.inerror + "\"," +
				" \"BPMOverview.supended\": \"" + bodyJSON.BPMOverview.supended + "\"" +
				"}" ;
				
	def BlockDataTenant = MetaData + EventDataTenant + "}";
	
	resultJSON = new JsonSlurper().parseText(BlockDataTenant);
	jsonFormateado = JsonOutput.toJson(resultJSON);
    
	salida += " " + jsonFormateado ;
	
	
	////////////////////////////////////////////////////
	/////////////////////// BPMs ///////////////////////
	////////////////////////////////////////////////////
	
	MetaData = "{ \"index\":\"sappo_bpms\"," + 
				" \"source\":\"sappo_bpms\"," + 
				" \"sourcetype\":\"_json\"," + 
				" \"event\":\r\n " ;
	
	bodyJSON.bpmsDetail.each{ bd ->
	
    	salida += "," + "\r\n";
	
		def EventData = "{" + CommonEventData +
				"    \"BPMsDetail.id\": \"" + bd.id + "\"," +
				"    \"BPMsDetail.title\": \"" + bd.title + "\"," +
				"    \"BPMsDetail.updated\": \"" + bd.updated + "\"," +
				"    \"BPMsDetail.category\": \"" + bd.category + "\"," +
				"    \"BPMsDetail.link\": \"" + bd.link + "\"," +
				"    \"BPMsDetail.instanceId\": \"" + bd.instanceId + "\"," +
				"    \"BPMsDetail.name\": \"" + bd.name + "\"," +
				"    \"BPMsDetail.subject\": \"" + bd.subject + "\"," +
				"    \"BPMsDetail.startDate\": \"" + bd.startDate + "\"," +
				"    \"BPMsDetail.endDate\": \"" + bd.endDate + "\"," +
				"    \"BPMsDetail.modelId\": \"" + bd.modelId + "\"," +
				"    \"BPMsDetail.definitionId\": \"" + bd.definitionId + "\"," +
				"    \"BPMsDetail.status\": \"" + bd.errorCategory + "\"," +
				"    \"BPMsDetail.parentProcessInstanceId\": \"" + bd.parentProcessInstanceId + "\"," +
				"    \"BPMsDetail.rootProcessInstanceId\": \"" + bd.rootProcessInstanceId + "\"," +
				"    \"BPMsDetail.processInitiatorName\": \"" + bd.processInitiatorName + "\"" +
				"}";
				
		def BlockData = MetaData + EventData + "}";
		
		resultJSON = new JsonSlurper().parseText(BlockData);
		jsonFormateado = JsonOutput.toJson(resultJSON);
    
    	salida += " " + jsonFormateado ;
	}
	
	
	////////////////////////////////////////////////////
	/////////////////////// Jobs ///////////////////////
	////////////////////////////////////////////////////
	
	MetaData = "{ \"index\":\"sappo_jobs\"," + 
				" \"source\":\"sappo_jobs\"," + 
				" \"sourcetype\":\"_json\"," + 
				" \"event\":\r\n " ;
	
	bodyJSON.jobsDetail.each{ jd ->
	
    	salida += "," + "\r\n";
	
		def EventData = "{" + CommonEventData +
				"    \"jobsDetail.status\": \"" + jd.status + "\"," +
				"    \"jobsDetail.name\": \"" + jd.name + "\"," +
				"    \"jobsDetail.returnCode\": \"" + jd.returnCode + "\"," +
				"    \"jobsDetail.node\": \"" + jd.node + "\"," +
				"    \"jobsDetail.user\": \"" + jd.user + "\"," +
				"    \"jobsDetail.startAt\": \"" + jd.startAt + "\"," +
				"    \"jobsDetail.endAt\": \"" + jd.endAt + "\"" +
				"}";
				
		def BlockData = MetaData + EventData + "}";
		
		resultJSON = new JsonSlurper().parseText(BlockData);
		jsonFormateado = JsonOutput.toJson(resultJSON);
    
    	salida += " " + jsonFormateado ;
	}
	
	
	////////////////////////////////////////////////////////////
	/////////////////////// Certificates ///////////////////////
	////////////////////////////////////////////////////////////
	
	MetaData = "{ \"index\":\"sappo_certificates\"," + 
				" \"source\":\"sappo_certificates\"," + 
				" \"sourcetype\":\"_json\"," + 
				" \"event\":\r\n " ;
	
	bodyJSON.certificatesDetail.each{ cd ->
	
    	salida += "," + "\r\n";
	
		if ((cd.subjectDN != null) && (!cd.subjectDN.equals("")))
		{
			byte[] decoded_sdn = cd.subjectDN.decodeBase64()
			String decoded = new String(decoded_sdn)
			decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
			cd.subjectDN = decoded
		}
		if ((cd.issuerDN != null) && (!cd.issuerDN.equals("")))
		{
			byte[] decoded_idn = cd.issuerDN.decodeBase64()
			String decoded = new String(decoded_idn)
			decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
			cd.issuerDN = decoded
		}
		
		def EventData = "{" + CommonEventData +
				"    \"certificatesDetail.alias\": \"" + cd.alias + "\"," +
				"    \"certificatesDetail.issuerDN\": \"" + cd.issuerDN + "\"," +
				"    \"certificatesDetail.subjectDN\": \"" + cd.subjectDN + "\"," +
				"    \"certificatesDetail.validNotAfter\": \"" + cd.validNotAfter + "\"," +
				"    \"certificatesDetail.validNotBefore\": \"" + cd.validNotBefore + "\"" +
				"}";
				
		def BlockData = MetaData + EventData + "}";
		
		resultJSON = new JsonSlurper().parseText(BlockData);
		jsonFormateado = JsonOutput.toJson(resultJSON);
    
    	salida += " " + jsonFormateado ;
	}
	
	
	////////////////////////////////////////////////////////
	/////////////////////// Messages ///////////////////////
	////////////////////////////////////////////////////////
	
	MetaData = "{ \"index\":\"sappo_messages\"," + 
				" \"source\":\"sappo_messages\"," + 
				" \"sourcetype\":\"_json\"," + 
				" \"event\":\r\n " ;
	
	bodyJSON.messagesDetail.each{ md ->
	
    	salida += "," + "\r\n";
	
        if ((md.detail != null) && (!md.detail.equals("")))
        {
            byte[] decoded_errorDetail = md.detail.decodeBase64()
	        String decoded = new String(decoded_errorDetail)
	        decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
	        md.detail = decoded
        }
	
		def EventData = "{" + CommonEventData +
				"    \"messagesDetail.flowParty\": \"" + md.flowParty + "\"," +
				"    \"messagesDetail.receiverParty\": \"" + md.flowReceiverParty + "\"," +
				"    \"messagesDetail.flowComponent\": \"" + md.flowComponent + "\"," +
				"    \"messagesDetail.flowReceiverComponent\": \"" + md.flowReceiverComponent + "\"," +
				"    \"messagesDetail.flowInterfaceName\": \"" + md.flowInterfaceName + "\"," +
				"    \"messagesDetail.flowInterfaceNamespace\": \"" + md.flowInterfaceNamespace + "\"," +
				"    \"messagesDetail.status\": \"" + md.status + "\"," +
				"    \"messagesDetail.startTimeAt\": \"" + md.startTimeAt + "\"," +
				"    \"messagesDetail.scenario\": \"" + md.scenario + "\"," +
				"    \"messagesDetail.direction\": \"" + md.direction + "\"," +
				"    \"messagesDetail.errorCategory\": \"" + md.errorCategory + "\"," +
				"    \"messagesDetail.errorCode\": \"" + md.errorCode + "\"," +
				"    \"messagesDetail.errorLabel\": \"" + md.errorLabel + "\"," +
				"    \"messagesDetail.node\": \"" + md.node + "\"," +
				"    \"messagesDetail.refToMessageId\": \"" + md.refToMessageId + "\"," +
				"    \"messagesDetail.protocol\": \"" + md.protocol + "\"," +
				"    \"messagesDetail.qualityOfService\": \"" + md.qualityOfService + "\"," +
				"    \"messagesDetail.receiverInterface\": \"" + md.receiverInterface + "\"," +
				"    \"messagesDetail.receiverInterfaceNamespace\": \"" + md.receiverInterfaceNamespace + "\"," +
				"    \"messagesDetail.size\": \"" + md.size + "\"," +
				"    \"messagesDetail.retries\": \"" + md.retries + "\"," +
				"    \"messagesDetail.timesFailed\": \"" + md.timesFailed + "\"," +
				"    \"messagesDetail.detail\": \"" + md.detail + "\"" +
				"}";
				
		def BlockData = MetaData + EventData + "}";
		
		resultJSON = new JsonSlurper().parseText(BlockData);
		jsonFormateado = JsonOutput.toJson(resultJSON);
    
    	salida += " " + jsonFormateado ;
	}
	
	
	////////////////////////////////////////////////////////
	/////////////////////// Channels ///////////////////////
	////////////////////////////////////////////////////////
	
	MetaData = "{ \"index\":\"sappo_channels\"," + 
				" \"source\":\"sappo_channels\"," + 
				" \"sourcetype\":\"_json\"," + 
				" \"event\":\r\n " ;
	
	bodyJSON.channelsDetail.each{ cd ->
	
    	salida += "," + "\r\n";
	
		if ((cd.detail != null) && (!cd.detail.equals("")))
		{
			byte[] decoded_sdn = cd.detail.decodeBase64()
			String decoded = new String(decoded_sdn)
			decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
			cd.detail = decoded
		}
		
		def EventData = "{" + CommonEventData +
				"    \"channelsDetail.status\": \"" + cd.status + "\"," +
				"    \"channelsDetail.channelSapId\": \"" + cd.channelSapId + "\"," +
				"    \"channelsDetail.channelName\": \"" + cd.channelName + "\"," +
				"    \"channelsDetail.channelComponent\": \"" + cd.channelComponent + "\"," +
				"    \"channelsDetail.channelParty\": \"" + cd.channelParty + "\"," +
				"    \"channelsDetail.detail\": \"" + cd.detail + "\"" +
				"}";
				
		def BlockData = MetaData + EventData + "}";
		
		resultJSON = new JsonSlurper().parseText(BlockData);
		jsonFormateado = JsonOutput.toJson(resultJSON);
    
    	salida += " " + jsonFormateado ;
	}

	
	salida += "\r\n" + "]" ;
    message.setBody(salida);
    return message;
}




