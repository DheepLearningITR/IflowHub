import com.sap.it.api.mapping.*;

def String getNumberParent(String externalId){
    String[] str = externalId.split("/|_");
	return str[2]; 
}
