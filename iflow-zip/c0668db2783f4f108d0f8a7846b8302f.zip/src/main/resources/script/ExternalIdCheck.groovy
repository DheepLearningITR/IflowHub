import com.sap.it.api.mapping.*;

def String externalIdCheck(String externalId){
	String res = externalId.contains("_");
	return res;
}
