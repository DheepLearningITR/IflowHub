import com.sap.it.api.mapping.*;

def String customFunc(String arg1){
	 
	
def message = """<root>
  <contact/>
</root>"""

def openingTag = "<plannedDurationInMinutes>"
def closingTag = "</plannedDurationInMinutes>"

message = message.replaceAll("<contact/>", "${openingTag}${closingTag}")

return arg1
}