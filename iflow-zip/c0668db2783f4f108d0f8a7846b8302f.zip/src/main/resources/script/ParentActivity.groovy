import com.sap.it.api.mapping.*;

def String ParentActivity(String externalId){
    String[] str;
    str = externalId.split('/');
    
	return str[1]; 
}
