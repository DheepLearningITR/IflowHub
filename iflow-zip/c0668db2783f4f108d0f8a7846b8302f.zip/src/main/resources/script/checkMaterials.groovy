import com.sap.it.api.mapping.*;

def String checkMaterials(String input) {
    def query = new XmlSlurper().parseText(input);
    def res;
    
    if(query.text() == '') {
        res = 'false';
    } else {
        res = 'true';
    }
    
    return res;
}
