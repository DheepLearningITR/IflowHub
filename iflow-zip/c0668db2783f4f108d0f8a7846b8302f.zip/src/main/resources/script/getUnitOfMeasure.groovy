import com.sap.it.api.mapping.*;
import java.util.HashMap;

def String getUnitofMeasure(String fsm_unit, MappingContext context) {
    Map<String,String> unitOfMeasure = context.getProperty("UnitOfMeasure");
    String defaultUnit = new String(context.getProperty("Default_UOM_Material"));
    Object unit = unitOfMeasure.get(fsm_unit);
    
	return unit == null ? defaultUnit : unit.toString();
}
