import com.sap.it.api.mapping.*;

def String getLineNumber(String externalId) {
    String[] str = externalId.split("/|_");
    
    return str[1]; 
}
