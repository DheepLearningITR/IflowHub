/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
       
       message.setBody(body + "Body is modified");
       //Headers 
       def map = message.getHeaders();
       def value = map.get("oldHeader");
       message.setHeader("oldHeader", value + "modified");
       message.setHeader("newHeader", "newHeader");
       //Properties 
       map = message.getProperties();
       value = map.get("oldProperty");
       message.setProperty("oldProperty", value + "modified");
       message.setProperty("newProperty", "newProperty");
       
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import groovy.xml.*;

def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String);
    def root = new XmlSlurper().parseText(body)
       
    List<String> lines = new ArrayList<>();
    List<String> formatters = new ArrayList<>()
    
    def remarks = root.data.remarks.text()
    
    processNotes(remarks, lines, formatters)
    def headerNotesXML = createHeaderNotesXML(lines,formatters)
    
    message.setProperty("headerNotesXML",headerNotesXML)
    
    root.data.activities.each{ activity ->
     
        if(activity.remarks != null && !activity.remarks.text().isEmpty()){
            
            lines = new ArrayList<>();
            formatters = new ArrayList<>()
            processNotes(activity.remarks.text(), lines,formatters)
            def itemNotesXML = createItemNotesXML(lines,formatters)
            
            def itemNotesKey
            if(activity.externalId.text() != null && !activity.externalId.text().isEmpty()){
                itemNotesKey ="itemNotesXML_" + activity.udfValues.find{it.udfMeta.externalId.text().equals("ItemGUID")}?.value.text()
            } else {
                itemNotesKey = "itemNotesXML_" + activity.id.text()
            }
            message.setProperty(itemNotesKey, itemNotesXML)
        }
     
     
    }
   
    
       
       
    return message;
}

public void processNotes(String notes, List<String> lines, List<String> formatters){
    
    if(notes == null || notes.isEmpty()){
        return;
    }
    
    int start = 0;
    int lengthCounter = 0;
    String format = '*';
    
    formatters.add(format)
    int i;
    for( i=0; i < notes.length() ; i++) {
        
        if(notes.charAt(i) == '\n'){
            
            lines.add(notes.substring(start, i))
            lengthCounter = 0;
            format = '*'
            formatters.add(format)
            start = i + 1
            
        } else if (lengthCounter == 131){
            
            String line = notes.substring(start, i)
            lines.add(line)
            lengthCounter = 0
            format = '='
            
            if(line.charAt(0) == ' ' && formatters.get(formatters.size() - 1).equals("=") ){
                formatters.set(formatters.size() - 1, '')
            }
            
            if(line.charAt(line.length() -1 ) == ' '){
                format = ''
            }
            
            formatters.add(format)
            start = i
            
        } else {
            lengthCounter++
        }
        
    }
    
    if(start != i){
        String line = notes.substring(start, i)
        lines.add(line)
        int index = lines.size()-1
        if(line.charAt(0) == ' ' && formatters.get(index).equals("=")){
            formatters.set(index, '')
        }
    }
    
}

public String createHeaderNotesXML(List<String> lines, List<String> formatters){
    
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.Notes(){
        for(int i = 0; i<lines.size();i++){
            
            E101CRMXIF_TLINE(SEGMENT: "1") { 
                APPL_SNAME("CRMXIF_TLINE")
                FORMAT_COL(formatters.get(i))
                TEXT_LINE(lines.get(i))
                E101CRMXIF_TLINE_F(SEGMENT:"1"){
                     APPL_SNAME("CRMXIF_TLINE_F")
                }
            }
        }
    }
    
    return writer.toString()
}

public String createItemNotesXML(List<String> lines, List<String> formatters){
    
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.Notes(){
        for(int i = 0; i<lines.size();i++){
            
            E102CRMXIF_TLINE(SEGMENT: "1") { 
                APPL_SNAME("CRMXIF_TLINE")
                FORMAT_COL(formatters.get(i))
                TEXT_LINE(lines.get(i))
                E102CRMXIF_TLINE_F(SEGMENT:"1"){
                     APPL_SNAME("CRMXIF_TLINE_F")
                }
            }
        }
    }
    
    return writer.toString()
}