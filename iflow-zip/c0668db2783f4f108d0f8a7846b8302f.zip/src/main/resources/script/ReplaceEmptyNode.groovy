import com.sap.it.api.mapping.*;

def String ReplaceEmptyNode(String plannedDurationInMinutes){
     def query = new XmlSlurper().parseText(plannedDurationInMinutes);
     def output = ""
     
     if(query.text() == "")
     {
         output = " ";
     }
           
	return output;
}