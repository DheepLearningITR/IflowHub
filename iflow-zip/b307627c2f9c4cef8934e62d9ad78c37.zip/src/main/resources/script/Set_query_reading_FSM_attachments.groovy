
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
       //Get Body and parse it.
       def parsedObj = new XmlSlurper().parseText(message.getBody(String.class));
       
       ArrayList C4C_Attachment_IDs = [];
       parsedObj.AttachmentFolderReplicateRequestMessage.AttachmentFolder.Document.each{
           C4C_Attachment_IDs.add(it.InternalLinkPathName.toString().trim());
       }
       message.setProperty("C4C_Attachment_IDs",C4C_Attachment_IDs);
       
       String s = '\'';
        String e = '\',';
        String eend = "\')";
        String u = ' UNION ';
       String finalQuery = "";
       String equipment_query = "{\"query\": \"SELECT attach.externalId FROM Attachment attach JOIN Equipment eq ON attach.object.objectId = eq.id WHERE attach.externalId IS NOT NULL AND eq.externalId IN (" ;

        String sc_q1 = "{\"query\": \"SELECT attach.externalId FROM Attachment attach JOIN ServiceCall sc ON attach.object.objectId = sc.id WHERE attach.externalId IS NOT NULL AND sc.externalId IN (" ;

        String sc_q2 = "SELECT attach.externalId FROM Attachment attach, Activity act, ServiceCall sc WHERE sc.id = act.object.objectId AND act.id = attach.object.objectId AND act.status != 'CLOSED' AND attach.externalId IS NOT NULL AND act.externalId IS NOT NULL AND sc.externalId IN (" ;
       
       String objTypeCode = parsedObj.AttachmentFolderReplicateRequestMessage[0].AttachmentFolder.HostObjectReference.ObjectTypeCode.toString().trim();
       String objectID = null

       message.setProperty("objTypeCode",objTypeCode);  
       
       if (objTypeCode == '118') //Ticket
       {
           parsedObj.AttachmentFolderReplicateRequestMessage.AttachmentFolder.HostObjectReference.ObjectID.each {
        		if (objectID == null)
        		{
        			objectID = s + it.text().trim() + eend;
        		}
        		else
        		{
        			objectID = s + it.text().trim() + e + objectID;
        		}
        	}
        	finalQuery = sc_q1 + objectID  + u + sc_q2 + objectID + '\"}';
            message.setProperty("query_dtos","Attachment.17;Activity.19;ServiceCall.25");
            message.setProperty("c4c_conf_path","/sap/bc/srt/scs/sap/servicerequestattachmentbulkre");
       }
       else if (objTypeCode == '185') // Registered Product
       {
           parsedObj.AttachmentFolderReplicateRequestMessage.AttachmentFolder.HostObjectReference.ObjectID.each {
        		if (objectID == null)
        		{
        			objectID = s + it.text().trim() + eend;
        		}
        		else
        		{
        			objectID = s + it.text().trim() + e + objectID;
        		}
        	}
        	
        	finalQuery = equipment_query + objectID + '\"}';
           message.setProperty("query_dtos","Attachment.17;Equipment.20");
           message.setProperty("c4c_conf_path","/sap/bc/srt/scs/sap/registeredproductattachmentrep");
       }

       //Modify and Save the incoming Payload into property
        parsedObj = new XmlParser().parseText(message.getBody(String.class));
        parsedObj.AttachmentFolderReplicateRequestMessage.each{
        	if(it.AttachmentFolder.Document.size() == 0) {		
        		it.parent().remove(it)
        	}
        }
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(parsedObj)
        message.setProperty("InPayload",stringWriter.toString());
       
       // Set the query in the message body   
       message.setBody(finalQuery);
       return message;
}