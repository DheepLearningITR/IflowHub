/*
Club AttachmentFolderReplicationConfirmation nodes Group by Service Call ID. 
 */
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
       def body = message.getBody(String.class);
       def root = new XmlParser().parseText(body);
       
    if(root.AttachmentFolderReplicationConfirmation.size() > 1) {
        //Create new XML file  with root_output node
    	Node root_output = new NodeBuilder()."n0:AttachmentFolderReplicationConfirmation"('xmlns:n0': 'http://sap.com/xi/SAPGlobal20/Global'){}
    	root_output.append(root.MessageHeader)   //Copy message header
    	//groupBy retruns a Map with key being ReceiverObjectIdentifier here, and value being list of grouped by node which is AttachmentFolderReplicationConfirmation here
    	root.AttachmentFolderReplicationConfirmation.groupBy{
    		it.AttachmentFolderReplicationConfirmation.ReceiverObjectIdentifier.text()
    	}.eachWithIndex{ key,value,i ->
    		root_output.append(value[0])   //First AttachmentFolderReplicationConfirmation anyway has to be there for each Ticket
    		//For subsequent values just the Document node has to be added
    		for(idx=1;idx < value.size(); idx++) {
    			root_output.AttachmentFolderReplicationConfirmation[i].AttachmentFolderReplicationConfirmation[0].append(value[idx].AttachmentFolderReplicationConfirmation.Document)
    		}
    	}
    	
    	StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(root_output)
        message.setBody(stringWriter.toString())
    }
    return message;
}