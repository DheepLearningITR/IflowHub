import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {

    def C4C_Attachment_IDs = message.getProperty('C4C_Attachment_IDs');
    ArrayList FSM_Attachment_IDs = []
    def parsedObj = new JsonSlurper().parseText(message.getBody(String.class));
    
    //Form ArrayList of FSM Attachment IDs retrived from FSM Query API
    parsedObj.data.each{
        FSM_Attachment_IDs.add(it.attach.externalId);
    }
    //Find attachment IDs which are in FSM but not present in C4C payload, so that they can be deleted.
    C4C_Attachment_IDs.intersect(FSM_Attachment_IDs).each{FSM_Attachment_IDs.remove(it)}

    String Delete_JSON_str = "";
    //Form JSON string to send to FSM for deletion
    FSM_Attachment_IDs.each{
        if (Delete_JSON_str == ""){
            Delete_JSON_str = '{\"externalId\" : ' + '\"'+it+'\"}]';
        }
        else
        {
            Delete_JSON_str = '{\"externalId\" : ' + '\"'+it+'\"}, ' + Delete_JSON_str; 
        }
    }
    
    if (Delete_JSON_str == "")
    {
        message.setProperty('C4C_Attachment_IDs','DELETE_NOTHING');
    }
    else
    {
        Delete_JSON_str = '[' + Delete_JSON_str;
    //Convert string to JSON
      //  def Delete_JSON = JsonOutput.toJson(Delete_JSON_str);
      // def msg_body = JsonOutput.prettyPrint(Delete_JSON);
        message.setBody(Delete_JSON_str);
    }

    return message;
}