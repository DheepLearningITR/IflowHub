import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def shopifyProductList = message.getProperty("shopify_product_list") as String
    def s4hanaProductId = message.getProperty("s4hana_product_id") as String
    def existingProduct = 'false'

    def slurper = new JsonSlurper()
    def parsedJson = slurper.parseText(shopifyProductList)

    for (product in parsedJson.products) {
        // Check if 'variants' is a map and contains the 'edges' list
        if (product?.variants?.edges) {
            for (variantEdge in product.variants.edges) {
                def variantNode = variantEdge.node
                // Check if the 'sku' matches the given product ID
                if (variantNode?.sku == s4hanaProductId) {
                    message.setProperty("shopify_product_id", product.id)
                    message.setProperty("shopify_variant_id", variantNode.id)
                    existingProduct = 'true'
                }
            }
        }
    }

    message.setProperty("existing_product", existingProduct)
    return message
}