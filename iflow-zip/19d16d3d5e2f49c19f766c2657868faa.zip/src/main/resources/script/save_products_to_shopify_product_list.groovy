import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def shopifyProductListString = message.getProperty("shopify_product_list") as String
    def responseBodyString = message.getBody(String) as String

    def jsonSlurper = new JsonSlurper()

    def savedProductListJson = shopifyProductListString ? jsonSlurper.parseText(shopifyProductListString) : [products: []]
    def responseBodyJson = responseBodyString ? jsonSlurper.parseText(responseBodyString) : [:]
    def newProducts = responseBodyJson.data?.products?.edges?.collect { it.node } ?: []

    if (!(savedProductListJson.products instanceof List)) {
        savedProductListJson.products = []
    }

    if (!newProducts.isEmpty()) {
        savedProductListJson.products.addAll(newProducts)
    }

    def builder = new JsonBuilder(savedProductListJson)
    def newSavedList = builder.toPrettyString()

    message.setProperty("shopify_product_list", newSavedList)

    return message
}