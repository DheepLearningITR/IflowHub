import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    // Retrieve the property and body as strings
    def shopifyProductListString = message.getProperty("shopify_product_list") as String
    def responseBodyString = message.getBody(String) as String

    // Initialize JSON parser
    def jsonSlurper = new JsonSlurper()

    // Parse the existing saved product list
    def savedProductListJson = shopifyProductListString ? jsonSlurper.parseText(shopifyProductListString) : [products: []]

    // Parse the response body
    def responseBodyJson = responseBodyString ? jsonSlurper.parseText(responseBodyString) : [:]

    // Extract products from GraphQL response
    def newProducts = responseBodyJson.data?.products?.edges?.collect { it.node } ?: []

    // Check that products is a list in the saved product list
    if (!(savedProductListJson.products instanceof List)) {
        // Initialize products as a list if not present or valid
        savedProductListJson.products = []
    }

    // Check if the new products list is not empty
    if (!newProducts.isEmpty()) {
        // Merge the products lists
        savedProductListJson.products.addAll(newProducts)
    }

    // Create a new JSON representation
    def builder = new JsonBuilder(savedProductListJson)
    def newSavedList = builder.toPrettyString()

    // Set the updated JSON back as a property
    message.setProperty("shopify_product_list", newSavedList)

    return message
}