import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper

def Message processData(Message message) {
  def responseBody = message.getBody(java.lang.String) as String;
  if (isEmptyProductResponse(responseBody)) {
    message.setProperty("last_product_reached", 'true');
  } else {
    def jsonSlurper = new JsonSlurper();

    def responseProductList = jsonSlurper.parseText(responseBody);

    def lastProductId = responseProductList.products[-1].id as String;

    message.setProperty("last_product_id", lastProductId);
  }

  return message;
}

private boolean isEmptyProductResponse(responseBody) {
  boolean lastProductReached = false;
  def slurper = new JsonSlurper();
  def jsonObject = slurper.parseText(responseBody);

  if (jsonObject.products) { // Check if 'products' key exists
    if (jsonObject.products instanceof List) { // Check if 'products' is an array
      if (jsonObject.products.empty) { // Check if 'products' array is empty
        lastProductReached = true;
      }
    }
  } else {
    lastProductReached = true;
  }
  return lastProductReached;
}