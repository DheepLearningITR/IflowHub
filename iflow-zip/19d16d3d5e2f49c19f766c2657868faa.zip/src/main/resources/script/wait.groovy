import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    try {
        Thread.sleep(1000) // wait for 1 seconds
    } catch (InterruptedException e) {
        // Handle exception
        throw new RuntimeException('Thread sleep was interrupted', e)
    }
    return message
}