import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder
import java.io.StringWriter

def Message prepareQueryForPricingProcedure(Message message) {
        // Get headers
        def headers = message.getHeaders();

        // Get the specific header value
        def pricingProcedureValue = headers.get("PricingProcedureName"); // Use the EXACT header name

        // Base query options (always include $expand)
        def queryOptions = '$expand=to_Text';

        // Check if the header value is present and not just whitespace
        if (pricingProcedureValue?.trim()){
            // If value exists, append the $filter part
            // Ensure correct quoting for string values in OData!
            queryOptions += '&$filter=PricingProcedure eq \'' + pricingProcedureValue + '\'';
        }
        // If pricingProcedureValue is null, empty, or whitespace, the $filter part is simply not added

        // Store the dynamically built query string in a property
        message.setProperty("dynamicOdataQuery", queryOptions);

        return message;
    }

def Message processPricingProcedureStepsTextInput(Message message) {
    // 1. Get Input Body and Logger
    def body = message.getBody(java.io.Reader);

    // Initialize XML builder
    def writer = new StringWriter();
    def xmlBuilder = new MarkupBuilder(writer);

    // 2. Parse JSON safely
    def parsedJson = null;
    if (body != null) {
        try {
            def jsonSlurper = new JsonSlurper();
            parsedJson = jsonSlurper.parse(body);
        } catch (Exception e) {
            xmlBuilder.root() {} // Create empty <root/>
            message.setBody(writer.toString());
            return message;
        }
    } else {
        // Build an empty root if input is empty
        xmlBuilder.root() {} // Create empty <root/>
        message.setBody(writer.toString());
        return message;
    }

    // 3. Process the parsed JSON and Build XML *within* the root closure
    xmlBuilder.root { // <--- Define root and put loops inside its closure
        // Check if parsing was successful and resulted in a Map
        if (parsedJson instanceof Map) {
            // Iterate through the top-level map
            parsedJson.each { pricingProcedureKey, stepsArray ->
                def currentPricingProcedure = pricingProcedureKey.toString();

                // Check if the value is a List
                if (stepsArray instanceof List) {
                    // Iterate through each item map in the steps array
                    stepsArray.each { stepCounterMap ->
                        // Check if the item is indeed a Map
                        if (stepCounterMap instanceof Map) {
                             // Iterate through the inner map
                             stepCounterMap.each { step, counter ->
                                 // Build the <item> element directly here
                                 // We are now inside the 'root' context
                                 item {
                                     def currentStep = step.toString();
                                     def currentCounter = counter.toString();

                                     // Create the child elements
                                     mkp.yieldUnescaped("<PricingProcedure>${currentPricingProcedure}</PricingProcedure>")
                                     mkp.yieldUnescaped("<PricingProcedureStep>${currentStep}</PricingProcedureStep>")
                                     mkp.yieldUnescaped("<PricingProcedureCounter>${currentCounter}</PricingProcedureCounter>")
                                 } // End item
                             } // End stepCounterMap.each
                        }
                    } // End stepsArray.each
                }
            } // End parsedJson.each
        }
    } // End xmlBuilder.root closure

    // 4. Set the final XML as the message body
    def outputXml = writer.toString();
    message.setBody(outputXml);

    return message;
}

def Message processConditionTableInput(Message message) {
    def body = message.getBody(java.io.Reader);

    // Parse the JSON array from the input body
    def jsonSlurper = new JsonSlurper();
    def conditionTables = jsonSlurper.parse(body);

    // Build the XML string dynamically
    def xmlBuilder = new StringBuilder();
    xmlBuilder.append("<?xml version='1.0' encoding='UTF-8'?><AccessSequence>");

    for (def conditionTable : conditionTables) {
        xmlBuilder.append("<item><conditionTable>");
        xmlBuilder.append(conditionTable);
        xmlBuilder.append("</conditionTable></item>");
    }

    xmlBuilder.append("</AccessSequence>");

    // Set the XML string as the new message body
    message.setBody(xmlBuilder.toString());

    return message;
}

def Message processeExclusionGroupInput(Message message) {
    def body = message.getBody(java.io.Reader);


    // Parse the JSON array from the input body
    def jsonSlurper = new JsonSlurper();
    def exclusionGroups = jsonSlurper.parse(body);

    // Build the XML string dynamically
    def xmlBuilder = new StringBuilder();
    xmlBuilder.append("<?xml version='1.0' encoding='UTF-8'?><root>");

    for (def SlsPrcgCndnExclusionGroup : exclusionGroups) {
        xmlBuilder.append("<item><SlsPrcgCndnExclusionGroup>");
        xmlBuilder.append(SlsPrcgCndnExclusionGroup);
        xmlBuilder.append("</SlsPrcgCndnExclusionGroup></item>");
    }

    xmlBuilder.append("</root>");

    // Set the XML string as the new message body
    message.setBody(xmlBuilder.toString());


    return message;
}

def Message processAccessSequenceInput(Message message) {
    def body = message.getBody(java.io.Reader);


    // Parse the JSON array from the input body
    def jsonSlurper = new JsonSlurper();
    def conditionTypes = jsonSlurper.parse(body);

    // Build the XML string dynamically
    def xmlBuilder = new StringBuilder();
    xmlBuilder.append("<?xml version='1.0' encoding='UTF-8'?><ConditionTypes_MT>");

    for (def conditionType : conditionTypes) {
        xmlBuilder.append("<item><conditionType>");
        xmlBuilder.append(conditionType);
        xmlBuilder.append("</conditionType></item>");
    }

    xmlBuilder.append("</ConditionTypes_MT>");

    // Set the XML string as the new message body
    message.setBody(xmlBuilder.toString());

    return message;
}


def Message processAccessSequenceFieldInput(Message message) {
    def body = message.getBody(java.io.Reader);

    // Parse the JSON array from the input body
    def jsonSlurper = new JsonSlurper();
    def accessSequenceData = jsonSlurper.parse(body);

    // Build the XML string dynamically using MarkupBuilder
    def writer = new StringWriter();
    def xmlBuilder = new MarkupBuilder(writer);

    xmlBuilder.root {
        accessSequenceData.each { entry ->
            entry.each { accessSequence, accessSequenceNos ->
                // Ensure accessSequence is treated as a String, not a method call
                def currentAccessSequence = accessSequence.toString();
                accessSequenceNos.each { accessSequenceNo ->
                    item {
                        // Use the variable currentAccessSequence here
                        mkp.yieldUnescaped("<accessSequence>${currentAccessSequence}</accessSequence>");
                        mkp.yieldUnescaped("<accessSequenceNo>${accessSequenceNo}</accessSequenceNo>");
                    }
                }
            }
        }
    }

    // Set the XML string as the new message body
    message.setBody(writer.toString());


    return message;
}