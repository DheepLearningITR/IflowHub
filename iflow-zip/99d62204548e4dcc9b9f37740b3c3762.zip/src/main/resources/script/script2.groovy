import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
def body = message.getBody(java.lang.String) as String;

String output = body.replaceAll("\"(\\d+)\"", "\$1");
message.setBody(output);

return message;
}