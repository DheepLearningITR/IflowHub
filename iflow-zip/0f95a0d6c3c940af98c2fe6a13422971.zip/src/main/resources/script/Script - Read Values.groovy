import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*

def Message processData(Message message) {
	
	def json = new JsonSlurper().parseText(message.getBody(String));
    //message.setProperty('wf_paymentstatus',json.A_OperationalAcctgDocItemCube.A_OperationalAcctgDocItemCubeType.IsCleared);
    
    //def msgUUID = UUID.randomUUID().toString();
    def msgID   = UUID.randomUUID().toString();
    Date latestdate = new Date();
    
    message.setProperty('soap_uuid','0000123456789ABCDEF' + latestdate.getTime());
    message.setProperty('soap_id', msgID);
    message.setProperty('soap_datetime', latestdate.format("yyyy-MM-dd'T'HH:mm:ss") + 'Z');
    //message.setProperty('soap_uuid', msgUUID);
    
    message.setProperty('data_accdoc',json.data.AccountingDocument);
    message.setProperty('data_companycode',json.data.CompanyCode);
    message.setProperty('data_fiscalyear',json.data.FiscalYear);
    message.setProperty('data_accdocitem',json.data.AccountingDocumentItemID);
    
    message.setProperty('data_dunblock',json.data.DunningBlockingReasonCode);
    
    return message;
}