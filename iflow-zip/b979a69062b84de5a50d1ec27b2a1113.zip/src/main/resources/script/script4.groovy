/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String ) as String;
       map = message.getProperties();
       RutEnvia = map.get("RutEnvia");
       DvEnvia = map.get("DvEnvia");
       token = map.get("token");
       signed_rft = map.get("signed_rtf");
       Email = map.get("Email");

       message.setProperty("CamelCharsetName", "ISO-8859-1");
       message.setProperty("signedrtf", body);
       message.setHeader("Host", "https://maullin.sii.cl");
       message.setHeader("Referer", "http://empresaabc.cl/test.html");
       message.setHeader("CamelHttpCharacterEncoding", "ISO-8859-1");
       message.setHeader("CamelHttpMethod", "POST");
       message.setHeader("Cookie", "TOKEN=" + token);
       message.setHeader("Content-Type", "multipart/form-data; boundary=----7d23e2a11301c4");
       message.setHeader("Accept", "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg,application/vnd.ms-powerpoint, application/ms-excel,application/msword, */*");
       message.setHeader("Accept-Encoding", "gzip, deflate");
       message.setHeader("User-Agent", "Mozilla/4.0 (compatible; PROG 1.0; Windows NT 5.0; YComp 5.0.2.4)");
       message.setHeader("Accept-Language", "es-cl");
       message.setHeader("Cache-Control", "no-cache");
       message.setHeader("CamelCharsetName", "ISO-8859-1");
       body = '------7d23e2a11301c4\r\nContent-Disposition: form-data; name="emailNotif"\r\n\r\n' + Email + '\r\n------7d23e2a11301c4\r\nContent-Disposition: form-data; name="rutCompany"\r\n\r\n' + RutEnvia + '\r\n------7d23e2a11301c4\r\nContent-Disposition: form-data; name="dvCompany"\r\n\r\n' + DvEnvia + '\r\n------7d23e2a11301c4\r\nContent-Disposition: form-data; name="archivo";  filename=AEC.xml\r\nContent-Type: text/xml\r\n\r\n' + body + '\r\n\r\n------7d23e2a11301c4--\r\n';
       message.setBody(body);
       return message;
}