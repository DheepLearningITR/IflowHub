import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();

    def properties = message.getProperties();
    def count = properties.get("count");
    def resultRecords = properties.get("resultRecords");
    message.setProperty("eventId", resultRecords[count].InternalId);
    
    //get db schema
    def db_schema = properties.get('Database_Schema_Name');
    
    // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    
    sqlStatement.root {
        sqlStatement.SelectStatement {
            sqlStatement.app_sourcing_events(action: 'SELECT') {
                sqlStatement.table(db_schema + '.APP_SOURCING_EVENTS')
                sqlStatement.access {
                    sqlStatement.INTERNAL_ID()
                    sqlStatement.EVENT_STATE()
                    sqlStatement.STEP_FLOW()
                }
                sqlStatement.key {
                    sqlStatement.INTERNAL_ID(resultRecords[count].InternalId)
                }
            }
        }
    };
    
    message.setBody(writer.toString());
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('resultRows', resultRows.toString(), 'text/plain');

    
    return message;
}