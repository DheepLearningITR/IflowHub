import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def properties = message.getProperties();
    
    def resultRecords = properties.get("resultRecords");
    def valueCount = properties.get("count");
    def rfxEventApi = resultRecords[valueCount];
    
    //count insertion
    def valueUpdatedCount = properties.get("updatedCount");
    valueUpdatedCount = valueUpdatedCount + 1;
    message.setProperty("updatedCount", valueUpdatedCount);

     // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    
    def db_schema = properties.get('Database_Schema_Name');
    
    def eventDB = properties.get("eventInDB");
    def newStepFlow = properties.get("newStepFlow");
    
    sqlStatement.root {
        sqlStatement.UpdateStatement {
            sqlStatement.app_sourcing_events(action: 'UPDATE') {
                sqlStatement.table(db_schema + '.APP_SOURCING_EVENTS')
                sqlStatement.access {
                    sqlStatement.EVENT_STATE(rfxEventApi.EventState)
                    sqlStatement.STEP_FLOW(newStepFlow)
                    sqlStatement.MODIFIEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                    sqlStatement.MODIFIEDBY(properties.get('Extension_User'))
                    sqlStatement.COMMENTS('The event was updated from: ' + eventDB.STEP_FLOW + ' to: ' + newStepFlow + '.')
                }
                sqlStatement.key {
                    sqlStatement.INTERNAL_ID(eventDB.INTERNAL_ID)
                    sqlStatement.EVENT_STATE(eventDB.EVENT_STATE)
                    sqlStatement.STEP_FLOW(eventDB.STEP_FLOW)
                }
            }
        }
    };
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('RFX SQL Insert', writer.toString(), 'text/plain');
    
    message.setBody(writer.toString());
  
    return message;
}