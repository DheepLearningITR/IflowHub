/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Body
    def body = message.getBody();
    
    //Headers
    def headers = message.getHeaders();

    //Properties
    def properties = message.getProperties();
    
    def count = properties.get("count");
    def resultRecordsFromApi = properties.get("resultRecords");
    def eventFromApi = resultRecordsFromApi[count];
    
    //get list of event states in pending
    def pendingStates = properties.get("Event_Pending_States").split(',');
    
    // get results
    def jsonSlurper = new JsonSlurper();
    def dbResult = jsonSlurper.parse(body);
    
     //eventState: 
    //  - PendingSelectionState -> 6
    //  - ClosedState -> 7
    //  - CancelledState -> 8
    //  - NewState -> 0
    
     //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('Result SQL SELECT', dbResult.toString(), 'text/plain');
    
    def hasChanges = '0';
    
    if (dbResult && dbResult.SelectStatement_response && 
        dbResult.SelectStatement_response.row && dbResult.SelectStatement_response.row.size() > 0) {
        def eventDB = dbResult.SelectStatement_response.row[0];
        
        //1. check for pending states
        for (String v in pendingStates) {
                
            //check eventos in pending status
            if (eventDB.EVENT_STATE == v && eventDB.STEP_FLOW == 'DRAFT') {
                message.setProperty("eventInDB", eventDB);
                
                // check if an Event in PendingSelecction is in Draft to update
                if (eventFromApi.EventState == 6) {
                    message.setProperty("newStepFlow", 'NEW');
                     hasChanges = '1';
                }
                else if (eventFromApi.EventState == 7) {
                    message.setProperty("newStepFlow", 'CLOSED');
                     hasChanges = '1';
                }
                else if (eventFromApi.EventState == 8) {
                    message.setProperty("newStepFlow", 'CANCELLED');
                     hasChanges = '1';
                }
                
                /*def messageDetail = 'Event in API: ' + eventFromApi.InternalId + '. EventState: ' + eventFromApi.EventState;
                messageDetail = messageDetail + 'Event in DB: ' + eventDB.INTERNAL_ID + '. EventState: ' + eventDB.EVENT_STATE + '. StepFlow: ' + eventDB.STEP_FLOW;
                messageLog.addAttachmentAsString(eventDB.INTERNAL_ID, messageDetail, 'text/plain');*/
                
                break;
            }
        }
        
        //2. check for PendingSelecction
        if (eventDB.EVENT_STATE == 6 && eventDB.STEP_FLOW == 'EVENT_READY_FOR_UI' 
            && (eventFromApi.EventState == 7 || eventFromApi.EventState == 8)) {
            hasChanges = '1';
            message.setProperty("eventInDB", eventDB);
            if (eventFromApi.EventState == 7) {
                message.setProperty("newStepFlow", 'CLOSED');
            }
            else {
                // if (eventFromApi.EventState == 8)
                message.setProperty("newStepFlow", 'CANCELLED');
            }
        }
    }
    
    message.setProperty("hasChanges", hasChanges);

    return message;
}