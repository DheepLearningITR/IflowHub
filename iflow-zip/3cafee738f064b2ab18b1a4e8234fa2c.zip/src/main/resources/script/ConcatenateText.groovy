import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String concatenateText(String t1,String t2,String t3,String t4,String t5,String t6,String t7,String t8,
                         String t9,String t10,String t11,String t12,String t13,String t14){
	String longText = ""; 
    longText = t1+t2+t3+t4+t5+t6+t7+t8+t9+t10+t11+t12+t13+t14;
	return longText;
}