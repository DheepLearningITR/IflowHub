import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Get the JSON string from the header
    def headers = message.getHeaders()
    def jsonString = headers.get("FormattedHTTPQuery")
    
    // Parse the JSON string
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(jsonString)

    // Initialize the writer for XML
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.setDoubleQuotes(true)

    // Build the XML structure with namespace
    xml.'n0:IsuC4cV2BpemGet'('xmlns:n0': 'urn:sap-com:document:sap:soap:functions:mc-style') {
        // Separate handling for dueDateFrom and dueDateTo
        if (jsonObject.dueDateFrom || jsonObject.dueDateTo) {
            ItDueDate {
                'item' {
                    Sign('I')
                    Option('BT')
                    DateFrom(jsonObject.dueDateFrom?.get(0)?.value ?: '')
                    DateTo(jsonObject.dueDateTo?.get(0)?.value ?: '')
                }
            }
        }

        jsonObject.each { key, value ->
            switch (key) {
                case 'top':
                    IvTop(value)
                    break
                case 'search':
                    IvSearchValue(value)
                    break
                case 'skip':
                    IvSkip(value)
                    break
                case 'contractAccountId':
                    ItContractAccount {
                        value.each { CA ->
                            'item'(CA.value.trim())
                        }
                    }
                    break
				case 'premise':
                    ItPremise {
                        value.each { premise ->
                            'item'(premise.value.trim())
                        }
                    }
                    break
				case 'processingStatus':
                    ItProcessingStatus {
                        value.each { ps ->
                            'item'(ps.value.trim())
                        }
                    }
                    break
				case 'priority':
                    ItPriority {
                    value.each { pr ->
                        'item' {
						Prio(pr.value.trim())
                        TXT("")
                        }
                    }
                }
                    break
                                 
                case 'reversedFlag':
                    IvIncludeReversedRet(value[0].value)
                    break
                default:
                    // Handle any additional dynamic fields here if necessary
                    break
            }
        }

        // Always include ItFilter with constant values
        ItAdditionalFilter {
            'item' {
                Fieldname('QueryFilter')
                FieldValue(headers.get("QueryFilter"))
                Sign('I')
                Option('')
                Low("")
                High("")
            }
        }
    }

    // Set the XML output as the message body
    message.setBody(writer.toString())

    return message
}
