import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def body = message.getBody(String.class);
    def headers = message.getHeaders() as String;
    
     if (messageLog != null) {
        messageLog.addAttachmentAsString("Request log", "Request body: " + body + "\nRequest headers: " + headers, "text/plain");
    }
    return message;
}