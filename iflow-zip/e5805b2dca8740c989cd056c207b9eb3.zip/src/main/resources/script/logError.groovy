import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def settlementUUID = message.getProperty("settlementUUID");

    if (messageLog != null) {
        messageLog.addAttachmentAsString("Error log", "The settlement with UUID=" + settlementUUID + " fail to synchronize with ITCM", "text/plain");
    }
    return message;
}