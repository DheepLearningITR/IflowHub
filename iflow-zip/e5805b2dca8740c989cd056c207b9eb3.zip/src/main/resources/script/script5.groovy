import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def settlementUUID = message.getProperty("settlementUUID");
    def body = message.getBody(String.class);
    
       if (messageLog != null) {
        messageLog.addAttachmentAsString("Result log", "The settlement with UUID=" + settlementUUID + " successfully synchronized with ITCM\n" + body, "text/plain");
    }
    return message;
}