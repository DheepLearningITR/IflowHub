import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    
    //Body
    def body = message.getBody(java.lang.String);

    def jsonSlurper = new JsonSlurper();
    def cfg = jsonSlurper.parseText(body);
    
    //Header
    if(cfg.InvoiceRequest.MessageHeader.ReconciliationIndicator != null){
        cfg.InvoiceRequest.MessageHeader.ReconciliationIndicator = Boolean.parseBoolean(cfg.InvoiceRequest.MessageHeader.ReconciliationIndicator);
    }
    //Amount
    if(cfg.InvoiceRequest.Invoice.GrossAmount != null){
        cfg.InvoiceRequest.Invoice.GrossAmount.value = Double.parseDouble(cfg.InvoiceRequest.Invoice.GrossAmount.value);
    }
    if(cfg.InvoiceRequest.Invoice.NetAmount != null){
        cfg.InvoiceRequest.Invoice.NetAmount.value = Double.parseDouble(cfg.InvoiceRequest.Invoice.NetAmount.value);
    }
    if(cfg.InvoiceRequest.Invoice.TaxAmount != null){
        cfg.InvoiceRequest.Invoice.TaxAmount.value = Double.parseDouble(cfg.InvoiceRequest.Invoice.TaxAmount.value);
    }
    //Header Tax
    if(cfg.InvoiceRequest.Invoice.HeaderTax != null){
        cfg.InvoiceRequest.Invoice.HeaderTax.each{
            if(it.Amount != null){
                it.Amount.value = Double.parseDouble(it.Amount.value);
            }
            if(it.TaxPercentage != null){
                it.TaxPercentage = Double.parseDouble(it.TaxPercentage);
            }
        }
    }
    //Payment Terms
    if(cfg.InvoiceRequest.Invoice.PaymentTerms != null){
        if(cfg.InvoiceRequest.Invoice.PaymentTerms.CashDiscount1Percent != null){
            cfg.InvoiceRequest.Invoice.PaymentTerms.CashDiscount1Percent = Double.parseDouble(cfg.InvoiceRequest.Invoice.PaymentTerms.CashDiscount1Percent);
        }
        if(cfg.InvoiceRequest.Invoice.PaymentTerms.CashDiscount1Days != null){
            cfg.InvoiceRequest.Invoice.PaymentTerms.CashDiscount1Days = Integer.parseInt(cfg.InvoiceRequest.Invoice.PaymentTerms.CashDiscount1Days);
        }
        if(cfg.InvoiceRequest.Invoice.PaymentTerms.CashDiscount2Percent != null){
            cfg.InvoiceRequest.Invoice.PaymentTerms.CashDiscount2Percent = Double.parseDouble(cfg.InvoiceRequest.Invoice.PaymentTerms.CashDiscount2Percent);
        }
        if(cfg.InvoiceRequest.Invoice.PaymentTerms.CashDiscount2Days != null){
            cfg.InvoiceRequest.Invoice.PaymentTerms.CashDiscount2Days = Integer.parseInt(cfg.InvoiceRequest.Invoice.PaymentTerms.CashDiscount2Days);
        }
        if(cfg.InvoiceRequest.Invoice.PaymentTerms.NetPaymentDays != null){
            cfg.InvoiceRequest.Invoice.PaymentTerms.NetPaymentDays = Integer.parseInt(cfg.InvoiceRequest.Invoice.PaymentTerms.NetPaymentDays);
        }
    }
    //Pricing Element
    if(cfg.InvoiceRequest.Invoice.PricingElement != null){
        cfg.InvoiceRequest.Invoice.PricingElement.each{
            if(it.ConditionAmount != null){
                it.ConditionAmount.value = Double.parseDouble(it.ConditionAmount.value);
            }
            if(it.ConditionBaseValue != null){
                it.ConditionBaseValue.value = Double.parseDouble(it.ConditionBaseValue.value);
            }
            if(it.ConditionRateValue != null){
                it.ConditionRateValue.value = Double.parseDouble(it.ConditionRateValue.value);
            }
            if(it.ConditionQuantity != null){
                it.ConditionQuantity.value = Double.parseDouble(it.ConditionQuantity.value);
            }
        }
    }
    //Item
    if(cfg.InvoiceRequest.Invoice.Item != null){
        cfg.InvoiceRequest.Invoice.Item.each{
            if(it.GrossAmount != null){
                it.GrossAmount.value = Double.parseDouble(it.GrossAmount.value);
            }
            if(it.NetAmount != null){
                it.NetAmount.value = Double.parseDouble(it.NetAmount.value);
            }
            if(it.TotalNetAmount != null) {
                it.TotalNetAmount.value = Double.parseDouble(it.TotalNetAmount.value);
            }
            if(it.TaxAmount != null) {
                it.TaxAmount.value = Double.parseDouble(it.TaxAmount.value);
            }
            if(it.InvoicedQuantity != null){
                it.InvoicedQuantity.value = Double.parseDouble(it.InvoicedQuantity.value);
            }
            //Item Tax
            if(it.ItemTax != null) {
                it.ItemTax.each {
                    if (it.Amount != null) {
                        it.Amount.value = Double.parseDouble(it.Amount.value);
                    }
                    if (it.TaxPercentage != null) {
                        it.TaxPercentage = Double.parseDouble(it.TaxPercentage);
                    }
                }
            }
            //Item Pricing Element
            if(it.PricingElement != null){
                it.PricingElement.each{
                    if(it.ConditionAmount != null){
                        it.ConditionAmount.value = Double.parseDouble(it.ConditionAmount.value);
                    }
                    if(it.ConditionBaseValue != null){
                        it.ConditionBaseValue.value = Double.parseDouble(it.ConditionBaseValue.value);
                    }
                    if(it.ConditionRateValue != null){
                        it.ConditionRateValue.value = Double.parseDouble(it.ConditionRateValue.value);
                    }
                    if(it.ConditionQuantity != null){
                        it.ConditionQuantity.value = Double.parseDouble(it.ConditionQuantity.value);
                    }
                }
            }
        }
    }
    def builder = new groovy.json.JsonBuilder(cfg);
    //println(builder.toPrettyString());

    message.setBody(builder.toPrettyString());
    return message;

}