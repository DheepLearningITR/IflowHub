import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;


def Message processData(Message msg) {
    def helperValMap = ITApiFactory.getApi(ValueMappingApi.class, null)
    def properties = msg.getProperties();

    def input = properties.get('logsysws');
    
    def url = helperValMap.getMappedValue('GK', 'logsysws', input , 'SAP', 'sap_binding_url_ws');
    def credentials = helperValMap.getMappedValue('GK', 'logsysws', input , 'SAP', 'sap_credentials_id_ws');
    def carcloudconnectionid = helperValMap.getMappedValue('GK', 'logsysws', input , 'SAP' , 'sap_cloud_connector_id_ws');
   
   
    msg.setProperty( 'binding_url', url );
    msg.setProperty( 'credentials_id', credentials);
    msg.setProperty( 'cloud_connector_id', carcloudconnectionid);
    
	return msg;
	
}