
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.*;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def json = jsonSlurper.parseText(body);

    def emailBody = "Integration Flow Execution Details:\n\n"
    
    json.each { key, value ->
        if (value) { 
            emailBody += "${key}: ${value}\n"
        }
    }
    message.setBody(emailBody)

    return message

}