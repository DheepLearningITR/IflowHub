
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.*;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    // Parse the message body to extract necessary fields
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper();
    def jsonObject = jsonSlurper.parseText(body);

    def executionStatus = jsonObject['Execution Status'];
    def artifactID = jsonObject['Artifact ID'];

    // Determine if a notification should be sent based on previous execution status
    def shouldNotify = true;
    def executionStatusByFlow = message.getProperty("p_ExecutionStatusByFlow");
    HashMap<Integer, String> executionStatusByFlowMap = new HashMap<Integer, String>();

    if (executionStatusByFlow != null && !executionStatusByFlow.trim().isEmpty()) {
        executionStatusByFlowMap = jsonSlurper.parseText(executionStatusByFlow) as HashMap<Integer, String>;
    }

    if (executionStatusByFlowMap.containsKey(artifactID)) {
        def previousStatus = executionStatusByFlowMap[artifactID];
        if (executionStatus.equals(previousStatus)) {
            shouldNotify = false;
        }
    }
    message.setProperty("p_ShouldNotify", shouldNotify);

    // Update the execution status map
    if (artifactID != null) {
        executionStatusByFlowMap.put(artifactID, executionStatus);
    }

    message.setProperty("p_ExecutionStatusByFlow", JsonOutput.toJson(executionStatusByFlowMap))
    message.setProperty("p_ExecutionStatus", executionStatus);

    return message

}