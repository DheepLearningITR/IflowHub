// =============================================================================================
// This groovy script deletes all linefeeds in in the payload of the 
// sender messagy body .
//
// History:// 2024-03-02 SAP [GS] - Initially created
// =============================================================================================
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.regex.Pattern;
import org.apache.commons.lang.StringEscapeUtils;

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    
      message.setBody(body.replaceAll("'\n", "'"));

    return message;
}
    
