// =============================================================================================
// This groovy script inserts a line feed after each UN/EDIFACT interchange, 
// if the sender messagy body has a payload with several UN/EDIFACT interchanges.
// For this case, the segment separator of the interchange trailer (UNZ) must be a single quote
// (').
//
// History:// 2024-03-02 SAP [GS] - Initially created
// =============================================================================================
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.regex.Pattern;
import org.apache.commons.lang.StringEscapeUtils;

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    
      message.setBody(body.replaceAll(/(UNZ\+[0-9]*\+[0-9A-Za-z]*)'(UN[AB])/, '$1\'\n$2'));
    
    return message;
}
    