// =============================================================================================
// This groovy script is responsible to determine if the partner sends multiple interchanges
//
// History:// 2024-09-20 SAP [MÖ] - Initially created
// =============================================================================================
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String;

    Pattern pattern = Pattern.compile(/UNB|ISA/); 
    Matcher matcher = pattern.matcher(body);
    if(matcher.find()){
        body = matcher.count;
        def interchanges = body;
        if(interchanges > 1)
            message.setHeader("SAP_EDI_Split_Sender_Per_Interchange","true")
        }

    return message;
}