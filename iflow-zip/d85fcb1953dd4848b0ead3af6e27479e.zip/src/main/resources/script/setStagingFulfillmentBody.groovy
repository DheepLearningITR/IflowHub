import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    setStagingFulfillmentBody(message)

    return message
}

def void setStagingFulfillmentBody(def message) {

    def body = message.getBody(java.lang.String) as String

    def stagingFulfillmentBody = body.replaceAll('WarehouseStockChangeNotification', 'WarehouseStagingFulfillmentNotification')

    message.setProperty('stagingFulfillmentBody', stagingFulfillmentBody)
}
