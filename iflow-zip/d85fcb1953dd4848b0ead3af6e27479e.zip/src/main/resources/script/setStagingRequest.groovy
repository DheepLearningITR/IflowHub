import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    setStagingRequest(message);

    return message;
}

def void setStagingRequest(def message) {


    def body = message.getBody(java.lang.String) as String;

    def data = new XmlSlurper().parseText(body);

    def stagingRequest = data.'**'.findAll { node -> node.name() == 'StagingRequest' }*.text();

    if (stagingRequest.size() > 0) {
        stagingRequest = stagingRequest[0].toString();

    } else {
        stagingRequest = "";
    }

    message.setProperty("stagingRequest", stagingRequest);

    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        messageLog.addAttachmentAsString("Log first stagingRequest:", stagingRequest, "text/plain");
    }

}