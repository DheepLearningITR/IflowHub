import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        messageLog.addAttachmentAsString("sap.dsc.dm.EWMStagingFulfillment.Received.v1 ", "True", "text/plain");
    }
    return message;
}