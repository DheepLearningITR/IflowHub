import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    props = message.getProperties();
    status = props.get("status");
    statusDate = props.get("statusDate");
    completion = "";
    if (status == 2) {
        completion = "Incomplete";
    } else {
        completion = "Complete";
    }
    
    latestDate = props.get("latest" + completion + "AssessmentDate");
    if (!latestDate || statusDate >= latestDate) {
        message.setProperty("latest" + completion + "AssessmentDate", statusDate);
        message.setProperty("latest" + completion + "AssessmentURL", props.get("currentOrderId"));
    }
    return message;
}