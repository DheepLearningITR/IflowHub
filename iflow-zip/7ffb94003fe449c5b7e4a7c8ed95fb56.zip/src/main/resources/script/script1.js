importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
    var body = String(message.getBody(new java.lang.String().getClass()));
	var jsonObject = JSON.parse(body);
	var expiresIn = jsonObject.expires_in;
	var tokenType = jsonObject.token_type;
	var accessToken = jsonObject.access_token;
	message.setProperty("TokenExpiresIn", expiresIn);
	message.setProperty("TokenType", tokenType);
	message.setProperty("AccessToken", accessToken);
    return message;
}