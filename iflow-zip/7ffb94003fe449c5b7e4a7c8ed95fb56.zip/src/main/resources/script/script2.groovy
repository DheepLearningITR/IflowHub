import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;

def Message processData(Message message) {
    def SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
    def map = message.getProperties();
    def tokenExpiresIn = map.get("TokenExpiresIn");
    def Calendar cal = Calendar.getInstance();
    cal.add(Calendar.SECOND, tokenExpiresIn.toInteger());
    message.setProperty("TokenExpirationTime", sdf.format(cal.getTime()));
    return message;
}