import com.sap.gateway.ip.core.customdev.util.Message;  //Default
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;                     //For getting credentials
import com.sap.it.api.securestore.SecureStoreService;   //For getting credentials
import com.sap.it.api.securestore.UserCredential;       //For getting credentials
import groovy.xml.*

// John Humma
// Vertex Inc.
// Credential Setting Script
// 08.09.2017

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	messageLog.setStringProperty("VtxLog1", "Get Credentials, Init");
	def service = ITApiFactory.getApi(SecureStoreService.class, null);
	map = message.getProperties();
	username = map.get("username");
	def credential = service.getUserCredential(username);

	//Set user
	messageLog.setStringProperty("VtxLog2", "Set User");
	def body = message.getBody(java.lang.String);
	def ns = new groovy.xml.Namespace("urn:vertexinc:o-series:tps:7:0",'ns1');
	def xml = new XmlParser().parseText(body);
	// Get username from security material credentials
	String userName = credential.getUsername();
	// Set username (always)
	xml[ns.Login][ns.UserName][0].value = userName;

	// Set password only if password is not null (On O Series Cloud, password is null)
	messageLog.setStringProperty("VtxLog3", "Set Password");
	if (credential.getPassword() != null) {
		xml[ns.Login][ns.Password][0].value = new String(credential.getPassword());
	}
	else {
		xml[ns.Login][ns.Password][0].value = userName;
	}

	// Put it all back together
	messageLog.setStringProperty("VtxLog4", "Serialize XML");
	body = XmlUtil.serialize(xml);
	message.setBody(body);

	//Return the message
	messageLog.setStringProperty("VtxLog5", "Return Message");
	return message;
}