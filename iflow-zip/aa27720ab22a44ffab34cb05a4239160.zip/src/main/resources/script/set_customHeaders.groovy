import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
	    def testRun = message.getHeaders().get("testRun");
		if(testRun != null && testRun != 'false' && testRun != ''){
			messageLog.addCustomHeaderProperty("cbr_testRun", testRun);		
        }
		def skillId = message.getProperties().get("skillId");
		if(skillId!=null){
			messageLog.addCustomHeaderProperty("cbr_skillId", skillId);		
        }
        def libName = message.getProperties().get("sfsfCompLibName");
		if(libName != null){
			messageLog.addCustomHeaderProperty("cbr_competencyLibraryName", libName);		
        }
	}
	return message;
}
def Message compCode(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def compCode = message.getProperties().get("sfsfCompetencyCode");
		if(compCode != null){
			messageLog.addCustomHeaderProperty("sfsf_competencyCode", compCode);		
        }
	}
	return message;
}