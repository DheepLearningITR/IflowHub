import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def orderInformation = new XmlSlurper().parse(body)

    if (orderInformation) {
        def currentProcessedBigCommerceOrderUpdatedAtTimestamp = orderInformation.date_modified;
        
        if(currentProcessedBigCommerceOrderUpdatedAtTimestamp && currentProcessedBigCommerceOrderUpdatedAtTimestamp.text()) {
            message.setProperty("currentProcessedBigCommerceOrderUpdatedAtTimestamp", currentProcessedBigCommerceOrderUpdatedAtTimestamp)
        }
    }

    return message;
}