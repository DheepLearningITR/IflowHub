import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def slurper = new JsonSlurper()
    def alreadyLinkedDeliveries = slurper.parseText(message.getProperty("alreadyLinkedS4HanaCloudOutboundDeliveries") ?: "[]")
    def newDeliveriesToLink = slurper.parseText(message.getProperty("newDeliveriesToLink")?: "[]")

    def combinedDeliveries = alreadyLinkedDeliveries + newDeliveriesToLink
    def stringDeliveries = combinedDeliveries.collect { it.toString() }
    def valueJsonString = JsonOutput.toJson(stringDeliveries)

    def result = ["permission_set": "read",
                  "namespace": "bigCommerce_accelerator",
                  "key": "s_4hana_cloud_outbound_deliveries",
                  "value": valueJsonString]

    message.setBody(JsonOutput.toJson(result))

    return message
}