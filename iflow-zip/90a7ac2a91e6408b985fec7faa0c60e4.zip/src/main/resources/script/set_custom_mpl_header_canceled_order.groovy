import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {

        def bigCommerceOrderId = message.getProperty("bigCommerceOrderID") as String;
        if (bigCommerceOrderId != null && !bigCommerceOrderId.isEmpty()) {
            messageLog.addCustomHeaderProperty("Canceled Order with BigCommerce ID", bigCommerceOrderId);
        }
    }
    return message;
}