import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {

        def bigCommerceOrderId = message.getProperty("bigCommerceOrderID") as String;
        if (bigCommerceOrderId != null && !bigCommerceOrderId.isEmpty()) {
            messageLog.addCustomHeaderProperty("Cancel not possible for BC Order ID", bigCommerceOrderId);
        }
    }
    return message;
}