import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)

    def xmlBody = new XmlSlurper().parse(body)

    xmlBody.data.each { metafieldsNode ->
        def key = metafieldsNode.key
        def value = metafieldsNode.value

        if (key == "s_4hana_cloud_order_id") {
            message.setProperty("S4HanaCloudOrderID", value.toString())
        }
        
        if (key == "s_4hana_cloud_outbound_deliveries") {
            message.setProperty("alreadyLinkedS4HanaCloudOutboundDeliveries", value)
            message.setProperty("outbound_delivery_metafield_id", metafieldsNode.id)
        }

        if (key == "s_4hana_cloud_order_cancelled") {
            message.setProperty("s4HanaCloudOrderCancelled", value)
        }
    }

    return message
}