import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import groovy.time.TimeCategory;



def Message processData(Message message) {
//Body
def body = message.getBody();

//Properties
def map = message.getProperties();
def currentperiod = map.get('Datetime');
def Periodicity = map.get('Periodicity');

Date date1 = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS", currentperiod)
Date date2;
def change = 0;
if(Periodicity == "001") {
date2 = date1.plus(-1)
}

else if(Periodicity == "002"){
use(TimeCategory){
date2 = date1 - 1.months 
}
}

else if(Periodicity == "007"){
use(TimeCategory){
date2 = date1 - 3.months 
}
}

else if(Periodicity == "008"){
use(TimeCategory){
date2 = date1 - 6.months 
}
}

else if(Periodicity == "003"){
use(TimeCategory){
date2 = date1 - 1.years 
}
}

else if(Periodicity == "005"){
use(TimeCategory){
date2 = date1 - 1.hours 
}
}

String date = date2.format("yyyy-MM-dd'T'HH:mm:ss.SSS")

message.setProperty("PreviousDate", date);

String datamonth = currentperiod.substring(5,7) + "/" + date.substring(0,4);

message.setProperty("dataMonth", datamonth);

return message;
}
