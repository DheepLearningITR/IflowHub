import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();

       //Properties 
       def map = message.getProperties();
       def value = map.get("openWFList");

       String bKey = map.get("UUID");
       
       String WFExists = 'N';
       if (value.contains(bKey)){
       WFExists = 'Y'    
       }
       
       message.setProperty("WFExists", WFExists);
       return message;
}