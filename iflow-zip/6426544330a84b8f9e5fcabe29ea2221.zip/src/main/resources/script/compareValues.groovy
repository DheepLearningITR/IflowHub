import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
       //Properties 
       def map = message.getProperties();
       def EType = map.get("EnvironmentLimitType");
       Double EUL = Double.parseDouble(map.get("EnvironmentLimitUpperValue"));
       Double ELL = Double.parseDouble(map.get("EnvironmentLimitValue"));
       
       Double EWUL = Double.parseDouble(map.get("EnvironmentLimitWarnUpValue"));
       Double EWLL = Double.parseDouble(map.get("EnvironmentLimitWarnValue"));
       
       Double dataValue = Double.parseDouble(map.get("Value"));
       def dataUnit = map.get("Measurename");
       def limit = '';
       def insight = '';
       Double absDiff = 0;
       Double perDiff = 0;
       
       if (EType == '00'){
           limit = 'value <= ' + EUL + ' ' + dataUnit;
       }
       else if (EType == '01'){
           limit = 'value >= ' + ELL + ' ' + dataUnit;
       }
       else {
           limit = ELL + ' ' + dataUnit + ' <= value <= ' + EUL + ' ' + dataUnit;
       }
       
       
       if (EType == '00'){
           if(dataValue > EWUL){
               absDiff = dataValue - EUL;
               perDiff = (dataValue - EUL) * 100 / EUL;
               perDiff = perDiff.round(2);
               
               if(absDiff > 0){
                    insight = absDiff + ' ' + dataUnit + ' (' + perDiff + ' %) ' + 'above Upper Limit';
               }
               else {
                   insight = '-' + (-1 * absDiff) + ' ' + dataUnit + ' (-' + (-1 * perDiff) + ' %) ' + 'away from Upper Limit';
               }
               
           }
       }
       else if (EType == '01'){
           if(dataValue < EWLL){
               absDiff = ELL - dataValue;
               perDiff = (ELL - dataValue) * 100 / ELL;
               perDiff = perDiff.round(2);
               
               if(absDiff > 0){
                    insight = absDiff + ' ' + dataUnit + ' (' + perDiff + ' %) ' + 'below Lower Limit';
               }
               else {
                   insight = '-' + (-1 * absDiff) + ' ' + dataUnit + ' (-' + (-1 * perDiff) + ' %) ' + 'away from Lower Limit';
               }
               
           }
       }
       else {
           if(dataValue > EWUL){
               absDiff = dataValue - EUL;
               perDiff = (dataValue - EUL) * 100 / EUL;
               perDiff = perDiff.round(2);
               
               if(absDiff > 0){
                    insight = absDiff + ' ' + dataUnit + ' (' + perDiff + ' %) ' + 'above Upper Limit';
               }
               else {
                   insight = '-' + (-1 * absDiff) + ' ' + dataUnit + ' (-' + (-1 * perDiff) + ' %) ' + 'away from Upper Limit';
               }
               
           }
           else if(dataValue < EWLL){
               absDiff = ELL - dataValue;
               perDiff = (ELL - dataValue) * 100 / ELL;
               perDiff = perDiff.round(2);
               
               if(absDiff > 0){
                    insight = absDiff + ' ' + dataUnit + ' (' + perDiff + ' %) ' + 'below Lower Limit';
               }
               else {
                   insight = '-' + (-1 * absDiff) + ' ' + dataUnit + ' (-' + (-1 * perDiff) + ' %) ' + 'away from Lower Limit';
               }
               
           }
       }
      
       
       message.setProperty("limit", limit.toString());
       message.setProperty("insight", insight.toString());
       message.setProperty("absDiff", absDiff.toString());
       message.setProperty("perDiff", perDiff.toString());
       return message;
}