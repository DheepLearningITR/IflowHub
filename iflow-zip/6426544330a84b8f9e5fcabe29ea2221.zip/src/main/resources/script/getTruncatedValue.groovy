import com.sap.it.api.mapping.*;


def String GetValue(String s){
	return s.substring(s.lastIndexOf(":")+1).trim(); 
}

def String GetDescription(String s){
	return s.replaceAll(",.*","").replace("Daily","").trim()
}