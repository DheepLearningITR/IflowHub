import com.sap.it.api.mapping.*;

def String IfElseIfElse(String value1, String condition1, String value2, String condition2, String value3, String condition3, String elseValue, MappingContext context){
    if(condition1 == "true"){
        return value1;
    }else if(condition2 == "true"){
        return value2;
    }
    else if(condition3 == "true"){
        return value3;
    }else{
        return elseValue;
    }
	
}