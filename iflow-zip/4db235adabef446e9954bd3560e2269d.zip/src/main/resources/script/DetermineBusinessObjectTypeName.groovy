import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser

def Message processData(Message message) {
    def body = message.getBody(String.class)
    def inputPayload = new XmlParser().parseText(body)

    // Set properties and headers
	message.setProperty("ActivityExternalId", inputPayload.fsm_body?.data?.activity?.externalId.text())
	message.setProperty("ServiceOrderKey", inputPayload.fsm_body?.data?.serviceCall?.externalId.text())
    message.setHeader("x-csrf-token", "fetch")

    def FSMTransactionType = message.getProperty("FSMTransactionType")
    def MaintenanceServiceCallTypeCode = message.getProperty("MaintenanceServiceCallTypeCode")
    def ServiceOrderBusinessObjectTypeName = message.getProperty("ServiceOrderBusinessObjectTypeName")
    def MaintenanceOrderBusinessObjectTypeName = message.getProperty("MaintenanceOrderBusinessObjectTypeName")

    // Set the BusinessObjectTypeName
    if (FSMTransactionType == MaintenanceServiceCallTypeCode) {
        message.setProperty("BusinessObjectTypeName", MaintenanceOrderBusinessObjectTypeName)
    } else {
        message.setProperty("BusinessObjectTypeName", ServiceOrderBusinessObjectTypeName)
    }
    
    return message
}
