import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

// Version 1.1
// get ids from incoming message from FSM API Attachment for setting SAP Application ID and custom log headers
def Message processData(Message message) {
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)
    
    def FSMTransactionType = jsonResult.root?.fsm_body?.data?.serviceCall?.type
    message.setProperty("FSMTransactionType", FSMTransactionType)
    
    def MaintenanceServiceCallTypeCode = message.getProperty("MaintenanceServiceCallTypeCode")
    
    // fetch X-Request-ID as SAP_ApplicationID
    def sapApplicationID = message.getHeaders().get("X-Request-ID")
    if (sapApplicationID != null && sapApplicationID != '') {
        message.setHeader("SAP_ApplicationID", sapApplicationID) 
    }
    // add ServiceOrder (id) and ServiceCall (id) to message headers and custom log headers
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null) {
        def serviceOrder, serviceCall, activityID
        // get ServiceOrder
        try {
            serviceOrder = jsonResult.root.fsm_body['data']['serviceCall']['externalId'] as String
        } catch(Exception ex1) { /* not found */ }
        if (serviceOrder == null) {
            try {
                activityID = jsonResult.root.fsm_body['data']['activity']['externalId'] as String
                if(activityID != null && activityID != '') {
                    serviceOrder = activityID.split('/')[0]
                }
            } catch(Exception ex2) { /* not found */ }
        }
        if(serviceOrder != null && serviceOrder != '') {
            message.setHeader("ServiceOrder", serviceOrder)
            
            if (FSMTransactionType == MaintenanceServiceCallTypeCode) {
                
            messageLog.addCustomHeaderProperty("MaintenanceOrder", serviceOrder)
            
              } else {
                  
                      messageLog.addCustomHeaderProperty("ServiceOrder", serviceOrder)
                    }
        }
        // get ServiceCall
        try {
            serviceCall = jsonResult.root.fsm_body['data']['serviceCall']['code'] as String
        } catch(Exception ex3) { /* not found */ }
        if(serviceCall != null && serviceCall != '') {
            message.setHeader("ServiceCall", serviceCall)
            messageLog.addCustomHeaderProperty("ServiceCall", serviceCall)
        }
    }
    
     if (FSMTransactionType == MaintenanceServiceCallTypeCode) {
         
      // Check the length of externalId in the serviceCall section for MaintenanceOrder
	def externalId = jsonResult.root?.fsm_body ?.data ?.serviceCall ?.externalId
    if (externalId && externalId.length() < 12) {
    jsonResult.root?.fsm_body.data.serviceCall.externalId = externalId.padLeft(12, '0')
    }
	
	// Check the externalId in the object section for MaintenanceOrder
    def objectExternalId = jsonResult.root?.fsm_body ?.data ?.attachment ?.object ?.objectId ?.externalId
    if (objectExternalId && objectExternalId.length() < 12) {
    jsonResult.root?.fsm_body.data.attachment.object.objectId.externalId = objectExternalId.padLeft(12, '0')
    }

    def updatedJsonString = JsonOutput.prettyPrint(JsonOutput.toJson(jsonResult))
    message.setBody(updatedJsonString);
    
     } else {
         
         message.setBody(body);
     }
    
    return message
}