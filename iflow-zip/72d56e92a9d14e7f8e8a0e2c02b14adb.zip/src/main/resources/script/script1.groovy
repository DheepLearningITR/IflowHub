import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message)
{   
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def deadQueue_endpoint = message.getProperties().deadQueue_endpoint ?: ''
    def EMpayload = message.getProperties().EM_Payload
    
    Exception exception = message.getProperties().get("CamelExceptionCaught");
    if(messageLog != null)
    {
        messageLog.addAttachmentAsString("Dead Queue Payload", EMpayload, "text/plain");
    }
    
    if(deadQueue_endpoint != '' && deadQueue_endpoint != null){
        messageLog.addCustomHeaderProperty("Error", "Send to Dead Queue Error: " + exception.getMessage());
        message.setProperty("deadQErr", "Send to Dead Queue Error: " + exception.getMessage());
    }
    else{
        messageLog.addCustomHeaderProperty("Error", "Send to Dead Queue Error: No deadQueue endpoint maintained.");
        message.setProperty("deadQErr", "Send to Dead Queue Error: No deadQueue endpoint maintained.");
    }
    return message;
}