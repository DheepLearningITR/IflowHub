/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.msglog.MessageLog
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message) {
    final messageLog = messageLogFactory.getMessageLog(message);
    Exception exception = message.getProperties().get("CamelExceptionCaught");
    String deadQueue_details;
    boolean isSendDeadQ = false;
    def deadQueueName = message.getProperties().get("deadQueueName");
    
    if(exception.getClass().getCanonicalName().contains("org.apache.camel.component.directvm.DirectVmConsumerNotAvailableException") || 
       exception.getClass().getCanonicalName().contains("com.sap.it.rt.adapter.processdirect.exceptions.ProcessDirectException"))
    {
        //get deadQueue endpoint
		def appID = message.getHeaders().get("SAP_ApplicationID");
		def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
		deadQueue_details = valueMapApi.getMappedValue('CPI', 'appID', appID, deadQueueName, 'Queue')
		message.setProperty("deadQueue_endpoint", deadQueue_details);
        isSendDeadQ = true;
        
        messageLog.addCustomHeaderProperty("Dead Queue", deadQueue_details.toString());
    }
    
    messageLog.addCustomHeaderProperty("Error", "Integration Flow Routing Error: " + exception.getMessage());
    messageLog.addCustomHeaderProperty("Send to Dead Queue", isSendDeadQ.toString());
    
    message.setProperty("ErrRoute", "Integration Flow Routing Error: " + exception.getMessage());
    message.setProperty("sendDeadQueue", isSendDeadQ);

    return message;
}