import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message) {
    //set properties
    def body = message.getBody(java.lang.String);
    def jsonparse
    def messageLog = messageLogFactory.getMessageLog(message);
    String JMS_Queue = message.getHeaders().get("JMSDestination");
    def appID = message.getHeaders().get("SAP_ApplicationID");
	
	//save orig payload
    message.setProperty("EM_Payload", body);
    
    //set custom getHeaders
    messageLog.addCustomHeaderProperty("appID", appID.toString());
    messageLog.addCustomHeaderProperty("JMS Queue", JMS_Queue);
    
	//get payload
    try{
        jsonparse = new JsonSlurper().parseText(body);
        jsonparse.data.each{
            if(it.value != '' && it.value != null){
                try{
                    messageLog.addCustomHeaderProperty(it.key, it.value);
                }
                catch(Exception e){
                }
            }
        }
    }
    catch(Exception e){
        throw new Exception("Validation: Invalid JSON payload from SAP Event Mesh", e); 
    }
    
    //get iflow endpoint
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def iflow_endpoint = valueMapApi.getMappedValue(JMS_Queue, 'appID', appID, 'CPI', 'Iflow')
    
    message.setProperty("iflow_endpoint", iflow_endpoint);
    messageLog.addCustomHeaderProperty("Destination Integration Flow", iflow_endpoint.toString());
    
    return message;
}