/**
 * Script Name: filterQueryByRegex
 * Author: Christian Riesener
 * Date: 2024-05-14
 * Description: This script contains functions to check if an interface is relevant based on regex filters and to count the number of interfaces, storing the count in a message property.
 *
 * Modifications:
 * None
 *
 * Notes:
 * - The `isIcoRelevant` function checks if the provided sender party, sender component, interface, and namespace match the regex patterns defined in the mapping context properties.
 * - The regex patterns are retrieved from the context properties: `FilterSenderParty`, `FilterSenderComponent`, `FilterInterface`, and `FilterNamespace`. Default patterns `.*` are used if the properties are not set.
 * - The `countInterfaces` function counts the number of interfaces provided in the array and stores this count as a string in the message property `NumberOfPOICos`.
 * - Ensure that the necessary context properties are set before executing these functions.
 */
import com.sap.it.api.mapping.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

def String isIcoRelevant(String sSenderParty, String sSenderComponent, String sInterface, String sNamespace, MappingContext context){
    
    // Read Regex Filter from Properties
	String sRegexSenderParty = context.getProperty("FilterSenderParty") ?: ".*";
	String sRegexSenderComponent = context.getProperty("FilterSenderComponent")?: ".*";
	String sRegexInterface = context.getProperty("FilterInterface")?: ".*";
	String sRegexNamespace = context.getProperty("FilterNamespace")?: ".*";
	
	// Create Pattern-Objects
    Pattern patternSenderParty = Pattern.compile(sRegexSenderParty);
    Pattern patternSenderComponent = Pattern.compile(sRegexSenderComponent);
    Pattern patternInterface = Pattern.compile(sRegexInterface);
    Pattern patternNamespace = Pattern.compile(sRegexNamespace);
    
    // Create Matcher-Objects
    Matcher matcherSenderParty = patternSenderParty.matcher(sSenderParty);
    Matcher matcherSenderComponent = patternSenderComponent.matcher(sSenderComponent);
    Matcher matcherInterface = patternInterface.matcher(sInterface);
    Matcher matcherNamespace = patternNamespace.matcher(sNamespace);
    
    if (matcherSenderParty.find() && matcherSenderComponent.find() && matcherInterface.find() && matcherNamespace.find() ) {
        return "true"
    } else {
        return "false"
    }
}

// Count Number of Interfaces and save in MessageProperty
def void countInterfaces(String[] interfaces, Output output, MappingContext context) {
    int numberOfPOIs = interfaces.length;

    String numberOfPOIsAsString = numberOfPOIs.toString();
    context.setProperty("NumberOfPOICos",numberOfPOIsAsString);
    
    interfaces.each { str ->
        output.addValue(str)
    }
}
