/**
 * Script Name: writeParametersToMsgLog.groovy
 * Author: Christian Riesener
 * Date: 2024-05-14
 * Description: This script logs various operational properties of the SAP CI Flow, including configurations for LeanIX and SAP Process Orchestration (PO),
 *              and dynamically records them as custom header properties. It supports conditional detailed logging for debugging purposes based on the trace level.
 *
 * Modifications:
 *
 * Notes:
 * - The script is designed to enhance traceability and ease troubleshooting processes within SAP integrations.
 */

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Retrieve the message log object for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // Retrieve properties from the message and log them with null checks.
    def traceLevel = message.getProperty("TraceLevel");
    def isSimulationModeActive = message.getProperty("isSimulationModeActive");
    def FilterSenderParty = message.getProperty("FilterSenderParty");
    def FilterSenderSystem = message.getProperty("FilterSenderSystem");
    def FilterInterface = message.getProperty("FilterInterface");
    def FilterNamespace = message.getProperty("FilterNamespace");
    def SAP_CC_LocationId = message.getProperty("SAP_CC_LocationId");
    def SAPPO_Hostname = message.getProperty("SAPPO_Hostname");
    def SAPPO_Port = message.getProperty("SAPPO_Port");
    def SAPPO_Timeout = message.getProperty("SAPPO_Timeout");
    def SAPPO_Credentials = message.getProperty("SAPPO_Credentials");
    def SAPCI_Credentials = message.getProperty("SAPCI_Credentials");
    def SAPCI_Hostname = message.getProperty("SAPCI_Hostname");

    // Log each property as a custom header property in the message log.
    messageLog.addCustomHeaderProperty("Ctrl_TraceLevel", traceLevel ?: "Not specified");
    messageLog.addCustomHeaderProperty("Ctrl_Simulation", isSimulationModeActive ?: "Not specified");
    messageLog.addCustomHeaderProperty("Filter_SenderParty", FilterSenderParty ?: "Not specified");
    messageLog.addCustomHeaderProperty("Filter_SenderSystem", FilterSenderSystem ?: "Not specified");
    messageLog.addCustomHeaderProperty("Filter_Interface", FilterInterface ?: "Not specified");
    messageLog.addCustomHeaderProperty("Filter_Namespace", FilterNamespace ?: "Not specified");
    messageLog.addCustomHeaderProperty("SAP_CC_LocationId", SAP_CC_LocationId ?: "Not specified");
    messageLog.addCustomHeaderProperty("SAPPO_Hostname", SAPPO_Hostname ?: "Not specified");
    messageLog.addCustomHeaderProperty("SAPPO_Port", SAPPO_Port ?: "Not specified");
    messageLog.addCustomHeaderProperty("SAPPO_Timeout", SAPPO_Timeout ?: "Not specified");
    messageLog.addCustomHeaderProperty("SAPPO_Credentials", SAPPO_Credentials ?: "Not specified");
    messageLog.addCustomHeaderProperty("SAPCI_Credentials", SAPCI_Credentials ?: "Not specified");
    messageLog.addCustomHeaderProperty("SAPCI_Hostname", SAPCI_Hostname ?: "Not specified");

    // Debugging logic: if trace level is debug, log all properties in a structured format.
    if (traceLevel == "debug") {
        messageLogFactory.getMessageLog(message)?.with {
            def content = new StringBuilder().with {
                it << "Properties".padRight(60, '-').padLeft(70, '-') + "\n";
                it << map(message.getProperties());
            };
            it.addAttachmentAsString("_Start Properties", content.toString(), "text/plain");
        }
    }

    return message;
}

// Helper function to format and sort message properties for logging.
def String map(Map map) {
    return map
        .sort { a, b -> a.key.toLowerCase() <=> b.key.toLowerCase() }
        .collect { "$it.key (${it.value.getClass().getSimpleName()}): $it.value" }
        .join("\n") + "\n\n";
}
