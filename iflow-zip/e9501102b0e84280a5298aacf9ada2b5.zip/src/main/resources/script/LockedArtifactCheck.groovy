/**
 * Script Name: LockedArtifactCheck
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script checks whether a value mapping artifact is locked by any users. It parses the input XML body
 *              and filters the "IntegrationDesigntimeLock" elements based on the artifact ID provided in the message properties.
 *              If the artifact is locked, it retrieves and logs the users who have locked the artifact.
 *              In simulation mode, the script logs the lock details and adds the information to the message log.
 * 
 * Notes:
 * - The script extracts the "ArtifactId" from the incoming XML and checks if the provided "Value Mapping ID" matches.
 * - If the artifact is locked, it retrieves the users who have locked the value mapping and logs the information.
 * - The script uses the `messageLogFactory` to log the details in case of a locked artifact.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

Message processData(Message message) {
    // Get the XML payload as a string from the message body
    def body = message.getBody(String)

    // Extract the "Value Mapping ID" from the message properties
    def artifactIdFilter = message.getProperty("Value Mapping ID") ?: ""

    // Parse the XML using XmlParser
    def xml = new XmlParser().parseText(body)

    // Find all "IntegrationDesigntimeLock" elements whose ArtifactId contains the provided Value Mapping ID
    def filteredLocks = xml.IntegrationDesigntimeLock.findAll { lock ->
        lock.ArtifactId.text().contains(artifactIdFilter)
    }

    // Determine if the artifact is locked
    def isLocked = !filteredLocks.isEmpty()

    // Set the "ValueMappingLocked" property on the message
    message.setProperty("ValueMappingLocked", isLocked)

    // If the artifact is locked, retrieve the users who have locked it and log the information
    if (isLocked) {
        // Collect the list of unique users who have locked the artifact
        def lockedByUsers = filteredLocks.collect { it.CreatedBy?.text() ?: "unknown" }.unique().join(", ")

        // Retrieve the message log (if available) to add log entries and attachments
        def messageLog = messageLogFactory?.getMessageLog(message)
        if (messageLog) {
            // Set a warning message in the message log for locked value mappings
            messageLog.setStringProperty("ValueMappingLockWarning", "Value Mapping '${artifactIdFilter}' is locked by: ${lockedByUsers}")
            
            // Add an attachment to the message log with detailed lock information
            messageLog.addAttachmentAsString("Internal Error Locked Info", "Locked Value Mapping: The Value Mapping is locked by \n${lockedByUsers}", "text/plain")
        }
    }

    // Return the updated message
    return message
}
