/**
 * Script Name: CreatePackage-PO
 * Author: Jakov Nasri
 * Date: 2024-11-06
 * Description: This script creates the JSON structure to create the Integration Package for the Value Mapping of the
 *              SAP Process Orchestration to LeanIX FactSheets synchranization. The Integration Package Name and Integration Package ID 
 *              can be configured idividually.
 * 
 * Modifications:
 * - 
 * Notes: 
 * - 
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);

    // Predefine the necessary values for package creation
    def packageId = message.getProperty("Value Mapping - Package ID");  // Predefined PackageId
    def packageName = message.getProperty("Value Mapping - Package Name");  // Predefined PackageName
    def packageShortText = "This Package is for the Value Mapping of thr SAP Cloud Integration to LeanIX Factsheets synchranization";  // Predefined ShortText

    // Validate that the packageName follows SAP's rules for PackageName
    if (!packageName.matches("[a-zA-Z_][a-zA-Z0-9 _.\\-]*[^.]")) {
        throw new IllegalArgumentException("Invalid PackageName format. It must start with a letter or underscore and should not end with a period.");
    }

    // Create a JSON structure using a map to avoid variable conflicts
    def jsonContent = [
        "Id"            : packageId,
        "Name"          : packageName,
        "ShortText"     : packageShortText,
        "Vendor"        : "Realcore Group GmbH"
    ]
    
    def cookie = message.getProperty("cookie");
    message.setHeader("Cookie", cookie.split(";")[0]);
    
    def token = message.getProperty("xCsrfToken");
    message.setHeader("X-CSRF-Token", token);

    // Convert the map to a JSON structure
    def jsonBuilder = new JsonBuilder(jsonContent);

    // Convert JSON structure to string and set it as the message body
    def jsonPayload = jsonBuilder.toPrettyString();
    message.setBody(jsonPayload);
    message.setHeader("content-type", "application/json");

    // Log the generated payload for debugging
    if (messageLog != null) {
        messageLog.addAttachmentAsString("Generated Package Payload", jsonPayload, "application/json");
    }

    return message;
}
