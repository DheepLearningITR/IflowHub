/**
 * Script Name: CreatePackage-PO
 * Author: Jakov Nasri
 * Date: 2024-11-06
 * Description: This script creates the JSON structure to create the Value Mapping of the
 *              SAP Process Orchestration to LeanIX FactSheets synchranization. The Value Mapping Name and Value Mapping ID 
 *              can be configured idividually.
 *
 * Modifications:
 * - 
 * Notes: 
 * - 
 */
 
 import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);

    // Predefine the necessary values directly
    def valueMappingId = message.getProperty("Value Mapping ID");  // Predefined ValueMappingId
    def valueMappingName = message.getProperty("Value Mapping Name");  // Predefined ValueMappingName
    def packageId = message.getProperty("Value Mapping - Package ID");  // Predefined PackageId
    def description = "This Value Mapping contains some tables to exchange technical information with business labels to provide SAP LeanIX Factsheet with an more understandable Result.";  // Predefined Description

    // Validate that the name follows SAP's rules for ValueMappingName
    if (!valueMappingName.matches("[a-zA-Z_][a-zA-Z0-9 _.\\-]*[^.]")) {
        throw new IllegalArgumentException("Invalid ValueMappingName format. It must start with a letter or underscore and should not end with a period.");
    }

    // Base64-encoded ZIP content (replace with the content from your zip file)
    def artifactContentBase64 = "UEsDBBQACAgIAG2CZlkAAAAAAAAAAAAAAAARAAAAdmFsdWVfbWFwcGluZy54bWytj1tLw0AQhf9KyLtuNjWXwnRLEYRA0YIKvpXZ7Gxc2EtI02D/vYsGpEhBio/nzOFjPlh/OJtMNBxM8KuU32ZpQr4Nyvhulb6+PNzU6VrA5H42edwI6IZw7BOjYi4lYq6KjIiTRLUoq4IWmSyWWhNyHsfkx+EkALuIPonnzW73tL8Prg8+XoDNPRzad3IoHtERsDnAhPZIovFmNGiBfUdgM/KcvCX0zdt+0/fWtDjGd3/BtyjJ/pXOvizPZOscVaUpKxG55rquSi7LuwJ5JSVf1hdkGz/SoLGl/5e9jL5KlU1OfAJQSwcIqsnHveQAAAAVAgAAUEsDBBQACAgIAG2CZlkAAAAAAAAAAAAAAAAIAAAALnByb2plY3SVkTtPAzEQhHt+hXV9fNBROJcCFAkpVAFEd9rYy8mRX/LjxM/H53MsngWdZzzjb7Vmu3etyIw+SGu23Q297ggaboU007Z7ftpvbrvdwJy3Z+TxHgP30sWcHa4IIcyAxuEFVMLxEZzLpfGAYB5exwOcULG+BEqUW63RxH5V9cFQ5SlJJY4OeZHNucsdMOJiNqL1E0WupAtIzyJSbn0+wAylhf4Tt9bAT2nBV+Bi9T8Q1WpzZFhMHkOrrPpv/Hq/0EvuWy1vgAZwVAqk8k3RugMaknPWx6b/98oMSoP7kr6IPDjrf/m6D1BLBwjLZw0e5gAAAPUBAABQSwMEFAAICAgAbYJmWQAAAAAAAAAAAAAAABQAAABNRVRBLUlORi9NQU5JRkVTVC5NRoWOQWrDMBBF9wLdYS5g0XaZnbMoGOzU4BKyMxNFSUUkjZAU09w+SuwK77qdx3/zOnT6rGKq9ipETW4D7+KNs+3NnYyquoUW+FHQDq3awB7NTUGH3mt3gaHuoVXomgO0eFQGzhRexz6QVDHCV5A/WRcwaeIMXLENd3sko+XKOi7WcTaOL2MZrHOfwflLNaPvu/9TLIaZ7ui0sOaz7eqes8Z6CqnqUV7xku+SrIjoxa8Wdl4KmXuMmNDkQxkMKkxa5kGpqWXSEyYK/0rEOqzMOOPsAVBLBwhF+DPl0gAAAIoBAABQSwMEFAAICAgAbYJmWQAAAAAAAAAAAAAAAA0AAABtZXRhaW5mby5wcm9wJY9NSwNBEETv+ysKcg/JIgsGPIggCBrExI9r70wn0zDbM0z3Rn++Wb0WvHpVq4OXxpjYSfRUUFup3FzYutUnR+zLBZsB22G3vd31A96PD+g3/U0X2UKT6lL07pjE8EF5ZrxQraJnhKJLo8HKxHAaMxu8gH9CIj1fIw5JJVDG4m0TLU34Fk8YZxNlM2QaOf9h11kXiYzD/SuemfTpC48U3BKz/0OkmJYns0Zu5qRxceKNbc6+7n4BUEsHCHIloFq3AAAA6AAAAFBLAQIUABQACAgIAG2CZlmqyce95AAAABUCAAARAAAAAAAAAAAAAAAAAAAAAAB2YWx1ZV9tYXBwaW5nLnhtbFBLAQIUABQACAgIAG2CZlnLZw0e5gAAAPUBAAAIAAAAAAAAAAAAAAAAACMBAAAucHJvamVjdFBLAQIUABQACAgIAG2CZllF+DPl0gAAAIoBAAAUAAAAAAAAAAAAAAAAAD8CAABNRVRBLUlORi9NQU5JRkVTVC5NRlBLAQIUABQACAgIAG2CZllyJaBatwAAAOgAAAANAAAAAAAAAAAAAAAAAFMDAABtZXRhaW5mby5wcm9wUEsFBgAAAAAEAAQA8gAAAEUEAAAAAA==";

    // Create a JSON structure using a map to avoid variable conflicts
    def jsonContent = [
        Name           : valueMappingName,
        Id             : valueMappingId,
        PackageId      : packageId,
        Description    : description,
        ArtifactContent: artifactContentBase64  // Base64-encoded content
    ]
    
    def cookie = message.getProperty("cookie");
    message.setHeader("Cookie", cookie.split(";")[0]);
    
    def token = message.getProperty("xCsrfToken");
    message.setHeader("X-CSRF-Token", token);

    // Convert the map to a JSON structure
    def jsonBuilder = new JsonBuilder(jsonContent);

    // Convert JSON structure to string and set it as the message body
    def jsonPayload = jsonBuilder.toPrettyString();
    message.setBody(jsonPayload);

    message.setHeader("content-type", "application/json");

    // Log the generated payload for debugging
    if (messageLog != null) {
        messageLog.addAttachmentAsString("Generated Value Mapping Payload", jsonPayload, "application/json");
    }

    return message;
}
