/**
 * Script Name: logNumberOfICOs
 * Author: Christian Riesener
 * Date: 2024-05-10
 * Description: This script is designed to log number of found Integrated Configuration Objects (ICOs) from SAP Process Orchestration (PO).
 *              It counts and logs the number of ICOs both before and after applying a specific filter, and logs the entire message body in debug mode.
 *
 * Modifications:
 * - 2024-05-13 - Comment added - Christian Riesener
 *
 * Notes:
 * - The script captures and logs the count of ICOs as found and after filtering.
 * - It adds detailed logging for debugging purposes, including the complete message body as a text attachment.
 * - The script uses regex to count specific XML tags
 */
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    // Retrieve the message log object for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // Retrieve the number of pre-filter ICOs and the trace level from the message properties.
    def numberOfPOICos = message.getProperty("NumberOfPOICos");
    def traceLevel = message.getProperty("TraceLevel");

    // Log the number of ICOs found in SAP PO as a custom header property.
    messageLog.addCustomHeaderProperty("__Found ICOs on SAP PO: ", numberOfPOICos);
    
    // Extract the message body as a String and use regex to count specific XML tags indicating ICOs.
    String xmlContent = message.getBody(String.class);
    def matcher = (xmlContent =~ /<\/IntegratedConfigurationID>/);
    def count = matcher.size();
    
    // Log the count of ICOs after filtering as a custom header property.
    messageLog.addCustomHeaderProperty("__ICOs to Read after Filter: ", count.toString());

    // If trace level is set to debug, log the entire XML message body for detailed review.
    if (traceLevel == "debug") {
        messageLog.addAttachmentAsString("SAP PO Query Response after Filter", xmlContent, "text/plain");
    }

    // Return the message, potentially modified with log entries.
    return message;
}
