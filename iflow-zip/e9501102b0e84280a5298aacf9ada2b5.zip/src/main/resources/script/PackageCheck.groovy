/**
 * Script Name: PackageCheck
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script processes the incoming XML payload to find an integration package with a specific ID.
 *              If the package is found, it is returned in the message body and logged in the message log. 
 *              If no matching package is found, a custom message is generated and returned instead.
 *              The result is also logged in the message log, and a boolean indicating whether the package was found
 *              is added as a property to the message.
 * 
 * Notes:
 * - The script filters the integration package based on the provided "Value Mapping - Package ID".
 * - If the package is found, it serializes and returns it in the message body and logs the result.
 * - If no matching package is found, a custom message is returned and logged.
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlParser;

def Message processData(Message message) {
    // Get the XML payload as a string from the message body
    def body = message.getBody(String);

    // Parse the XML using XmlParser
    def xmlParser = new XmlParser();
    def root = xmlParser.parseText(body);

    // The ID of the integration package we want to filter
    def targetPackageId = message.getProperty("Value Mapping - Package ID");

    // Find the desired integration package
    def foundPackage = root.IntegrationPackage.find { pkg ->
        pkg.Id.text() == targetPackageId
    }

    // Define a boolean variable to track if the package is found
    def packageFound = false;

    // Log the found result and set boolean
    def messageLog = messageLogFactory.getMessageLog(message);
    if (foundPackage != null) {
        packageFound = true;  // Set boolean to true if found
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Filtered Integration Package", groovy.xml.XmlUtil.serialize(foundPackage), "text/xml");
        }
        // Return the filtered integration package in the message body
        message.setBody(groovy.xml.XmlUtil.serialize(foundPackage));
    } else {
        // Set custom message when no matching package is found
        def noPackageMessage = "No matching Integration Package could be found";
        
        if (messageLog != null) {
            messageLog.addAttachmentAsString("No Integration Package Found", noPackageMessage, "text/plain");
        }

        // Set the custom message in the body
        message.setBody(noPackageMessage);
    }

    // Add the boolean result as a property in the message
    message.setProperty("packageFound", packageFound);

    return message;
}
