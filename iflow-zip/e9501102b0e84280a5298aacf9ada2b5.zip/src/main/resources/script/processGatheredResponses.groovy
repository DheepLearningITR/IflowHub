/**
 * Script Name: processGatheredResponses
 * Author: Christian Riesener
 * Date: 2024-05-14
 * Description: This script processes the response from a ValueMapping OData service. It analyzes the response lines to count and log the occurrences of 
 *              specific success and error messages related to 'System' and 'Interface'. Additionally, it adds these counts as custom header properties 
 *              for further processing and monitoring.
 *
 * Modifications:
 *
 * Notes:
 * - The script checks the trace level and logs the entire response as an attachment if the trace level is set to 'debug'.
 * - It uses regular expressions to identify and count success and error messages.
 * - Custom header properties are added to the message log for easy tracking of success and error counts.
 */

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    def traceLevel = message.getProperty("TraceLevel")
    def vmResponse = message.getBody(String).split('\n');
    
    def patternSystemError = ~/^(?!202).*System.*$/;
    def matchesSystemError = vmResponse.findAll{it =~ patternSystemError};
    def countSystemError = matchesSystemError.size();

    def patternInterfaceError = ~/^(?!202).*Interface.*$/;
    def matchesInterfaceError = vmResponse.findAll{it =~ patternInterfaceError};
    def countInterfaceError = matchesInterfaceError.size();

    def patternSystemSuccess = ~/^202.*System :.*$/;
    def matchesSystemSuccess = vmResponse.findAll{it =~ patternSystemSuccess};
    def countSystemSuccess = matchesSystemSuccess.size();

    def patternInterfaceSuccess = ~/^202.*Interface :.*$/;
    def matchesInterfaceSuccess = vmResponse.findAll{it =~ patternInterfaceSuccess};
    def countInterfaceSuccess = matchesInterfaceSuccess.size();

    if ((traceLevel == "debug" && !isSimulationModeActive) || countSystemError > 0 || countInterfaceError > 0) {
        messageLog.addAttachmentAsString("ValueMapping OData Response", message.getBody(String), "text/plain")
    }

    messageLog.addCustomHeaderProperty("__VM System Inserts Successfull", countSystemSuccess.toString());
    messageLog.addCustomHeaderProperty("__VM System Inserts Errors", countSystemError.toString());
    messageLog.addCustomHeaderProperty("__VM Interface Inserts Successfull", countInterfaceSuccess.toString());
    messageLog.addCustomHeaderProperty("__VM Interface Inserts Errors", countInterfaceError.toString());

    // Return the modified message.
    return message;
}
