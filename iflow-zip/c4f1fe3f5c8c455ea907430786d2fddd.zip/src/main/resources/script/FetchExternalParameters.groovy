import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;

// Returns the value of propertyName
def String getProperty(String propertyName, MappingContext context){
	return context.getProperty(propertyName); 
}