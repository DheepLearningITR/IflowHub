import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.CompileStatic

def Message processData(Message message) {
    def grcControls = message.getProperty("grcControls")
    def skip = message.getProperty("skip")
    def top = message.getProperty("top")

    def body = message.getBody(java.io.Reader)
    def jsonBody = new JsonSlurper().parse(body)
    List controlList = jsonBody.value

    controlList.stream().filter{control -> control.externalId != null && control.externalId.length() > 0 && !(control.status.equals("RETIRED"))}.forEach{ control -> grcControls.add(new GrcControl(control.complianceControlId, control.externalId))}

    message.setProperty("skip", Integer.valueOf(skip) + Integer.valueOf(top))

    return message
}

@CompileStatic
class GrcControl {
    String controlGuid
    String signavioControlId
    List processes

    GrcControl(String controlGuid, String signavioControlId) {
        this.controlGuid = controlGuid
        this.signavioControlId = signavioControlId
        processes = []
    }
}