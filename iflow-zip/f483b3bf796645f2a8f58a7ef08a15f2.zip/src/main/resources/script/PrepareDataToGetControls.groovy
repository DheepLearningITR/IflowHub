import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def grcControls = []
    message.setProperty('grcControls', grcControls)
    
    def nonExistControlMap = [:]
    message.setProperty('nonExistControlMap', nonExistControlMap)

    return message
}