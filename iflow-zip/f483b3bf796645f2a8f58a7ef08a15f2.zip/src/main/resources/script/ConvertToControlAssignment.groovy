import com.sap.gateway.ip.core.customdev.util.Message
import groovy.transform.CompileStatic

def Message processData(message) {
    def controls = message.getProperty('grcControls')
    def processMappingMap = message.getProperty('processMappingMap')

    setGrcProcessIds(controls, processMappingMap)
    def grcControlProcessAssignments = convertToGrcControlProcessAssignments(controls)

    message.setProperty('grcControlProcessAssignments', grcControlProcessAssignments)
    message.setProperty('index', 0)
    
    def nonExistControlMap = message.getProperty('nonExistControlMap')
    if (nonExistControlMap.size() > 0){
        def messageLog = messageLogFactory.getMessageLog(message)
        messageLog.addAttachmentAsString("Not Exist RAM-Signavio Control Ids in Signavio", "Not Exist RAM-Signavio Control Ids in Signavio: " + nonExistControlMap, "text/plain")
    }

    return message
}

def List convertToGrcControlProcessAssignments(controls) {
    List<GrcControlProcessAssignment> grcControlProcessAssignments = []
    for (def control : controls) {
        def controlProcessAssignment = new GrcControlProcessAssignment(control.controlGuid)
        def assignedProcess = controlProcessAssignment.processes
        for (def process : control.processes) {
            if (process.processId) {
                assignedProcess.add(new Process(process.processId))
            }
        }
        grcControlProcessAssignments.add(controlProcessAssignment)
    }
    return grcControlProcessAssignments
}

def void setGrcProcessIds(controls, processMappingMap) {
    for (def control : controls) {
        for (def process : control.processes) {
            if (processMappingMap.containsKey(process.signavioProcessId)) {
                def processMapping = processMappingMap.get(process.signavioProcessId)
                if (process.signavioActivityId) {
                    def activityMapping = processMapping.activityMappingMap
                    process.processId = activityMapping.get(process.signavioActivityId).grcActivityId
                } else {
                    process.processId = processMapping.grcProcessId
                }
            }
        }
    }
}

@CompileStatic
class GrcControlProcessAssignment {
    String controlId
    List processes

    GrcControlProcessAssignment(String controlId) {
        this.controlId = controlId
        this.processes = []
    }
}

@CompileStatic
class Process {
    String processId

    Process(String processId) {
        this.processId = processId
    }
}