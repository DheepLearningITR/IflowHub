import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.CompileStatic
import groovy.transform.Field

@Field public static final String META_BPMN_CONTRIL = 'meta-bpmncontrol'
@Field public static final String META_ACTIVITY_CONTRIL = 'meta-activitycontrol'

def Message processData(Message message) {
    def controls = message.getProperty('grcControls')
    def index = Integer.valueOf(message.getProperty('index'))

    def body = message.getBody(java.io.Reader)
    def links = new JsonSlurper().parse(body)

    def currentControl = controls[index]
    
    if (!(links instanceof ArrayList) && links.errors) {
        def nonExistControlMap = message.getProperty('nonExistControlMap')
        nonExistControlMap.put(currentControl.controlGuid, currentControl.signavioControlId)
    } else {
        links.each{link -> setControlAssignment(currentControl, link)} 
    }
    
    message.setProperty('index', ++index)
    return message
}

def void setControlAssignment(control, link) {
    switch (link.rep.propertyId) {
        case META_BPMN_CONTRIL:
            def process = new AssignedProcess(link.rep.model)
            control.processes.add(process)
            break
        case META_ACTIVITY_CONTRIL:
            def process = new AssignedProcess(link.rep.model, link.rep.elementId)
            control.processes.add(process)
            break
        default:
            break
    }
}

@CompileStatic
class AssignedProcess {
    String processId
    String signavioProcessId
    String signavioActivityId

    AssignedProcess(String signavioProcessId) {
        this.signavioProcessId = signavioProcessId
    }

    AssignedProcess(String signavioProcessId, String signavioActivityId) {
        this.signavioProcessId = signavioProcessId
        this.signavioActivityId = signavioActivityId
    }
}

