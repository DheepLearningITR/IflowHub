import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.Field

@Field public static final String CUSTOM_ATTRIBUTE_PROCESS_ID = 'meta-ramprocesstechnicalid'
@Field public static final String ACTIVITY_STENCIL_ID = 'Task'

def Message processData(Message message) {
    Map processMappingMap = message.getProperty('processMappingMap')
    def modelIds = message.getProperty('modelIds')
    def index = Integer.valueOf(message.getProperty('index'))
    def currentModelId = modelIds[index]

    def body = message.getBody(java.io.Reader)
    def model = new JsonSlurper().parse(body)

    if (model.errors) {
        processMappingMap.remove(currentModelId)
    } else {
        def currentProcess = processMappingMap.get(currentModelId)
        currentProcess.grcProcessId = model.properties[CUSTOM_ATTRIBUTE_PROCESS_ID]
        getProcessesAndActivities(model, currentProcess.activityMappingMap)
    }

    message.setProperty('index', ++index)

    return message
}

def void getProcessesAndActivities(model, activityMappingMap) {
    if (model?.stencil?.id?.equals(ACTIVITY_STENCIL_ID)) {
        if (activityMappingMap.containsKey(model.resourceId)) {
            activityMappingMap.get(model.resourceId).grcActivityId = model.properties[CUSTOM_ATTRIBUTE_PROCESS_ID]
        }
    }

    model.childShapes.each{ getProcessesAndActivities(it, activityMappingMap) }
}