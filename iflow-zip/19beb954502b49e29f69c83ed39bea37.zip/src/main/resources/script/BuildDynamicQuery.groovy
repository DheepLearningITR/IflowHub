import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

	//Properties  
	def pmap = message.getHeaders();
    def messageLog = messageLogFactory.getMessageLog(message);

   
    String personIdExternal = pmap.get("personIdExternal");
    String emailAddress = pmap.get("emailAddress");
    
	String Operator = "";
	String query = "";

	
// add filter parameter for personIdExternal
	if(personIdExternal != null && personIdExternal != "") {	
	    query = query + " personIdExternal eq ('" + personIdExternal +"')";
		message.setProperty("FILTER_PARAMETERS", query);
		Operator = 'TRUE'
	}
	
// add filter parameter for emailAddress
	if(emailAddress != null && emailAddress != "") 
	{ 
	    if(Operator == 'TRUE')
	    {
	    query = query + " emailAddress eq ('" + emailAddress +"')";
    	} 
	    else 
    	{
	    query = query + " emailAddress eq ('" + emailAddress +"')";
	         Operator = 'TRUE'
    	}
    }


		//Set FILTER_PARAMETERS
	message.setProperty("FILTER_PARAMETERS", query);
	if(messageLog != null){
		messageLog.setStringProperty("FILTER_PARAMETERS: ", query);
	}
	
	return message;
}