//  Prepare HTTP call to check relevance
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.ITApiFactory;

def Message processData(Message message) {
    
    def properties = message.getProperties();
    
	message.setHeader("Content-Type","application/xml");
	message.setHeader("Accept","application/xml");
	message.setHeader("Authorization","Bearer "+ message.getProperty("com.sap.hybris.fscm.AccessToken"));
	//dont have the mappting at this point. Will use it later
	def valueMapService = ITApiFactory.getApi(ValueMappingApi.class, null);
	
	def valueFSCMVersion   = 'FSCM_' + message.getProperty("com.sap.hybris.fscm.FSCM_Version");
    def valueHybrisVersion = 'FSA_' + message.getProperty("com.sap.hybris.fscm.FSA_Version");
    
    def fscmProductId = message.getProperty("com.sap.hybris.fscm.ProductID");
	def valueProductId = valueMapService.getMappedValue(valueFSCMVersion, "ProductId", fscmProductId, valueHybrisVersion, "ProductId")
	
	message.setBody("<?xml version='1.0' encoding='UTF-8'?><claims><claim><claimId>" + message.getProperty("com.sap.hybris.fscm.ClaimNumber") + "</claimId><policyHolderId>" + message.getProperty("com.sap.hybris.fscm.BusinessPartnerID") +"</policyHolderId><productId>" +  valueProductId  + "</productId><policyId>" +  message.getProperty("com.sap.hybris.fscm.PolicyNumber")  + "</policyId><contractId>" +  message.getProperty("com.sap.hybris.fscm.ContractID")  + "</contractId></claim></claims>");

	return message;
}