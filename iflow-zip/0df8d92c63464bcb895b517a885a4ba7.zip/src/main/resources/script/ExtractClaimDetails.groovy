
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.ITApiFactory;

def Message processData(Message message) {
    def properties = message.getProperties();
    def bodyStr = message.getBody();

    def rfcSet = new XmlSlurper().parseText(bodyStr);
    
    def keyStr = '';
    def valStr = '';
    def tabName = '';
    def fieldName = '';

    def resp = rfcSet.breadthFirst().find { node-> node.name() == 'ET_DATA' };
    
    if (resp == null || resp.item == null) {
        return message;
    }
    
    def valueMapService = ITApiFactory.getApi(ValueMappingApi.class, null);
    def valueFSCMVersion   = 'FSCM_' + message.getProperty("com.sap.hybris.fscm.FSCM_Version");
    def valueHybrisVersion = 'FSA_' + message.getProperty("com.sap.hybris.fscm.FSA_Version");
    
    resp.item.each{ item->
    
        tabName = item.TABNAME.text();
        fieldName = item.FIELDNAME.text();
        valStr = item.VALUE.text();
        origVal = valStr;
        
        keyStr = "com.sap.hybris.fscm." + tabName + '_' + fieldName;

        if (tabName == "ICLCLAIM") {
            
            if (fieldName == "STATUS") {
                keyStr = "com.sap.hybris.fscm.ClaimStatusCode";
                valStr = valueMapService.getMappedValue(valueFSCMVersion, "ClaimStatusCode", valStr, valueHybrisVersion, "ClaimStatusCode");
                
            } else if (fieldName == "DATELOSS") {
                keyStr = "com.sap.hybris.fscm.LossDateTime";
                valStr = valStr.substring(0, 4) + "-" + valStr.substring(4, 6) + "-" + valStr.substring(6) + "T00:00:00";
                
            } else if (fieldName == "LOSSTYPE") {
                keyStr = "com.sap.hybris.fscm.IncidentTypeIncidentCode";
                valStr = valueMapService.getMappedValue(valueFSCMVersion, "LossType", valStr, valueHybrisVersion, "LossType");
            }
        }
        
        if (valStr == null) {
            valStr = "";
        }

        message.setProperty(keyStr, valStr);
     }
     
    message.setBody(""); 
    
	return message;
	
}

