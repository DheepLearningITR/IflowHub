import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

def String subStringforRemarks(String invoicetype, String note, MappingContext context){
    String taxationMode= context.getProperty("taxationMode");
    taxationMode= taxationMode.toString();
    switch(taxationMode) {            
         case "0": 
         	if(invoicetype.equals("1") || invoicetype.equals("2") || invoicetype.equals("3")){
         		return note.take(96)
         	}
         	if(invoicetype.equals("0") || invoicetype.equals("4")){
         		return note.take(154)
         	}
         case "2": 
           if(invoicetype.equals("1") || invoicetype.equals("2") || invoicetype.equals("3")){
         		return note.take(114)
         	}
         	if(invoicetype.equals("0") || invoicetype.equals("4")){
         		return note.take(160)
         	}
      }
}