/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
       message.setProperty("successCode","000000");
   
       def map = message.getProperties();
       def method = map.get("method");
       def invcCode = map.get("invcCode");
       def invcNmbr = map.get("invcNmbr");
       def invcType = map.get("invcType");
       def netvalueHeader = map.get("netvalueHeader");
       def netvalueItem = map.get("netvalueItem");
       def discamount = map.get("discamount");
       def deductions = map.get("deductions");
       def item = map.get("item");
       def gtdNo = map.get("gtdNo");
       def rednotenmbr = map.get("rednotenmbr");
       def taxamount = map.get("taxamount");
       def quantity = map.get("quantity");
       
        if(method == "open"){
           message.setProperty("logKey",gtdNo);
        }else if(method == "cancel"){
           message.setProperty("logKey",invcCode + "_" + invcNmbr);
        }       
       
       if(method == "open" && gtdNo == ""){
	    	message.setProperty("successCode","200003");
	        message.setProperty("errorMessage","流水号不能为空");
	        message.setProperty("detailMessage","开具请求中，发票流水号不能为空，请确保gtdnmbr不为空");
	        return message;
       }

       if(method =="open" && (item == null || item == '' )){
           	message.setProperty("successCode","200007");
	        message.setProperty("errorMessage","XML格式错误");
	        message.setProperty("detailMessage","XML格式错误，Item节点不能为空");
	        return message;
       }
       
       if(!taxamount.isNumber() && method == "open"){
           message.setProperty("successCode","200014");
		   message.setProperty("errorMessage","XML字段错误");
		   message.setProperty("detailMessage","XML字段错误, 发票总税额必须为数字且不能为空");
		   return message;
       }
       
       if(!netvalueHeader.isNumber() && method == "open"){
           message.setProperty("successCode","200014");
		   message.setProperty("errorMessage","XML字段错误");
		   message.setProperty("detailMessage","XML字段错误, Header中的发票总金额必须为数字且不能为空");
		   return message;
       }
       
        String content = message.getBody(java.lang.String) as String;
	    def rootNode = new XmlParser().parseText(content)
        def items = rootNode.Invoices.Header.Item
	    for (Node node : items) {
	        def netvalueContext = node.netvalue.text();
		    if(!netvalueContext.isNumber()){
			    message.setProperty("successCode","200014");
		        message.setProperty("errorMessage","XML字段错误");
		        message.setProperty("detailMessage","XML字段错误, Item中的发票总金额必须为数字且不能为空");
		        return message;
		    }
		    def discountAmountContext = node.discamount.text();
		    if(discountAmountContext != "" & !discountAmountContext.isNumber()){
			    message.setProperty("successCode","200014");
		        message.setProperty("errorMessage","XML字段错误");
		        message.setProperty("detailMessage","XML字段错误, Item中的折扣金额必须为数字");
		        return message;
		    }
		    def discountTaxAmountContext = node.disctaxamount.text();
		    if(discountTaxAmountContext != "" & !discountTaxAmountContext.isNumber()){
			    message.setProperty("successCode","200014");
		        message.setProperty("errorMessage","XML字段错误");
		        message.setProperty("detailMessage","XML字段错误, Item中的折扣税额必须为数字");
		        return message;
		    }
		    def quantityText = node.blldqty.text();
		    if(quantityText != ""){
		        if(quantityText == "0" || !quantityText.isNumber()){
			    message.setProperty("successCode","200014");
		        message.setProperty("errorMessage","XML字段错误");
		        message.setProperty("detailMessage","XML字段错误, Item中的商品数量必须为数字且不能为零");
		        return message;
	            }
	        }
		}
       
       if(deductions != "" && !deductions.isNumber() && method == "open"){
           message.setProperty("successCode","200014");
		   message.setProperty("errorMessage","XML字段错误");
		   message.setProperty("detailMessage","XML字段错误, 差额征税扣除额必须为数字");
		   return message;
       }
       
       if(method == "open" && (invcCode == "" || invcNmbr == "") && netvalueHeader.toBigDecimal() < 0 && invcType == "1"){
	    	message.setProperty("successCode","200005");
	        message.setProperty("errorMessage","发票代码或发票号码不能为空");
	        message.setProperty("detailMessage","开具请求为红普票，发票代码或发票号码不能为空，请确保invccode和invcnmbr不为空");
	        return message;
       }
       
       if(method == "open" && rednotenmbr == "" && netvalueHeader.toBigDecimal() < 0 && invcType == "0"){
	    	message.setProperty("successCode","200006");
	        message.setProperty("errorMessage","红票通知单号不能为空");
	        message.setProperty("detailMessage","开具请求为红专票，红票通知单号不能为空，请确保rednotenmbr不为空");
	        return message;
       }
       if((invcCode == "" || invcNmbr == "") && method == "cancel"){
            message.setProperty("successCode","200004");
            message.setProperty("errorMessage","发票代码或发票号码不能为空");
            message.setProperty("detailMessage","作废请求中，发票代码或发票号码不能为空，请确保invccode和invcnmbr不为空");
            return message;
       }
       
       return message;
}