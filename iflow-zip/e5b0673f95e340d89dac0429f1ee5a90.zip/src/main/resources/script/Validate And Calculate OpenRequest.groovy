import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.Exception;
import java.lang.String;
import java.math.BigDecimal;
import groovy.xml.XmlUtil;
import groovy.util.*;

def Message processData(Message message) {

	def map = message.getProperties();
	def messageLog = messageLogFactory.getMessageLog(message);

	String content = message.getBody(java.lang.String) as String;

	def rootNode = new XmlParser().parseText(content)

// 	handleEmptyAmountCase(rootNode,message,messageLog)

    setBuyerEmail(map, message)

	calucalateInvoiceTypeCode(map, message)

	caluclateDeductionAndTaxationMode(rootNode, message)

	recaluclateItems(rootNode,map, message, messageLog);

	return message;
}

def setBuyerEmail(Map map, Message message){
	def buyerEmail = map.get("buyerEmail");
	def defaultEmail = map.get("defaultBuyerEmail");
	if(buyerEmail == "")
	{
	    message.setProperty("buyerEmail", defaultEmail);
	}
}

def calucalateInvoiceTypeCode(Map map, Message message){
    String body = message.getBody(java.lang.String) as String;
	def invoiceTypeCode = map.get("invoiceTypeCode");
	switch(invoiceTypeCode) {
		case "0":
			message.setProperty("invoiceTypeCode", "004");
			break;
		case "1":
			message.setProperty("invoiceTypeCode", "007");
			break;
		case "2":
			message.setProperty("invoiceTypeCode", "007");
			break;
		case "3":
			message.setProperty("invoiceTypeCode", "026");
			break;
		case "4":
			message.setProperty("invoiceTypeCode", "028");
			break;
		case "5":
		    message.setProperty("invoiceTypeCode", "01");
            message.setProperty("eInvoiceMode", "X");
			break;
		case "6":
		    message.setProperty("invoiceTypeCode", "02");
            message.setProperty("eInvoiceMode", "X");
			break;
		default: 
            message.setProperty("invoiceTypeCode", invoiceTypeCode);
			break;
	}
}

def caluclateDeductionAndTaxationMode(rootNode, message){
	def allItems = rootNode.Invoices.Header.Item
	def deductibleAmount = 0;
	for (Node item : allItems) {
		if(item.deductions != null && !item.deductions.text().isEmpty()){
			def deduction = item.deductions.text() as Double;
			deductibleAmount = deductibleAmount + deduction;
		}
	}

	if(deductibleAmount > 0){
		message.setProperty("taxationMode", "2");
	}else{
		message.setProperty("taxationMode", "0");
	}

	if(deductibleAmount != 0){
		message.setProperty("deductibleAmount", deductibleAmount);
	}else{
		message.setProperty("deductibleAmount", "");
	}
}

def recaluclateItems(Node rootNode, Map map,Message message,Object messageLog) {
	def decimalLength = map.get("decimalLength");
	
	def originalItems = rootNode.Invoices.Header.Item
	
	//  check item length, if length > 8, set isgoodslist to 1, else set to 0
	def originalItemsLen = originalItems.size();
	if (originalItemsLen > 8) {
	    message.setProperty("isgoodslist", "1");
	} else {
	    message.setProperty("isgoodslist", "0");
	}
	
	def newItems = new NodeList();
	for (Node node : originalItems) {
	    //re-calculate unitprice
		def quantityText = node.blldqty.text();
		def netvalueText = node.netvalue.text();
		BigDecimal netvalue = new BigDecimal(netvalueText);

		if(quantityText == ""){
		    if(netvalue > 0){
		        quantityText = "1";
		        node.blldqty.get(0).setValue('1')
		    }
		    else{
		        quantityText = "-1";
		        node.blldqty.get(0).setValue('-1')
		    }
		}
		
		BigDecimal quantity = new BigDecimal(quantityText);
		BigDecimal num = netvalue.divide(quantity, decimalLength.toInteger(), BigDecimal.ROUND_HALF_UP)
		
		def unitpriceText = num.stripTrailingZeros().toString();
        node.unitprice.get(0).setValue(unitpriceText);

		def discountAmountContext = node.discamount.text();
		if(discountAmountContext.isEmpty()){
			node.discamount.get(0).setValue('0')
		}
		newItems.add(node);
		
		if(!discountAmountContext.isEmpty()){
			def discountAmount = discountAmountContext as Double
			if(discountAmount != 0){
				def discountTaxAmountText = node.disctaxamount.text();
				def caluclatedDiscountTaxAmountText;
				if(discountTaxAmountText != null && !discountTaxAmountText.isEmpty()){
					def discountTaxAmount = discountTaxAmountText as Double
					def caluclatedDiscountTaxAmount = -Math.abs(discountTaxAmount)
					caluclatedDiscountTaxAmountText = caluclatedDiscountTaxAmount.toString()
				}else{
					caluclatedDiscountTaxAmountText = ""
				}
				def caluclatedDiscountAmount = -Math.abs(discountAmount)
				def discountItem = node.clone();
				discountItem.netvalue.get(0).setValue(caluclatedDiscountAmount);
				discountItem.taxamount.get(0).setValue(caluclatedDiscountTaxAmountText)
				if(discountItem.matlspec.size() != 0 && discountItem.matlspec.get(0).text().isEmpty() == false){
					discountItem.remove(discountItem.matlspec)
				}
				if(discountItem.blldqty.size() != 0 && discountItem.blldqty.get(0).text().isEmpty() == false){
					discountItem.remove(discountItem.blldqty)
				}
				if(discountItem.unitprice.size() != 0 && discountItem.unitprice.get(0).text().isEmpty() == false){
					discountItem.remove(discountItem.unitprice)
				}
				if(discountItem.unitofmsrdesc.size() != 0 && discountItem.unitofmsrdesc.get(0).text().isEmpty() == false){
					discountItem.remove(discountItem.unitofmsrdesc)
				}
				newItems.add(discountItem)
			}
		}
	}

	for(int i = 0; i< newItems.size(); i++){
		def lineNo = i + 1
		def noInfo = '<GTD_ITEM_NMBR>'<<lineNo.toString()<<'</GTD_ITEM_NMBR>\n</Item>'
		def nodeContextWithoutLineNo = XmlUtil.serialize(newItems.get(i))
		def nodeContextWithLineNo = nodeContextWithoutLineNo.replaceAll('</Item>', noInfo.toString());
		def nodeWithLineNo = new XmlParser().parseText(nodeContextWithLineNo)
		newItems.set(i, nodeWithLineNo)
	}

	originalItems.each { b ->
		b.parent().remove(b)
	}

	newItems.each { n ->
		rootNode.Invoices.Header.get(0).append(n)
	}
	def newRootNode = XmlUtil.serialize(rootNode)
	//	messageLog.addAttachmentAsString("newRootNode",newRootNode, "text/plain");
	message.setBody(newRootNode)

}