import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String)
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        messageLog.addAttachmentAsString('Product groups to map', body, 'application/json')
    }
    def materialPayload = message.getProperty('originalPayload')
    if (messageLog != null) {
        messageLog.addAttachmentAsString('Products to map', materialPayload, 'application/json')
    }
    return message;
}
