import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.HashSet;
def Message processData(Message message) {
    
    Set<String> sendSet = new HashSet<String>();
    message.setProperty("send", sendSet);
    
    return message;
}