import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Properties 
    map = message.getProperties();
    def sendSet = map.get("send");
    if(sendSet.size() == 0){
        sendSet.add("No");
    }
    message.setProperty("send", sendSet);
    return message;
}