importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
	map = message.getProperties();
	var access_token = map.get("access_token");
	message.setHeader("Authorization", "Bearer "+access_token.toString());
        message.setHeader("Content-Type","application/json");
        message.setBody(map.get("message_body"));
        return message;
}
