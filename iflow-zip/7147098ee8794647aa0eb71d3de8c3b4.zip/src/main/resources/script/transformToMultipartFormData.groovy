import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def map = message.getProperties()
    def schema = map.get("schema")
    def primaryKeys = map.get("primaryKeys")
    def filename = map.get("filename")

    // Modify the message body for CSV line endings
    def body = message.getBody(String).replaceAll("\n", "\r\n")
    def boundary = "--cpi"
    def newline = "\r\n"
    def multipartBody = new StringBuilder()

    // Append schema part
    multipartBody.append(boundary)
        .append(newline)
        .append('Content-Disposition: form-data; name="schema"')
        .append(newline)
        .append(newline)
        .append(schema)
        .append(newline)

    // Append file part with dynamic filename
    multipartBody.append(boundary)
        .append(newline)
        .append("Content-Disposition: form-data; name=\"files\"; filename=\"${filename}\"")
        .append(newline)
        .append('Content-Type: text/csv')
        .append(newline)
        .append(newline)
        .append(body)
        .append(newline)

    // Append primary keys part
    multipartBody.append(boundary)
        .append(newline)
        .append('Content-Disposition: form-data; name="primaryKeys"')
        .append(newline)
        .append(newline)
        .append(primaryKeys)
        .append(newline)
        .append(boundary)
        .append("--")

    message.setBody(multipartBody.toString())
    
    return message
}

/*import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Body 
    def map = message.getProperties();
    def schema = map.get("schema");
    def primaryKeys = map.get("primaryKeys");
    
    // Body 
    def body = message.getBody(String);
    body = body.replaceAll("\n", "\r\n");
    
    // Erstelle den multipart/form-data-Bereich
    def multipartBody = new StringBuilder();
    def boundary = "--cpi";

    // Schema hinzufügen
    multipartBody.append(boundary)
                .append("\r\nContent-Disposition: form-data; name=\"schema\"\r\n\r\n")
                .append(schema)
                .append("\r\n");

    // Datei hinzufügen
    multipartBody.append(boundary)
                .append("\r\nContent-Disposition: form-data; name=\"files\"; filename=\"MedalliaCX.csv\"\r\nContent-Type: text/csv\r\n\r\n")
                .append(body)
                .append("\r\n");

    // PrimaryKeys hinzufügen
    multipartBody.append(boundary)
                .append("\r\nContent-Disposition: form-data; name=\"primaryKeys\"\r\n\r\n")
                .append(primaryKeys)
                .append("\r\n")
                .append(boundary + "--");

    message.setBody(multipartBody.toString());
    return message;
}

*/