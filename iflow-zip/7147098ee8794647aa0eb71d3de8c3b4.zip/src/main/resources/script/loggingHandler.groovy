import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def properties = message.getProperties();
    def loggingEnabled = properties.get("loggingEnabled");
    

    if (loggingEnabled != null && loggingEnabled == "true") {
        def body = message.getBody(java.lang.String);
        def messageLog = messageLogFactory.getMessageLog(message);
        
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Request Message:", body, "text/plain");
        }
    }
    
    return message;
}