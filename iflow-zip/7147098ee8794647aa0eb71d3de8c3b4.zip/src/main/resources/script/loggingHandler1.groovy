import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def properties = message.getProperties();
    def loggingEnabled = properties.get("loggingEnabled");
    

    if (loggingEnabled != null && loggingEnabled == "true") {
        def body = message.getBody(java.lang.String) as String;
        def messageLog = messageLogFactory.getMessageLog(message);
        
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Response Message:", body, "text/plain");
        }
    }
    
    return message;
}