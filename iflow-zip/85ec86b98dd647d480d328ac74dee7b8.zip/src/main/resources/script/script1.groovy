import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.*;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    
    // def body = '{"Code":{"content":"10"},"ISOCode":{"content":"DAY"},"CommercialDescription":[{"languageCode":"HE","value":"DD"},{"languageCode":"SV","value":"CC"}],"TechnicalDescription":[{"languageCode":"HE","value":"dd"},{"languageCode":"SV","value":"ee"}],"LongDescription":[{"languageCode":"HE","value":"ימים"},{"languageCode":"SV","value":"Dagar"},{"languageCode":"AB","value":"Dagar"}],"AllownonwholeIndicator":"true","PreferredMappingIndicator":"false","Category":"1","NumberOfDecimalPlaces":"0"}' as String;
    
    def body = message.getBody(java.lang.String) as String;
    
    def jsonParser = new JsonSlurper()
    def jsonObject = jsonParser.parseText(body);
    
    jsonObject=jsonObject.get("UnitOfMeasurement");
    // println(JsonOutput.toJson(jsonObject));
    // Handling Header Parsing
    def commercials = jsonObject.get("CommercialDescription");
    def technicals = jsonObject.get("TechnicalDescription");
    def longDescriptions = jsonObject.get("LongDescription");
    def langList = [] as LinkedHashSet;
    def uom = [:];
    def uomList = [];
    def mainMap = [:];
    
    def descriptionList = [];
    
    uom.put("code", jsonObject.get("Code").get("content"));
    if(null!=jsonObject.get("ISOCode")){
        uom.put("isoCode", jsonObject.get("ISOCode").get("content"));
    }
    else{
         uom.put("isoCode",null);
    }
   
    if(!(commercials instanceof List)){
        def commercialList = [];
       commercialList.add(commercials);
       commercials=commercialList;
    }
    
    if(!(technicals instanceof List)){
        def technicalList = [];
        technicalList.add(technicals);
        technicals=technicalList;
    }
    
    if(!(longDescriptions instanceof List)){
        def longDescriptionList = [];
        longDescriptionList.add(longDescriptions);
        longDescriptions=longDescriptionList;
    }
    
    for(int i=0;i<commercials.size();i++){
        if(null!= commercials && null!=commercials.get(i)){
            langList.add(commercials.get(i).get("@languageCode"));
        }
    }
    
    for(int i=0;i<technicals.size();i++){
        if(null!= technicals && null!=technicals.get(i)){
            langList.add(technicals.get(i).get("@languageCode"));
        }
    }
    
    for(int i=0;i<longDescriptions.size();i++){
        if(null!=longDescriptions && null!=longDescriptions.get(i)){
            langList.add(longDescriptions.get(i).get("@languageCode"));
        }
    }
    
    for(int i=0;i<langList.size();i++){
       
       def  description = jsonParser.parseText('{}');
       
       description.put("commercialDescription",null);
       description.put("technicalDescription",null);
       description.put("longDescription",null);
       
        def commercial = commercials.find{it.'@languageCode' == langList.getAt(i) };
       def longDesc = longDescriptions.find{it.'@languageCode' == langList.getAt(i) };
       def technical = technicals.find{it.'@languageCode' == langList.getAt(i) };
       if(null!= commercial)
         description.put("commercialDescription",commercial.get("\$"));
        
        if(null!= technical)
         description.put("technicalDescription",technical.get("\$"));
         
         if(null!= longDesc)
          description.put("longDescription",longDesc.get("\$"));
          
          description.put("languageCode",langList.getAt(i));
         descriptionList.add(description); 
   }
   
   for (int i=0; i<descriptionList.size();i++){
        uom = [:];
        uom.put("code", jsonObject.get("Code").get("content"));
        if(null!=jsonObject.get("ISOCode")){
            uom.put("isoCode", jsonObject.get("ISOCode").get("content"));
        }
        else{
            uom.put("isoCode",null);
        }
       uom.put("description", descriptionList.getAt(i));
       uomList.add(uom);
   }
   
   mainMap.put("UnitOfMeasurement", uomList);
   message.setBody(JsonOutput.toJson(mainMap));    
   
   return message;
    
}