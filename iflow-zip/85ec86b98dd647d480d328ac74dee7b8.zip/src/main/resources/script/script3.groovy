import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;


def Message processData(Message message) {	
	def body = message.getBody(java.lang.String) as String;
	def headers = message.getHeaders() as Map<String, Object>;
	def properties = message.getProperties() as Map<String, Object>;
	
	def propertiesAsString ="\n";
	properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };
	
	def enableLog = properties.get("enableLog") as String;
	
	def headersAsString ="\n";
	headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };
	
	if(null!= body && body.contains("failed to respond")){
	    message.setHeader("CamelHttpResponseCode",503);
	}else{
	    message.setHeader("CamelHttpResponseCode",400);
	}
    
	def messageLog = messageLogFactory.getMessageLog(message);
    def payload = properties.get("CurrentPayload") as String;
    if(enableLog==true && messageLog != null){
		messageLog.addAttachmentAsString("Error Message",   "\n Properties \n ----------   \n" + propertiesAsString +
                                                            "\n Headers \n ----------   \n" + headersAsString +
		                                                    "\n Body \n ----------  \n\n" + body +
		                                                    "\n CurrentPayload \n ----------  \n\n" + payload,
	 	                                                    "text/xml");
	}
	
	
	
	return message;
}