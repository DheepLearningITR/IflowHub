import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message readPayload(Message message) {
    def body = message.getBody(java.lang.String);
    def messageLog = messageLogFactory.getMessageLog(message);
    def runMode = message.getHeaders().get("runMode")
    def jsonparse;
    
    try{
        jsonparse = new JsonSlurper().parseText(body);
        
        //set custom header
        jsonparse.data.each{
            if(it.value != '' && it.value != null){
                try{
                    messageLog.addCustomHeaderProperty(it.key, it.value);
                }
                catch(Exception e){
                }
            }
        }
    }
    catch(Exception e){
        messageLog.addCustomHeaderProperty("Error", "Unexpected Payload from SAP Event Mesh");
        messageLog.addCustomHeaderProperty("Error Type", runMode);
        message.setProperty("Error", "Unexpected Payload from SAP Event Mesh");
        message.setProperty("ErrorType", runMode);
    }
    
    messageLog.addCustomHeaderProperty("Run Mode", runMode);
    return message;
}

def Message prettyprintPayload(Message message) {
    def payload = message.getProperties().get("payload");
    
    if(payload != '' && payload != null){
        def jsonparse = new JsonSlurper().parseText(payload);
        def result = new JsonBuilder(jsonparse).toPrettyString();
        message.setBody(result);
        message.setProperty("payload", result);
    }

    return message;
}

