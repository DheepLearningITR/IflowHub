import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.transform.Field;
import com.sap.it.api.msglog.MessageLog;
import groovy.xml.*;
import groovy.json.*;

@Field static final String CONNECTION_ERROR = "503";
@Field static final String BAD_GATEWAY = "502";
@Field static final String TIMEOUT_ERROR = "408";
@Field static final String CERTIFICATE_ERROR = "sun.security.validator.ValidatorException: PKIX path building failed";

def RetryCheck (String retrycount, String counter)
{
    boolean output = false
    int Retrycount = retrycount as Integer
    int Counter = counter as Integer

    if(retrycount != 0)
    {
       if(Retrycount < Counter)
       {
          output = true; 
       }
    }
    else{
        if(Counter >= 1)
       {
          output = true; 
       }
    }
    return output
}

def Message processData(Message message) {
    
    def mapProperties = message.getProperties();
    def mapheaders= message.getHeaders();
  
    String retrycount = mapheaders.get("SAPJMSRetries") ?: '0'
    String Counter = mapProperties.get("RetryCount") ?: '0'
  
    final messageLog = messageLogFactory.getMessageLog(message);
    Exception exception = mapProperties.get("CamelExceptionCaught");
  
    boolean isRetryMessage = false;
    boolean isSendDeadQ = false;
    
    if(exception.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException"))
    {
        if (exception.getMessage().contains(CONNECTION_ERROR)) {
          isRetryMessage=RetryCheck(retrycount, Counter)
        }
        if (exception.getMessage().contains(TIMEOUT_ERROR)) {
          isRetryMessage=RetryCheck(retrycount, Counter)
        }
        if (exception.getMessage().contains(CERTIFICATE_ERROR)) {
          isRetryMessage=RetryCheck(retrycount, Counter)
        }
        if (exception.getMessage().contains(BAD_GATEWAY)) {
          isRetryMessage=RetryCheck(retrycount, Counter)
        }
        isSendDeadQ = true
        messageLog.setStringProperty("The exception message is", exception.getMessage());
        message.setProperty("Error", exception.getMessage() + "\n" + exception.getResponseBody());
        message.setProperty("ErrorType", "Target System Processing");
        messageLog.addCustomHeaderProperty("Error", exception.getMessage() + " " + exception.getResponseBody());
        messageLog.addCustomHeaderProperty("Error Type", "Target System Processing");
    }
    else if(exception.getClass().getCanonicalName().equals("com.sap.esb.camel.error.handler.ErrorEventException"))
    {	
        if(mapheaders.get("errorAuthFlag") == 'X' && mapheaders.get("errorBJ") == 'X'){
            if (mapProperties.get("custErr").contains(CONNECTION_ERROR)) {
              isRetryMessage=RetryCheck(retrycount, Counter)
            }
            if (mapProperties.get("custErr").contains(TIMEOUT_ERROR)) {
              isRetryMessage=RetryCheck(retrycount, Counter)
            }
            if (mapProperties.get("custErr").contains(CERTIFICATE_ERROR)) {
              isRetryMessage=RetryCheck(retrycount, Counter)
            }
            if (mapProperties.get("custErr").contains(BAD_GATEWAY)) {
              isRetryMessage=RetryCheck(retrycount, Counter)
            }
            message.setProperty("Error", mapProperties.get("custErr") + "\n" + mapheaders.get("errorTxt"));
            messageLog.addCustomHeaderProperty("Error", mapProperties.get("custErr") + " " + mapheaders.get("errorTxt"));
            
            isSendDeadQ = true;
        }
        else{
            message.setProperty("Error", mapProperties.get("custErr"));
            messageLog.addCustomHeaderProperty("Error", mapProperties.get("custErr"));
            isSendDeadQ = mapProperties.get("toDeadQ").toBoolean();
        }
        message.setProperty("ErrorType", mapProperties.get("custErrType"));
        messageLog.addCustomHeaderProperty("Error Type", mapProperties.get("custErrType"));
    }
    else{
        messageLog.setStringProperty("The exception message is", exception.getMessage());
        message.setProperty("Error", exception.getMessage());
        message.setProperty("ErrorType", mapProperties.get("exceptionErrorType"));
        messageLog.addCustomHeaderProperty("Error", exception.getMessage());
        messageLog.addCustomHeaderProperty("Error Type", mapProperties.get("exceptionErrorType"));
        isSendDeadQ = true
    }

    message.setProperty("RetryFlag", isRetryMessage);
    message.setProperty("SendDeadQ", isSendDeadQ);
    messageLog.addCustomHeaderProperty("Send to Dead Queue", isSendDeadQ.toString());
    messageLog.setBooleanProperty("The RetryMessage value is", isRetryMessage)
    return message;

}