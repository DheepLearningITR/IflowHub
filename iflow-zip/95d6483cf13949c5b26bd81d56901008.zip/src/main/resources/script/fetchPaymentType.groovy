import com.sap.it.api.mapping.*;



def String fetchPaymentType(String p1, MappingContext context) {
         
         
         if(p1.equals("Invoice"))
         {
             return p1;
         }
         else
         {
         return context.getProperty("paymentMethod");
         }
        
}




