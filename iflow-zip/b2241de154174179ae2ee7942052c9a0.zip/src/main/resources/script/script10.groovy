/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    // Retrieve body that contains encoded values of header and claims.
    def body = message.getBody(java.lang.String) as String;
    
    // Retreive Backup of body
    def mapProperties = message.getProperties();
    def bodyBackup = mapProperties.get("bodyBackup")
    
    // Retreive signed value
    def map = message.getHeaders();
    def signHeader = map.get("CDCRSASignature");
    def signature_str = signHeader.replace('+','-').replace('/','_').replace('\n','').replace('=','').replace('\r','')
    
    message.setHeader("Authorization", "Bearer " + body + "." + signature_str)
    message.setBody(bodyBackup);
       
    return message;
}