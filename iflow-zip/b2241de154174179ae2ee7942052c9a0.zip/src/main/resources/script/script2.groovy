/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    body_str = "";

            
    //Properties 
    map = message.getProperties();
    
    def accType = map.get("accountType")
    
    //Body 
    body_str = "apiKey=" + URLEncoder.encode(map.get("apiKey"), "UTF-8");
    
    def mdmrole = map.get("mdmrole")
    def customerRole = map.get("customerRole")
    def prospectRole = map.get("prospectRole")

    if(mdmrole == customerRole){
        body_str += "&UID=" + URLEncoder.encode(map.get("CDCAccountUid"), "UTF-8");
        body_str += "&include=" + URLEncoder.encode(map.get("include"), "UTF-8");
        body_str += "&extraProfileFields=" + URLEncoder.encode("phones", "UTF-8");    
    }
    else if(mdmrole == prospectRole){
        body_str += "&query=" + URLEncoder.encode("SELECT * FROM accounts WHERE UID='"+map.get("CDCAccountUid")+"'", "UTF-8");
        body_str += "&accountTypes=" + URLEncoder.encode("lite", "UTF-8");    
    }
            
    
    message.setBody(body_str);
       
    return message;
}


