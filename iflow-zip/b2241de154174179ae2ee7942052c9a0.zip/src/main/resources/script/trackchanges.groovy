/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper;
import java.io.StringWriter;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.OutputKeys;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.Gson;

def Message processData(Message message) {
    
    //Body 
   def cdcPayload = message.getBody(java.lang.String);
       
    //Properties 
   map = message.getProperties();
  
   DOMSource source = new DOMSource(map.get("senderPayload"));
   TransformerFactory transFactory = TransformerFactory.newInstance();
   Transformer transformer = transFactory.newTransformer();
   StringWriter buffer = new StringWriter();
   transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
   transformer.transform(source,new StreamResult(buffer));
   
   def cdcData = new XmlSlurper().parseText(cdcPayload);
   def mdmData = new XmlSlurper().parseText(buffer.toString());
   def isRecordModified = false;
   def profileData = new JsonObject();
   
    def VerifyRecord = { CDCAttribute, MDMAttribute, req_attrib ->
    
        // Set profile data only if the data is modified
        if((CDCAttribute.equals(MDMAttribute) ? false : true)){
            
            // Add to profile JsonObject
            profileData.addProperty(req_attrib,MDMAttribute.text());
            
            // Log the modified status
            if(!isRecordModified){
                isRecordModified = true;
            }
        }
    }
    
    // First name
    VerifyRecord(cdcData.firstName,mdmData.Common.Person.Name.GivenName,"firstName");
   
    // Last name
    VerifyRecord(cdcData.lastName,mdmData.Common.Person.Name.FamilyName,"lastName");
   
    // Set Body to modifed profile data
    message.setBody(profileData.toString());

    // Set Modified Status in a property
    message.setProperty("isRecordModified",(isRecordModified));
    
    // to handle in exception
    if(!isRecordModified){
            message.setBody("No modified records found"+ profileData.toString());
    }
 
    return message;
}