
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

    map = message.getProperties();
    map.get("CDCAccountUid")+"'"
    
    //Body 
    def body = message.getBody(java.lang.String);
    
    throw new Exception("Record with CDCAccountUid="+map.get("CDCAccountUid")+" is not modified."+body);  

}