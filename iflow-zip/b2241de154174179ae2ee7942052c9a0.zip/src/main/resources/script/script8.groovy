import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    body_str = "";
    
    // Save current payload for future processing
    message.setProperty("cdcQueryPayload",message.getBody(java.lang.String));
    
    // Header
    message.setHeader("Content-Type", "application/x-www-form-urlencoded");
            
    //Properties 
    map = message.getProperties();
    
    //Body 
    body_str = "apiKey=" + URLEncoder.encode(map.get("apiKey"), "UTF-8");
    
    body_str += "&email=" + URLEncoder.encode(map.get("cdcEmail"), "UTF-8");
    
    message.setBody(body_str);
       
    return message;
}


