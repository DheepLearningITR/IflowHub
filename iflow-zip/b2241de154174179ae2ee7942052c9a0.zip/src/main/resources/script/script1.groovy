import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    body_str = "";

    
    // Header
    message.setHeader("Content-Type", "application/x-www-form-urlencoded");

    
    //Properties 
    map = message.getProperties();
    
    def accType = map.get("accountType")
    
    //Body 
    body_str = "apiKey=" + URLEncoder.encode(map.get("apiKey"), "UTF-8");

    
   body_str += "&UID=" + URLEncoder.encode(map.get("CDCAccountUid").replace("-",""), "UTF-8");
   body_str += "&profile=" + URLEncoder.encode(message.getBody(java.lang.String), "UTF-8");
  
   liteRegToken = map.get("liteRegToken")
   if(liteRegToken){
      body_str += "&regToken=" + URLEncoder.encode(liteRegToken, "UTF-8");
   }
            
    
    message.setBody(body_str);
       
    return message;
}


