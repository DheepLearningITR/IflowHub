import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    def localTimeZone = TimeZone.getTimeZone('America/New_York');
    def cal = Calendar.instance;
    def date = cal.time;
    def dateFormat = "yyyyMMdd"
   
    def value = message.getProperty("xfFileName");
    
    message.setProperty("xfFileName",value+date.format(dateFormat, localTimeZone));
       
      
    return message;
}