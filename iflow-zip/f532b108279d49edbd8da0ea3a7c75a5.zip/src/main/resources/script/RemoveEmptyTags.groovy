/*
This Groovy script processes the XML content of a message in SAP CPI. It performs the following steps:

1. Parses the message body as XML.
2. Iterates through all <value> nodes and checks if both <regardingobjectid_opportunity> and <regardingobjectid_lead> child elements are present and empty (no text and no attributes).
3. Collects and removes <value> nodes where both <regardingobjectid_opportunity> and <regardingobjectid_lead> are empty.
4. Converts the modified XML back to a string.
5. Sets the updated XML as the message body.

This script cleans the XML by removing <value> elements that have both empty <regardingobjectid_opportunity> and <regardingobjectid_lead> tags.
*/


import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def removeNodeIfBothTagsPresent(xml) {
    def root = new XmlParser().parseText(xml)
    
    // Iterate through the value nodes and collect those that need to be removed
    def nodesToRemove = []
    root.'**'.findAll { it.name() == 'value' }.each { valueNode ->
        def opportunityNode = valueNode.regardingobjectid_opportunity
        def leadNode = valueNode.regardingobjectid_lead
        
        // Check if both nodes exist and are empty (no text and no attributes)
        if ((opportunityNode && opportunityNode[0].attributes().isEmpty() && opportunityNode.text().isEmpty()) &&
            (leadNode && leadNode[0].attributes().isEmpty() && leadNode.text().isEmpty())) {
            nodesToRemove << valueNode
        }
    }
    
    // Remove the nodes
    nodesToRemove.each { valueNode ->
        valueNode.parent().remove(valueNode)
    }
    
    return XmlUtil.serialize(root)
}

def Message processData(Message message) {
    def body = message.getBody(String)
    
    // Process the XML to remove the required nodes
    def updatedXml = removeNodeIfBothTagsPresent(body)
    
    // Set the updated XML back to the message body
    message.setBody(updatedXml)
    
    return message
}
