import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper

def Message processData(Message message) {

    def body = message.getBody(String)

    def xmlSlurper = new XmlSlurper()
    def xml = xmlSlurper.parseText(body)

    def hasNextPage = xml.data.products.pageInfo.hasNextPage.toBoolean()

    if (hasNextPage) {
        def endCursor = '"' + xml.data.products.pageInfo.endCursor.text() + '"'
        message.setProperty("lastNode", endCursor)
    } else {
        message.setProperty("hasNextPage", false)
    }

    return message
}
