/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

def Message processData(Message message) {
	
	
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssZ");
	Date date = new Date();
	dateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
	
	//get the clientid  
	def headers = message.getHeaders();
	String clientId = headers.get("client_id");
	String customerId = headers.get("customer_id");
	
	//get the txn and gstin
	properties = message.getProperties();
	String txn = properties.get("txn");
	String gstin = properties.get("gstin");
	String action = properties.get("action");
	String api_action = properties.get("api_action");
	String apiVersion = properties.get("api_version");
	String vayana_auth_token;
	
	StringBuilder sb = new StringBuilder();
	//create the X-Asp-Auth-Token string
	sb.append(apiVersion);
	
	if(customerId == null || customerId.trim().isEmpty()) {
		sb.append("::").append(clientId);
	}
	else {
		sb.append(":").append(customerId).append(":");
	}
	sb.append(":").append(txn).append(":").append(dateFormat.format(date)).append(":").append(gstin);
	if (api_action.equals("DETAILS")) {
		vayana_auth_token = sb.append(":");
	}
	else {
		vayana_auth_token = sb.append(":").append(action);
	}
	
	// set the auth token for Vayana GSP
	message.setProperty("X-Asp-Auth-Token",vayana_auth_token);
	
	//Body 
	def body = message.getBody();
	message.setBody(vayana_auth_token);

	return message;
}

