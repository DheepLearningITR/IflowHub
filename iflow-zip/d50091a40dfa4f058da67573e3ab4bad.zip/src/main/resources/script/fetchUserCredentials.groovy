/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 */
import com.sap.gateway.ip.core.customdev.util.Message;

import java.util.HashMap;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.Key
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import com.sap.it.nm.types.NodeManagerException;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;

import groovy.json.JsonBuilder

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;
import com.sap.it.api.keystore.exception.KeystoreException;
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential

def Message processData(Message message) {

 

    // get the headers
    def headers = message.getHeaders();
    def prop = message.getProperties();
    String gstin = headers.get("gstin");
    String einvgstin = gstin+'_einv';
    //Get the vayana gstin credentials from the keystore
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    boolean evnType = false;
    
    if(service != null)
    {
        try{
            UserCredential userCredential = service.getUserCredential(einvgstin);
            if(userCredential != null) {
               setUserCredentials(message,userCredential);
            }
            else{
                UserCredential userCredential1 = service.getUserCredential(gstin);
                if(userCredential1 != null) {
                    setUserCredentials(message,userCredential1);
                }
                else{
                    evnType = true;
                    throw new NodeManagerException();
                }
            }
        }
        catch(Exception e)
        {
            if(!evnType) {
                UserCredential userCredential1 = service.getUserCredential(gstin);
                if(userCredential1 != null) {
                     setUserCredentials(message,userCredential1);
                }
            }
            else {
                throw new NodeManagerException();
            }
        }
        
       if(headers.get("passwordempty"))  {
            throw new NodeManagerException();
       }
        
    }
    
    return message;
}

def void setUserCredentials(Message message,UserCredential userCredential)
{
   def headers = message.getHeaders();
    message.setProperty("username",userCredential.getUsername());
   
    if(userCredential.getPassword() != null){
    message.setProperty("password",new String((char[])userCredential.getPassword()));
    }
     else{
            headers.put("passwordempty", true);
        }
}


