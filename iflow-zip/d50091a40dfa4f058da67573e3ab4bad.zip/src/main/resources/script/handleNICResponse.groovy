/**
 * This script is used to handle the response received from GSP/GSTN system
 * 
 * Date		  |	Information
 * ------------------------------------------------------------------------ 
 * 13-08-2017 | Initial Version
 */

import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import groovy.xml.MarkupBuilder;
import java.security.NoSuchAlgorithmException

import javax.crypto.Cipher
import javax.crypto.NoSuchPaddingException
import javax.crypto.ShortBufferException
import javax.crypto.spec.SecretKeySpec
import javax.xml.bind.DatatypeConverter

import javax.crypto.Mac;

import java.util.zip.ZipEntry;
import org.apache.commons.compress.compressors.gzip.*;
import org.apache.commons.io.IOUtils;
import org.apache.commons.compress.archivers.tar.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;


def Message processData(Message message) {

	//Body
	def props = message.getProperties();
	def headers = message.getHeaders();

	def body = message.getBody(String.class);
	def jsonSlurper = new JsonSlurper();
	def object = jsonSlurper.parseText(body);
	def jsonString = new JsonBuilder();
	def jsonStr = new JsonBuilder();
	def errorStr = new JsonBuilder();
	def infoStr = new JsonBuilder();
	
	def writer = new StringWriter();
	def markupBuilder = new MarkupBuilder(writer);
	
	message.setHeader("status", object.Status);

	// Form the header and body of the payload based on the api group(api_action) and action
	switch (props.get("api_action")) {
		case "AUTH":
			// for SUCCESS
			if(object.Status.equals(1))
			{
				// for ACCESSTOKEN
				if (props.get("action").equals("ACCESSTOKEN")) {

					String app_key = headers.get("appkey");
					String sek = object.Data.Sek;
					String decsek = symmDecryption(app_key, object.Data.Sek);

					jsonString	status: object.Status,
					authtoken: object.Data.AuthToken,
					sek: decsek

					// Set authtoken and sek to property for further calls
					message.setProperty("authtoken", object.Data.AuthToken);
					message.setProperty("sek", decsek);

					String delimiter = "\$";
					def date = new Date(System.currentTimeMillis()).toString();
					//adding constant of 350 mins as irp is not providing it in response
					String completeToken = date.toString().concat(delimiter).concat(props.get("irp_tokenexpiry")).concat(delimiter).concat(object.Data.AuthToken).concat(delimiter).concat(decsek);
					message.setBody(completeToken);
				}
			}
			else
			{
				message.setProperty("status", object.Status);
				message.setProperty("action","ErrorData");
				
					
					jsonString ErrorDetails: object.ErrorDetails
								
					jsonStr	details: jsonString.getContent();
					message.setBody(jsonStr.toString());
				
			}
			break;
			
		case "EINVOICE":
			// for SUCCESS
			
			if(object.Status.equals(1))
			{
				message.setProperty("status", object.Status);
								
				// for GENEINVOICE
				if (props.get("action").equals("Invoice")) {
				
					String tokensek = props.get("sek");
					String data = new String(symmDecryption(tokensek, object.Data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					message.setProperty("JSONResponse", data);
								
					    								
					message.setProperty("AckNo", actualData.AckNo == null ? "": actualData.AckNo);
					message.setProperty("AckDt", actualData.AckDt == null ? "": actualData.AckDt);
					message.setProperty("Irn", actualData.Irn == null ? "": actualData.Irn);
					message.setProperty("SignedInvoice", actualData.SignedInvoice == null ? "": actualData.SignedInvoice);
					message.setProperty("SignedQRCode",actualData.SignedQRCode == null ? "": actualData.SignedQRCode);
					message.setProperty("Status", actualData.Status == null ? "": actualData.Status);
					message.setProperty("EwbNo", actualData.EwbNo == null ? "": actualData.EwbNo);
					message.setProperty("EwbDt", actualData.EwbDt == null ? "": actualData.EwbDt);
					message.setProperty("EwbValidTill", actualData.EwbValidTill == null ? "": actualData.EwbValidTill);
					message.setProperty("Remarks", actualData.Remarks == null ? "": actualData.Remarks);
					
					message.setBody(data);		



					

					
				}
				
				// for CANEINV
				if (props.get("action").equals("Cancel")) {
				
					String tokensek = props.get("sek");
					String data = new String(symmDecryption(tokensek, object.Data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					message.setProperty("JSONResponse", data);
					
					message.setProperty("Irn", actualData.Irn == null ? "": actualData.Irn);
					message.setProperty("CancelDate", actualData.CancelDate == null ? "": actualData.CancelDate );
				}
				
				if (props.get("action").equals("ewaybill")) {
					
					String tokensek = props.get("sek");
					String data = new String(symmDecryption(tokensek, object.Data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					message.setProperty("JSONResponse", data);
					
					message.setProperty("EwbNo", actualData.EwbNo == null ? "": actualData.EwbNo);
					message.setProperty("EwbDt", actualData.EwbDt == null ? "": actualData.EwbDt);
					message.setProperty("EwbValidTill", actualData.EwbValidTill == null ? "": actualData.EwbValidTill);
					message.setProperty("Remarks", actualData.Remarks == null ? "": actualData.Remarks);
				}
				
				if (props.get("action").equals("CANEWB")) {
					
					message.setProperty("status", object.status);
								
					
					String tokensek = props.get("sek");
					String data = new String(symmDecryption(tokensek, object.data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					message.setProperty("JSONResponse", data);
					
					message.setProperty("EwbNo", actualData.ewayBillNo == null ? "": actualData.ewayBillNo);
					message.setProperty("CancelDate", actualData.cancelDate == null ? "": actualData.cancelDate);
				}				
				
				if(object.InfoDtls != null){
					
						infoStr info : object.InfoDtls;
						JsonSlurper slurper1 = new JsonSlurper()
						Map parsedJson1 = slurper1.parseText(infoStr.toString());
					
					    message.setProperty("INFOCD",parsedJson1.info.InfCd);
					    message.setProperty("DESC",parsedJson1.info.Desc);
					    message.setProperty("InfoLength",(parsedJson1.info).size());
					    
					    for(int i=0;i<(parsedJson1.info).size();i++){
					        
					        markupBuilder.'n0:details'{
								 'n0:InfoDtls'{
								     'n0:InfCd'(parsedJson1.info.InfCd[i])
					        		 'n0:Desc'(parsedJson1.info.Desc[i].toString())
					        			 }
									}
							}
							
						message.setProperty("infoDetails", writer);
					  
					     }
				
			}
			else
			{
				
				message.setProperty("status", object.Status);
				message.setProperty("action","ErrorData");
				//message.setProperty("api_action","ErrorData");
					
					
					
					jsonString ErrorDetails: object.ErrorDetails
					jsonStr	details: jsonString.getContent();
					
					
					//For Handling Invalid Token : Deleting the existing token and setting the XML error message (Without calling the json to XML convertor), so that the next call will have a fresh token generated.
					errorStr error : object.ErrorDetails;
					JsonSlurper slurper = new JsonSlurper()
					Map parsedJson = slurper.parseText(errorStr.toString());
					message.setProperty("invalid_token",parsedJson.error.ErrorCode[0]);
					
					if(message.getProperty("invalid_token").equals("105") || message.getProperty("invalid_token").equals("1005")) {
					
							markupBuilder.'n0:details'{
								 'n0:ErrorDetails'{
								     'n0:ErrorCode'('1005')
					        		 'n0:ErrorMessage'('Invalid Token')
					        			 }
									}
								message.setProperty("eInvoiceDetails", writer);
								message.setProperty("code", "1005");
								message.setProperty("action","ErrorCode"); //The Action is explicitly set to ErrorCode so the the normal flow of JsontoXML does not happen.
						
						}
					
					if(object.InfoDtls != null){
					
						infoStr info : object.InfoDtls;
						JsonSlurper slurper1 = new JsonSlurper()
						Map parsedJson1 = slurper1.parseText(infoStr.toString());
					
					    message.setProperty("INFOCD",parsedJson1.info.InfCd);
					    message.setProperty("DESC",parsedJson1.info.Desc);
					    message.setProperty("InfoLength",(parsedJson1.info).size());
					    
					    for(int i=0;i<(parsedJson1.info).size();i++){
					        
					        markupBuilder.'n0:details'{
								 'n0:InfoDtls'{
								     'n0:InfCd'(parsedJson1.info.InfCd[i])
					        		 'n0:Desc'(parsedJson1.info.Desc[i].toString())
					        			 }
									}
							}
							
						message.setProperty("infoDetails", writer);
					  
					     }

					
					
					message.setBody(jsonStr.toString());
				
					
				
			}
			break;
			
		case "DETAILS":
			// for SUCCESS
			message.setProperty("status", object.Status);
			
			if(object.Status.equals(1)){
				
				// for GetEInvoiceDetails
				if(props.get("action").equals("GetEInvoiceDetails")){
					
					String tokensek = props.get("sek");
					String data = new String(symmDecryption(tokensek, object.Data).decodeBase64());

					def actualData = jsonSlurper.parseText(data);
					jsonString details: actualData
					message.setBody(jsonString.toString());					
				}
				
				// for GetGSTINDetails
				if(props.get("action").equals("GetGSTINDetails")){
					
					message.setProperty("GetGSTINDetails","GetGSTINDetails");
										
					String tokensek = props.get("sek");
					String data = new String(symmDecryption(tokensek, object.Data).decodeBase64());

											
					def actualData = jsonSlurper.parseText(data);
					jsonString details: actualData
					message.setBody(jsonString.toString());					
				}
				
				
				//for SyncGSTINDetails
				if(props.get("action").equals("SyncGSTINDetails")){
					
					String tokensek = props.get("sek");
					String data = new String(symmDecryption(tokensek, object.Data).decodeBase64());

					def actualData = jsonSlurper.parseText(data);
					jsonString details: actualData
					message.setBody(jsonString.toString());					
				}
				
				
				//for GetIRNByDocDetails
				if(props.get("action").equals("GetIRNByDocDetails")){
					
					String tokensek = props.get("sek");
					String data = new String(symmDecryption(tokensek, object.Data).decodeBase64());

					def actualData = jsonSlurper.parseText(data);
					jsonString details: actualData
					message.setBody(jsonString.toString());					
				}
				
				//for GetEWBDetailsByIrn
				if(props.get("action").equals("GetEWBDetailsByIrn")){
					
					String tokensek = props.get("sek");
					String data = new String(symmDecryption(tokensek, object.Data).decodeBase64());

					def actualData = jsonSlurper.parseText(data);
					jsonString details: actualData
					message.setBody(jsonString.toString());					
				}
				
				
				
			}
			else
			{
				
					message.setProperty("status", object.Status);
					message.setProperty("action","ErrorData");
				//message.setProperty("api_action","ErrorData");
					
					
					
					jsonString ErrorDetails: object.ErrorDetails
					jsonStr	details: jsonString.getContent();
					
					
					//For Handling Invalid Token : Deleting the existing token and setting the XML error message (Without calling the json to XML convertor), so that the next call will have a fresh token generated.
					errorStr error : object.ErrorDetails;
					JsonSlurper slurper = new JsonSlurper()
					Map parsedJson = slurper.parseText(errorStr.toString());
					message.setProperty("invalid_token",parsedJson.error.ErrorCode[0]);
					
					if(message.getProperty("invalid_token").equals("105") || message.getProperty("invalid_token").equals("1005")) {
					
							markupBuilder.'n0:details'{
								 'n0:ErrorDetails'{
								     'n0:ErrorCode'('1005')
					        		 'n0:ErrorMessage'('Invalid Token')
					        			 }
									}
								message.setProperty("eInvoiceDetails", writer);
								message.setProperty("code", "1005");
								message.setProperty("action","ErrorCode"); //The Action is explicitly set to ErrorCode so the the normal flow of JsontoXML does not happen.
						
						}
					
						if(object.InfoDtls != null){
					
						infoStr info : object.InfoDtls;
						JsonSlurper slurper1 = new JsonSlurper()
						Map parsedJson1 = slurper1.parseText(infoStr.toString());
					
					    message.setProperty("INFOCD",parsedJson1.info.InfCd);
					    message.setProperty("DESC",parsedJson1.info.Desc);
					    message.setProperty("InfoLength",(parsedJson1.info).size());
					    
					    for(int i=0;i<(parsedJson1.info).size();i++){
					        
					        markupBuilder.'n0:details'{
								 'n0:InfoDtls'{
								     'n0:InfCd'(parsedJson1.info.InfCd[i])
					        		 'n0:Desc'(parsedJson1.info.Desc[i].toString())
					        			 }
									}
							}
							
						message.setProperty("infoDetails", writer);
					  
					     }
					
					message.setBody(jsonStr.toString());
				
				
				
				
				
			}
			
			
			break;
		default:
			break;
	}
	return message;
}

def void setResponseBody(def object, Message message, def error) {
	
	if (object != null) {
		message.setProperty("status", "1");
		message.setProperty("Irn", object.Irn);
		message.setProperty("AckNo", object.AckNo);
		message.setProperty("AckDt", object.AckDt);
		message.setProperty("SignedInvoice", object.SignedInvoice);
		message.setProperty("SignedQRCode", object.SignedQRCode);
		message.setProperty("Status", object.Status);
		message.setProperty("CancelDate", object.CancelDate);
		message.setProperty("EwbNo", object.EwbNo);
		message.setProperty("EwbDt", object.EwbDt);
		message.setProperty("EwbValidTill", object.EwbValidTill);
		}
		
	if (error != null) {
		message.setProperty("status", "0");
		message.setProperty("errorCodes", error.errorCodes);
	}
}

def String symmDecryption(String key, String data){
	//constants
	String AES_TRANSFORMATION = "AES/ECB/PKCS5Padding";
	String AES_ALGORITHM = "AES";
	ENC_BITS = 256;
	Cipher decryptCipher;

	try {
		decryptCipher = Cipher.getInstance(AES_TRANSFORMATION);
	} catch (NoSuchAlgorithmException | NoSuchPaddingException e1) {
		return null;
	}
	SecretKeySpec secreteKey = new SecretKeySpec(key.decodeBase64(), AES_ALGORITHM);
	decryptCipher.init(Cipher.DECRYPT_MODE, secreteKey);

	InputStream instream = new ByteArrayInputStream(DatatypeConverter.parseBase64Binary(data));
	OutputStream outStream = new ByteArrayOutputStream();

	final int cipherBlockSize = decryptCipher.getBlockSize();
	final int outBlockSize = decryptCipher.getOutputSize(cipherBlockSize);

	final byte[] inData = new byte[cipherBlockSize];
	byte[] outData = new byte[outBlockSize];
	int inReadSize = 0;

	try
	{
		while((inReadSize % cipherBlockSize == 0))
		{
			inReadSize = instream.read(inData);
			if(inReadSize == cipherBlockSize)
			{
				try {
					final int encryptedLength = decryptCipher.update(inData, 0, inReadSize,outData);
					outStream.write(outData, 0, encryptedLength);
				} catch (ShortBufferException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return null;
				}

			}
		}

		if(inReadSize > 0)
		{
			outData = decryptCipher.doFinal(inData,0,inReadSize);
		}
		else
		{
			outData = decryptCipher.doFinal();
		}

		outStream.write(outData);
		byte[] decryptedData = ((ByteArrayOutputStream)outStream).toByteArray();
		return decryptedData.encodeBase64().toString();
	}
	finally
	{
		try
		{
			instream.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
		try
		{
			outStream.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
	}
}

def String generateHmac(String key, String data){
	try{
		Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
		SecretKeySpec secret_key = new SecretKeySpec(key.decodeBase64(), "AES");
		sha256_HMAC.init(secret_key);

		String hash = sha256_HMAC.doFinal(data.getBytes()).encodeBase64().toString();
		return hash;
	}catch(Exception e){
		return "";
	}
	
}


