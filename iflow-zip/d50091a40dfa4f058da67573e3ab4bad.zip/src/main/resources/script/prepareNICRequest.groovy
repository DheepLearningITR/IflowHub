import javax.crypto.Cipher

/**
 * This script is used to build the JSON request details 
 * 
 * Date		  |	Information
 * ------------------------------------------------------------------------ 
 * 12-03-2018 | Initial Version
 */

import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

import java.lang.invoke.SwitchPoint;
import java.security.KeyFactory
import java.security.NoSuchAlgorithmException
import java.security.PublicKey
import java.security.cert.X509Certificate
import java.security.spec.X509EncodedKeySpec
import java.security.NoSuchAlgorithmException

import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.SecretKeySpec
import javax.crypto.ShortBufferException
import javax.crypto.NoSuchPaddingException

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;
import com.sap.it.api.keystore.exception.KeystoreException;

import javax.crypto.Mac;

def Message processData(Message message) {

	// get the properties
	def props = message.getProperties();
	// get the headers
	def headers = message.getHeaders();

	StringBuilder sbUrl = new StringBuilder();
	StringBuilder sbQuery = new StringBuilder();
	def jsonString = new JsonBuilder();
	def jsonString1 = new JsonBuilder();
	def data = new JsonBuilder();

	// Form the Payload for IRP Request based on the API_ACTION(e.g. AUTH, EINVOICE, DETAILS etc.) 
	// and ACTION(e.g. ACCESSTOKEN,FORCEREFRESH, GENEINVOICE, CANEINV, etc.)
	
	
	switch (props.get("api_action")) {
		
		case "AUTH":
		//set the required headers for the Authentication request
			message.setHeader("Content-Type","application/json");
			message.setHeader("gstin",props.get("gstin"));
			message.setHeader("GspHttpUrl", sbUrl.append(props.get("irp_einvoice")).append(props.get("irp_auth")));
			

		//set the Payload for the authentication requests
		//for ACCESSTOKEN
			if (props.get("action").equals("ACCESSTOKEN")) {
				//1. Generate a new Application Key(APPKEY)
				byte[] rawAppkey =  generateAppKey();

				//set the appkey in the header so that it can be send back in the response to the ECC application
				//the same appkey must be send in the subsequent request for AUTHTOKEN
				message.setHeader("appkey", rawAppkey.encodeBase64().toString());
				
				def refreshTokenFlag = false;
				if(props.get("forceRefreshToken")) {
				    refreshTokenFlag = true;
				}
								
				//2.Form the JSON Payload
				//jsonString	action	: props.get("action"),
			     jsonString	UserName: props.get("username"),
				Password: props.get("password"),
				AppKey : rawAppkey.encodeBase64().toString(), // Encrypt the application key using the IRP public key
				ForceRefreshAccessToken : refreshTokenFlag
				
				//set the message body
				message.setProperty("authDataJson",jsonString.toString());
				jsonString1 Data : encryptRawData(jsonString.toString().getBytes(), props.get("irppkalias"))
				def req_payload = jsonString1.toString();
				message.setBody(req_payload);
			}
			break;
			
			
		case "EINVOICE":
			//Set the required headers for the IRP post request
			message.setHeader("gstin", props.get("gstin"));
			message.setHeader("AuthToken", props.get("authtoken"));
			message.setHeader("Content-Type","application/json");
			//message.setHeader("GspHttpUrl", sbUrl.append(props.get("irp_einvoice")).append("/").append(props.get("action").trim()));
			message.setHeader("user_name",props.get("username"));
			
			def body = message.getBody(String.class);
			
			// for GENEINVOICE
			if (props.get("action").equals("Invoice")) {
			
				message.setHeader("GspHttpUrl", sbUrl.append(props.get("irp_einvoice")).append(props.get("invoice_path")));
			
				String in_data = body;
				String tokensek = props.get("sek");

				//jsonString	action: props.get("action"),	
				jsonString Data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			
			}
			
			// for CANEINV
			else if (props.get("action").equals("Cancel")) {
			
				message.setHeader("GspHttpUrl", sbUrl.append(props.get("irp_einvoice")).append(props.get("cancel_path")));
			
			
				String in_data = body;
				String tokensek = props.get("sek");

				//jsonString	action: props.get("action"),	
				jsonString Data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				
				}
			
			
			else if (props.get("action").equals("ewaybill"))
			{
    			message.setHeader("GspHttpUrl", sbUrl.append(props.get("irp_einvoice")).append(props.get("gen_ewb_path")));
			
				String in_data = body;
				String tokensek = props.get("sek");

				//jsonString	action: props.get("action"),	
				jsonString Data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			
			}
			
			else if (props.get("action").equals("CANEWB"))
			{
    			message.setHeader("GspHttpUrl", sbUrl.append(props.get("irp_einvoice")).append(props.get("ewb_cancel_path")));
			
				String in_data = body;
				String tokensek = props.get("sek");

				jsonString	action: props.get("action"),	
				Data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			
			}
			
							
			break;

		
		case "DETAILS":
			//Set the required headers for the IRP post request
			message.setHeader("gstin", props.get("gstin"));
			message.setHeader("authtoken", props.get("authtoken"));
			message.setHeader("Content-Type","application/json");
			message.setHeader("user_name",props.get("username"));
						
						
			// for GetEInvoiceDetails
			if (props.get("action").equals("GetEInvoiceDetails")) {
			
		    	message.setHeader("GspHttpUrl", sbUrl.append(props.get("irp_einvoice")).append(props.get("getIrn_path")).append(props.get("Irn")));
		    	//message.setHeader("GspHttpQuery", sbQuery.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("Irn=").append(props.get("Irn")));
			    message.setHeader("CamelHttpMethod", "GET");
			    
			   
			}
						
			if (props.get("action").equals("GetEWBDetailsByIrn")) {
			
		    	message.setHeader("GspHttpUrl", sbUrl.append(props.get("irp_einvoice")).append(props.get("getEWBfromIrn_path")).append(props.get("Irn")));
		    	//message.setHeader("GspHttpQuery", sbQuery.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("irn=").append(props.get("Irn")));
			    message.setHeader("CamelHttpMethod", "GET");
			    			   
			}
						
			// for GetGSTINDetails
			if (props.get("action").equals("GetGSTINDetails")) {
			
		    	message.setHeader("GspHttpUrl", sbUrl.append(props.get("irp_einvoice")).append(props.get("getGSTIN_path")).append(props.get("gstin")));
		    	//message.setHeader("GspHttpQuery", sbQuery.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("gstin=").append(props.get("gstin")));
		    	message.setHeader("CamelHttpMethod", "GET");
			    			   
			}
			
			//for SyncGSTINDetails
			if (props.get("action").equals("SyncGSTINDetails")) {
			
		    	message.setHeader("GspHttpUrl", sbUrl.append(props.get("irp_einvoice")).append(props.get("syncGSTIN_path")).append(props.get("syncReqGSTIN")));
		    	//message.setHeader("GspHttpQuery", sbQuery.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("gstin=").append(props.get("syncReqGSTIN")));
			    message.setHeader("CamelHttpMethod", "GET");
			    
			 }
			
			
			if (props.get("action").equals("GetIRNByDocDetails")) {
			
		    	message.setHeader("GspHttpUrl", sbUrl.append(props.get("irp_einvoice")).append(props.get("getIRNByDoc_path")));
		    	message.setHeader("GspHttpQuery", sbQuery.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("doctype=").append(props.get("doctype")).append("&docnum=").append(props.get("docnum")).append("&docdate=").append(props.get("docdate")));
			    message.setHeader("CamelHttpMethod", "GET");
			   			   
			}
			
			
			
			break;
		
		default:
			break;
	}

	// set the current timestamp as the REQUEST timestamp
	def currentDate = new Date();
	message.setHeader("GSP_LAST_TIMESTAMP", currentDate);
	message.setHeader("GSP_REQ_TIMESTAMP", currentDate);
	return message;
}


def String generateHmac(byte[] key, String data){
	try{
		Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
		SecretKeySpec secret_key = new SecretKeySpec(key, "AES");
		sha256_HMAC.init(secret_key);

		String hash = sha256_HMAC.doFinal(data.getBytes()).encodeBase64().toString();
		return hash;
	}catch(Exception e){
		return "";
	}
}

def String encryptRawData(byte[] rawAppKey, String irppkalias){
	/* ASYMMETRIC ENCRYPTION */
	// get the IRP public key from the JAVA keystore
	def service = ITApiFactory.getApi(KeystoreService.class, null);
	PublicKey pk;
	byte[] keydata;

	if(service != null)
	{
		// here it reads the certificate with alias irpcert.
		// the IRP public key must be deployed in the cloud integration tenants keystore with alias name as irpcert
		X509Certificate certificate = service.getCertificate(irppkalias);
		if(certificate != null)
		{
			pk = certificate.getPublicKey();
			String encoded  = pk.getEncoded().encodeBase64().toString();
			keydata = encoded.decodeBase64();
		}
	}

	// encrypt the raw appkey using the IRP public key from keystore
	Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	PublicKey pubKey = KeyFactory.getInstance("RSA")
			.generatePublic(new X509EncodedKeySpec(keydata));
	cipher.init(Cipher.ENCRYPT_MODE, pubKey);
	byte[] encryptedByte= cipher.doFinal(Base64.getEncoder().encodeToString(rawAppKey).getBytes());
	return encryptedByte.encodeBase64().toString();
}

def byte[] generateAppKey(){
	//constants
	String AES_TRANSFORMATION = "AES/ECB/PKCS5Padding";
	String AES_ALGORITHM = "AES";
	ENC_BITS = 256;
	KeyGenerator keyGenerator = null;

	try {
		keyGenerator = KeyGenerator.getInstance(AES_ALGORITHM);
		keyGenerator.init(ENC_BITS);
	}
	catch (NoSuchAlgorithmException e) {
		e.printStackTrace();
	}

	SecretKey appkey = keyGenerator.generateKey();
	return appkey.getEncoded();
}

def String symmEncryption(String key, String data){
	//constants
	String AES_TRANSFORMATION = "AES/ECB/PKCS5Padding";
	String AES_ALGORITHM = "AES";
	ENC_BITS = 256;
	Cipher encryptCipher;

	try {
		encryptCipher = Cipher.getInstance(AES_TRANSFORMATION);
	} catch (NoSuchAlgorithmException | NoSuchPaddingException e1) {
		return null;
	}
	SecretKeySpec secreteKey = new SecretKeySpec(key.decodeBase64(), AES_ALGORITHM);
	encryptCipher.init(Cipher.ENCRYPT_MODE, secreteKey);

	InputStream instream = new ByteArrayInputStream(data.getBytes());
	OutputStream outStream = new ByteArrayOutputStream();

	final int cipherBlockSize = encryptCipher.getBlockSize();
	final int outBlockSize = encryptCipher.getOutputSize(cipherBlockSize);

	final byte[] inData = new byte[cipherBlockSize];
	byte[] outData = new byte[outBlockSize];
	int inReadSize = 0;

	try
	{
		while((inReadSize % cipherBlockSize == 0))
		{
			inReadSize = instream.read(inData);
			if(inReadSize == cipherBlockSize)
			{
				try {
					final int encryptedLength = encryptCipher.update(inData, 0, inReadSize,outData);
					outStream.write(outData, 0, encryptedLength);
				} catch (ShortBufferException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return null;
				}

			}
		}

		if(inReadSize > 0)
		{
			outData = encryptCipher.doFinal(inData,0,inReadSize);
		}
		else
		{
			outData = encryptCipher.doFinal();
		}

		outStream.write(outData);
		byte[] encryptedData = ((ByteArrayOutputStream)outStream).toByteArray();
		return encryptedData.encodeBase64().toString();
	}
	finally
	{
		try
		{
			instream.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
		try
		{
			outStream.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
	}
}
