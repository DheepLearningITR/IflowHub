import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {	
	
	def body = message.getBody(String.class);
	def dateExpiryTokenSek = body.split('\\$');
	
//Calculate the expiry date and time
	def expiry = new Date().parse('EEE MMM dd HH:mm:ss z yyyy', dateExpiryTokenSek[0]);
    expiry.setTime(expiry.getTime() + (Integer.parseInt(dateExpiryTokenSek[1]) * 60 * 1000));  	
	def currentdate = new Date();
	
	def datediff = new Date();
	datediff.setTime(expiry.getTime()-600000);// currently IRP expects forceRefreshToken to be true for API calls that are 10 mins before Token expiry.
			
//set indicator to start new flow to fetch new token	
	if(currentdate > expiry){
		message.setHeader("refresh", "X");
	}
	else if (currentdate >= datediff && currentdate <= expiry){
	  
		message.setHeader("refresh", "X");
	    message.setProperty("forceRefreshToken" , true);             
	}
	else {
		message.setProperty("authtoken", dateExpiryTokenSek[2]);
		message.setProperty("sek", dateExpiryTokenSek[3]);
	}
	return message;
}

