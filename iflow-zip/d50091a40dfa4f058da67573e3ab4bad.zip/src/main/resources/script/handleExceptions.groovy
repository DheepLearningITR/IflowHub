/**
 * This script is used to handle the exceptions raised at any of the steps 
 * 
 * Change Details
 * 
 * Date		  |	Information
 * ------------------------------------------------------------------------ 
 * 13-08-2017 | Initial Version
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
	def map = message.getHeaders();
	def map1 = message.getProperties();
	def ex = map1.get("CamelExceptionCaught");
	def jsonString = new JsonBuilder();
	def writer = new StringWriter();
   
    
	map.put("Content-Type",   "application/json");
	map.put("CamelHttpResponseCode",   200);
	
	def markupBuilder = new MarkupBuilder(writer);

	if (ex!=null) {

		if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
			message.setProperty("status", "0");
			
			markupBuilder.'n0:details'{
			 'n0:ErrorDetails'{
			     'n0:ErrorCode'('502')
        		 'n0:ErrorMessage'(ex.toString())
        		 }
			}
			message.setProperty("eInvoiceDetails", writer);
			
		} 
		
		else if (ex.getClass().getCanonicalName().equals("com.sap.esb.datastore.MessageNotFoundException")) {
			message.setHeader("AUTH", "X");
		}
		 
		else if(ex.toString().contains("javax.net.ssl.SSLHandshakeException")){ 
			message.setProperty("status", "0");
			
			markupBuilder.'n0:details'{
			 'n0:ErrorDetails'{
			   	 'n0:ErrorCode'('503')
        		 'n0:ErrorMessage'('Missing SSL Certificate or incorrect URLs in IFLOW cnfg')
			}
			}
			message.setProperty("eInvoiceDetails", writer);
			
		}
		
		
		
		else if(ex.toString().contains("java.lang.IllegalStateException")){ 
			message.setProperty("status", "0");
			
			markupBuilder.'n0:details'{
			 'n0:ErrorDetails'{
			   	 'n0:ErrorCode'('506')
        		 'n0:ErrorMessage'('The Keypair in the keystore does not match with the respective alias name in the IFLOW configuration')
			}
			}
			message.setProperty("eInvoiceDetails", writer);
			
		}
		
		
		else if(ex.getClass().getCanonicalName().equals("java.net.UnknownHostException")){
			message.setProperty("status", "0");
			
			markupBuilder.'n0:details'{
			 'n0:ErrorDetails'{
			   	 'n0:ErrorCode'('504')
        		 'n0:ErrorMessage'('Incorrect GSP URLs in the IFLOW configuration')
			}
			}
			message.setProperty("eInvoiceDetails", writer);
				
		}
		
		else {
			if(ex.toString().contains("B.clone()")){
				message.setProperty("status", "0");
				markupBuilder.'n0:details'{
			 'n0:ErrorDetails'{
			   	 'n0:ErrorCode'('505')
        		 'n0:ErrorMessage'('IRP/GSP public key in the keystore does not match with the respective alias name in the IFLOW confiuration')
			}
			}
			message.setProperty("eInvoiceDetails", writer);
				
						
			}
			else if (ex.toString().contains("com.sap.it.nm.types.NodeManagerException")) {
				message.setProperty("status", "0");
				
				
				if(map.get("passwordempty")){
				    
            			markupBuilder.'n0:details'{
            			 'n0:ErrorDetails'{
            			   	 'n0:ErrorCode'('501')
                    		 'n0:ErrorMessage'('Password is empty for the GSTIN User Credential')
            			}
            			}
            				    
				}
				
				else{	
					markupBuilder.'n0:details'{
					'n0:ErrorDetails'{
					'n0:ErrorCode'('501')
					'n0:ErrorMessage'('User Credentials for GSTIN not deployed in SCPI')
						}
					}
			
				}
			
			message.setProperty("eInvoiceDetails", writer);
				
			}
			
			
			else if(ex.toString().contains("com.sap.it.api.securestore.exception.SecureStoreException")){
			
				message.setProperty("status", "0");	
				if(map1.get("actualAction").equals("SyncGSTINDetails") || map1.get("actualAction").equals("GetGSTINDetails")){
					
				    if(map.get("gstinempty")){
						markupBuilder.'n0:details'{
							 'n0:ErrorDetails'{
            			   	 'n0:ErrorCode'('507')
                    		 'n0:ErrorMessage'('Maintain a valid GSTIN for external parameter field userGSTIN_publicAPI in the Integration flow.')
            				}
            			}
					}
					else{
						markupBuilder.'n0:details'{
							 'n0:ErrorDetails'{
            			   	 'n0:ErrorCode'('507')
                    		 'n0:ErrorMessage'('Add the user GSTIN credentials for the external parameter field userGSTIN_publicAPI under Security material in the Integration tenant.')
            				}
            			}
					
					}
					
					
				}
				
				else{
					markupBuilder.'n0:details'{
							 'n0:ErrorDetails'{
            			   	 'n0:ErrorCode'('507')
                    		 'n0:ErrorMessage'('Add the user GSTIN credentials under Security material in the Integration tenant.')
            				}
            			}
				
				}
				message.setProperty("eInvoiceDetails", writer);
			}
			
			else {
				message.setProperty("status", "0");
				markupBuilder.'n0:details'{
				 'n0:ErrorDetails'{
			   	 'n0:ErrorCode'('500')
        		 'n0:ErrorMessage'(ex.toString())
				}
			}
			message.setProperty("eInvoiceDetails", writer);
				
			}			
		}
	}

	return message;
}



	