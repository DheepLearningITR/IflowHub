import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

	// get the headers
	def headers = message.getHeaders();
	def props = message.getProperties();
	// get the request body
	def body = message.getBody(String.class);
	def jsonSlurper = new JsonSlurper();
	def object = jsonSlurper.parseText(body);
	def newBody;
	
	// set default properties from headers
	message.setProperty("action", headers.get("action"));
	message.setProperty("txn", headers.get("txn"));
	message.setProperty("gstin", headers.get("gstin"));
	
	
	// Read the Payload from ECC based on ACTION(e.g. ACCESSTOKEN, GENEINVOICE, CANEINV etc.)
	switch (headers.get("action")) {
		case "Invoice":
			message.setProperty("api_action", "EINVOICE");
			newBody = setValuesToIntFromStr(object.submitDocumentRequest.docData);
			break;
		
		case "Cancel":
			message.setProperty("api_action", "EINVOICE");
			newBody = object.cancelDocRequest.cancelRequest;
			break;
		
		case "ewaybill":
			message.setProperty("api_action", "EINVOICE");
			newBody = setValuesToInt(object.generateEWBRequest.generateEwb);
			break;
			
		case "GetEInvoiceDetails":
			message.setProperty("Irn", headers.get("Irn"));
			message.setProperty("api_action", "DETAILS");
			break;
			
		case "GetEWBDetailsByIrn":
			message.setProperty("Irn", headers.get("Irn"));
			message.setProperty("api_action", "DETAILS");
			break;	
				
		case "CANEWB":
			message.setProperty("api_action", "EINVOICE");
			newBody = setValuestoNumber(object.cancelEWBRequest.cancelEWB);
			break;
			
		case "GetGSTINDetails":
			message.setProperty("Irn", headers.get("Irn"));
			message.setProperty("getGSTIN",headers.get("getGSTIN"));
			headers.put("gstin", props.get("userGSTIN"));
			message.setProperty("gstin", headers.get("gstin"));
			message.setProperty("api_action", "DETAILS");
			break;
			
		case "SyncGSTINDetails":
			message.setProperty("Irn", headers.get("Irn"));
			message.setProperty("getGSTIN",headers.get("getGSTIN"));
			headers.put("gstin", props.get("userGSTIN"));
			message.setProperty("gstin", headers.get("gstin"));
			message.setProperty("api_action", "DETAILS");
			break;
			
		case "GetIRNByDocDetails":
			message.setProperty("doctype",headers.get("doctype"));
			message.setProperty("docnum",headers.get("docnum"));
			message.setProperty("docdate",headers.get("docdate"));
			message.setProperty("api_action", "DETAILS");
			break;	
				
		default:
			newBody = headers.get("action");
			break;
	}
	message.setBody(JsonOutput.toJson(newBody));
	return message;
}

// method to set all string values to int
static Object setValuesToIntFromStr(Object newBody){

	def jsonSlurper = new JsonSlurper();

 
if(newBody.SellerDtls != null){

    if(newBody.SellerDtls.Pin != null && newBody.SellerDtls.Pin != "")
		newBody.SellerDtls.Pin = convertToInt(newBody.SellerDtls.Pin);
 }
 
 if(newBody.BuyerDtls != null){

    if(newBody.BuyerDtls.Pin != null && newBody.BuyerDtls.Pin != "")
		newBody.BuyerDtls.Pin = convertToInt(newBody.BuyerDtls.Pin);
 }
 
 if(newBody.DispDtls != null){

    if(newBody.DispDtls.Pin != null && newBody.DispDtls.Pin != "")
		newBody.DispDtls.Pin = convertToInt(newBody.DispDtls.Pin);
 }
 
 if(newBody.ShipDtls != null){

    if(newBody.ShipDtls.Pin != null && newBody.ShipDtls.Pin != "")
		newBody.ShipDtls.Pin = convertToInt(newBody.ShipDtls.Pin);
 }
 
 
if(newBody.ValDtls != null){


  	if(newBody.ValDtls.AssVal != null && newBody.ValDtls.AssVal != "")
		newBody.ValDtls.AssVal = convertToDecimal(newBody.ValDtls.AssVal);
		
	if(newBody.ValDtls.CgstVal != null && newBody.ValDtls.CgstVal != "")
		newBody.ValDtls.CgstVal = convertToDecimal(newBody.ValDtls.CgstVal);
		
	if(newBody.ValDtls.SgstVal != null && newBody.ValDtls.SgstVal != "")
		newBody.ValDtls.SgstVal = convertToDecimal(newBody.ValDtls.SgstVal);
		
	if(newBody.ValDtls.IgstVal != null && newBody.ValDtls.IgstVal != "")
		newBody.ValDtls.IgstVal = convertToDecimal(newBody.ValDtls.IgstVal);
		
	if(newBody.ValDtls.CesVal != null && newBody.ValDtls.CesVal != "")
		newBody.ValDtls.CesVal = convertToDecimal(newBody.ValDtls.CesVal);
		
	if(newBody.ValDtls.StCesVal != null && newBody.ValDtls.StCesVal != "")
		newBody.ValDtls.StCesVal = convertToDecimal(newBody.ValDtls.StCesVal);
				
	if(newBody.ValDtls.Discount != null && newBody.ValDtls.Discount != "")
		newBody.ValDtls.Discount = convertToDecimal(newBody.ValDtls.Discount);
		
	if(newBody.ValDtls.OthChrg != null && newBody.ValDtls.OthChrg != "")
		newBody.ValDtls.OthChrg = convertToDecimal(newBody.ValDtls.OthChrg);
			
	if(newBody.ValDtls.RndOffAmt != null && newBody.ValDtls.RndOffAmt != "")
		newBody.ValDtls.RndOffAmt = convertToDecimal(newBody.ValDtls.RndOffAmt);
			
	if(newBody.ValDtls.TotInvVal != null && newBody.ValDtls.TotInvVal != "")
		newBody.ValDtls.TotInvVal = convertToDecimal(newBody.ValDtls.TotInvVal);
	
	if(newBody.ValDtls.TotInvValFc != null && newBody.ValDtls.TotInvValFc != "")
		newBody.ValDtls.TotInvValFc = convertToDecimal(newBody.ValDtls.TotInvValFc);
	}
	
if(newBody.PayDtls != null){

   	if(newBody.PayDtls.CrDay != null && newBody.PayDtls.CrDay != "")
		  newBody.PayDtls.CrDay = convertToInt(newBody.PayDtls.CrDay);
	if(newBody.PayDtls.PaidAmt != null && newBody.PayDtls.PaidAmt != "")
		  newBody.PayDtls.PaidAmt = convertToDecimal(newBody.PayDtls.PaidAmt);
	if(newBody.PayDtls.PaymtDue != null && newBody.PayDtls.PaymtDue != "")
		  newBody.PayDtls.PaymtDue = convertToDecimal(newBody.PayDtls.PaymtDue);
		
}

if(newBody.ExpDtls != null){

   	if(newBody.ExpDtls.ExpDuty != null && newBody.ExpDtls.ExpDuty != "")
		  newBody.ExpDtls.ExpDuty = convertToDecimal(newBody.ExpDtls.ExpDuty);
}

if(newBody.EwbDtls != null){

   	if(newBody.EwbDtls.Distance != null && newBody.EwbDtls.Distance != "")
		  newBody.EwbDtls.Distance = convertToInt(newBody.EwbDtls.Distance);
}

 
if(newBody.ItemList != null){
	for(int i=0;i<(newBody.ItemList).size();i++)
	{
    
   		 if(newBody.ItemList[i].Qty != null && newBody.ItemList[i].Qty != "")
			newBody.ItemList[i].Qty = convertToDecimal(newBody.ItemList[i].Qty);
		
		if(newBody.ItemList[i].FreeQty != null && newBody.ItemList[i].FreeQty != "")
			newBody.ItemList[i].FreeQty = convertToDecimal(newBody.ItemList[i].FreeQty);
		    
    	if(newBody.ItemList[i].UnitPrice != null && newBody.ItemList[i].UnitPrice != "")
			newBody.ItemList[i].UnitPrice = convertToDecimal(newBody.ItemList[i].UnitPrice);
		
		if(newBody.ItemList[i].TotAmt != null && newBody.ItemList[i].TotAmt != "")
			newBody.ItemList[i].TotAmt = convertToDecimal(newBody.ItemList[i].TotAmt);
		
		if(newBody.ItemList[i].Discount != null && newBody.ItemList[i].Discount != "")
			newBody.ItemList[i].Discount = convertToDecimal(newBody.ItemList[i].Discount);
				
		if(newBody.ItemList[i].PreTaxVal != null && newBody.ItemList[i].PreTaxVal != "")
			newBody.ItemList[i].PreTaxVal = convertToDecimal(newBody.ItemList[i].PreTaxVal);
		
		if(newBody.ItemList[i].AssAmt != null && newBody.ItemList[i].AssAmt != "")
			newBody.ItemList[i].AssAmt = convertToDecimal(newBody.ItemList[i].AssAmt);
				
		if(newBody.ItemList[i].GstRt != null && newBody.ItemList[i].GstRt != "")
			newBody.ItemList[i].GstRt = convertToDecimal(newBody.ItemList[i].GstRt);
		
		if(newBody.ItemList[i].IgstAmt != null && newBody.ItemList[i].IgstAmt != "")
			newBody.ItemList[i].IgstAmt = convertToDecimal(newBody.ItemList[i].IgstAmt);
		
		if(newBody.ItemList[i].CgstAmt != null && newBody.ItemList[i].CgstAmt != "")
			newBody.ItemList[i].CgstAmt = convertToDecimal(newBody.ItemList[i].CgstAmt);
		
		if(newBody.ItemList[i].SgstAmt != null && newBody.ItemList[i].SgstAmt != "")
			newBody.ItemList[i].SgstAmt = convertToDecimal(newBody.ItemList[i].SgstAmt);
		
		if(newBody.ItemList[i].CesRt != null && newBody.ItemList[i].CesRt != "")	
			newBody.ItemList[i].CesRt = convertToDecimal(newBody.ItemList[i].CesRt);
		
		if(newBody.ItemList[i].CesAmt != null && newBody.ItemList[i].CesAmt != "")	
			newBody.ItemList[i].CesAmt = convertToDecimal(newBody.ItemList[i].CesAmt);
		
		if(newBody.ItemList[i].CesNonAdvlAmt != null && newBody.ItemList[i].CesNonAdvlAmt != "")	
			newBody.ItemList[i].CesNonAdvlAmt = convertToDecimal(newBody.ItemList[i].CesNonAdvlAmt);
				
		if(newBody.ItemList[i].StateCesRt != null && newBody.ItemList[i].StateCesRt != "")	
			newBody.ItemList[i].StateCesRt = convertToDecimal(newBody.ItemList[i].StateCesRt);
		
		if(newBody.ItemList[i].StateCesAmt != null && newBody.ItemList[i].StateCesAmt != "")	
			newBody.ItemList[i].StateCesAmt = convertToDecimal(newBody.ItemList[i].StateCesAmt);
		
		if(newBody.ItemList[i].StateCesNonAdvlAmt != null && newBody.ItemList[i].StateCesNonAdvlAmt != "")	
			newBody.ItemList[i].StateCesNonAdvlAmt = convertToDecimal(newBody.ItemList[i].StateCesNonAdvlAmt);
				
		if(newBody.ItemList[i].OthChrg != null && newBody.ItemList[i].OthChrg != "")	
			newBody.ItemList[i].OthChrg = convertToDecimal(newBody.ItemList[i].OthChrg);
		
		if(newBody.ItemList[i].TotItemVal != null && newBody.ItemList[i].TotItemVal != "")	
			newBody.ItemList[i].TotItemVal = convertToDecimal(newBody.ItemList[i].TotItemVal);
					
	}
	
}
	
	newBody = denull(newBody);
			
	return newBody;
}

static Object setValuesToInt(Object newBody){

if(newBody.Distance!= null && newBody.Distance != "")
		newBody.Distance = convertToInt(newBody.Distance);
		

if(newBody.ExpShipDtls != null){

    	if(newBody.ExpShipDtls.Pin != null && newBody.ExpShipDtls.Pin != "")
			newBody.ExpShipDtls.Pin = convertToInt(newBody.ExpShipDtls.Pin);
 	}			
		
	newBody = denull(newBody);
			
	return newBody;
}


static Object setValuestoNumber(Object newBody){

if(newBody.ewbNo!= null && newBody.ewbNo != "")
		newBody.ewbNo = convertToLongInt(newBody.ewbNo);
//if(newBody.cancelRsnCode!= null && newBody.cancelRsnCode != "")
	//	newBody.cancelRsnCode = convertToInt(newBody.cancelRsnCode);
						
	newBody = denull(newBody);
			
	return newBody;
}



static Object convertToInt(Object inputValue){
	
		if(inputValue.isNumber()){
			return inputValue.toInteger();
		}else{
			return inputValue;
		}
	
}

static Object convertToInt64(Object inputValue){
	
		if(inputValue.isNumber()){
			return Integer.parseInt(inputValue,64);
		}else{
			return inputValue;
		}
	
}

static Object convertToDecimal(Object inputValue){

	if (inputValue != null)
	return Double.parseDouble(inputValue.toString());
	
}


static Object convertToLongInt(Object inputValue){
     if(inputValue != null)
     return  Long.valueOf(inputValue);             
                  
}


static Object denull(Object obj) {
  if(obj instanceof Map) {
    return obj.collectEntries {k, v ->
      if(v != null && v != "") [(k): denull(v)] else [:]
    }
  } else if(obj instanceof List) {
      return  obj.collect { denull(it) }.findAll { it != null }
  } else {
      return obj;
  }
}