import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.util.XmlSlurper

def Message processData(Message message) {

	def props = message.getProperties();
	// get the request body
	def body = message.getBody(String.class);
	def newBody;
	
	// Read the Payload from ECC based on ACTION(e.g. ACCESSTOKEN, GENEINVOICE,CANEINVOICE,GetEInvoiceDetails)
	switch (message.getProperty("action")) {
		case "GetEInvoiceDetails":
		    message.setProperty("Irn", props.get("Irn"));
			message.setProperty("api_action", "DETAILS");
			message.setProperty("irnDetails", body);
			break;
		
		case "GetGSTINDetails":
		    message.setProperty("Irn", props.get("Irn"));
			message.setProperty("api_action", "DETAILS");
			message.setProperty("gstinDetails", body);
			break;
				
			
		case "SyncGSTINDetails":
		    message.setProperty("Irn", props.get("Irn"));
			message.setProperty("api_action", "DETAILS");
			message.setProperty("gstinDetails", body);
			break;		
		
		case "GetIRNByDocDetails":
		    message.setProperty("Irn", props.get("Irn"));
			message.setProperty("api_action", "DETAILS");
			message.setProperty("irnDetails", body);
			break;
			
		case "GetEWBDetailsByIrn":
		    message.setProperty("Irn", props.get("Irn"));
			message.setProperty("api_action", "DETAILS");
			message.setProperty("irnDetails", body);
			break;	
		
		case "ErrorData":
			message.setProperty("api_action", "ErrorData");
			message.setProperty("eInvoiceDetails", body);
			break;
		
		default:
			newBody = message.getProperty("action");
			break;
	}
	message.setBody(JsonOutput.toJson(newBody));
	return message;
}

