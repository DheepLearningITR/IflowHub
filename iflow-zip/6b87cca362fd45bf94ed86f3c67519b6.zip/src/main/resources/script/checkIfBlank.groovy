import com.sap.it.api.mapping.*;

def String checkIfBlank(String message, String id){

    if(message != null && !message.isEmpty()){
        	return message;
    }
    return "Payment request "+id+" was reversed.";
 
}