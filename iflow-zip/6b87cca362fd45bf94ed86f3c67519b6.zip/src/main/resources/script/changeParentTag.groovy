import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
       def map = message.getProperties();
       def value = map.get("Function");
       def mBody = message.getBody();

       
       if(value == 'RL'){
           mBody = mBody.replaceAll("releasePayment","processPayment");
       }else if(value == 'PO'){
           mBody = mBody.replaceAll("postPayment","processPayment");
       }else{
           mBody = mBody.replaceAll("reversePayment","processPayment");
       }
       
       
       message.setBody(mBody);
       return message;
}