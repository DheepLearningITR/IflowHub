/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Calendar.*;
import groovy.xml.*;
import com.sap.it.api.ITApiFactory; 
import com.sap.it.api.securestore.SecureStoreService; 
import com.sap.it.api.securestore.UserCredential; 
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import groovy.json.JsonSlurper;


def Message LogResult(Message message) {
    def map = message.getProperties();
    def value = map.get("ConversationId") as String;
    def log = map.get("EnableLog") as String;
    def body = message.getBody(java.lang.String) as String;
    
	def messageLog = messageLogFactory.getMessageLog(message);
     
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body);

    if(object.ResultCode == "30000"){ 
        message.setProperty("edoc_status",'01'); 
        if( log == 'X')
        {messageLog.addAttachmentAsString(value+'_success_reponse', body, "text/xml");}
    } 
    else{ message.setProperty("edoc_status",'02');
       if( log == 'X')
       {messageLog.addAttachmentAsString(value+'_failed_reponse', body, "text/xml");}
    }
     
    message.setProperty("ResultCode",object.ResultCode);
    message.setProperty("ResultMessage",object.ResultMessage);
    return message;
}

def Message LogRequest(Message message) {
    def map = message.getProperties();
    def value = map.get("ConversationId");
    def log = map.get("EnableLog") as String;
    def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null && log == 'X')
	{messageLog.addAttachmentAsString(value+'_request', body, "text/xml"); }
     
    return message;
}

def Message SetProperty(Message message) {
    
       //Properties 
       def map = message.getProperties();
       def messageLog = messageLogFactory.getMessageLog(message);
       def value = map.get("ConversationId");
       def log = map.get("EnableLog") as String;
       
       //Set MessageId
       def pool = ['a'..'z','A'..'Z',0..9,'-'].flatten()
       def Random rand = new Random(System.currentTimeMillis())
       def RandomChars = (0..35).collect { pool[rand.nextInt(pool.size())] }
       def MessageID = RandomChars.join()
       message.setProperty("MessageId", MessageID);
       
       //Set Timestamp
       def now = new Date()
       message.setProperty("Timestamp", now.format("yyyyMMddHHmmss", TimeZone.getTimeZone('Asia/Seoul'))); 
       
       //Set Sender/Receiver
       def body = message.getBody(java.lang.String) as String;       
       def send = map.get("SendComRegno");
       def rec = map.get("ReceiveComRegno");
       def TaxInvoice = new XmlSlurper().parseText(body);
       def Sender = TaxInvoice.TaxInvoiceTradeSettlement.InvoiceeParty.ID;
       def Receiver = TaxInvoice.TaxInvoiceTradeSettlement.InvoicerParty.ID;
       message.setProperty("SendComRegno", Sender);
       message.setProperty("ReceiveComRegno", Receiver);
       
       
       //*Add leading zero for TaxRegistritionId, eg:1--->0001
       def TaxRegistritionId_initial = TaxInvoice.TaxInvoiceTradeSettlement.InvoiceeParty.SpecifiedOrganization.TaxRegistrationID as String;
       def TaxRegistritionId = TaxInvoice.TaxInvoiceTradeSettlement.InvoiceeParty.SpecifiedOrganization.TaxRegistrationID as String;    
       if(TaxRegistritionId.length() < 4){
           (4 - TaxRegistritionId.length()).times
           {
               TaxInvoice.TaxInvoiceTradeSettlement.InvoiceeParty.SpecifiedOrganization.TaxRegistrationID.replaceBody('0'+TaxRegistritionId);
               TaxRegistritionId = TaxInvoice.TaxInvoiceTradeSettlement.InvoiceeParty.SpecifiedOrganization.TaxRegistrationID as String;
           };
       };
       
       def TaxRegistritionId_initial_s = TaxInvoice.TaxInvoiceTradeSettlement.InvoicerParty.SpecifiedOrganization.TaxRegistrationID as String;
       def TaxRegistritionId_s  = TaxInvoice.TaxInvoiceTradeSettlement.InvoicerParty.SpecifiedOrganization.TaxRegistrationID as String;    
       if(TaxRegistritionId_s.length() < 4){
           (4 - TaxRegistritionId_s.length()).times
           {
               TaxInvoice.TaxInvoiceTradeSettlement.InvoicerParty.SpecifiedOrganization.TaxRegistrationID.replaceBody('0'+TaxRegistritionId_s);
               TaxRegistritionId_s = TaxInvoice.TaxInvoiceTradeSettlement.InvoicerParty.SpecifiedOrganization.TaxRegistrationID as String;
           };
       };
      
       //AuthToken maintained in Security Material with name like "edoc_kr_smartbill_token_1234567890"
       def service = ITApiFactory.getApi(SecureStoreService.class, null); 
       def CredentialName = "edoc_kr_smartbill_token_"+Sender;
       def credential = service.getUserCredential(CredentialName); 
       if (credential == null){ throw new IllegalStateException("No credential found for alias" + CredentialName); }
       String token = new String(credential.getPassword()); 
       message.setProperty("AuthToken", token);
       
       /*CertPassword => Encrypt with AES/CBC/PKCS#5    
         AES key saved in Security Material with name "edoc_kr_smartbill_AESkey"
       */
       def AEScredential = service.getUserCredential("edoc_kr_smartbill_AESkey"); 
       if (AEScredential == null){ throw new IllegalStateException("No credential found for alias 'edoc_kr_smartbill_AESkey'"); }
       String AESkey = new String(AEScredential.getPassword()); 
       //certpassword maintained in Security Material with name like "edoc_kr_smartbill_certpassword_1234567890"
       def CertpasswordName = "edoc_kr_smartbill_certpassword_"+Sender;
       def certpassword = service.getUserCredential(CertpasswordName); 
       if (certpassword == null){ throw new IllegalStateException("No credential found for alias " + CertpasswordName); }
       String text = new String(certpassword.getPassword()); 
       
       Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
       byte[] keyBytes= new byte[16];
       byte[] b= AESkey.getBytes("UTF-8");
       int len= b.length;
       if (len > keyBytes.length) len = keyBytes.length;
       System.arraycopy(b, 0, keyBytes, 0, len);
       SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
       IvParameterSpec ivSpec = new IvParameterSpec(keyBytes);
       cipher.init(Cipher.ENCRYPT_MODE,keySpec,ivSpec);
       byte[] results = cipher.doFinal(text.getBytes("UTF-8"));
       def encoded = results.encodeBase64().toString()
       message.setProperty("CertPassword", encoded);
       
       def serialize_body = XmlUtil.serialize(body);
       def escape_quot_body =  serialize_body.replaceAll("\"","\'");
       def escape_n_body = escape_quot_body.replaceAll("\n","");
       def add_leading_zero_body = escape_n_body.replaceAll("<TaxRegistrationID>"+TaxRegistritionId_initial+"</TaxRegistrationID>","<TaxRegistrationID>"+TaxRegistritionId+"</TaxRegistrationID>"); 
       def add_leading_zero_body_s = add_leading_zero_body.replaceAll("<TaxRegistrationID>"+TaxRegistritionId_initial_s+"</TaxRegistrationID>","<TaxRegistrationID>"+TaxRegistritionId_s+"</TaxRegistrationID>"); 
       message.setBody(add_leading_zero_body_s);
       
       if(log == 'X')
       {messageLog.addAttachmentAsString(value+'_send2smartbill_xml', add_leading_zero_body, "text/xml");}
       
       return message;
       
}
