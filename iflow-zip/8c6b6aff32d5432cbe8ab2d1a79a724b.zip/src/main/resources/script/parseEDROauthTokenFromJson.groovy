import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
def Message processData(Message message) {

 	def body = message.getBody(java.lang.String) as String
    
    def continueRetry = false
	def tokenResponseBody = ''
	
    if(body != null && body != ''){
        tokenResponseBody = new JsonSlurper().parseText(body)
        def authCode = tokenResponseBody.'authorization'
        if (authCode != '') {
            message.setHeader('Authorization', authCode)
        }
        else {
            throw new EDRNotFoundException('EDR token could not be read from json!')
        }
    }else {
            throw new EDRNotFoundException('EDR token could not be read from json!')
    }
    
    return message
}

class EDRNotFoundException extends Exception {
  EDRNotFoundException(String errorText){
      super(errorText)
  }
}