import com.sap.it.api.mapping.*;

def String getSDDocumentRelatedObjectType(String arg1, MappingContext context) {
  return context.getProperty("P_SDDocumentRelatedObjectType")
}

def String trimString(String input, int length) {
  // Check if the string length is greater than 35
  if (input.length() > length) {
    // Return the first 35 characters of the string
    return input.substring(0, length);
  } else {
    // Return the original string if its length is 35 or less
    return input;
  }
}