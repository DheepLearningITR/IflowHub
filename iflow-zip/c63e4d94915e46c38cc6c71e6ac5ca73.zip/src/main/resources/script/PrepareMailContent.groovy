/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import javax.xml.bind.DatatypeConverter;
//import org.apache.camel.impl.DefaultAttachment;
import javax.mail.util.ByteArrayDataSource;
import org.apache.commons.codec.binary.Base64;
import com.sap.gateway.ip.core.customdev.util.AttachmentWrapper;

def Message processData(Message message) {
    
   def props = message.getProperties();
    
   def body = message.getBody(String.class); // this value is used for the CSV file
   byte[] bytes = body.decodeBase64();
   def content = bytes.toString();
   def dataSource = new ByteArrayDataSource(bytes, 'application/zip');
   //  Construct a DefaultAttachment object
  //  def attachment = new DefaultAttachment(dataSource);
  
     def attachment = new AttachmentWrapper(dataSource);
    //    Add the attachment to the message
    message.addAttachmentObject(props.get("fileName"), attachment);
    
    
    return message;
}













