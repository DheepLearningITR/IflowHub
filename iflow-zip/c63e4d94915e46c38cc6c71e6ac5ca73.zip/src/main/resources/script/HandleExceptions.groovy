/**
 * This script is used to handle the exceptions raised at any of the steps 
 * 
 * Change Details
 * 
 * Date		  |	Information
 * ------------------------------------------------------------------------ 
 * 13-08-2017 | Initial Version
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder

def Message processData(Message message) {
	def map = message.getHeaders();
	def map1 = message.getProperties();
	def ex = map1.get("CamelExceptionCaught");
	def jsonString = new JsonBuilder();
	def errorString = new JsonBuilder();

	map.put("Content-Type",   "application/json");
	map.put("CamelHttpResponseCode",   200);

	if (ex!=null) {

	    if(ex.getClass().getCanonicalName().equals("javax.mail.AuthenticationFailedException")){ 
		
			jsonString	code    : "NOTIF-0002",
			            description : "Wrong Credentials",
			            status	: "FAILED"
			
			
			//set the message body
			def req_payload = jsonString.toString();
			message.setBody(req_payload);
		
		}else if(ex.getClass().getCanonicalName().equals("com.sun.mail.util.MailConnectException")){
		
			
			jsonString	code    : "NOTIF-0002",
			            description : "Connection to server failed. Check the Configuration",
			            status	: "FAILED"
			//set the message body
			def req_payload = jsonString.toString();
			message.setBody(req_payload);
		
		}else if (ex.toString().contains("com.sap.it.nm.types.NodeManagerException")) {
		    
		    
		    if(map.get("mailempty")){
		        
		        jsonString	code    : "NOTIF-0002",
			            description : "Test mail id is not configured in the external parameter",
			            status	: "FAILED"
			
		    	//set the message body
		    	def req_payload = jsonString.toString();
		    	message.setBody(req_payload);
		    }
	    	
	    	else{
	        	jsonString	code    : "NOTIF-0003",
			            description : "TO and CC mail ids are empty",
			            status	: "FAILED"
			
			    //set the message body
		    	def req_payload = jsonString.toString();
			    message.setBody(req_payload);
	    	}
		}
			
		else{
		    
		    jsonString	code    : "NOTIF-0003",
			            description : ex.toString(),
			            status	: "FAILED"
			
			//set the message body
			def req_payload = jsonString.toString();
			message.setBody(req_payload);
		}


	}else{
		def aMultilineString = """{
				\"code\":\"NOTIF-0002\",
				\"description\"	:\"GSP Integration failed.\",
				\"status\":\"FAILED\"
				}
				}""";
		message.setBody(aMultilineString);
	}

	return message;
}