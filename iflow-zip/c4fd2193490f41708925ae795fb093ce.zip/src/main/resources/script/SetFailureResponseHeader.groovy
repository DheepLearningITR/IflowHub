import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Properties
    def properties = message.getProperties();
    value = properties.get("Failure CamelHttpResponseCode");
    message.setHeader("CamelHttpResponseCode", value);
    return message;
}
