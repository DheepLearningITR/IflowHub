import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlParser;
import java.util.*;
def Message processData(Message message) {

//Retrieve response Body from ODATA service.
      def response = message.getBody(java.lang.String) as String ;
      def root = new XmlParser().parseText(response);
      def i=0;
      def allmessage=[];
      def flag = 'false';

// Retrieve statusCode value and putting into an array.
      root.'**'.findAll { it.name() == 'statusCode'}.each { a ->allmessage << a.text()};

//Finding length of the array.
      int len = allmessage.size();
      
//Looping an array.
      while(i<allmessage.size())
                {
//Set the flag if any value start with other than 2.
         if(!(allmessage[i].startsWith("2"))){
         flag = 'true';
         break;
         }
         i++;
         }

// Set the header value if status code starts with other than 2 then send error message.
      if (flag == 'true'){

                 throw new Exception("Received error status code in the response body.");

      }

      return message;
}
