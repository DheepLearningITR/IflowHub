import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData_S4_Confirm_S4_structure(Message message) {
	def map = message.getProperties();
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
	def body = message.getBody(java.lang.String) as String;
 	def rcCustomerId = map.get("CustomerNumber");
    def rcContactId = map.get("ContactNumber");
    def s4CustomerId = map.get("S4CustomerID");
    def s4ContactId = map.get("S4ContactID");
	def messageLog = messageLogFactory.getMessageLog(message);
	if (messageLog != null) {
			messageLog.addAttachmentAsString("SBRelationship(" + rcCustomerId + "_" + rcContactId + ")_S4(" + s4CustomerId + "_" + s4ContactId + ")_confirm_S4_structure", body, "text/xml");
		}
	}
	return message;
}

def Message processData_S4_Confirm_Failed(Message message) {
    def map = message.getProperties();
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
    def body = message.getBody(java.lang.String) as String;
    def rcCustomerId = map.get("CustomerNumber");
    def rcContactId = map.get("ContactNumber");
    def s4CustomerId = map.get("S4CustomerID");
    def s4ContactId = map.get("S4ContactID");
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
            messageLog.addAttachmentAsString("SBRelationship(" + rcCustomerId + "_" + rcContactId + ")_S4(" + s4CustomerId + "_"+s4ContactId + ")_confirm_failed_S4_structure", body, "text/xml");
        }
    }
    return message;
}

def Message processData_S4_Confirm_RC_structure(Message message) {
	def map = message.getProperties();
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {    
    def body = message.getBody(java.lang.String) as String;
    def rcCustomerId = map.get("CustomerNumber");
    def rcContactId = map.get("ContactNumber");
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
            messageLog.addAttachmentAsString("SBRelationship(" + rcCustomerId + "_" + rcContactId + ")_confirm_SB_structure", body, "text/json");
        }
    }
    return message;
}