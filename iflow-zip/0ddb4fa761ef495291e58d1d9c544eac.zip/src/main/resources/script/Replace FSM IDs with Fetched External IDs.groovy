import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.util.XmlParser;

def Message processData(Message message) {
    
       def response = message.getBody(String.class);
       def payload = message.getProperty('InPayload')

       def root = new XmlParser().parseText(payload);
        def resp_obj = new JsonSlurper().parseText(response);
        def id_map = [:]
        // Loop over response and form a Map of ID and ExternalID pair
        resp_obj.data.each{
        	id_map.put(it.values().id[0], it.values().externalId[0])
        }
        // Loop over ObjectPicker nodes and replace ID with External ID
        root.fsm_body.data.checklistInstance.values.ObjectPicker.each{
            //no ExternalID then pass FSM ID suffix with [C4C_ID_NOT_EXIST]
	        it.value = id_map[it.text()] ?: it.text() + '[C4C_ID_NOT_EXIST]'
        }
        // Set the updated XML to the body for next step of transformation
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(root)
        message.setBody(stringWriter.toString())
        return message;
}