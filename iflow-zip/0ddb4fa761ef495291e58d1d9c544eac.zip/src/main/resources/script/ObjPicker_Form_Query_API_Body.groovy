import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlParser;

def Message processData(Message message) {
     //Get Body and parse it.
       def root = new XmlParser().parseText(message.getBody(String.class));

        String query
        String queryStart = '{\"query\":'
        String whereIn //  "(";
        String s = '\'';
        String e = '\',';
        String whereInend = '\')';
        String queryEnd = '\"}';
        String var_s, var_dtos
        String OBJECT_ITEM = 'OBJECT-ITEM', OBJECT_BP = 'OBJECT-BUSINESSPARTNER', OBJECT_EQUIP = 'OBJECT-EQUIPMENT', OBJECT_CONTACT = 'OBJECT-CONTACT', OBJECT_PERSON = 'OBJECT-PERSON', OBJECT_ADDRESS = 'OBJECT-ADDRESS';
        
        root.fsm_body.data.checklistInstance.values.'*'.findAll{node ->
        	((node.name()?.toUpperCase() == OBJECT_ITEM || node.name()?.toUpperCase() == OBJECT_BP || node.name()?.toUpperCase() == OBJECT_EQUIP
        		|| node.name()?.toUpperCase() == OBJECT_CONTACT || node.name()?.toUpperCase() == OBJECT_PERSON || node.name()?.toUpperCase() == OBJECT_ADDRESS)
        		&& node.text().size() == 0)}.each{
        	//Remove object picker nodes in which no values have been selected. Such nodes are generated when
        	// checklist is submitted on Microsoft mobile app
        	it.parent().remove(it)
        }

        root.fsm_body.data.checklistInstance.values.'*'.findAll{node -> node.name()?.toUpperCase() == OBJECT_BP}.each{
        	var_s = it.text().toString().substring(6,42).replaceAll('-','')  // fetching id from value cloud(F89FDD95-A434-41BA-8274-EF5B5E488888)
        	whereIn = whereIn == null ? s + var_s + whereInend : s + var_s + e + whereIn
        	//Create a node with Generic name (ObjectPicker) and having key (Checklist Element ID) and Objects' externalId
        	root.fsm_body.data.checklistInstance.values[0].append(new NodeBuilder().ObjectPicker(key:it.@key,seriesIndex:it.@seriesIndex,var_s))
        }
        if(whereIn != null){
        	query = "\"SELECT b.id, b.externalId FROM BusinessPartner b WHERE b.id IN (" + whereIn
        	whereIn = null
        	var_dtos = "BusinessPartner.20"
        }
        
        root.fsm_body.data.checklistInstance.values.'*'.findAll{node -> node.name()?.toUpperCase() == OBJECT_EQUIP}.each{
        	var_s = it.text().toString().substring(6,42).replaceAll('-','')
        	whereIn = whereIn == null ? s + var_s + whereInend : s + var_s + e + whereIn
        	root.fsm_body.data.checklistInstance.values[0].append(new NodeBuilder().ObjectPicker(key:it.@key,seriesIndex:it.@seriesIndex,var_s))
        }
        if(whereIn != null){
        	if(query == null){
        		query = "\"SELECT e.id, e.externalId FROM Equipment e WHERE e.id IN (" + whereIn
        	}
        	else{
        		query = query + ' UNION ' + "SELECT e.id, e.externalId FROM Equipment e WHERE e.id IN (" + whereIn
        	}
        	whereIn = null
        	var_dtos = var_dtos == null? "Equipment.18" : var_dtos + ";Equipment.18"
        }
        
        root.fsm_body.data.checklistInstance.values.'*'.findAll{node -> node.name()?.toUpperCase() == OBJECT_ITEM}.each{
        	var_s = it.text().toString().substring(6,42).replaceAll('-','')
        	whereIn = whereIn == null ? s + var_s + whereInend : s + var_s + e + whereIn
        	root.fsm_body.data.checklistInstance.values[0].append(new NodeBuilder().ObjectPicker(key:it.@key,seriesIndex:it.@seriesIndex,var_s))
        }
        if(whereIn != null){
        	if(query == null){
        		query = "\"SELECT i.id, i.externalId FROM Item i WHERE i.id IN (" + whereIn
        	}
        	else{
        		query = query + ' UNION ' + "SELECT i.id, i.externalId FROM Item i WHERE i.id IN (" + whereIn
        	}
        	whereIn = null
        	var_dtos = var_dtos == null? "Item.21" : var_dtos + ";Item.21"
        }
        
       root.fsm_body.data.checklistInstance.values.'*'.findAll{node -> node.name()?.toUpperCase() == OBJECT_CONTACT}.each{
        	var_s = it.text().toString().substring(6,42).replaceAll('-','')
        	whereIn = whereIn == null ? s + var_s + whereInend : s + var_s + e + whereIn
        	root.fsm_body.data.checklistInstance.values[0].append(new NodeBuilder().ObjectPicker(key:it.@key,seriesIndex:it.@seriesIndex,var_s))
        }
        if(whereIn != null){
        	if(query == null){
        		query = "\"SELECT c.id, c.externalId FROM Contact c WHERE c.id IN (" + whereIn
        	}
        	else{
        		query = query + ' UNION ' + "SELECT c.id, c.externalId FROM Contact c WHERE c.id IN (" + whereIn
        	}
        	whereIn = null
        	var_dtos = var_dtos == null? "Contact.16" : var_dtos + ";Contact.16"
        }
        
        root.fsm_body.data.checklistInstance.values.'*'.findAll{node -> node.name()?.toUpperCase() == OBJECT_PERSON}.each{
        	var_s = it.text().toString().substring(6,42).replaceAll('-','')
        	whereIn = whereIn == null ? s + var_s + whereInend : s + var_s + e + whereIn
        	root.fsm_body.data.checklistInstance.values[0].append(new NodeBuilder().ObjectPicker(key:it.@key,seriesIndex:it.@seriesIndex,var_s))
        }
        if(whereIn != null){
        	if(query == null){
        		query = "\"SELECT p.id, p.externalId FROM UnifiedPerson p WHERE p.id IN (" + whereIn
        	}
        	else{
        		query = query + ' UNION ' + "SELECT p.id, p.externalId FROM UnifiedPerson p WHERE p.id IN (" + whereIn
        	}
        	whereIn = null
        	var_dtos = var_dtos == null? "UnifiedPerson.8" : var_dtos + ";UnifiedPerson.8"
        }
        
       root.fsm_body.data.checklistInstance.values.'*'.findAll{node -> node.name()?.toUpperCase() == OBJECT_ADDRESS}.each{
        	var_s = it.text().toString().substring(6,42).replaceAll('-','')
        	whereIn = whereIn == null ? s + var_s + whereInend : s + var_s + e + whereIn
        	root.fsm_body.data.checklistInstance.values[0].append(new NodeBuilder().ObjectPicker(key:it.@key,seriesIndex:it.@seriesIndex,var_s))
        }
        if(whereIn != null){
        	if(query == null){
        		query = "\"SELECT a.id, a.externalId FROM Address a WHERE a.id IN (" + whereIn
        	}
        	else{
        		query = query + ' UNION ' + "SELECT a.id, a.externalId FROM Address a WHERE a.id IN (" + whereIn
        	}
        	whereIn = null
        	var_dtos = var_dtos == null? "Address.18" : var_dtos + ";Address.18"
        }
        
        if(query != null){
        	query = queryStart + query + queryEnd
        	// Temporarily store modified inbound payload as property 
        	StringWriter stringWriter = new StringWriter()
            XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
            nodePrinter.setPreserveWhitespace(true)
            nodePrinter.print(root)
            message.setProperty("InPayload",stringWriter.toString());
            // Set the query in the message body  
            message.setBody(query);
            //Set the FSM DTOs to be queried
        	message.setProperty("P_DTOS",var_dtos);
        }
        else{
            message.setProperty("P_DTOS","");
        }
       
       return message;
}