import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def root = new XmlParser().parseText(message.getBody(String.class));

    def root_output = new NodeBuilder()."n0:ChecklistInstanceReplicationRequest"('xmlns:n0': 'http://sap.com/xi/SAPGlobal20/Global'){
    	MessageHeader{
    	    ID(root.fsm_header."x-request-id".text().toUpperCase())
    		UUID(root.fsm_header."x-message-id".text())
    		CreationDateTime(root.fsm_body.eventTime.text())
    		SenderParty{
    			InternalID(schemeID:'CommunicationSystemID',schemeAgencyID:'310',root.fsm_header."x-company-id".text())
    		}
    		RecipientParty{
    			InternalID(schemeID:'CommunicationSystemID',schemeAgencyID:'310',root.fsm_header.C4C_tenant_ID.text())
    		}
    		BusinessScope{
    			TypeCode(listID:'25201',listAgencyID:'310',"3")
    			ID(schemeID:'10555',schemeAgencyID:'310',"106")
    		}
    	}
    	ChecklistInstanceReplicationRequest{
    		BasicMessageHeader{
    			UUID(root.fsm_body.eventID.text())
    		}
    		ChecklistInstance(ActionCode:'04'){
    			ExternalID(root.fsm_body.data.checklistInstance.id.text())
    			TemplateID(root.fsm_body.data.checklistInstance.template.externalId.text())
    			LanguageCode(root.fsm_body.data.checklistInstance.language.text().toUpperCase())
    			PartyID(root.fsm_body.data.checklistInstance.responsiblePerson.externalId.text())
        		BTDReference(ActionCode:'04'){
    				BusinessTransactionDocumentRelationshipRoleCode('1') // Ticket is predecessor
    				BusinessSystemID(root.fsm_header."x-company-id".text())
    				BTDReference{
    					ID('DUMMY_VALUE') //Getting determined in C4C, sending as 1:1 cardinality
    					TypeCode('118')
    					ItemUUID(root.fsm_body.data.checklistInstance.object.objectId.externalId.text())
    					ItemTypeCode('271')
    				}
    			}			
    		}
    	}
    }

    def pos_node, v_trow, value, v_s_idx
    String[] S_array

    //Loop over all the Values
    root.fsm_body.data.checklistInstance.values.'*'.each{
    	
    	if (it.name() in ['string', 'number', 'datetime', 'date', 'time', 'bool', 'ObjectPicker']){
    		S_array = it.@key.split("\\.")
    		v_trow = it.@tRow ?: ""
    		v_s_idx = it.@seriesIndex ?: ""
    		value = it.text()?.trim()?.length()>255 ? it.text()?.trim()?.substring(0,255) : it.text()?.trim()
    		
    		pos_node = new NodeBuilder().Position(ActionCode:'04'){
    			ElementID(S_array[S_array.size() - 2])
    			SeriesIndex(v_s_idx)
    			TableRow(v_trow)
    			ValueText(value)
    		}
    		
    		root_output.ChecklistInstanceReplicationRequest.ChecklistInstance[0].append(pos_node)
    	}
    }

        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(root_output)
        message.setBody(stringWriter.toString())
        return message;
}