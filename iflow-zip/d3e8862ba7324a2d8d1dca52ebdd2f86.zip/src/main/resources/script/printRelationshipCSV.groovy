import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
   
    
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties() as Map<String, Object>;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null && properties.get("ReplicateBusinessPartnerStatus").equals("approved")) {
             messageLog.addAttachmentAsString("Organizations to Customers - CSV" ,body, "text/csv");
       
    }
    
    
    return message;
}