import com.sap.it.api.mapping.*;

def String verifyRoleID(String roleID, MappingContext context){
    	def externalisedRoleID =  context.getProperty('RoleID');
    	if (roleID.equals(externalisedRoleID)){
    	    return 'true'
    	}
    	return 'false';

	
}