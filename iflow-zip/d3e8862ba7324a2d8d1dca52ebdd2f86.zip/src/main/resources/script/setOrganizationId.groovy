import com.sap.it.api.mapping.*;

def String setOrganizationId(String ID, MappingContext context){
    context.setProperty("OrganizationID", ID)
	return ID; 
}