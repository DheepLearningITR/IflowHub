import com.sap.it.api.mapping.*;
import java.util.HashMap;
import groovy.json.JsonSlurper;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String getRequesterInfo(String property, String Id, MappingContext context){
    def body = context.getProperty("ContactPersonData");
    def object = new JsonSlurper().parseText(body);
    def relationship = context.getProperty("BusinessPartnerRelationship")
    String returnVal = '';
    def relObject = new JsonSlurper().parseText(relationship);
       def relation = relObject.root.Relationships.Relation;
       String setPropertyFlag = 'false';
       //def setOrgId = map.get("OrganizationID");
       def contacts = object.Relationships.ContactPersonData;
       if(contacts instanceof java.util.ArrayList){
        for(def contact : contacts){
            def ID = contact.ContactPersonID;
            def OrganizationID = contact.OrganizationID;
            if(relation instanceof java.util.ArrayList){
                for( def rel : relation){
                    if(ID.equals(rel.UID) && OrganizationID.equals(rel.BPID) && ID.equals(Id)){
                        setPropertyFlag = 'true'
                        break;
                    }
               
                }
            }else{
                if(ID.equals(relation.get("UID")) && OrganizationID.equals(relation.get("BPID")) && ID.equals(Id)){
                    setPropertyFlag = 'true'
                    
                }
            }
          if(setPropertyFlag.equals('true')){
              if(property.equals('Email'))
              returnVal = contact.Email
              else if(property.equals('contactPersonID'))
              returnVal = contact.ContactPersonID
              else if(property.equals('department'))
              retrunVal = contact.department;
              else if(property.equals('jobFunction'))
              returnVal = contact.jobFunction;
              else if(property.equals('phone'))
              returnVal = contact.phone;
              else
              returnVal = contact.ID;
            setPropertyFlag = 'false'
         }
      }
    }else{
        def OrganizationID = contacts.OrganizationID;
        def ID = contacts.ContactPersonID;
        if(relation instanceof java.util.ArrayList){
            
        
            for( def rel : relation){
                if(ID.equals(rel.UID) && OrganizationID.equals(rel.BPID) && ID.equals(Id)){
                    setPropertyFlag = 'true'
                    break;
                }
               
            }
        }else{
            if(ID.equals(relation.get("UID")) && OrganizationID.equals(relation.get("BPID")) && ID.equals(Id)){
                    setPropertyFlag = 'true'
                    
            }
        }
        if(setPropertyFlag.equals('true')){   
            if(property.equals('Email'))
              returnVal = contacts.Email
              else if(property.equals('contactPersonID'))
              returnVal = contacts.ContactPersonID
              else if(property.equals('department'))
              retrunVal = contacts.department;
              else if(property.equals('jobFunction'))
              returnVal = contacts.jobFunction;
              else if(property.equals('phone'))
              returnVal = contacts.phone;
              else
              returnVal = contacts.ID;
            setPropertyFlag = 'false';
         }
    }
    
	return returnVal;
}
