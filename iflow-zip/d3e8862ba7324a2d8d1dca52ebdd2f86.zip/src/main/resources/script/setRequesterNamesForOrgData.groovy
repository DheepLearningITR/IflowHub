
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
def Message processData(Message message) {
    //Body 
    //   def organizationBody 
     def body = message.getBody();
       def properties = message.getProperties() as Map<String, Object>;
       //def body =
       def organizationBody  = properties.get("BusinessPartnerOrganisation");
       def jsonSlurper = new JsonSlurper();
def contactPersonData = jsonSlurper.parseText(body);
 def organizationData = jsonSlurper.parseText(organizationBody);
 def contactPerson = contactPersonData.Payload.customers;
 def orgData = organizationData.OrgData.organization;
 def newOrgData = []; 
 def orgID = [];
 def index = 0;
 int flag = 1;
  //def messageLog = messageLogFactory.getMessageLog(message);
 if(properties.get("ReplicateBusinessPartnerStatus").equals("requested")){
     for(def data : orgData){
    if(contactPerson instanceof groovy.json.internal.LazyMap){
             if(contactPerson.get("customer").get("profile.email").equals(data.get("requester.email") )){
                data.put("requester.firstName",contactPerson.get("customer").get("profile.firstName"))
                data.put("requester.lastName",contactPerson.get("customer").get("profile.lastName"))
                newOrgData.add(data);
                
             }
               
    }else {
     for( def contact : contactPerson){
         //println(data.get("requester.email"));  
          if(contact instanceof groovy.json.internal.LazyMap){
                    if(!contact.isEmpty()){
                        if(contact.get("customer").get("profile.email").equals(data.get("requester.email") )){
                            
                            if(orgID.isEmpty()){
                                orgID[index++] = data.get("organization.BPID")
                                data.put("requester.firstName",contact.get("customer").get("profile.firstName"))
                                data.put("requester.lastName",contact.get("customer").get("profile.lastName"))
                                newOrgData.add(data);
                                break;
                            }
                            else{
                                for(int i = 0 ; i < index ; i++){
                                    if(orgID[i] == data.get("organization.BPID")){
                                        flag = 0;
                                    }
                                }
                                if(flag == 1){
                                    orgID[index++] = data.get("organization.BPID")
                                    data.put("requester.firstName",contact.get("customer").get("profile.firstName"))
                                    data.put("requester.lastName",contact.get("customer").get("profile.lastName"))
                                    newOrgData.add(data);
                                    break;
                                    
                                    
                                }
                            }
                        }
                    }
                }else if(contact instanceof java.lang.String){
                    
                }
                else{
                    //println(contact.getClass())
                     if(!contact){
                         //println(contact.getClass())
                         if(contact.getValue().get("profile.email").equals(data.get("requester.email"))){
                            data.put("requester.firstName",contact.getValue().get("profile.firstName"))
                            data.put("requester.lastName",contact.getValue().get("profile.lastName"))
                            newOrgData.add(data);
                           
                        }
                       /* if(contact.getValue().get("UID").equals(rel.get("uid"))){
                            newContactPersonData.add(contact)
                        }*/
                    }
                }
      }
    }
     
   
 }
  organizationData.OrgData.organization = newOrgData ; 
 // body = new JsonBuilder(organizationData).toPrettyString();
       message.setBody(new JsonBuilder(organizationData).toPrettyString());
 }else
 message.setBody(properties.get("BusinessPartnerOrganisation"))
       return message;
}