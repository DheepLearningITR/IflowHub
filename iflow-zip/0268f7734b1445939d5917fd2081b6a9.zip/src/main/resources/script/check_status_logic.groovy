/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();
       //message.setBody(body + "Body is modified");
       //Headers 
       try{
             def map = message.getHeaders();
       def status = map.get("status");
       def objectNumber=map.get("objectNumber");
     
       if(status && !status.empty){
           if(status.equals("E")) {
             message.setHeader("errorExists","true");
          }
       }else{
          def propertiesMap  = message.getProperties();
          def ex   = propertiesMap.get("CamelExceptionCaught");
          if (ex != null) {
               message.setHeader("errorExists","true");
            //if exception message comes in xml format, get the error from respective block and format it
            if(ex.getMessage().contains("?xml version=")){
                message.setHeader("xmlVersion","true");
                 def exceptionText = new XmlSlurper().parseText(ex.getMessage());
                 def parsedObj = exceptionText.Name.text().split('\n');
                 def concatString="";
                 for (int i = 1; i<parsedObj.size(); i++) {
                   println parsedObj;
                   concatString = concatString+parsedObj[i-1];
                }
                if(concatString.equals("")){
                    message.setHeader("errorMessage", exceptionText.Name.text());
                }else{
                     message.setHeader("errorMessage", concatString);
                }
            // if exception comes as a direct string
            }else{
                 message.setHeader("errorExists","true");
                 message.setHeader("errorMessage", ex.getMessage());
            }
         
        }else{
             message.setHeader("errorMessage", "Issue occured in creation of claim");
        }
      }
     
       }catch(Exception e){
           message.setHeader("errorExists","true");
           message.setHeader("errorMessage", "Issue occured in creation of claim");
       }
             return message;
}