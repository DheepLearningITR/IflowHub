import com.sap.it.api.mapping.*;
def String customFunc(String input, String index){
    int i = Integer.parseInt(index)
    String[] value = input.split('\\|');
    if(i < value.length){
    return value[i];
    }
    else{
        return "";
    }
}