import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def payload = message.getBody(String.class);                            
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.setStringProperty("Logging", "payload.xml");
    messageLog.addAttachmentAsString("payload.xml", payload, "application/xml");
    return message;
}