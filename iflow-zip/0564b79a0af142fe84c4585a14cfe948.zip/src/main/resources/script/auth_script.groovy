import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.*;
import groovy.json.JsonSlurper;
import groovy.xml.XmlUtil;
import groovy.json.StringEscapeUtils;
import src.main.resources.script.CPILogger;

def Message clearWhitespaceInResponse(Message message) {
	def body = message.getBody(String.class);
	body = body.replaceAll("\\s","");
	message.setBody(body);
	return message;
}

def Message cleanupHeaders(Message message) {
	def headers = message.getHeaders();
	def remove = [];
	for (header in headers) {
		switch(header.key) {
			case "AUTH":
			case "MAIN":
			case "LAST":
			case "CamelHttpResponseCode":
			case "Location":
			case "Content-Type":
				break;
			default:
				remove << header.key;
		}
	}
	remove.each {
		headers.remove(it);
	}
	return message;
}

def Message removeExtraQuotes(Message message) {
    def body =  message.getBody(String.class);
    body = StringEscapeUtils.unescapeJavaScript(body)
	message.setBody(body);
    return message;
}

def Message handleHttpException(Message message) {
	def props = message.getProperties();
	def headers = message.getHeaders();
	def exc = props.get("CamelExceptionCaught");
	if (exc!=null) {
		if (exc.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
			def body = exc.getResponseBody();
			message.setBody(body);
			try {
				new JsonSlurper().parseText(body);
				message.setHeader("Content-Type", "application/json");
			} catch (ignored1) {
				try {
					Utils.parseXml(props.get(body));
					message.setHeader("Content-Type", "application/xml");
				} catch (ignored2) {
				}
			}
		} else {
		    if (headers.get('Content-Type') == 'text/plain' && message.getBody() != null) {
		        message.setHeader( 'CamelHttpResponseCode', '428' );
		    }
		}
	}
	return message;
}

def Message log_res_out(Message message) {
	def log_suffix = 'res_out';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_req_in(Message message) {
	def log_suffix = 'req_in';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_exc(Message message) {
	def log_suffix = 'exc';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}
