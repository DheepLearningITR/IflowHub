import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null);
    if(service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }

    def headers   = message.getHeaders();
	def partnerID = headers.get("SAP_TPM_ACTIVITYPARTNER_ID");
    def recDocumentStandard = service.getParameter("SAP_EDI_REC_Document_Standard", partnerID , String.class);
    
	message.setProperty("SAP_EDI_REC_Document_Standard", recDocumentStandard);
	
    return message;
}