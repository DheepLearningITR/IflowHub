// =============================================================================================
// This script adds for better readability a line feed after each UN/EDIFACT related segment
//
// History:
// 2023-01-20 SAP [GS]- Script created
// =============================================================================================

import com.sap.gateway.ip.core.customdev.util.Message;
import org.apache.commons.lang.StringEscapeUtils;
// import groovy.xml.MarkupBuilder
import java.util.HashMap;
def Message processData(Message message) {
       //Body 
        def body = message.getBody(java.lang.String) as String;

        message.setBody(body.replaceAll("'", "'\n"));
        
        return message;
}