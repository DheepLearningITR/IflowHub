import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import groovy.util.XmlSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();
    def map = message.getProperties();
    def writer = new StringWriter();
    def builder = new MarkupBuilder(writer);
    String Fieldglass_Credential = new String (map.get("Fieldglass_Credential"));
    def service =  ITApiFactory.getApi(SecureStoreService.class, null);
    def credential_Secret = service.getUserCredential(Fieldglass_Credential);
    String username_Secret = new String(credential_Secret.getUsername());
    String password_Secret = new String(credential_Secret.getPassword());
    message.setProperty("FG_User", username_Secret)
    message.setProperty("FG_Password", password_Secret)
    def parentRequisitionId = map.get("parentRequisitionId");
    def FieldglassConnectorName = map.get("FieldglassConnectorName");
    def entityNs = [
        'xmlns:soap': 'http://www.w3.org/2003/05/soap-envelope',
        'xmlns:ins': 'insite:soapws:connectorn:v1'
    ]   
    def downloadNs = [
        'ins:dataFormat' : 'csvCommaSeparated',
        'ins:dataEncoding' : 'none'
    ]
    // builder."soap:Envelope"(entityNs) {
    //     "soap:Header"() {
    //     }
    //     "soap:Body"() {
    //         "ins:dataTransferRequestType"() {
    //             "ins:login"() {
    //                 username "${username_Secret}"
    //                 password "${password_Secret}"
    //             }
    //             connector "Attachment XML Download"
    //             connectorArguments() {
    //                 parameter() {
    //                     parameterName "__p1"
    //                     parameterValue "DLABWK00000463"
    //                 }
    //             }
    //             "ins:download"(downloadNs) {
    //             } 
    //         }
    //     }
            
    // }
    builder."soap:Envelope"(entityNs) {
        "soap:Header"() {
        }
        "soap:Body"() {
            "ins:dataTransferRequestType"() {
                "ins:login"() {
                    username "${username_Secret}"
                    password "${password_Secret}"
                }
                connector "${FieldglassConnectorName}"
                connectorArguments() {
                    parameter() {
                        parameterName "__p1"
                        parameterValue "${parentRequisitionId}"
                    }
                }
                "ins:download"(downloadNs) {
                } 
            }
        }
            
    }
    message.setBody(writer.toString());
    
    return message;
}