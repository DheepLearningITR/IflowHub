import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;
import java.util.HashMap;
import groovy.util.slurpersupport.NodeChildren;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def supplierItem, attachments;
    def writer = new StringWriter();
    def builder = new groovy.xml.MarkupBuilder(writer);
    
    def originalPayloadXML  = new XmlSlurper().parse(message.getProperty("original_payload"));
    def baseModuleId = message.getProperty("baseModuleId");
    // get attachments payload
    def attachmentsPayload = new XmlSlurper().parse(message.getBody(java.io.Reader)).declareNamespace('soapenv' : 'http://www.w3.org/2003/05/soap-envelope');
    
    def content = originalPayloadXML.data.baseModuleData.content;
    if(content != null) {
        switch(baseModuleId) {
            case '20':
                supplierItem = parseWorker(content, message);
                attachments = parseAttachmentPayload(attachmentsPayload)
                break;
            case '870':
                supplierItem = parseActivityItem(content);
                break;
        }
        builder.body {
            SupplierItemType {
                supplierItem.each() { key, value ->
                    "${key}" "${value}"
                }
            }
            buildAttachmentBody builder, attachments
        }
        // set message body
        message.setBody(writer.toString());
    }
    return message;
}

def HashMap parseWorker(NodeChildren worker, Message message) {
    def supplierItem  = new HashMap<>();
    // get SOW data from response body
    def sowPayload = message.getProperty("SOWBody");
    def sowPayloadXML = new XmlSlurper().parse(sowPayload);
    def sowBody = sowPayloadXML.Body.dataTransferResponseType.data.text();
    // Purchase order fieldname configured in SOW Download connector
    def fieldName = message.getProperty('FieldglassSOWDownloadFieldName');
    // construct supplier item data
    if (worker != null) {
        supplierItem.put('FldLogsSuplrItemName', worker.displayName);
        supplierItem.put('FldLogsExtWorkerIdentifier', worker.workerRef);
        supplierItem.put('FldLogsSuplrItemSerialNumber', worker.displayName);
        // specify origin of supplier item
        supplierItem.put('FldLogsSupplierItemSource', 'FG');
    }
    // get purchase Order ID (PONumber) from SOW
    if(sowBody != null) {
        sowBody = sowBody.minus("<![CDATA[");
        sowBody = sowBody.minus("]]>");
        def jsonSlurper = new JsonSlurper();
        def sowBodyJSON = jsonSlurper.parseText(sowBody);
        if(sowBodyJSON?.data?.size() > 0) {
            supplierItem.put('FldLogsSuplrItmPOItmUniqueID', "${sowBodyJSON.data[0][fieldName]}/00010");
        }
    }
    return supplierItem;
}

def HashMap parseActivityItem(NodeChildren activityItem) {
    def supplierItem  = new HashMap<>();
    
    supplierItem.put("FldLogsExtWorkerIdentifier", activityItem.relatedBaseModuleInfo.workerRef);
    
    def customFields = activityItem.customFieldSet;
    for (field in customFields) {
        def fieldName = field.name.text();
        switch(fieldName) {
            case "ItemIsDangerousGood":
                def isDangerousGood = false;
                if(field.value.text().toLowerCase() == "yes") {
                    isDangerousGood = true;
                }
                supplierItem.put(field.name.text(), isDangerousGood);
                break;
            // initialize value to 0 if values are missing -- OData V4 action restriction 
            case ["ProductGrossWeight", "FldLogsSuplrItemGrossVolume", "FldLogsSuplrItemLength", "FldLogsSuplrItemWidth", "FldLogsSuplrItemHeight"]:
                def fieldValue = field.value;
                if(fieldValue == null || fieldValue == "") {
                    fieldValue = 0;
                }
                supplierItem.put(field.name.text(), fieldValue);
                break;
            case ["ProductGrossWeight", "ProductWeightUnit"]:
            case ~/^FldLogs.*/:                                                             //pick fields with Prefix "FldLogs"
                supplierItem.put(field.name.text(), field.value);
                break;
        }
    }
    return supplierItem;
}

// parse attachment payload from Fieldglass outbound
def parseAttachmentPayload(attachmentsPayload) {
    def attachments = [];
    def workerId, attachment;
    if(attachmentsPayload != null) {
        def documentObject = attachmentsPayload?.Body?.dataTransferResponseType?.data?.dataXml?.DocAttachments?.DocumentObject;
        if(documentObject != null && documentObject?.Attachment != null) {
            workerId = documentObject.ObjectRef;
            documentObject?.Attachment?.NonXMLContent?.each { attachmentData ->
                attachment = new HashMap<>();
                attachment.put("FldLogsSuplrItmFileContentText",attachmentData?.TextContent.text());
                attachment.put("FileName",attachmentData?.SupportingInformation?.FileName.text());
                attachment.put("MimeType",attachmentData?.SupportingInformation?.MimeType.text());
                attachment.put("FldLogsExtWorkerIdentifier",workerId.text());
                attachments.add(attachment);
            }
        }
    }
    return attachments;
}

// build attachment batch request payload for S4HANA Inbound
def buildAttachmentBody(builder, attachments) {
    if(attachments != null && attachments.size() > 0) {
        builder.attachments {
            attachments.each { attachmentData ->
                SupplierItemAttachmentType {
                    "FldLogsSuplrItmFileContentText" "${attachmentData?.FldLogsSuplrItmFileContentText}"
                    "FileName" "${attachmentData?.FileName}"
                    "FldLogsExtWorkerIdentifier" "${attachmentData?.FldLogsExtWorkerIdentifier}"
                    "MimeType" "${attachmentData?.MimeType}"
                }
            }
        }
    }
    return builder
}