import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;
import groovy.xml.XmlUtil;
import groovy.xml.StreamingMarkupBuilder;
import org.xml.sax.InputSource;
import java.io.Reader;

def Message processData(Message message) {
    def requestHeader = ["Content-Type": "application/json", "Accept": "application/json"];
    def writer = new StringWriter();
    def builder = new groovy.xml.MarkupBuilder(writer);
    
    def body = message.getBody(java.io.Reader);
    def baseModuleId = message.getProperty("baseModuleId");
    def resourcePath = "SupplierItem";
    if(body != null) {
        // Update scenario
        def parsedBody = new XmlSlurper().parse(body);
        
        if(baseModuleId == '870') {
            resourcePath = "SupplierItem/SAP__self.UpdateSupplierItem";
        }
        
        def batchPayload = new StreamingMarkupBuilder().bind { 
          batchParts {
            // To handle supplier item changes
            batchChangeSet0() {
                batchChangeSetPart0() {
                    method 'POST'
                    uri "${resourcePath}"
                    headers {
                        requestHeader.each() { key, value -> 
                            header {
                                headerName "${key}"
                                headerValue "${value}"
                            }
                        }
                    }
                    delegate.body {
                        SupplierItem {
                            mkp.yield parsedBody?.SupplierItemType   
                        }
                    }
                }
            }
            // to handle attachment changes
            parsedBody?.attachments?.children()?.eachWithIndex{ attachmentData, idx ->
                "batchChangeSet${idx+1}" {
                    "batchChangeSetPart${idx+1}" {
                        method 'POST'
                        uri "SupplierItemAttachment/SAP__self.AssignAttachment"
                        headers {
                            requestHeader.each() { key, value -> 
                                header {
                                    headerName "${key}"
                                    headerValue "${value}"
                                }
                            }
                        }
                        delegate.body {
                            SupplierItemAttachment {
                                mkp.yield attachmentData
                            }
                        }
                    }
                }
            }
          }
        }
       if(batchPayload != null) {
           message.setBody(XmlUtil.serialize(batchPayload));
       } 
    }
        
    return message;
}