/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper;
import groovy.util.slurpersupport.NodeChildren;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Body
    def sowBody = message.getBody();
        //def supplierItem  = new HashMap<>();
    // get SOW data from response body
   // def sowPayload = message.getProperty("SOWBody");
    def sowPayloadXML = new XmlSlurper().parse(sowBody);
    //def sowPayloadXML = new XmlSlurper().parse(message.getBody(java.io.Reader)).declareNamespace('soapenv' : 'http://www.w3.org/2003/05/soap-envelope');
    def sowStr = sowPayloadXML.Body.dataTransferResponseType.data.text();
    message.setProperty("nodeName1", sowStr);
    //def sowBody = sowPayloadXML.Body.text();
    // Purchase order fieldname configured in SOW Download connector
    //def fieldName = message.getProperty('FieldglassSOWDownloadFieldName');
    // construct supplier item data
    // get purchase Order ID (PONumber) from SOW
    if(sowBody != null) {
        sowStr = sowStr.minus("<![CDATA[");
        sowStr = sowStr.minus("]]>");
        message.setProperty("sowStr", sowStr);
        def jsonSlurper = new JsonSlurper();
        def sowBodyJSON = jsonSlurper.parseText(sowStr);
        message.setProperty("FldLogsSuplrItmPOItmUniqueID", sowBodyJSON.data[0]["PONumber"]);
       // if(sowBodyJSON?.data?.size() > 0) {
         //   supplierItem.put('FldLogsSuplrItmPOItmUniqueID', "${sowBodyJSON.data[0][fieldName]}/00010");
       // }
    }
    //return supplierItem;
    
/*To set the body, you can use the following method. Refer SCRIPT APIs document for more detail*/
    //message.setBody(body + " Body is modified");
    //Headers
    //def headers = message.getHeaders();
   // def value = headers.get("oldHeader");
    //message.setHeader("oldHeader", value + " modified");
    //message.setHeader("newHeader", "newHeader");
    ////Properties
   // def properties = message.getProperties();
    //value = properties.get("oldProperty");
    //message.setProperty("oldProperty", value + " modified");
    //message.setProperty("newProperty", "newProperty");
    return message;
}