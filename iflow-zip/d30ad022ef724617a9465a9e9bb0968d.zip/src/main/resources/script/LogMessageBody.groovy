import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	
	def msgLog = messageLogFactory.getMessageLog(message); 
	if(msgLog != null){
		def body = message.getBody(java.lang.String) as String;   
		msgLog.addAttachmentAsString("Message Body", body, "text/plain")
	}

    return message;
}
