import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	
	def binary = message.getProperty("billingDocumentPdfBinary");
    println binary;
    binary = binary.replaceAll("\n","")
	message.setProperty("billingDocumentPdfBinary",binary);

    return message;
}

