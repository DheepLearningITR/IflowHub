import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.util.*;
import groovy.xml.*;
import org.codehaus.*;
import java.util.HashMap;

def Message processData(Message message) {
     
     // Read Response Body
     def body_json= message.getBody(java.lang.String) as String;
     def jsonSlurper = new JsonSlurper();
     try{
         def result = jsonSlurper.parseText(body_json);
         message.setProperty("result",result.GetPDF.GetPDFResult.BillingDocumentBinary);
         message.setProperty("errorMessage", "");
         message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
     }
     catch(Exception e)
     {
         message.setProperty("result", "");
         message.setProperty("errorMessage", "");
         message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
     }
     return message;
}