import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {

    //Body
    def body = message.getBody() as String;
    def messageLog = messageLogFactory.getMessageLog(message);
   // def errorLog = "<root>";
    def root = new XmlSlurper().parseText(body);
    def status = "";
      root.batchChangeSetResponse.each {

        status = "${it.batchChangeSetPartResponse.statusInfo}";

        if(status == "REASON_422" || status == "Bad Request" ) {
           errorLog = "${it.batchChangeSetPartResponse.body}";
// y = errorLog.split('@')[0];
           def json = new JsonSlurper().parseText(errorLog);
           throw new Exception(json.error.message.value); 
        }
     }
    return message;
}