/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
       
       //Properties  
	   map = message.getProperties();
      // def query = "$filter=(workAssignmentId in 'AVAILTEST1')";
       def query = "" ;
       def company = "" ;
       
       
       if ((map.get("companyCodes").length() > 0) && !(map.get("companyCodes").equals("Company Codes separated by commas"))) {
		company = map.get("companyCodes");
		company_split = company.split(",");
		    for (int k=0; k < company_split.length; k++) {
			    if (k==0) 
				    company = "'" + company_split[k].trim() + "'";
			    else
				    company = company + ",'" + company_split[k].trim() + "'"; 	        		        	
		    } 	  	
        query = "(jobDetailNav/companyCode in " + company + " )";
	   }
       
       if ((map.get("jobCodes").length() > 0) && !(map.get("jobCodes").equals("Job Codes separated by commas"))) {
		jobs = map.get("jobCodes");
		jobs_split = jobs.split(",");
		    for (int k=0; k < jobs_split.length; k++) {
			    if (k==0) 
				    jobs = "'" + jobs_split[k].trim() + "'";
			    else
				    jobs = jobs + ",'" + jobs_split[k].trim() + "'"; 	        		        	
		    } 
		    
		    if ( query.length() > 0 ){
		        query = query + " and (jobDetailNav/jobCode in " + jobs + " )";   
		    }else{
		         query = "(jobDetailNav/jobCode in " + jobs + " )";   
		    }
	   }
	   
	   if ((map.get("employeeClass").length() > 0) && !(map.get("employeeClass").equals("Employee Classes separated by commas"))) {
		empclass = map.get("employeeClass");
		empclass_split = empclass.split(",");
		    for (int k=0; k < empclass_split.length; k++) {
			    if (k==0) 
				    empclass = "'" + empclass_split[k].trim() + "'";
			    else
				    empclass = empclass + ",'" + empclass_split[k].trim() + "'"; 	        		        	
		    } 
		    
		    if ( query.length() > 0 ){
		        query = query + " and (jobDetailNav/employeeClass in " + empclass + " )";   
		    }else{
		         query = "(jobDetailNav/employeeClass in " + empclass + " )";   
		    }
	   }
	   
	   if ((map.get("employmentType").length() > 0) && !(map.get("employmentType").equals("Employment Types separated by commas"))) {
		emptype = map.get("employmentType");
		emptype_split = emptype.split(",");
		    for (int k=0; k < emptype_split.length; k++) {
			    if (k==0) 
				    emptype = "'" + emptype_split[k].trim() + "'";
			    else
				    emptype = emptype + ",'" + emptype_split[k].trim() + "'"; 	        		        	
		    } 
		    
		    if ( query.length() > 0 ){
		        query = query + " and (jobDetailNav/employmentType in " + emptype + " )";   
		    }else{
		         query = "(jobDetailNav/employmentType in " + emptype + " )";   
		    }
	   }
	   
	   if ((map.get("workAssignmentIds").length() > 0) && !(map.get("workAssignmentIds").equals("UserIds separated by commas"))) {
		workassgnmnts = map.get("workAssignmentIds");
		workassgnmnts_split = workassgnmnts.split(",");
		    for (int k=0; k < workassgnmnts_split.length; k++) {
			    if (k==0) 
				    workassgnmnts = "'" + workassgnmnts_split[k].trim() + "'";
			    else
				    workassgnmnts = workassgnmnts + ",'" + workassgnmnts_split[k].trim() + "'"; 	        		        	
		    } 	  	
            if ( query.length() > 0 ){
		        query = query + " and (workAssignmentId  in " + workassgnmnts + " )";   
		    }else{
		         query = "(workAssignmentId  in " + workassgnmnts + " )";   
		    }
	   }
	   
       message.setProperty("Query",query);
       return message;
}