import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.LocalDate

def Message enrichJsonOutput(Message message) {
    
    def body = message.getBody(java.io.Reader)
    def parsedJson = new JsonSlurper().parse(body)
   
    parsedJson.messageRequests?.each { request ->
            request.body?.each { key, value ->
                if (value == "") {
                    request.body[key] = null
                }
            }
            request.body?.workAssignment?.each { assignment ->
                if (assignment.isBlocked) {
                    assignment.isBlocked = assignment.isBlocked.toBoolean()
                }
            }
        }

    def responseBody = JsonOutput.toJson(parsedJson)
    message.setBody(responseBody)
    
    //Set the C4C message ID as customer monitoring header
   def messageLog = messageLogFactory.getMessageLog(message);
  	if(messageLog != null){
       
  		def messageHeaderId = message.getProperties().get("P_MessageHeaderId")		
  		if(messageHeaderId != null){
  			messageLog.addCustomHeaderProperty("Replication Message ID", messageHeaderId)
          }
  	}

    return message
}

def Message setNoOfRecordsProcessed(Message message) {
    // Retrieve properties from the message
    def properties = message.getProperties()
    def recordsProcessed = properties.get("recordsProcessed")?.toInteger() ?: 0

    // Update the total records processed
    recordsProcessed += 100

    // Set the updated value back to the message properties
    message.setProperty("recordsProcessed", recordsProcessed)

    return message
}

def Message buildQueryParam(Message message) {
    // Retrieve properties from the message
    def properties = message.getProperties()
    def lastChangeDate = properties.get("lastChangedDate")
    def initialLoad = properties.get("initialLoad")
    
    def recordsProcessed = properties.get("recordsProcessed")?.toString()?.trim() ? properties.get("recordsProcessed").toInteger() : 0
    message.setProperty("recordsProcessed", recordsProcessed)
    
    def query = properties.get("query")
    def queryParam

    // Determine query type: Initial Load or Delta Load
    
    if ("IN-PROCESS".equals(initialLoad))
    {
         queryParam = "$query&\$filter=LastChangeDate le $lastChangeDate"
    
    }
    
    else if (lastChangeDate) {
        // Delta Load
        queryParam = "$query&\$filter=LastChangeDate ge $lastChangeDate or CreationDate ge $lastChangeDate"
        
    }

    // Set the new query in message properties
    message.setProperty("queryParam", queryParam)
    return message
}

def Message setVariableNames(Message message) {
    
    def body = message.getBody(java.io.Reader)
    def data = new JsonSlurper().parse(body)
    def senderId =  data.messageHeader.senderCommunicationSystemDisplayId
    def receiverId = data.messageHeader.receiverCommunicationSystemDisplayId
    
    message.setProperty("SenderBusinessSystem", receiverId)
    message.setProperty("ReceiverBusinessSystem", senderId)
    
    def lastChangeDate = message.getProperty("lastChangedDate")
    
    if (!lastChangeDate)
    {
        def today = LocalDate.now().toString()
        message.setProperty("lastChangedDate", today)
        message.setProperty("initialLoad", "IN-PROCESS")
    }
   
    return message
}
// For Debugging Only
def Message generateException(Message message) {
   
       def map = message.getProperties()
       def loopIndex = map.get("CamelLoopIndex")
       if (loopIndex >= 50)
        throw new Exception ("Explicit Exception for Internal Testing")
       
       return message
}