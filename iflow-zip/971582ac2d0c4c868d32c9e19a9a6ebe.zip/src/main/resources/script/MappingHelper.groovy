import com.sap.it.api.mapping.MappingContext;


def String generateGuid(){
	return UUID.randomUUID()
}

def String generateMessageHeaderId(String arg1, MappingContext context){
  	String messageHeaderId =  UUID.randomUUID().toString()
  	context.setProperty("P_MessageHeaderId", messageHeaderId)
  	return messageHeaderId
  }
