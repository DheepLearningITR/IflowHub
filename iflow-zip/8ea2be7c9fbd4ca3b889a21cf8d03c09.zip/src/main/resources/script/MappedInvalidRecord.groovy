import com.sap.it.api.mapping.*;

def String customFunc(String arg1,String arg2,String arg3,String arg4,String arg5,String arg6){
	
	String err = "";
	
	if(arg1 == "")
	{
	    err = "Missing Start Date";
	}
	
	if(arg2 == "")
	{
	    if(err != "")
	    {
	        err = err + ";" + "Missing End Date";
	    }
	    else
	    {
	        err = "Missing End Date";
	    }
	}
	
	if(arg3 == "")
	{
	    if(err != "")
	    {
	        err = err + ";" + "Missing Component Type";
	    }
	    else
	    {
	        err = "Missing Component Type";
	    }	    
	}
	
	if(arg4 == "")
	{
	    if(err != "")
	    {
	        err = err + ";" + "Missing Amount";
	    }
	    else
	    {
	        err = "Missing Amount";
	    }	    
	}
	
	if(arg5 == "E")
	{
	    if(err != "")
	    {
	        err = err + ";" + "PayrollID is not numeric";
	    }
	    else
	    {
	        err = "PayrollID is not numeric";
	    }	    
	}
	
	if(arg6.size()>=9)
	{
	    if(err != "")
	    {
	        err = err + ";" + "PayrollID has more than 9 characters";
	    }
	    else
	    {
	        err = "PayrollID has more than 9 characters";
	    }	    
	}
	
	return err;
}