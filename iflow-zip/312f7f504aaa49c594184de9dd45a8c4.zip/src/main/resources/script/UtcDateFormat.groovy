import com.sap.it.api.mapping.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

// This method converts the date time into required format as per target system

def String customFunc(String arg1){

    Date inputDate_parsed=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(arg1);

    DateFormat dateFormat_required = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    def converted_datetime=dateFormat_required.format(inputDate_parsed);

    return converted_datetime;
}
