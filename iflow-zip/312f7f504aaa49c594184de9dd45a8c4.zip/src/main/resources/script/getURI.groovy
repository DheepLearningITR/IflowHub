import com.sap.it.api.mapping.*;

//This method forms the ProductOriginDataSet URI
def String getProductOriginSetDataURI(String arg1, String arg2){
	return "ProductOriginDataSet(ProductID='"+URLEncoder.encode(arg1, "UTF-8")+"',ProductOrigin='"+URLEncoder.encode(arg2, "UTF-8")+"')";
}

//This method forms the DeleteProductCategoryAssignments URI
def String getDeleteCategoryAssignmentURI(String arg1, String arg2, String arg3){
	return "DeleteProductCategoryAssignments?ProductID='"+URLEncoder.encode(arg1, "UTF-8")+"'&ProductOrigin='"+URLEncoder.encode(arg2, "UTF-8")+"'&HierarchyID='"+URLEncoder.encode(arg3, "UTF-8")+"'";
}
