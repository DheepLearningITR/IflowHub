import com.sap.it.api.mapping.*;
import groovy.util.XmlParser;
import groovy.xml.XmlUtil;
/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

*/



def void custFunc(String[] is,String[] ps, Output output, MappingContext context) {
        theNode = '''<a></a>'''
        segmentToAdd = new XmlParser().parseText(theNode)
        output.addValue(theNode)
        //output.addValue(XmlUtil.serialize(segmentToAdd));
}