import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body); //Parse the JSON payload
    
    jsonObject["EQUIPMENT"].each {
        if(it["nameTranslations"] == ""){
            it["nameTranslations"] = null; //If no name translations exist, send 'null'
        }
    }
    
    message.setBody(JsonOutput.toJson(jsonObject["EQUIPMENT"]));
    message.setProperty("RequestPayload", JsonOutput.toJson(jsonObject["EQUIPMENT"])); //Saving payload that s being sent to FSM. This payload will be attached or mailed in case of error, based on configuration in error handling
    return message;
}
