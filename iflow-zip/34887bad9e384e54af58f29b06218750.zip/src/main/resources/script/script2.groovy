import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) { 
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)
    
    if (jsonResult.eventType == "activity.confirmed" || jsonResult.eventType == "activity.confirmedcompleted")
    {
        def ServiceOrder, ServiceOrderItem, serviceOrderBundleItem, ParentServiceOrderItem
        def fsmItemID
        fsmItemID = jsonResult['data']['serviceCall']['activity']['unifiedIdentifier']['externalId'] as String
        ServiceOrder = fsmItemID.split('/')[0]
        ServiceOrderItem = fsmItemID.split('/')[-1]
        if (fsmItemID.split('/').size() == 3) {
            serviceOrderBundleItem = fsmItemID.split('/')[-2]
            ParentServiceOrderItem = serviceOrderBundleItem
            message.setProperty("serviceOrderBundleItem",serviceOrderBundleItem)
        } else {
            ParentServiceOrderItem = ServiceOrderItem
        }
        message.setProperty("ServiceOrder",ServiceOrder)
        message.setProperty("ServiceOrderItem",ServiceOrderItem)
        message.setProperty("ParentServiceOrderItem",ParentServiceOrderItem)
        message.setProperty("originalPayload",body)
        message.setProperty("serviceType", "ServiceConfirmation")
        if (jsonResult.eventType == "activity.confirmedcompleted") {
            message.setProperty("ConfirmedCompleted", "X")
        }
    } else if (jsonResult.eventType == "activity.created" && jsonResult.data.serviceCall.activity.sourceActivity != null) {
        message.setProperty("ActivityDuplicate", "X")
    } else if (jsonResult.eventType == "activity.replannedreleased" || jsonResult.eventType == "activity.releasedunassigned") {
        if (jsonResult.data.serviceCall.sourceActivityCompleted != null) {
            message.setProperty("SourceActivityCompleted", "X")
        }
        message.setProperty("ActivityReassignment", "X")
    }
    
    return message
}