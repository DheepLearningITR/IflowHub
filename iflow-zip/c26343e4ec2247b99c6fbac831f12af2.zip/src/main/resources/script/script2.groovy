import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import java.util.*;
import java.text.SimpleDateFormat;

def Message processData(Message message) {

    def body = message.getBody(String.class);
    def params = [
       "emailId" : message.getProperties().get('emailId'),
       "externalQuoteId" : message.getProperties().get('externalQuoteId'),
       "feedback" : message.getProperties().get('feedback'),
    ];
    def result = map(params);
    message.setBody(result);
    return message;
}


def String map(def params) {
    def targetMessage = new XmlParser().parseText(getTaskCollectionTemplate());
    targetMessage.Tasks[0].Subject[0].value = "Feedback from "+ params.emailId +" for quote " +params.externalQuoteId;
    targetMessage.Tasks[0].Status[0].value = 1;
    targetMessage.Tasks[0].PriorityCode[0].value = 1;
    targetMessage.Tasks[0].DocumentType[0].value = "0006";
    targetMessage.Tasks[0].TasksTextCollection[0].TasksTextCollection[0].Text[0].value = params.feedback;;
    targetMessage.Tasks[0].TasksTextCollection[0].TasksTextCollection[0].TypeCode[0].value = 10002;
    def result = XmlUtil.serialize(targetMessage);
    return result;
}

///----------------------------------------------------------------------------------
/// XML Templates


def getTaskCollectionTemplate() {
    return '''
    <TasksCollection>
      <Tasks>
        <ObjectID></ObjectID>
        <Subject></Subject>
        <Status></Status>
        <PriorityCode></PriorityCode>
        <DocumentType></DocumentType>
        <TasksTextCollection>
          <TasksTextCollection>
            <Text></Text>
            <TypeCode></TypeCode>
          </TasksTextCollection>
        </TasksTextCollection>
      </Tasks>
    </TasksCollection>
    '''.stripMargin();
}



 