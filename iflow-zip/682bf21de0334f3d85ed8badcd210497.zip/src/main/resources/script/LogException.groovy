        import com.sap.gateway.ip.core.customdev.util.Message;

        def Message processData(Message message) {
                        
                        // get a map of iflow properties
                        def map = message.getProperties()
                        def refernceID = map.get("ExchangeRate")
                        def logException = map.get("ExceptionLogging")
                        def enableMailNotification = map.get("EnableMailNotification")
                        def SAP_MessageProcessingLogID =  map.get("SAP_MessageProcessingLogID")
                        def attachID = ""
                        def errordetails = ""

                        // get an exception java class instance
                        def ex = map.get("CamelExceptionCaught")
                        if (ex!=null) 
                        {
                        // save the error response as a message attachment 
                        def messageLog = messageLogFactory.getMessageLog(message);
                        if (refernceID == null || refernceID == "" )
                        {
                            errordetails = "The Exchange Rate replication failed because of the following error:  " + ex.toString()
                            attachID  = "Error Details for Exchange Rate"
                        }
                        else 
                        {
                            errordetails = "The Exchange Rate replication for  '" + refernceID + "' failed because of the following error:  " + ex.toString()
                            attachID  = "Error Details for Exchange Rate '" + refernceID + "'"	
                        }
                        
                        if (logException != null && logException.equalsIgnoreCase("TRUE")) 
                        {
                            messageLog.addAttachmentAsString(attachID, errordetails, "text/plain");
                        }
                        
                        }

                        return message;
        }