import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.*;
import groovy.json.JsonBuilder;
import groovy.lang.*;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String);
       def jsonSlurper = new JsonSlurper()
       def object = jsonSlurper.parseText(body.toString());
	   def payload;
       def claimNumber=object.claimNumber;
       def status_code=object.status_code;
       def isAsynchronousRequest=object.isAsynchronousRequest;
       if(null!=isAsynchronousRequest){
           isAsynchronousRequest = isAsynchronousRequest.toLowerCase().toBoolean();
       }
		
	   def json = new JsonBuilder();
       payload= json claimNumber:claimNumber, status_code:status_code, isAsynchronousRequest:isAsynchronousRequest
		
 
      message.setBody(groovy.json.JsonOutput.toJson(payload));
      message.setHeader("claimNumber",claimNumber);
      message.setProperty("payload",groovy.json.JsonOutput.toJson(payload));
      return message;
}