/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData( Message message) {
	def headers = message.getHeaders();
	
	def httpPath = headers.get("CamelHttpPath");
	def parts = httpPath.split("/");
	
	// error handling (method not allowed)
	def httpMethod = headers.get("CamelHttpMethod");
	if ("GET" != httpMethod) {
	    message.setHeader("CamelHttpResponseCode", "405");
	    message.setBody("");
	    return message;
	}
	
	
	if (parts[0] == "projects") {
	    message.setProperty("Operation", "GetProjects");
	}

    if (parts.length >= 2) {
        message.setProperty("ProjectUuid", parts[1]);
        message.setProperty("ProjectUuidRaw", parts[1].toUpperCase().replaceAll("-", ""))
    }

	if (parts.length >= 3) {
	    if (parts[2] == "projectPlan") {
	        message.setProperty("Operation", "GetProjectPlan");
	    }
	}
	
	// error handling (unknown rest operation)
	if (message.getProperty("Operation") == null) {
	    message.setHeader("CamelHttpResponseCode", "404");
	    message.setBody("");
	    return message;
	}

    return message;
}