/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

    // Get Message body
    def body = message.getBody(java.lang.String) as String;
    def MessageBody = new XmlParser().parseText(body);   

    //iterate over each item
    MessageBody.row.each{
        //checking if exists SelectedAttributes node
        if(it.SelectedAttributes.size() == 0){
            //if SelectedAttributes doesn't exist we create one empty SelectedAttributes node with dummy data
            
            //creation of emtpty Values node which will be appended to SelectedAttributes later
            def emptyValues = new NodeBuilder().Values {
                Value("")
                Author("")
            }
            //creation of empty SelectedAttirbutes node
            def emptySelectedAttirbute = new NodeBuilder().SelectedAttributes {
                Id("-1")
                SystemId("EmptyAttribute")
                ValueDataType("string")
            }

            emptySelectedAttirbute.append emptyValues
            it.append emptySelectedAttirbute
        }
    }
    
    message.setBody(groovy.xml.XmlUtil.serialize(MessageBody))
    return message;
}

