import com.sap.it.api.mapping.*;
import java.lang.*;
import java.text.*;

def String getItemDescription(String Description, String ProductName, int MaxLength){
    
    
    String BusSolnQtanItemDescription = "";
    
    if(Description != null && Description != "")
    {
        
         if(Description.size() > MaxLength) 
         {
             BusSolnQtanItemDescription = Description.substring(0,MaxLength);
         }
         
         else
         {
             BusSolnQtanItemDescription = Description;
         }
    }
    
    else
    {
            if(ProductName != null && ProductName != "")
            {
            
                 if(ProductName.size() > MaxLength) 
                 {
                     BusSolnQtanItemDescription = ProductName.substring(0,MaxLength);
                 }
                 
                 else
                 {
                     BusSolnQtanItemDescription = ProductName;
                 }
            }     
    }
    
    
	return BusSolnQtanItemDescription; 
}