import java.util.HashMap;
import groovy.json.*;
import groovy.xml.*;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(String.class);

    def jsonSlurper = new JsonSlurper();
    def jsonData = jsonSlurper.parseText(body);

    message.setProperty("page_marker", "");
    jsonData.each {
        nextToken = it.get("nextToken");
        if (nextToken)
            message.setProperty("page_marker", nextToken);
    }

    return message;
}
