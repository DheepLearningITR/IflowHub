import java.util.HashMap;
import groovy.json.*;
import groovy.xml.*;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(String.class);

    def jsonSlurper = new JsonSlurper();
    def jsonData = jsonSlurper.parseText(body);

    message.setProperty("interos_job_uuid", "00000000-0000-4000-0000-000000000000");

    data = jsonData.get("data");
    if (data) {
        job = data.get("job");
        if (job.uuid) {
            message.setProperty("interos_job_uuid", job.uuid);
        }
    }

    return message;
}
