import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

def String stGetZip4(String arg1, String theCountry){
    if( theCountry && !(theCountry.trim().equalsIgnoreCase("US") || theCountry.trim().equalsIgnoreCase("USA")) ) {
        return "";
    }
    if(arg1) {
        def tokens = arg1.trim().tokenize("-");
        
        if( tokens ) {
            int i = 0;
            for( item in tokens ) {
                if( i == 1 ) {
                    return item;
                } else if ( i > 1 ) {
                    return "";
                }
                i++;
            }
        }
    }
    
	return "";
}

def String stGetZip5(String arg1, String theCountry){
  
    if( theCountry == null || theCountry.trim().equals("") ) {
        throw new Exception("COUNTRY is required");
    } 
    String country = theCountry.trim();
    
    if( country && !(country.equalsIgnoreCase("US") || country.equalsIgnoreCase("USA")) ) {
        return arg1;
    }
    if(arg1) {
    def tokens = arg1.trim().tokenize("-");
    
        if( tokens ) {
            int i = 0;
            for( item in tokens ) {
                if( i == 0 ) {
                    return item;
                } else if ( i > 0 ) {
                    return "";
                }
                i++;
            }
        }
    }
    
	return "";
}


def String customGetClientNumber(String storedUsername) {
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential(storedUsername);
    if (credential == null) {
        throw new IllegalStateException("No credential found for alias '$storedUsername'");
    }
    return credential.getUsername();
}

def String customGetVKey (String storedUsername) {
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential(storedUsername);
    if (credential == null) {
        throw new IllegalStateException("No credential found for alias '$storedUsername'");
    }
    return new String(credential.getPassword());
}

def String getErrorCode(String responseCode){
    String errorCode = "1999";
    if( responseCode != null && responseCode.trim().equals("9999") ) {
        errorCode = "0000";
    } 
	return errorCode;
}

def String getReturnCode(String responseCode){
    String returnCode = "1";
    if( responseCode != null && responseCode.trim().equals("9999") ) {
        returnCode = "0";
    } 
	return returnCode;
}

def String getExchangeProperty(String propertyName, MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}

def String stateMapping (String jurisdictionCode, MappingContext context) {
    def stateMap = 
    ["00":"US",
     "01":"AL",
     "02":"AK",
     //"03":"AL",
     "04":"AZ",
     "05":"AR",
     "06":"CA",
     //"07":"AL",
     "08":"CO",
     "09":"CT",
     "10":"DE",
     "11":"DC",
     "12":"FL",
     "13":"GA",
     //"14":"AK"
     "15":"HI",
     "16":"ID",
     "17":"IL",
     "18":"IN",
     "19":"IA",
     "20":"KS",
     "21":"KY",
     "22":"LA",
     "23":"ME",
     "24":"MD",
     "25":"MA",
     "26":"MI",
     "27":"MN",
     "28":"MS",
     "29":"MO",
     "30":"MT",
     "31":"NE",
     "32":"NV",
     "33":"NH",
     "34":"NJ",
     "35":"NM",
     "36":"NY",
     "37":"NC",
     "38":"ND",
     "39":"OH",
     "40":"OK",
     "41":"OR",
     "42":"PA",
     //"43":"NV",
     "44":"RI",
     "45":"SC",
     "46":"SD",
     "47":"TN",
     "48":"TX",
     "49":"UT",
     "50":"VT",
     "51":"VA",
     //"52":"TX",
     "53":"WA",
     "54":"WV",
     "55":"WI",
     "56":"WY",
     "60":"AS",
     "64":"FM",
     "66":"GU",
     "68":"MH",
     "69":"MP",
     "70":"PW",
     "72":"PR",
     "78":"VI",
     "96":"ZZ",
     "97":"ZZ",
     "98":"ZZ"];
     
     
    String jcdUnifyIndicator = getExchangeProperty("exchangejcdunifyind", context);
    
    
    def countryCode = jurisdictionCode.substring(0,2);
    if(jcdUnifyIndicator != null && "X".equalsIgnoreCase(jcdUnifyIndicator) && "US".equalsIgnoreCase(countryCode)) {

        def stateCode = jurisdictionCode.substring(2,4);
        def stateAbr = stateMap[stateCode];
        if (stateAbr != null) {
            def result = jurisdictionCode.substring(0,2) + stateAbr + jurisdictionCode.substring(2) + "-";
            return result;
        }
    }
     
    
    return jurisdictionCode + jcdUnifyIndicator;
}

