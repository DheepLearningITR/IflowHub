import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    
    def body = message.getBody(String)
    def jsonData = new JsonSlurper().parseText(body)

    // Extract the "partyAccount" array
    def partyAccountArray = jsonData.partyAccount

    // Print or process each entry in the array
    def resultArray = partyAccountArray.collect { entry ->
        [
            id: entry.id,
            href: entry.href,
            name: entry.name,
            billStructure: entry.billStructure,
            defaultPaymentMethod: entry.defaultPaymentMethod,
            financialAccount: entry.financialAccount,
            relatedParty: entry.relatedParty
        ]
    }

    def resultJson = new groovy.json.JsonBuilder(resultArray).toPrettyString()


    // Set the result string as the new body
    message.setBody(resultJson)
    
    return message
}
