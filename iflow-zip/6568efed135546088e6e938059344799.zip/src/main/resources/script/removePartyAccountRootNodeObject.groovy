import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    
    def body = message.getBody(String)
    def jsonData = new JsonSlurper().parseText(body)

    // Extract the "partyAccount" field
    def partyAccount = jsonData.partyAccount

    if (partyAccount instanceof Map) {
        // If "partyAccount" is a single object, use it directly
        jsonData = partyAccount
    }

    // Convert the updated jsonData to a JSON string
    def resultJson = new groovy.json.JsonBuilder(jsonData).toPrettyString()

    // Set the result string as the new body
    message.setBody(resultJson)
    
    return message
}
