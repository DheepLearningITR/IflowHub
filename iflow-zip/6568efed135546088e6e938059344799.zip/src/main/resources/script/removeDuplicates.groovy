/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    //Body
    def body = message.getBody(String);

    def inputJsonObject = new JsonSlurper().parseText(body)
    // Create a map to store unique entries based on "id"
    def uniqueEntries = [:]

    // Iterate through the JSON array
    inputJsonObject.each { entry ->
    def id = entry.id
    // Check if the "id" is not already in the map
    if (!uniqueEntries.containsKey(id)) {
        uniqueEntries[id] = entry
    }
}

// Convert the map values back to an array
def filteredPayload = uniqueEntries.values()

// Convert the filtered payload back to a JSON string
def filteredPayloadJson = JsonOutput.toJson(filteredPayload)
    
    message.setBody(filteredPayloadJson)

    return message;
}