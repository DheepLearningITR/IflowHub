import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	String x_api_token = "";
	def properties = message.getProperties();
    def QualtricsIntegrationToken = properties.get("QualtricsAPIToken");
	def service = ITApiFactory.getApi(SecureStoreService.class, null);
	def secureParam = service.getUserCredential(QualtricsIntegrationToken);
	if (secureParam == null){ 
	   throw new IllegalStateException("No secure parameter found for alias '" +QualtricsIntegrationToken+ "'");             
    } 
    else{
       x_api_token =  new String(secureParam.getPassword());
    }

    if(x_api_token){
       message.setHeader("X-API-TOKEN",x_api_token);
    }
	return message;
}