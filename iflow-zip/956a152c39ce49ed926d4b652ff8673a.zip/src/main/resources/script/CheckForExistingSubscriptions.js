importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
    
    var body = String(message.getBody(new java.lang.String().getClass()));
    //create json object from string object
    body = JSON.parse(body);
      
    if(body && body.result && body.result.elements){
        if(body.result.elements.length){
          message.getProperties().put("PostSubscription",'true');
          var aSubscriptions = body.result.elements;
          var SurveyID = message.getProperties().get('SurveyID');
          for (var i = 0; i<aSubscriptions.length; i++){
              if(aSubscriptions[i].topics.indexOf('completedResponse') >= 0){
                  if(aSubscriptions[i].topics.indexOf(SurveyID) >= 0){
                      var pubuRL = message.getProperty('PublicationURL');
                       if(aSubscriptions[i].publicationUrl == pubuRL){
                         message.getProperties().put("PostSubscription",'false');
                         break;
                       }
                  }
              }
          }
        }else{
          message.getProperties().put("PostSubscription",'true');
        }
    }
   
    return message;
   
}
