import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import java.util.*;
import java.text.SimpleDateFormat;

def Message processData(Message message) {
    def surveyId = message.getProperties().get('SurveyID');
    def response_id = message.getProperties().get('ResponseID');
    def body = message.getBody(String.class);
    def adminFields = [
       "CreatedOn" : message.getProperties().get('CreatedOn'),
       "ModifiedOn" : message.getProperties().get('ModifiedOn'),
       "ValidFrom" : message.getProperties().get('ValidFrom'),
       "ValidTo" : message.getProperties().get('ValidTo')
    ];
    def result = map(response_id,surveyId, body, adminFields);
    message.setBody(result);
    return message;
}

def String map(String response_id,String surveyId, String message, def adminFields) {
    def SourceMessage = new XmlParser().parseText(message);
    def TargetMessage = new XmlParser().parseText(getTargetMessageTemplate());
    TargetMessage.SurveyId[0].value   = surveyId;
    TargetMessage.CreatedOn[0].value  = adminFields.CreatedOn;
    TargetMessage.ModifiedOn[0].value = adminFields.ModifiedOn;
    TargetMessage.ValidFrom[0].value  = adminFields.ValidFrom;
    TargetMessage.ValidTo[0].value    = adminFields.ValidTo;
 
    SourceMessage.result.values.each {
 
    //    def recordId = it._recordId.text();
        def recordDate = it.recordedDate.text();
        def sapOutboundId = it.'sap-outbound-id'.text();
        
    //    if (record_id_filter.equals(recordId)) {
          def SurveyResponse   = new XmlParser().parseText(getTargetMessageSurveyResponseTemplate());
          SurveyResponse.ResponseId[0].value = response_id;
          SurveyResponse.RespondedOn[0].value = recordDate;
          SurveyResponse.OutboundKey[0].value = sapOutboundId;
          
          if(sapOutboundId){ //Clear dummy ID and IdOrigin values if outbound key is already captured
            SurveyResponse.Id[0].value = "";
            SurveyResponse.IdOrigin[0].value = "";
          }
          
          TargetMessage.append(SurveyResponse);

    it.each {
      def groovy.util.Node nit = it;
      String nodeName = nit.name();

       def DetailSet = new XmlParser().parseText(getTargetMessageDetailSetTemplate());           

        if (SourceMessage.result.displayedFields.find{ ls-> ls.text() == nit.name() }) {
    // For Matrix Question Type
           if (nodeName.matches("(.*_\\d+)")) {
            def index = nit.name().indexOf("_");
                DetailSet.QuestionId[0].value    = nit.name().substring(0, index);
                DetailSet.ResponseIdRow[0].value = nit.name().substring(index + 1);
                DetailSet.ResponseIdCol[0].value = nit.value();
                TargetMessage.SurveyResponseSet[0].append(DetailSet);
           }
    // For Free Text Question Type
             else if (nodeName.matches("(.*_TEXT)")) {
                 index = nit.name().indexOf("_");
                    DetailSet.QuestionId[0].value   = nit.name().substring(0, index);
                    DetailSet.ResponseText[0].value = nit.value();
                    TargetMessage.SurveyResponseSet[0].append(DetailSet);
             }
    // For Remaining Question Types
                else if (!nodeName.matches("(.*_NPS_GROUP)")){   
                      DetailSet.QuestionId[0].value    = nit.name(); 
                      DetailSet.ResponseIdRow[0].value = nit.value();
                      TargetMessage.SurveyResponseSet[0].append(DetailSet);
            }
          }
        }
    }
 
    def result = XmlUtil.serialize(TargetMessage);
    return result;
}

///----------------------------------------------------------------------------------
/// XML Templates
 
def getTargetMessageTemplate() {
return '''

<SurveySet>
  <SurveyId></SurveyId>
  <Provider>Qualtrics</Provider>
  <Version>1</Version>
  <IsMultipleRespAllowed>true</IsMultipleRespAllowed>
  <IsSurveyAnonymous>false</IsSurveyAnonymous>
  <CreatedOn></CreatedOn>
  <ModifiedOn></ModifiedOn>
  <ValidFrom></ValidFrom>
  <ValidTo></ValidTo>  
</SurveySet>
'''.stripMargin();
}

def getTargetMessageSurveyResponseTemplate() {
return '''
  <SurveyResponseSet>
  <ResponseId></ResponseId>
  <Id></Id>
  <IdOrigin></IdOrigin>
  <RespondedOn></RespondedOn>
  <OutboundKey></OutboundKey>
  </SurveyResponseSet>
'''.stripMargin();
}

def getTargetMessageDetailSetTemplate() {
return '''
<SurveyResponseSurveyResponseDetailSet>
        <QuestionId></QuestionId>
        <ResponseIdRow></ResponseIdRow>
        <ResponseIdCol></ResponseIdCol>
        <ResponseText></ResponseText>
    </SurveyResponseSurveyResponseDetailSet>
'''.stripMargin();
}