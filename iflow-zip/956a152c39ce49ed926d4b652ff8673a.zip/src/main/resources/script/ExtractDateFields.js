importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
    var body = String(message.getBody(new java.lang.String().getClass()));
    //create json object from string object
    body = JSON.parse(body);
    
    var source = body.result;
   
    message.getProperties().put("CreatedOn",String(source.creationDate));
    message.getProperties().put("ModifiedOn",String(source.lastModifiedDate));
    message.getProperties().put("ValidFrom",String(source.expiration && source.expiration.startDate ? source.expiration.startDate : source.creationDate));
    message.getProperties().put("ValidTo",String(source.expiration && source.expiration.endDate ? source.expiration.endDate : "9999-12-31T11:59:59Z"));
    
    return message;
}

function formatDateField(sDate) {
    if(sDate){
      sDate = sDate.substring(0,sDate.length - 1);
    }
    return sDate;
}
