import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def values = body.split('&');
	
	values.each {
	 def (k, v) =  it.split('=', 2)
	 message.getProperties().put(k,v);
	}
	
	return message;
}