import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.*;

def Message processData(Message message) {
	
	def map = message.getProperties();
	def des = map.get("Description");
	des.trim();
	message.setProperty("Description",des);
	def messageLog = messageLogFactory.getMessageLog(message);
	if (messageLog != null) {
		messageLog.addAttachmentAsString("des", des, "application/json");
	}
	
	return message;
}