/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	def body = message.getBody();
	def map = message.getProperties();
	System.out.println("Preparing body");	
	
	if(map.get("processingTypeCode") == "SRRQ"){  
	    message.setProperty("processingTypeCode",1);
	}else{
	    System.out.println("processingTypeCode should not be sent to sec");
	}
	
	System.out.println("servicePriorityCode :: "+ map.get("servicePriorityCode"))
	switch(map.get("servicePriorityCode") as Integer){
	    
	    case 2:  message.setProperty("servicePriorityCode",1);
	    	 System.out.println("case 2 :servicePriorityCode code changed to 1");
	    	break;
	    case 3:  message.setProperty("servicePriorityCode",2);
	    	 System.out.println("case 3: servicePriorityCode code changed to 2");
	    	break;
	    case 7:  message.setProperty("servicePriorityCode",3);
	    	 System.out.println("case 7: servicePriorityCode code changed to 3");
	    	break;   
	}
	System.out.println("servicePriorityCode :: "+ map.get("servicePriorityCode"))

	System.out.println("serviceRequestLifeCycleStatusCode :: "+ map.get("serviceRequestLifeCycleStatusCode"))
	switch(map.get("serviceRequestLifeCycleStatusCode") as Integer){
	    
	    case "3":  message.setProperty("serviceRequestLifeCycleStatusCode",4);
	    	 System.out.println("case 3: serviceRequestLifeCycleStatusCode code changed to 4");
	    	break;
	    case "4":  message.setProperty("serviceRequestLifeCycleStatusCode",5);
	    	System.out.println("case 4: serviceRequestLifeCycleStatusCode code changed to 5");
	    	break;   
	}
	System.out.println("serviceRequestLifeCycleStatusCode :: "+ map.get("serviceRequestLifeCycleStatusCode"))



	return message;
}

