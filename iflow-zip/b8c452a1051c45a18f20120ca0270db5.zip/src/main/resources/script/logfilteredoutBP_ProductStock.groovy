import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil;
//import groovy.util.slurpersupport.NodeChild;

def Message processData(Message message) {
    /* This script is to log the Product Stock IDs that are filtered out with no FSM company. */
	
    def body = message.getBody(java.lang.String)
    def query = new XmlSlurper().parseText(body)
    def messageLog = messageLogFactory.getMessageLog(message)
    def plant;
    def material;
    def storagelocation;
	
    query.MaterialStockReplicateMsg.each { stockMessage ->
        stockMessage.MaterialStock.each { stock ->
         material = stock.Material.text();
         plant = stock.Plant.text();
         storagelocation = stock.StorageLocation.text();
         if (messageLog != null) {
            messageLog.addCustomHeaderProperty("FSMCompanyNotFoundForWarehouse", material + '|' + plant + '|' + storagelocation)
               
            }
        }
    }
    return message
}