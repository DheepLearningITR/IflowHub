import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    message.setProperty("WarehoseMapped_Original",body)
    def query = new XmlSlurper().parseText(body);
    def Set <String> set = new HashSet <String> ();
    query.data.each{
        set.add(it.externalId);
    }
    
    def mssg = """{"query":"SELECT wh.externalId from Warehouse wh WHERE wh.externalId IN (""";
    int i;
    for(i=0; i<set.size()-1; i++) {
        mssg = """${mssg}'${set[i]}',""";
    }
    mssg = """${mssg}'${set[i]}')"}""";
    message.setBody(JsonOutput.toJson(new JsonSlurper().parseText(mssg)));
    
    // To access FSM, company and account are required -- either their name or their ID.
    // If the IDs are configured, they are used; otherwise, the names are used.
    def accountCompany = '';
    def accountID = message.getProperty('X-Account-ID');
    def accountName = message.getProperty('X-Account-Name');
    def companyID = message.getProperty('X-Company-ID');
    def companyName = message.getProperty('X-Company-Name');
    

    if (accountID == null || accountID == '' || accountID == '<FSM_Account_ID>' || companyID == null || companyID == '' || companyID == '<FSM_Company_ID>') {
        accountCompany = 'account='+accountName+'&company='+companyName+'&';
        message.setHeader('X-Account-Name', accountName);
        message.setHeader('X-Company-Name', companyName);
    } else {
        accountCompanyUser = '';
        message.setHeader('X-Account-ID', accountID);
        message.setHeader('X-Company-ID', companyID);
    }
    message.setProperty('AccountCompany', accountCompany);
    
    return message;
}