import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {
    def body = message.getBody(java.lang.String)
    def query = new XmlParser().parseText(body)
    def valueMappingApi = ITApiFactory.getApi(ValueMappingApi.class, null)

    query.MaterialStockReplicateMsg.each { psMessage ->
        psMessage.MaterialStock.each { ps ->
            def mcXML = new XmlParser().parseText("<FSMMultiCompany></FSMMultiCompany>")
            def map = message.getProperties();
            message.setProperty("Flag1","1")
            
            //def psRoleCode = ps.Role[0].RoleCode.text();
            def fsmFromValueMap = null;
            
            /*set the FSM company and account as the default configured for the Org PS*/
            /*if(psRoleCode == "BUP004"){
                def fsmAccountID = map.get("X-Account-ID") ?: "NA"
                def fsmCompanyID = map.get("X-Company-ID") ?: "NA"
                fsmFromValueMap = fsmAccountID + "|" + fsmCompanyID
                def fsmXml = new XmlParser().parseText("<FSMCompany>${fsmFromValueMap}</FSMCompany>")
                mcXML.append(fsmXml)
            }

            /*identify the FSM company details using Produt Stock Plant rule type*/
            //ps.Customer.Plant.each { pa ->
                def Plant = "${ps.Plant.text()}"
                def psKeyMap = "PRODUCTSTOCK|||Plant|${Plant}"

                fsmFromValueMap = valueMappingApi.getMappedValue('S4H', 'KeyMap', psKeyMap, 'FSM', 'AccountIDCompanyID')
                message.setProperty("VMValue",fsmFromValueMap)
                if(fsmFromValueMap){
					def fsmXml = new XmlParser().parseText("<FSMCompany>${fsmFromValueMap}</FSMCompany>")
					mcXML.append(fsmXml)
				}
            }
  

           /* def processAccountingInformation = { role, keyType, key ->
                ps."${role}".AccountingInformation.each { acc ->
                    def psKeyMap = "PRODUCTSTOCK|${psRoleCode}|PlantArea|${PlantArea}"
                    fsmFromValueMap = valueMappingApi.getMappedValue('S4H', 'KeyMap', psKeyMap, 'FSM', 'AccountIDCompanyID')
                    if(fsmFromValueMap){
					    def fsmXml = new XmlParser().parseText("<FSMCompany>${fsmFromValueMap}</FSMCompany>")
					    mcXML.append(fsmXml)
				    }
				    else {
				        	def fsmXml = new XmlParser().parseText("<FSMCompany>NA|NA</FSMCompany>")
				mcXML.append(fsmXml)
				    }
                }
            }
            
            /*identify the FSM company details using Customer & Supplier CompanyID rule type*/
            /*processAccountingInformation("Customer", "COMPANYCODE", "CompanyID");
            processAccountingInformation("Supplier", "COMPANYCODE", "CompanyID");
            
			if (!mcXML.FSMCompany)
			{
				def fsmXml = new XmlParser().parseText("<FSMCompany>NA|NA</FSMCompany>")
				mcXML.append(fsmXml)
			}
            */
            ps.append(mcXML)
        }
    

    def FSMCompanyData = XmlUtil.serialize(query)
    message.setBody(FSMCompanyData)
    return message
}
