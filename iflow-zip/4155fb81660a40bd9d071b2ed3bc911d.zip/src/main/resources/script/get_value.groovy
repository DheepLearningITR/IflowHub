import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String.class) as String
    def jsonSlurper = new JsonSlurper()
    try {
        def result = jsonSlurper.parseText(body)
        if (result.containsKey('value') && result.value instanceof List && !result.value.isEmpty()) {
            message.setProperty('isComplaintFound', 'true')
        } else {
            message.setProperty('isComplaintFound', 'false')
        }
        message.setProperty('statusCode', message.getHeaders().get('CamelHttpResponseCode').toString())
        message.setProperty('errorMessage', '')
    } catch (Exception e) {
        message.setProperty('isComplaintFound', 'false')
        message.setProperty('statusCode', message.getHeaders().get('CamelHttpResponseCode').toString())
        message.setProperty('errorMessage', 'Error processing response: ' + e.getMessage())
    }

    return message
}
