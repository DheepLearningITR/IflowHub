import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

 
def Message processData(Message message) {
 
	def body = message.getBody(String.class) as String;
    def jsonSlurper = new JsonSlurper();
    try{
         def result = jsonSlurper.parseText(body);
         def deliveryItemList = []
         def deliveryItemListJson
        if(result.A_ReturnsDeliveryHeader.A_ReturnsDeliveryHeaderType.to_DeliveryDocumentItem.A_ReturnsDeliveryItemType instanceof ArrayList)
        {
            deliveryItemList = result.A_ReturnsDeliveryHeader.A_ReturnsDeliveryHeaderType.to_DeliveryDocumentItem.A_ReturnsDeliveryItemType
        }
        else
        {
            deliveryItemList.add(result.A_ReturnsDeliveryHeader.A_ReturnsDeliveryHeaderType.to_DeliveryDocumentItem.A_ReturnsDeliveryItemType)
        }
        deliveryItemListJson  = new JsonBuilder(deliveryItemList)
            def customerReturnNumber = deliveryItemList[0].ReferenceSDDocument
            message.setProperty("deliveryDocumentItemResult" , deliveryItemListJson)
            message.setProperty("customerReturnNumber",customerReturnNumber)
            message.setProperty("filterByStatus", "\$filter=(items/identifier eq '${customerReturnNumber}')")
            message.setProperty("errorMessage" , "")
            message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString())
    }
    catch(Exception e)
    {
        message.setProperty("deliveryDocumentItemResult" , [])
        message.setProperty("errorMessage" , "")
        message.setProperty("customerReturnNumber" , "")
        message.setProperty("outboundDelivery" , "")
        message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString())
    }
    return message;
}
