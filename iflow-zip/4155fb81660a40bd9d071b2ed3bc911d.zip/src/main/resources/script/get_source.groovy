import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(String.class)
    def destination = null
    message.setProperty("selectQuery","\$select=to_DeliveryDocumentItem/ReferenceSDDocumentItem,to_DeliveryDocumentItem/DeliveryDocumentItem,to_DeliveryDocumentItem/CreationDate,to_DeliveryDocumentItem/ReferenceSDDocument,to_DeliveryDocumentItem/Material,to_DeliveryDocumentItem/ActualDeliveryQuantity,to_DeliveryDocumentItem/DeliveryQuantityUnit")

    try {
        def xmlParser = new XmlSlurper().parseText(body) 
        def source = xmlParser.source.text()
        message.setProperty("SourceValue", source) // Log for debugging
        if (source && source.contains("/")) {
            destination = source.substring(source.lastIndexOf("/") + 1).trim()
        }
        message.setProperty("Destination", destination)  

    } catch (Exception e) {
        message.setProperty("Destination", "")  
        message.setProperty("ErrorMessage", e.getMessage()) // Log any error
    }

    return message
}