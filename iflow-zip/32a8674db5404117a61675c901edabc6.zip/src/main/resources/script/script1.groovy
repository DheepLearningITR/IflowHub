
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    /*Setting CSRF cookies*/
    def headers = message.getHeaders();
    def cookie = headers.get("set-cookie");
    StringBuffer bufferedCookie = new StringBuffer();
    for (Object item : cookie) 
    {
        bufferedCookie.append(item + "; ");      
    }
    message.setHeader("cookie", bufferedCookie.toString());
    
    return message;
}