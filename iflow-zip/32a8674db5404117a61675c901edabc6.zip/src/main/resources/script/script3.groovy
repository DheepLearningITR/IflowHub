import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Setting sap-language and ERP client
       def body;
       def map = message.getProperties();
       def sap_client = map.get("sap-client");
       def sap_language = map.get("sap-language");
       body = "--cpi\r\nContent-Disposition: form-data; name=\"sap-client\"\r\n\r\n"+sap_client+"\r\n--cpi--\r\n" + "--cpi\r\nContent-Disposition: form-data; name=\"sap-language\"\r\n\r\n"+sap_language+"\r\n--cpi--";

       message.setBody(body);
       return message;
}