/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def messageLog = messageLogFactory.getMessageLog(message);
        	
       int count = 0;
       StringBuilder output = new StringBuilder();
       def body =  message.getBody(java.lang.String) as String
       
       //Processed_Error_Records
       def map = message.getProperties();
       def requestData = map.get("originalPayload");
        def errorRecordCount = 0

       //HashSet<Integer> set = new HashSet<Integer>();
       HashMap<Integer,String> mapError = new HashMap<Integer,String>();

       //Set Error records
       def list = new groovy.util.XmlSlurper().parseText(body);
       list.children().each { tag -> 
            count++;
            if("ERROR".equals(tag.status.text())){
                String errorMessage = tag.message.text() + "";
                errorMessage = errorMessage.replace(","," ");
                errorMessage = errorMessage.replace("\n"," ").replace("\r","");
                mapError.put(count,"Error Code-" + tag.httpCode.text() + "/Error Message-"  + errorMessage);
                errorRecordCount = errorRecordCount + 1;
            }
       }
       
       count = 0;
       if(mapError.size() > 0){
          requestData = requestData.replaceAll("\\<\\?xml(.+?)\\?\\>","");
           def list1 = new groovy.util.XmlSlurper().parseText(requestData);
           list1.children().each { tag -> 
                count++;
                if(mapError.containsKey(count)){
                        /*tag.children().each{ innerTag ->
                            output.append(innerTag.text());
                            output.append(",");
                        }*/
                          output.append("Bank key-");
                        output.append(tag.cust_bankKey.text()).append(",");
                  
                       if("ERROR".equals(tag.processStatus.text())){
                            output.append("Error Code").append("-");
                            output.append(tag.processStatus.text()).append("/Error Message-");
                            output.append(tag.processMessage.text());
                       }else{
                           output.append(mapError.get(count));
                       }
                       output.append("\n")
                }
           }
  
       }
	   
	  def EnableLogging = map.get("P_EnableLogging");

    if(EnableLogging =='true') {
       messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment");
       messageLog.addAttachmentAsString("ErrorReport:", output.toString(), "text/plain");
	}
	      message.setBody(output.toString());

       return message;
}