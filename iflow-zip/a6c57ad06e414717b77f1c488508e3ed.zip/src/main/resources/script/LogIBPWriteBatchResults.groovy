/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    def headers = message.getHeaders();
	    
	    def headerWriteBatches = new StringReader(headers.get('IBPWriteBatches'));
        def xmlBatches = new XmlSlurper().parse(headerWriteBatches);
        
        def bodyAsString = message.getProperty('ShortenedBody');
        def bodyReader = new StringReader(bodyAsString);
        def xmlResponses = new XmlSlurper().parse(bodyReader);
        
	    def batches = '';
	    def batchesProcessedWithErrors = '';
	    def batchesUnprocessed = '';
	    xmlResponses.children()?.IBPWriteBatch.each { 
	        batches += (batches == '' ? '' : ',') + it.@Id.text();
	        if (it?.@WorstProcessingStatus == 'PROCESSED_WITH_ERRORS') batchesProcessedWithErrors += (batchesProcessedWithErrors == '' ? '' : ',') + it.@Id.text();
	        if (!(it?.@WorstProcessingStatus == 'PROCESSED_WITH_ERRORS' || it?.@WorstProcessingStatus == 'PROCESSED')) batchesUnprocessed += (batchesUnprocessed == '' ? '' : ',') + it.@Id.text();
	    }; 
	    if (batches!='') message.setHeader('IBPbatches', batches);
/*	    def batchesProcessedWithErrors = xmlResponses?.Batch.findAll{it.parent()@WorstProcessingStatus == 'PROCESSED_WITH_ERRORS'}.@Id.text().join(', ');
	    def batchesUnprocessed = xmlResponses?.Batch.findAll{ it.@WorstProcessingStatus != 'PROCESSED' && it.@WorstProcessingStatus == 'PROCESSED_WITH_ERRORS'}.@Id.text().join(', ');

	    message.setHeader('IBPbatches', batches);
	    */
	    if (batchesProcessedWithErrors!='') messageLog.addCustomHeaderProperty('IBPBatchesWithValidationErrors', batchesProcessedWithErrors);
	    if (batchesUnprocessed!='') messageLog.addCustomHeaderProperty('IBPWriteBatchesUnprocessed', batchesUnprocessed);
	    
	    def numberOfBatches = xmlBatches?.IBPWriteBatch.size();
	    def numberOfSuccessfullBatches = xmlResponses.children()?.IBPWriteBatch.findAll{it.@WorstProcessingStatus == 'PROCESSED'}.size();
	    def numberOfContentErrorBatches = xmlResponses.children()?.IBPWriteBatch.findAll{it.@WorstProcessingStatus == 'PROCESSED_WITH_ERRORS'}.size();
	    message.setHeader('IBPWriteProcessingWorstStatus', (numberOfSuccessfullBatches == numberOfBatches) ? 'PROCESSED' : (numberOfSuccessfullBatches + numberOfContentErrorBatches == numberOfBatches) ? 'PROCESSED_WITH_ERRORS' : 'unprocessed');
	    def statusItems = xmlResponses.'_-IBP_-INTIS_GET_PP_STATUS.Response'.'ET_PP_STATUS'.item;
	    xmlResponses.children()?.IBPWriteBatch.each { messageLog.addCustomHeaderProperty("IBP Write Batch Times", 'id:' + it.@Id + ', created:' + it.@CreatedAt + ', scheduled:' + it.@ScheduledAt + ', started:' + it.@ProcessingStartedAt + ', ended:' + it.@ProcessingEndedAt) }
	    xmlResponses.children()?.IBPWriteBatch.each { messageLog.addCustomHeaderProperty("IBP Write Batch Details", 'id:' + it.@Id + ', key:' + it.@Key + ', destination:' + it.@Destination + (it.@Name!=''? ', name:' : '') + it.@Name + (it.@CreatedBy!=''? ', createdBy:' : '') + it.@CreatedBy  ) }
	    xmlResponses.children()?.IBPWriteBatch.each { messageLog.addCustomHeaderProperty("IBP Write Batch Status", 'id:' + it.@Id + ', worstProcessingStatus:' + it.@WorstProcessingStatus + ', scheduleStatus:' + it.@ScheduleStatus ) };
	    xmlResponses.children()?.IBPWriteBatch?.Files?.File.each { messageLog.addCustomHeaderProperty("IBP Write Batch File", 'batch:' + it.parent().parent().@Id + ', name:' + it.@Name + ', count:' + it.@Count + ', status:' + it.@Status + (it.@ErrorCount!='' ? ', errorCount:' : '') + it.@ErrorCount) };
	    xmlResponses.children()?.IBPWriteBatch?.Files?.File.findAll {it.@FirstError!=''}.each{ addLogCustomHeaderWithSplit(messageLog,"1st Validation Error " + it.parent().parent().@Id.text() + ',' + it.@Id.text(), it.@FirstError.text()) };
	    xmlResponses.children()?.IBPWriteBatch?.Files?.File.findAll {it.@FirstErrorTitle!=''}.each { addLogCustomHeaderWithSplit(messageLog,"1st Long Validation Error " + it.parent().parent().@Id.text() + ',' + it.@Id.text(), it.@FirstErrorTitle.text()) };


	    xmlResponses.children()?.IBPWriteBatch?.ScheduleException.each { addLogCustomHeaderWithSplit(messageLog,"IBP Schedule Exeption " + it.parent().@Id.text(), it.text()) };
	    xmlResponses.children()?.IBPWriteBatch?.ScheduleException.findAll {it.@FailureEndpoint!=''}.each { addLogCustomHeaderWithSplit(messageLog,"IBP Schedule Failure Endpoint " + it.parent().@Id.text(), it.@FailureEndpoint.text()) };
	    xmlResponses.children()?.IBPWriteBatch?.ScheduleException.findAll {it.@FailureRouteId!=''}.each { addLogCustomHeaderWithSplit(messageLog,"IBP Schedule Failure Route ID " + it.parent().@Id.text(), it.@FailureRouteId.text()) };
	    xmlResponses.children()?.IBPWriteBatch?.ScheduleResponse.each {
	        it.Messages.children().eachWithIndex { it2, index -> addLogCustomHeaderWithSplit(messageLog,"IBP Schedule " + it.@Id.text() + ' ' + it2.@Type.text() + ' ' + (index +1).toString(), it2.text()) }
	    }

	    xmlResponses.children()?.IBPWriteBatch?.GetStatusException.each { addLogCustomHeaderWithSplit(messageLog,"IBP Get Status Exception " + it.parent().@Id.text(), it.text()) };
	    xmlResponses.children()?.IBPWriteBatch?.GetStatusException.findAll {it.@FailureEndpoint!=''}.each { addLogCustomHeaderWithSplit(messageLog,"IBP Get Status Failure Endpoint " + it.parent().@Id.text(), it.@FailureEndpoint.text()) };
	    xmlResponses.children()?.IBPWriteBatch?.GetStatusException.findAll {it.@FailureRouteId!=''}.each { addLogCustomHeaderWithSplit(messageLog,"IBP Get Status Failure Route ID " + it.parent().@Id.text(), it.@FailureRouteId.text()) };
	    xmlResponses.children()?.IBPWriteBatch.each {
	        it.Messages.children().eachWithIndex { it2, index -> addLogCustomHeaderWithSplit(messageLog,"IBP Process " + it.@Id.text() + ' ' + it2.@Type.text() + ' ' + (index +1).toString(), it2.text()) }
	    }
	    
	    messageLog.addAttachmentAsString('IBPWriteProcessingResults', bodyAsString, 'text/xml')	
	}
	return message;
}

def void addLogCustomHeaderWithSplit(MessageLog messageLog, String headerName, String content) {
    def messageLength = content.length();
    if (messageLength<=198) messageLog.addCustomHeaderProperty(headerName, content);
    else {
        int i = 0;
        for (int j = 0; j < messageLength;j += 198) {
            def k = j + 198;
            i++;
            messageLog.addCustomHeaderProperty(headerName + '.' + i.toString(), content.substring(j,k<=messageLength?k:messageLength));
        }
    }
}




def Message raiseIBPErrorMessage(Message message) {
	def headers = message.getHeaders();
	def ibpStep = headers.get("IBPStep");	
	throw new Exception("Error in IBP step ${ibpStep}");
	return message;
}

def Message setLogCustomHeaders(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    def headers = message.getHeaders();
	    String emailBody = headers.get('emailBody') + "\r\nLog custom headers:";
    	def logCustomHeaders = headers.get("LogCustomHeaders");
    	def logCustomProperties = headers.get("LogCustomProperties");
    	def logAttachmentHeaders = headers.get("LogAttachmentHeaders");
	    if(logCustomHeaders!=null) {
    	    logCustomHeaders.tokenize(',').each() {
    	        setLogCustomHeader(headers, messageLog, it);		
    	        emailBody += "\r\n\${it}: ${headers.get(it)}"
    	    }
	    }
	    if(logCustomProperties!=null) {
    	    logCustomProperties.tokenize(',').each() {
    	        setLogCustomProperty(message, messageLog, it);
    	        emailBody += "\r\n\${it}: ${message.getProperty(it)}"
    	    }
	    }
	    if(logAttachmentHeaders!=null) {
    	    logAttachmentHeaders.tokenize(',').each() {
    	        setLogAttachmentHeader(headers, messageLog, it);		
    	    }
	    }
	    
	}
	return message;
}

def void setLogCustomHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addCustomHeaderProperty(headerName, header.toString());		
    }
}

def void setLogCustomProperty(Message message, MessageLog messageLog, String propertyName) {
    
	def property = message.getProperty(propertyName);		
	if(property!=null){
		messageLog.addCustomHeaderProperty(propertyName, property.toString());		
    }
}

def void setLogAttachmentHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addAttachmentAsString(headerName, header.toString(), 'text/plain')	
    }
}
