/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import com.sap.it.api.mapping.*;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	
	def batches = message.getProperty('IBPWriteProcessShortenedBody');
    def batchesReader = new StringReader(batches);
    def xmlBatches = new XmlSlurper().parse(batchesReader);
	message.setProperty('IBPNumberOfBatches',xmlBatches.children().size());

	if(messageLog != null){

	    xmlBatches.children()?.IBPWriteBatch?.@Id.each { messageLog.addCustomHeaderProperty('IBP Write Batch ID', it.text()) };
	    xmlBatches.children()?.IBPWriteBatch?.@Key.each { messageLog.addCustomHeaderProperty('IBP Write Batch Key', it.text()) };
	    xmlBatches.children()?.IBPWriteBatch.each {}collect{it.@Destination.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Destination", it2) };

        messageLog.addAttachmentAsString("IBPWriteBatchesBeforeProcessing" , batches, "text/xml");
	}
	return message;
}
