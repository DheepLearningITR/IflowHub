import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	
	def messageLog = messageLogFactory.getMessageLog(message);
	def body = message.getBody(java.io.Reader);
    def xmlResponses = new XmlSlurper().parse(body);
    def batchWithErrors = xmlResponses?.Batch.findAll{it.@WorstProcessingStatus != 'PROCESSED'}.find{it.@WorstProcessingStatus != 'PROCESSED_WITH_ERRORS'}?.@Id.text();
	throw new Exception("Technical errors occurred during processing of data written to IBP Batch " + batchWithErrors);  	
	
	return message;
}
