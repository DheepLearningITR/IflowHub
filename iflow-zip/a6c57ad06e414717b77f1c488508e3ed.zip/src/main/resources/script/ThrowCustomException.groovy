import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.msglog.*;

def Message processData(Message message) {
	
	def body = message.getBody(java.io.Reader);
    def xmlResponses = new XmlSlurper().parse(body);
	def messageLog = messageLogFactory.getMessageLog(message);


	HashMap<String, HashMap<String, String[]>> destinationAndbatchIDByCause = [:].withDefault { key -> [:] }
	//Get all Destination and Batch combinations for Batches that have a GetStatusException node grouped by the Exceptions Cause Attribute
	//GetStatusException node occurs when batch get status request fails
	xmlResponses.children()?.IBPWriteBatch?.GetStatusException.each{ 
		String destination = it.parent().@Destination.text()
		String batchID = it.parent().@Id.text()
		String cause = it.@Cause.text() ?: 'STATUS'
		if(!destinationAndbatchIDByCause[cause]){
			HashMap<String, String[]> tempMap = [:]
			tempMap.put(destination, [batchID]) 
			destinationAndbatchIDByCause.put(cause, tempMap) 
		}
		else{
			if (!destinationAndbatchIDByCause[cause][destination]) { 
				destinationAndbatchIDByCause.get(cause).put(destination, [batchID]) 
			}
			else { 
				destinationAndbatchIDByCause.get(cause).get(destination).add(batchID) 
			}
		}	
	}

	if(messageLog != null){	
		if(!destinationAndbatchIDByCause.isEmpty()){
			
			//Throw exception and add logs for the worst cause
			switch (destinationAndbatchIDByCause) {
				case {destinationAndbatchIDByCause.containsKey("Timeout")}:

					String batchTimeoutMessage = "Status request timed out for the following destination and batch combination(s): " + formatMapReturn(destinationAndbatchIDByCause.get("Timeout"),"Timeout") + ". Post processing may still be running, check in the target IBP system(s)"

					throw new TimeoutException(batchTimeoutMessage);   

					break
				default:
					
					break
			}
			
		}
	}

	return message;
}

def String formatMapReturn(HashMap<String, String[]> inputMap,String inputkey){
	String result = ""
	inputMap.each{
		key, array ->
		result += key +': '+ array.join(';') +' '
	}
	return result
}

public class TimeoutException extends Exception {
  public TimeoutException(String message) {
    super(message);
  }
}
