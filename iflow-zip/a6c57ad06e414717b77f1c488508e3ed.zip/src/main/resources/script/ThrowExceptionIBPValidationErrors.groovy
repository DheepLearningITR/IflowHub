import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	
	def messageLog = messageLogFactory.getMessageLog(message);
	def body = message.getBody(java.io.Reader);
    def xmlResponses = new XmlSlurper().parse(body);
    def batchWithErrors = xmlResponses?.Batch.find{it.@WorstProcessingStatus != 'PROCESSED'}?.@Id.text();
	throw new Exception("Validation errors occurred during processing of data written to IBP Batch " + batchWithErrors);  	
	
	return message;
}
