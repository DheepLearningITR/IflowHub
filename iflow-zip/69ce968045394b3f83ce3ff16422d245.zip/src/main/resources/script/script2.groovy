import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

     def body = message.getBody(String.class);
     message.setBody(body.replaceAll("&#0;", ""));
     return message;
}