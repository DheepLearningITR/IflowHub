import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;
import groovy.xml.XmlUtil;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;



def Message processData(Message message) {

	def pmap = message.getProperties();
	
	def body = message.getBody(java.lang.String) as String;
	def headers = message.getHeaders() as Map<String, Object>;
	def properties = message.getProperties() as Map<String, Object>;
	def serviceCallNodeList = properties.get("original_payload") as NodeList;
    StringWriter buf = new StringWriter();
    def l = 0;
	while(l < serviceCallNodeList.getLength()){
	    Node elem = serviceCallNodeList.item(l);//Your Node
        Transformer xform = TransformerFactory.newInstance().newTransformer();
        xform.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes"); // optional
        xform.setOutputProperty(OutputKeys.INDENT, "yes"); // optional
        xform.transform(new DOMSource(elem), new StreamResult(buf));
        l++;
	}
	
	def originalPayload = buf.toString();
	
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null ) {
		messageLog.addAttachmentAsString("Log - Payload" , "\n serviceCall \n ----------   \n" + buf.toString() +
		                                                   "\n Body \n ----------  \n\n" + body,
		                                                   "text/xml");
	}
	
    def serviceCall = new XmlSlurper().parseText(originalPayload)
    def sapOrders = new XmlSlurper().parseText(body)
    
    
    Closure<MarkupBuilder> buildRequirements = { MarkupBuilder builder, String skillId ->
            builder.'requirements'{
            builder.'skill'{
                builder.'id'(skillId)
            }
            builder.'mandatory'(false)
            builder.'inherited'(false)
        
            }
    
        return builder
    }
    
    def consignmentEntries = sapOrders.SAPOrder.consignments.Consignment[0].consignmentEntries
    def serviceOrderId = sapOrders.SAPOrder.serviceOrderId.text()
    def size = consignmentEntries.ConsignmentEntry.size()
    int i = 0
    
    while(i< size){
        println i + ' ' + consignmentEntries.ConsignmentEntry[i].sapOrderEntryRowNumber.text()
        def entryNumber = consignmentEntries.ConsignmentEntry[i].sapOrderEntryRowNumber.text()
        def skills = consignmentEntries.ConsignmentEntry[i].orderEntry.AbstractOrderEntry.product.Product.skills
        def skillsCount =  consignmentEntries.ConsignmentEntry[i].orderEntry.AbstractOrderEntry.product.Product.skills.SapServiceSkill.size()
        def externalId = serviceOrderId +"/"+ entryNumber
        def activity = serviceCall.activities.find{it.externalId.text() == externalId}
        int j=0
        while(j < skillsCount){
            def skillId = skills.SapServiceSkill[j].code.text()
            def xmlWriter = new StringWriter()
            def xmlMarkup = new MarkupBuilder(xmlWriter)
            buildRequirements(xmlMarkup,skillId) 
            def requirements = new XmlSlurper().parseText(xmlWriter.toString())
            activity.appendNode(requirements)
            j++
        }
        i++
    }
    
    String outxml = XmlUtil.serialize( serviceCall )
    outxml=outxml.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
    message.setProperty("original_payload", outxml)
	
	return message;
}