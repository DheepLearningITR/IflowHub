import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

String body = message.getBody(String.class);
def propMap = message.getProperties();
String CIStackTrace = propMap.get("CIStackTrace");
if(CIStackTrace.contains("Caused"))
{
    int index1=CIStackTrace.indexOf("Caused");
    int totalLength= CIStackTrace.length();
    int len= totalLength-index1;
    String errorMessage;
    if (len >501)
        errorMessage = CIStackTrace.substring(index1,index1+500);
    else 
        errorMessage = CIStackTrace.substring(index1,totalLength-1);
    errorMessage = errorMessage.replaceAll("[^A-Za-z0-9\\-\\=\\,.\\<\\>\\% /]", "")
    errorMessage = errorMessage.replaceAll("[\\t\\n\\r]+"," ");
    message.setProperty("FinalCIError" , errorMessage);
}
else
{
    message.setProperty("FinalCIError" , propMap.get("CIException"));
}
return message;
}