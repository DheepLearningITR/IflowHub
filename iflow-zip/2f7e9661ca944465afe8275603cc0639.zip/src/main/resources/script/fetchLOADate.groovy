import com.sap.it.api.mapping.*

def String extractDate(String input) {
    if (input == null || input.isEmpty()) {
        return ""
    }
    // Use a regular expression to find the LOAStartDate value
    def matcher = input =~ /LOAStartDate:(\d{4}-\d{2}-\d{2})/
    if (matcher.find()) {
        return matcher[0][1] // Return the captured group (date)
    }
    return "" // Return empty if no match found
}
def String extractEndDate(String input) {
    if (input == null || input.isEmpty()) {
        return ""
    }
    
    try {
        def pattern = /EndEffectivedate:\s*([\d-]+)/
        def matcher = input =~ pattern
        
        if (matcher.find()) {
            return matcher.group(1).trim()
        }
    } catch (Exception e) {
        return ""
    }
    return ""
}
 // Import required package
def String fetchName(String combinedValue) {
    // Check if the input is valid
    if (combinedValue == null || combinedValue.isEmpty()) {
        return ""
    }

    // Use a regular expression to extract the Name value until ', State'
    def matcher = combinedValue =~ /Name:(.*), State:/
    if (matcher.find()) {
        return matcher[0][1].trim() // Return the captured Name value
    }

    return "" // Return a default message if Name is not found
}


def String extractAddressState(String input) {
    if (input == null || input.isEmpty()) {
        return ""
    }
    // Use a regular expression to find the value for "State"
    def matcher = input =~ /State:([^,]*)/
    if (matcher.find()) {
        return matcher[0][1].trim() // Return the captured group (value)
    }
    return "" // Return empty if no match found
}

def String extractAddressCountry(String input) {
    if (input == null || input.isEmpty()) {
        return ""
    }
    // Use a regular expression to find the value for "Country"
    def matcher = input =~ /Country:([^,]*)/
    if (matcher.find()) {
        return matcher[0][1].trim() // Return the captured group (value)
    }
    return "" // Return empty if no match found
}

def String extractEndEffectiveDate(String input) {
    if (input == null || input.isEmpty()) {
        return ""
    }
    // Use a regular expression to find the value for "EndEffectivedate"
    def matcher = input =~ /EndEffectivedate:\s*([^,]*)/
    if (matcher.find()) {
        return matcher[0][1].trim() // Return the captured group (value)
    }
    return "" // Return empty if no match found
}

def String extractTerminationEvents(String input) {
    if (input == null || input.isEmpty()) {
        return ""
    }
    // Use a regular expression to find the value for "TerminationEvents"
    def matcher = input =~ /TerminationEvent:([^,]*)/
    if (matcher.find()) {
        return matcher[0][1].trim() // Return the captured group (value)
    }
    return "" // Return empty if no match found
}
def String extractBusinessPhone(String input) {
    if (input == null || input.isEmpty()) {
        return ""
    }
    // Use a regular expression to find the value for "buisnessphn"
    def matcher = input =~ /buisnessphn:\s*([^,]*)/
    if (matcher.find()) {
        return matcher[0][1].trim() // Return the captured group (value)
    }
    return "" // Return empty if no match found
}
def String extractLastName(String input) {
    if (input == null || input.isEmpty()) {
        return ""
    }
    def matcher = input =~ /lastname:\s*([^,]*)/
    if (matcher.find()) {
        return matcher[0][1].trim()
    }
    return ""
}
def String extractFirstName(String input) {
    if (input == null || input.isEmpty()) {
        return ""
    }
    def matcher = input =~ /firstname:\s*([^,]*)/
    if (matcher.find()) {
        return matcher[0][1].trim()
    }
    return ""
}
def String extractEmail(String input) {
    if (input == null || input.isEmpty()) {
        return ""
    }
    def matcher = input =~ /email:\s*([^,]*)/
    if (matcher.find()) {
        return matcher[0][1].trim()
    }
    return ""
}




