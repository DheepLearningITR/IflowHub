import com.sap.aii.mapping.api.*

def String transform(String input) {
    if (input == null || input.trim().isEmpty()) {
        return "0.0" // Default value to avoid casting issues
    }
    try {
        def value = Math.abs(Double.parseDouble(input))
        def formattedValue = value == (int) value ? String.format("%.0f", value) : value.toString()
        return formattedValue
    } catch (Exception e) {
        return "" // Fallback for non-numeric values
    }
}
