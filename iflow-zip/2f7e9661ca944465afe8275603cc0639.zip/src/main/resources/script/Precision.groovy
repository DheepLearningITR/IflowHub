import com.sap.it.api.mapping.*
import java.math.BigDecimal
import java.math.RoundingMode

// UDF Method
def String formatNumber(String input, MappingContext context) {
    if (input == null || input.trim().isEmpty()) {
        return ""
    }
    
    try {
        BigDecimal number = new BigDecimal(input)
        number = number.setScale(2, RoundingMode.HALF_UP)
        return number.toPlainString()
    } catch (Exception e) {
        return ""
    }
}
