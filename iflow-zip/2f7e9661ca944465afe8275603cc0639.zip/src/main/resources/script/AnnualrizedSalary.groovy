import com.sap.it.api.mapping.*

def String fetchStartDate(String combinedValue) {
    if (combinedValue == null || combinedValue.isEmpty()) {
        return ""
    }
    // Update the regex to capture everything before the 'T'
    def matcher = combinedValue =~ /startDate:\s*([^\sT,]*)/
    if (matcher.find()) {
        return matcher[0][1].trim() // Return the date part before 'T'
    }
    return ""
}


def String fetchAmount(String combinedValue) {
    if (combinedValue == null || combinedValue.isEmpty()) {
        return ""
    }
    def matcher = combinedValue =~ /amount:\s*([^,]*)/
    if (matcher.find()) {
        return matcher[0][1].trim()
    }
    return ""
}


def String fetchStandardHours(String combinedValue) {
    // Check if the input is null or empty
    if (combinedValue == null || combinedValue.trim().isEmpty()) {
        return ""
    }

    // Use regular expression to match the standardHours pattern
    def matcher = combinedValue =~ /standardHours:\s*([^,]*)/
    
    // If a match is found, return the matched value after trimming spaces
    if (matcher.find()) {
        return matcher[0][1].trim()
    }

    // If no match found, return an empty string or a custom message
    return ""
}




def String calculateStartDate(String Anualarized, String SWH, String Anual_Date) {
    if (Anualarized != "0") {
        if (SWH != "0") {
            return Anual_Date
        } else {
            return Anual_Date
        }
    } else {
        return Default_Date
    }
}



def String calculateAmount(String Anualarized, String SWH) {
    // Check for null or empty values
    if (Anualarized == null || Anualarized.trim().isEmpty() || SWH == null || SWH.trim().isEmpty()) {
        return ""  // Return default value if any input is empty
    }

    // Check if the inputs are valid numbers (not zero or invalid)
    try {
        double annualizedValue = Double.parseDouble(Anualarized)
        double swhValue = Double.parseDouble(SWH)

        // If the values are valid and non-zero
        if (annualizedValue != 0 && swhValue != 0) {
            return (annualizedValue / 52 / swhValue).toString()
        } else {
            return ""  // Return "0" if either value is zero
        }
    } catch (NumberFormatException e) {
        // Handle invalid number format (non-numeric values)
        return ""  // Return "0" if there's a parsing error
    }
}



def String calculateAnualarized1(String Anualarized) {
    if (Anualarized != "0") {
        return Anualarized
    } else {
        return ""
    }
}

