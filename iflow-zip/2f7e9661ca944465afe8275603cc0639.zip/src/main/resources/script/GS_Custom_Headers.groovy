import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat

def Message processData(Message message) {
    
    def sftpFileName = message.getProperty("FileName")

    if (sftpFileName) {
        // Get current timestamp in yyyyMMdd format
        def timestamp = new SimpleDateFormat("yyyyMMdd").format(new Date())

        // Append timestamp and ensure .csv extension
        def updatedFileName = "${sftpFileName}_${timestamp}.csv"

        // Set the modified filename in the header
        message.setHeader("Final_FinalName", updatedFileName)

        // Log the updated filename as a custom header property
        def messageLog = messageLogFactory.getMessageLog(message)
        if (messageLog != null) {
            messageLog.addCustomHeaderProperty("Filename", updatedFileName)
        }
    }

    return message
}
