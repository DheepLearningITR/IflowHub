import com.sap.it.api.mapping.*

def String fetchValueByKey(String cacheName, String key, MappingContext context) {
    // Retrieve the HashMap from the header
    def cache = context.getHeader(cacheName) as Map

    // Check if the cacheEntity exists
    if (cache == null) {
        return ""
    }

    // Ensure key lookup works even if there are spaces
    def trimmedKey = key?.trim()
    def value = cache.find { it.key.trim() == trimmedKey }?.value

    // Return the value or a default message if the key is not found
    return value ?: ""
}
