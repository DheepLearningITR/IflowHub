import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat

def Message processData(Message message) {
    def properties = message.getProperties()
    def jobStart = properties.get("JobStart")
    def startDate = properties.get("StartDate")
    def test = properties.get("EndDate")
    def country = properties.get("Country")
    def termiDate = properties.get("Termination_Days")
    def currentDateStr = properties.get("currentTime") // Get current date as String

    def inputFormat = new SimpleDateFormat("yyyy-MM-dd")

    // Convert input dates safely
    def currentDate = currentDateStr ? inputFormat.parse(currentDateStr) : null
    def jobStartDate = jobStart ? inputFormat.parse(jobStart) : null
    def startDateDate = startDate ? inputFormat.parse(startDate) : null

    def check = false

    // Check if jobStartDate and startDateDate are not equal to currentDate
    if (jobStartDate != null && startDateDate != null && currentDate != null) {
    if (!jobStartDate.after(currentDate) && !startDateDate.after(currentDate)) {
        check = true;
    }
}


    // Convert and evaluate SecondCheck condition
    def testDate = test ? inputFormat.parse(test) : null
    def termiDateObj = termiDate ? inputFormat.parse(termiDate) : null
    def CountryCheck = (country == "USA" || country == "PRI")

    def secondCheck = (testDate == null || (termiDateObj != null && testDate.after(termiDateObj)))

    message.setProperty("Check", check)
    message.setProperty("SecondCheck", secondCheck)
    message.setProperty("CountryCheck", CountryCheck)

    return message
}
