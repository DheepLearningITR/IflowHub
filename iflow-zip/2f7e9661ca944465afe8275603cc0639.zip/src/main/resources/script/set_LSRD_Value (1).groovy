import com.sap.gateway.ip.core.customdev.util.Message


def Message processData(Message message) {
    
    def headers = message.getHeaders()

    String checkManual = headers.get("ManualRun_V")
    String ManualLastModified = headers.get("ManualLastRunDate")
    def DynamicLastModified = headers.get("Last_RunDate")

    // Set Last_Run based on ManualRun_V flag
    if (checkManual == "Y") {
        message.setHeader("Last_Run", ManualLastModified)
        // message.setHeader("SendtoSFTP_V", "N")
    } else {
        message.setHeader("Last_Run", DynamicLastModified)
        
    }


    return message
}
