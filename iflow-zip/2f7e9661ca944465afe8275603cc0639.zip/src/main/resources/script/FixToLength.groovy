import com.sap.it.api.mapping.*;
import java.util.Map;

public String fixToLength(String input, int length) {
    // Check if input is null
    if (input == null) {
        input = "";
    }

    // Pad the input with spaces if shorter than the desired length
    StringBuilder result = new StringBuilder(input);
    while (result.length() < length) {
        result.append(" ");
    }

    // Truncate the string if it exceeds the desired length
    if (result.length() > length) {
        return result.substring(0, length);
    }

    return result.toString();
}
