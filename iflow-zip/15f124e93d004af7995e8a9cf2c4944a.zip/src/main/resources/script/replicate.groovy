import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.json.JsonOutput;


def Message parseHeaders(Message message) {

	def map = message.getHeaders();

    def sfsfTagFound = map.get("sfsfTagFound");
	message.setProperty("sfsfTagFound", sfsfTagFound);
	
    def testRun = map.get("testRun");
	message.setProperty("testRun", testRun);	
	
 	//divide filesize to 2 as both en_US and de_DE languages are included in the same file!! 
	def SFTP_Target_FileSize = message.getProperties().get("SFTP_Target_FileSize").toInteger();
	SFTP_Target_FileSize = SFTP_Target_FileSize / 2;
	message.setProperty("SFTP_Target_FileSize", SFTP_Target_FileSize);
	
	//used to clear hashmap global variables
	def emptyHmap = new HashMap<String, String>();
	emptyHmap.put('null','');
	message.setProperty("emptyHmap", emptyHmap);
	
	return message;
}

def Message gather_filenames(Message message) {
	def body = message.getBody(java.lang.String);
	def root = new XmlSlurper().parseText(body);
    
    List<String> files = [
        "filenameUPDTagTexts"
    ];

    files.each { file ->
        Set<String> filenames = new HashSet<>();
        def elements = root."$file";
        elements.each(){
            def fname = it.text().trim();
            if(fname && fname != '[]'){
                filenames.add(fname)
            }
        }
        if(!filenames.isEmpty()){
            message.setHeader(file, JsonOutput.toJson(filenames));
        }
    }    
    
    return message;
}

def Message get_duplicateTagTexts(Message message) {
    def body = message.getBody(String);
    def root = new XmlSlurper().parseText(body);
    
    // Check if root is empty or has no children
    if (root.children().size() > 0) {    
    
        // Collect all sumCreate values and calculate total sum
        def sumTagTextUpdates = root.'**'.findAll { it.name() == 'sumTagTextUpdates' }*.text()*.toInteger().sum();
        message.setHeader("sumTagTextUpdates", sumTagTextUpdates);
        
        // Collect all sumDuplicateTagTexts values and calculate total sum
        def sumDuplicateTagTexts = root.'**'.findAll { it.name() == 'sumDuplicateTagTexts' }*.text()*.toInteger().sum();
        message.setHeader("sumDuplicateTagTexts", sumDuplicateTagTexts);
        
        Set<String> duplicateTagTexts = extractSetFromXml(root, 'duplicateTagTexts')
        message.setHeader("duplicateTagTexts", JsonOutput.toJson(duplicateTagTexts).toString());      
        
    }

    return message;
}

// Reusable method to extract and clean up sets from XML nodes
Set<String> extractSetFromXml(def xml, String tagName) {
    
    Set<String> resultSet = new HashSet<>();
    xml.'**'.findAll { it.name() == tagName }.each { node ->
        def content = node.text().trim();
        if (content != '[]'){ 
            
            if(content.startsWith("[") && content.endsWith("]")) {
                content = content[1..-2]; // remove square brackets
                
                content.split(',').each { item ->
                    def trimmed = item.trim();
                    if (trimmed) {
                        trimmed = trimmed.replace('%2C', ','); //decode commas
                        resultSet.add(trimmed);
                    }
                }
            }
        }
    }
    return resultSet;
}

def String format_desc(description){
    String descr = description;
    descr = descr.replaceAll(/\/n/, "\n");  //replace with actual new line
    descr = descr.replaceAll ('"','\\\\\\"'); //escape double quotes
    descr = descr.take(4000);  //4000 char limit    
    return descr;
}


def Message process_textUpdates(Message message) {
	
	def map = message.getProperties();
	HashMap<String, String> hmapTexts = map.get("hmap_sfsfTagTexts"); 
	Set<String> duplicateTagTexts = new HashSet<>();
    def sumDuplicateTagTexts = 0;	
	
	def body = message.getBody(java.lang.String);
    HashMap<String, String> hmapTag = map.get("hmap_sfsfTags"); 

	//change status 
	def sumTextUpdates = 0;
	def Root = new XmlParser().parseText(body);
	
    Root.file.each{
        it.attribute.each{r->
            def cbrId = r.id[0].text(); //with cbr_ prefix
            if(!hmapTag.containsKey(cbrId)){
                //Competency NOT FOUND in SFSF Tag, nothing to update!
                r.replaceNode{}; //remove
            }else{
                //Competency FOUND in SFSF
                if(hmapTexts!=null){
                    //check for duplicates en_US Texts 
                    def name = 'en_US-'+r.translation_en_US[0].title.text().trim().toLowerCase();
                    def duplicateId = hmapTexts.get(name);
                    if(duplicateId!=null && cbrId!=duplicateId){
                        //duplicate Text found, remove Translation Node
                        r.translation_en_US.replaceNode();
                        //encode comma in names to make sure correct decoding of hashset values
                        duplicateTagTexts.add(cbrId+':'+name.replace(',', '%2C')+'|'+duplicateId);
                        sumDuplicateTagTexts++;
                    }
                    
                    /*
                    //check for duplicate de_DE Texts!                
                    name = 'de_DE-'+r.translation_de_DE[0].title.text().trim().toLowerCase();
                    duplicateId = hmapTexts.get(name);
                    if(duplicateId!=null && cbrId!=duplicateId){
                        //duplicate Text found, remove Translation Node
                        r.translation_de_DE.replaceNode();  
                        duplicateTagTexts.add(cbrId+':'+name.text().replace(',', '%2C')+'|'+duplicateId);
                        sumDuplicateTagTexts++;
                    }
                    */
                    
                    if( r.findAll { it.name().startsWith('translation_') }.size() == 0){
                        //remove entire skill Node
                        r.replaceNode{}; 
                    }else{
                        r.id[0].value = cbrId; //prefix with cbr_
                        sumTextUpdates++;
                        
                        r.findAll { it.name().startsWith('translation_') }.each { t ->
                            // Locate the <description> element within each translation node
                            // Truncate the description text
                            if(t.description[0]){
                                t.description[0].value = format_desc(t.description[0].text());
                            }
                        }                         
                    }
                }    
            }
        }
    }
    
    message.setProperty("hmap_sfsfTags","");  //clear processed data
    message.setBody(XmlUtil.serialize(Root));
    message.setProperty("sumTagTextUpdates",sumTextUpdates.toString());
    message.setProperty("sumDuplicateTagTexts",sumDuplicateTagTexts.toString());
    message.setProperty("duplicateTagTexts",duplicateTagTexts.toString());      
	return message;
}

