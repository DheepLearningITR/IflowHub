import com.sap.gateway.ip.core.customdev.util.Message;  //Default
import groovy.transform.Field;  												//For using the @Field notation
import groovy.xml.MarkupBuilder;  											//For using the MarkupBuilder

// John Humma
// Vertex Inc.
// Vertex Integration Flow Exception Handling Script
// 08.09.2017 - Initial Version
// Updated 11/16/2018 for 1902 release changes. See  "//New for build 1902" tags for details
// Updated 02/14/2019 for 1905 release changes. See  "//New for build 1905" tags for details
// Updated 09/11/2019 for 1908 release changes. See  "//New for build 1908" tags for details

//Global Variables
@Field int DLNGTH;						//Get detail length, ERRMSG length = 72 or 200
@Field int ELNGTH = 183;				//ERRMSG length
@Field String ERRCOD;					//Error Code
@Field String FLTCOD;					//Fault Code (External or Uncaught)
@Field String ERRMES;					//Error Message
@Field String VTXTID;					//Transaction ID
@Field String JAXCON;					//RFC being used (DETERMINE/CALC./FORCE/UPDATE)

//Global Constants
@Field def ENABLE_LOGGING = "TRUE";
@Field int DETLEN = 55;       			//RFC_DETERMINE_JURISDICTION error message length (72 -17)
@Field int OTHLEN = 183;     			//RFC_CALC/FORCE/UPDATE_TAXES_DOC error message length (200 - 17)
@Field def XXXTID = "XXX";				//Set VTXTID to "XXX"

@Field String XTERNL = "External: ";    //Wording for first section of error message
@Field String UNCGHT = "Uncaught: ";    //Wording for first section of error message

@Field String CLIENT = "client";		//SOAP Client fault
@Field String SERVER = "server";		//SOAP Server fault

@Field String SYSVER = "iFlow";			//SYS Version
@Field String RETCOD = "1";				//RETCODE

@Field String UNCDTL = "An error occurred but the details were not caught.";

@Field def DUPTID_FAULT = "1000";		//TID already exists in datastore
@Field def CRDNTL_FAULT = "1001";		//Credentials missing or not deployed
@Field def UNCGHT_FAULT = "1099";		//Uncaught non-camel fault

@Field def SCRIPT_FAULT = "3000";		//Script error

@Field def CAMEL0_FAULT = "4000";		//UnknownHostException
@Field def CAMEL1_FAULT = "4001";		//404: Not Found
@Field def CAMEL9_FAULT = "4099";		//Unknown Camel fault

@Field def SOAPC0_FAULT = "5000";		//User login failed - Client
@Field def SOAPC1_FAULT = "5001";		//Destination location is required - Client
@Field def SOAPC2_FAULT = "5002";		//Cannot find tax area - Client
@Field def SOAPC3_FAULT = "5003";		//No unit of measure passed - Client
@Field def SOAPC4_FAULT = "5004";		//Lineitem is not licensed - Client
@Field def SOAPC5_FAULT = "5005";		//No tax areas were found - Client
@Field def SOAPC6_FAULT = "5006";		//CountryExceptionUnknown - Client
@Field def SOAPC7_FAULT = "5007";		//Cannot find tax area, address cleansing error  - Client  //New for build 1902
@Field def SOAPC9_FAULT = "5099";		//Unknown SOAP Client fault

@Field def SOAPS0_FAULT = "6000";		//Numberformatexception - Server
@Field def SOAPS1_FAULT = "6001";		//Unparseable date - Server
@Field def SOAPS2_FAULT = "6002";		//Sockettimeoutexception - Server
@Field def SOAPS3_FAULT = "6003";		//Sslhandshakeexception - Server
@Field def SOAPS4_FAULT = "6004";		//Connection timed out - Server
@Field def SOAPS5_FAULT = "6005";		//Oracle DB issues (ora-0, ora-1, ora-2) - Server
@Field def SOAPS9_FAULT = "6099";		//Unknown SOAP Server fault

//Main Processing
def Message processData(Message message) {
	if (ENABLE_LOGGING == "TRUE") {
		def messageLog = messageLogFactory.getMessageLog(message);
		def xmlWriter  = new StringWriter();
		def xmlMarkup  = new MarkupBuilder(xmlWriter)

		//Get Headers And Properties
		map = message.getProperties();
		hed = message.getHeaders();
		ipt = map.get("InProcessTID");
		dsi = hed.get("SapDataStoreId");
		wrt = map.get("WriteTID");
		ex1 = map.get("CamelExceptionCaught");
		jct = map.get("jaxwsContext");
		apiversion = map.get("api_version")

		//Set ERRMSG max length
		if (jct.toString().contains("VertexDetermineJurisdiction")) {
			JAXCON = "VTXDET";
			ELNGTH = DETLEN;
		} else if (jct.toString().contains("VertexUpdateTax")) {
			JAXCON = "VTXUPD";
		} else if (jct.toString().contains("VertexForceTax")) {
			JAXCON = "VTXFRC";
		} else if (jct.toString().contains("VertexCalculateTax")) {
			JAXCON = "VTXCAL";
		} else if (jct.toString().contains("VertexFindChanged")) {
			JAXCON = "VTXGET"; //New for build 1902
		} else if (jct.toString().contains("VertexMassTXJCD")) {
			JAXCON = "VTXRED"; //New for build 1902
		}

		//Handle Errors
		if (ex1 != null) {
			def exmap = ex1.getProperties();

			if (ex1.getClass().getCanonicalName().contains("DuplicateEntryException")) {  //Duplicate TID
				//Get Write Error Details And Populate Responses Accordingly
				details = ex1.getMessage().toString();
				ERRCOD  = DUPTID_FAULT;  //"1000";

				//For Routing Purposes Set VTX_TID To "XXX" and clear others
				message.setHeader("VTX_TID", XXXTID);
				VTXTID = XXXTID;
				ipt    = null;
				dsi    = null;
			} else if (ex1.getClass().getCanonicalName().contains("SoapFault")) {  //SOAP Fault
				//Get SOAP Error Details
				details = ex1.getDetail().getTextContent();

				//Get SOAP Fault Code: "Client/Server"
				def fcString = exmap.get("faultCode").toString();

				//Client Fault
				if (fcString.toLowerCase().contains(CLIENT)) {
					//Set Error Code: "ERRCOD"
					if (details.toLowerCase().contains("user login failed")) {
						ERRCOD  = SOAPC0_FAULT;  //"5000";
					} else if (details.toLowerCase().contains("a destination location is required")) {
						details = ex1.getMessage().toString();  //Special Message Because Of Formatting
						ERRCOD  = SOAPC1_FAULT;  //"5001";
					} else if (details.toLowerCase().contains("cannot find tax area")) {
						ERRCOD  = SOAPC2_FAULT;  //"5002";
					} else if (details.toLowerCase().contains("no unit of measure")) {
						ERRCOD  = SOAPC3_FAULT;  //"5003";
					} else if (details.toLowerCase().contains("lineitem is not licensed")) {
						ERRCOD  = SOAPC4_FAULT;  //"5004";
					} else if (details.toLowerCase().contains("no tax areas were found")) {
						details = ex1.getMessage().toString().reverse().take(155).reverse();  //Special Message Because Of Length
						details = "No tax areas found for: " + details;
						ERRCOD  = SOAPC5_FAULT;  //"5005";
					} else if (details.toLowerCase().contains("countryexceptionunknown")) {
						ERRCOD  = SOAPC6_FAULT;  //"5006";
					} else if (details.toLowerCase().contains("fault code=")) {
						def int1 = ex1.getMessage().toString().indexOf("fault code=").toInteger();  //Special Message Because Cleansing Error Code
						details = details.substring(int1);
						ERRCOD  = SOAPC7_FAULT;  //"5007";  //New for build 1902 
					}	else {
						//ERRCOD = details;  //For Troubleshooting Only.
						ERRCOD  = SOAPC9_FAULT;  //"5099" "Unknown SOAP Client Fault"
					}
				}
				//Server Fault
				if (fcString.toLowerCase().contains(SERVER)) {
					//Set Error Code: "ERRCOD"
					if (details.toLowerCase().contains("numberformatexception")) {
						ERRCOD = SOAPS0_FAULT;   //"6000";
					} else if (details.toLowerCase().contains("unparseable date")) {
						ERRCOD =	SOAPS1_FAULT;  //"6001";
					} else if (details.toLowerCase().contains("sockettimeoutexception")) {
						ERRCOD =	SOAPS2_FAULT;  //"6002";
					} else if (details.toLowerCase().contains("sslhandshakeexception")) {
						ERRCOD =	SOAPS3_FAULT;  //"6003";
					} else if (details.toLowerCase().contains("connection timed out")) {
						ERRCOD =	SOAPS4_FAULT;  //"6004";
					} else if (details.toLowerCase().contains("ora-0")) {
						ERRCOD =	SOAPS5_FAULT;  //"6005";
					} else if (details.toLowerCase().contains("ora-1")) {
						ERRCOD =	SOAPS5_FAULT;  //"6005";
					} else if (details.toLowerCase().contains("ora-2")) {
						ERRCOD =	SOAPS5_FAULT;  //"6005";
					} else {
						//ERRCOD = details;  //For Troubleshooting Only.
						ERRCOD = SOAPS9_FAULT;  //"6099" "Unknown SOAP Server Fault"
					}
				}
			} else {  //Other Camel Fault
				//Get Camel Error Details
				details = ex1.getCause().toString();  //Gets Full Error Message, Including Class. https://cxf.apache.org/javadoc/latest/org/apache/cxf/interceptor/Fault.html

				//Get Length Of Details String
				if (details.length() > ELNGTH) {
					DLNGTH = ELNGTH;  //ERRMSG Max Length
				} else {
					DLNGTH = details.length().toInteger();
				}

				//Set Error Code: "ERRCOD"
				if (details.contains("UnknownHostException")) {
					ERRCOD  = CAMEL0_FAULT;  //"4000";
				} else if (details.contains("404: Not Found")) {
					ERRCOD  = CAMEL1_FAULT;  //"4001";
				} else if (details.contains("artifactName vertexinc")) {
					details = details.reverse().take(DLNGTH).reverse();  //Special Message Because Of Length
					ERRCOD  = CRDNTL_FAULT;  //"1001";
				}	else if (ex1.getClass().getCanonicalName().contains("ScriptException")) {
					ERRCOD  = SCRIPT_FAULT;  //"3000";
				} else {
					ERRCOD  = CAMEL9_FAULT;  //"4099" "Unknown Camel Fault"
				}
			}

			//Set Fault Code: FLTCOD
			FLTCOD = XTERNL;  //"External: "

			//Avoid String Index Out Of Bounds.... For Errors Smaller Than 72/200 Characters.
			if (details.length() > ELNGTH) {
				DLNGTH = ELNGTH;  //ERRMSG Max Length
			} else {
				DLNGTH = details.length().toInteger();
			}
			ERRMES = details.substring(0,DLNGTH)

		} else {  //Non-Camel Fault
			//Set Response Variables
			ERRCOD = UNCGHT_FAULT;
			FLTCOD = UNCGHT;  //"Uncaught: "
			ERRMES = UNCDTL;  //"An error occurred but the details were not caught."
		}

		//Set VTX_TID Variable For Routing
		if (ipt != null) {
			message.setHeader("VTX_TID", ipt);
			VTXTID = ipt;
		} else if (dsi != null) {
			message.setHeader("VTX_TID", dsi);
			VTXTID = dsi;
		} else {  //Duplicate TID
			message.setHeader("VTX_TID", XXXTID);
			VTXTID = XXXTID;
		}

		//Set Response XML Based On RFC Used
		switch (JAXCON) {
			case "VTXDET":
			xmlMarkup.'n1:TAX_JURISDICTION_RECEIVE'('xmlns:n1':'http://sap.com/xi/FotETaxUS') {
				LOCATION_HEADER {
					RETCODE(RETCOD)
					ERRCODE(ERRCOD)
					ERRMSG(FLTCOD + ERRCOD + " - " + ERRMES)
				}
			}
			break;
			case "VTXUPD":
			xmlMarkup.'n1:TAX_UPDATE_RECEIVE'('xmlns:n1':'http://sap.com/xi/FotETaxUS') {
				UPDATE_RESULT_HEADER {
					API_VERSION(apiversion)
					SYST_VERSION(SYSVER)
					TID(VTXTID)
					RETCODE(RETCOD)
					ERRCODE(ERRCOD)
					ERRMSG(FLTCOD + ERRCOD + " - " + ERRMES)
				}
			}
			break;
			case "VTXFRC":
			xmlMarkup.'n1:TAX_FORCE_RECEIVE'('xmlns:n1':'http://sap.com/xi/FotETaxUS') {
				FORCE_RESULT_HEADER {
					API_VERSION(apiversion)
					SYST_VERSION(SYSVER)
					TID(VTXTID)
					RETCODE(RETCOD)
					ERRCODE(ERRCOD)
					ERRMSG(FLTCOD + ERRCOD + " - " + ERRMES)
				}
			}
			break;
			case "VTXCAL":
			xmlMarkup.'n1:TAX_CALCULATION_RECEIVE'('xmlns:n1':'http://sap.com/xi/FotETaxUS') {
				CALCULATION_RESULT_HEADER {
					API_VERSION(apiversion)
					SYST_VERSION(SYSVER)
					RETCODE(RETCOD)
					ERRCODE(ERRCOD)
					ERRMSG(FLTCOD + ERRCOD + " - " + ERRMES)
				}
			}
			break;
			case "VTXGET": //New for build 1902
			xmlMarkup.'n1:TAX_JUR_GETCHANGELIST_RECEIVE'('xmlns:n1':'http://sap.com/xi/FotETaxUS') {
				MSG_RETURN {
					RETCODE(RETCOD)
					ERRCODE(ERRCOD)
					ERRMSG(FLTCOD + ERRCOD + " - " + ERRMES)
				}
			}
			break;
			case "VTXRED":  //New for build 1902
			xmlMarkup.'n1:TAX_JURI_REDEFINE_RECEIVE'('xmlns:n1':'http://sap.com/xi/FotETaxUS') {
				TAX_JURI_CODE_NUM {
					MSG_RETURN {
						RETCODE(RETCOD)
						ERRCODE(ERRCOD)
						ERRMSG(FLTCOD + ERRCOD + " - " + ERRMES)
					}
				}
		  }
			break;
		}

		//Set Message Body To XML Response
		def output = xmlWriter.toString();
		message.setBody(output);
		messageLog.setStringProperty("VtxLog_EX_VBD",output);
	}
	return message;
}