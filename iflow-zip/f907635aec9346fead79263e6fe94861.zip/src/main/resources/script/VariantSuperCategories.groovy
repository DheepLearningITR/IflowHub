import com.sap.it.api.mapping.*;
import groovy.util.slurpersupport.GPathResult
import groovy.xml.StreamingMarkupBuilder
import java.text.NumberFormat;
import java.lang.Number;
import java.text.DecimalFormat;
import java.util.Locale;



def  GPathResult processXMLData(String message) {
    if(null == message){
	    return
	}
	return new XmlSlurper().parseText(message)

}

def String getSuperCategoryBaseProductCode(String matlName, String charName, String charValue, MappingContext context){
	return determineVariantAttributesCode(matlName,charName,charValue,context,getRelevantCharProfAttributes(context), getRelevantMatlCatAttributes(context))
}

def String getSuperCategoryCode(String matlName, String charName, String charValue, String charValueFloatFrom, String charValueFloatTo, String dependencyCode, MappingContext context){
    def String code = determineVariantAttributesCode(matlName,charName,charValue,context,getRelevantCharProfAttributes(context), getRelevantMatlCatAttributes(context))
    def String returnCharValue;
 
    if(null != code && !code.equals('')){
       def chrmas = processXMLData(context.getProperty(charName+'CHRMAS_XML'))
		//check dataType
	   def dataType = chrmas.IDOC.E1CABNM.ATFOR.text()
		//check rangesAllowed
	   def rangesAllowed = null
	   if(chrmas.IDOC.E1CABNM.ATINT.size()> 0){
	        rangesAllowed = chrmas.IDOC.E1CABNM.ATINT.text()
	   }
	   if(dataType.equals('NUM')) {
            def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))
            if(rangesAllowed != null && rangesAllowed.equals('X')){
	               returnCharValue = convertNumberRangeForVariantValueID(charValueFloatFrom, charValueFloatTo, dependencyCode)
	        }else{
                returnCharValue = charValue.split(' ')[0]
	        }
	    }
	    else {// CHAR
		    returnCharValue = charValue
	    }    
        
        return code+'_'+returnCharValue
    }else{
        return ''
    }   
}



def String determineVariantAttributesCode(matlName,charName,charValue,context,relevantAttributes,relevantMatlCatAttributes) {
	def String CHAR_PROF= context.getProperty("CHAR_PROF");
	def String BASE_ARTICLE_ID= context.getProperty("MATERIAL_CODE");
	def String MATL_GROUP= context.getProperty("MATL_GROUP");
	def String finalString =''

    def boolean additionalValueExists = context.getProperty("additionalValueExists")
	if(relevantAttributes.contains(charName)){ //This means the attribute is from CHAR_PROF 
	    if(!additionalValueExists) {
	        //NO ADDN VALUE
		    finalString= CHAR_PROF+'_'+charName
	    }else{
	        //ADDN VALUE
	        finalString= BASE_ARTICLE_ID+'_'+charName
	    }
	}else if(relevantMatlCatAttributes.contains(charName)){ //This means the attribute is fron MATL_GROUP 
	    if(!additionalValueExists) {
	        //NO ADDN VALUE
		    finalString= MATL_GROUP+'_'+charName
	    }else{
	        //ADDN VALUE
	        finalString= BASE_ARTICLE_ID+'_'+charName
	    }
	}
	return finalString
}

def getRelevantCharProfAttributes(context){
	def String CHAR_PROF= context.getProperty("CHAR_PROF");
	def String CHAR_PROF_CLSMAS_XML= context.getProperty(CHAR_PROF+'CLSMAS_XML');

	def relevantAttributes=[]
	
	if(null != CHAR_PROF && !CHAR_PROF.equals('')) {
		relevantAttributes.addAll(extractAttributes(CHAR_PROF_CLSMAS_XML))
	}
   
	return relevantAttributes
}

def getRelevantMatlCatAttributes(context){
    def String MATL_CAT = context.getProperty("MATL_CAT");
    def String MATL_GROUP= context.getProperty("MATL_GROUP");
    def parent = null;
    def relevantMatlCatAttributes=[]
    
     // find attributes by category
	if(null != MATL_CAT && MATL_CAT.contains('01')) {
		while (null != MATL_GROUP && !MATL_GROUP.equals('')) {
			 relevantMatlCatAttributes.addAll(extractAttributes(context.getProperty(MATL_GROUP+'CLSMAS_XML')))
			 parent= findParentMatlGroup(MATL_GROUP,context)
			if(null != parent) {
				MATL_GROUP = parent
			}else {
				MATL_GROUP=null
			}
		}
	}
	return relevantMatlCatAttributes
}


def extractAttributes(String fileName) {
	def relevantAttributes = []
	if(null == fileName){
	    return relevantAttributes
	}
	def root = processXMLData(fileName)
	if(null != root && !root.text().contains('NOTFOUND') && root.IDOC.E1KLAHM.E1KSMLM.size()>0) {
		root.IDOC.E1KLAHM.E1KSMLM.each{ it->
			if(null != it.RELEV && it.RELEV.text().equals('2')) {
				relevantAttributes.add(it.ATNAM.text())
			}
		}
	}
    return relevantAttributes
}


def findParentMatlGroup(String matlGroup,context) {
	def clfmas=context.getProperty(matlGroup+'CLFMAS_XML')
	if(clfmas==null){
	    return null
	}
	def root = processXMLData(clfmas)
		if(null != root && root.CLFMAS02.IDOC.E1OCLFM.E1KSSKM.size()>0){
		return root.CLFMAS02.IDOC.E1OCLFM.E1KSSKM.CLASS.text()
	}else {
		return null
	}
}

def convertNonLocalizedNumberForVariantValueID(String number){
    return convertNonLocalizedNumber(number).replaceAll(",", "x").replaceAll("\\.", "x")
}

def convertNonLocalizedNumber(String number) {
	def maxFractionDigits = 9;
	
	java.text.NumberFormat numberFormat = NumberFormat.getInstance(java.util.Locale.ENGLISH);
	java.lang.Number parsedNumber = numberFormat.parse(number.replaceFirst("E\\+", "E"));
	java.text.DecimalFormat decimalFormat = (java.text.DecimalFormat)java.text.NumberFormat.getNumberInstance(java.util.Locale.ENGLISH)
	decimalFormat.setMaximumFractionDigits(maxFractionDigits);
	decimalFormat.setGroupingUsed(false);
	
	return decimalFormat.format(parsedNumber)
	
}


def convertNumberRangeForVariantValueID(String numberFrom, String numberTo, String dependencyCode){
		String rangeID;
        String formattedNumberFrom = convertNonLocalizedNumber(numberFrom);
		String formattedNumberTo = convertNonLocalizedNumber(numberTo);
		switch (dependencyCode)
		{
			case "1":
				rangeID = formattedNumberFrom;
				break;
			case "2":
				rangeID = ">=".concat(formattedNumberFrom.concat("<").concat(formattedNumberTo));
				break;
			case "3":
				rangeID = ">=".concat(formattedNumberFrom.concat("<=").concat(formattedNumberTo));
				break;
			case "4":
				rangeID = ">".concat(formattedNumberFrom.concat("<").concat(formattedNumberTo));
				break;
			case "5":
				rangeID = ">".concat(formattedNumberFrom.concat("<=").concat(formattedNumberTo));
				break;
			case "6":
				rangeID = "<".concat(formattedNumberFrom);
				break;
			case "7":
				rangeID = "<=".concat(formattedNumberFrom);
				break;
			case "8":
				rangeID = ">".concat(formattedNumberFrom);
				break;
			case "9":
				rangeID = ">=".concat(formattedNumberFrom);
				break;
		}

		return rangeID;
	}










