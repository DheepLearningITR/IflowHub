import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def xmlDoc = message.getBody(java.lang.String) as String;
    message.setBody(xmlDoc);
	return message;
}