import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil
import groovy.util.slurpersupport.GPathResult
import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi;


def String getApprovalStatus(String arg1, MappingContext context){
     def appStatus = context.getProperty('Approval_Status')
     return appStatus
}


def String getEAN_UPC(String productCode, MappingContext context){
     def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))
     def returnVal=''
     for(def it: artmas.IDOC.E1BPE1MARMRT){
          if(it.MATERIAL.text().equals(productCode) && it.EAN_UPC.size()>0){
              returnVal = it.EAN_UPC.text()
              break
          }
     }
     
     return returnVal
}

def String getVariantUnit(String productCode, MappingContext context){
     def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))
     def returnVal=''
     for(def it: artmas.IDOC.E1BPE1MARART){
          if((it.MATERIAL.text().equals(productCode) || it.E1BPE1MARART1.MATERIAL_LONG.text().equals(productCode)) && it.BASE_UOM_ISO.size()>0){
              returnVal = it.BASE_UOM_ISO.text()
              break
          }
     }
     
     return returnVal
}


def String getPricingGrp(String material, MappingContext context){
    String pricingGrp = "";
    def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))
    if(artmas.IDOC.E1BPE1MVKERT.size()>0){
        for(def it : artmas.IDOC.E1BPE1MVKERT){
            if(it.MATERIAL.text().equals(material)){
                pricingGrp = it.MAT_PR_GRP.text()
                break;
            }
        }
    }
	return pricingGrp
}


def String getBaseProduct(String arg1, MappingContext context){
    def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))
    return artmas.IDOC.E1BPE1MATHEAD.MATERIAL.text()
}

def String getSingleUnit(String productCode, MappingContext context){
    def returnVal='';
    def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))
    if(artmas.IDOC.E1BPE1MARART.size()>0){
        for(def it : artmas.IDOC.E1BPE1MARART){
            if((it.MATERIAL.text().equals(productCode) || it.E1BPE1MARART1.MATERIAL_LONG.text().equals(productCode)) && it.BASE_UOM_ISO.size()>0){
                returnVal = it.BASE_UOM_ISO.text()
                break;
            }
        }
    }
	return returnVal
}

def String getSingleUnit1(String productCode, MappingContext context){
    def returnVal='';
    def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))
    if(artmas.IDOC.E1BPE1MVKERT.size()>0){
        for(def it : artmas.IDOC.E1BPE1MVKERT){
            if((it.MATERIAL.text().equals(productCode) || it.MATERIAL_LONG.text().equals(productCode)) && it.SALES_UNIT_ISO.size()>0){
                returnVal = it.SALES_UNIT_ISO.text()
                break;
            }
        }
    }
	return returnVal
}

def String getCharProf(String arg1, MappingContext context){
	return context.getProperty('CHAR_PROF'); 
}

def String getMatlGrp(String arg1, MappingContext context){
	return context.getProperty('MATL_GROUP'); 
}

def String getDiscountAllowed(String material, String sales_org, String dist_channel, MappingContext context){
    def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))
    if(artmas.IDOC.E1BPE1WLK2RT.size()>0){
        artmas.IDOC.E1BPE1WLK2RT.each{it ->
            if(it.MATERIAL.text().equals(material) && it.SALES_ORG.text().equals(sales_org) && it.DISTR_CHAN.text().equals(dist_channel)){
                if(it.DISC_ALLWD.size()>0 && it.DISC_ALLWD.text().equals('X')){
                    return 'true'
                }else{
                    return 'false'
                }
            }
        }
    }
    return 'false'
}



def String getProductName(String material, MappingContext context){
    def returnVal='';
    def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))
    if(artmas.IDOC.E1BPE1MAKTRT.size()>0){
        for(def it : artmas.IDOC.E1BPE1MAKTRT){
            if(it.MATERIAL.text().equals(material) && it.LANGU_ISO.text().equals('EN')){
                returnVal = it.MATL_DESC.text()
                break;
            }
        }
    }
    return returnVal
}


def String getSapBlockedStatus(String material, MappingContext context){
    def returnVal='';
    def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))
    if(artmas.IDOC.E1BPE1MARART.size()>0){
        for(def it : artmas.IDOC.E1BPE1MARART){
            if(it.MATERIAL.text().equals(material) && it.SAL_STATUS.size()>0){
                returnVal = it.SAL_STATUS.text()
                break;
            }
        }
    }
    return returnVal
}

def String getSapBlockedFrom(String material, MappingContext context){
    def returnVal='';
    def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))
    if(artmas.IDOC.E1BPE1MARART.size()>0){
        for(def it : artmas.IDOC.E1BPE1MARART){
            if(it.MATERIAL.text().equals(material) && it.SVALIDFROM.size()>0){
                returnVal = it.SVALIDFROM.text()
                break;
            }
        }
    }
    return returnVal
}

def String getMaterialCode(String header, MappingContext context){
    
    return (context.getProperty("MATERIAL_LONG_CODE") == ''?context.getProperty("MATERIAL_CODE"):context.getProperty("MATERIAL_LONG_CODE")) ;
}

def String getProductTaxGroup(String material, String salesOrg, String distChannel,MappingContext context){
    def service = ITApiFactory.getApi(ValueMappingApi.class, null);
    def country = service.getMappedValue("S4HANA","SalesArea_DistChannel",salesOrg+'_'+distChannel,"Commerce","TaxCountry");
    if(null==country || country.equals('')){
        country = context.getProperty('Default_Tax_Country_Code')
    }
    def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))
    def prdTaxGrp = ''
    
    for(def it: artmas.IDOC.E1BPE1MLANRT){
        if(it.MATERIAL.text().equals(material) && it.DEPCOUNTRY_ISO.text().equals(country)){
            prdTaxGrp=country+'-'+it.TAX_TYPE_1.text()+'-'+it.TAXCLASS_1.text()
            break;
        }
        
    }
    
    return prdTaxGrp
}

def String getBaseProductSalesCatalogVersionForSalesArea(String arg,MappingContext context){
    def service = ITApiFactory.getApi(ValueMappingApi.class, null);
    String salesOrg = context.getProperty("SALES_ORG");
    String distChannel = context.getProperty("DISTR_CHAN");
    
    def version = service.getMappedValue("S4HANA","Sales_Catalog_version",salesOrg+'_'+distChannel,"Commerce","Sales_Catalog_version");
    if(null == version){
        version = context.getProperty('Default_Sales_Catalog_Version')
    }
	return version 
}

def String getBaseProductSalesCatalogIdForSalesArea(String arg, MappingContext context){
    def service = ITApiFactory.getApi(ValueMappingApi.class, null);
    String salesOrg = context.getProperty("SALES_ORG");
    String distChannel = context.getProperty("DISTR_CHAN");
    
    def id = service.getMappedValue("S4HANA","Sales_Catalog_Id",salesOrg+'_'+distChannel,"Commerce","Sales_Catalog_Id");
    if(null==id){
        id = context.getProperty('Default_Sales_Catalog_Id')
    }
	return id 
}

def String getSalesCatalogVersionForSalesArea(String salesOrg, String distChannel,MappingContext context){
    def service = ITApiFactory.getApi(ValueMappingApi.class, null);
    def version = service.getMappedValue("S4HANA","Sales_Catalog_version",salesOrg+'_'+distChannel,"Commerce","Sales_Catalog_version");
    if(null == version){
        version = context.getProperty('Default_Sales_Catalog_Version')
    }
	return version 
}

def String getSalesCatalogIdForSalesArea(String salesOrg, String distChannel, MappingContext context){
    def service = ITApiFactory.getApi(ValueMappingApi.class, null);
    def id = service.getMappedValue("S4HANA","Sales_Catalog_Id",salesOrg+'_'+distChannel,"Commerce","Sales_Catalog_Id");
     if(null==id){
        id = context.getProperty('Default_Sales_Catalog_Id')
    }
	return id 
}



def  GPathResult processXMLData(String message) {
	return new XmlSlurper().parseText(message)
}






