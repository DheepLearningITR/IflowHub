import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil

def Message processData(Message message) {
    def String DEFAULT_PAYLOAD_XML = '<batchParts>'+message.getProperty('DEFAULT_STAGED_VARIANTS_PAYLOAD_XML')+'</batchParts>';
     def String DEFAULT_SUPERCATEGORY_PAYLOAD_XML = '<batchParts>'+message.getProperty('DEFAULT_STAGED_VARIANTS_SUPERCATEGORY_PAYLOAD_XML')+'</batchParts>';
      def String DEFAULT_TEXT_PAYLOAD_XML = '<batchParts>'+message.getProperty('VARIANTS_TEXT_PAYLOAD_XML')+'</batchParts>';
      
    def merged = mergeSuperCategories(DEFAULT_PAYLOAD_XML,DEFAULT_SUPERCATEGORY_PAYLOAD_XML)
    merged = mergeBaseProduct(DEFAULT_SUPERCATEGORY_PAYLOAD_XML,merged)
    merged = mergeProductText(DEFAULT_TEXT_PAYLOAD_XML,merged)
    message.setBody(merged);
    return message
}


public mergeProductText(textsMessage, merged) {
    def String textMessage= textsMessage;
	def String mergedMessage = merged
	
	def textRoot = new XmlSlurper().parseText(textMessage);
	def plainRoot = new XmlSlurper().parseText(mergedMessage);

	plainRoot.batchChangeSet.each{plainIt->
		def variantName = plainIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.code.text()
		textRoot.batchChangeSet.each{textIt->
			if(textIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.code.text().equals(variantName)) {
				plainIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.appendNode(textIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.localizedAttributes)
				//plainIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.appendNode(textIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.unit)
				//plainIt.batchChangeSetPart.headers.appendNode(textIt.batchChangeSetPart.headers.header)

			}
		}
	}
	return (groovy.xml.XmlUtil.serialize(plainRoot).replaceAll(/<.xml.*?>/,"") )
}

public mergeBaseProduct(variantsMessage,merged) {
    def String variantMessage= variantsMessage;
	def String mergedMessage = merged
	

	def variantRoot = new XmlSlurper().parseText(variantMessage);
	def plainRoot = new XmlSlurper().parseText(mergedMessage);

	plainRoot.batchChangeSet.each{plainIt->
		def variantName = plainIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.code.text()
		variantRoot.batchChangeSet.each{variantIt->
			if(variantIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.code.text().equals(variantName)
			&& variantIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.baseProduct.Product.supercategories.size() > 0
			&& variantIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.baseProduct.Product.supercategories.Category.code.text()!=null
			&& !variantIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.baseProduct.Product.supercategories.Category.code.text().equals('')) {
				plainIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.baseProduct.Product.supercategories.appendNode(variantIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.baseProduct.Product.supercategories.Category)
			}
		}
	}
	return (groovy.xml.XmlUtil.serialize(plainRoot).replaceAll(/<.xml.*?>/,"") )

}

public mergeSuperCategories(mainMessage, variantsMessage) {
    def String variantMessage= variantsMessage;
    def String plainMessage = mainMessage;

	def variantRoot = new XmlSlurper().parseText(variantMessage);
	def plainRoot = new XmlSlurper().parseText(plainMessage);
	plainRoot.batchChangeSet.each{plainIt->
		def variantName = plainIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.code.text()
		variantRoot.batchChangeSet.each{variantIt->
			if(variantIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.code.text().equals(variantName)
			&& variantIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.supercategories.Category.code.text()!=null
			&& !variantIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.supercategories.Category.code.text().equals('')) {
				plainIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.supercategories.appendNode(variantIt.batchChangeSetPart.GenericVariantProducts.GenericVariantProduct.supercategories.Category)

			}
		}
	}
	return (groovy.xml.XmlUtil.serialize(plainRoot).replaceAll(/<.xml.*?>/,"") )
}
