import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.mapping.*;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.XmlUtil;
def Message processData(Message message) {
    def name = message.getProperty("XMLNAME") as String;
    def dsname = message.getProperty("DATASTORE_NAME") as String;

    def xmlDoc = message.getBody(java.lang.String) as String;
    message.setProperty(name+dsname+"_XML",xmlDoc);
    if(xmlDoc == null || xmlDoc == ''){
       return message;
    }
	message.setProperty(name+dsname+"_XML",xmlDoc);
	message.setBody(xmlDoc);
	return message;
}
