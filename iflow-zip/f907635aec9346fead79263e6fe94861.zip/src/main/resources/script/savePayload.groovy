import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.mapping.*;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.XmlUtil;



def Message saveSingleProduct(Message message) {
    def xmlDoc = message.getBody(java.lang.String) as String;
    if(xmlDoc == null || xmlDoc == ''){
       return message;
    }
	message.setProperty("DEFAULT_PRODUCT_PAYLOAD_XML",xmlDoc);
	return message;
}

def Message saveSingleSalesProduct(Message message) {
    def xmlDoc = message.getBody(java.lang.String) as String;
    if(xmlDoc == null || xmlDoc == ''){
       return message;
    }
	message.setProperty("SALES_PRODUCT_PAYLOAD_XML",xmlDoc);
	return message;
}


def Message saveSingleText(Message message) {
    def xmlDoc = message.getBody(java.lang.String) as String;
    if(xmlDoc == null || xmlDoc == ''){
       return message;
    }
	message.setProperty("SINGLE_TEXT_PAYLOAD_XML",xmlDoc);
	return message;
}

def Message saveVariantsText(Message message) {
    def xmlDoc = message.getBody(java.lang.String) as String;
    if(xmlDoc == null || xmlDoc == ''){
       return message;
    }
	message.setProperty("VARIANTS_TEXT_PAYLOAD_XML",xmlDoc);
	return message;
}


def Message saveSalesVariantsSupercategory(Message message) {
    def xmlDoc = message.getBody(java.lang.String) as String;
    if(xmlDoc == null || xmlDoc == ''){
       return message;
    }
	message.setProperty("SALES_VARIANTS_SUPERCATEGORY_PAYLOAD_XML",xmlDoc);
	return message;
}

def Message saveSalesVariants(Message message) {
    def xmlDoc = message.getBody(java.lang.String) as String;
    if(xmlDoc == null || xmlDoc == ''){
       return message;
    }
	message.setProperty("SALES_AREA_VARIANT_PAYLOAD_XML",xmlDoc);
	return message;
}


def Message saveDefaultVariantsSupercategory(Message message) {
    def xmlDoc = message.getBody(java.lang.String) as String;
    if(xmlDoc == null || xmlDoc == ''){
       return message;
    }
	message.setProperty("DEFAULT_STAGED_VARIANTS_SUPERCATEGORY_PAYLOAD_XML",xmlDoc);
	return message;
}

def Message saveDefaultVariants(Message message) {
    def xmlDoc = message.getBody(java.lang.String) as String;
    if(xmlDoc == null || xmlDoc == ''){
       return message;
    }
	message.setProperty("DEFAULT_STAGED_VARIANTS_PAYLOAD_XML",xmlDoc);
	return message;
}




