import com.sap.it.api.mapping.*;
import groovy.util.slurpersupport.GPathResult
import groovy.xml.StreamingMarkupBuilder
import java.text.NumberFormat;
import java.lang.Number;
import java.text.DecimalFormat;
import java.util.Locale;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

       determineAdditionalVariantCategories(message)
       return message;
}

def String determineAdditionalVariantCategories(context) {
	def boolean additionalValueExists = checkForAdditionalAttributes(getRelevantCharProfAttributes(context), getRelevantMatlCatAttributes(context), context)
	context.setProperty('additionalValueExists', additionalValueExists)
}

def getRelevantCharProfAttributes(context){
	def String CHAR_PROF= context.getProperty("CHAR_PROF");
	def String CHAR_PROF_CLSMAS_XML= context.getProperty(CHAR_PROF+'CLSMAS_XML');

	def relevantAttributes=[]

	if(null != CHAR_PROF && !CHAR_PROF.equals('')) {
		relevantAttributes.addAll(extractAttributes(CHAR_PROF_CLSMAS_XML))
	}

	//context.setProperty('relevantAttributes', relevantAttributes)
	return relevantAttributes
}

def getRelevantMatlCatAttributes(context){
    def String MATL_CAT = context.getProperty("MATL_CAT");
    def String MATL_GROUP= context.getProperty("MATL_GROUP");
    def parent = null;
    def relevantMatlCatAttributes=[]

     // find attributes by category
	if(null != MATL_CAT && MATL_CAT.equals('01')) {
		while (null != MATL_GROUP && !MATL_GROUP.equals('')) {
			 relevantMatlCatAttributes.addAll(extractAttributes(context.getProperty(MATL_GROUP+'CLSMAS_XML')))
			 parent= findParentMatlGroup(MATL_GROUP,context)
			if(null != parent) {
				MATL_GROUP = parent
			}else {
				MATL_GROUP=null
			}
		}
	}
	return relevantMatlCatAttributes
}


def boolean checkForAdditionalAttributes(relevantAttributes,relevantMatlCatAttributes, context) {
    def exists = false
    def attributes = relevantAttributes
    attributes.addAll(relevantMatlCatAttributes)
    def artmas = processXMLData(context.getProperty('ARTMASXMLFORMAT'))

	for(def it : attributes) {
	   def String attr = it
	   def chrmas = processXMLData(context.getProperty(attr+'CHRMAS_XML'))
		//check dataType
	   def dataType = chrmas.IDOC.E1CABNM.ATFOR.text()
		//check rangesAllowed
		def rangesAllowed = null
	   if(chrmas.IDOC.E1CABNM.ATINT.size()> 0){
	        rangesAllowed = chrmas.IDOC.E1CABNM.ATINT.text()
	   }
	   if(checkAdditionalValues(context,attr, dataType, rangesAllowed,chrmas,artmas)){
	       	exists = true
	        break;
	    }
	}
	return exists;
}

def checkAdditionalValues(context,attributeId, dataType, rangesAllowed,chrmas, artmas) {
    def exists = false

	if(dataType.equals('NUM')) {
	    if(rangesAllowed != null && rangesAllowed.equals('X')){
	        exists = checkForNumWithRange(context,attributeId,chrmas,artmas)
	    }else{
	       exists = checkForNum(context,attributeId,chrmas,artmas)
	    }
	}
	else {
	//do for Char
		exists = checkForChar (context,attributeId,chrmas,artmas)
	}
	return exists
}

def checkForNumWithRange(context,attributeId,chrmas,artmas) {
    def additionValueExists = false

    def artmasValues = []
    def chrmasValues = []

    if(artmas.IDOC.E1BPE1AUSPRT.size()>0)
    {
        artmas.IDOC.E1BPE1AUSPRT.each{ ausprt->
            if(ausprt.CHAR_NAME.text().equals(attributeId)){
                artmasValues.add(convertNumberRangeForVariantValueID(ausprt.CHAR_VAL_FLOAT_FROM.text(), ausprt.CHAR_VAL_FLOAT_TO.text(), ausprt.CHAR_VAL_DEPENDENCY_CODE.text()))
            }
        }
    }

    if(chrmas.IDOC.E1CABNM.E1CAWNM.size()>0){
	   for(def it : chrmas.IDOC.E1CABNM.E1CAWNM) {
	       chrmasValues.add(convertNumberRangeForVariantValueID(it.ATFLV.text(), it.ATFLB.text() , it.ATCOD.text()))
	     }
	 }

    for(def value : artmasValues) {
	     if(!chrmasValues.contains(value)){
	         additionValueExists = true
	         context.setProperty("additionNumRangeValue",value)
	         break
	     }
	 }

	return additionValueExists
}

def checkForNum(context,attributeId,chrmas,artmas) {
    def additionValueExists = false

    def artmasValues = []
    def chrmasValues = []

    if(artmas.IDOC.E1BPE1AUSPRT.size()>0){
        artmas.IDOC.E1BPE1AUSPRT.each{ ausprt->
            if(ausprt.CHAR_NAME.text().equals(attributeId)){
                artmasValues.add(ausprt.CHAR_VALUE.text())
            }
        }
    }
    if(chrmas.IDOC.E1CABNM.E1CAWNM.size()>0){
	   for(def it : chrmas.IDOC.E1CABNM.E1CAWNM) {
	       chrmasValues.add(convertNonLocalizedNumberForVariantValueID(it.ATFLV.text()))
	     }
	 }

	 for(def value : artmasValues) {
	     if(!chrmasValues.contains(value)){
	         additionValueExists = true
	         context.setProperty("additionNumValue",value)
	         break
	     }
	 }
	 return additionValueExists
}

def checkForChar (context,attributeId,chrmas,artmas) {
    def additionValueExists = false

    def artmasValues = []
    def chrmasValues = []
    if(artmas.IDOC.E1BPE1AUSPRT.size()>0)
    {
        artmas.IDOC.E1BPE1AUSPRT.each{ ausprt->
            if(ausprt.CHAR_NAME.text().equals(attributeId)){
                artmasValues.add(ausprt.CHAR_VALUE.text())
            }
        }
    }

    if(chrmas.IDOC.E1CABNM.E1CAWNM.size()>0){
	   for(def it : chrmas.IDOC.E1CABNM.E1CAWNM) {
	       chrmasValues.add(it.ATWRT.text())
	     }
	 }

	 for(def value : artmasValues) {
	     if(!chrmasValues.contains(value)){
	         additionValueExists = true
	         context.setProperty("additionCharValue",value)
	         break
	     }
	 }

	return additionValueExists
}

def extractAttributes(String fileName) {
	def relevantAttributes = []
	def root = processXMLData(fileName)
	if(null != root && !root.text().contains('NOTFOUND') && root.IDOC.E1KLAHM.E1KSMLM.size()>0) {
		root.IDOC.E1KLAHM.E1KSMLM.each{ it->
			if(null != it.RELEV && it.RELEV.text().equals('2')) {
				relevantAttributes.add(it.ATNAM.text())
			}
		}
	}
    return relevantAttributes
}


def findParentMatlGroup(String matlGroup,context) {
	def clfmas=context.getProperty(matlGroup+'CLFMAS_XML')
	if(clfmas==null){
	    return null
	}
	def root = processXMLData(clfmas)
		if(null != root && root.CLFMAS02.IDOC.E1OCLFM.E1KSSKM.size()>0){
		return root.CLFMAS02.IDOC.E1OCLFM.E1KSSKM.CLASS.text()
	}else {
		return null
	}
}

def convertNonLocalizedNumberForVariantValueID(String number){
    return convertNonLocalizedNumber(number).replaceAll(",", "x").replaceAll("\\.", "x")
}

def convertNonLocalizedNumber(String number) {
	def maxFractionDigits = 9;

	java.text.NumberFormat numberFormat = NumberFormat.getInstance(java.util.Locale.ENGLISH);
	java.lang.Number parsedNumber = numberFormat.parse(number.replaceFirst("E\\+", "E"));
	java.text.DecimalFormat decimalFormat = (java.text.DecimalFormat)java.text.NumberFormat.getNumberInstance(java.util.Locale.ENGLISH)
	decimalFormat.setMaximumFractionDigits(maxFractionDigits);
	decimalFormat.setGroupingUsed(false);

	return decimalFormat.format(parsedNumber)

}


def convertNumberRangeForVariantValueID(String numberFrom, String numberTo, String dependencyCode){
		String rangeID;
        String formattedNumberFrom = convertNonLocalizedNumber(numberFrom);
		String formattedNumberTo = convertNonLocalizedNumber(numberTo);
		switch (dependencyCode)
		{
			case "1":
				rangeID = formattedNumberFrom;
				break;
			case "2":
				rangeID = ">=".concat(formattedNumberFrom.concat("<").concat(formattedNumberTo));
				break;
			case "3":
				rangeID = ">=".concat(formattedNumberFrom.concat("<=").concat(formattedNumberTo));
				break;
			case "4":
				rangeID = ">".concat(formattedNumberFrom.concat("<").concat(formattedNumberTo));
				break;
			case "5":
				rangeID = ">".concat(formattedNumberFrom.concat("<=").concat(formattedNumberTo));
				break;
			case "6":
				rangeID = "<".concat(formattedNumberFrom);
				break;
			case "7":
				rangeID = "<=".concat(formattedNumberFrom);
				break;
			case "8":
				rangeID = ">".concat(formattedNumberFrom);
				break;
			case "9":
				rangeID = ">=".concat(formattedNumberFrom);
				break;
		}

		return rangeID;
	}


def  GPathResult processXMLData(String message) {
	return new XmlSlurper().parseText(message)
}
