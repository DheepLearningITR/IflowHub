import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil

def Message processSalesData(Message message) {
    def String SALES_PRODUCT_PAYLOAD = '<batchParts>'+message.getProperty('SALES_PRODUCT_PAYLOAD_XML')+'</batchParts>';
    def String SINGLE_TEXT_PAYLOAD = '<batchParts>'+message.getProperty('SINGLE_TEXT_PAYLOAD_XML')+'</batchParts>';

    def merged = mergeProductText(SALES_PRODUCT_PAYLOAD,SINGLE_TEXT_PAYLOAD)
    message.setBody(merged);
    return message
}


def Message processDefaultData(Message message) {
    def String DEFAULT_PRODUCT_PAYLOAD_XML = '<batchParts>'+message.getProperty('DEFAULT_PRODUCT_PAYLOAD_XML')+'</batchParts>';
    def String SINGLE_TEXT_PAYLOAD = '<batchParts>'+message.getProperty('SINGLE_TEXT_PAYLOAD_XML')+'</batchParts>';

    def merged = mergeProductText(DEFAULT_PRODUCT_PAYLOAD_XML,SINGLE_TEXT_PAYLOAD)
    message.setBody(merged);
    return message
}


public mergeProductText(plainMessages, textsMessage) {
    def String textMessage= textsMessage;
	def String plainMessage = plainMessages;

	//def newPlainMessage = ''

	def textRoot = new XmlSlurper().parseText(textMessage);
	def plainRoot = new XmlSlurper().parseText(plainMessage);


	plainRoot.batchChangeSet.each{plainIt->
		 // plainRoot = new XmlSlurper().parseText(plainMessage);
          textRoot.batchChangeSet.each{textIt->
				plainIt.batchChangeSetPart.Products.Product.appendNode(textIt.batchChangeSetPart.Products.Product.localizedAttributes)
	       }
	     // newPlainMessage = newPlainMessage + groovy.xml.XmlUtil.serialize(plainRoot).replaceAll(/<.xml.*?>/,"").replaceAll("<batchParts>","").replaceAll("</batchParts>","")
	}

	return groovy.xml.XmlUtil.serialize(plainRoot).replaceAll(/<.xml.*?>/,"")
}
