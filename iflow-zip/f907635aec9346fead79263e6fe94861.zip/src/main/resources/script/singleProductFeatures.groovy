import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil
import groovy.time.*
import com.sap.it.api.mapping.*;
import java.text.NumberFormat;
import java.lang.Number;
import java.text.DecimalFormat;
import java.util.Locale;
import groovy.util.slurpersupport.GPathResult;


def Message processData(Message message) {
	def root = processXMLData(message.getProperty('ARTMASXMLFORMAT'))
	if(root.IDOC.E1BPE1AUSPRT.size() == 0) {
	     return message;
	}
	
	def rootPayload = new XmlSlurper().parseText(message.getBody(java.lang.String) as String);
    def productToCatalog=[]
	String parts=''
	
	rootPayload.batchChangeSet.batchChangeSetPart.each{it->
	    productToCatalog.add(it.Products.Product.code.text()+':'+it.Products.Product.catalogVersion.CatalogVersion.catalog.Catalog.id.text()+':'+it.Products.Product.catalogVersion.CatalogVersion.version.text())
	}
    productToCatalog.unique()
	
	for(def productPayload :productToCatalog){
    	parts = parts + processCleanFeatures(root, productPayload)
	}
	
	for(def productPayload :productToCatalog){
    	parts = parts + processProductFeatures(root, productPayload, message)
	}
	
    message.setBody('<batchParts xmlns="">'+parts+'</batchParts>')
	return message;
}

def String processCleanFeatures(root, productPayload) {
    def materialCode = productPayload.split(':')[0];
    def productCatalogId = productPayload.split(':')[1];
    def productCatalogVersion = productPayload.split(':')[2];
        
	def builder = new StreamingMarkupBuilder()
	def productFeatureBatchParts = builder.bind {
				batchChangeSet {
					batchChangeSetPart{
						method('POST')
						headers{
							header{
								headerName('Pre-Persist-Hook')
								headerValue('sapCpiProductFeatureCleanHook')
							}
						}
						Products{
							Product{
								integrationKey('')
								code(materialCode)
								catalogVersion {
									CatalogVersion{
										integrationKey('')
										version(productCatalogVersion)
										catalog{
											Catalog{
												integrationKey('')
												id(productCatalogId)
											}
										}
									}
								}
							}
						}
					}
				}
		}
	return productFeatureBatchParts
}

def String processProductFeatures(root, productPayload, message) {
        def materialCode = productPayload.split(':')[0];
        def productCatalogId = productPayload.split(':')[1];
        def productCatalogVersion = productPayload.split(':')[2];
        
		def productFeatureValue=[]
		def attributeToClassName=[:]
		def attributeToCharName=[:]
		
		for(def value : root.IDOC.E1BPE1AUSPRT){
		    if(value.CHAR_NAME.text().charAt(0) == '!'){
		        continue;
		    }
		    if(value.MATERIAL == materialCode && (getDataType(value.CHAR_NAME.text(), message).equals('CHAR') || getDataType(value.CHAR_NAME.text(), message).equals('NUM'))){
		        def dataType = getDataType(value.CHAR_NAME.text(), message)

		        def className = charProfAttribute(message, value.CHAR_NAME.text())
		        if(className == null){
		            className = matlGroupAttribute(message, value.CHAR_NAME.text())
		        }

		        def attribute;
		        
		            attribute = value.CHAR_NAME.text()

                if(dataType.equals('CHAR')){
		            def values = getFixedValues(value.CHAR_NAME.text(), message)
		            if (values != null && !values.isEmpty()){
			                productFeatureValue.add(attribute+'#'+value.CHAR_NAME.text()+'_'+value.CHAR_VALUE.text())
			                attributeToClassName.put(attribute,className)
			                attributeToCharName.put(attribute,value.CHAR_NAME.text())
		              }
		            else{
		                    productFeatureValue.add(attribute+'#'+value.CHAR_VALUE.text())
		                    attributeToClassName.put(attribute,className)
		                    attributeToCharName.put(attribute,value.CHAR_NAME.text())
	               	}
		       }else if (dataType.equals('NUM')){
		            def floatFrom = value.CHAR_VAL_FLOAT_FROM.text()
		            def dependencyCode= value.CHAR_VAL_DEPENDENCY_CODE.text()

		            if(dependencyCode != null && !dependencyCode.equals('')){
		                productFeatureValue.add(attribute+'#'+convertNumericAttributeValues(floatFrom))
		                attributeToClassName.put(attribute,className)
		                attributeToCharName.put(attribute,value.CHAR_NAME.text())

		            }else{
		                productFeatureValue.add(attribute+'#'+convertNumericValueFromArticle(value.CHAR_VALUE.text()))
		                attributeToClassName.put(attribute,className)
		                attributeToCharName.put(attribute,value.CHAR_NAME.text())
		            }
		       }

		    }
		}
		int i=0;
		def builder = new StreamingMarkupBuilder()
		def productFeatureBatchParts = builder.bind {
					batchChangeSet {
						batchChangeSetPart{
							method('POST')
							headers{
						        header{
							        headerName('Pre-Persist-Hook')
							        headerValue('sapCpiProductFeaturePersistenceHook')
						        }
				        	}       
							Products{
								Product{
									integrationKey('')
									code(materialCode)
									catalogVersion {
										CatalogVersion{
											integrationKey('')
											version(productCatalogVersion)
											catalog{
												Catalog{
													integrationKey('')
													id(productCatalogId)
												}
											}
										}
									}
									features{
										productFeatureValue.each { feature->
                                            def (attribute, attributeValue) =feature.tokenize( '#' )

											ProductFeature{
												integrationKey('')
												qualifier('ERP_CLASSIFICATION_026'+'/ERP_IMPORT/'+attribute)
												value(attributeValue)
												valuePosition(i++)
												classificationAttributeAssignment{
												    ClassAttributeAssignment{
												        integrationKey('')
												        classificationAttribute{
												            ClassificationAttribute{
												                integrationKey('')
												                code(attributeToCharName.get(attribute))
												                systemVersion{
												                    ClassificationSystemVersion{
												                        integrationKey('')
												                        version('ERP_IMPORT')
												                        catalog{
												                            ClassificationSystem{
												                                integrationKey('')
												                                id('ERP_CLASSIFICATION_026')
												                            }
												                        }
												                    }
												                }
												            }
												        }
												        classificationClass{
												            ClassificationClass{
												                integrationKey('')
												                code(attributeToClassName.get(attribute))
												                catalogVersion{
												                    ClassificationSystemVersion{
												                        integrationKey('')
												                        version('ERP_IMPORT')
												                        catalog{
												                            ClassificationSystem{
												                                integrationKey('')
												                                id('ERP_CLASSIFICATION_026')
												                            }
												                        }
												                    }
												                }
												            }
												        }
												    }

											}
												product{
												    Product{
												        integrationKey('')
									                code(materialCode)
									                catalogVersion {
										                CatalogVersion{
											                integrationKey('')
											                version(productCatalogVersion)
											            catalog{
												            Catalog{
													               integrationKey('')
													                id(productCatalogId)
											                    	}
											                    }
										                    }
								                    	}
												    }
											    }
											}
										}
									}

								}
							}
						}
					}

			}

		return productFeatureBatchParts
}

def String getDataType(charName, message){
    def String CHRMAS_XML= message.getProperty(charName+'CHRMAS_XML');

    def root = new XmlSlurper().parseText(CHRMAS_XML);
    return root.IDOC.E1CABNM.ATFOR.text()

}

def getFixedValues(charName, message){
    def String CHRMAS_XML= message.getProperty(charName+'CHRMAS_XML');

    def values =[]
    def root = new XmlSlurper().parseText(CHRMAS_XML);
    root.IDOC.E1CABNM.E1CAWNM.each{ value->
        values.add(value.ATWRT.text())
    }
    return values
}

def convertNumericValueFromArticle(value){
    if (value.contains(" - ") || value.contains("<") || value.contains(">")
				|| value.contains("=")){
			return;
		}
    return convertNonLocalizedNumber(value.trim())
}

def convertNumericAttributeValues(value){
    return convertNonLocalizedNumber(value.trim())
}


def convertNonLocalizedNumber(String number) {
	def maxFractionDigits = 9;

	java.text.NumberFormat numberFormat = NumberFormat.getInstance(java.util.Locale.ENGLISH);
	java.lang.Number parsedNumber = numberFormat.parse(number.replaceFirst("E\\+", "E"));
	java.text.DecimalFormat decimalFormat = (java.text.DecimalFormat)java.text.NumberFormat.getNumberInstance(java.util.Locale.ENGLISH)
	decimalFormat.setMaximumFractionDigits(maxFractionDigits);
	decimalFormat.setGroupingUsed(false);

	return decimalFormat.format(parsedNumber)

}



def String charProfAttribute(context, charName){
    def returnValue = null
	def String CHAR_PROF= context.getProperty("CHAR_PROF");
	def String CHAR_PROF_CLSMAS_XML= context.getProperty(CHAR_PROF+'CLSMAS_XML');
    if(CHAR_PROF_CLSMAS_XML == null){
         return returnValue
    }
    def root = processXMLData(CHAR_PROF_CLSMAS_XML)

    for(def it : root.IDOC.E1KLAHM.E1KSMLM){
        if(it.ATNAM.text().equals(charName)){
            return CHAR_PROF
        }
    }

    return returnValue
}

def String matlGroupAttribute(context,charName){
    def returnValue = null
    def String MATL_GROUP= context.getProperty("MATL_GROUP");
    def parent = null;

     // find attributes by category
		while (null != MATL_GROUP && !MATL_GROUP.equals('')) {
		    def String MATL_GROUP_CLSMAS_XML= context.getProperty(MATL_GROUP+'CLSMAS_XML');
		    if(null != MATL_GROUP_CLSMAS_XML){
			    def root = processXMLData(MATL_GROUP_CLSMAS_XML)
			     for(def it : root.IDOC.E1KLAHM.E1KSMLM){
                     if(it.ATNAM.text().equals(charName)){
                         return MATL_GROUP
                    }
                }

		    }
			parent= findParentMatlGroup(MATL_GROUP,context)
			if(null != parent) {
				MATL_GROUP = parent
			}else {
				MATL_GROUP=null
			}
		}
	return returnValue
}

def findParentMatlGroup(String matlGroup,context) {
	def clfmas=context.getProperty(matlGroup+'CLFMAS_XML')
	if(clfmas==null){
	    return null
	}
	def root = processXMLData(clfmas)
		if(null != root && root.CLFMAS02.IDOC.E1OCLFM.E1KSSKM.size()>0){
		return root.CLFMAS02.IDOC.E1OCLFM.E1KSSKM.CLASS.text()
	}else {
		return null
	}
}

def  GPathResult processXMLData(String message) {
	return new XmlSlurper().parseText(message)

}
