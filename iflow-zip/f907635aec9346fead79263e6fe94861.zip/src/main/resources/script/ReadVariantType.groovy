import com.sap.it.api.mapping.*;

def String readVariantType(String VariantType,MappingContext context){
        String value2 = context.getProperty(VariantType)
	return value2;
	
	
}