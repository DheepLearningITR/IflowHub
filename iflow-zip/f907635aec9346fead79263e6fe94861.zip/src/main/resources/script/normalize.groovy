import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil

def Message processData(Message message) {
    def default_payload = message.getBody(java.lang.String) as String;
    def normalized = normalize(default_payload)
    message.setBody(normalized);
    message.setProperty("ARTMASXMLFORMAT",normalized);
    return message
}

def normalize(payload){
    def root = new XmlSlurper().parseText(payload);
    //E1BPE1MATHEAD
    if(root.IDOC.E1BPE1MATHEAD.size()>0){
        root.IDOC.E1BPE1MATHEAD.each{it->
            if(it.MATERIAL.size() == 0){
                it.appendNode{MATERIAL(it.MATERIAL_LONG.text())}
            }
        }
    }

    //E1BPE1AUSPRT
    if(root.IDOC.E1BPE1AUSPRT.size()>0){
        root.IDOC.E1BPE1AUSPRT.each{it->
            if(it.MATERIAL.size() == 0){
                it.appendNode{MATERIAL(it.MATERIAL_LONG.text())}
            }
        }
    }

    //E1BPE1MAKTRT
    if(root.IDOC.E1BPE1MAKTRT.size()>0){
        root.IDOC.E1BPE1MAKTRT.each{it->
            if(it.MATERIAL.size() == 0){
                it.appendNode{MATERIAL(it.MATERIAL_LONG.text())}
            }
        }
    }

    //E1BPE1MVKERT
    if(root.IDOC.E1BPE1MVKERT.size()>0){
        root.IDOC.E1BPE1MVKERT.each{it->
            if(it.MATERIAL.size() == 0){
                it.appendNode{MATERIAL(it.MATERIAL_LONG.text())}
            }
        }
    }

     //E1BPE1MARMRT
    if(root.IDOC.E1BPE1MARMRT.size()>0){
        root.IDOC.E1BPE1MARMRT.each{it->
            if(it.MATERIAL.size() == 0){
                it.appendNode{MATERIAL(it.MATERIAL_LONG.text())}
            }
        }
    }

     //E1BPE1MLANRT
    if(root.IDOC.E1BPE1MLANRT.size()>0){
        root.IDOC.E1BPE1MLANRT.each{it->
            if(it.MATERIAL.size() == 0){
                it.appendNode{MATERIAL(it.MATERIAL_LONG.text())}
            }
        }
    }


     //E1BPE1WLK2RT
    if(root.IDOC.E1BPE1WLK2RT.size()>0){
        root.IDOC.E1BPE1WLK2RT.each{it->
            if(it.MATERIAL.size() == 0){
                it.appendNode{MATERIAL(it.MATERIAL_LONG.text())}
            }
        }
    }

     //E1BPE1VARKEY
    if(root.IDOC.E1BPE1VARKEY.size()>0){
        root.IDOC.E1BPE1VARKEY.each{it->
            if(it.VARIANT.size() == 0){
                it.appendNode{VARIANT(it.VARIANT_LONG.text())}
            }
        }
    }

    return (groovy.xml.XmlUtil.serialize(root))
}
