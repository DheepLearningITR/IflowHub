import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.slurpersupport.GPathResult;
import java.util.HashMap;
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil
import java.text.NumberFormat;
import java.lang.Number;
import java.text.DecimalFormat;
import java.util.Locale;

def Message processData(Message message) {
    def attributes =[];
    attributes.addAll(getRelevantCharProfAttributes(message))
    attributes.addAll(getRelevantMatlCatAttributes(message))

	  def artmas = processXMLData(message.getProperty('ARTMASXMLFORMAT'))


    def payload = processVariantValueCategories(message, artmas, attributes);
    message.setBody(XmlUtil.serialize('<batchParts xmlns="">'+payload+'</batchParts>') );
    return message;

}

def  GPathResult processXMLData(String message) {
	return new XmlSlurper().parseText(message)

}

def getRelevantCharProfAttributes(context){
	def String CHAR_PROF= context.getProperty("CHAR_PROF");
	def String CHAR_PROF_CLSMAS_XML= context.getProperty(CHAR_PROF+'CLSMAS_XML');

	def relevantAttributes=[]

		if(null != CHAR_PROF && !CHAR_PROF.equals('')) {
		relevantAttributes.addAll(extractAttributes(CHAR_PROF_CLSMAS_XML))
	}

	return relevantAttributes
}

def getRelevantMatlCatAttributes(context){
    def String MATL_CAT = context.getProperty("MATL_CAT");
    def String MATL_GROUP= context.getProperty("MATL_GROUP");
    def parent = null;
    def relevantMatlCatAttributes=[]

     // find attributes by category
	if(null != MATL_CAT && MATL_CAT.equals('01')) {
		while (null != MATL_GROUP && !MATL_GROUP.equals('')) {
			 relevantMatlCatAttributes.addAll(extractAttributes(context.getProperty(MATL_GROUP+'CLSMAS_XML')))
			 parent= findParentMatlGroup(MATL_GROUP,context)
			if(null != parent) {
				MATL_GROUP = parent
			}else {
				MATL_GROUP=null
			}
		}
	}
	return relevantMatlCatAttributes
}

def findParentMatlGroup(String matlGroup,context) {
	def clfmas=context.getProperty(matlGroup+'CLFMAS_XML')
	if(clfmas==null){
	    return null
	}
	def root = processXMLData(clfmas)
		if(null != root && root.CLFMAS02.IDOC.E1OCLFM.E1KSSKM.size()>0){
		return root.CLFMAS02.IDOC.E1OCLFM.E1KSSKM.CLASS.text()
	}else {
		return null
	}
}
def processVariantValueCategories(context, artmas, attributes){
    def baseArticleID = artmas.IDOC.E1BPE1MATHEAD.MATERIAL.text()
    def counter=0
    def batchSequenceMap =[:]
    artmas.IDOC.E1BPE1AUSPRT.each{ ausprt->
        batchSequenceMap.put(ausprt.MATERIAL.text()+ausprt.CHAR_NAME.text(),0)
    }

    def builder = new StreamingMarkupBuilder()
    def batchParts = builder.bind {
			  artmas.IDOC.E1BPE1AUSPRT.each{ chars->
			    if(attributes.contains(chars.CHAR_NAME.text())){
			        def batchAttributeValueLangList = [:]
                    def batchLangChangeSets = [:]
                    def langs =[]

			        def chr_root = processXMLData(context.getProperty(chars.CHAR_NAME.text()+'CHRMAS_XML'))
			        def dataType = chr_root.IDOC.E1CABNM.ATFOR.text()
                    def rangesAllowed = chr_root.IDOC.E1CABNM.ATINT.text()
                    //def lang = chr_root.IDOC.E1CABNM.E1CABTM.SPRAS_ISO.text()
                    
                    chr_root.IDOC.E1CABNM.E1CABTM.each{lang->
                        langs.add(lang.SPRAS_ISO.text())
                    }
                    
                    def charUnit = chr_root.IDOC.E1CABNM.MSEHI.text()
                    if(null == charUnit){
                        charUnit =''
                    }else{
                        charUnit = ' '+charUnit
                    }
                    
                    def sequenceNumber = batchSequenceMap.get(chars.MATERIAL.text()+chars.CHAR_NAME.text())+1
                    batchSequenceMap.put(chars.MATERIAL.text()+chars.CHAR_NAME.text(),sequenceNumber)
                    
                    if(dataType.equals('NUM')) {
	                    if(rangesAllowed != null && rangesAllowed.equals('X')){
	                        def charValueFloatFrom=chars.CHAR_VAL_FLOAT_FROM.text()
	                        def charValueFloatTo=chars.CHAR_VAL_FLOAT_TO.text()
	                        def dependencyCode=chars.CHAR_VAL_DEPENDENCY_CODE.text()
	                        
                            batchLangChangeSets.put(convertNumberRangeForVariantValueID(charValueFloatFrom, charValueFloatTo, dependencyCode)+charUnit,langs)
                            batchAttributeValueLangList.put(convertNumberRangeForVariantValueID(charValueFloatFrom, charValueFloatTo, dependencyCode),batchLangChangeSets )
                            batchLangChangeSets = [:];
	                    }else{
                            batchLangChangeSets.put(chars.CHAR_VALUE.text()+charUnit,langs)
                            batchAttributeValueLangList.put(chars.CHAR_VALUE.text(),batchLangChangeSets )
                            batchLangChangeSets = [:];
	                    }
	                }else{

                            batchLangChangeSets.put(chars.CHAR_VALUE.text(),langs)
                            batchAttributeValueLangList.put(chars.CHAR_VALUE.text(),batchLangChangeSets )
                            batchLangChangeSets = [:];
	                }
	                batchAttributeValueLangList.each{ key,value ->
					 batchChangeSet {
						 batchChangeSetPart{
							 method('POST')
							 VariantValueCategories{
								 VariantValueCategory{
									 integrationKey('')
									 code(baseArticleID+'_'+chars.CHAR_NAME.text()+'_'+key)
									 sequence(++counter)
									 localizedAttributes{
                                        value.each {langKey,langValue->
                                            langValue.each{val->
                                            Localized___VariantValueCategory{
                                                    name(langKey)
                                                    language(val.toLowerCase())
                                                }
                                            }
									    }
                                    }
									 catalogVersion{
										 CatalogVersion{
											 integrationKey('')
											 version('ERP_IMPORT')
											 catalog{
												 Catalog{
													 integrationKey('')
													 id('ERP_CLASSIFICATION_'+'026')
												 }
											 }
										 }
									 }
									 supercategories{
									     	Category{
    			                                integrationKey('')
    			                                 code(baseArticleID+'_'+chars.CHAR_NAME.text())
    			                                 catalogVersion {
    				                                CatalogVersion{
    					                                       integrationKey('')
    					                                        version('ERP_IMPORT')
    					                                        catalog{
    						                                        Catalog{
    							                                            integrationKey('')
    							                                            id('ERP_CLASSIFICATION_'+'026')
    						                                        }
    					                                        }
    				                                        }
    			                                        }
    	                                    	}
									 }
								 }
							 }
						 }
					 }
			        }
			    }
			 }

  	}
    return batchParts;
}

def extractAttributes(String fileName) {
	def relevantAttributes = []
	def root = processXMLData(fileName)
	if(null != root && !root.text().contains('NOTFOUND') && root.IDOC.E1KLAHM.E1KSMLM.size()>0) {
		root.IDOC.E1KLAHM.E1KSMLM.each{ it->
			if(null != it.RELEV && it.RELEV.text().equals('2')) {
				relevantAttributes.add(it.ATNAM.text())
			}
		}
	}
    return relevantAttributes
}

def formatNumber(String number){
    return convertNonLocalizedNumber(number);
}

def convertNonLocalizedNumberForVariantValueID(String number){
    return convertNonLocalizedNumber(number).replaceAll(",", "x").replaceAll("\\.", "x")
}

def convertNonLocalizedNumber(String number) {
	def maxFractionDigits = 9;

	java.text.NumberFormat numberFormat = NumberFormat.getInstance(java.util.Locale.ENGLISH);
	java.lang.Number parsedNumber = numberFormat.parse(number.replaceFirst("E\\+", "E"));
	java.text.DecimalFormat decimalFormat = (java.text.DecimalFormat)java.text.NumberFormat.getNumberInstance(java.util.Locale.ENGLISH)
	decimalFormat.setMaximumFractionDigits(maxFractionDigits);
	decimalFormat.setGroupingUsed(false);

	return decimalFormat.format(parsedNumber)

}

def convertNumberRangeForVariantValueID(String numberFrom, String numberTo, String dependencyCode){
		String rangeID;
        String formattedNumberFrom = convertNonLocalizedNumber(numberFrom);
		String formattedNumberTo = convertNonLocalizedNumber(numberTo);
		switch (dependencyCode)
		{
			case "1":
				rangeID = formattedNumberFrom;
				break;
			case "2":
				rangeID = ">=".concat(formattedNumberFrom.concat("<").concat(formattedNumberTo));
				break;
			case "3":
				rangeID = ">=".concat(formattedNumberFrom.concat("<=").concat(formattedNumberTo));
				break;
			case "4":
				rangeID = ">".concat(formattedNumberFrom.concat("<").concat(formattedNumberTo));
				break;
			case "5":
				rangeID = ">".concat(formattedNumberFrom.concat("<=").concat(formattedNumberTo));
				break;
			case "6":
				rangeID = "<".concat(formattedNumberFrom);
				break;
			case "7":
				rangeID = "<=".concat(formattedNumberFrom);
				break;
			case "8":
				rangeID = ">".concat(formattedNumberFrom);
				break;
			case "9":
				rangeID = ">=".concat(formattedNumberFrom);
				break;
		}

		return rangeID;
}
