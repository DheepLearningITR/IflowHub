import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def int getNumber(s){
    if (s instanceof String){
        return Integer.parseInt(s) 
    } else {
        return s
    }
}


def Message setRowsProperties(Message message) {


    def body = message.getBody(String.class)

    def startRowProp = message.getProperty("startRow")
    def startRow = getNumber(startRowProp)
    
    def endRowProp = message.getProperty("endRow")
    def endRow = getNumber(endRowProp)
    
    def executePageSize = message.getProperty("executePageSize")
    def pageSize = getNumber(executePageSize)
    
    def numberOfItemsProp = message.getProperty("numberOfItems")
    def numberOfItems = getNumber(numberOfItemsProp)
    
    if (endRow > 0){
        startRow = startRow + pageSize
    }
    
    endRow = endRow + pageSize
    
    if (numberOfItems <= endRow){
        endRow = numberOfItems 
        message.setProperty("hasMoreRecords", "false")
    }
    
    message.setProperty("startRow", startRow)
    message.setProperty("endRow", endRow)

    return message
}
