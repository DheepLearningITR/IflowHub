import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
def Message processData(Message message){
 def body = message.getBody(java.lang.String);
 def query = new XmlSlurper().parseText(body);
 boolean flag=false
 
 query.BusinessPartnerSUITEReplicateRequestMessage.each{
     if(it.BusinessPartner.AddressInformation.text()=="")
         it.replaceNode {};
     else
       flag=true
  } 
 /* Commented to add MultiComapnyloic
 if(flag==false)
 message.setProperty("flag","false")
 */
 message.setProperty("flag",flag) //Added to include MultiCompany Logic
 def valid_data = XmlUtil.serialize(query);
 message.setBody(valid_data);
 return message;
}