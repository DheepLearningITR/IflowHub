import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
  def body = message.getBody(java.lang.String) as String;
  body = body.replace("{\"@nil\":\"true\"}","null");
  def jsonParser = new JsonSlurper();
  def jsonObject = jsonParser.parseText(body); 
  def String newJson = "[ ]";
  def newJsonObject = jsonParser.parseText(newJson);
  jsonObject.MultiAddress.Address.each { Multiadd->
    Multiadd.each{ Singleadd->
        newJsonObject.add(Singleadd);
    }
  }
  message.setBody(JsonOutput.toJson(newJsonObject));
  message.setProperty("RequestPayload", JsonOutput.toJson(newJsonObject));
  
  // To access FSM, company and account are required -- either their name or their ID.
  // If the IDs are configured, they are used; otherwise, the names are used.
  def accountCompany = '';
  def accountID = message.getProperty('X-Account-ID');
  def companyID = message.getProperty('X-Company-ID');
  
  accountCompanyUser = '';
  message.setHeader('X-Account-ID', accountID);
  message.setHeader('X-Company-ID', companyID);
  
  message.setProperty('AccountCompany', accountCompany);
  return message;
}
