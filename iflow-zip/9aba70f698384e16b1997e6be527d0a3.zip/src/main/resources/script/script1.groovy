import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.securestore.*;
import java.util.HashMap;
import java.net.URL;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import src.main.resources.script.CPILogger;

class ECUser {
	String name;
	String data_v1;
	def void setPass(String pass, String key) {
		Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, aesKey);
		data_v1 = cipher.doFinal(pass.getBytes()).encodeBase64().toString();
	}
	def String getPass(String key) {
		Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, aesKey);
		return new String(cipher.doFinal(data_v1.decodeBase64()));
	}
}

def Message checkECUserInPD(Message message) {
	def headers = message.getHeaders();
	def props = message.getProperties();
	def ecuid = headers.get("ECUID");
	if (ecuid != null){
		def pdService = ITApiFactory.getApi(PartnerDirectoryService.class, null);
		if (pdService == null){
			throw new IllegalStateException("Partner Directory Service not found");
		}
		def ecUserJson = pdService.getParameter("EC_USER", "HRNO_ECUID_"+ecuid , String.class);
		if (ecUserJson != null){
			JsonSlurper slurper = new JsonSlurper();
			def object = slurper.parseText(ecUserJson);
			def ecUser = new ECUser(object);
			message.setProperty("EC_USER_NAME", ecUser.name );
			def secureService = ITApiFactory.getApi(SecureStoreService.class, null);
			if (secureService == null){
				throw new IllegalStateException("Secure Store Service not found");
			}
			def pdMasterPasswordAlias = props.get("EC_USER_MASTER_PASSWORD_ALIAS");
			def credential = secureService.getUserCredential(pdMasterPasswordAlias);
			if (credential == null){
				throw new IllegalStateException("No credential found for alias '${pdMasterPasswordAlias}'");
			}
		}
	}
	return message;
}

def Message createEC_USER(Message message) {
	def props = message.getProperties();
	def secureService = ITApiFactory.getApi(SecureStoreService.class, null);
	if (secureService == null){
		throw new IllegalStateException("Secure Store Service not found");
	}
	def pdMasterPasswordAlias = props.get("EC_USER_MASTER_PASSWORD_ALIAS");
	def credential = secureService.getUserCredential(pdMasterPasswordAlias);
	if (credential == null){
		throw new IllegalStateException("No credential found for alias '${pdMasterPasswordAlias}'");
	}
	def ecUser = new ECUser(name: props.get("ECUNAME"));
	ecUser.setPass(props.get("ECUPASS"), new String(credential.getPassword()) );
    def mapECUser = ecUser.properties.findAll { !it.key.equals('class') && it.value };
	message.setProperty("EC_USER", JsonOutput.toJson(mapECUser) );
	return message;
}

def Message createECUID(Message message) {
	def props = message.getProperties();
	def ecuid = UUID.randomUUID().toString().replace("-", "").toUpperCase();
	message.setProperty("ECUID", ecuid );
	return message;
}

def Message processData(Message message) {
	def log_suffix = 'general';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_logid_in(Message message) {
	def props = message.getProperties();
	def logID = props.get("LOG_ID");
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${logID}_in", message);
	return message;
}

def Message log_logid_out(Message message) {
	def props = message.getProperties();
	def logID = props.get("LOG_ID");
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${logID}_out", message);
	return message;
}

def Message log_req_in(Message message) {
	def log_suffix = 'req_in';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_res_out(Message message) {
	def log_suffix = 'res_out';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}