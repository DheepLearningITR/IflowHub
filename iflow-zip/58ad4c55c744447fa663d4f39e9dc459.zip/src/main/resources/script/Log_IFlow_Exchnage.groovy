import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.Exception;
import java.util.Map.Entry;

def Message processData(Message message) {

		def body = message.getBody(java.lang.String) as String;
		def messageLog = messageLogFactory.getMessageLog(message);
		if(messageLog != null){
			messageLog.addAttachmentAsString("Payload", body, "text/xml");
		}
		
		def headerMap=message.getHeaders();
		def all= "";
		for (Entry<Integer, Integer> entry : headerMap.entrySet()) {
            all= all.concat("[Key = " + entry.getKey() + ", Value = " + entry.getValue() + "]\n");
        }
		messageLog.addAttachmentAsString("Headers", all, "text/xml");
		
		def propertiesMap=message.getProperties();
		all= "";
		for (Entry<Integer, Integer> entry : propertiesMap.entrySet()) {
            all= all.concat("[Key = " + entry.getKey() + ", Value = " + entry.getValue() + "]\n");
        }
		messageLog.addAttachmentAsString("Properties", all, "text/xml");


	return message;
}
