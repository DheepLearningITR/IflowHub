import com.sap.it.api.mapping.*;

def String customFunc(String arg1){
    def cleanedTimeString = arg1.replaceAll('[\\+\\-]', '')
	return cleanedTimeString
}