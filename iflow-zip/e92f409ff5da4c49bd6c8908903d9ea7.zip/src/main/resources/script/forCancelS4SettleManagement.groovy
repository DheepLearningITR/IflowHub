package cancel.s4settle

import groovy.util.slurpersupport.GPathResult
import groovy.xml.XmlUtil
import groovy.xml.StreamingMarkupBuilder
import com.sap.gateway.ip.core.customdev.util.Message

import java.time.LocalDateTime

import static java.util.stream.Collectors.groupingBy
import static java.util.stream.Collectors.mapping
import static java.util.stream.Collectors.toSet


def toSettleGet(GPathResult origBody) {
    def mkpBuilder = new StreamingMarkupBuilder()

    mkpBuilder.encoding = 'utf-8'

    def tpmDocumentNumbers = origBody.bo.root.docFlow.findAll({ it?.documentType?.text() == 'SETTLEMENT_DOCUMENT' })?.documentNumber?.collect({ it.text() })
    def tpmDocumentNumberSet = tpmDocumentNumbers == null ? [] : tpmDocumentNumbers.findAll({ it }).toSet()

    def xmlGetSettle = mkpBuilder.bind { bld ->
        mkp.xmlDeclaration()
        mkp.declareNamespace(ns_func: 'urn:sap-com:document:sap:rfc:functions')

        ns_func.BAPI_SINGLESETTREQS_GETLIST {
            MAXLINES(500) // Only load 500 record lines

            REFDOCNORANGE {
                if (tpmDocumentNumberSet.size() > 0) {
                    for (def tpmDocNumber in tpmDocumentNumberSet) {
                        item {
                            SIGN('I')
                            OPTION('EQ')
                            LOW(tpmDocNumber.padLeft(10, '0'))
                        }
                    }
                } else {
                    item {
                        SIGN('I')
                        OPTION('EQ')
                        LOW('NO_DOC_NUM')
                    }
                }
            }
        }
    }

    def errMsg = tpmDocumentNumberSet.size() > 0 ? '' : 'There is no SETTLEMENT_DOCUMENT <docFlow> element.'

    return [XmlUtil.serialize(xmlGetSettle), errMsg]
}

String appendRequestResponseInto(origBody, req, resp, docTrans) { // re-use
    def mkpBuilder = new StreamingMarkupBuilder()

    mkpBuilder.encoding = 'utf-8'

    def appendMsgXml = mkpBuilder.bind { bld ->
        mkp.xmlDeclaration()

        message {
            // append original bo
            origBody.bo.build(bld)

            // append documentTransactions
            for (documentTransactions in origBody.documentTransactions) {
                documentTransactions.build(bld)
            }

            for (def docTran in docTrans) {
                if (docTran instanceof String) {
                    mkp.yieldUnescaped(docTran.replaceFirst(/<\?xml.+\?>/, ''))
                } else {
                    docTran.build(bld)
                }
            }

            // append current tran
            trans {
                for (tran in origBody.trans.tran) {
                    tran.build(bld)
                }

                if (null != req && null != resp) {
                    def apiName = 'S4Settlement'
                    def curCallOrder = origBody.trans.tran.findAll({ it.@api == apiName }).size()

                    tran(api: apiName, callOrder: curCallOrder) {
                        request {
                            body(req)
                        }
                        response(resp)
                    }
                }
            }
        }
    }

    return XmlUtil.serialize(appendMsgXml)
}

/**
 * Step(0)
 *
 * */
def sleepBetweenEachCall(Message msg) {
    // get the retry times & setting
    def propMap = msg.getProperties()
    def retryTime = propMap.getOrDefault('retryTime', 0)
    def isExpDelay = propMap.getOrDefault('isExpDelay', 'F')
    def errorRetryInterval = Integer.parseInt(propMap.getOrDefault('retryInterval', '30').toString())

    // sleep given time
    if (retryTime > 0) {
        def obj = new Object()
        if (isExpDelay in ['T', 't', 'True', 'true', 'TRUE']) {
            obj.sleep((2**retryTime) * 1000)
        } else {
            obj.sleep(errorRetryInterval*1000)
        }
    }

    // set back the retry time
    msg.setProperty('retryTime', ++retryTime)

    return msg
}

class MsgWrapper {

    private Message msg;
    private XmlSlurper xmlSlp;

    MsgWrapper(Message msg) {
        this.msg = msg
        this.xmlSlp = new XmlSlurper()
    }

    def getMsg() {
        return msg
    }

    private GPathResult getXmlGPathFromMsgProperty(String property) {
        def propertyVal = msg.getProperty(property) as String

        return propertyVal ? xmlSlp.parseText(propertyVal) : null
    }

    GPathResult getRequest() {
        return xmlSlp.parseText(msg.getProperty('request') as String)
    }

    void setRequest(String request) {
        msg.setProperty('request', request)
    }

    GPathResult getResponse() {
        return xmlSlp.parseText(msg.getProperty('response') as String)
    }

    void setResponse(String response) {
        msg.setProperty('response', response)
    }

    GPathResult getOrigBody() {
        return getXmlGPathFromMsgProperty('origBody')
    }

    void setOrigBody(String origBody) {
        msg.setProperty('origBody', origBody)
    }

    String getSettleStatus() {
        return msg.getProperty('settleStatus') as String
    }

    void setSettleStatus(String status) {
        msg.setProperty('settleStatus', status)
    }

    String getSettleErrMsg() {
        return msg.getProperty('settleErrMsg') as String
    }

    void setSettleErrMsg(String status) {
        msg.setProperty('settleErrMsg', status)
    }

    boolean getNeedRetry() {
        return 'T' == (msg.getProperty('needRetry') as String)
    }

    void setNeedRetry(boolean needRetry) {
        msg.setProperty('needRetry', needRetry ? 'T' : 'F')
    }

    void setTenantId(String tenantId) {
        msg.setProperty('X-Tenant-ID', tenantId)
    }

    String getTenantId() {
        return msg.getProperty('X-Tenant-ID') as String
    }

    void setStepInfo(String step) {
        msg.setProperty('stepInfo', step)
    }

    String getStepInfo() {
        return msg.getProperties().getOrDefault('stepInfo', null) as String
    }

    GPathResult getBody() {
        return xmlSlp.parseText(msg.getBody(String.class) as String)
    }

    void setBody(String body) {
        msg.setBody(body)
    }
}

def transferS4SettleGetRequest(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'prepare get S4 settle request'

    // get the whole body and saved into a property 'origBody'
    msgWrapper.origBody = msg.getBody(String)
    msgWrapper.tenantId = msg.getHeader('X-Tenant-ID', String)

    // fetch and build request for get settle
    def (strSettleRequest, errMsg) = toSettleGet(msgWrapper.origBody)
    msgWrapper.body = strSettleRequest

    // keep the request payload into a property 'request'
    msgWrapper.request = strSettleRequest

    // set the property 'needRetry'
    msgWrapper.needRetry = true

    if (errMsg?.trim()) {
        msgWrapper.settleErrMsg = errMsg
    }

    return msg
}

enum ResponseStatus {
    needRetry,
    blockError,
    accept
}

def handleResponseNeedRetry(GPathResult origBody, GPathResult resp) {

    def s4DocumentNumbers = origBody.bo.root.docFlow.findAll({ it?.documentType?.text() == 'SETTLEMENT_S4_DOCUMENT' })?.documentNumber?.collect({ it.text().padLeft(10, '0') })
    def s4DocumentNumberSet = s4DocumentNumbers == null ? [] : s4DocumentNumbers.findAll({ it }).toSet()

    def lineItemNode = resp."**".find({ it.name() == "ITEMDATAOUT" })

    def s4CancellationDocItems = lineItemNode.item.findAll({ s4DocumentNumberSet.contains(it.ORIG_DOC_HEAD.text()) }).collect({ it })
    def itemDocNumberGroups = s4CancellationDocItems.stream()
            .collect(groupingBy({ it.ORIG_DOC_HEAD?.text() }, mapping({ it.DOCUMENT_NUMBER?.text() }, toSet())))

    if (itemDocNumberGroups.size() < s4DocumentNumberSet.size()) {
        def notFoundS4DocNum = s4DocumentNumberSet.findAll({ !itemDocNumberGroups.keySet().contains(it) }).join(', ')

        return [ResponseStatus.needRetry, new ArrayList<String>(), "The following S4 document numbers are not found in the response: ${notFoundS4DocNum}."]
    }

    def allNotUniqueGroups = itemDocNumberGroups.entrySet().findAll({ it.value.size() > 1 }).collect()
    if (allNotUniqueGroups.size() > 0) {
        def notUniqueInform = allNotUniqueGroups.collect({ "${it.key} => [${it.value.join(', ')}]" }).join(', ')

        return [ResponseStatus.blockError, new ArrayList<String>(), "The following S4 document numbers are associated with more then one item in the response: ${notUniqueInform}."]
    }

    def errMessages = new ArrayList<String>()
    def docTrans = new HashSet<String>()
    for (def itemDocNumGroup in itemDocNumberGroups.entrySet()) {

        def itemDocNum = itemDocNumGroup.value.first()
        def headItemNode = resp."**".find({ it.name() == "HEADDATAOUT" })
        def s4CancellationHeads = headItemNode.item.findAll({ it.DOCUMENT_NUMBER?.text() == itemDocNum })

        def isPassed = false
        for (head in s4CancellationHeads) {
            def docNumber = head.DOCUMENT_NUMBER.text()
            def companyCode = head.COMP_CODE?.text()

            if ([docNumber, companyCode].every({ !it.isEmpty() })) {
                def docTranDateTime = LocalDateTime.now()

                def docTran = responseToDocumentTransaction(docNumber, companyCode, '', docTranDateTime)

                docTrans.add(docTran)
                isPassed = true
                break
            }
        }
        if (!isPassed) {
            errMessages.add("For ${itemDocNumGroup.key} failed to get valid document head line by item for document number: ${itemDocNum}.")
        }
    }

    if (errMessages.size() == 0) {
        return [ResponseStatus.accept, docTrans.toList(), 'successful']
    }

    def returnNode = resp.RETURN
    def returnItem = returnNode.item.collect({ it.MESSAGE.text() }).findAll({ !it.isEmpty() }).join(', ')
    def errMsg = ""
    if (returnItem) {
        errMsg += "Message from S4: ${returnItem}."
    }
    if (errMessages.size() > 0) {
        errMsg += "Message from artifact: ${errMessages.join(', ')}."
    }

    return [ResponseStatus.needRetry, new ArrayList<String>(), errMsg]
}

String responseToDocumentTransaction(docNumber, companyCode, fiscalYear, settleDT) {
    // Build documentTransaction
    def mkpBuilder = new StreamingMarkupBuilder();

    mkpBuilder.encoding = 'utf-8'

    def docTranXml = mkpBuilder.bind { bld ->
        mkp.xmlDeclaration()

        bld.documentTransactions {
            bld.documentNumber(docNumber)
            bld.documentType('SETTLEMENT_S4_CANCELLATION_DOCUMENT')
            bld.fiscalYear(fiscalYear)
            bld.createdOn(settleDT)
            bld.companyCode(companyCode)
        }
    }

    return XmlUtil.serialize(docTranXml)
}

String toClaimsSettlementCallback(origBody, settleStatus, settleErrMsg) {
    def mkpBuilder = new StreamingMarkupBuilder();

    mkpBuilder.encoding = 'utf-8'

    StringBuilder messageBuilder = new StringBuilder();
    if (settleErrMsg != null && settleErrMsg.length() > 0) {
        messageBuilder.append("Failed to get cancellation settlement in SAP S/4HANA. \n")
        messageBuilder.append(settleErrMsg)
        settleErrMsg = messageBuilder.toString()
    }


    def callbackXml = mkpBuilder.bind { bld ->
        mkp.xmlDeclaration()

        bld.root {
            mkp.comment("the settle process")

            def settlement = origBody.bo

            bld.settlementUUID(settlement.root.settlementUUID.text())
            bld.timestamp(LocalDateTime.now())
            bld.status(settleStatus)

            origBody.documentTransactions.build(bld)

            bld.message(settleErrMsg)
        }
    }

    return XmlUtil.serialize(callbackXml)
}

def mergeGetSettleResponse(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'merge S4 response into orig-body'

    // get the response from message body & keep the response payload into property 'response'
    msgWrapper.response = msg.getBody(String)

    def appendedBody = appendRequestResponseInto(msgWrapper.origBody, msgWrapper.request, msgWrapper.response, new ArrayList())
    msgWrapper.body = appendedBody
    msgWrapper.origBody = appendedBody

    return msg
}

def handleSettleResponseForRetry(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'calc settle response for needRetry'

    def (respStatus, documentTransactions, errMsg) = handleResponseNeedRetry(msgWrapper.origBody, msgWrapper.response)

    // merge current documentTransaction if settle successful
    if (respStatus == ResponseStatus.accept) {
        def appendBody = appendRequestResponseInto(msgWrapper.origBody, null, null, documentTransactions)

        msgWrapper.origBody = appendBody
        msgWrapper.body = appendBody
    }

    // set the property 'needRetry' & 'settleErrMsg'
    msgWrapper.settleStatus = (respStatus != ResponseStatus.accept ? 'ERROR' : '')
    if (errMsg?.trim()) {
        msgWrapper.settleErrMsg = errMsg
    }
    msgWrapper.needRetry = (respStatus == ResponseStatus.needRetry)

    return msg
}

def transferToClaimsSettlementCallback(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'prepare callback message for error settle'

    msgWrapper.body = toClaimsSettlementCallback(msgWrapper.origBody, msgWrapper.settleStatus, msgWrapper.settleErrMsg)
    msg.setHeader('X-Tenant-ID', msgWrapper.tenantId)

    return msg
}

def transferExceptionToClaimsSettlementCallback(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'prepare callback message for exception'

    // If there is exception happened in following step, the 'origBody' might be empty.
    if (msgWrapper.origBody == null) {
        msgWrapper.origBody = msg.getBody(String)
    }
    if (!(msgWrapper.settleStatus?.trim())) {
        msgWrapper.settleStatus = 'ERROR'
    }
    String camelException = msg.getProperty('CamelExceptionCaught') as String
    String errorMessages = msgWrapper.settleErrMsg
    if (camelException != null && camelException.trim().length() > 0) {
        errorMessages = camelException + "\n\n" + "response message:" + errorMessages
    }

    msgWrapper.body = toClaimsSettlementCallback(
            msgWrapper.origBody, msgWrapper.settleStatus, errorMessages)
    msg.setHeader('X-Tenant-ID', msgWrapper.tenantId)

    return msg
}

/**
 * Log all these message part
 *
 * */
def logFormatStr(String body, boolean compactXml) {
    if (body.startsWith('<?xml')) {
        if (!compactXml) {
            return XmlUtil.serialize(new XmlSlurper().parseText(body))
        } else {
            return body.replaceAll(/>\s+</, '><').trim()
        }
    }

    return body
}

def logFormatHeaderOrProperty(Map<String, Object> headerOrProperty) {
    def allStringValKeys = headerOrProperty.findAll({ it.value instanceof String }).collect({ it.key })
    allStringValKeys = allStringValKeys.sort()

    def maxKeyLen = allStringValKeys.collect({ it.size() }).max()
    return allStringValKeys.collect({ "${it.padRight(maxKeyLen)} : ${logFormatStr(headerOrProperty.get(it), true)}" }).join('\n')
}

def logAllOfMessage(Message msg) {
    // get log execute times
    def propMap = msg.getProperties()

    def printLogTimes = propMap.getOrDefault('printLogTimes', new HashMap<String, Integer>()) as Map<String, Integer>
    def msgWrapper = new MsgWrapper(msg)

    // get Header, Property & Body
    def headers = logFormatHeaderOrProperty(msg.getHeaders())
    def properties = logFormatHeaderOrProperty(msg.getProperties())
    def body = logFormatStr(msg.getBody(java.lang.String) as String, false)

    def stepTime = msgWrapper.stepInfo ? printLogTimes.getOrDefault(msgWrapper.stepInfo, 0) : 0
    def stepName = msgWrapper.stepInfo ? "${msgWrapper.stepInfo} ($stepTime)" : ''
    def globalStepTime = printLogTimes.getOrDefault('_GlobalStepTime', 0)
    def messageLog = messageLogFactory.getMessageLog(msg)
    if (messageLog != null)
    {
        def logText = '--------------------- Header ---------------------\n' + headers
        logText += '\n-------------------- Property --------------------\n' + properties
        logText += '\n---------------------- Body ----------------------\n' + body
        messageLog.addAttachmentAsString("Log ($globalStepTime) at $stepName:", logText, "text/plain")
    }

    if (msgWrapper.stepInfo) {
        printLogTimes.put(msgWrapper.stepInfo, ++stepTime)
    }
    printLogTimes.put('_GlobalStepTime', ++globalStepTime)
    msg.setProperty('printLogTimes', printLogTimes)

    return msg
}

def setContinueFlag(Message message){
    //Body
    def body = message.getBody(java.lang.String) as String;
    def parser = new XmlParser()
    def dom = parser.parseText(body)
    message.setProperty("I_CONTINUE", "T")
    def s4SettlementDocNumList = dom.bo.root.docFlow.findAll({ it.documentType.text() == 'SETTLEMENT_S4_DOCUMENT' }).collect({it->it.documentNumber?.text()})
    if(s4SettlementDocNumList == null || s4SettlementDocNumList.size() == 0){
        message.setProperty("I_CONTINUE", "F")
    }
    return message
}


def cancellationCompletionCallback(Message msg){
    def msgWrapper = new MsgWrapper(msg)
    if (msgWrapper.origBody == null) {
        msgWrapper.origBody = msg.getBody(String)
    }
    msgWrapper.body = toClaimsSettlementCallback(msgWrapper.origBody, 'CANCELLED', '')

    msg.setHeader('X-Tenant-ID', msgWrapper.tenantId)

    return msg
}

