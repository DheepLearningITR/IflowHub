import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;

@Field String FULFILLMENT_REQUEST_ID = 'Fulfillment Request ID';
@Field String DOCUMENT_NUMBER = 'Document Number';

def Message setHeaders(Message message) {
    def properties = message.getProperties();
	String fulfillmentRequestId = properties.get("externalDocumentId");
	String docNumber = properties.get("returnOrderId");
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
		// Add custom header for property 'fulfillmentRequestId' using the same text as in CALM
		messageLog.addCustomHeaderProperty(FULFILLMENT_REQUEST_ID, fulfillmentRequestId);
        messageLog.addCustomHeaderProperty(DOCUMENT_NUMBER, docNumber);

    }
    return message;
}