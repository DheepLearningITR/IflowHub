import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;
import groovy.json.JsonOutput;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;



@Field String soapNamespace = 'http://schemas.xmlsoap.org/soap/envelope/';


def Message confirmationRequest(Message message) {	
	def headers = message.getHeaders();
	def properties = message.getProperties();
	headers.put("Content-Type",   "application/json");
		
	def request = [:];		
	request["fulfillmentRequestId"] = properties.get("externalDocumentId").replaceAll('\n','').trim();
	request["documentNumber"] = properties.get("returnOrderId").replaceAll('\n','').trim();
	
	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(request)));

	return message;	
}


def Message exceptionDetails(Message message) {	
	
	def properties = message.getProperties();
	
    def exception = properties.get('CamelExceptionCaught');
    if(exception!=null){
        if(exception.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")){
            def body = exception.getResponseBody();
            message.setBody(body);
            def exceptionBody= exception.getResponseBody();
            def js = new JsonSlurper();
            def exceptionObject = js.parseText(exceptionBody);
            	
        	def writer = new StringWriter()
        	def xmlBuilder = new MarkupBuilder(writer)
        	xmlBuilder.doubleQuotes = true;
        	xmlBuilder.'soap:Envelope'('xmlns:soap':soapNamespace){
        	    'soap:Body'{
            	    'soap:Fault'{
            	            'faultcode'(exceptionObject.error.code)
            	            'faultstring'(exceptionObject.error.message)
            	    }
        	    }
        	}
    		String soapResponse = writer.toString()	
    		message.setBody(soapResponse)
        }
        
        
    }
	return message;	
}

def Message confirmationResponse (Message message){
    def exception = properties.get('CamelExceptionCaught');
    if(exception==null){
        def body = message.getBody(java.lang.String) as String;
        def js = new JsonSlurper();
        def bodyObject = js.parseText(body);
        def headers = message.getHeaders();
	    def respCode = headers.get("CamelHttpResponseCode") as String;
        if(respCode=='400'){
         confirmationResponseBadRequest(message);
        }else{
            
        def writer = new StringWriter();
        def xmlBuilder = new MarkupBuilder(writer);
        xmlBuilder.doubleQuotes = true;
        xmlBuilder.'soap:Envelope'('xmlns:soap':soapNamespace){
            'soap:Body'{
                'soap:Result'{
                    'fulfillmentRequestId'(bodyObject.fulfillmentRequestId)
                    'responseMessage'(bodyObject.message)
                    'documentNumber'(bodyObject.documentNumber)
                }
            }
        }
        
        String soapResponse = writer.toString();
        message.setBody(soapResponse);
        }
    }
    
    
    return message;
}


def void confirmationResponseBadRequest(Message message){
        def writer = new StringWriter();
        def xmlBuilder = new MarkupBuilder(writer);
        def body = message.getBody(java.lang.String) as String;
        def js = new JsonSlurper();
        def bodyObject = js.parseText(body);

        xmlBuilder.doubleQuotes = true;
        xmlBuilder.'soap:Envelope'('xmlns:soap':soapNamespace){
        	    'soap:Body'{
            	    'soap:Fault'{
            	            'faultcode'(bodyObject.error.code)
            	            'faultstring'(bodyObject.error.message)
            	    }
        	    }
        	}
        String soapResponse = writer.toString();
        message.setBody(soapResponse);
        
}
