import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def properties = message.getProperties()
    def errorBody = ''

    def exception = properties.get('CamelExceptionCaught')
    if (exception) {
        errorBody = 'ERROR: ErrorSendingEmail' + "\n"
        errorBody += 'Error in Send Email Notifiaction Subprocess' + "\n"
        def exceptionProperties = exception.getProperties()
        errorBody += "Exception Class: " + exceptionProperties.get("class") + "\n"
        errorBody += "Message: " + exceptionProperties.get("message") + "\n"
    }

    message.setBody(errorBody)
    return message
}