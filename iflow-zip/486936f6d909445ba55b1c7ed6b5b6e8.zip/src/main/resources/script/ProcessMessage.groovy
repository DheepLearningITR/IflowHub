
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper


def Message getCreatedContract(Message message){
    def body = message.getBody(String.class)

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)
    
    message.setProperty("error", 'true')

    if (json.content?.properties?.SalesContract){
        message.setBody(json.content.properties.SalesContract)
        message.setProperty("error", 'false')
    }else if (json.message?."\$"){
        message.setBody(json.message?."\$")
        
    } 
    
    return message
}


def Message shouldRefreshToken(Message message) {
       
        def body = message.getBody(String.class)
        

        message.setProperty("refresh", "CSRF token validation failed" == body)
      
        return message
}


def Message setUniqueId(Message message) {
       
        def body = message.getBody(String.class)
        def jsonSlurper = new JsonSlurper()
        def json = jsonSlurper.parseText(body)

        message.setProperty("uniqueId", json.uniqueName)
        
        
        return message
        
}