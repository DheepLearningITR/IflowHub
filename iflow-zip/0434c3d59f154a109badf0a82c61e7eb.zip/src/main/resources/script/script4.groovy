import groovy.json.JsonOutput;

 import com.sap.gateway.ip.core.customdev.util.Message;
 import java.util.HashMap;
 import java.util.UUID;
 import java.time.format.DateTimeFormatter;
 import java.time.LocalDateTime
 import java.time.ZoneOffset;
 import java.time.format.DateTimeFormatter
 
def Message processData(Message message) {
    def workflowRequests = message.getProperty("WORKFLOW_REQUESTS");
    def jobInfoEvents = message.getProperty("JOB_INFO_EVENTS");
    
 	def wfRequestXML = new XmlSlurper().parseText(workflowRequests)
    def wfRequestList = wfRequestXML.WfRequest
    
	def count = message.getProperty('PAGE_NUMBER_COUNT');
	def odmEvents = [];
	
	LocalDateTime ldt = LocalDateTime.now()
	DateTimeFormatter dtfC = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
	def currentDateTime = ldt.format(dtfC)
		
	wfRequestList.each { wfRequestVal ->
        String createdAt = wfRequestVal.createdDateTime;
	    String modifiedAt = wfRequestVal.lastModifiedDateTime;
	    String status = wfRequestVal.status;
	    if (createdAt != null && modifiedAt != null) {
	        // datetime format in EC response XML 2021-04-20T14:03:08.000
	        if(createdAt.length() >= 19) {
	            createdAt = createdAt.substring(0, 19)
	        }
	        if(modifiedAt.length() >= 19) {
	            modifiedAt = modifiedAt.substring(0, 19)
            }
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
            LocalDateTime createdDateTime = LocalDateTime.parse(createdAt, dtf);
            LocalDateTime modifiedDateTime = LocalDateTime.parse(modifiedAt, dtf);
            
            def odmEvent = [:];
            def odmEventData = [:];
	        
	        odmEvent.id = UUID.randomUUID().toString();
	        odmEventData.workflowRequestId = wfRequestVal.wfRequestId.text();
	        odmEventData.createdAt = createdAt + "Z";
	        odmEventData.activityProcessedAt = modifiedAt + "Z";
	        odmEventData.status = [:];
	        odmEventData.status.code = wfRequestVal.status.text();
	        odmEventData.currentStepId = wfRequestVal.currentStepNum.text();
	        odmEventData.sentAt = currentDateTime.toString();
	        odmEvent.data = odmEventData;
	        
	        odmEvents << odmEvent;
	    }
	}
	
	if (jobInfoEvents != null && !jobInfoEvents.isEmpty()) {
    	def jobInfoEventsXML = new XmlSlurper().parseText(jobInfoEvents)
        def jobInfoEventList = jobInfoEventsXML.EmpJob
    	
    	jobInfoEventList.each { jobInfoEvent ->
    	    def odmEvent = [:];
            def odmEventData = [:];
            
            // 2021-04-20T14:03:08.000 -> 2021-04-20
            def startDate = jobInfoEvent.startDate.text();
            startDate = startDate.substring(0, 10) 
            
            def lastModifiedOn = jobInfoEvent.lastModifiedOn.text();
            if (lastModifiedOn.length() >= 19) {
                lastModifiedOn = lastModifiedOn.substring(0, 19);
	        }

            odmEvent.id = UUID.randomUUID().toString();
            odmEventData.eventReason = jobInfoEvent.eventReasonNav.FOEventReason.externalCode.text();
            odmEventData.eventReasonDescription = jobInfoEvent.eventReasonNav.FOEventReason.description.text();
            odmEventData.userId = jobInfoEvent.userId.text();
            odmEventData.seqNumber = jobInfoEvent.seqNumber.text();
            odmEventData.startDate = startDate.toString();
            odmEventData.lastModifiedOn = lastModifiedOn.toString() + "Z";
            odmEventData.lastModifiedBy = jobInfoEvent.lastModifiedBy.toString();
            odmEventData.company = jobInfoEvent.companyNav.FOCompany.externalCode.text();
            odmEventData.country = jobInfoEvent.countryOfCompany.text();
            odmEventData.personIdExternal = jobInfoEvent.employmentNav.EmpEmployment.personIdExternal.text();
            //odmEventData.firstName = jobInfoEvent.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.firstName.text();
            //odmEventData.lastName = jobInfoEvent.employmentNav.EmpEmployment.personNav.PerPerson.personalInfoNav.PerPersonal.lastName.text();
            
            odmEvent.data = odmEventData;
            
            odmEvents << odmEvent;
    	}
	}
      
	message.setProperty('ODM_EVENT_COUNT', odmEvents.size());
	message.setProperty('ODM_EVENT_LOOP_INDEX', 0);
	message.setProperty('PAGE_NUMBER_COUNT', count);
    
    def eventPayload = JsonOutput.toJson(odmEvents);
    message.setProperty('ODM_WORKFLOW_EVENTS', eventPayload); 

	def messageLog = messageLogFactory.getMessageLog(message);
	def logPayload =  message.getProperty('ENABLE_PAYLOAD_LOGGING');
	if (messageLog != null  && "true".equalsIgnoreCase(logPayload)){ 
	    messageLog.addAttachmentAsString("Generated events", eventPayload, "text/plain");
	}
    message.setHeader('Content-Type', 'application/json');
	message.setBody(eventPayload);
    return message;
}