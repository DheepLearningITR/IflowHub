import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	if (messageLog != null) {
	    StringBuilder sb = new StringBuilder()
        sb.append('last modified date: ').append(message.getProperty('LAST_MODIFIED_DATETIME')).append('\n')
        sb.append('user set last modified date: ').append(message.getProperty('USER_SET_LAST_MODIFIED_DATETIME')).append('\n')
        sb.append('enable payload logging: ').append(message.getProperty('ENABLE_PAYLOAD_LOGGING')).append('\n')
		messageLog.addAttachmentAsString('External parameters', sb.toString(), 'text/plain');
	}
    return message;
}