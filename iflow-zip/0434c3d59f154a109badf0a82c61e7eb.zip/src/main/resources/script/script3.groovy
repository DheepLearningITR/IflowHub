import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def logPayload =  message.getProperty('ENABLE_PAYLOAD_LOGGING');
    def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
			if(messageLog != null && "true".equalsIgnoreCase(logPayload)){
			  messageLog.addAttachmentAsString("EC Workflow query response", body, "text/xml");
			}
	return message
}