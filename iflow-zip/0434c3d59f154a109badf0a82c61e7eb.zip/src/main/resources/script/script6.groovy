import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def logPayload =  message.getProperty('ENABLE_PAYLOAD_LOGGING');
    def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	// && "true".equalsIgnoreCase(logPayload)
			if(messageLog != null ){
			  messageLog.addAttachmentAsString("single out bound event " + message.getProperty('ODM_EVENT_LOOP_INDEX'), body, "text/plain");
			}
	return message
}