import com.sap.gateway.ip.core.customdev.util.Message;
 
def Message processData(Message message) {
 	def body = message.getBody(java.lang.String) as String;
 	message.setProperty('JOB_INFO_EVENTS', body);
 	
    def logPayload =  message.getProperty('ENABLE_PAYLOAD_LOGGING');
	def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null && "true".equalsIgnoreCase(logPayload)) {
	    messageLog.addAttachmentAsString("EC Job Info Change query response", body, "text/xml");
	}
    return message;
}