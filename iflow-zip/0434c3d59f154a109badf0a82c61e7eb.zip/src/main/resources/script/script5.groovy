import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

def Message processData(Message message) {
    //Body ${property.ODM_EVENT_LOOP_INDEX} < ${property.DOM_EVENT_COUNT}
       def body = message.getBody();
       def loopCount = message.getProperty('ODM_EVENT_LOOP_INDEX');
	   def totalCount = message.getProperty('ODM_EVENT_COUNT');
	   String odmEvents =  message.getProperty('ODM_WORKFLOW_EVENTS')
	   def messageLog = messageLogFactory.getMessageLog(message);
           /*
		   if(messageLog != null){ //application/json
		   String debugLog = "loopCount: " + loopCount + " totalCount: " + totalCount + "odmEvents isEmpty: " + odmEvents.isEmpty() + "input events: " + odmEvents.toString();
			  messageLog.addAttachmentAsString("ODM send debug", debugLog, "text/plain");
		   } */
       if(loopCount < totalCount && odmEvents != null && !odmEvents.isEmpty() ) {
           def eventList = new JsonSlurper().parseText(odmEvents);
           def odmEvent = eventList.get(loopCount);
           //eventList.remove(0);
           def odmOutEvents = [];
           odmOutEvents << odmEvent;
           String singleEventPayload = JsonOutput.toJson(odmEvent);
      /*
		   if(messageLog != null){ //application/json
			  messageLog.addAttachmentAsString("ODM send single event " + loopCount, singleEventPayload, "text/plain");
		   } */
         loopCount++;
         message.setProperty('ODM_EVENT_LOOP_INDEX', loopCount);
         //message.setProperty('ODM_EVENT_COUNT', eventList.size());
         
         // set body
         message.setHeader('Content-Type', 'application/json');
	     message.setBody(singleEventPayload);
     }
    
	  
       return message;
}