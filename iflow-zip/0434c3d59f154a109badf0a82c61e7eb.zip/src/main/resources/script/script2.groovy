import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def lastModifiedDateTime = message.getProperty('LAST_MODIFIED_DATETIME')
    def userSetLastModifiedDateTime = message.getProperty('USER_SET_LAST_MODIFIED_DATETIME')
	
    if ((lastModifiedDateTime == null || lastModifiedDateTime.isEmpty())
        && (userSetLastModifiedDateTime == null ||  userSetLastModifiedDateTime.isEmpty() || "null".equalsIgnoreCase(userSetLastModifiedDateTime))) {
        throw new Exception('Please provide user set last modified datetime')
    }
    if (userSetLastModifiedDateTime != null && !userSetLastModifiedDateTime.isEmpty() && !"null".equalsIgnoreCase(userSetLastModifiedDateTime)) {
        lastModifiedDateTime = userSetLastModifiedDateTime
    } 
    
    def filterString = "empWfRequestNav/wfConfigNav/applicationScenario eq 'CrossSystemWorkflow' and lastModifiedDateTime gt '" + lastModifiedDateTime + "'"
    message.setProperty('WORKFLOW_REQUEST_FILTER', filterString)
    
    // set new lastModifiedDateTime for next job, Substract 10 seconds because of possible transaction commit overlap in EC
	LocalDateTime ldt = LocalDateTime.now().minusSeconds(10)
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
	def lastModifiedDateTimeNew = ldt.format(dtf)
    message.setProperty('LAST_MODIFIED_DATETIME_NEW', lastModifiedDateTimeNew) 
    
    def eventReasonIds = message.getProperty('EVENT_REASON_IDS');
    if (eventReasonIds != null && !eventReasonIds.trim().isEmpty()) {
        def eventReasonIdsArray = eventReasonIds.split(",");
        def eventReasonFilterString = "lastModifiedDateTime gt '" + lastModifiedDateTime + "' and eventReasonNav/externalCode in ";
        for (def i = 0; i < eventReasonIdsArray.length; i++) {
            def eventReasonId = eventReasonIdsArray[i].trim();
            eventReasonFilterString += "'" + eventReasonId + "'";
            if (i < eventReasonIdsArray.length - 1) {
                eventReasonFilterString += ",";
            }
        }
        message.setProperty('EVENT_REASONS_FILTER', eventReasonFilterString);
        
        def messageLog = messageLogFactory.getMessageLog(message);
        if (messageLog != null) {
    		messageLog.addAttachmentAsString('Event reason filter', eventReasonFilterString, 'text/plain');
    	}
    } else {
        message.setProperty('EVENT_REASONS_FILTER', '');
    }
 
   // TO DO log filter string, current and new lastModifiedDateTime
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
		messageLog.addAttachmentAsString('Workflow request filter', filterString, 'text/plain');
	}
   return message;
}