import com.sap.gateway.ip.core.customdev.util.Message;
 
def Message processData(Message message) {
 	def body = message.getBody(java.lang.String) as String;
 	message.setProperty('WORKFLOW_REQUESTS', body);
    return message;
}