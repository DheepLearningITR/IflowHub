import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message checkSalesText(Message message) {

  def body = message.getBody(java.io.Reader);
  def xml = new XmlParser().parse(body)
  def map = message.getProperties();
  def flag = map.get("P_SalesText");
  
  if (flag == "true"){
      
      xml.'**'.findAll { it.name() == 'SalesProcessInformation' }.each { salesProcessInfo ->
    // Check if SalesProcessInfoTextCollection is missing under each SalesProcessInformation
    if (!salesProcessInfo.'SalesProcessInfoTextCollection') {
        // Create and add the SalesProcessInfoTextCollection element if missing
        def salesProcessInfoTextCollection = new groovy.util.Node(salesProcessInfo, 'SalesProcessInfoTextCollection')
        salesProcessInfoTextCollection.attributes().put('actionCode', '04')
        salesProcessInfoTextCollection.attributes().put('textListCompleteTransmissionIndicator', 'true')
        }
     }
    // Output the modified XML string
    def modifiedXmlString = XmlUtil.serialize(xml)
    
    // set the modified XML back to the message body
    message.setBody(modifiedXmlString) 
  }
 
  return message;

}
