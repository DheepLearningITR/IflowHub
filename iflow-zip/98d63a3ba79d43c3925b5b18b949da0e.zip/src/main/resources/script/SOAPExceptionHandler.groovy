/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

 	// get a map of iflow properties
 	def map = message.getProperties();

 	// get an exception java class instance
 	def ex = map.get("CamelExceptionCaught");
 	
 	if (ex!=null) {

 		// an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
 		if (ex.getClass().getCanonicalName().equals("org.apache.cxf.binding.soap.SoapFault")) {

	 		// save the http error response as a message attachment
		 	def messageLog = messageLogFactory.getMessageLog(message);
			messageLog.addAttachmentAsString("soap.ResponseBody", ex.getResponseBody(), "text/plain");
			
		 	// copy the http error response to an iflow's property
			message.setProperty("soap.ResponseBody",ex.getResponseBody());
			
			// copy the http error response to the message body
			message.setBody(ex.getResponseBody());
			
		 	// copy the value of http error code (i.e. 500) to a property
			message.setProperty("soap.StatusCode",ex.getStatusCode());
			
		 	// copy the value of http error text (i.e. "Internal Server Error") to a property
			message.setProperty("soap.StatusText",ex.getStatusText());
 		}
 	}
 	
 	return message;
}


