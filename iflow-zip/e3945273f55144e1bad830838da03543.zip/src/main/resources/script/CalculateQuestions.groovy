import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.*;
import groovy.xml.*;
import groovy.json.*

def Message processData(Message message) {
    
    def body  = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def noOfQuestions = 0;
    
    if(body != null && !("").equalsIgnoreCase(body))
    {
        def questionList = jsonSlurper.parseText(body);
        noOfQuestions = questionList.size();
        
        def messageLog = messageLogFactory.getMessageLog(message);
//        def newQAList = jsonSlurper.parseText('{"QandA": ""}');
//        newQAList.QandA = questionList;
        def newQAList = jsonSlurper.parseText('{"QandA": { "QandAList": ""}}');
        newQAList.QandA.QandAList = questionList;
        
        message.setBody(JsonOutput.toJson(newQAList));
//        message.setBody(JsonOutput.toJson(questionList));
    }
    
    message.setProperty("noOfQuestions", noOfQuestions )
    
    return message;
}