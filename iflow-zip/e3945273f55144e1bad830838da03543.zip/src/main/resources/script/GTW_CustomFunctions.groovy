import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*


def Message getAttributesToProperty(Message message) {
    // Get MessageBody
    def body = message.getBody(String.class)   
    def sessionResponse = new JsonSlurper().parseText(body)
    def sessionKey = sessionResponse.sessionKey[0]
    def webinarID = sessionResponse.webinarID[0]

    message.setProperty("sessionKey",sessionKey)
    message.setProperty("webinarID",webinarID)
    
    return message
}

def Message TEST(Message message) {
   
   def map = message.getProperties();   
   def body = message.getBody()
   def jsonSlurper = new JsonSlurper();
   def sessionResponse = jsonSlurper.parseText(body);
   def sessionKey = sessionResponse.sessionKey;
   
   message.setProperty("totalAttendees",size);
   
   def messageLog = messageLogFactory.getMessageLog(message);
   def newAttendeeList = jsonSlurper.parseText('{"attendees": ""}')
   newAttendeeList.attendees = attendeeList
   message.setBody(JsonOutput.toJson(newAttendeeList))

   return message;
}
