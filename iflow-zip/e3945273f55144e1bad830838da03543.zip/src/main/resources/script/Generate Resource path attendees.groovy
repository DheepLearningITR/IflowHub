import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
import java.text.DateFormat;  
import java.text.SimpleDateFormat; 

def Message processData(Message message) {

    def json_body  = message.getBody();
    def jsonSlurper = new JsonSlurper();
    def attendeeSession = jsonSlurper.parseText(json_body);    
    def sessionID = 0;
    def webinarID = 0;
   
    def messageLog = messageLogFactory.getMessageLog(message);
    
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    Date minStartTime, minEndTime, currentStartTime, currentEndTime;
    if(null != attendeeSession && attendeeSession.size() > 0) {
        attendeeSession.each{
            
            minStartTime = dateFormat.parse(it.startTime)
            minEndTime = dateFormat.parse(it.endTime)
            
            if((null == currentStartTime || null == currentEndTime)) {
                currentStartTime = dateFormat.parse(it.startTime);
                currentEndTime = dateFormat.parse(it.endTime);
                sessionID = it.sessionKey;
                webinarID = it.webinarID;
            }
            else if(currentStartTime.before(minStartTime) && currentEndTime.before(minEndTime)) {
                currentStartTime = minStartTime;
                currentEndTime = minEndTime;
                sessionID = it.sessionKey;
                webinarID = it.webinarID;
            }
        }
        def map = message.getHeaders();
        def id = map.get("externaleventid");
        def resourcePath = "/meetings/" + id + "/sessions/" + sessionID + "/attendees";
        message.setProperty("sessionKey",sessionID);
        message.setProperty("webinarID",webinarID);
        messageLog.setStringProperty("Logging#1", "Session with minimum start time: " + sessionID);
        message.setProperty("resourcePath", resourcePath);      
        message.setProperty("noSessions","false");
        messageLog.setStringProperty("Logging#2", "Resource Path: " + resourcePath);
    }
    else {
        messageLog.setStringProperty("Logging#1", "No Sessions found");
        message.setProperty("noSessions","true");
    }

    return message;
}