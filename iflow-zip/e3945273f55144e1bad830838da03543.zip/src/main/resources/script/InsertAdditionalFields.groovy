import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.*;
import groovy.xml.*;
import groovy.json.*
def Message processData(Message message) {
    //Body
    def xmlBody  = message.getBody(java.lang.String) as String;

    //Properties 
    def map = message.getProperties();
    def totalAttendee = map.get("totalAttendee");    
    
    // Get Event ID
    def mapHeader = message.getHeaders();
    def eventid = mapHeader.get("externaleventid");    
    
    // Append Total attendees and eventId to the body
    def root = new XmlParser().parseText(xmlBody);
    root.appendNode("totalattendees", [:], totalAttendee);
    root.appendNode("eventid", [:], eventid);
    def xml = XmlUtil.serialize(root);
    message.setBody(xml);
    
    return message;
}