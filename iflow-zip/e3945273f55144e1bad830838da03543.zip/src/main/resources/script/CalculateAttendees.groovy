import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
def Message processData(Message message) {
   
   def map = message.getProperties();   
   def body = message.getBody()
   def jsonSlurper = new JsonSlurper();
   def attendeeList = jsonSlurper.parseText(body);
   def size = attendeeList.size();
   
   message.setProperty("totalAttendees",size);
   
   def messageLog = messageLogFactory.getMessageLog(message);
   def newAttendeeList = jsonSlurper.parseText('{"attendees": ""}')
   newAttendeeList.attendees = attendeeList
   message.setBody(JsonOutput.toJson(newAttendeeList))

   return message;
}