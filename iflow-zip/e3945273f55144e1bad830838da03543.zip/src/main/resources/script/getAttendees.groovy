import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonBuilder;
def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
     //convert the body to a json object
     def jsonObject = jsonSlurper.parseText(body.toString());
     //get the attendees from  json object
    def root = jsonObject.root;
    if(root != null)
    {
        def totalAttendees = jsonObject.root.totalattendees;
        def attendees= jsonObject.root.attendees;
        def jsonOP;
        //if there are no attendees then send empty array
        if(totalAttendees == "0")
        {
            jsonOP = [];
        }
        else
        {
            jsonOP = JsonOutput.toJson(attendees);
            
        }
        message.setBody(jsonOP);
    }
    body = message.getBody();
    return message;
}