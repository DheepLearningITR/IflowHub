import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil
    
def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
    def map = message.getProperties();
    String attendeePayload = map.get("attendeePayload");
    
    def xmlValue = new XmlParser().parseText(attendeePayload);
    
    noOfQuestions = map.get("noOfQuestions");
    noOfPollsAnswered = map.get("noOfPollsAnswered");
    noOfSurveys = map.get("noOfSurveys")
    responses = message.getBody(java.lang.String) as String;
    
    String[] ResponseCluster = responses.split("(?<=</QandA>)|(?<=</Polls>)")

    QandAs = ResponseCluster[0].replaceAll("<QandA>","");
    QandAs = QandAs.replaceAll("</QandA>","");
    QandAs = QandAs.replaceAll("<QandA/>","");

    Polls = ResponseCluster[1].replaceAll("<Polls>","");
    Polls = Polls.replaceAll("</Polls>","");
    Polls = Polls.replaceAll("<Polls/>","");

    Surveys = ResponseCluster[2].replaceAll("<Surveys>","");
    Surveys = Surveys.replaceAll("</Surveys>","");
    Surveys = Surveys.replaceAll("<Surveys/>","");

    responses = responses.replace(">[][]",">");
    
    xmlValue.appendNode("numberofquestions", [:], noOfQuestions)
    xmlValue.appendNode("numberofpollsanswered", [:], noOfPollsAnswered);
    xmlValue.appendNode("numberofsurveysanswered", [:], noOfSurveys);

    xmlValue.appendNode("questionsandanswers", [:], QandAs);
    xmlValue.appendNode("Polls", [:], Polls);
    xmlValue.appendNode("Surveys", [:], Surveys);

    def xml = XmlUtil.serialize(xmlValue);
    xml = xml.replaceAll("&lt;", "<").trim();
    xml = xml.replaceAll("&gt;", ">").trim();
    xml = xml.trim();
    message.setBody(xml);
    return message;
}
