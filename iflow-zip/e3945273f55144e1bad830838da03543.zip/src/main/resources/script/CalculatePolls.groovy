import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.*;
import groovy.xml.*;
import groovy.json.*
def Message processData(Message message) {
    
    def body  = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def noOfPollsAnswered = 0;
    if(body != null && !("").equalsIgnoreCase(body))
    {
        def pollList = jsonSlurper.parseText(body);
        noOfPollsAnswered = pollList.size();

        def newPollList = jsonSlurper.parseText('{"Polls": { "PollList": ""}}');
        newPollList.Polls.PollList = pollList;
        
        message.setBody(JsonOutput.toJson(newPollList));
    }

    def resourcePath = message.getProperty("resourcePath")
    def eventexternalID = (resourcePath =~ /(\d+)/)[0][1]

    message.setProperty("eventexternalID", eventexternalID)

    message.setProperty("noOfPollsAnswered", noOfPollsAnswered)
    return message;
}

