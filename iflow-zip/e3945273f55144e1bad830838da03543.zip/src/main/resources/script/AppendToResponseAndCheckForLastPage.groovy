import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {
    
  def body = message.getBody()
  map = message.getProperties();

  //Check if Last Page
  if(body == null || body.equalsIgnoreCase(""))
    message.setProperty("isLastPage", "true");
  JsonSlurper jsonSlurper = new JsonSlurper()
  def pageAttendeeList = jsonSlurper.parseText(body)
  if(pageAttendeeList == [])
    message.setProperty("isLastPage", "true");

  //Append the Current result to totalAttendeeList
  def attendeeBody = map.get("totalAttendeeList");
  def attendeeList = [];
  if(attendeeBody == null || ("").equalsIgnoreCase(attendeeBody)) {
    attendeeList = pageAttendeeList.clone();
  }
  else {
    attendeeList = jsonSlurper.parseText(attendeeBody)
    attendeeList.addAll(pageAttendeeList)
  }
  message.setProperty("totalAttendeeList", JsonOutput.toJson(attendeeList))

  message.setBody(body);
  return message;
  
}