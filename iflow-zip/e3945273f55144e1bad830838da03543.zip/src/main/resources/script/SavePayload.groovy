import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
def Message processData(Message message) {

    def xml_body  = message.getBody(java.lang.String) as String;
    message.setProperty("xmlBody", xml_body);
        
    return message;
}