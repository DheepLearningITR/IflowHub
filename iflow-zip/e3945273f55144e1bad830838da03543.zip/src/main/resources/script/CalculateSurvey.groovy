import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.*;
import groovy.xml.*;
import groovy.json.*
def Message processData(Message message) {
    //Body 
    
    def body  = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    
    def noOfSurveys = 0;
    if(body != null && !("").equalsIgnoreCase(body))
    {    
        def surveyList = jsonSlurper.parseText(body);
        surveyList.each {
            if(it.answer != null && !"".equalsIgnoreCase(it.answer)) 
            noOfSurveys++
            if(it.answers != null && it.answers.size > 0)
            noOfSurveys++        }
        
        def newSurveyList = jsonSlurper.parseText('{"Surveys": { "SurveyList": ""}}');
        newSurveyList.Surveys.SurveyList = surveyList;
        
        message.setBody(JsonOutput.toJson(newSurveyList));
        
    }
    
    message.setProperty("noOfSurveys", noOfSurveys)
    return message;
}