import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    // Generate the resource path to read the sessions for the input meeting
       def map = message.getHeaders();
       def id = map.get("externaleventid");
       def resourcePath = "/meetings/" + id + "/sessions";
       message.setProperty("resourcePath", resourcePath);
       
       return message;
}