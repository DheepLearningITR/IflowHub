import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.*;
import groovy.xml.*;

def Message processData(Message message) {
    def map = message.getProperties();
    
    def body = message.getBody(java.lang.String) as String;
    
    def attendeePayload = new XmlParser().parseText(body);
    
    def resourcePath = map.get("resourcePath");
    def attendeeParmsEndpoint = map.get("attendeeParmsEndpoint");
   
    def resourcePathForAttendeeParms = resourcePath + "/" + attendeePayload.registrantKey.text() + "/" + attendeeParmsEndpoint;
    message.setProperty("resourcePathForAttendeeParms", resourcePathForAttendeeParms);
        
    return message;
}