import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def body = message.getBody(java.lang.String) as String

    if (messageLog != null) {
        def doc = new XmlSlurper(false, false).parseText(body)

        def wd = new groovy.xml.Namespace("urn:com.workday/bsvc", "wd")
        def requisitionIds = []

        // Navigate using dot notation and namespace
        doc.wd.'Response_Data'.wd.'Job_Requisition'.each { jobReq ->
            jobReq.wd.'Job_Requisition_Reference'.wd.'ID'.each { idNode ->
                if (idNode.@'wd:type' == 'Job_Requisition_ID') {
                    requisitionIds << idNode.text()
                    messageLog.addCustomHeaderProperty("FoundID", idNode.text())
                }
            }
        }

        if (!requisitionIds.isEmpty()) {
            message.setHeader("JobRequisitionIDs", requisitionIds.join("\n"))
        } else {
            messageLog.addCustomHeaderProperty("Debug", "No Job_Requisition_ID found")
        }
    }

    return message
}