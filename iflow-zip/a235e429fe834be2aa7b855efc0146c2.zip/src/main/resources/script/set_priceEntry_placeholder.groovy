import groovy.xml.StreamingMarkupBuilder;
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
def Message processData(Message message) {
    
    
   def omsOrder_xml = message.getBody(java.lang.String) as String;

   def root = new XmlSlurper(false, true).parseText(omsOrder_xml);

   root.SalesOrder.Item.each(
   {it -> it.Material.replaceNode { node ->
   mkp.yield(node)
   priceEntry(it.'**'.find { it.name() == 'Material'}.parent().ExternalItemID.text())
 }})

   def outxml = groovy.xml.XmlUtil.serialize( root )
	
	message.setBody(outxml);
	return message;
}