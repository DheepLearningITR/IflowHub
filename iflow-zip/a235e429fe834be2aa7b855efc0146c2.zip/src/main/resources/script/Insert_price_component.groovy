import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import javax.xml.xpath.*
import javax.xml.parsers.DocumentBuilderFactory

def Message processData(Message message) {
    
  def omsOrder_xml = message.getBody(java.lang.String) as String;
  def tag = "Price_"

  def root = new XmlSlurper(false, true).parseText(omsOrder_xml);

  root.SalesOrder.Item.each(
  {
      it -> it.appendNode(new XmlSlurper().parseText('''<Prices>''' + message.getProperty(tag + it.priceEntry.text()) + '''</Prices>''' ))
  }
    )

  def outxml = groovy.xml.XmlUtil.serialize( root );
	
	message.setBody(outxml);
	return message;
    
}    
