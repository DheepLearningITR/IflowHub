import groovy.xml.StreamingMarkupBuilder;
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
def Message processData(Message message) {
    
    
   def omsOrder_xml = message.getBody(java.lang.String) as String;
   def priceEentryNum = message.getProperty("PriceEntryNum") as int;

   def root = new XmlSlurper(false, true).parseText(omsOrder_xml);

   root.SalesOrder.Item.PricingElement.each(
   {it -> it.ConditionQuantity.replaceNode { node ->
   mkp.yield(node)
   PriceEntryIndicator(priceEentryNum + 1)
 }})

   def outxml = groovy.xml.XmlUtil.serialize( root )
	
	message.setBody(outxml);
	// remove property payload
	message.setProperty("OMS_ORDER_PAYLOAD", "");
	return message;
}