import com.sap.gateway.ip.core.customdev.util.Message;
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.xml.sax.InputSource
import java.text.NumberFormat
import javax.xml.xpath.XPath
import javax.xml.xpath.XPathConstants
import javax.xml.xpath.XPathFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.Transformer
import javax.xml.transform.TransformerFactory
import javax.xml.transform.OutputKeys
import javax.activation.DataHandler;
import groovy.json.JsonSlurper;
import groovy.xml.XmlUtil;
import groovy.util.XmlSlurper
import src.main.resources.script.CPILogger;


def Message checkVersionRequirement(Message message) {
	def properties = message.getProperties()
	NumberFormat format = NumberFormat.getInstance(Locale.US)
	def number = format.parse(properties.get("VERSION_REQUIREMENT"))
	def version_requirement = number.doubleValue()
	if (version_requirement == 0){
		throw new IllegalStateException("Implement latest SAP Notes as described in SAP Note 3211436.")
	} else if (version_requirement > 1.0){
		throw new IllegalStateException("SCPI content for communication with SPOT needs to be updated to newer version.")
	}
	return message;
}

def Message rewrapEnvelope(Message message) {
	def properties = message.getProperties()
	def xpath = XPathFactory.newInstance().newXPath()
	def modTransformer = {
		it.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes")
	}
	Document originalEnvelope = parseXml(properties.get("ORIGINAL_BODY"))
	Document strippedRequest = message.getBody(Document.class)
	Element request = (Element)xpath.evaluate("/*[local-name()='getEBol']/*[local-name()='ebolReq']", strippedRequest, XPathConstants.NODE)
	String text = ""
	if (request != null) {
		text = request.getTextContent()
	}
	Element originalVlog = (Element)xpath.evaluate("/*[local-name()='getEBol']", originalEnvelope, XPathConstants.NODE)
	originalVlog.removeChild(originalVlog.getFirstChild())
	originalVlog.setTextContent(text)
	message.setBody(printSingleLineXml(originalEnvelope, byte[].class))
	return message
}

def Message clearWhitespaceInResponse(Message message) {
	def body = message.getBody(String.class);
	body = body.replaceAll("\\s","");
	body = body.replaceAll("[\n\r]","");
	message.setBody(body);
	return message;
}

def parseXml(def source){
	def builder = DocumentBuilderFactory.newInstance().newDocumentBuilder()
	Document document
	switch(source.class) {
		case byte[].class:
			document = builder.parse(new ByteArrayInputStream(source))
			break
		case String.class:
		default:
			document = builder.parse(new InputSource(new StringReader(source)))
			break
	}
	//removeWhitspace(document)
	return document
}

def printSingleLineXml(Document document, Class returnType = String.class, Closure modTransformer = null){
	Transformer transformer = TransformerFactory.newInstance().newTransformer()
	transformer.setOutputProperty(OutputKeys.INDENT, "no")
	if(modTransformer!=null){
		modTransformer.call(transformer)
	}
	switch(returnType) {
		case byte[].class:
			ByteArrayOutputStream bos = new ByteArrayOutputStream()
			transformer.transform(new DOMSource(document), new StreamResult(bos))
			return bos.toByteArray()
			break
		case String.class:
		default:
			StringWriter writer = new StringWriter()
			transformer.transform(new DOMSource(document), new StreamResult(writer))
			return writer.getBuffer().toString()
			break
	}
}

def Message storeHttpHeaderDetails(Message message) {
	def props = message.getProperties();
	def headers = message.getHeaders();
	def prefix = headers.containsKey("MAIN") ? "LAST" : ( headers.containsKey("AUTH") ? "MAIN" : "AUTH" );
	headers.put(prefix,"${props.get(prefix+'_ORIGIN')}|${headers.get('CamelHttpResponseCode')}|${headers.get('CamelHttpResponseText')}");
	props.put(prefix+"_RESPONSE_CODE",headers.get("CamelHttpResponseCode"));
	props.put(prefix+"_CONTENT_TYPE",headers.get("Content-Type"));
	return message;
}

def Message cleanupHeaders(Message message) {
	def headers = message.getHeaders();
	def remove = [];
	for (header in headers) {
		switch(header.key) {
			case "AUTH":
			case "MAIN":
			case "LAST":
			case "CamelHttpResponseCode":
			case "Location":
			case "Content-Type":
				break;
			default:
				remove << header.key;
		}
	}
	remove.each {
		headers.remove(it);
	}
	return message;
}

def Message handleHttpException(Message message) {
	def props = message.getProperties();
	def exc = props.get("CamelExceptionCaught");
	if (exc!=null) {
		if (exc.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
			def body = exc.getResponseBody();
			message.setBody(body);
			try {
				new JsonSlurper().parseText(body);
				message.setHeader("Content-Type", "application/json");
			} catch (ignored1) {
				try {
					Utils.parseXml(props.get(body));
					message.setHeader("Content-Type", "application/xml");
				} catch (ignored2) {
				}
			}
		}
	}
	return message;
}

def Message propagateSoapFault(Message message) {
	try {
		def map = message.getProperties()
		def ex = map.get("CamelExceptionCaught")
		if (ex!=null) {
			String stringEnvelope = '''<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Header/>'''
			stringEnvelope += '''<soap:Body><soap:Fault><faultcode/><faultstring/><detail/></soap:Fault></soap:Body></soap:Envelope>'''
			def xmlEnvelope = new XmlSlurper().parseText(stringEnvelope)
			xmlEnvelope.Body.Fault.faultstring = ex.getMessage()
			if (ex instanceof org.apache.cxf.interceptor.Fault) {
				String stringDetail = ex.getDetail() as String
				xmlEnvelope.Body.Fault.faultcode = ex.getFaultCode().toString()
				if (stringDetail!=null) {
					def xmlDetail = new XmlSlurper().parseText(stringDetail)
					xmlDetail.'*'.each{ node -> xmlEnvelope.Body.Fault.detail.appendNode(node) }
				}
				message.setBody(XmlUtil.serialize(xmlEnvelope))
			} else {
				if (ex.getCause()!=null) {
					xmlEnvelope.Body.Fault.faultcode = ex.getCause().getClass().getCanonicalName()
				} else {
					xmlEnvelope.Body.Fault.faultcode = ex.getClass().getCanonicalName()
				}
			}
			message.setBody(XmlUtil.serialize(xmlEnvelope))
		}
	} catch (Exception ex01) {
		String exBody = '''<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Header/>'''
			exBody += '<soap:Body><soap:Fault><faultcode>SCPI_GENERAL</faultcode><faultstring>'
			exBody += XmlUtil.escapeXml(ex01.getMessage())
	        StringWriter ex01Sw = new StringWriter();
            ex01.printStackTrace(new PrintWriter(ex01Sw));
			exBody += XmlUtil.escapeXml(ex01Sw.toString())
			exBody += '</faultstring></soap:Fault></soap:Body></soap:Envelope>'
			message.setBody(exBody)
	}
	return message
}

def Message log_res_out(Message message) {
	def log_suffix = 'res_out';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_req_in(Message message) {
	def log_suffix = 'req_in';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_exc(Message message) {
	def log_suffix = 'exc';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}
