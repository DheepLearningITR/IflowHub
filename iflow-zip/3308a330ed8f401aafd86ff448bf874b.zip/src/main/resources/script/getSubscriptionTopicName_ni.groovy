import com.sap.it.api.mapping.*;

//Add MappingContext parameter to read or set headers and properties
def String getSubscriptionTopicName(String propertyName,MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    String subscriptionTopicName = context.getProperty("subscriptionTopicName"+propertyValue);
    context.setProperty(propertyName, ++propertyValue);
    return subscriptionTopicName;
}
