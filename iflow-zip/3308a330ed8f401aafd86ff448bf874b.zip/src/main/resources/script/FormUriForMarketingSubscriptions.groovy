import com.sap.it.api.mapping.*;

//This method forms the Contact Origin Data URI
def String formUriMarketingSubscriptions(String contactId, String contactOrigin, String contactSubscriptionID, String contactSubscriptionOrigin, String communicationMedium, String subscriptionTopic){
	return "MarketingSubscriptions(ContactID='"+contactId+"',ContactOrigin='"+contactOrigin+"',ContactSubscriptionID='"+contactSubscriptionID+"',ContactSubscriptionOrigin='"+contactSubscriptionOrigin+"',CommunicationMedium='"+communicationMedium+"',SubscriptionTopic='"+subscriptionTopic+"')";
}