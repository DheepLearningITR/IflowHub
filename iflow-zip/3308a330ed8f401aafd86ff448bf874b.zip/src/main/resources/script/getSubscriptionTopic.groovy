import com.sap.it.api.mapping.*;

def String getSubscriptionTopic(String propertyName, MappingContext context){
String subscriptionTopic = propertyName;
switch(subscriptionTopic)
{
    case "brand1DailyNewsletter":
        subscriptionTopic = "21";
        break;
    case "brand2DailyNewsletter":
        subscriptionTopic = "22";
        break;
    default:
        subscriptionTopic = "21";
        break;
}
    return subscriptionTopic; 
}