import com.sap.it.api.mapping.*;

def String getPermissionOrigin(String propertyName, MappingContext context){
String permissionOrigin = propertyName;
switch(permissionOrigin)
{
    case "Email":
        permissionOrigin = "EMAIL";
        break;
    case "EMAIL":
        permissionOrigin = "EMAIL";
        break;
    case "Sms":
        permissionOrigin = "MOBILE";
        break;
    case "SMS":
        permissionOrigin = "MOBILE";
        break;
    default:
        permissionOrigin = "EMAIL";
        break;
}
    return permissionOrigin; 
}