import com.sap.it.api.mapping.*;

//This method forms the Contact Origin Data URI
def String marketingArea(String contactId, String contactOrigin, String marketingArea){
	return "MarketingAreas(ContactID='"+contactId+"',ContactOrigin='"+contactOrigin+"',InteractionContactMktgArea='"+marketingArea+"')";
}