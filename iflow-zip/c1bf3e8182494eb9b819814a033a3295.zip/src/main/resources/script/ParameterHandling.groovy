import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.SimpleDateFormat;

def Message processData(Message message) {
    def headers = message.getHeaders();
    def properties = message.getProperties();
    String SourceTimeProfilefromAddon = headers.get("SourceTimeProfilefromAddon") ?:''
    String SourceTimeProfileLevelfromAddon = headers.get("SourceTimeProfileLevelfromAddon") ?:''
    String FilterForTheDataSource = headers.get("FilterForTheDataSource") ?:''
    String DestinationforAddon = headers.get("DestinationforAddon") ?:''
    String DestinationforSAPIBP = headers.get("DestinationforSAPIBP") ?:''
    String ReadPackageSizeinMb = headers.get("ReadPackageSizeinMb") ?:''
    String BatchName = headers.get("BatchName") ?:''
    String BatchCommand = headers.get("BatchCommand") ?:''
    String PlanningArea = headers.get("PlanningArea") ?:''
    String DateFrom = headers.get("DateFrom") ?:''
    String DateTo = headers.get("DateTo") ?:''


    def messageLog = messageLogFactory.getMessageLog(message);
    
    
 //parameter validations
    if(!DestinationforAddon){
        throw new Exception("The 'Destination for Add-on' parameter can not be empty.")
    }
    if(!DestinationforSAPIBP){
        throw new Exception("The 'Destination for SAP IBP' parameter can not be empty.")
    }
    if(!BatchName){
        throw new Exception("The 'Batch Name' parameter can not be empty.")
    }
    
    //Calculating package size
    if(ReadPackageSizeinMb != ''){
        try {
            ReadPackageSizeinMb.toInteger()
        }catch (Exception e){
            throw new Exception("The 'Read Package Size in Mb' parameter must be an integer.")
        }
        
        if(ReadPackageSizeinMb.toInteger() > 0) {
          def packageSize = ReadPackageSizeinMb.toInteger() * 1048576
          
          message.setHeader('MaxPackageSize', packageSize)
          
        }
        else{
           throw new Exception("The 'Read Package Size in Mb' parameter must be greater than zero.") 
        }
    }
    
    if(BatchCommand != 'INSERT_UPDATE' && BatchCommand != 'REPLACE' && BatchCommand != 'DELETE' ){
        throw new Exception("The 'Batch Command' parameter can have the following values: INSERT_UPDATE,REPLACE,DELETE.")
    }
 
    if(!PlanningArea){
        throw new Exception("The 'Planning Area' parameter can not be empty.")
    }
 
    

    def filters = [];

    //Add time profile filters to the filters List
    if(SourceTimeProfilefromAddon != ''){
        try {
            SourceTimeProfilefromAddon.toInteger()
        }catch (Exception e){
            throw new Exception("The 'Source Time Profile from Add-on' parameter must be an integer.")
        }

        filters.add("TIMEPROFILEID EQ '" + SourceTimeProfilefromAddon + "'")
    }
    else{
        throw new Exception("The 'Source Time Profile from Add-on' parameter can not be empty.")
    }

    if(SourceTimeProfileLevelfromAddon != ''){
        try {
            SourceTimeProfileLevelfromAddon.toInteger()
        }catch (Exception e){
            throw new Exception("Source Time Profile Level from Add-on must be an integer")
        }
        filters.add("TIMEPROFILELEVEL EQ '" + SourceTimeProfileLevelfromAddon + "'")
    }
    else{
        throw new Exception("The 'Source Time Profile Level from Add-on' parameter can not be empty.")
    }
    
    //if timestamps are added we are filtering for key figure date
    if(DateFrom != '' && DateTo != ''){
        
        SimpleDateFormat oldDateFormat = new SimpleDateFormat("yyyy-MM-dd")
        SimpleDateFormat newDateFormat = new SimpleDateFormat("yyyyMMdd")
        
        String newDateFrom = ''
        String newDateTo = ''
        
        //process DateFrom
        if (DateFrom.isNumber() && DateFrom.length() == 8) {
            // DateFrom is in constant format ('yyyyMMdd')
            newDateFrom = DateFrom
        } 
        else {
            Date dateFrom = oldDateFormat.parse(DateFrom)
            newDateFrom = newDateFormat.format(dateFrom)
        }

        // process DateTo
        if (DateTo.isNumber() && DateTo.length() == 8) {
            // DateTo is in constant format ('yyyyMMdd')
            newDateTo = DateTo
        }
        else {
            Date dateTo = oldDateFormat.parse(DateTo)
            newDateTo = newDateFormat.format(dateTo)
        }
        
        //add the timestamps to the filters
        filters.add("KEYFIGUREDATE BT '" + newDateFrom + "' '" + newDateTo + "'")
    }       
        

    //Create the OData filter for MRPType
    createFilter((headers.get("MRPTypeFilters")?:'') as String, "MRPTYPE", filters)

    //Include the further filters
    if(FilterForTheDataSource != ''){
        filters.add(FilterForTheDataSource);
    }

    message.setHeader("FilterForTheDataSource", filters.join(','))
    return message;
}

def createFilter(String commaSeparatedSimpleFilters, String Field, List<String> filterList){
    def pattern = '(?<=(?:^|-))(([^-\"]*?)|(\"(?:[^\"]+|\"\")*\"))(?=(?:-|$))';
    def odataFilters = [];
    def simpleFilters = commaSeparatedSimpleFilters.tokenize(',')

    for (simpleFilter in simpleFilters) {
        def simpleFilterMatches = simpleFilter.findAll(pattern);
        odataFilters += (simpleFilterMatches.size() <= 1) ? "${Field} EQ '${simpleFilterMatches[0].replaceAll('^\"|\"$','')}'" : "${Field} GE '${simpleFilterMatches[0].replaceAll('^\"|\"$','')}' , ${Field} LE '${simpleFilterMatches[1].replaceAll('^\"|\"$','')}'";
    }

    if (odataFilters.size() > 0 ) {
        filterList.add(odataFilters.join(','));
    }
}