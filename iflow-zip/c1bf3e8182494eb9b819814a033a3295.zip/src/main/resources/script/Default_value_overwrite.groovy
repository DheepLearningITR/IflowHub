import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.LinkedHashMap;
def Message processData(Message message) {
    //Headers
    def headers = message.getHeaders();
    LinkedHashMap<String,Object> newHeaders = [:];
    Set<String> keys = headers.keySet();
        
    for (String key : keys) {
        if (key.startsWith('Default_')) {
            def newHeaderName = key.substring(key.indexOf('_') + 1);
            def newHeader = headers.get(newHeaderName);
            def defaultHeader = key.startsWith('Default_') ? null : headers.get('Default_' + newHeaderName);
            if ( (newHeader == '-keep default-' || newHeader == null ) 
               && ( defaultHeader == '-keep default-' || defaultHeader == null ) )
            {
                newHeaders.put(newHeaderName,headers.get(key));
            }
            newHeaders.put(key,null);
        }
    }
    
    Set headerSet = newHeaders.entrySet();
    Iterator it = headerSet.iterator();
    while (it.hasNext()) {
        def header = it.next();
        message.setHeader(header.key,header.value);
    }
    headers = message.getHeaders();
    headers.findAll{it.value instanceof String ? it.value.matches(/^-copy from .+-$/) : false}.each {
        def sourceHeader = it.value.substring(11,it.value.length()-1);
        message.setHeader(it.key,headers.get(sourceHeader));
    }

    return message;
}
