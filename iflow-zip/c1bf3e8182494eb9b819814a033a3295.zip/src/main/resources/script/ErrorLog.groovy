import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.msglog.MessageLog;

def Message processData(Message message) {
        // Get the messageLogFactory and the FetchMessages property
        def messageLog = messageLogFactory.getMessageLog(message);

        //Set custom headers
        //addCustomHeadersToLog(message, messageLog)

        //Log body to attachment
        logBodyToAttachment(message, messageLog)

    return message;
}


def logBodyToAttachment(Message message, MessageLog messageLog) {
    if (messageLog != null) {
        def body = message.getBody(String)
        if (body != null && body.trim()) {
            messageLog.addAttachmentAsString('ExceptionBody', body, 'text/plain')
        }
    }
}