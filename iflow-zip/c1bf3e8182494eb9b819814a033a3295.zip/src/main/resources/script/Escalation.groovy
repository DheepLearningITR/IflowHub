import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    def headers = message.getHeaders();

    def escalationMessage = headers.get("EscalationMessage");
    
    throw new Exception(escalationMessage);


    return message;
}
