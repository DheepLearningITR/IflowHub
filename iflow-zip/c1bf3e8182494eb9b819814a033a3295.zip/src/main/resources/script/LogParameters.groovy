import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	def headers = message.getHeaders();
	
	messageLog.addCustomHeaderProperty('Batch Name', headers.get("BatchName"));
	messageLog.addCustomHeaderProperty('Destination for SAP IBP', headers.get("DestinationforSAPIBP"));
	messageLog.addCustomHeaderProperty('Destination for SAP ERP or SAP S/4HANA or SAP S/4HANA Private Edition', headers.get("DestinationforAddon"));
	messageLog.addCustomHeaderProperty('Planning Area', headers.get("PlanningArea"));
	messageLog.addCustomHeaderProperty('Planning Area Version', headers.get("PlanningAreaVersion"));
	messageLog.addCustomHeaderProperty('Data Source', headers.get("DataSource"));
	messageLog.addCustomHeaderProperty('Parallel Data Transfer', headers.get("ParallelDataTransfer"));
	
	
   def attachment = "Filter for the Data Source: " + headers.get("FilterForTheDataSource")+
                     "\nCustom Mapping Extension Integration Flow Address: " + headers.get("CustomMappingExtensionIntegrationFlowAddress")+
                     "\nPost Fetch Filter Extension Address: " + headers.get("PostFetchFilterExtensionAddress")+
                     "\nTarget Fields in SAP IBP: " + headers.get("TargetFieldsInSAPIBP")+
                     "\nSource Fields from SAP ERP or SAP S/4HANA or SAP S/4HANA Private Edition: " + headers.get("SourceFieldsfromAddon")+
                     "\nField Mapping: " + headers.get("FieldMapping")+
                     "\nMax Package Size: " + headers.get("MaxPackageSize")+
                     "\nSource Time Profile ID in SAP ERP or SAP S/4HANA or SAP S/4HANA Private Edition: " + headers.get("SourceTimeProfilefromAddon")+
                     "\nTarget Time Profile Level in SAP IBP: " + headers.get("TargetTimeProfileLevelinSAPIBP")+
                     "\nSource Time Profile Level in SAP ERP or SAP S/4HANA or SAP S/4HANA Private Edition: " + headers.get("SourceTimeProfileLevelfromAddon")+
                     "\nProcess Unchanged Data " + headers.get("ProcessUnchangedData");
                     
        messageLog.addAttachmentAsString("Parameters" , attachment.toString(), "text/xml");
	return message;
}