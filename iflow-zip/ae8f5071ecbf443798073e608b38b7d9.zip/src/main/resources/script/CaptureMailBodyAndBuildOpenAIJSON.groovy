import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder

def Message processData(Message message) {
    
    String p_model = message.getProperty("P_Model")
    String p_user = message.getProperty("P_User")
    def body = message.getBody(java.lang.String)

    def mailText = body.replaceAll('\n', ' ').replaceAll('\\s+', ' ')

    def builder = new JsonBuilder()

    builder {
        model p_model
        messages ([[
            role: p_user,
            content: "Convert following text into a JSON with properties 'PO' for purchase order value, and 'NAME' for signer's name: ${mailText}."
        ]])
    }

    def originalMail = message.getProperty("SAP_MAIL_ORIGINAL_MESSAGE")
    if (originalMail) {
        def fromPattern = /From:[^<]*<([^>]+)>/
        def matcher = (originalMail =~ fromPattern)
        if (matcher.find()) {
            def fromEmailAddress = matcher.group(1).trim()
            message.setProperty("P_ToEmailAddress", fromEmailAddress)
        }
    }

    message.setBody(builder.toPrettyString())

    return message
}