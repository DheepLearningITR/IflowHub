import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.ITApiFactory
import groovy.util.XmlParser

def Message processData(Message message) {
    // Getting Body
    def inputXml = new XmlParser().parseText(message.getBody(java.lang.String))

    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    
    def builder = new StringBuilder()
    
    def quantityOfSalesOrder = inputXml.A_SalesOrderType.size()
    
    def orderText = quantityOfSalesOrder == 1 ? "registry" : "registries"
    builder.append("We have found $quantityOfSalesOrder $orderText for your order. ")
    
    // Iterate through each A_SalesOrderType element
    inputXml.A_SalesOrderType.each { salesOrderType ->
        def overallDeliveryStatus = salesOrderType.OverallDeliveryStatus.text()
        def salesOrder = salesOrderType.SalesOrder.text()
        def description = valueMapApi.getMappedValue("S4Hana", "Status", overallDeliveryStatus, "OpenAI", "Description")
        
        // Create a new text line
        def textLine = "Status of SalesOrder $salesOrder is $description"
        builder.append(textLine).append('. ')  // Append the text and add a new line
    }

    message.setBody(builder.toString())

    return message
}
