import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential
import com.sap.it.api.securestore.exception.SecureStoreException

def Message processData(Message message) 
{
    //Get Properties
    String accountKeyAlias = message.getProperty("P_KeyAlias")
    String accept = message.getProperty("P_Accept")
    String contentType = message.getProperty("P_ContentType")
    
    //Get Account Key from Secure Parameter
    def accountKey = "Bearer " + getAccountKey(accountKeyAlias)
    
    //Set Headers
    message.setHeader("Authorization", accountKey)
    message.setHeader("Accept", accept)
    message.setHeader("Content-Type", contentType)

    return message
}

String getAccountKey(String accountKeyAlias)
{
   def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)
    try
    {
        def secureParameter = secureStorageService.getUserCredential(accountKeyAlias)
        return secureParameter.getPassword().toString()
    } 
    catch(Exception e)
    {
        throw new SecureStoreException("Secure Parameter not available")
    }
}