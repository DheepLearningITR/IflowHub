import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.MarkupBuilder;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
 
def Message getInstallationPointID(Message message) {
  //Get message and parse to json
  def json = message.getBody(java.io.Reader)
  def data = new JsonSlurper().parse(json)

  message.setProperty("P_SourcePayload", JsonOutput.toJson(data))

  //messageHeader
  message.setHeader("SAP_ApplicationID", data.messageHeader.id)

  //get fields of the payload 
  message.setProperty("P_MessageID", data.messageHeader.id)
  message.setProperty("P_SenderParty", data.messageHeader.senderCommunicationSystemDisplayId)
  message.setProperty("P_ReceiverParty", data.messageHeader.receiverCommunicationSystemDisplayId)

  if (data.messageRequests[0].body.receiverParentRegisteredProductDisplayId || data.messageRequests[0].body.receiverParentFunctionalLocationDisplayId) {
    message.setProperty("P_InstallationRequired", 'true')

  } else {
    message.setProperty("P_InstallationRequired", 'false')
  }
  message.setProperty("P_EquipmentId", data.messageRequests[0].body.id)
  message.setProperty("P_EquipmentNum", data.messageRequests[0].body.displayId)
  message.setProperty("P_LongText", data.messageRequests[0].body.customerInformation ? data.messageRequests[0].body.customerInformation.content : '')
  message.setProperty("P_Warranty", data.messageRequests[0].body.warranty ? data.messageRequests[0].body.warranty.receiverDisplayId : '')

  message.setProperty("P_S4_EquipmentNum", data.messageRequests[0].body.receiverDisplayId ? data.messageRequests[0].body.receiverDisplayId : '')
  message.setProperty("P_C4CParentEquipment", data.messageRequests[0].body.receiverParentRegisteredProductDisplayId ? data.messageRequests[0].body.receiverParentRegisteredProductDisplayId.toString() : '')
  message.setProperty("P_C4CFunctionalLocation", data.messageRequests[0].body.receiverParentFunctionalLocationDisplayId ? data.messageRequests[0].body.receiverParentFunctionalLocationDisplayId.toString() : '')
  //ids for confirmation message
  message.setProperty("P_messageHeaderId", java.util.UUID.randomUUID())
  message.setProperty("P_messageRequestHeaderId", java.util.UUID.randomUUID())
  return message
}

def Message retrieveSourcePayload(Message message) {
  //Body
  def body = message.getBody(java.io.Reader)
  def root = new XmlSlurper().parse(body)

  message.setProperty("P_FunctionalLocation", root.EquipmentType.FunctionalLocation ? root.EquipmentType.FunctionalLocation.toString() : '')
  message.setProperty("P_SuperordinateEquipment", root.EquipmentType.SuperordinateEquipment ? root.EquipmentType.SuperordinateEquipment.toString() : '')
  if (root.EquipmentType.FunctionalLocation.toString() || root.EquipmentType.SuperordinateEquipment.toString())
    message.setProperty("P_InstallationRequired", 'true')
  //Properties
  def properties = message.getProperties()
  def value = properties.get("P_SourcePayload")
  message.setBody(value.toString())
  return message
}


def Message setReceiverEquipmentNo(Message message) {

  def json = message.getBody(java.io.Reader);
  def dataStoreEntry = new JsonSlurper().parse(json);
  message.setProperty("P_S4_EquipmentNum", dataStoreEntry.ReceiverInstallationPointID)
  return message
}

/**
 * Creates Equipment long text batch payload
 * Format : PATCH EquipmentLongText(Equipment='10006844') HTTP/1.1
 * 
 */

def Message processTextCollection(Message message) {

  def body = message.getBody(java.io.Reader)
  def content = new XmlSlurper().parse(body)

  def textContent = content.Text.ContentText.toString()

  def map = message.getProperties()
  def equipmentNo = map.get("P_S4_EquipmentNum")

  def xmlWriter = new StringWriter()
  def xmlMarkup = new MarkupBuilder(xmlWriter)

  xmlMarkup.batchParts {
    batchChangeSet {
      if (textContent.size() > 0) batchChangeSetPart {
        method('PATCH')
        uri("EquipmentLongText(Equipment='" + equipmentNo + "')")
        EquipmentLongText {
          EquipmentLongTextType {
            EquipmentLongText(textContent)
          }
        }
      }
    }
  }

  String result = xmlWriter.toString()
  message.setBody(result)
  return message

}


def Message processPartnerFunction(Message message) {

  def body = message.getBody(java.io.Reader)
  def s4Party = new XmlSlurper().parse(body)

  def map = message.getProperties()
  def equipmentNo = map.get("P_S4_EquipmentNum")
  //def c4cParty = new XmlSlurper().parseText(map.get("P_C4C_InvolvedParties"))
  def c4cParty = new XmlSlurper().parse(map.get("P_C4C_InvolvedParties"))

  def patchlist = []
  def postlist = []

  for (party in c4cParty.Party) {

    def partnerRole = party.PartnerFunction.toString()
    def partnerNo = party.Partner.toString()
    def existingParty = false

    for (sparty in s4Party.EquipmentType.to_Partner.EquipmentPartnerType) {

      def s4PartnerRole = sparty.PartnerFunction.toString()
      def s4PartnerNo = sparty.Partner.toString()

      if (s4PartnerRole.equals(partnerRole) && s4PartnerNo.equals(partnerNo)) existingParty = true

      if (s4PartnerRole.equals(partnerRole) && !s4PartnerNo.equals(partnerNo)) {
        patchlist.add(party.PartnerFunction + sparty.EquipmentPartnerObjectNmbr + party.Partner)
        existingParty = true
      }
    }

    if (!existingParty) postlist.add(party.PartnerFunction + party.Partner)
  }

  def xmlWriter = new StringWriter()
  def xmlMarkup = new MarkupBuilder(xmlWriter)
  xmlMarkup.batchParts {
    batchChangeSet {
      for (e in patchlist) {
        batchChangeSetPart {
          method('PATCH')
          uri("EquipmentPartner(Equipment='" + equipmentNo + "',PartnerFunction='" + e[0] + "',EquipmentPartnerObjectNmbr='" + e[1] + "')")
          EquipmentPartner {
            EquipmentPartnerType {
              Partner(e[2])
            }
          }
        }

      }
      for (e in postlist) {
        batchChangeSetPart {
          method('POST')
          uri('EquipmentPartner')
          EquipmentPartner {
            EquipmentPartnerType {
              Equipment(equipmentNo)
              PartnerFunction(e[0])
              Partner(e[1])
            }
          }
        }
      }
    }
  }
  String result = xmlWriter.toString()
  message.setBody(result)
  return message
}

/**
 * Equipment Hierarchy Processing 
 * If C4C ReceiverUpperInstallationPointID exists and S/4 SuperordinateEquipment is initial - Do an Installation
 * If S/4 SuperordinateEquipment exists and C4C ReceiverUpperInstallationPointID is initial - Do a Dismantle
 * If both exists and the values are not equal, first Dismantle (existing SuperordinateEquipment) and then install (C4C ReceiverUpperInstallationPointID)
 */
 
def Message processHierachyRelationship(Message message) {

  def map = message.getProperties()
  def c4c_parentequipment = map.get("P_C4CParentEquipment")
  def s4_parentequipment = map.get("P_SuperordinateEquipment")
  def s4_equipmentNo = map.get("P_S4_EquipmentNum")
  def c4c_functionalLocation = map.get("P_C4CFunctionalLocation");
  def s4_functionalLocation = map.get("P_FunctionalLocation")
  def etag = map.get("P_batch_etag")

  def equipInstallationPositionNmbr = "&EquipInstallationPositionNmbr='" + "0000" + "'"

  def xmlWriter = new StringWriter()
  def xmlMarkup = new MarkupBuilder(xmlWriter)

  message.setProperty("c4c_parentequipment.size", c4c_parentequipment.size())
  message.setProperty("s4_parentequipment.size", s4_parentequipment.size())
  message.setProperty("c4c_functionalLocation.size", c4c_functionalLocation.size())
  message.setProperty("s4_functionalLocation.size", s4_functionalLocation.size())

  xmlMarkup.batchParts {
    if (c4c_parentequipment.size() > 0) {
      //update
      if (!c4c_parentequipment.equalsIgnoreCase(s4_parentequipment) &&
        (s4_parentequipment.size() > 0)) {
        batchChangeSet {
          batchChangeSetPart {
            method('POST')
            uri("DismantleEquipment?Equipment='" + s4_equipmentNo + "'&ValidityEndDate=datetime%279999-12-31T00%3A00%3A00%27")
            headers {
              header {
                headerName("If-Match")
                headerValue(etag)
              }
            }
          }
        }

        batchChangeSet {
          batchChangeSetPart {
            method('POST')
            uri("InstallEquipment?Equipment='" +
              s4_equipmentNo +
              "'&ValidityEndDate=datetime%279999-12-31T00%3A00%3A00%27&SuperordinateEquipment='" +
              c4c_parentequipment +
              "'" +
              equipInstallationPositionNmbr)
            headers {
              header {
                headerName("If-Match")
                headerValue("*")
              }
            }
          }
        }
      } //create
      else if (s4_parentequipment.size() == 0) {
        batchChangeSet {
          batchChangeSetPart {
            method('POST')
            uri("InstallEquipment?Equipment='" +
              s4_equipmentNo +
              "'&ValidityEndDate=datetime%279999-12-31T00%3A00%3A00%27&SuperordinateEquipment='" +
              c4c_parentequipment +
              "'" +
              equipInstallationPositionNmbr)
            headers {
              header {
                headerName("If-Match")
                headerValue(etag)
              }
            }
          }
        }

      }
    } //delete
    else if (c4c_parentequipment.size() == 0 && s4_parentequipment.size() > 0) {
      batchChangeSet {
        batchChangeSetPart {
          method('POST')
          uri("DismantleEquipment?Equipment='" + s4_equipmentNo + "'&ValidityEndDate=datetime%279999-12-31T00%3A00%3A00%27")
          headers {
            header {
              headerName("If-Match")
              headerValue(etag)
            }
          }
        }
      }
    }
    //done

    if (c4c_functionalLocation.size() > 0) {
      //update
      if (!c4c_functionalLocation.equalsIgnoreCase(s4_functionalLocation) &&
        (s4_functionalLocation.size() > 0)) {
        batchChangeSet {
          batchChangeSetPart {
            method('POST')
            uri("DismantleEquipment?Equipment='" + s4_equipmentNo + "'&ValidityEndDate=datetime%279999-12-31T00%3A00%3A00%27")
            headers {
              header {
                headerName("If-Match")
                headerValue(etag)
              }
            }
          }
        }

        batchChangeSet {
          batchChangeSetPart {
            method('POST')
            uri("InstallEquipment?Equipment='" +
              s4_equipmentNo +
              "'&ValidityEndDate=datetime%279999-12-31T00%3A00%3A00%27&FunctionalLocation='" +
              c4c_functionalLocation +
              "'" +
              equipInstallationPositionNmbr)
            headers {
              header {
                headerName("If-Match")
                headerValue("*")
              }
            }
          }
        }
      } //create
      else if (s4_functionalLocation.size() == 0) {
        batchChangeSet {
          batchChangeSetPart {
            method('POST')
            uri("InstallEquipment?Equipment='" +
              s4_equipmentNo +
              "'&ValidityEndDate=datetime%279999-12-31T00%3A00%3A00%27&FunctionalLocation='" +
              c4c_functionalLocation +
              "'" +
              equipInstallationPositionNmbr)
            headers {
              header {
                headerName("If-Match")
                headerValue(etag)
              }
            }
          }
        }

      }
    } else if (c4c_functionalLocation.size() == 0 && s4_functionalLocation.size() > 0) {
      batchChangeSet {
        batchChangeSetPart {
          method('POST')
          uri("DismantleEquipment?Equipment='" + s4_equipmentNo + "'&ValidityEndDate=datetime%279999-12-31T00%3A00%3A00%27")
          headers {
            header {
              headerName("If-Match")
              headerValue(etag)
            }
          }
        }
      }
    }
  }
  String result = xmlWriter.toString()
  message.setBody(result)
  return message

}

/**
 * Parse the ODATA batch response to extract the message
 * Note the batch response is XML inside XML
 * batchPartResponse is the outer XML root node and body is the inner XML root node
 * Message text is available inside the error/message/text of inner XML
 */

def Message throwBatchProcessingException(Message message) {

  def body = message.getBody(java.io.Reader)
  def errorBody = null

  try {
    def batchPartResponse = new XmlSlurper().parse(body)
    errorBody = new XmlSlurper().parseText(batchPartResponse.batchChangeSetResponse.batchChangeSetPartResponse.body.text())
  } catch (Exception exception) {
    throw new Exception('Batch Processing Exception' + exception)
  }

  if (errorBody != null) throw new Exception(errorBody.message.text())

  return message
}

/**
 * For ODATA post error get the error message text from the ODATA response body and populate it in MPL
 * For Other exceptions return as is
 */

def Message throwODATACreateException(Message message) {

  def body = message.getBody(java.io.Reader)
  def map = message.getProperties();
  def ex = map.get("CamelExceptionCaught")
  def errorBody = null

  if (ex != null) {

    if (ex.getClass().getCanonicalName().equals("com.sap.gateway.core.ip.component.odata.exception.OsciException")) {

      try {
        errorBody = new XmlSlurper().parse(body)
      } catch (Exception exception) {
        throw new Exception(exception)
      }

      if (errorBody.message != null) throw new Exception(errorBody.message.text())
    } else throw new Exception(ex)
  }

  return message
}


//Set Custom Monitoring Header
def Message setCustomConfirmationMessageHeader(Message message) {

  def messageLog = messageLogFactory.getMessageLog(message);
  if (messageLog != null) {

    def messageHeaderId = message.getProperties().get("P_messageHeaderId")
    if (messageHeaderId != null) {
      messageLog.addCustomHeaderProperty("Confirmation Message ID", messageHeaderId.toString())
    }
  }
  return message;
}
