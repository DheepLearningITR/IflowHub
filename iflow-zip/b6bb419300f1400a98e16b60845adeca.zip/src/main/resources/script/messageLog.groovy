import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData_getBillTransferList(Message message) {
	def map = message.getProperties();
	def property_EnableErrorLogOnly = map.get("EnableErrorLogOnly");
	def property_EnableAllLog = map.get("EnableAllLog");
	if (property_EnableAllLog.toUpperCase().equals("TRUE") && (!property_EnableErrorLogOnly.toUpperCase().equals("TRUE"))  ) {
		def body = message.getBody(java.lang.String) as String;
		def messageLog = messageLogFactory.getMessageLog(message);

		if (messageLog != null) {
			messageLog.addAttachmentAsString(" SB_get_transfer_bills_response", body, "text/json");
		}
	}
	return message;
}

def Message processData_RC_bill(Message message) {
	def map = message.getProperties();
	def property_EnableErrorLogOnly = map.get("EnableErrorLogOnly");
	def property_EnableAllLog = map.get("EnableAllLog");
	if (property_EnableAllLog.toUpperCase().equals("TRUE") && (!property_EnableErrorLogOnly.toUpperCase().equals("TRUE"))  ) {
		def body = message.getBody(java.lang.String) as String;
		def billId = map.get("BillDocNumber");
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Bill(" + billId + ")_in_RC", body, "text/xml");
		}
	}
	return message;
}

def Message processData_S4_Inbound(Message message) {
	def map = message.getProperties();
	def property_EnableErrorLogOnly = map.get("EnableErrorLogOnly");
	def property_EnableAllLog = map.get("EnableAllLog");
	if (property_EnableAllLog.toUpperCase().equals("TRUE") && (!property_EnableErrorLogOnly.toUpperCase().equals("TRUE"))  ) {
		def body = message.getBody(java.lang.String) as String;
		def billId = map.get("BillDocNumber");
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
				messageLog.addAttachmentAsString("Bill(" + billId + ")_to_S4_msg", body, "text/xml");
		}
	}
	return message;
}

def Message processData_returnMsg(Message message) {
	def map = message.getProperties();
	def property_EnableErrorLogOnly = map.get("EnableErrorLogOnly");
	def property_EnableAllLog = map.get("EnableAllLog");
	if (property_EnableAllLog.toUpperCase().equals("TRUE") && (!property_EnableErrorLogOnly.toUpperCase().equals("TRUE"))  ) {
		def body = message.getBody(java.lang.String) as String;
		def billId = map.get("BillDocNumber");
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
				messageLog.addAttachmentAsString("Bill(" + billId + ")_return_msg", body, "text/xml");
		}
	}
	return message;
}

def Message processData_updateStatus(Message message) {
	def map = message.getProperties();
	def property_EnableErrorLogOnly = map.get("EnableErrorLogOnly");
	def property_EnableAllLog = map.get("EnableAllLog");
	if (property_EnableAllLog.toUpperCase().equals("TRUE") && (!property_EnableErrorLogOnly.toUpperCase().equals("TRUE"))  ) {
		def body = message.getBody(java.lang.String) as String;
		def billId = map.get("BillDocNumber");
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
				messageLog.addAttachmentAsString("Bill(" + billId + ")_status_update", body, "text/json");
		}
	}
	return message;
}