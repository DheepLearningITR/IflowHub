/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

 * 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
importClass(com.sap.it.api.exception.ITApiRuntimeException);

function processData(message) {    
    //body
    var body = message.getBody(new java.lang.String().getClass());
    var singleBill = JSON.parse(body);
    var billType = singleBill.Root.Response.billingType;
    var billItems = singleBill.Root.Response.billItems;
    
    for (var item in billItems) {
        if (billType == "CREDIT") {
        	billItems[item].comboChargesCredits = billItems[item].credits;
        }
        else {
        	singleBill.Root.Response.billingType = "CHARGE";
        	billItems[item].comboChargesCredits = billItems[item].charges;
        }
    }
    
    body = JSON.stringify(singleBill);
    message.setBody(body);
    return message;
}