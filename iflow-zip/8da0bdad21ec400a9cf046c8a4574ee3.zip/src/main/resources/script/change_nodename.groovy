import com.sap.gateway.ip.core.customdev.util.Message


def Message processData(Message message) {

	def body = message.getBody(String.class)

	def root_name = 'ns0:Messages'
	def new_root_name = '_-SCWM_-MFG_REVERSE_HUS_EXT'
	body = body.replaceAll("<$root_name>", "<$new_root_name>")
	body = body.replaceAll("<$root_name ", "<$new_root_name ")
	body = body.replaceAll("</$root_name>", "</$new_root_name>")

	def ns0 = ' xmlns:ns0="http://sap.com/xi/XI/SplitAndMerge"'
	def new_ns0 = ''
	body = body.replaceAll("$ns0", "$new_ns0")
	
	def rfcns = ' xmlns:rfc="urn:sap-com:document:sap:rfc:functions"'
	def new_rfcns = ''
	body = body.replaceAll("$rfcns", "$new_rfcns")
	
	def ns = ' xmlns="http://sap.com/xi/ME/erpcon"'
	def new_ns = ''
	body = body.replaceAll("$ns", "$new_ns")

	def rfc = 'rfc:'
	def new_rfc = ''
	body = body.replaceAll("<$rfc", "<$new_rfc")
	body = body.replaceAll("</$rfc", "</$new_rfc")

	def message1 = 'ns0:Message1'
	def new_message1 = ''
	body = body.replaceAll("<$message1>", "$new_message1")
	body = body.replaceAll("</$message1>", "$new_message1")

	def message2 = 'ns0:Message2'
	def new_message2 = ''
	body = body.replaceAll("<$message2>", "$new_message2")
	body = body.replaceAll("</$message2>", "$new_message2")
	
	def message3 = 'ns0:Message3'
	def new_message3 = ''
	body = body.replaceAll("<$message3>", "$new_message3")
	body = body.replaceAll("</$message3>", "$new_message3")

	message.setBody(body)

	return message
}

