import com.sap.gateway.ip.core.customdev.util.Message;

Message processData(Message message) {

	def body = message.getBody(java.io.Reader);
	def root = new XmlSlurper().parse(body);
	
	// EWM Part
	def ewmErrItem = root.ET_BAPIRET.item.findAll { it -> it.TYPE.text().matches("[EAX]")};
	
	if (ewmErrItem.size() > 0){
		def errText = "\r\n-----EWM BAPI errors begin-----\r\n";
		errText += ewmErrItem.MESSAGE.join(";\r\n");
		errText += "\r\n-----EWM BAPI errors end-----\r\n";

		throw new Exception(errText);
	}
    
	return message;
}