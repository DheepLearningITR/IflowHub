import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.transform.CompileStatic
import groovy.transform.Field

@Field public static final String ACKNOWLEDGE_MESSAGE_STATUS_SUCCESS = 'SUCCESS'
@Field public static final String ACKNOWLEDGE_MESSAGE_STATUS_PARTIAL_SUCCESS = 'PARTIAL_SUCCESS'
@Field public static final String ACKNOWLEDGE_MESSAGE_RESPONSE_SEVERITY_SUCCESS = 'SUCCESS'

def Message processData(Message message) {

    def body = message.getBody(java.io.Reader)
    def acknowledgeMessageJson = new JsonSlurper().parse(body)
    def data = acknowledgeMessageJson.data
    def messageStatus = data.messageStatus
    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addCustomHeaderProperty("messageStatus", messageStatus)
    messageLog.addCustomHeaderProperty("xsapcorrelationid", acknowledgeMessageJson.xsapcorrelationid)
    messageLog.addCustomHeaderProperty("messageId", acknowledgeMessageJson.id)

    message.setProperty('messageStatus', messageStatus)
    def currentModelId
    def grcProcessMap = [:]
    if (messageStatus.equals(ACKNOWLEDGE_MESSAGE_STATUS_SUCCESS) || messageStatus.equals(ACKNOWLEDGE_MESSAGE_STATUS_PARTIAL_SUCCESS)) {
        for (def response : data.messageResponse) {
            if (response.severity.equals(ACKNOWLEDGE_MESSAGE_RESPONSE_SEVERITY_SUCCESS)) {
                ProcessInfo processInfo = new ProcessInfo()
                processInfo.id = response.id
                processInfo.index = response.index
                processInfo.displayId = response.displayId
                processInfo.externalId = response.externalId
                processInfo.url = response.url
                String[] ids = response.externalId.split('/')

                if (!currentModelId) {
                    currentModelId = ids[0]
                } else if (!currentModelId.equals(ids[0])) {
                    throw new Exception("Multiple model ids found in the response")
                }

                grcProcessMap.put(ids[ids.size() - 1], processInfo)
            }
        }

        if (!currentModelId) {
            throw new Exception("No Signavio model id found in the response")
        }
        messageLog.addCustomHeaderProperty("signavioModelId", currentModelId)
        message.setProperty('currentModelId', currentModelId)
        message.setProperty('grcProcessMap', grcProcessMap)
    }

    if (!messageStatus.equals(ACKNOWLEDGE_MESSAGE_STATUS_SUCCESS)) {
        messageLog.addAttachmentAsString("Message Body", JsonOutput.prettyPrint(JsonOutput.toJson(acknowledgeMessageJson)), "text/plain")
    }
    
    return message
}

@CompileStatic
class ProcessInfo {
    String id
    String index
    String displayId
    String externalId
    String url
    String severity
    String responseCode

    List<String> parameter

    ProcessInfo() {}
}

