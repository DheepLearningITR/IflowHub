import com.google.gson.Gson
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.Field

@Field public static final String SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_ID = 'meta-ramprocesstechnicalid'
@Field public static final String SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_DISPLAY_ID = 'meta-ramprocessid'
@Field public static final String SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_URL = 'meta-ramprocessurl'
@Field public static final String SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_URL_LABEL = 'RAM Process'
@Field public static final String GRC_PROCESS_URL_PREFIX_FORMAT = '%s/cp.portal/site#MsdRepositories-display?sap-ui-app-id-hint=com.sap.grc.dpg.msd.repository.manage&/Processes/'
@Field public static final String URL_ENCODING_CHARSET = 'UTF-8'


def Message processData(Message message) {
    def currentModelId = message.getProperty('currentModelId')
    def grcProcessMap = message.getProperty('grcProcessMap')
    def grcProcessUrlPrefix = String.format(GRC_PROCESS_URL_PREFIX_FORMAT, message.getProperty("ramHost"))
    def body = message.getBody(java.io.Reader)

    def jsonModel = new JsonSlurper().parse(body)
    message.setProperty('isCallSignavioNeed', 'false')

    if (grcProcessMap.containsKey(currentModelId)) {
        def grcProcess = grcProcessMap.get(currentModelId)
        def originProcessId = jsonModel.properties.get(SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_ID)
        def originProcessDisplayId = jsonModel.properties.get(SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_DISPLAY_ID)
        Boolean isProcessIdSame = grcProcess.id.equals(originProcessId)
        Boolean isProcessDisplayIdSame = grcProcess.displayId.equals(originProcessDisplayId)
        if (!(originProcessId && originProcessDisplayId && isProcessIdSame && isProcessDisplayIdSame)) {
            jsonModel.properties.put(SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_ID, grcProcess.id)
            jsonModel.properties.put(SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_DISPLAY_ID, grcProcess.displayId)
            jsonModel.properties.put(SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_URL, assembleGRCProcessUrl(grcProcessUrlPrefix, grcProcess.id, false))
            message.setProperty('isCallSignavioNeed', 'true')
        }
    }

    updateChildActivity(message, jsonModel, grcProcessMap, grcProcessUrlPrefix)

    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addCustomHeaderProperty("isCallSignavioNeed", message.getProperty('isCallSignavioNeed'))

    message.setProperty('jsonXML', new Gson().toJson(jsonModel))

    return message
}

def static List<Map> assembleGRCProcessUrl(grcProcessUrlPrefix, grcProcessId, needEncode) {
    def formattedUrl = []
    def url = needEncode ? URLEncoder.encode(grcProcessUrlPrefix + grcProcessId, URL_ENCODING_CHARSET) : grcProcessUrlPrefix + grcProcessId
    def urlMap = ['url': url, 'label': SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_URL_LABEL]
    formattedUrl.add(urlMap)
    return formattedUrl
}

def void updateChildActivity(message, childModel, grcProcessMap, grcProcessUrlPrefix) {
    def properties = childModel.properties
    def originProcessId = properties.get(SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_ID)
    def originProcessDisplayId = properties.get(SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_DISPLAY_ID)
    if (properties.tasktype && grcProcessMap.containsKey(childModel.resourceId)) {
        def grcProcess = grcProcessMap.get(childModel.resourceId)
        Boolean isProcessIdSame = grcProcess.id.equals(originProcessId)
        Boolean isProcessDisplayIdSame = grcProcess.displayId.equals(originProcessDisplayId)
        if (!(originProcessId && originProcessDisplayId && isProcessIdSame && isProcessDisplayIdSame)) {
            properties.put(SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_ID, grcProcess.id)
            properties.put(SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_DISPLAY_ID, grcProcess.displayId)
            properties.put(SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_URL, assembleGRCProcessUrl(grcProcessUrlPrefix, grcProcess.id, true))
            message.setProperty('isCallSignavioNeed', 'true')
        }

    } else {
        // We found we need to encode the url again if the url had been encoded before
        def grcProcessUrl = properties.get(SIGNAVIO_CUSTOM_ATTRIBUTE_PROCESS_URL)
        if (grcProcessUrl && grcProcessUrl[0]) {
            def existedProcessUrl = grcProcessUrl[0].url
            grcProcessUrl[0].url = URLEncoder.encode(existedProcessUrl, URL_ENCODING_CHARSET)
        }

    }

    for (child in childModel.childShapes) {
        updateChildActivity(message, child, grcProcessMap, grcProcessUrlPrefix)
    }
}
