import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.Field


@Field public static final String SIGNAVIO_MODEL_UPDATE_BODY_FORMAT = 'parent=%s&name=%s&description=%s&comment=Update custome attributes by GRC Process&json_xml=%s'

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def jsonModel = new JsonSlurper().parse(body)
    def jsonXML = message.getProperty('jsonXML')

    def signavioUpdateBody = String.format(SIGNAVIO_MODEL_UPDATE_BODY_FORMAT, jsonModel.parent, jsonModel.name, jsonModel.description, jsonXML)
    message.setBody(signavioUpdateBody)
    
    return message
}
