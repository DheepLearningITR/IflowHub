import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper


def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message)
    def body = message.getBody(java.io.Reader);
    def model = new JsonSlurper().parse(body)
    if (!model instanceof ArrayList && model.errors) {
        messageLog.addCustomHeaderProperty("IsWriteToSignavioError", "true")
        messageLog.addCustomHeaderProperty("WriteToSignavioErrorMessage", model.message)
    }else{
         messageLog.addCustomHeaderProperty("IsWriteToSignavioError", "false")
    }

    return message;
}