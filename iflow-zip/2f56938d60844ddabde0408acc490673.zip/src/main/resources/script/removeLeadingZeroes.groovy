import com.sap.it.api.mapping.*;
import org.apache.commons.lang3.StringUtils;

def String removeLeadingZeros(String id){
    if (StringUtils.isNumeric(id)) {
        def stripped = StringUtils.stripStart(id, "0")
        return stripped.isEmpty() ? "0" : stripped
        
    }
    else {
    return id;
        
    }
}