import com.sap.gateway.ip.core.customdev.util.Message;


def Message setMonitoringIdentifiers(Message message) {
    message.setHeader("SAP_ApplicationID", message.getHeaders().get("SapMessageIdEx").toLowerCase())
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        def idocNo = message.getHeaders().get("SapIDocTransferId")
        if (idocNo != null) {
            messageLog.addCustomHeaderProperty("IDoc Number", idocNo)
        }
    }
    return message
}