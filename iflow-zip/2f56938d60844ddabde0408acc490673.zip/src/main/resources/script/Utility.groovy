import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message enrichJsonPayload(Message message) {
  //Body 
  def body = message.getBody(java.io.Reader)
  Map parsedJson = new JsonSlurper().parse(body)

  parsedJson.messageRequests.each { request ->
        def requestBody = request.body
        requestBody.priceElements.each { element ->
           processPriceElement(element)
        }
    }
    
  def respbody = JsonOutput.toJson(parsedJson)
  message.setBody(respbody)
  return message;
}

def Object processPriceElement(Object priceElement ){
    priceElement.isManuallyChanged = convertToBoolean(priceElement.isManuallyChanged)
	priceElement.isDeleteEnabled = convertToBoolean(priceElement.isDeleteEnabled)
	priceElement.isEffective = !convertToBoolean(priceElement.isEffective)
	priceElement.isGroupedIndicator = convertToBoolean(priceElement.isGroupedIndicator)
	priceElement.isRateDenominatorUpdateEnabled = convertToBoolean(priceElement.isRateDenominatorUpdateEnabled)
	priceElement.isRateNumeratorUpdateEnabled = convertToBoolean(priceElement.isRateNumeratorUpdateEnabled)
	priceElement.isViewAuthorizationSufficient = convertToBoolean(priceElement.isViewAuthorizationSufficient)
	priceElement.isEditAuthorizationSufficient = convertToBoolean(priceElement.isEditAuthorizationSufficient)
}

def Boolean convertToBoolean(String value){
    return value == 'X'
}
