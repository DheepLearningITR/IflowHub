import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def xmlString = message.getBody(java.io.Reader)
    def xml = new XmlSlurper().parse(xmlString)

    def definitionJson = [
            definition: [
                    name       : xml.name.text(),
                    namespace  : xml.namespace.text(),
                    key        : xml.key.text(),
                    description: xml.description.text(),
                    type       : xml.type.text(),
                    ownerType  : xml.ownerType.text(),
                    pin        : Boolean.parseBoolean(xml.pin.text())
            ]
    ];

    def jsonString = JsonOutput.toJson(definitionJson);

    message.setBody(jsonString);

    return message;
}