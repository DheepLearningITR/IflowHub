import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.msglog.MessageLog;

def Message processData(Message message) {
    try {
        // Get the messageLogFactory and the FetchMessages property
        def messageLog = messageLogFactory.getMessageLog(message);

        //Set custom headers
        addCustomHeadersToLog(message, messageLog)

        //Log body to attachment
        logBodyToAttachment(message, messageLog)
    }catch (Exception ignored){
        
    }

    if (message.getProperty("OriginalCamelExceptionCaught") == null || message.getProperty("OriginalCamelExceptionCaught") == "") {
        message.setProperty("OriginalCamelExceptionCaught", message.getProperty("CamelExceptionCaught"))
    }
    message.setProperty("OriginalCamelExceptionCaught", message.getProperty("CamelExceptionCaught"))

    message.setProperty("CamelExceptionCaught", null)
    return message;
}

def addCustomHeadersToLog(message, messageLog) {
    def customHeaders = [
            'BatchCommand',
            'BatchName',
            'DestinationforSAPIBP',
            'DestinationforAddon',
            'SourceFieldsfromAddon',
            'DataSource',
            'FieldMapping',
            'FilterForTheDataSource',
            'TargetFieldsInSAPIBP',
            'CustomMappingExtensionIntegrationFlowAddress',
            'MasterDataPrefix',
            'MasterDataType',
            'PlanningArea',
            'PlanningAreaVersion',
            'PostFetchFilterExtensionAddress',
            'ProcessUnchangedData',
            'TargetTimeProfileLevelinSAPIBP',
            'Stage'
    ]
    customHeaders.each { headerKey ->
        def headerValue = message.getHeader(headerKey, String)
        if (messageLog != null && headerValue != null) {
            messageLog.addCustomHeaderProperty(headerKey, headerValue)
        }
    }
}

def logBodyToAttachment(Message message, MessageLog messageLog) {
    if (messageLog != null) {
        def body = message.getBody(String)
        if (body != null && body.trim()) {
            messageLog.addAttachmentAsString('ExceptionBody', body, 'text/plain')
        }
    }
}