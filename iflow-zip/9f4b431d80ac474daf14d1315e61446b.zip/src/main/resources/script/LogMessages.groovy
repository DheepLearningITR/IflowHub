import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.msglog.MessageLog;
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    try {
        def properties = message.getProperties();

        // Get the OriginalCamelExceptionCaught property
        def originalException = properties.get("OriginalCamelExceptionCaught")

        // Set the CamelExceptionCaught property to the original exception
        if (originalException != null) {
            message.setProperty("CamelExceptionCaught", originalException)
        }

        // Log the messages

        def messageLog = messageLogFactory.getMessageLog(message);
        logMessages(message, messageLog)
    } catch (Exception e) {
        // TODO:Log the exception
    }

    // Prepare XML output
    try {
        message.setBody(createXMLbody(message))
    } catch (Exception e) {
        // TODO:Log the exception
        message.setBody("""<IBPAddOnGeneric xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" Status="Error">
            <Messages>
                <Message Origin="Add_On_Generic_Process_Stage_${message.getHeader("Stage",String)}" Type="Error">An error occurred during processing.</Message>
            </Messages>
        </IBPAddOnGeneric>""")
    }

    return message
}

def logMessages(Message message, MessageLog messageLog) {
    def properties = message.getProperties();
    String allMessages = ["InitMessages","FetchMessages", "CreateBatchesMessages", "PostDataMessages", "CloseMessages", "ProcessPostedDataMessages"].collect { properties.get(it) ?: '' }.join('');

    if (messageLog != null) {
        // Log and format the ERPReadFetchMessages attachment and Add the exception message to it if there is any
        try {
            def ex = properties.get("CamelExceptionCaught");
            String exMessage = "<Message Type=\"Error\" Origin=\"SAP_IBP_Add-On_Read_Generic_Process_Stage_${message.getHeader("Stage",String)}\">" + ex.getMessage() + "</Message>"
            messageLog.addAttachmentAsString('AllMessages', ("<Messages>" + exMessage + allMessages + "</Messages>").replaceAll(/<.xml.*?>/, "").replaceAll("[\\t\\n\\r]+",""), 'text/XML')


        } catch (Exception e) {
            if(allMessages != ""){
                messageLog.addAttachmentAsString('AllMessages', "<Messages>" + allMessages + "</Messages>", 'text/XML')
            }
        }

        // Set the AllMessages property
        message.setProperty("AllMessages", allMessages);
    }
}

def String createXMLbody(Message message) {
    def properties = message.getProperties();
    String allMessages = ["InitMessages","FetchMessages", "CreateBatchesMessages", "PostDataMessages", "CloseMessages", "ProcessPostedDataMessages"].collect { properties.get(it) ?: '' }.join('');

    def status = "Error" // Set status as needed
    def origin = "Add_On_Generic_Process_Stage_${message.getHeader("Stage",String)}"
    def type = "Error"
    def exceptionMessage = message.properties.get("CamelExceptionCaught")?.getMessage() ?: ""

    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.IBPAddOnGeneric('xmlns:xsi': "http://www.w3.org/2001/XMLSchema-instance", Status: status) {
        Messages {
            Message(Origin: origin, Type: type, exceptionMessage)
        }
    }
    return writer.toString()
}
