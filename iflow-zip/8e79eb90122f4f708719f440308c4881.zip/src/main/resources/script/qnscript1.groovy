import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.*;
import groovy.json.JsonBuilder;
import groovy.lang.*;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String);
       def jsonSlurper = new JsonSlurper()
       def object = jsonSlurper.parseText(body.toString());
       Double quantity=Double.parseDouble(object.quantity);
	   def bostatuses=object.businessObjectStatuses;
	   def list=[];
	   def payload;
       def qualityNotificationNumber=object.qualityNotificationNumber;
       def qnType=object.qnType;
       def unit_code=object.unit_code;
       def purchaseOrderNumber=object.purchaseOrderNumber;
       def purchaseOrderItem=object.purchaseOrderItem;
       def supplierCode=object.supplierCode;
       def personResponsibleCode=object.personResponsibleCode;
       def personResponsibleRole=object.personResponsibleRole;
       def materialCode=object.materialCode;
       def plantCode=object.plantCode;
       def purchaseOrganisationCode=object.purchaseOrganisationCode;
       def referenceNumber=object.referenceNumber;
       def defect=object.defect;
       def defectlist=[];
       def subjectCode_code=object.subjectCode_code;
	   def subjectCode_subjectCodeGroup_code=object.subjectCode_subjectCodeGroup_code;
	   def destination = object.destination;
	   def processDescription=object.processDescription;
	   def isAsynchronousRequest=object.isAsynchronousRequest;
       if(null!=isAsynchronousRequest){
           isAsynchronousRequest = isAsynchronousRequest.toLowerCase().toBoolean();
       }
		
	   def json = new JsonBuilder();
	   //If both Defects and BOStatuses are multiple
	   if (bostatuses instanceof ArrayList && defect instanceof ArrayList) {
		       payload= json qualityNotificationNumber:qualityNotificationNumber, qnType:qnType, quantity:quantity, unit_code:unit_code, purchaseOrderNumber:purchaseOrderNumber, purchaseOrderItem:purchaseOrderItem, supplierCode:supplierCode, destination:destination, personResponsibleCode:personResponsibleCode, personResponsibleRole:personResponsibleRole, materialCode:materialCode, //createdBy:createdBy,
		plantCode:plantCode, purchaseOrganisationCode:purchaseOrganisationCode, referenceNumber:referenceNumber, defect:defect, businessObjectStatuses:bostatuses,
		subjectCode_code:subjectCode_code,subjectCode_subjectCodeGroup_code:subjectCode_subjectCodeGroup_code,processDescription:processDescription,isAsynchronousRequest:isAsynchronousRequest
		
	   }else{
	       //If any of Defects and BOStatuses are multiple
	       	   if(bostatuses instanceof ArrayList || defect instanceof ArrayList){
	       	       //If only BOStatuses is multiple
	            if(bostatuses instanceof ArrayList){
	                defectlist.add(defect);
	                 payload= json qualityNotificationNumber:qualityNotificationNumber, qnType:qnType, quantity:quantity, unit_code:unit_code, purchaseOrderNumber:purchaseOrderNumber, purchaseOrderItem:purchaseOrderItem, supplierCode:supplierCode, destination:destination, personResponsibleCode:personResponsibleCode, personResponsibleRole:personResponsibleRole, materialCode:materialCode, //createdBy:createdBy,
		                 plantCode:plantCode, purchaseOrganisationCode:purchaseOrganisationCode, referenceNumber:referenceNumber, defect:defectlist, businessObjectStatuses:bostatuses,
		                 subjectCode_code:subjectCode_code,subjectCode_subjectCodeGroup_code:subjectCode_subjectCodeGroup_code,processDescription:processDescription,isAsynchronousRequest:isAsynchronousRequest
	            }else { 
	                //If only defects is multiple
	                        list.add(bostatuses);
                           payload= json qualityNotificationNumber:qualityNotificationNumber, qnType:qnType, quantity:quantity, unit_code:unit_code, purchaseOrderNumber:purchaseOrderNumber, purchaseOrderItem:purchaseOrderItem, supplierCode:supplierCode, destination:destination, personResponsibleCode:personResponsibleCode, personResponsibleRole:personResponsibleRole, materialCode:materialCode, //createdBy:createdBy,
		                       plantCode:plantCode, purchaseOrganisationCode:purchaseOrganisationCode, referenceNumber:referenceNumber, defect:defect, businessObjectStatuses:list,
		                       subjectCode_code:subjectCode_code,subjectCode_subjectCodeGroup_code:subjectCode_subjectCodeGroup_code,processDescription:processDescription,isAsynchronousRequest:isAsynchronousRequest
	            }
	
               }else{
                   //If both BOStatuses and defects have single entry
                   defectlist.add(defect);
                    list.add(bostatuses);
                    payload= json qualityNotificationNumber:qualityNotificationNumber, qnType:qnType, quantity:quantity, unit_code:unit_code, purchaseOrderNumber:purchaseOrderNumber, purchaseOrderItem:purchaseOrderItem, supplierCode:supplierCode, destination:destination, personResponsibleCode:personResponsibleCode, personResponsibleRole:personResponsibleRole, materialCode:materialCode, //createdBy:createdBy,
		                       plantCode:plantCode, purchaseOrganisationCode:purchaseOrganisationCode, referenceNumber:referenceNumber, defect:defectlist, businessObjectStatuses:list,
		                       subjectCode_code:subjectCode_code,subjectCode_subjectCodeGroup_code:subjectCode_subjectCodeGroup_code,processDescription:processDescription,isAsynchronousRequest:isAsynchronousRequest
               }
	      }
		
 
      message.setBody(groovy.json.JsonOutput.toJson(payload));
      message.setProperty("payload",groovy.json.JsonOutput.toJson(payload));
      return message;
}