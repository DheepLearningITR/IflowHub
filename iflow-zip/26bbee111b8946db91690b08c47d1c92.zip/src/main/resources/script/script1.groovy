import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){

		def id = message.getHeaders().get("pfx_ref_id");		
		if(id!=null){
			messageLog.addCustomHeaderProperty("pfx_ref_id", id);		
        }
	}
	return message;
}