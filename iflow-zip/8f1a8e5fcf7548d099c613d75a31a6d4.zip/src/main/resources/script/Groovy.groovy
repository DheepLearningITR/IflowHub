import java.util.HashMap;
import com.sap.gateway.ip.core.customdev.util.Message;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import groovy.json.JsonOutput;
import groovy.json.JsonSlurper;


def Message processData(Message message) {

    message.setHeader("X-User-ID", "12");
    message.setHeader("X-Tenant-ID", "0");
    message.setHeader("X-Tenant-Detail", false);
    message.setHeader("Content-Type", "application/json");
            
    return message;
}
