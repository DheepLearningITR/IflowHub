import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.MessageLog;

def Message processData(Message message) {

    def headers = message.getHeaders();
	MessageLog messageLog = messageLogFactory.getMessageLog(message);

    if(messageLog != null){
        Integer loop_counter = headers.get("LoopCounter") as Integer;

        messageLog.addAttachmentAsString(loop_counter + '. Package Payload', message.getBody(String), 'text/xml')
        
        loop_counter++;
        message.setHeader("LoopCounter",loop_counter);  
    }
	return message;
}