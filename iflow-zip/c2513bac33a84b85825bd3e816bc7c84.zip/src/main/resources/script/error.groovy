import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.Map.Entry;
import org.apache.camel.impl.DefaultAttachment
import javax.mail.util.ByteArrayDataSource

def Message processData(Message message) {

    def headers = message.getHeaders();
	def properties = message.getProperties();
	def messageLog = messageLogFactory.getMessageLog(message);
	def bodyAsString = message.getBody(java.lang.String);
	
	messageLog.addAttachmentAsString('Body before error', bodyAsString, 'text/xml')
    
    return message;
}

	