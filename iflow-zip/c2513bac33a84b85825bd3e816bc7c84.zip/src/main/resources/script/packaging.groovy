import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def headers = message.getHeaders();
	
	//get the required headers
	def loop_counter = headers.get("LoopCounter")
    def package1 = headers.get("Package1");
    def package2 = headers.get("Package2");
    
    //setting the data we want to write in the current package
    if(loop_counter == '1') {
      message.setHeader("DataToWrite",package1);  
    }
    else{
    message.setHeader("DataToWrite",package2);
    message.setHeader("IsLastPackage",'TRUE')
    }
    
    return message;
}

	