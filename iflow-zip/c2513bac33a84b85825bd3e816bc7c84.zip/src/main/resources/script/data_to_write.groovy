import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	
    def package1 =   '''<item>
<PRDID>PRDID_1</PRDID> 
<LOCID>LOCID_1</LOCID> 
<CUSTID>DUMMY</CUSTID> 
<KEYFIGUREDATE>2023-06-01</KEYFIGUREDATE> 
<ADJDELIVQTY>4</ADJDELIVQTY> 
</item>
<item>
<PRDID>PRDID_2</PRDID> 
<LOCID>LOCID_2</LOCID> 
<CUSTID>DUMMY</CUSTID> 
<KEYFIGUREDATE>2023-06-01</KEYFIGUREDATE> 
<ADJDELIVQTY>5</ADJDELIVQTY> 
</item>
'''
def package2 ='''<item>
<PRDID>PRDID_3</PRDID> 
<LOCID>LOCID_3</LOCID> 
<CUSTID>DUMMY</CUSTID> 
<KEYFIGUREDATE>2023-06-01</KEYFIGUREDATE> 
<ADJDELIVQTY>5</ADJDELIVQTY> 
</item>
<item>
<PRDID>PRDID_4</PRDID> 
<LOCID>LOCID_4</LOCID> 
<CUSTID>DUMMY</CUSTID> 
<KEYFIGUREDATE>2023-06-01</KEYFIGUREDATE> 
<ADJDELIVQTY>5</ADJDELIVQTY> 
</item>
'''
                            
    message.setHeader("Package1",package1); 
    message.setHeader("Package2",package2);
    
	return message;
}