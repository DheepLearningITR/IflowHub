import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
//import groovy.util.XmlParser
//import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script is to merge the custom FSM company with incoming PR*/    
    def body = message.getBody(String)
    def parsedXml = new XmlParser().parseText(body)
    def propmap = message.getProperties(); 

    def srcparsedXml = new XmlParser().parseText(propmap.get("customCompanyMessage"))

    parsedXml.'multimap:Message1'.SrvcMgmtFSMCompanyCstmLogic.SrvcMgmtFSMCompanyCstmLogic_Type.each { it ->
        def account = it.FSMAccount.text()
        def company = it.FSMCompany.text()

        srcparsedXml.'n0:ProductMDMBulkReplicateRequestMessage'.each { prRequest ->        
			if (prRequest.@MultiCompanyGroup == 'CUSTOM') {
				prRequest.ProductMDMReplicateRequestMessage.each { prMessage ->                    
					prMessage.Product.each { pr ->                    
                    def customCompany = new XmlParser().parseText("<FSMCustomCompany>${account}|${company}</FSMCustomCompany>")                    
						if (pr.ProductInternalID.text() == it.SrvcMgmtFSMRplctnObjID.text()) {
							pr.FSMMultiCompany[0].append(customCompany)                            
						}
					}
				}
			}
			if (prRequest.@MultiCompanyGroup == 'ATTRIBUTE') {                
				prRequest.ProductMDMReplicateRequestMessage.each { prMessage ->                
					prMessage.Product.each { pr ->                    
                        def customCompany = new XmlParser().parseText("<FSMCustomCompany>${account}|${company}</FSMCustomCompany>")
						if (pr.ProductInternalID.text() == it.SrvcMgmtFSMRplctnObjID.text() && pr.ProductTypeCode.text() == it.SrvcMgmtFSMRplctnObjAttribVal.text()) {                            
						    pr.FSMMultiCompany[0].append(customCompany)
						}
					}
				}
			}
		}
	}

    message.setBody(XmlUtil.serialize(srcparsedXml))
    return message
}

