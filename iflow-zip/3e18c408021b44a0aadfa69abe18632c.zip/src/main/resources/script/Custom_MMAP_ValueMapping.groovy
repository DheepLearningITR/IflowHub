import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;
import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;


def String dynamicValueMapping(String sourceAgency, String sourceIdentifier, String targetAgency, String targetIdentifier, String inputKey, String onFailureValue){
/*this script is to read the value mapping by passing custom source and target agency parameters in Message Mapping*/

    def service = ITApiFactory.getApi(ValueMappingApi.class, null)

    if(service != null && sourceAgency && sourceIdentifier && inputKey && targetAgency && targetIdentifier) {
        // Get mapped value
        def val = service.getMappedValue(sourceAgency, sourceIdentifier, inputKey, targetAgency, targetIdentifier)

        // Check for null or empty value
        if (val == null || val.equals("")) {
            if(onFailureValue == null || onFailureValue.equals("")){
                return inputKey
            }else if(onFailureValue == 'THROWERROR'){
                throw new Exception("Failed to find the Value Mapping result");
            }else{
                return onFailureValue   
            }
        } else {
            return val
        }
    }
    
    return null
}