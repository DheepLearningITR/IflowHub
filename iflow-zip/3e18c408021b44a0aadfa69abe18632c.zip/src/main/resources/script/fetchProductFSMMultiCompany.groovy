import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.asdk.datastore.*
import com.sap.it.api.asdk.runtime.*

def Message processData(Message message) {
    def body = message.getBody(java.lang.String)
    def query = new XmlParser().parseText(body)
    def valueMappingApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def allfsmCompanyList;
    
    def getAllCompanies = {
        def messageLog = messageLogFactory.getMessageLog(message)
        def DSservice = new Factory(DataStoreService.class).getService()
        // get the FSM Company List from data store
        def dsEntry = DSservice.get("FSMCompanyList", 'FSMCompanyList')?DSservice.get("FSMCompanyList", 'FSMCompanyList'):'NA'
		if (dsEntry != 'NA'){
			def result = new String(dsEntry.getDataAsArray())
			allfsmCompanyList = new XmlParser().parseText(result)
		}else{
		   allfsmCompanyList = new XmlParser().parseText("<FSMMultiCompany><FSMCompany>NA|NA</FSMCompany></FSMMultiCompany>")
		}
    }
    
    /*START: Logic to handle all & custom FSM Company mapping*/
    def allCompanies = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', 'PR', 'FSM', 'AccountCompany');
    if (allCompanies == 'ALLCOMPANIES') {
        getAllCompanies();
        query.ProductMDMReplicateRequestMessage.each { prdMessage ->
            prdMessage.Product.each { prod ->
                prod.append(allfsmCompanyList)
            }
        }
    }else if (allCompanies == 'CUSTOM') {	
		customCompany = new XmlParser().parseText("<FSMMultiCompany><FSMCompany>CUSTOM</FSMCompany></FSMMultiCompany>")
		
        query.ProductMDMReplicateRequestMessage.each { prdMessage ->
            prdMessage.Product.each { prd ->
                prd.append(customCompany)
            }
        }
	/*END: Logic to handle all & custom Company logic*/
	}else{

        query.ProductMDMReplicateRequestMessage.each { prdMessage ->
            prdMessage.Product.each { prod ->
    
                def mcXML = new XmlParser().parseText("<FSMMultiCompany></FSMMultiCompany>")
                def map = message.getProperties();
                
                def productType = prod.ProductTypeCode.text();
                def fsmFromValueMap = null;
                def division;

                /*START: Logic to handle all & custom FSM Company mapping*/
                def prodAllKeyMap = "PR|MATERIALTYPE|${productType}"
                fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', prodAllKeyMap, 'FSM', 'AccountCompany')
                if(fsmFromValueMap == 'ALLCOMPANIES'){
                    getAllCompanies();
                	allfsmCompanyList.FSMCompany.each { fsmCompany ->
                        mcXML.append(fsmCompany)
                    }
                }else if (fsmFromValueMap == 'CUSTOM') {				
					customCompany = new XmlParser().parseText("<FSMMultiCompany><FSMCompany>ATTRIBUTE</FSMCompany></FSMMultiCompany>")					
                	customCompany.FSMCompany.each { fsmCompany ->
                        mcXML.append(fsmCompany)
                    }				
				}
                /*END: Logic to handle all & custom FSM Company mapping*/
                
                //function to append account and company to incoming message
                def appendAccountCompany = { AcctComp ->
                    def entries = AcctComp.tokenize(":")
                    entries.each { entry ->
                        def (account, companies) = entry.split("\\|")
                        def companyList = companies.split(",")
                        
                        companyList.each { company ->
	    			        def fsmXml = new XmlParser().parseText("<FSMCompany>${account}|${company}</FSMCompany>")
	    			        mcXML.append(fsmXml)
                        }
                    }
                }
    
                /*identify the FSM company details using Sales Area rule type*/
                prod.SalesSpecification.each { sa ->
                    division = sa.DivisionCode ? sa.DivisionCode.text() : "00"
                    def salesArea = "${sa.SalesOrganizationID.text()}|${sa.DistributionChannelCode.text()}|${division}"
                    def prodKeyMap = "PR|MATERIALTYPE|${productType}|SALESAREA|${salesArea}"
                    
                    fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', prodKeyMap, 'FSM', 'AccountCompany')
                    if(fsmFromValueMap){
	    				appendAccountCompany(fsmFromValueMap);
	    			}
                }
                
                /*identify the FSM company details using Plant rule type*/
                prod.Plant.each { pl ->
                    def plant = "${pl.PlantID.text()}"
                    def prodKeyMap = "PR|MATERIALTYPE|${productType}|PLANT|${plant}"
                    
                    fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', prodKeyMap, 'FSM', 'AccountCompany')
                    if(fsmFromValueMap){
	    				appendAccountCompany(fsmFromValueMap);
	    			}
                }
                
                
                /****Handle Specific Field mapping scenaiors -- START ****/
                def PRspecfieldsize = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', 'PRSPECSIZE', 'FSM', 'AccountCompany')
                if (PRspecfieldsize){
				    def fieldmap = [:]
                    (1..PRspecfieldsize).each { i ->
                        //get xpath value of each specific field
				    	def fieldnum = "PRFIELD"+i
				    	fieldmap[fieldnum] = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', fieldnum, 'FSM', 'AccountCompany')					
				    	if (fieldmap[fieldnum]){
				    		// Search specific XPath expression
				    		def searchxpath = '/Product' + fieldmap[fieldnum]
				    		
				    		// Define a function to find nodes based on XPath
				    		def findNodes = { node, path ->
				    			def parts = path.tokenize('/')
				    			parts.inject([node]) { list, part ->
				    				list.findAll { it.name() == part }.collect { it.children() }.flatten()
				    			}
				    		}
				    		
				    		// Find nodes based on XPath
				    		def nodes = findNodes(prod, searchxpath)
    
				    		// get the Value Mappings based on the specific fields and append the FSM companies
				    		nodes.each { node ->
				    			def prKeyMap = "PR|MATERIALTYPE|${productType}|${fieldnum}|${node}"
                                fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', prKeyMap, 'FSM', 'AccountCompany')
                                if(fsmFromValueMap){
	    		    		        appendAccountCompany(fsmFromValueMap);
	    		    	        }
	    		    	        
	    		    	        def prspecKeyMap = "PR|||${fieldnum}|${node}"
                                specfsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', prspecKeyMap, 'FSM', 'AccountCompany')
                                if(specfsmFromValueMap){
	    		    		        appendAccountCompany(specfsmFromValueMap);
	    		    	        }
				    		}
				    	}				
				    }
                }
                /****Handle Specific Field mapping scenaiors -- END ****/
                
                
	    		if (!mcXML.FSMCompany)
	    		{
	    			def fsmXml = new XmlParser().parseText("<FSMCompany>NA|NA</FSMCompany>")
	    			mcXML.append(fsmXml)
	    		}
    
                prod.append(mcXML)
            }
        }
    }

    def FSMCompanyData = XmlUtil.serialize(query)
    message.setBody(FSMCompanyData)
    return message
}
