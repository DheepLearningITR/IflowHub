import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.util.XmlParser
import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script gets Product Object details for custom company determination */
    
    def body = message.getBody(String)
    def parsedXml = new XmlSlurper().parseText(body)
    def customObjects = new XmlParser().parseText("<CustomObjects></CustomObjects>")

    parsedXml.ProductMDMBulkReplicateRequestMessage.each { prRequest ->
        //get the PR details where Custom rule type is set at the object level
        if (prRequest.@MultiCompanyGroup.text() in ['CUSTOM', 'ATTRIBUTE']) {
            prRequest.ProductMDMReplicateRequestMessage.each { prMessage ->
                prMessage.Product.each { pr ->
                   // pr.Role.each { role ->
                    def customObjectXml = buildCustomObjectXml(pr, pr, prRequest.@MultiCompanyGroup.text())
                    def customObjectNode = new XmlParser().parseText(customObjectXml)
                    customObjects.append(customObjectNode)
                    //}
                }
            }
        }
    }

    message.setBody(XmlUtil.serialize(customObjects))
    return message
}

def String buildCustomObjectXml(pr, type, ruleType) {
    def builder = new StringBuilder()
    builder.append("<customObject>")
    builder.append("<SrvcMgmtFSMRplctnObjID>").append(pr.ProductInternalID.text()).append("</SrvcMgmtFSMRplctnObjID>")
    builder.append("<SrvcMgmtFSMReplicationObject>PR</SrvcMgmtFSMReplicationObject>")

    if (ruleType == 'ATTRIBUTE') {
        builder.append("<SrvcMgmtFSMRplctnObjAttribute>MATERIALTYPE</SrvcMgmtFSMRplctnObjAttribute>")
        builder.append("<SrvcMgmtFSMRplctnObjAttribVal>").append(type.ProductTypeCode.text()).append("</SrvcMgmtFSMRplctnObjAttribVal>")
    } else {
        builder.append("<SrvcMgmtFSMRplctnObjAttribute></SrvcMgmtFSMRplctnObjAttribute><SrvcMgmtFSMRplctnObjAttribVal></SrvcMgmtFSMRplctnObjAttribVal>")
    }

    builder.append("</customObject>")
    return builder.toString()
}
