import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import javax.activation.DataHandler;

def Message processEvent(Message message) {
	//Body 
	def body = message.getBody(String.class);
	JsonSlurper slurper = new JsonSlurper();
	Map parsedJson = slurper.parseText(body);
	def type;
	
	switch (parsedJson.type) {
		case "sap.s4.beh.creditmemorequest.v1.CreditMemoRequest.Deleted.v1":
		type = "Credit Memo Request Deleted";"
		break;
		
		default:
		type = "NA";
	}
	
	message.setProperty("eventType", type);
	
	if (type != "NA") {
		message.setProperty("processDefinitionId", "managecreditmemo");
		message.setProperty("processInstanceId", parsedJson.data.CreditMemoRequest.CreditMemoRequest);
		message.setProperty("eventTimestamp", parsedJson.time);
		message.setProperty("orderId", parsedJson.data.CreditMemoRequest.CreditMemoRequest);
	}
	
	return message;
	
}

def Message processCreditMemoRequest(Message message) {
	def body = message.getBody(String.class);
	def creditMemoRequest;
	String[] reasonList;
	def creditMemoRequestApprovalReason;
	def payload = new groovy.json.JsonBuilder()
	def ApprovalRelevance = "Not Relevant";
	
	JsonSlurper slurper = new JsonSlurper();
	Map parsedJson = slurper.parseText(body);
	
	if (parsedJson.d != null) {
		creditMemoRequest = parsedJson.d;
		creditMemoRequest.remove('__metadata');
		creditMemoRequest.remove('to_Item');
		creditMemoRequest.remove('to_Partner');
		creditMemoRequest.remove('to_PricingElement');
		creditMemoRequest.remove('to_Text');
		
		message.setProperty("creditMemoRequest", creditMemoRequest);
		
		
		// prepare credit memo request changed event for process visibility
		def root = payload {
			processDefinitionId "managecreditmemo"
			processInstanceId message.properties.processInstanceId
			eventType message.properties.eventType
			timestamp message.properties.eventTimestamp
			context creditMemoRequest
		}
		message.setBody(payload.toString());
		message.setHeader("Content-Type", "application/json");
		
		} else {
		message.setProperty("approvalRequired", 'false');
	}
	return message;
}


def Message prepareCheckCMRApprovalWorkflowExists(Message message) {
	message.setProperty("workflowCallType", "GET");
	// Look specifically for Approve Sales Order Workflow. We then proceed based on its status.
	def queryParam = "definitionId=com.sap.content.creditmemo.approvecreditmemo&businessKey=" + message.properties.orderId;
	message.setProperty("queryParameters", queryParam);
	return message;
}

def Message processApprovalWFCheck(Message message) {
	def body = message.getBody(String.class);
	def parsedJson = new JsonSlurper().parseText(body);
	def approvalWFExists = false;
	def approvalWFIndex = 0;
	if (parsedJson.size() > 0) {
		parsedJson.eachWithIndex {
			it,
			idx ->
			if (it.status == "RUNNING") {
				approvalWFExists = true;
				approvalWFIndex = idx;
			}
			
		}
	}
	
	if (approvalWFExists) {
		// We may get more workflows since they could be older completed/cancelled/erronous/suspended.
		// Only look for workflow in Running state.
		// RootInstance ID WILL ALWAYS EXIST IF WORKFLOW EXISTS
		message.setProperty("approvalWFRootInstanceID", parsedJson[approvalWFIndex].rootInstanceId);
		message.setProperty("approvalWFExists", approvalWFExists);
		message.setProperty("workflowCallType", "PATCH");
		def payload = new groovy.json.JsonBuilder()
		def payloads = [];
		def root = payload {
			status "Canceled"
			cascade "true"
		}
		payloads.push(payload);
		message.setBody(payloads.toString());
		message.setHeader("Content-Type", "application/json");
		
		} else if (parsedJson.size() < 1) {
		message.setProperty("approvalWFExists", "false");
	} 
	return message;
}