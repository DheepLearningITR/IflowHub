import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.pd.BinaryData;


def Message processData(Message message) {
    
    def unique_id = message.getProperty('ENDPOINT_ID');
    
    def PD_NAMESPACE = "DME_Generic_Processing_$unique_id";

    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 

    if (service == null){
      throw new IllegalStateException("Partner Directory Service not found");
    }

    def headers = message.getHeaders();
    if (headers != null) {
        def rfc_target_url = headers.get("ErpDestination");
        if (rfc_target_url == null || "".equals(rfc_target_url)) {
            throw new IllegalStateException("ErpDestination not found");
        }
    }

    return message;
}

def void copy_single_parameter(String propname, String pdname, String pid, def message, def service) {

    def VALUE1 = service.getParameter(pdname, pid, String.class);
    message.setProperty(propname, VALUE1 );

}

def void copy_pd_parameter(String propname, String pdname1, String pdname2, String pid, def message, def service) {
  
    def VALUE1 = service.getParameter(pdname1, pid, String.class);
    def VALUE2 = service.getParameter(pdname2, pid, String.class);
    if (VALUE1) { 
         message.setProperty(propname, VALUE1 );
    } else if (VALUE2) {
         message.setProperty(propname, VALUE2 );
    }
}

def void copy_binary_pd_parameter(String propname, String pdname1, String pdname2, String pid, def unique_id, def message, def service) {
  
    def VALUE1 = service.getParameter(pdname1, pid, BinaryData.class);
    def VALUE2 = service.getParameter(pdname2, pid, BinaryData.class);
    if (VALUE1) { 
         message.setProperty(propname, "pd:DME_Generic_Processing_$unique_id:$pdname1:Binary" );
    } else if (VALUE2) {
         message.setProperty(propname, "pd:DME_Generic_Processing_$unique_id:$pdname2:Binary" );
    }
}
