/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {
    def httpStatusCode = message.getHeader("CamelHttpResponseCode", java.lang.Integer);
    def json = new JsonSlurper().parseText(message.getBody(java.lang.String));
    
    if(httpStatusCode.equals(201)) {
        message.setProperty("PurchaseOrderNumber",json.d.PurchaseOrder);
        message.setProperty("Status", "Success");
        message.setProperty("Message", "Purchase Order created");
    } 
    else if(httpStatusCode.equals(400)) {
        def errors = json.error.innererror.errordetails;
        def errMessage = json.error.message.value.replaceAll("\"","'") + ". ";
         
        errors.each { node ->
            if(node.severity == "error"){
                errMessage += node.message.replaceAll("\"","'") + ". ";   
            }
        }

        message.setProperty("Status", "Failed");
        message.setProperty("Message", errMessage);
    } 
    else {
        def errMessage = "Technical error occurred - MPL ID " 
                            + message.getHeader("SAP_MplCorrelationId") + ". "
                            + json.error.message.value;
        
        message.setProperty("Status", "Failed");
        message.setProperty("Message", errMessage);
    }
    
    return message;
}