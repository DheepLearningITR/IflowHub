import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.TreeSet;
import java.io.InputStream;
import java.awt.Component.BaselineResizeBehavior
import java.io.ByteArrayInputStream;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.XmlUtil;
import java.text.SimpleDateFormat;
import java.text.Format;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message) {
//Body

    InputStream is  = message.getBody(java.io.InputStream);
	String xml = is.getText("UTF-8");
    
    
    products = getProducts(xml);
    message.setProperty("productData",products);
    
    is = new ByteArrayInputStream(xml.getBytes("UTF-8"))
	message.setBody(is);

    return message;
}

def getProducts(def body){

    def object = new XmlParser().parseText(body);

    def products = object.products[0];

    return XmlUtil.serialize(products).replace('<?xml version="1.0" encoding="UTF-8"?>',"");
 }
