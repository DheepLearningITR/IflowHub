/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.TreeSet;
import java.io.InputStream;
import java.awt.Component.BaselineResizeBehavior;
import java.io.ByteArrayInputStream;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.XmlUtil;
import java.text.SimpleDateFormat;
import java.text.Format;
import com.sap.it.api.ITApiFactory;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    //Body
    def body = message.getBody(String);
    def object = new XmlParser().parseText(body);

    def entries = object.'ATPRlvtProductMRPArea_Type';
    def chunkSize = 150;
    def batchId = '1000';
    def changesetId = '2000';
    
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.root {
        entries.collate(chunkSize).eachWithIndex { chunk, index ->
            def localBatchId = batchId + index.toString()
            def localChangesetId = changesetId + (index * chunkSize).toString()
            def batchRequest = generateBatchContentMRPArea(localBatchId, localChangesetId, chunk)
    
            group(batchId: localBatchId) {
                products {
                chunk.each { entry ->
                    A_ProductType {
                            Product(entry.Product.text())
                            MRPArea(entry.MRPArea.text())
                            ProductStandardID(entry.ProductStandardID.text())
                            InventoryItemID(entry.InventoryItemID.text())
                        }
                    }
                }
                content {
                    mkp.yieldUnescaped("<![CDATA[${batchRequest}]]>")
                }
            }
        }
    }

    message.setBody(writer.toString());
    return message;
}


def generateBatchContentMRPArea(localBatchId, localChangesetId, entries) {
    def batchId = "batch_" + localBatchId
    def batchRequest = ""

    entries.eachWithIndex { entry, index ->
        batchRequest += "--${batchId}\n"
        def changesetId = "changeset_${index + localChangesetId}"
        batchRequest += "Content-Type: multipart/mixed;boundary=${changesetId}\n\n"

        batchRequest += "--${changesetId}\n"
        batchRequest += "Content-Type: application/http\n"
        batchRequest += "Content-Transfer-Encoding: binary\n"
        batchRequest += "Content-ID: ${index + 1}\n\n"

        def uri = "ProductMRPArea(Product='${entry.Product.text()}',MRPArea='${entry.MRPArea.text()}')/SAP__self.DetmAvailabilityTimeSeries"
        batchRequest += "POST ${uri} HTTP/1.1\n\n"

        batchRequest += "{\n"
        batchRequest += "   \"ATPCheckingRule\": \"A\"\n"
        batchRequest += "}\n\n"
        
        batchRequest += "--${changesetId}--\n\n"
    }
    batchRequest += "--${batchId}--"

    return batchRequest.toString();
}
