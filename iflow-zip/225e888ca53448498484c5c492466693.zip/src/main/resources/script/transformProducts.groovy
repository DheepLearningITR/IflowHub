import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.TreeSet;
import java.io.InputStream;
import java.awt.Component.BaselineResizeBehavior
import java.io.ByteArrayInputStream;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.XmlUtil;
import java.text.SimpleDateFormat;
import java.text.Format;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
//Body

    InputStream is  = message.getBody(java.io.InputStream);
	String xml = is.getText("UTF-8");
    
    def productMRPAreas = message.getProperty("allProductMRPAreas");
    def allProductsShopify = message.getProperty("allProductsShopify");
    
    xml = transformProducts(xml);
    productMRPAreas = transformProductMRPAreas(productMRPAreas);
    
    productMRPAreas = filterProductsInShopify(productMRPAreas, allProductsShopify);
    
    xml = combineXML(productMRPAreas, xml);
    
    is = new ByteArrayInputStream(xml.getBytes("UTF-8"))
	message.setBody(is);

    return message;
}

def refreshXMLStructure(def xml){
	 //used to reparse the xml
	def temp = XmlUtil.serialize(xml);
	return new XmlParser().parseText(temp);
}

def filterProductsInShopify(def productMRPAreas, def shopifyProducts){
    productMRPAreas = new XmlParser().parseText(productMRPAreas)
    shopifyProducts = new XmlParser().parseText(shopifyProducts)

    // Creating a map of product IDs to InventoryItemIDs from shopifyProducts
    def shopifyProductIdToInventoryMap = [:]
    shopifyProducts.'**'.findAll { it.name() == 'ATPRlvtProductMRPArea_Type' }.each {
        def productId = it.Product.text()
        def inventoryItemId = it.InventoryItemID.text()
        shopifyProductIdToInventoryMap[productId] = inventoryItemId
    }

    // Filtering productMRPAreas and creating XML for filtered products
    StringWriter writer = new StringWriter()
    def builder = new MarkupBuilder(writer)
    builder.ProductMRPArea {
        productMRPAreas.ATPRlvtProductMRPArea_Type.each { productArea ->
            def productID = productArea.Product.text()
            if (shopifyProductIdToInventoryMap.containsKey(productID)) {
                ATPRlvtProductMRPArea_Type {
                    Product(productID)
                    MRPArea(productArea.MRPArea.text())
                    InventoryItemID(shopifyProductIdToInventoryMap[productID])
                }
            }
        }
    }
    return writer.toString()
}

def transformProducts(def body){

	def object = new XmlParser().parseText(body);

    def products = object.A_Product?.A_ProductType;
    for(def i = 0; i < products.size(); i++){
        
        if((products[i].Product.text().contains("_") && !products[i].Product.text().matches(".*\\d+.*")) ){
            products[i].replaceNode{};
        }
        
        products[i]."*".find{p -> p.name() == "Product"}.value = [products[i].Product.text().replaceAll(" ","%20")];
        
    }
    
    
	return XmlUtil.serialize(object);
 }
 
 def transformProductMRPAreas(def body){

	def object = new XmlParser().parseText(body);
 
    def products = object.ATPRlvtProductMRPArea_Type;
    for(def i = 0; i < products.size(); i++){
        
        if((products[i].Product.text().contains("_") && !products[i].Product.text().matches(".*\\d+.*")) ){
            products[i].replaceNode{};
        }
        
        products[i]."*".find{p -> p.name() == "Product"}.value = [products[i].Product.text().replaceAll(" ","%20")];
        
    }
    
    
	return XmlUtil.serialize(object);
 }
 
 //add the productstandardid to the mrpareas xml
 def combineXML(productMRPAreas, xml) {
    def parser = new XmlParser()
    def productMRPAreasParsed = parser.parseText(productMRPAreas)
    def xmlParsed = parser.parseText(xml)

    def productStandardIDs = [:]
    xmlParsed.A_Product.A_ProductType.each { node ->
        productStandardIDs[node.Product.text()] = node.ProductStandardID.text()
    }

    productMRPAreasParsed.ATPRlvtProductMRPArea_Type.each { node ->
        def product = node.Product.text()
        if (productStandardIDs[product]) {
            node.appendNode('ProductStandardID', productStandardIDs[product])
        } else {
            node.replaceNode {} // Remove the node if ProductStandardID is empty
        }
    }


    def result = XmlUtil.serialize(productMRPAreasParsed)
    result = result.replaceAll(/>\s+</, '><')

    return result
}