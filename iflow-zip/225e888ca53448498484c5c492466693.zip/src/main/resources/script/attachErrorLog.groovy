import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
//Log message body (if it has any content, else do not create empty logs)
    if(message){
        def body = message.getBody(java.lang.String) as String;
        if(body){
            def map = message.getProperties();
            def logConfig = map.get("SAP_MessageProcessingLogConfiguration");
            def messageLog = messageLogFactory.getMessageLog(message);
            if(messageLog){
                messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
                messageLog.addAttachmentAsString("ERRORLOG: ", body, "text/plain");
            }
        }
    }
    
    return message;
}