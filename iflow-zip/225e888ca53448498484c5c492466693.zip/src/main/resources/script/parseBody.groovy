/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;


def Message processData(Message message) {
    //Body
    def body = message.getBody(String);
    
    def boundary = body =~ /boundary=([\w-]+)/
    def parts = body.split("--${boundary[0][1]}")
    
    def jsonSlurper = new JsonSlurper()
    def jsonContents = []
    
    parts.each { part ->
        if (part.contains("Content-Type: application/json")) {
            def jsonStartIndex = part.indexOf('{')
            def jsonEndIndex = part.lastIndexOf('}')
            def json = part.substring(jsonStartIndex, jsonEndIndex + 1)
            //json = json.replaceAll(/W\/"(.+)(?=")/, '$1').replaceAll(/([^:])""/, '$1"')
            def parsedJson = jsonSlurper.parseText(json)
            jsonContents << parsedJson
        }
    }
    
    def productData = message.getProperty("productData")
    def xmlParser = new XmlSlurper().parseText(productData)
    
    def result = new StringWriter()
    def xml = new MarkupBuilder(result)
    
    xml.Availabilities {
        xmlParser.A_ProductType.eachWithIndex { product, index ->
            xml.ProductAvailability {
                xml.A_ProductType {
                    xml.Product(product.Product)
                    xml.MRPArea(product.MRPArea)
                    xml.ProductStandardID(product.ProductStandardID)
                    xml.InventoryItemID(product.InventoryItemID)
                }
                
                xml.CalculateAvailabilityTimeseries {
                    if (jsonContents[index] != null) {
                    jsonContents[index].value.each { record ->
                            xml.AvailabilityRecord {
                                xml.AvailableQuantityInBaseUnit(record.AvailableQuantityInBaseUnit)
                                xml.BaseUnit(record.BaseUnit)
                                xml.BaseUnitISOCode(record.BaseUnitISOCode)
                                xml.ProdAvailyPerdEndTimeZone(record.ProdAvailyPerdEndTimeZone)
                                xml.ProdAvailyPerdEndTmznIANACode(record.ProdAvailyPerdEndTmznIANACode)
                                xml.ProdAvailyPerdEndUTCDteTme(record.ProdAvailyPerdEndUTCDteTme)
                                xml.ProdAvailyPerdStrtTimeZone(record.ProdAvailyPerdStrtTimeZone)
                                xml.ProdAvailyPerdStrtTmznIANACode(record.ProdAvailyPerdStrtTmznIANACode)
                                xml.ProdAvailyPerdStrtUTCDteTme(record.ProdAvailyPerdStrtUTCDteTme)
                            }
                        }
                    }
                    }
                }
            }
        }
    
    message.setBody(result.toString());
    return message;
}