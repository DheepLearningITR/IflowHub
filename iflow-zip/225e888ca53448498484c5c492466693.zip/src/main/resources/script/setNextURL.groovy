import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
    // Get headers
    def map = message.getHeaders()

    // Get Link header
    def linkHeader = map.get("Link")

    // Extract URL using regex
    def matcher = linkHeader =~ /<.*?(\?limit.*?)>; rel="next"/
    def nextUrl = [];
    if (matcher.find()) {
        nextUrl = matcher.group(1)
    
        // Set nextUrl as a property
        message.setProperty("nextUrl", nextUrl)
    }
    
    if(nextUrl.size() > 10){
        message.setProperty("continueLoop","true");
    }else{
        message.setProperty("continueLoop","false");
    }

    return message
}
