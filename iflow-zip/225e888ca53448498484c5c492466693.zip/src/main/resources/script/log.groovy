import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
//Body

    def body = message.getBody(java.lang.String) as String;
    if(body){
            def map = message.getProperties();
            def logConfig = map.get("SAP_MessageProcessingLogConfiguration");
            def logLevel = (String) logConfig.logLevel;
            //if(logLevel.equals("DEBUG") || logLevel.equals("TRACE")) {
                def messageLog = messageLogFactory.getMessageLog(message);
                if(messageLog){
                    messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
                    messageLog.addAttachmentAsString("Log xml", body, "text/plain");
                }
            //}
        }
    return message;
}
