import com.sap.it.api.mapping.*;


def String fetchTaxPrefix(String p1, MappingContext context) {
         
         return context.getProperty(p1);
         
}
