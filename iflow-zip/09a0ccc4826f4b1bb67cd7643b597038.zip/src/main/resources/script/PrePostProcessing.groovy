import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processXmlInput(Message message) {

  def body = message.getBody(java.io.Reader)
  def xml = new XmlParser().parse(body)

  //find tags with null value
  def results = xml.
  '**'.findAll {
    !it.value()
  }

  results.each {
    def newNode = new Node(null, it.name(), 'xsi.nil')
    // replace node    
    it.replaceNode(newNode)
  }
  // write to body
  StringWriter stringWriter = new StringWriter()
  XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
  nodePrinter.setPreserveWhitespace(true)
  nodePrinter.print xml

  message.setBody(stringWriter.toString())
  return message;

}

def Message enrichJsonOutput(Message message) {
    def body = message.getBody(java.io.Reader)
    JsonSlurper slurper = new JsonSlurper()
    Map parsedJson = slurper.parse(body)

    def respbody = JsonOutput.toJson(parsedJson).replace('"xsi.nil"', 'null')
    parsedJson = slurper.parseText(respbody)

    parsedJson.messageRequests.each { request ->
        request.body.isBlocked = request.body.isBlocked?.toBoolean()
        request.body.isDeleted = request.body.isDeleted?.toBoolean()

        request.body.salesDistributionChains.each { chain ->
            chain.isDeleted = chain.isDeleted?.toBoolean()
            chain.minimumOrderQuantity.content = chain.minimumOrderQuantity.content?.toDouble()
            chain.defaultContractDuration = chain.defaultContractDuration?.toInteger()
            chain.defaultContractExtensionDuration = chain.defaultContractExtensionDuration?.toInteger()
            chain.firstAlternativeContractDuration = chain.firstAlternativeContractDuration?.toInteger()
            chain.firstAlternativeContractExtensionDuration = chain.firstAlternativeContractExtensionDuration?.toInteger()
            chain.secondAlternativeContractDuration = chain.secondAlternativeContractDuration?.toInteger()
            chain.secondAlternativeContractExtensionDuration = chain.secondAlternativeContractExtensionDuration?.toInteger()
        }

        request.body.quantityConversion.each { conversion ->
            conversion.correspondingQuantity.content = conversion.correspondingQuantity.content?.toInteger()
            conversion.quantity.content = conversion.quantity.content?.toInteger()
        }

        request.body.globalTradeItemNumbers.each { item ->
            item.isMain = item.isMain?.toBoolean()
        }
    }

    message.setBody(JsonOutput.toJson(parsedJson))
    return message
}