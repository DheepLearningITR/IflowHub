import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    def body = message.getBody(java.io.Reader);
    def root =  new XmlSlurper().parse(body);
    
    def EnviarXmlCancelacionCFDIUsrResult = root.EnviarXmlCancelacionCFDIUsrResult.toString();
        root = new XmlSlurper().parseText(EnviarXmlCancelacionCFDIUsrResult);
        message.setProperty("Error",root.Mensaje.@CodigoError.toString());
        message.setProperty("Descripcion",root.Mensaje.toString());
        message.setProperty("cancelResponseXML",EnviarXmlCancelacionCFDIUsrResult);
   
       
       return message;
}
