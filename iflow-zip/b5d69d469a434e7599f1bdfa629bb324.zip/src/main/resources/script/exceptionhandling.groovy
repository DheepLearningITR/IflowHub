
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;


def Message processData(Message message) {
def map = message.getProperties();
def ex = map.get("CamelExceptionCaught");

   
if (ex!=null) {
	def body = message.getBody();
	
	message.setBody(ex.getMessage().substring(47).replace("\"", "").replace("\'", ""));

 

//Headers
//	message.setHeader("STATUS_CODE", ex.getFaultCode());
//	message.setHeader("STATUS_TEXT", ex.getMessage());

//    message.setHeader("STATUS_CODE", ex.getStatusCode());
	message.setHeader("STATUS_TEXT", ex.getMessage());

	}
	
	return message;
}


