import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def body = message.getBody(java.io.Reader);
    def root =  new XmlSlurper().parse(body);
    
    def TimbreFiscalDigital = root.TimbradoCFDStrXMLResult.toString();
    if(TimbreFiscalDigital.indexOf("?>")>0)
        message.setProperty("TimbreFiscalDigital",TimbreFiscalDigital.substring(TimbreFiscalDigital.indexOf("?>")+2));
    else{
        root = new XmlSlurper().parseText(TimbreFiscalDigital);
        message.setProperty("Error",root.Mensaje.@CodigoError.toString());
        message.setProperty("Descripcion",root.Mensaje.toString());
        message.setProperty("TimbreFiscalDigital",TimbreFiscalDigital);
    }
         
       
       return message;
}