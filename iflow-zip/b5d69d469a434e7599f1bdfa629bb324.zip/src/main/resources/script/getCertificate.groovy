/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.commons.codec.binary.Base64;
import java.security.cert.X509Certificate;
import java.security.cert.Certificate;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

def Message processData(Message message) {
   
     def map = message.getProperties();
     def header = message.getHeaders();
     
         def serviceSecureStore = ITApiFactory.getApi(SecureStoreService.class, null);
    if( serviceSecureStore != null){
        String pUserName = message.getProperty("P_RfcEmisor") + "_ME_USER"
        String pPassword = message.getProperty("P_RfcEmisor") + "_ME_PASSWD"
        
        //Get UserCredential containing user credential details deployed on the node with the given alias.
        String username = serviceSecureStore.getUserCredential(pUserName).getPassword().toString();
        String password = serviceSecureStore.getUserCredential(pPassword).getPassword().toString();
        
        message.setProperty("P_USERNAME",username );
        message.setProperty("P_PASSWORD",password );
    } 
     
     String input = map.get("epayment");     
     def submit= header.get("submit");
     def cancel= header.get("cancel");
     def getStatus = header.get("getStatus")
     int j=0;
     char[] cert = new char[20];
 
          
     //Deciding the name of the root node and response path based on the action
     if(submit)
     {
     	message.setProperty("root","scfd:EmisionRapidaCFDXml/scfd:peticion");
     	message.setProperty("response","/EmisionRapidaCFDXmlResponse/EmisionRapidaCFDXmlResult/ResponseAdmon");
     }
	 else if(cancel)
	 {
	 	message.setProperty("root","scfd:CancelaCFDPorSolicitud/scfd:peticion");
	 	message.setProperty("response","/CancelaCFDPorSolicitudResponse/CancelaCFDPorSolicitudResult");
	 }
	 else if(getStatus)
	 {
	 	message.setPropery("root","cfdi:getUUIDTest");
	 	message.setProperty("response","/getUUIDTestResponse/getUUIDTestReturn");
	 }
	 

	 if(submit)
	 {
	 def certname = header.get("certname");
	 //Access the keystore and get the certificate based on the alias
	 def service = ITApiFactory.getApi(KeystoreService.class, null);
//     if (credential == null){
//      throw new IllegalStateException("No credential found for alias" + credentials);
//    }
    
     Certificate certs = service.getCertificate(certname);
	 X509Certificate x509certificate = (X509Certificate)certs;
     
	 def serial =  certs.getSerialNumber();
	 
	 String cert_serial =  x509certificate.getSerialNumber().toString(16);
	 
	 char[] serialno = cert_serial.toCharArray();
	 
	 for(int i=1;i<cert_serial.length();i=i+2)
	    cert[j++] = serialno[i];
	    
	 String certificateno= String.valueOf(cert); 
	 message.setHeader('certificateno',certificateno);
	 message.setHeader('serial',serial);
	 
	 //prepare Base64 encoded format of the certificate
	 String certificate =  Base64.encodeBase64String(certs.getEncoded());
	
	 message.setHeader("certificate", certificate);
	
	 }
	 
	return message;
}

