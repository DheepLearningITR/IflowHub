import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    //Get the message body
    def body = message.getBody(java.lang.String);
     
    //Unescape
    def output = body.replaceAll(/&lt;/, '<').replaceAll(/&gt;/, '>').replaceAll(/&quot;/, '"').replaceAll(/&apos;/, "'").replaceAll(/&amp;/,'&')      
 
	//set the output message body
	message.setBody(output)
	return message
}
