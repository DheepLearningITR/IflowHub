import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Payload", body, "text/plain");
		}
	}
	return message;
}

def Message respMasterEDI(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Response MASTEREDI", body, "text/plain");
		}
	}
	return message;
}

def Message respSAP(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Response To SAP", body, "text/plain");
		}
	}
	return message;
}


def Message reqMasterEDI(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Request To MASTEREDI", body, "text/plain");
		}
	}
	
	return message;
}