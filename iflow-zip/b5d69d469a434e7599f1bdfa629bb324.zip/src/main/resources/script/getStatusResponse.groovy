import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    def body = message.getBody(java.io.Reader);
    def root =  new XmlSlurper().parse(body);
    
    def ConsultaCancelacionCFDIUsrResult = root.ConsultaCancelacionCFDIUsrResult.toString();
        root = new XmlSlurper().parseText(ConsultaCancelacionCFDIUsrResult);
        message.setProperty("Error",root.Mensaje.@CodigoError.toString());
        message.setProperty("Descripcion",root.Mensaje.toString());
        message.setProperty("getStatusResponseXML",ConsultaCancelacionCFDIUsrResult);
        message.setProperty("FechaAcuse",root.Mensaje.@FechaAcuse.toString());
        message.setProperty("Acuse",root.Mensaje.@Acuse.toString());
        def Acuse = root.Mensaje.@Acuse.toString();
        
        if(Acuse.equals(""))
        {
             message.setProperty("EstatusUUID","");
        }
        else
        {
           childxml = new XmlSlurper().parseText(Acuse);
           message.setProperty("EstatusUUID",childxml.Folios.EstatusUUID.toString());
           message.setBody(Acuse);
        }
        
       return message;
}
