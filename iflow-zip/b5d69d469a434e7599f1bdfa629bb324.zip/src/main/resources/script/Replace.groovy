
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.commons.codec.binary.Base64;
import java.security.cert.X509Certificate;
import java.security.cert.Certificate;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

def Message processData(Message message) {
   
     def map = message.getProperties();
     def header = message.getHeaders();
     
          
    def Str = message.getProperty("Descripcion");
	def str_replace = Str.replaceAll('"','\'');
        
    message.setProperty("Descripcion",str_replace);
	 
	
	return message;
}
