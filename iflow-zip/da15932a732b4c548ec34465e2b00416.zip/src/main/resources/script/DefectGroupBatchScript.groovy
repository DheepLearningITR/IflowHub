import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	
	// Batch Payload
    String completePayload = "";
  
    // Generate Random Id to be used in Batch Code
    String batchId = UUID.randomUUID().toString();
  
    // Prepare Batch Code
    String batchCode = "--batch_id-" + batchId;    
	
	// Generate changeset Id to be used in changeset Code
	String changesetID = UUID.randomUUID().toString();
	
	// Prepare changeset Code
	String changeset = "--changeset_" + changesetID; 
	
	completePayload=completePayload.concat(batchCode + "\n")
	completePayload=completePayload.concat("Content-Type: multipart/mixed; boundary=changeset_"+changesetID+ "\n")
    
	//Checking if there is only one Record
    
	if (!isCollectionOrArray(object.row)) {
        
		//Converting Record to an array
        
		object.row = [object.row].toArray();
    
	}

	// Prepare changeset data by looping the list of records
	object.row.each { record ->
		String tempPayload = changeset + "\n"
		tempPayload = tempPayload + "Content-Type:application/http " + "\n" + "Content-Transfer-Encoding:binary" + "\n" + "\n"
		tempPayload = tempPayload + "POST DefectGroups HTTP/1.1" + "\n"
		tempPayload = tempPayload + "Accept:application/json;odata.metadata=minimal;IEEE754Compatible=true" + "\n" 
		tempPayload = tempPayload + "Accept-Language:en-US" + "\n" 
		tempPayload = tempPayload + "Content-Type:application/json;charset=UTF-8;IEEE754Compatible=true" + "\n" + "\n" 
		//convert the closure variable to Json output
		def sRecord = JsonOutput.toJson(record)
		
		tempPayload = tempPayload + sRecord + "\n"
	
		completePayload=completePayload.concat(tempPayload)
	}
	
	// Close the full payload
	completePayload = completePayload + "--changeset_" + changesetID + "--" + "\n"
	
	// Prepare Message Body
	message.setBody(completePayload)
	
	// Prepare Boundary Header Parameter to be added in message header
	String boundaryParam = "multipart/mixed; boundary=changeset_" + changesetID;
	
	// Prepare Message Header
	message.setHeader('Content-Type', boundaryParam)
	message.setHeader('Prefer', "odata.continue-on-error")
	
    return message
}



//Returns true if object is an array

boolean isCollectionOrArray(object) {
    
	[Collection, Object[]].any {
        
		it.isAssignableFrom(object.getClass())
    
	}

}