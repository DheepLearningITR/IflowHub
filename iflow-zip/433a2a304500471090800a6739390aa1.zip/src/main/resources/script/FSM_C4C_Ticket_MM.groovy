import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.time.TimeCategory;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {
       def root = new XmlParser().parseText(message.getBody(String.class));
       def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
       
        def x_comp_id = root.fsm_header."x-company-id".text()
        boolean new_sc = message.getProperty("TM_Approv_Complete_Data").toLowerCase().equals("true") ? true : false

        def root_output = new NodeBuilder()."n0:TicketBulkReplicationRequest"('xmlns:n0': 'http://sap.com/xi/SAPGlobal20/Global'){
        	MessageHeader{
        		ID(root.fsm_header."x-request-id".text().toUpperCase())
        		UUID(root.fsm_header."x-message-id".text())
        		CreationDateTime(new Date().format("yyyy-MM-dd'T'HH:mm:ss'Z'"))
        		SenderParty{
        			InternalID(schemeID:'CommunicationSystemID',schemeAgencyID:'310',x_comp_id)
        		}
        		RecipientParty{
        			InternalID(schemeID:'CommunicationSystemID',schemeAgencyID:'310',root.fsm_header.C4C_tenant_ID.text())
        		}
        		BusinessScope{
        			TypeCode(listID:'25201',listAgencyID:'310',"3")
        			ID(schemeID:'10555',schemeAgencyID:'310',"106")
        		}
        	}
        	TicketReplicationRequest{
        		BasicMessageHeader{
        			UUID(root.fsm_body.eventID.text())
        		}
        		ServiceRequest(actionCode:'02',ServiceReferenceObjectCompleteTransmissionIndicator:'false',ItemCompleteTransmissionIndicator:'false',PartyCompleteTransmissionIndicator:'false',skillListCompleteTransmissionIndicator:'false'){
        			ReceiverID(root.fsm_body.data.externalId.text())
        			ServiceRequestBTDReference(actionCode:'04'){
        				BusinessTransactionDocumentRelationshipRoleCode('6')
        				BusinessSystemID(x_comp_id)
        				FormattedUUID(root.fsm_body.data.id.text())
        				BTDReference{
        					ID(root.fsm_body.data.code.text() == "" ? root.fsm_body.data.id.text() : root.fsm_body.data.code.text())
        					TypeCode('118')
        				}
        			}
        		}
        	}
        }
        
        def sr_head = root_output.TicketReplicationRequest.ServiceRequest[0]
        def sc_eventType = root.fsm_body.eventType.text()
        if(sc_eventType.equals('servicecall.created')) {
        	sr_head.@actionCode = '01'
        	new_sc = true
        }
        else if(sc_eventType.equals('servicecall.fullsynced')) {
        	sr_head.@actionCode = '04'
        	sr_head.append(new NodeBuilder().FullSyncIndicator(true))
        	new_sc = true
        }
        
        if(sc_eventType.equals('servicecall.updated') 
        || sc_eventType.equals('servicecall.created')
        || sc_eventType.equals('servicecall.fullsynced')
        || (sc_eventType.equals('activity.confirmed') && new_sc == true)){
            sr_header_and_activity_data(message, root, new_sc, sr_head)
        }
        
        if(sc_eventType.equals('activity.confirmed') || sc_eventType.equals('servicecall.fullsynced')){
        	
        	for(act in root.fsm_body.data.activities) {
        		if(!(act.eventType.text().equals('activity.confirmed') || root.fsm_body.eventType.text().equals('servicecall.fullsynced'))) {
        			continue
        		}
        		// Material consumption to Part Consumption line item
        		for(mat in act.materials) {
        			if(mat.approvalStatus.text().equals('APPROVED')) {
        				Node mat_item = new NodeBuilder().Item(actionCode:'04', ItemScheduleLinesCompleteTransmissionIndicator : true,
        				ItemPartyCompleteTransmissionIndicator : true){
        					UUID(mat.externalId.text())
        					ExecutionLifeCycleStatusCodeText('CLOSED')
        					TicketItemDeterminationMethodCode('6')
        					FSMRelevanceCode('3')
        					HierarchyRelationship{
        						ParentItemUUID(act.externalId.text())
        						TypeCode('001')
        					}
        					ItemScheduleLines(actionCode:'04'){
        						TypeCode('5')
        						Quantity(mat.quantity.text())
        					}
        					ItemProduct(actionCode:'04'){
        						ProductInternalID(mat.item.externalId.text())
        					}
        					ItemParty(actionCode:'04'){
        						PartyID(mat.createPerson.externalId.text())
        						RoleCode('43')
        						MainIndicator(true)
        					}
        					ItemBTDReference(actionCode:'04'){
        						BusinessTransactionDocumentRelationshipRoleCode('6')
        						BusinessSystemID(x_comp_id)
        						FormattedUUID(mat.id.text())
        						BTDReference{
        							ID(mat.id.text())
        							TypeCode('118')
        							ItemTypeCode('271')
        						}
        					}
        				}
        				// Consumption from Reserved Material
        				if(mat.reservedMaterials[0]?.externalId?.text()?.length() > 0) {
        					mat_item.append(new NodeBuilder().ReservedMaterialReferenceUUID(mat.reservedMaterials[0].externalId.text()))
        				}
        
                        //equipment mapping
                        
        
        				if(!mat.remarks.text().equals("")) {
        					mat_item.append(new NodeBuilder().ItemTextCollection(){
        						Text(actionCode:'04'){
        							TypeCode('10011')
        							ContentText(mat.remarks.text())
        						}
        					})
        				}
        
        				sr_head.append(mat_item)
        			}
        		}
        		// Travel mileages to Ticket line item
        		for(mil in act.mileages) {
        			if(mil.approvalStatus.text().equals('APPROVED')) {
        				Node mil_item = new NodeBuilder().Item(actionCode:'04', ItemScheduleLinesCompleteTransmissionIndicator : true,
        				ItemPartyCompleteTransmissionIndicator : true){
        					UUID(mil.externalId.text())
        					ExecutionLifeCycleStatusCodeText('CLOSED')
        					TicketItemDeterminationMethodCode('6')
        					FSMRelevanceCode('5')
        					HierarchyRelationship{
        						ParentItemUUID(act.externalId.text())
        						TypeCode('001')
        					}
        					ItemScheduleLines(actionCode:'04'){
        						TypeCode('5')
        						Quantity(mil.distance.text())
        						DateTimePeriod{
        							StartDateTime(timeZoneCode:'UTC',mil.travelStartDateTime.text())
        							EndDateTime(timeZoneCode:'UTC',mil.travelEndDateTime.text())
        						}
        					}
        					ItemParty(actionCode:'04'){
        						PartyID(mil.createPerson.externalId.text())
        						RoleCode('43')
        						MainIndicator(true)
        					}
        					ItemBTDReference(actionCode:'04'){
        						BusinessTransactionDocumentRelationshipRoleCode('6')
        						BusinessSystemID(x_comp_id)
        						FormattedUUID(mil.id.text())
        						BTDReference{
        							ID(mil.id.text())
        							TypeCode('118')
        							ItemTypeCode('271')
        						}
        					}
        				}
        
        				if(!mil.remarks.text().equals("")) {
        					mil_item.append(new NodeBuilder().ItemTextCollection(){
        						Text(actionCode:'04'){
        							TypeCode('10011')
        							ContentText(mil.remarks.text())
        						}
        					})
        				}
        
        				sr_head.append(mil_item)
        			}
        		}
        
        		// Expenses incurred to Ticket line item
        		for(exp in act.expenses) {
        			if(exp.approvalStatus.text().equals('APPROVED')) {
        				Node exp_item = new NodeBuilder().Item(actionCode:'04',	ItemPartyCompleteTransmissionIndicator : true){
        					UUID(exp.externalId.text())
        					ExecutionLifeCycleStatusCodeText('CLOSED')
        					TicketItemDeterminationMethodCode('6')
        					FSMRelevanceCode('6')
        					HierarchyRelationship{
        						ParentItemUUID(act.externalId.text())
        						TypeCode('001')
        					}
        					ExpenseType(exp.type.code.text())
        					ItemParty(actionCode:'04'){
        						PartyID(exp.createPerson.externalId.text())
        						RoleCode('43')
        						MainIndicator(true)
        					}
        					ItemBTDReference(actionCode:'04'){
        						BusinessTransactionDocumentRelationshipRoleCode('6')
        						BusinessSystemID(x_comp_id)
        						FormattedUUID(exp.id.text())
        						BTDReference{
        							ID(exp.id.text())
        							TypeCode('118')
        							ItemTypeCode('271')
        						}
        					}
        				}
        				
                        if(!exp.externalAmount.amount.text().equals("")) {
                					exp_item.append(new NodeBuilder().ExternalAmount(exp.externalAmount.amount.text()))
                					exp_item.append(new NodeBuilder().CurrencyCode(exp.externalAmount.currency.text()))
        				}
        				
        				if(!exp.remarks.text().equals("")) {
        					exp_item.append(new NodeBuilder().ItemTextCollection(){
        						Text(actionCode:'04'){
        							TypeCode('10011')
        							ContentText(exp.remarks.text())
        						}
        					})
        				}
        
        				sr_head.append(exp_item)
        			}
        		}
        	}
    //TimeEfforts to C4C Time Entry mapping    	
        	for(act in root.fsm_body.data.activities) {
        		if(!(act.eventType.text().equals('activity.confirmed') || root.fsm_body.eventType.text().equals('servicecall.fullsynced'))) {
        			continue
        		}
        	    for(te in act.timeEfforts) {
        			if(te.approvalStatus.text().equals('APPROVED')) {
        			    def rec_tz = valueMapApi.getMappedValue('FSM', 'FSM_TZ', te.startDateTimeTimeZoneId.text(), 'C4C', 'C4C_TZ')
        			    if(rec_tz.equals(null)){
        			        rec_tz = 'UTC'
        			    }
        				Node te_item = new NodeBuilder().TimeEntry(ActionCode:'04'){
        					PartyID(te.createPerson.externalId.text())
        					ItemReferenceUUID(act.externalId.text())
        					TimeType(te.task.code.text())
        					ObjectType('118')
        					ReceiverTimeZone(rec_tz)
        					StartDateTime(te.startDateTime.text())
        					EndDateTime(te.endDateTime.text())
        					BreakInMinutes(te.breakInMinutes.text())
        				}
        				if(te.remarks.text().length() > 0) {
        					te_item.append(new NodeBuilder().Description(te.remarks.text()))
        				}
        				sr_head.append(te_item)
        			}
        		}
        	}
        	// Workaround for expense pricing node after Extended XML handling enabled
        	if(!root.fsm_body.data.activities.'*'.find{node ->
        		((node.name().equals('expenses')) &&
        				(node.approvalStatus.text().equals('APPROVED')))}.equals(null)) {
        			sr_head.append(new NodeBuilder().ExternalPriceDocument(ItemCompleteTransmissionIndicator: false) {
        				BaseBusinessTransactionDocumentTypeCode('118')
        			})
        	}
        }
        
        if(sc_eventType.equals('stocktransfer.created') || sc_eventType.equals('stocktransfer.fullsync')){
        	for(st in root.fsm_body.data.stockTransfer) {
        		Node st_item = new NodeBuilder().Item(actionCode:'04'){
        			FSMRelevanceCode("7")
        			TicketItemDeterminationMethodCode('6')
        			ReservedMaterialReferenceUUID(st.reservedMaterials[0].externalId.text())
        			ItemScheduleLines(actionCode:'04'){
        				TypeCode('1')
        				Quantity(st.inventoryItems.quantity.text())
        			}
        			ItemProduct(actionCode:'04'){
        				ProductInternalID(st.inventoryItems.item.externalId.text())
        			}
        			ItemBTDReference(actionCode:'04'){
        				BusinessTransactionDocumentRelationshipRoleCode('6')
        				BusinessSystemID(x_comp_id)
        				FormattedUUID(st.id.text())
        				BTDReference{
        					ID(st.id.text())
        					TypeCode('118')
        					ItemTypeCode('271')
        				}
        			}
        			ItemParty(actionCode:'04'){
        				PartyID(st.createPerson.externalId.text())
        				RoleCode('43')
        				MainIndicator(true)
        			}
        
        		}
        		sr_head.append(st_item)
        	}
        }

        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(root_output)
        message.setBody(stringWriter.toString())
        return message;
}

    private sr_header_and_activity_data(Message message, Node root, boolean new_sc, Node sr_head){
            // sr_head is reference of the ServiceRequest node
            Node var_node
            def contact_partyID = '~ID-JOIN~' + root.fsm_body.data.businessPartner.externalId.text()
            contact_partyID = root.fsm_body.data.contact.'*'.size() > 0 || root.fsm_body.data.updatedProperty.'*'.contains('contact') ? root.fsm_body.data.contact.externalId.text().replaceFirst(contact_partyID,"") : null
            
            def x_comp_id = root.fsm_header."x-company-id".text()
            def use_cat_map = message.getProperty("serv_categ_val_map").toLowerCase()
            def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
        
        	def end_date = Date.parse("yyyy-MM-dd'T'HH:mm:ss'Z'", root.fsm_body.data.earliestStartDateTime.text())
        	end_date = root.fsm_body.data.durationInMinutes.text() == "" ? null : use(groovy.time.TimeCategory){end_date + root.fsm_body.data.durationInMinutes.text().toInteger().minutes}
       
        	if(new_sc == true) {
        		sr_head.append(new NodeBuilder().DataOriginTypeCodeText(root.fsm_body.data.origin.text()))
        	}
        	if(new_sc == true || root.fsm_body.data.updatedProperty.'*'.contains('subject')) {
        		sr_head.append(new NodeBuilder().Name(languageCode:'EN',root.fsm_body.data.subject.text().length()>255 ? root.fsm_body.data.subject.text().trim().substring(0,255) : root.fsm_body.data.subject.text().trim()))
        	}
        	if(new_sc == true) {
        		sr_head.append(new NodeBuilder().ProcessingTypeCodeText(root.fsm_body.data.type.text()))
        	}
        	
        	if(new_sc == true) {
        		sr_head.append(new NodeBuilder().ServiceTerm(actionCode:'04'){
        			PriorityText(root.fsm_body.data.priority.text())
        			ServiceCategoryText(root.fsm_body.data.problemType.text())
        			UserStatusText(root.fsm_body.data.status.text())
        		})
        		sr_head.append(new NodeBuilder().TicketTimeline(actionCode:'04'){
        			RequestedStart(root.fsm_body.data.earliestStartDateTime.text())
        			RequestedEnd(end_date == null ? null : end_date.format("yyyy-MM-dd'T'HH:mm:ss'Z'"))
        			ResolutionDueDate(root.fsm_body.data.dueDateTime.text())
        		})
        	}
        	else {
        		var_node = new NodeBuilder().ServiceTerm(actionCode:'04'){}
        		if(root.fsm_body.data.updatedProperty.'*'.contains('priority')) {
        			var_node.append(new NodeBuilder().PriorityText(root.fsm_body.data.priority.text()))
        		}
        		if(root.fsm_body.data.updatedProperty.'*'.contains('problemTypeCode')) {
        			var_node.append(new NodeBuilder().ServiceCategoryText(root.fsm_body.data.problemType.text()))
        		}
        		if(root.fsm_body.data.updatedProperty.'*'.contains('statusCode')) {
        			var_node.append(new NodeBuilder().UserStatusText(root.fsm_body.data.status.text()))
        		}
        		if(var_node.'*'.size() > 0) {
        			sr_head.append(var_node)
        		}
        
        		var_node = new NodeBuilder().TicketTimeline(actionCode:'04'){}
        		if(root.fsm_body.data.updatedProperty.'*'.contains('startDateTime')) {
        			var_node.append(new NodeBuilder().RequestedStart(root.fsm_body.data.earliestStartDateTime.text()))
        		}
        		if(root.fsm_body.data.updatedProperty.'*'.contains('endDateTime')) {
        			var_node.append(new NodeBuilder().RequestedEnd(end_date == null ? null : end_date.format("yyyy-MM-dd'T'HH:mm:ss'Z'")))
        		}
        		if(root.fsm_body.data.updatedProperty.'*'.contains('dueDateTime')) {
        			var_node.append(new NodeBuilder().ResolutionDueDate(root.fsm_body.data.dueDateTime.text()))
        		}
        		if(var_node.'*'.size() > 0) {
        			sr_head.append(var_node)
        		}
        	}
	        
	        if(new_sc == true || root.fsm_body.data.updatedProperty.'*'.contains('businessPartner')
        	    || root.fsm_body.data.updatedProperty.'*'.contains('contact')) {
        		sr_head.append(new NodeBuilder().Party(ActionCode:'04'){
        			PartyID(root.fsm_body.data.businessPartner.externalId.text())
        			RoleCode('1001')
        			PartyTypeCode('159')
        			MainIndicator(true)
        		})
        		if(contact_partyID != null) {
        			sr_head.Party[0].append(new NodeBuilder().ContactParty(actionCode:'04'){
        				PartyID(contact_partyID)
        				MainIndicator(true)
        			})
        		}
        	}
        	
        	if((new_sc == true || root.fsm_body.data.updatedProperty.'*'.contains('responsibles'))
            	&& !root.fsm_body.data.responsibles[0].externalId.text().equals("")) {
        		sr_head.append(new NodeBuilder().Party(ActionCode:'04'){
        			PartyID(root.fsm_body.data.responsibles[0].externalId.text())
        			RoleCode('40')
        			PartyTypeCode('147')
        			MainIndicator(true)
        		})
        	}
        	
        	// Remarks and Resolution mapping
        	Node text_col = new NodeBuilder().TextCollection(actionCode:'04'){}
        	if((new_sc == true && root.fsm_body.data.remarks.text().length() > 0) ||
	        root.fsm_body.data.updatedProperty.'*'.contains('remarks') ){
        		text_col.append(new NodeBuilder().Text(actionCode:'04'){
        			TypeCode('10004')
        			ContentText(root.fsm_body.data.remarks.text())
        		})
        	}
        	if((new_sc == true && root.fsm_body.data.resolution.text().length() > 0) ||
	        root.fsm_body.data.updatedProperty.'*'.contains('resolution')) {
        		text_col.append(new NodeBuilder().Text(actionCode:'04'){
        			TypeCode('10022')
        			ContentText(root.fsm_body.data.resolution.text())
        		})
        	}
        	if(text_col.'*'.size() > 0) {
        		sr_head.append(text_col)
        	}
        
        	if((new_sc == true || root.fsm_body.data.updatedProperty.'*'.contains('equipments'))) {
        	    root.fsm_body.data.equipments.each{eqp->
        	        if(!eqp.externalId.text().equals("")){
        	            sr_head.append(new NodeBuilder().ServiceReferenceObject(ActionCode: '04'){
        	                InstallationPointID(eqp.externalId.text())
        	            })
        	        }
        	    }
        	}
        	
            if(use_cat_map.equals('true') && (new_sc == true || root.fsm_body.data.updatedProperty.'*'.contains('problemTypeCode'))){
                String cat = valueMapApi.getMappedValue('FSM', 'Problem_Type', root.fsm_body.data.problemType.text(), 'C4C', 'Catalog#Version#CategoryID')
                if(!cat.equals(null)){
                    cat = cat.substring(cat.lastIndexOf('#')+1) //Fetch the Catalog ID from the formation as Catalog#Version#CategoryID
                    sr_head.append(new NodeBuilder().UseValueMappingForCategory(true))
                    sr_head.append(new NodeBuilder().ServiceCategory(ActionCode:'04'){
                        ID(cat)
                    })
                }
            }
            
        	for(sk in root.fsm_body.data.requirements) {
        		if(sk.inherited.text().equals('true') || sk.skill.externalId.text().equals("")) {
        			continue
        		}
        		sr_head.append(new NodeBuilder().TicketSkill(actionCode:'04'){
        			ReceiverSkillID(sk.skill.externalId.text())
        			Mandatory(sk.mandatory.text())
        			SkillSource('07')
        		})
        	}
        	// Activities to Ticket line Item mapping
         if(root.fsm_body.data.activities.'*'.size() > 0) {	
        	for(act in root.fsm_body.data.activities) {
        	    boolean item_sch_typ_1 = false;
        	    
        		if(!act.type.text().equals("ASSIGNMENT")        //Do not repicate FSM Activites which are not of type ASSIGNMENT
        		|| (act.status.text().equals("DRAFT") && act.externalId.text().equals(""))){ //Do not replicate DRAFT status activities to C4C which are not already in C4C
    				continue	
    			}
        		//If new service call or complete data flag true then send all activities data
    			boolean new_act = new_sc == true ? true : false 
    			if(new_act == false
    			&&
    			( (act.status.text().equals("OPEN") && act.externalId.text().equals("")
    			&& act.updatedProperty.'*'.contains("status") )		//Activity created in FSM and released
    			||
    			( (act.status.text().equals("OPEN") || act.status.text().equals("CLOSED"))
    			&& act.externalId.text().equals("") && act.updatedProperty.'*'.size() == 0 ) ) ) { //Activity created in FSM mobile
    				new_act = true
    			}
        
        		Node act_item = new NodeBuilder().Item(actionCode:'04',ItemScheduleLinesCompleteTransmissionIndicator : false,
        		ItemPartyCompleteTransmissionIndicator : false, ItemTextCollectionCompleteTransmissionIndicator : false,itemSkillListCompleteTransmissionIndicator : false){
        			UUID(act.externalId.text())
        			FSMRelevanceCode("1")
        			ItemBTDReference(actionCode:'04'){
        				BusinessTransactionDocumentRelationshipRoleCode('6')
        				BusinessSystemID(x_comp_id)
        				FormattedUUID(act.id.text())
        				BTDReference{
        					ID(act.code.text() == "" ? act.id.text() : act.code.text())
        					TypeCode('118')
        					ItemTypeCode('271')
        				}
        			}
        		}
        		
        		if(new_act == true || act.updatedProperty.'*'.contains('subject')) {
    				act_item.append(new NodeBuilder().Description(act.subject.text().length() > 40 ? act.subject.text().substring(0,40) : act.subject.text()))
    			}
    			if(new_act == true || act.updatedProperty.'*'.contains('status')) {
    				act_item.append(new NodeBuilder().ExecutionLifeCycleStatusCodeText(act.executionStage.text().equals('CANCELLED') ? 'CANCELLED' : act.status.text()))
    			}
    			
    			if(new_act == true) {
    				act_item.append(new NodeBuilder().ItemScheduleLines(actionCode:'04'){
    					TypeCode('1')
    					DateTimePeriod{
    						StartDateTime(timeZoneCode:'UTC',act.earliestStartDateTime.text())
    						EndDateTime(timeZoneCode:'UTC',act.dueDateTime.text())
    					}
    				})
    				// For ItemScheduleLines of TypeCode = 1
    				if(act.durationInMinutes.text() != "" && act.durationInMinutes.text().toInteger() > 0) {
    					act_item.ItemScheduleLines[0].append(new NodeBuilder().Quantity(unitCode: 'MIN',act.durationInMinutes.text()))
    					act_item.ItemScheduleLines[0].append(new NodeBuilder().QuantityTypeCode('TIME'))
    				}
    
    				act_item.append(new NodeBuilder().ItemScheduleLines(actionCode:'04'){
    					TypeCode('4')
    					DateTimePeriod{
    						StartDateTime(timeZoneCode:'UTC',act.plannedStartDate.text())
    						EndDateTime(timeZoneCode:'UTC',act.plannedEndDate.text())
    					}
    				})
    				
    				if(act.status.text().equals("CLOSED")) {
    					act_item.append(new NodeBuilder().ItemScheduleLines(actionCode:'04'){
    						TypeCode('5')
    						DateTimePeriod{
    							StartDateTime(timeZoneCode:'UTC',act.plannedStartDate.text())
    							EndDateTime(timeZoneCode:'UTC',act.plannedEndDate.text())
    						}
    					})
    				}
    				//Workaround for UOM defaulting/copying in C4C
    				act_item.append(new NodeBuilder().ItemProduct(actionCode:'04'){
    					QuantityTypeCode('TIME')
                        QuantityMeasureUnitCode('HUR')
    				})    				
    			}
    			else{
    				var_node = new NodeBuilder().ItemScheduleLines(actionCode:'04'){TypeCode('1')}
    				if(act.updatedProperty.'*'.intersect(['earliestStartDateTime', 'dueDateTime']).size() > 0) {
    					var_node.append(new NodeBuilder().DateTimePeriod{
    						StartDateTime(timeZoneCode:'UTC',act.earliestStartDateTime.text())
    						EndDateTime(timeZoneCode:'UTC',act.dueDateTime.text())
    					})
    				}
    				if(act.updatedProperty.'*'.contains('durationInMinutes') && act.durationInMinutes.text() != ""
    				&& act.durationInMinutes.text().toInteger() > 0) {
    					var_node.append(new NodeBuilder().Quantity(unitCode: 'MIN',act.durationInMinutes.text()))
    					var_node.append(new NodeBuilder().QuantityTypeCode('TIME'))
    				}
    				if(var_node.'*'.size() > 1) { //TypeCode is already default child
    					act_item.append(var_node)
    					item_sch_typ_1 = true //Workaround to cover-up issue of copying UOM at ItemScheduleLines level. Send type 1 data always if ItemScheduleLines is added
    				}
    
    				var_node = new NodeBuilder().ItemScheduleLines(actionCode:'04'){TypeCode('4')}
    				if(act.updatedProperty.'*'.intersect(['plannedStartDate', 'plannedEndDate', 'startDateTime','endDateTime']).size() > 0) {
    					var_node.append(new NodeBuilder().DateTimePeriod{
    						StartDateTime(timeZoneCode:'UTC',act.plannedStartDate.text())
    						EndDateTime(timeZoneCode:'UTC',act.plannedEndDate.text())
    					})
    				}
    				if(var_node.'*'.size() > 1) { //TypeCode is already default child
    					act_item.append(var_node)
    					if(item_sch_typ_1 == false) {
    						act_item.append(new NodeBuilder().ItemScheduleLines(actionCode:'04')
    						{
    							TypeCode('1')
    							DateTimePeriod{
    								StartDateTime(timeZoneCode:'UTC',act.earliestStartDateTime.text())
    								EndDateTime(timeZoneCode:'UTC',act.dueDateTime.text())
    							}
    							if(act.durationInMinutes.text() != "" && act.durationInMinutes.text().toInteger() > 0) {
    								Quantity(unitCode: 'MIN',act.durationInMinutes.text())
    								QuantityTypeCode('TIME')
    							}
    						}
    						)
    					}
    				}
    				
    				// when activity is Closed but not CANCELLED
        			if(act.updatedProperty.'*'.contains('status') &&
        			act.status.text().equals('CLOSED') && !act.executionStage.text().equals('CANCELLED')) {
        				act_item.append(new NodeBuilder().ItemScheduleLines(actionCode:'04'){
        					TypeCode('5')
        					DateTimePeriod{
        						StartDateTime(timeZoneCode:'UTC',act.plannedStartDate.text())
        						EndDateTime(timeZoneCode:'UTC',act.plannedEndDate.text())
        					}
        				})
        				
        				if(item_sch_typ_1 == false) {
    						act_item.append(new NodeBuilder().ItemScheduleLines(actionCode:'04')
    						{
    							TypeCode('1')
    							DateTimePeriod{
    								StartDateTime(timeZoneCode:'UTC',act.earliestStartDateTime.text())
    								EndDateTime(timeZoneCode:'UTC',act.dueDateTime.text())
    							}
    							if(act.durationInMinutes.text() != "" && act.durationInMinutes.text().toInteger() > 0) {
    								Quantity(unitCode: 'MIN',act.durationInMinutes.text())
    								QuantityTypeCode('TIME')
    							}
    						}
    						)
    					}
        			}
    			}
			
        		// To determine that the Activity is created from FSM
        		if(act.externalId.text().equals("")) {
        			act_item.append(new NodeBuilder().TicketItemDeterminationMethodCode("5"))
        		}
        		//Registered Product at Item level
        		if((new_act == true || act.updatedProperty.'*'.contains('equipment')) && act.equipment.externalId.text() != "") {
    				act_item.append(new NodeBuilder().ItemServiceReferenceObjects(ActionCode:'04'){
    					InstallationPointID(act.equipment.externalId.text())
    					MainIndicator(true)
    				})
    			}
                
        		if((new_act == true || act.updatedProperty.'*'.contains('responsibles')) 
    				&& act.responsibles[0]?.externalId?.text()?.length() > 0) {
    				act_item.append(new NodeBuilder().ItemParty(actionCode:'04'){
    					PartyID(act.responsibles[0].externalId.text())
    					RoleCode('43')
    					MainIndicator(true)
    				})
    			}
    			
    			if(act.updatedProperty.'*'.contains('responsibles') && act.responsibles.'*'.size() == 0){
    			    // This would mean responbility unassigned. Un-assign action in FSM.
    			    // To clear Technician data in C4C service item
    				    act_item.append(new NodeBuilder().ItemParty(actionCode:'04'){
    					    PartyID()
    					    RoleCode('43')
    					    MainIndicator(true)
    				    })
    				// To clear Planned start and end dates in C4C service item
    				    act_item.append(new NodeBuilder().ItemScheduleLines(actionCode:'04'){
    					TypeCode('4')
    					DateTimePeriod{
    						StartDateTime()
    						EndDateTime()
    					    }
    				    })
    			}
        
        		if((new_act == true && act.remarks.text().length() > 0) ||
    				act.updatedProperty.'*'.contains('remarks')) {
    				act_item.append(new NodeBuilder().ItemTextCollection(){
    					Text(actionCode:'04'){
    						TypeCode('10011')
    						ContentText(act.remarks.text())
    					}
    				})
    			}
        
        		for(sk in act.requirements) {
        			if(sk.inherited.text().equals('true') || sk.skill.externalId.text().equals("")) {
        				continue
        			}
        			act_item.append(new NodeBuilder().TicketItemSkill(actionCode:'04'){
        				ReceiverSkillID(sk.skill.externalId.text())
        				Mandatory(sk.mandatory.text())
        				SkillSource('07')
        			})
        		}
        		// Append line item to the ServiceRequest node
        		sr_head.append(act_item)
        	}
        }	
    }