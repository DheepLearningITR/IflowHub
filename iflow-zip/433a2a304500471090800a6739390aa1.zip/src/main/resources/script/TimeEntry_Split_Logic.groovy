/*
Time Efforts in FSM can span over 2 days with the restriction being that the todal duration of the one time effort
cannot be more than 24 hours. In C4C, restriction is time effort can not span over more than one day.
Hence in this case here we are splilting such TimeEfforts into two TimeEntry records.
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.SimpleDateFormat
import java.util.TimeZone

def Message processData(Message message) {
    //Body 
       def body = message.getBody(String.class);
       def root = new XmlParser().parseText(body);
       
        SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        
        if(root.fsm_body.eventType.text().equals('activity.confirmed') || root.fsm_body.eventType.text().equals('servicecall.fullsynced')){
        	root.fsm_body.data.activities.each{
        		if(it.eventType.text().equals('activity.confirmed') || root.fsm_body.eventType.text().equals('servicecall.fullsynced')) {
        			it.timeEfforts.each{ 
        			  if(it.approvalStatus.text().equals('APPROVED')) {  
        				Date str_date_time, end_date_time, str_mid, end_mid
        				long diff_1_it, diff_2_var, break_in_min, brk_div_2
        				String str_date, end_date
        				def var
        				def in_tz = TimeZone.getTimeZone(it.startDateTimeTimeZoneId.text())
        				
        				isoFormat.setTimeZone(TimeZone.getTimeZone("UTC")) //Indicates the inbound Timestamps are in UTC
        				//Parse string to Date object 				
        				str_date_time = isoFormat.parse(it.startDateTime.text())
        				end_date_time = isoFormat.parse(it.endDateTime.text())
        
        				//Set Technician TimeZone for formatting				
        				isoFormat.setTimeZone(in_tz);
        				str_date = isoFormat.format(str_date_time).substring(0,10)
        				end_date = isoFormat.format(end_date_time).substring(0,10)
        
        				//Compare Date of start and End in Technician Time zone
        				if( str_date != end_date){
        					var = it.clone()
        					end_mid = isoFormat.parse(str_date + 'T23:59:00Z')
        					str_mid = isoFormat.parse(end_date + 'T00:00:00Z')
        						
        					isoFormat.setTimeZone(TimeZone.getTimeZone("UTC"))
        					it.endDateTime[0].value = isoFormat.format(end_mid)
        					var.startDateTime[0].value = isoFormat.format(str_mid)
        
        					diff_1_it = (end_mid.getTime() - str_date_time.getTime())/(1000*60) //Diff in mins, duration of 1st Time Entry
        					
        					break_in_min = it.breakInMinutes.text().toInteger()
        					if(break_in_min < diff_1_it){
        						var.breakInMinutes[0].value = '-1' //No break time in second Time Entry, To adjust 1 min gap in C4C
        					}
        					else {
        						diff_2_var = (end_date_time.getTime() - str_mid.getTime())/(1000*60) //Diff in mins, duration of second Time Entry
        						if(break_in_min < diff_2_var) {
        							it.breakInMinutes[0].value = 0 //No break time in 1st Time Entry
        							var.breakInMinutes[0].value = break_in_min - 1   //To adjust 1 min gap in C4C
        						}
        						else {
        						    brk_div_2 = Math.floorDiv(break_in_min, 2)
        							if(brk_div_2 < diff_1_it && brk_div_2 < diff_2_var) {
        							    //Divide break time equally in both Time Entries
        								diff_1_it = brk_div_2
        								diff_2_var = break_in_min - diff_1_it
        							}
        							else {
        							    //Entire duration of T1 considered as Break and Remaing break time considered in T2
        							    diff_2_var = break_in_min - diff_1_it
        							}
							        it.breakInMinutes[0].value = diff_1_it
							        var.breakInMinutes[0].value = diff_2_var - 1 //To adjust 1 min gap in C4C
        						}
        					}
        					
        					//Create New TimeEffort node for next day
        					it.parent().append(var)
        				}
        			  }	
        			}			
        		}
        	}
        }
        
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(root)
        message.setBody(stringWriter.toString())
        return message;
}