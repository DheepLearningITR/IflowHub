import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

       ArrayList Attach_IDs = message.getProperty('Attach_IDs');

       message.setProperty("attach_id_fetch", Attach_IDs[0]);
       
       return message;
}