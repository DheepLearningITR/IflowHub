import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlParser;

def Message processData(Message message) {

    def parsedObj = new XmlParser().parseText(message.getBody(String.class));
    ArrayList Attach_IDs = []

    if(parsedObj.fsm_body.eventType.text().equals('activity.confirmed')){
        //Removing attachments from the service call
        parsedObj.fsm_body.data.attachments.each{
    		it.parent().remove(it)
    	}
        
        parsedObj.fsm_body.data.activities.each{
            boolean del_act = true
             // Expense attachment replication
            if(it.eventType.text().equals('activity.confirmed')) {
                it.attachments.each { 
    				it.parent().remove(it) //Remove attachments of the activity as they would have already replicated 
    			}
                it.expenses.each{
                    if(it.approvalStatus.text().equals('APPROVED')) {
                        // Form list of attachment IDs    
                        if(it.attachments[0].id.text().length() > 0){
                            del_act = false
                            it.attachments.each{
                                Attach_IDs.add(it.id.text().trim())
                            }
                        }
                        else{
                            //Remove expense where there are no attachments
                            it.parent().remove(it)
                        }
                    }
                }
            }
            
            if(del_act == true){
                //Remove activities node where there are no T&M approvals or Has Expenses but no attachments
                 it.parent().remove(it)
            }
        }
    }
    else if(parsedObj.fsm_body.eventType.text().equals('servicecall.updated') || parsedObj.fsm_body.eventType.text().equals('servicecall.created')){
        //Removing attachments from the service call
        parsedObj.fsm_body.data.attachments.each{
    		it.parent().remove(it)
    	}
        
        parsedObj.fsm_body.data.activities.each{
    //if one or more activty are set to Released now and has attachments to be replicated
    
    //if activity directly created in OPEN or CLOSED status, can happen from Mobile app, then to replicate their attachements as the original attachement.created
    // event would have ignored since activity externalId is not there.
            if (  ( (it.status.text() == 'OPEN') && (it.executionStage.text() == 'EXECUTION') 
                    && (it.updatedProperty.text().find('executionStage')) && (it.attachments.text().size() > 0) 
                  ) || 
                  ( it.type.text().equals("ASSIGNMENT") && ((it.status.text() == 'OPEN') || (it.status.text() == 'CLOSED' && it.executionStage.text() != 'CANCELLED')) 
                    && (it.externalId.text() == '') && (it.attachments.text().size() > 0) 
                  ) 
                )
            {
                // Form list of attachment IDs 
                    it.attachments.each{
                       Attach_IDs.add(it.id.text().trim())
                    }
            }
            else{
                //Remove activities node where activity is not set to Released now.
                Node parent = it.parent()
                parent.remove(it)
            }
        }
    }
    else if(parsedObj.fsm_body.eventType.text().equals('servicecall.fullsynced')
            && message.getProperty("FullSync_Attachments").toLowerCase().equals("true")){
        
        if(parsedObj.fsm_body.data.attachments.'*'.size() > 0) {
    		parsedObj.fsm_body.data.attachments.each{
    			//Adding attachments of the Service Call
    			Attach_IDs.add(it.id.text().trim())
    		}
    	}
        
        parsedObj.fsm_body.data.activities.each{
            boolean del_act = true
             
            //Ignore activities which are in DRAFT status
            if (it.type.text().equals("ASSIGNMENT") && (it.status.text() == 'OPEN' || (it.status.text() == 'CLOSED' && it.executionStage.text() != 'CANCELLED')) 
                 && it.attachments.text().size() > 0)
            {
                // Form list of attachment IDs 
                    it.attachments.each{
                       Attach_IDs.add(it.id.text().trim())
                    }
                    del_act = false
            }
            //attachments of the expenses associated with the activity
            it.expenses.each{
                if(it.approvalStatus.text().equals('APPROVED')) {
                        // Form list of attachment IDs    
                        if(it.attachments[0].id.text().length() > 0){
                            del_act = false
                            it.attachments.each{
                                Attach_IDs.add(it.id.text().trim())
                            }
                        }
                        else{
                            //Remove expense where there are no attachments
                            it.parent().remove(it)
                        }
                }
            }
            if(del_act == true){
                //Remove activities node where there are no attachments and no (T&M approvals or Has Expenses but no attachments)
                 it.parent().remove(it)
            }
        }
    }
   
    
    if(Attach_IDs.size() > 0){
        // Set in prperty the FSM attachment IDs for which content to be fetched
        message.setProperty("Attach_IDs",Attach_IDs);
        
        //Set in property the modified FSM sent message
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(parsedObj)
        message.setProperty('FSMMessage',stringWriter.toString())
        sleep(10000) // To delay the call of Attachment service in C4C to prevent locking of object
    }
    else{
        message.setProperty("Attach_IDs",'NONE');
    }
    
    return message;
}