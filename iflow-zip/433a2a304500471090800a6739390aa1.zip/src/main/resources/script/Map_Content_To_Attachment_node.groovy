/*
Purpose: Put the attachment content in the FSM message which 
would be used later to map to C4C Attacment service.
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlParser;
import groovy.xml.QName;

def Message processData(Message message) {
 
       ArrayList Attach_IDs = message.getProperty('Attach_IDs');
       def fsm_body = message.getProperty('FSMMessage');
       def parsedObj = new XmlParser().parseText(fsm_body);
    //Attachment content from body   
       def content = message.getBody(String.class); 
    
    outer:{ 

       for(act in parsedObj.fsm_body.data.activities){
        //loop through all activities which were released and had attachments 
           for(attachment in act.attachments){
            // loop through its attachments and set content correspondingly   
                if (attachment.id.text() == Attach_IDs[0]){
                        attachment.appendNode(
                        new QName("content"),
                        [:],
                        content);
                    break outer;    
                }
           }
           
           if(act.expenses.'*'.size()> 0) {
                for(expense in act.expenses){
                    if(expense.approvalStatus.text().equals('APPROVED')) {
                        // Form list of attachment IDs    
                        for(attach in expense.attachments){
                           // loop through its attachments and set content correspondingly   
                           if (attach.id.text() == Attach_IDs[0]){
                                attach.appendNode(
                                new QName("content"),
                                [:],
                                content);
                                break outer; 
                            }
                        }
                    }
                }
            }
       }
       
       if(parsedObj.fsm_body.eventType.text().equals('servicecall.fullsynced')){
           // only in case of full sync check for servicecall attachments
            for(attach in parsedObj.fsm_body.data.attachments){
                if (attach.id.text() == Attach_IDs[0]){
                            attach.appendNode(
                            new QName("content"),
                            [:],
                            content);
                        break outer;    
                }
            } 
       }
    } 
    
    // Below code was in use before Full sync for Attachments was enabled.
    
    //   parsedObj.fsm_body.data.activities.each{
    // //loop through all activities which were released and had attachments  
    //       it.attachments.each{
    //         // loop through its attachments and set content correspondingly   
    //           if (it.id.text() == Attach_IDs[0]){
    //                 it.appendNode(
    //                 new QName("content"),
    //                 [:],
    //                 content);
    //             }
    //       }
           
    //       if(it.eventType.text().equals('activity.confirmed')) {
    //         it.expenses.each{
    //             if(it.approvalStatus.text().equals('APPROVED')) {
    //                 // Form list of attachment IDs    
    //                 it.attachments.each{
    //                   // loop through its attachments and set content correspondingly   
    //                   if (it.id.text() == Attach_IDs[0]){
    //                         it.appendNode(
    //                         new QName("content"),
    //                         [:],
    //                         content);
    //                     }
    //                 }
    //             }
    //         }
    //         }
           
    //   }
        
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(parsedObj)
        
       Attach_IDs.remove(0)
       if(Attach_IDs.size() == 0){
            message.setProperty("Attach_IDs", 'FETCH_DONE');
            message.setBody(stringWriter.toString())
       }
       else{
            message.setProperty("Attach_IDs", Attach_IDs);
            //Set in property the modified FSM message with Content
            message.setProperty('FSMMessage',stringWriter.toString())
       }

       return message;
}