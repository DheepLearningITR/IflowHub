import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def sfsfCompanyId = message.getProperties().get("sfsfCompanyId");
		if(sfsfCompanyId!=null){
			messageLog.addCustomHeaderProperty("sfsf_CompanyId", sfsfCompanyId);		
        }
        def SFTP_Target_Directory = message.getProperties().get("SFTP_Target_Directory");
		if(SFTP_Target_Directory!=null){
			messageLog.addCustomHeaderProperty("sfsf_SFTP_Target_Directory", SFTP_Target_Directory);		
        }
        def TIHFilesFound = message.getProperties().get("TIHFilesFound");
		if(TIHFilesFound!=null){
			messageLog.addCustomHeaderProperty("sfsf_TIHFilesFound", TIHFilesFound.toString());		
        }        
	}
	return message;
}

