import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput;

def Message validate(Message message) {

    def headers = message.getHeaders();
    def properties = message.getProperties();

    def errors = []; // Unified error list

    // Validate HEADERS --------------------
    def mandatoryHeaders = [
        "sfsfCompanyId"
    ]
    
    mandatoryHeaders.each { key ->
        if (!headers[key]?.trim()) {
            errors.add(["errorCode": "[SAP-IS] MISSING_HDR", "errorMessage": key]);
        }
    }    
    
    def sfsfCompanyId = headers.get("sfsfCompanyId");

    // Validate VM CONFIG ---------------------
    if(sfsfCompanyId){
        def configMappings = [
            "SFTP_Address"                          : "cbrInt_SuccessFactors_SFTP:Address",
            "SAP_FtpAuthMethod"                     : "cbrInt_SuccessFactors_SFTP:Authentication",        
            "SFTP_Target_Directory"                 : "cbrInt_SuccessFactors_SFTP_TIH:TargetDirectory",
            "SFTP_Target_FnamePrefix_Attributes"    : "cbrInt_SuccessFactors_SFTP_TIH:TargetFilePrefix_Attributes", 
            "SFTP_Target_FnamePrefix_AttributeTags" : "cbrInt_SuccessFactors_SFTP_TIH:TargetFilePrefix_AttributeTags",
            "SFTP_Target_FnamePrefix_Tags"          : "cbrInt_SuccessFactors_SFTP_TIH:TargetFilePrefix_Tags"
        ];
        
        if(properties["SAP_FtpAuthMethod"]=='user' || properties["SAP_FtpAuthMethod"]=='dual'){
            configMappings.put("SFTP_Credential","cbrInt_SuccessFactors_SFTP:Credential");
        }
        if(properties["SAP_FtpAuthMethod"]=='key'){
            configMappings.put("SFTP_UserName","cbrInt_SuccessFactors_SFTP:UserName");
            configMappings.put("SFTP_PrivateKeyAlias","cbrInt_SuccessFactors_SFTP:PrivateKeyAlias");
        }        
        
        configMappings.each { property, vmconfig ->
            if (!properties[property]?.trim()) {
                errors.add(["errorCode": "[SAP-IS] MISSING_VMCONFIG", "errorMessage": "${vmconfig}"]);
            }
        }
    }

    // If there are any errors, set the error response and return
    if (!errors.isEmpty()) {
        def errorJson = JsonOutput.toJson(["errors": errors]);
        message.setProperty("errorJson", errorJson);
        throw new IllegalArgumentException(errorJson); // Exit with all errors
    }

    return message;
}

def Message checkIfFound(Message message) {
    
    def properties = message.getProperties();
    def fileFound = properties.get("SAP_PollEnrichMessageFound");
    def TIHFilesFound = properties.get("TIHFilesFound");
    def fname = properties.get("SFTP_Fname_Prefix");
    
    Set<String> files = properties.get("files");
    if(files==null){
        files = new HashSet<>();	
    }
    
    if(fileFound==true){
        files.add(fname+'*.csv');
        TIHFilesFound = true;
    }
    
    message.setProperty("files", files);
    message.setProperty("filesJSON", JsonOutput.toJson(files));
    message.setProperty("TIHFilesFound", TIHFilesFound);
    message.setBody(null);
    
    return message;
}