/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
     //Get Body and parse it.
       def body = message.getBody(java.lang.String)as String;
       def error_msg = "error";
       message.getProperties().put("error message","");
       if(body.contains("401")){
           error_msg = "The configured Qualtrics API token is unauthorized to write the response back to Survey. Please make sure the Survey Owner or Survey Collaborator's API token is configured ";
       }else if(body.contains("500")){
           error_msg = "Internal Server Error "+body;
       }else{
           error_msg = body;
       }
            message.getProperties().put("error message",error_msg);
            return message;
       
}