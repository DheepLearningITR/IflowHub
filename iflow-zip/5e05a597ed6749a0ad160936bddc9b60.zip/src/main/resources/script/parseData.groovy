import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def parsedObj = new JsonSlurper().parseText(body);
	
	//Creating Origin Payload Exchange Property for Extension
	JsonBuilder builderA = new JsonBuilder(parsedObj);
	message.setProperty("originPayload",JsonOutput.prettyPrint(builderA.toString()));
	
	def descText = "";
	def datOriginCode = "16";
	
	parsedObj.each {
	 message.getProperties().put(it.getKey(),it.getValue());
	}
	
	parsedObj?.serviceTicket?.ServiceRequestTextCollection.each{
          if(it.TypeCode == '10004'){
              descText = it.Text
          }
      }
      
      if(descText == ""){
          if(parsedObj?.serviceTicket?.ServiceRequestTextCollection){
             parsedObj?.serviceTicket.remove('ServiceRequestTextCollection'); 
          }
      }
      if(parsedObj.event == 'event.TicketCreate'){
        if(parsedObj?.serviceTicket?.Name.length() > 255){
        parsedObj.serviceTicket.Name = parsedObj.serviceTicket.Name.substring(0,255);  
        }
        parsedObj.serviceTicket << [DataOriginTypeCode: datOriginCode];
      }
	parsedObj?.serviceTicket.each{
     message.getProperties().put(it.getKey(),it.getValue());
	}
// 	parsedObj.serviceTicket << [DataOriginTypeCode: datOriginCode];
	JsonBuilder builder = new JsonBuilder(parsedObj.serviceTicket);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
    message.getProperties().put("serviceTicket",jsonBody);
	return message;
}