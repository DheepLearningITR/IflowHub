import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def map = message.getProperties();
	def serviceTicketBody = map.get("serviceTicket");
	def CustomerID = map.get("CustomerID");
	def ContactID  = map.get("ContactID");
	
	def parsedObj = new JsonSlurper().parseText(serviceTicketBody);
	if(CustomerID != ""){
	parsedObj << [BuyerPartyID: CustomerID];
	parsedObj << [BuyerMainContactPartyID: ContactID];
	
	JsonBuilder builder = new JsonBuilder(parsedObj);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
	message.getProperties().put("serviceTicket",jsonBody);
	}
	return message;
}