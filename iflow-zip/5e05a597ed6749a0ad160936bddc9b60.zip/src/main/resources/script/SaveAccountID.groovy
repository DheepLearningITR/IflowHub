import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def parsedObj = new JsonSlurper().parseText(body);
	message.getProperties().put("CustomerID","");
	message.getProperties().put("ContactID","");
	if(!parsedObj.d.results.isEmpty()){
	    parsedObj.d.results.each{
	        message.getProperties().put("CustomerID",it.AccountID);
	        message.getProperties().put("ContactID",it.ContactID);
	    }
	}
	return message;
}