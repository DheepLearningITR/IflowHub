/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {
    //Body
    body = message.getBody(String)
    properties = message.getProperties()

    jsonSlurper = new JsonSlurper()
    lbnRelationship = jsonSlurper.parseText(body)

    submodelInstance = """{
  \"submodels\" : [ {
    \"modelType\" : \"Submodel\",
    \"kind\" : \"Instance\",
    \"semanticId\" : {
      \"keys\" : [ {
        \"type\" : \"ConceptDescription\",
        \"value\" : \"urn:bamm:io.catenax.single_level_bom_as_built:1.0.0#SingleLevelBomAsBuilt\"
      } ],
      \"type\": \"ModelReference\"
    },
    \"id\" : \"urn:""" + properties.bpn + ":" + "SingleLevelBomAsBuilt" + ":" + properties.cxuuid + """\",
    \"idShort\" : \"SingleLevelBomAsBuilt\",
    \"submodelElements\" : [ {
      \"modelType\" : \"Property\",
      \"kind\" : \"Instance\",
      \"semanticId\" : {
        \"keys\" : [ {
          \"type\" : \"ConceptDescription\",
          \"value\" : \"urn:bamm:io.catenax.single_level_bom_as_built:1.0.0#catenaXId\"
        } ],
        \"type\": \"ModelReference\"
      },
      \"value\" : \"""" + lbnRelationship.catenaXId + """\",
      \"displayName\" : [ {
        \"language\" : \"en\",
        \"text\" : \"Catena-X Identifier\"
      } ],
      \"idShort\" : \"catenaXId\",
      \"description\" : [ {
        \"language\" : \"en\",
        \"text\" : \"The Catena-X ID of the given part (e.g. the assembly), valid for the Catena-X dataspace.\"
      } ]
    }, {
      \"modelType\" : \"SubmodelElementCollection\",
      \"displayName\" : [ {
        \"language\" : \"en\",
        \"text\" : \"Child Parts\"
      } ],
      \"idShort\" : \"childParts\",
      \"description\" : [ {
        \"language\" : \"en\",
        \"text\" : \"Set of child parts, of which the given parent object is assembled by (one structural level down).\"
      } ],
      \"value\" : [ """;

    //loop for child parts
    for (int i = 0; i < lbnRelationship.childParts.size(); i++) {
        submodelInstance = submodelInstance + """{
        \"modelType\" : \"SubmodelElementCollection\",
        \"displayName\" : [ {
          \"language\" : \"en\",
          \"text\" : \"Child Data\"
        } ],
        \"idShort\" : \"ChildData\",
        \"description\" : [ {
          \"language\" : \"en\",
          \"text\" : \"Catena-X ID and meta data of the assembled child part.\"
        } ],
        \"value\" : [ {
          \"modelType\" : \"Property\",
          \"kind\" : \"Instance\",
          \"semanticId\" : {
            \"keys\" : [ {
              \"type\" : \"ConceptDescription\",
              \"value\" : \"urn:bamm:io.catenax.single_level_bom_as_built:1.0.0#createdOn\"
            } ],
            \"type\": \"ModelReference\"
          },
          \"value\" : \"""" + lbnRelationship.childParts[i].createdOn + """\",
          \"displayName\" : [ {
            \"language\" : \"en\",
            \"text\" : \"Created On\"
          } ],
          \"idShort\" : \"createdOn\",
          \"description\" : [ {
            \"language\" : \"en\",
            \"text\" : \"Timestamp when the relation between the parent part and the child part was created, e.g. when the serialized child part was assembled into the given part.\"
          } ]
        }, {
          \"modelType\" : \"SubmodelElementCollection\",
          \"idShort\" : \"Quantity\",
          \"description\" : [ {
            \"language\" : \"en\",
            \"text\" : \"Comprises the number of objects and the unit of measurement for the respective child objects\"
          } ],
          \"value\" : [ {
            \"modelType\" : \"Property\",
            \"kind\" : \"Instance\",
            \"semanticId\" : {
              \"keys\" : [ {
                \"type\" : \"ConceptDescription\",
                \"value\" : \"urn:bamm:io.catenax.single_level_bom_as_built:1.0.0#quantityNumber\"
              } ],
              \"type\": \"ModelReference\"
            },
            \"value\" : \"""" + lbnRelationship.childParts[i].quantity.quantityNumber + """\",
            \"displayName\" : [ {
              \"language\" : \"en\",
              \"text\" : \"Quantity Number\"
            } ],
            \"idShort\" : \"quantityNumber\",
            \"description\" : [ {
              \"language\" : \"en\",
              \"text\" : \"The number of objects related to the measurement unit\"
            } ]
          }, {
            \"modelType\" : \"Property\",
            \"kind\" : \"Instance\",
            \"semanticId\" : {
              \"keys\" : [ {
                \"type\" : \"ConceptDescription\",
                \"value\" : \"urn:bamm:io.catenax.single_level_bom_as_built:1.0.0#measurementUnit\"
              } ],
              \"type\": \"ModelReference\"
            },
            \"value\" : \"""" + lbnRelationship.childParts[i].quantity.measurementUnit + """\",
            \"idShort\" : \"measurementUnit\",
            \"description\" : [ {
              \"language\" : \"en\",
              \"text\" : \"Unit of Measurement for the quantity of serialized objects\"
            } ]
          } ]
        }, {
          \"modelType\" : \"Property\",
          \"kind\" : \"Instance\",
          \"semanticId\" : {
            \"keys\" : [ {
              \"type\" : \"ConceptDescription\",
              \"value\" : \"urn:bamm:io.catenax.single_level_bom_as_built:1.0.0#lastModifiedOn\"
            } ],
            \"type\": \"ModelReference\"
          },
          \"value\" : \"""" + lbnRelationship.childParts[i].lastModifiedOn + """\",
          \"displayName\" : [ {
            \"language\" : \"en\",
            \"text\" : \"Last Modified on\"
          } ],
          \"idShort\" : \"lastModifiedOn\",
          \"description\" : [ {
            \"language\" : \"en\",
            \"text\" : \"Timestamp when the assembly relationship between parent part and child part was last modified.\"
          } ]
        }, {
          \"modelType\" : \"Property\",
          \"kind\" : \"Instance\",
          \"semanticId\" : {
            \"keys\" : [ {
              \"type\" : \"ConceptDescription\",
              \"value\" : \"urn:bamm:io.catenax.single_level_bom_as_built:1.0.0#lifecycleContext\"
            } ],
            \"type\": \"ModelReference\"
          },
          \"value\" : \"""" + lbnRelationship.childParts[i].lifecycleContext + """\",
          \"displayName\" : [ {
            \"language\" : \"en\",
            \"text\" : \"Lifecycle Context\"
          } ],
          \"idShort\" : \"lifecycleContext\",
          \"description\" : [ {
            \"language\" : \"en\",
            \"text\" : \"The lifecycle context in which the child part was assembled into the parent part.\"
          } ]
        }, {
          \"modelType\" : \"Property\",
          \"kind\" : \"Instance\",
          \"semanticId\" : {
            \"keys\" : [ {
              \"type\" : \"ConceptDescription\",
              \"value\" : \"urn:bamm:io.catenax.single_level_bom_as_built:1.0.0#childCatenaXId\"
            } ],
            \"type\": \"ModelReference\"
          },
          \"value\" : \"""" + lbnRelationship.childParts[i].childCatenaXId + """\",
          \"displayName\" : [ {
              \"language\" : \"en\",
              \"text\" : \"Catena-X Identifier of the Child\"
          } ],
          \"idShort\" : \"childCatenaXId\",
          \"description\" : [ {
            \"language\" : \"en\",
            \"text\" : \"The Catena-X ID of the child object which is assembled into the given parent part.\"
          } ]
        } ]
      }"""
        if (lbnRelationship.childParts.size() > (i + 1)) {
            submodelInstance = submodelInstance + ','
        }
    }
    //end loop child parts
    submodelInstance = submodelInstance + """ ]
    } ],
    \"description\" : [ {
      \"language\" : \"en\",
      \"text\" : \"The aspect provides the child parts (one structural level down) which the given object assembles.\"
    } ]
  } ]
}"""

    message.setBody(submodelInstance)
    return message
}