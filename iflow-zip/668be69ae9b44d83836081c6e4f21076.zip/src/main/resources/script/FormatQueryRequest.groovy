import com.sap.it.api.mapping.Output

def void ReadValues(String[] ID, Output materialNumber, Output serialNumber, Output register, Output meterReadingDocType, Output limit, Output language, Output period) {
    // Join the values of the ID array using the '&' delimiter
    def header = ID.join('&')

    // Remove the '$filter=%2522' part from the header
    header = header.replace('$filter=', '')

    // Split the string by ampersand (&) to get individual key-value pairs
    def pairs = header.split('%2520and%2520')

    // Iterate through each key-value pair
    pairs.each { pair ->
        // Split the pair by equals sign (=) to get the variable name and value
         
        def parts = pair.split('%2520eq%2520')
        def varName = parts[0]
        def varValue = parts[1]

        // Assign the variable value to respective field names
        switch (varName) {
            case 'materialNumber':
                materialNumber.addValue(varValue)
                break
            case 'serialNumber':
                serialNumber.addValue(varValue)
                break
            case 'register':
                register.addValue(varValue)
                break
            case 'meterReadingDocType':
                meterReadingDocType.addValue(varValue)
                break
            case 'limit':
                limit.addValue(varValue)
                break
            case 'language':
                language.addValue(varValue)
                break
            case 'period':
                period.addValue(varValue)
                break
            default:
                // Handle unrecognized variable names if needed
                break
        }
    }
}
