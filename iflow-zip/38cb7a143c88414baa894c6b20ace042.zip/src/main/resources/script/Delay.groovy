import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
def Message processData(Message message) {
    sleep(5000) // 5 sec delay
    return message
}
