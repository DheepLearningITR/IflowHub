package script
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def body = message.getBody(String.class)
    def payLoad = message.getProperty("originalPayload")

    def xmlParser = new XmlParser()
    def xmlResult = xmlParser.parseText(body)

    def jsonParser = new JsonSlurper()
    def jsonResult = jsonParser.parseText(payLoad)

    def isUnplannedCase = "false";
    
    def materialFSMList = jsonResult.data.serviceCall.activity.materials as List
    if ( !materialFSMList.is(null) && materialFSMList.size() > 0) {
        materialFSMList = materialFSMList.grep{
            it -> it.reservedMaterials.size() == 0
        }.collect{
            it -> it.item.externalId
        }
    }

    def mileageFSMProduct = message.getProperty("mileageFSMProduct")
    def expenseFSMList = message.getProperty("expenseFSMList")
    
    def productS4PlannedList = xmlResult.A_ServiceOrderItemType.Product.collect{ item -> item.text()} as List
    if ( expenseFSMList != "" && !productS4PlannedList.containsAll(expenseFSMList.split(',')) ){
        isUnplannedCase = "true"
    } else if ( materialFSMList.size() > 0 && !productS4PlannedList.containsAll(materialFSMList) ) {
        isUnplannedCase = "true"
    } else if ( mileageFSMProduct != "" && !productS4PlannedList.containsAll(mileageFSMProduct) ) {
        isUnplannedCase = "true"
    }
    
    message.setProperty("isUnplannedCase",isUnplannedCase)
    message.setBody(payLoad)
    return message
}
