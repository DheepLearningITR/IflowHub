import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def map = message.getHeaders()
    
    def http_status = map.get("CamelHttpResponseCode");
    
    //HTTP 423 is sent to Sender to indicate Locking Error, else HTTP 500 is sent
    if (http_status != 423) {
        message.setHeader("CamelHttpResponseCode", 500)
    } 
    
    return message
}
