// =============================================================================================
// This flow step is responsible for subsituting some of the content in UN/EDIFACT 
// or ASC X12 interchange payloads so that this conctent will be sufficiently processed by 
// the subsequent flow steps.
//
// History: 
// 2024-02-27 SAP [MÖ] - Removal of Replace Escape characters ?' so that EDI Splitter does not count these segments 
// 2024-02-07 SAP [MÖ] - Removed reg expression for IMD segment
// 2024-02-01 SAP [MÖ] - Replace Escape characters ?' so that EDI Splitter does not count these segments 
// 2024-18-01 SAP [TO] - added line 29 "UNB\\+UNOC:1"
// 2024-01-11 SAP [MÖ] - Commented line 27 - UNOD supported with workaround
// 2023-12-28 SAP [MÖ] - Split script from Step1b Flow
// 2023-12-14 SAP [PS] - 1. Substitute comma with dot: , -> . 2. Add release character for dot: . -> ?. 3. remove release character for comma: ?, -> ,
// 2023-11-20 SAP [AG] - EDIFACT message with IMD Segment has item description in payload more than field length of 35 chars. Additional data truncated
// 2023-08-24 SAP [GS] - Subsitute codepage UNOY to UNOC
// 2023-06-01 SAP [GS] - Set sender/receiver id qualifiers ZZ to ZZZ
// 2023-01-01 SAP [GS] - Initially created
// 2023-11-02 SAP [AH] - UNB:1 segment changed to UNOC:3
// =============================================================================================

import com.sap.gateway.ip.core.customdev.util.Message;
import org.apache.commons.lang.StringEscapeUtils;
import java.util.HashMap;
import java.util.regex.Pattern;
def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String) as String;

        body = body.replaceFirst("UNB\\+UNOC:2", "UNB+UNOC:3");
        //body = body.replaceFirst("UNB\\+UNOY:3", "UNB+UNOC:3");
        //body = body.replaceFirst("UNB\\+UNOD:2", "UNB+UNOC:3");
        body = body.replaceFirst("UNB\\+UNOA:1", "UNB+UNOC:3");
        body = body.replaceFirst("UNB\\+UNOC:1", "UNB+UNOC:3");
        
        
        //START: 2023-11-02 SAP [AH] - UNB:1 segment changed to UNOC:3
        // body = body.replaceFirst("UNB\\+UNOB:1", "UNB+UNOB:3");
        body = body.replaceFirst("UNB\\+UNOB:1", "UNB+UNOC:3");
        //body = body.replaceFirst("UNB\\+UNOD:2", "UNB+UNOC:3");
        //END: 2023-11-02 SAP [AH] - UNB:1 segment changed to UNOC:3
        
        body = body.replaceFirst(/(UNB.*):ZZ\+(.*):ZZ\+(.*'UNH)/, '$1:ZZZ+$2:ZZZ+$3');
        body = body.replaceFirst(/(UNB.*):ZZ\+(.*'UNH)/, '$1:ZZZ+$2');
        body = body.replaceAll(/([UNB]*):ZZ\+/, '$1:ZZZ+')
       
        // /Remove unwanted new lines
        def body_temp = body.replace("\n", "");
        def compsiteSeparator, dataElementSeparator, decimalSeparator, releaseCharacter, repet, segmentSeparator;
       
        try {
          // read meta from message which should work if UNA segment present
          (_, compsiteSeparator, dataElementSeparator, decimalSeparator, releaseCharacter, repet, segmentSeparator) = (body_temp =~ (/UNA([^A-Z])([^A-Z])([^A-Z])([^A-Z])([^A-Z])?([^A-Z])/))[0]
        } catch (Exception e) {
          // when reading from UNA fails, assume default meta
          (_, compsiteSeparator, dataElementSeparator, decimalSeparator, releaseCharacter, repet, segmentSeparator) = ["", ":", "+", ".", "?", "", "'"];  
        }
        
        def originalReleaseCharacter = releaseCharacter;
        
        // Construct regex
        segmentSeparator = "\\" + segmentSeparator; 			    // '
        releaseCharacter = "\\" + releaseCharacter; 			    // ?
        compsiteSeparator = "\\" + compsiteSeparator; 			    // :
        dataElementSeparator = "\\" + dataElementSeparator; 		// +

        any_separator = dataElementSeparator + compsiteSeparator + segmentSeparator;
        
        //07.02. commented as not needed anymore
        //imd_segment = "([^A-Z]?IMD" + dataElementSeparator + ".*?" + dataElementSeparator + "(?>(?>(?<=" + releaseCharacter + ")[" + any_separator + "]|[^" + any_separator + "])*" + compsiteSeparator + "){3})((?>(?<=" + releaseCharacter + ")[" + any_separator + "]|[^" + any_separator + "]){35})(?>(?<=" + releaseCharacter + ")[" + any_separator + "]|[^" + any_separator + "])+([" + dataElementSeparator + "" + compsiteSeparator + "].*)?(" + segmentSeparator + ")";
        
       // def pattern_imd = Pattern.compile(imd_segment)
        //body = body.replaceAll(pattern_imd, { all, match1, match2, match3, match4 ->  match1 + match2 +( match3==null?"":match3) + match4 })
        
        def expectedDecimalSeparator = ".";
        if (decimalSeparator != expectedDecimalSeparator) {
            expectedDecimalNotation = ".";
            // escape the existing dots
            dp0 = Pattern.compile("\\" + expectedDecimalSeparator)
            body = body.replaceAll(dp0, originalReleaseCharacter+expectedDecimalSeparator)

            // change all unescaped decimal points to dots
            dp1 = Pattern.compile("(?<=[^"+ releaseCharacter + "])\\" + decimalSeparator)
            body = body.replaceAll(dp1, expectedDecimalSeparator)

            // unescape the old decimal point
            dp2 = Pattern.compile(releaseCharacter + "\\" + decimalSeparator)
            body = body.replaceAll(dp2, decimalSeparator)
        }
    //escape ?' 
    //body= body.replaceAll(releaseCharacter+segmentSeparator,"-");
    message.setBody(body);
    
    return message;
}