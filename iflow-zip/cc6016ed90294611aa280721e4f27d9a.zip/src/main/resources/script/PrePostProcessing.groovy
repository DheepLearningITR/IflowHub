import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processXmlInput(Message message) {

  def body = message.getBody(java.io.Reader)
  def xml = new XmlParser().parse(body)

  //find tags with null value
  def results = xml.
  '**'.findAll {
    !it.value()
  }

  results.each {
    def newNode = new Node(null, it.name(), 'xsi.nil')
    // replace node    
    it.replaceNode(newNode)
  }
  // write to body
  StringWriter stringWriter = new StringWriter()
  XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
  nodePrinter.setPreserveWhitespace(true)
  nodePrinter.print xml

  message.setBody(stringWriter.toString())
  return message;

}

def Message enrichJsonOutput(Message message) {
  //Body 
  def body = message.getBody(java.io.Reader);

  JsonSlurper slurper = new JsonSlurper()
  Map parsedJson = slurper.parse(body)

  parsedJson.messageRequests.each {

 it.body.nameAndAddress.each {
     if (it.isPostOfficeBoxWithoutId) {
         it.isPostOfficeBoxWithoutId = Boolean.parseBoolean(it.isPostOfficeBoxWithoutId)
     }
 }
 
 it.body.web.each {
    if (it.isDefault) {
      it.isDefault = Boolean.parseBoolean(it.isDefault)
    }
}

 it.body.email.each {
    if (it.isDefault) {
      it.isDefault = Boolean.parseBoolean(it.isDefault)
    }
}

 it.body.facsimile.each {
    if (it.isDefault) {
      it.isDefault = Boolean.parseBoolean(it.isDefault)
    }
}
 //messageRequests/0/body/telephone/0/isUsageDenied
 it.body.telephone.each {
    if (it.isDefaultMobile) {
      it.isDefaultMobile = Boolean.parseBoolean(it.isDefaultMobile)
    }
    if (it.isDefaultLandline) {
      it.isDefaultLandline = Boolean.parseBoolean(it.isDefaultLandline)
    }
}
  }


 def openAPISchemaStream = this.getClass().getResourceAsStream("/src/main/resources/json/customerAddressERPReplicationIn.json")
 def iDOCReplicationHelper = message.getProperty('iDOCReplicationHelper')
 
   try {

    def schema = new JsonSlurper().parse(openAPISchemaStream)
      .components.schemas.CustomerAddressReplicationIncreaterequest.properties.messageRequests.items.properties.body

    parsedJson.messageRequests.each {
      request ->
        iDOCReplicationHelper.setMissingAttributesToNull(request.body, schema)
    }

    def modifiedJson = JsonOutput.toJson(parsedJson)
    message.setBody(modifiedJson)

  } finally {
    if (openAPISchemaStream != null) {
      openAPISchemaStream.close()
    }
  }
  
  def respbody = JsonOutput.toJson(parsedJson)
  // handle xml nil 
  def body2 = respbody.replace('"xsi.nil"', 'null')
  message.setBody(body2)
  
  return message;
}