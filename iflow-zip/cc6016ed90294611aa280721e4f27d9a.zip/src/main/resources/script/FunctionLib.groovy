import com.sap.it.api.mapping.*;

def String getIntValue(String value){
	return Integer.parseInt(value)
}

def String generateUUID(String value){
	return UUID.randomUUID().toString()
}

def String generateMessageHeaderUUID(String value, MappingContext context){
    def messageId = UUID.randomUUID().toString()
    context.setProperty ("p_msg_header_id", messageId)
	return messageId
}