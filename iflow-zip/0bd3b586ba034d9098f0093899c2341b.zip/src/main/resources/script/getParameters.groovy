
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();

       //Headers 
       def map = message.getHeaders();
       def value = map.get("CamelHttpQuery");

       String[] str;
       String[] val;
       String companyCode;
       String costCenter;
       
       str = value.split('&');
       
       for(String s in str) { 
         if(s.matches("CompanyCode(.*)"))
         {
            val = s.split('=');    
            companyCode = val[1];
         }
         
         if(s.matches("CostCenter(.*)"))
         {
            val = s.split('=');    
            costCenter = val[1];
         }
         
       } 
       


       //Properties 
       map = message.getProperties();
       message.setProperty("companyCode", companyCode);
       message.setProperty("costCenter", costCenter);
       return message;
}