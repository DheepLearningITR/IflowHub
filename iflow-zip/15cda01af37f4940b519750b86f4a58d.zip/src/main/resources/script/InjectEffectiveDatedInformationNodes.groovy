import com.sap.it.api.mapping.*;
import groovy.xml.XmlUtil;

def void injectEffectiveDatedInformationNodes(String[] jobs, String[] person, Output output, MappingContext context) {
  def personXml = new XmlParser().parseText(person[0]);
  context.setProperty(XmlUtil.serialize(personXml));
  output.addValue("hi");
  /**
  def personXml = new XmlParser().parseText(person[0]);
  for (int i = 0; i < jobs.length; i++) {
    def job = job[i];
    for (def snapshot : personXml.snapshot) {
      for (def employmentInfo : snapshot.employment_information) {
        if (job == employmentInfo.user_id.text()) {
          output.addValue(snapshot);
        }
      }
    }
  }
  **/
}