import com.sap.it.api.mapping.*;

def String determineCorrectTimezone(String derivedTimezone, String sourceTimezone) {
    if (derivedTimezone != "failed") {
	    return derivedTimezone;
    }
    return sourceTimezone;
}