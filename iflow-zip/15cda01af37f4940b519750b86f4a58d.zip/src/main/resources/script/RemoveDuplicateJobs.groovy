import com.sap.it.api.mapping.*;

def void removeDuplicateJobs(String[] jobs, Output output) {
  def uniqueJobs = new HashSet<>();
  for (int i = 0; i < jobs.length; i++) {
    uniqueJobs.add(jobs[i]);
  }
  for (def uniqueJob : uniqueJobs) {
    output.addValue(uniqueJob);
  }
}