import com.sap.gateway.ip.core.customdev.util.Message;
import java.net.URL;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneOffset;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import groovy.json.JsonBuilder;
import java.util.Base64;

Message processData(Message message) {
  String eventDescription = "This is a test info message";
  sendEMEvent(message, eventDescription, "SUMMARY_SO_FAR");
  return message;
}

private void sendEMEvent(Message message, String eventDescription, String eventType) {
    def properties = message.getProperties();
    def credentialService = ITApiFactory.getApi(SecureStoreService.class, null);
    def credentials = credentialService.getUserCredential(properties.get("sf_credential_name"));
    def url = new URL(properties.get("sf_api_url") + "/odata/v2/EMEvent");
    def connection = (HttpURLConnection) url.openConnection();
    def emEventBody = buildEmEventBody(message, eventDescription, eventType);
    connection.setRequestMethod("POST");
    def username = credentials.getUsername();
    def password = credentials.getPassword().toString();
    def userCredentials = username + "@" + properties.get("company_id") + ":" + password;
    def basicAuthorization = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
    connection.setRequestProperty("Authorization", basicAuthorization);
    connection.setRequestProperty("Content-Type", "application/json");
    connection.setRequestProperty("Accept", "application/json");
    connection.setDoOutput(true);
    def outputStream = connection.getOutputStream();
    def outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
    outputStreamWriter.write(emEventBody);
    outputStreamWriter.flush();
    outputStreamWriter.close();
    outputStream.close();
}

private buildEmEventBody(Message message, String eventDescription, String eventType) {
    def properties = message.getProperties();
    def sapMessageProcessingLogId = properties.get("SAP_MessageProcessingLogID");
    def json = new JsonBuilder();
    def formattedNow = "/Date(" + Instant.now().toEpochMilli() + "+0000)/";
    def process = json processDefinitionId: "Packaged Integration SF EC to WFS", processInstanceId: sapMessageProcessingLogId, processType: "INTEGRATION", processDefinitionName: "Packaged Integration SF EC to WFS", processInstanceName: "Packaged Integration SF EC to WFS_" + sapMessageProcessingLogId;
    def root = json eventName: "An " + eventType.toLowerCase() + " occurred during the execution of the Integration process", eventType: eventType.toUpperCase(), eventDescription: eventDescription, eventTime: formattedNow, process: process;
    return json;
}