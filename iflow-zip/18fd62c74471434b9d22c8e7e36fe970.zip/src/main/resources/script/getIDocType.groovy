// =============================================================================================
// This groovy script is responsible to identify the IDocType as well as the CIMTYP
//
// History:
//2025-01-17 SAP [MÖ] - Optimized to write unique entry to DS 
//2024-10-25 SAP [MÖ] - Initially created
// =============================================================================================
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message){
    
    String body = message.getBody(String);
    String[] lines = body.tokenize("\n");
    
    Map<String, Object> props = message.getProperties();
    String sapRelease = props.get("SAP_RFC_SAPRelease") as String;
    String APPREL = props.get("SAP_RFC_APPRelease") as String;
    def cimType = "";
    docNumber   = lines[0].substring(13, 29).trim();
    senderPrn   = lines[0].substring(162, 172).trim();
    receiverPrn = lines[0].substring(277, 287).trim();
    idocType    = lines[0].substring(39, 69).trim();
    cimType     = lines[0].substring(69, 99).trim();
    
    message.setProperty("SAP_DS_DOCNUM", docNumber);
    message.setProperty("SAP_DS_SNDPRN", senderPrn);
    message.setProperty("SAP_DS_RCVPRN", receiverPrn);
    message.setProperty("SAP_RFC_IDOCTYP", idocType);
    message.setProperty("SAP_RFC_CIMTYP", cimType);
    
    String SAP_RFC_DataStoreKey = idocType;
    SAP_RFC_DataStoreKey = cimType == "" ? SAP_RFC_DataStoreKey : SAP_RFC_DataStoreKey + "_" + cimType;
    SAP_RFC_DataStoreKey = sapRelease == "" ? SAP_RFC_DataStoreKey : SAP_RFC_DataStoreKey + "_" + sapRelease;
    SAP_RFC_DataStoreKey = APPREL == "" ? SAP_RFC_DataStoreKey : SAP_RFC_DataStoreKey + "_" + APPREL;
    
    if (cimType !=null) {
        SAP_DS_Entry = senderPrn + "_" + receiverPrn + "_" + docNumber + "_" + idocType
    }
    else 
    SAP_DS_Entry = senderPrn + "_" + receiverPrn + "_" + docNumber + "_" + idocType + "_" +cimType
    message.setHeader("SAP_DS_DataStoreKey", SAP_DS_Entry );
    
    message.setProperty("SAP_RFC_DataStoreKey", SAP_RFC_DataStoreKey );

    return message;
}