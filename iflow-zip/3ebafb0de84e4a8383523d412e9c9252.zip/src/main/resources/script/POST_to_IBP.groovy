/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.HashMap;
import java.util.UUID; 
import java.util.Iterator; 
import java.util.List; 
import java.lang.Thread;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;
import groovy.xml.XmlUtil;


import java.util.Base64; 
import org.json.JSONObject; 
import org.json.JSONArray;
import org.json.JSONException;
import javax.ws.rs.core.MediaType; 
 
import org.apache.camel.*;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.json.JsonGenerator

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream; 
import java.net.HttpURLConnection;
import java.net.URL;
 
 
//import groovyx.net.http.RESTClient;
//import static groovyx.net.http.ContentType.JSON;

// @Grab (group = 'org.codehaus.groovy.modules.http-builder', module = 'http-builder', version = '0.5.0')

def String fetchToken(Message message) {
    
     //Read the User Name and password 
    def IBPUserEncoded = null;
    def headerMap = message.getHeaders();
    
    try{
        IBPUserEncoded = getCredentials(headerMap.get('IBPCredentials') as String);
    } catch (Exception e) {
        message.setProperty("stepStatus", "error");
        message.setProperty("errorMessage", "Error getting user credentials - "); 
        message.setProperty("errorException", e);  
        return message;
    }
    
    def getRequest = new URL(message.getProperty("IBPTransactionURL")).openConnection() as HttpURLConnection; 
	getRequest.setRequestMethod("GET");
	getRequest.setRequestProperty("User-Agent", "SAP CPI");
	getRequest.setRequestProperty("x-csrf-token", "fetch");
	getRequest.setRequestProperty('Authorization','Basic ' + IBPUserEncoded);
	getRequest.connect(); 
	
    def status = getRequest.getResponseCode(); 
    String token = "init";
    def cookies = getRequest.getHeaderFields().get("set-cookie") as List<String>;
    
	if (status == HttpURLConnection.HTTP_OK) {
        token = getRequest.getHeaderField("x-csrf-token");
    }
    
    message.setProperty("IBPToken", token);
    
    message.setProperty("IBPCookie", cookies);
    
    return token;
		 
}


def String getCredentials(String aliasName) throws Exception{
   try{
       //Get the Service Instance of the SecureStoreService API 
    def service = ITApiFactory.getService(SecureStoreService.class, null);
    //Read the credential of a given alias
    def credential = service.getUserCredential(aliasName);
    //Read the User Name and password
    def IBPUser = credential.getUsername() + ':' + credential.getPassword();
    // Encode to base 64
    def IBPUserEncoded = IBPUser.bytes.encodeBase64().toString();
    
    return IBPUserEncoded;
   } catch (Exception e) {
       throw new Exception(e);
   }
} 

 /*

def Message directUsingRESTClient(Message message){
     fetchToken(message);
    
    
    // def body = message.getBody(java.lang.String) as String;
    def headerMap = message.getHeaders();
    def propertiesMap = message.getProperties();
        
    String nav = "Nav" + headerMap.get("IBPPlanningArea");  
        
    def commit = headerMap.get("IBPCommit") as Boolean;
        
    def mp = ['Transactionid' : headerMap.get("IBPTransactionID"), 'DoCommit': (commit), 'AggregationLevelFieldsString': headerMap.get("IBPFieldsString"), (nav) : propertiesMap.get("IBPOdataPayload")];   
        
            
    def ibp_Payload = new JSONObject(mp);
   
    long len = ibp_Payload.toString().getBytes().length;
        
    message.setHeader("Content-Type", "application/json");
    message.setHeader("Accept", "application/json");
    
    message.setProperty("IBPOdataPayload", ibp_Payload);
    	
    String payloadSize = len.toString(); 
    
    try{
        def client = new RESTClient(headerMap.get("IBPDestination") as String)
	
    	def cookies = propertiesMap.get("IBPCookie");
    	def toCookie = "";
    	
    	for (String cookie : cookies) {
            toCookie += cookie.split(";", 2)[0];
        }
        
        def IBPUserEncoded = getCredentials(headerMap.get('IBPCredentials') as String);
        
        def postHeaders = [:]
            postHeaders."Accept" = 'application/json'
            postHeaders."User-Agent" = 'SAP CI'
            postHeaders."x-csrf-token" = propertiesMap.get("IBPToken")
            postHeaders."Cookie" = toCookie
            postHeaders."Authorization" = 'Basic ' + IBPUserEncoded

        
    	def response = client.post(path: "/" + headerMap.get("IBPPlanningArea") + "Trans",
                          contentType: JSON,
                          body: ibp_Payload,
                          headers: postHeaders)
                              
                              
         message.setBody(response.data)
    } catch (Exception e) {
	    message.setBody(e.toString());
	} 
	
     return message;
}
 */

def Message preparePlanningDataDIRECT(Message message) {
        
    fetchToken(message);
    
    
    // def body = message.getBody(java.lang.String) as String;
    def headerMap = message.getHeaders();
    def propertiesMap = message.getProperties();
        
    String nav = "Nav" + headerMap.get("IBPPlanningArea");  
        
    def commit = headerMap.get("IBPCommit") as Boolean;
        
    def mp = ['Transactionid' : headerMap.get("IBPTransactionID"), 'DoCommit': (commit), 'AggregationLevelFieldsString': headerMap.get("IBPFieldsString"), (nav) : propertiesMap.get("IBPOdataPayload")];   
        
            
    def ibp_Payload = new JSONObject(mp).toString();
    
    long len = ibp_Payload.getBytes().length;
    
    //def ibp_Payload = new JSONObject(mp);
    //long len = ibp_Payload.toString().getBytes().length;
        
    message.setHeader("Content-Type", "application/json");
    message.setHeader("Accept", "application/json");
    
    message.setProperty("IBPOdataPayload", ibp_Payload);
    	
    String payloadSize = len.toString(); 
	 
    def messageLog = messageLogFactory.getMessageLog(message);

    // Request
    def postRequest = new URL(message.getProperty("IBPWriteURL")).openConnection() as HttpURLConnection;

    postRequest.setRequestMethod('POST'); 
    postRequest.setRequestProperty("Accept", 'application/json');
    postRequest.setRequestProperty("Content-Type", 'application/json');
	postRequest.setRequestProperty("User-Agent", "SAP CPI");
    postRequest.setRequestProperty("Content-Length", payloadSize);
    postRequest.setRequestProperty("x-csrf-token", message.getProperty("IBPToken"));
    
    def cookies = message.getProperty("IBPCookie");
    
    for (String cookie : cookies) {
        postRequest.addRequestProperty("Cookie", cookie.split(";", 2)[0]);
    }
    
    def IBPUserEncoded = getCredentials(headerMap.get('IBPCredentials') as String);
    postRequest.setRequestProperty('Authorization','Basic ' + IBPUserEncoded);
    
    //def jsonObj = new JsonSlurper().parseText(ibp_Payload);
    
    String msg;
    postRequest.setDoOutput(true);
    
    // def output = JsonOutput.toJson(mp);
    
    def output = new JsonGenerator.Options()
                .disableUnicodeEscaping()
                .build()
                .toJson(mp)
    
	OutputStream os = postRequest.getOutputStream();
	
	os.write(JsonOutput.prettyPrint(output.toJson().toString()).getBytes("UTF8"));
	
//output = output.replaceAll("(?:\\n|\\r)", "");
	//os.write(output.getBytes());
	
	os.flush();
	os.close();
	int responseCode = postRequest.getResponseCode();
	def inputStr = " - ";
	try{
	    inputStr = postRequest.getInputStream() as InputStream;
        // String encoding = postRequest.getContentEncoding() == null ? "UTF-8" : postRequest.getContentEncoding();
    
        // String inputLine = new String(inputStr.readAllBytes(), encoding); 
        String inputLine = read(inputStr);
        
    	if (responseCode == 200) {  
    	    msg = "POST request WORKED - " + responseCode + " \n " + inputLine; 
    	} else {
    	    msg = "POST request did not work - " + responseCode + " \n " + inputLine; 
    	} 
	    
	} catch (Exception e) {
	    msg = msg + e.toString();
	}  
     
    message.setBody(msg); 
    return message;
}


def String read(InputStream inputStream) throws IOException {
    def result = new StringBuilder() as StringBuilder;
    
    while (inputStream.available() > 0) {
        result.append(inputStream.read() as char);
    } 
    return result.toString();
}