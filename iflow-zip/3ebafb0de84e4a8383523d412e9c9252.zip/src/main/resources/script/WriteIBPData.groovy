/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
 
 import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.HashMap;
import java.util.UUID; 
import java.util.Iterator; 
import java.util.List; 
import java.lang.Thread;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;
import groovy.xml.XmlUtil; 

import java.util.Base64; 
import org.json.JSONObject; 
import org.json.JSONArray;
import org.json.JSONException;
import javax.ws.rs.core.MediaType;

import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

import groovy.xml.*;
 

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher
import java.util.regex.Pattern


 
import org.apache.camel.*;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream; 
import java.net.HttpURLConnection;
import java.net.URL;

def String genUUID(){ 
 
   return UUID.randomUUID().toString().replace("-", "").toUpperCase(); 

}



def String getTimeStamp(){
   //"yyyy-MM-dd'T'HH:mm:ss.SSSZ"
   return new Date().format("yyyy-MM-dd'T'HH:mm:ss",TimeZone.getTimeZone('GMT+2'))
}

def Message addSomeDelay(Message message){
    int delayTime = 10; // 10 seconds before the next call
    Thread.sleep(delayTime * 1000);
    return message;
}

def Message handleRequestToWrite(Message message) {
    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body); 
    def queryString="" as String;
     
    // IBP Instance of the Supplier
    // in the format e.g. https://myXXXXXX-api.scmibp1.ondemand.com/sap/opu/odata/IBP/PLANNING_DATA_API_SRV/<<NAME of PLAN AREA>>
    if (input.IBPDestination == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPDestination", input.IBPDestination);
    }
    
    // Credentials used for the IBP instance
    if (input.IBPCredentials == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPCredentials", input.IBPCredentials);
    }
    
    // Planning area used in the IBP instance
    if (input.IBPPlanningArea == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPPlanningArea", input.IBPPlanningArea);
    }
    
    // Field strings for the Write API
    if (input.IBPFieldsString == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPFieldsString", input.IBPFieldsString);
    }
    
    // Data to be written
    if (input.Value == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setProperty("IBPOdataPayload", input.Value);
    } 
    
    // Transaction ID for write API - ignored for the moment
    /*
    if (input.IBPTransactionID == null) {
        message.setHeader("IBPTransactionID", genUUID()); 
    } else {
        message.setHeader("IBPTransactionID", input.IBPTransactionID);
    }
    */
    
    // Commit to Planning area after download ?
    if (input.IBPCommit == null) {
        message.setHeader("IBPCommit", true as Boolean); 
    } else {
        message.setHeader("IBPCommit", input.IBPCommit as Boolean);
    }
    
    message.setProperty("CurrentTS", getTimeStamp())
    message.setProperty("iFlowId", "WRITE_IBP_USING_ODATA");
    
    // IBP WS-RFC support in future
    message.setHeader("IBPQueryTimeAggregationLevel", input.IBPQueryTimeAggregationLevel);
    message.setHeader("IBPQueryKey1", input.IBPQueryKey1);
    message.setHeader("IBPQueryOffset1", input.IBPQueryOffset1);
    message.setHeader("IBPPackageSizeInRows", input.IBPPackageSizeInRows); 
    
    
    message.setHeader("inputsAvailable", true);
    return message;
} 
   
  
  
def Message preparePlanningData(Message message) { 
    
      try { 
          
        message.setProperty("IBPStep", "preparing data to post"); 
        
        def headerMap = message.getHeaders();
        def propertiesMap = message.getProperties();
        
        String nav = "Nav" + headerMap.get("IBPPlanningArea");  
        
        def commit = headerMap.get("IBPCommit") as Boolean;
        
        def mp = ['Transactionid' : headerMap.get("IBPTransactionID"), 'DoCommit': (commit), 'AggregationLevelFieldsString': headerMap.get("IBPFieldsString"), (nav) : propertiesMap.get("IBPOdataPayload")];   
        
        def ibp_Payload = new JSONObject(mp); 
        
        message.setHeader("Content-Type", "application/json");
        message.setHeader("Accept", "application/json");
    
        message.setBody(ibp_Payload.toString());
        
    } catch (JSONException e) { 
		message.setBody(e);
	    message.setProperty("stepStatus", "error");
        message.setProperty("errorMessage", "Error making oData calls to IBP"); 
        message.setProperty("errorException", e);  
	}
    
    return message;  
}



def Message getTransactionID(Message message) {
    
    def headerMap = message.getHeaders();
        
    message.setProperty("IBPStep", "GET Transaction ID");
   
    def cookies = headerMap.get("set-cookie") as List<String>;
    
    message.setProperty("IBPCookie", cookies);
	
	def body = message.getBody(java.io.Reader);
    Map ibpInput = new JsonSlurper().parse(body);  
       
    def transactionID = ibpInput.get("d").get("Value")
    message.setHeader("IBPTransactionID", transactionID);  
	 
    return message;
} 



def Message checkPost(Message message) {
    
    def headerMap = message.getHeaders();
        
    message.setProperty("IBPStep", "Check Post transaction data"); 
    
	def body = message.getBody(java.io.Reader);
    
    try{
        Map ibpResponse = new JsonSlurper().parse(body);  
       
        def transactionID = ibpResponse.get("d").get("Transactionid")
        message.setHeader("IBPTransactionID", transactionID);  
        message.setProperty("stepStatus", "success"); 
    } catch (Exception e){
        message.setProperty("stepStatus", "error");
        message.setProperty("errorMessage", "Error Posting data to IBP"); 
    } 
    return message;
} 



def Message checkExportResult(Message message) {
    
    def headerMap = message.getHeaders();
        
    message.setProperty("IBPStep", "Check Export Results"); 
    
    if(!headerMap.get("IBPCommit")){
        message.setProperty("processingStatus",  "PROCESSED");
		message.setProperty("processingMessage", "IBPCommit is false");
		return message;
    }
    
	def body = message.getBody(java.io.Reader);
    
    try{
        Map ibpResponse = new JsonSlurper().parse(body);  
       
        def processingMessageType = ibpResponse.get("d").get("results")[0].get("Value") as String;
        
    	message.setProperty("processingStatus",  mapProcessingMessageTypeToString(message, processingMessageType));
		message.setProperty("processingMessage", processingMessageType);
        
        message.setProperty("stepStatus", "success"); 
        
    } catch (Exception e){
        message.setProperty("stepStatus", "error");
        message.setProperty("errorMessage", "Error Checking export results"); 
         message.setProperty("errorException", e); 
    } 
    return message;
} 


 
 def String mapProcessingMessageTypeToString(Message message, String processingMessageType) { 
     
    switch (processingMessageType) {
        case 'PROCESSED_WITH_ERRORS': return 'PROCESSED';
        case 'PROCESSING':            return 'loop';
        case 'PROCESSED':             return 'PROCESSED'; 
        case 'INITIAL':               return 'loop'; 
        default: return processingMessageType;
    }
}


def Message prepareToPost(Message message){
    
    message = getTransactionID(message);
    
    message = preparePlanningData(message);
    
    return message;
}



def String getCredentials(String aliasName) throws Exception{
   try{
       //Get the Service Instance of the SecureStoreService API 
    def service = ITApiFactory.getService(SecureStoreService.class, null);
    //Read the credential of a given alias
    def credential = service.getUserCredential(aliasName);
    //Read the User Name and password
    def IBPUser = credential.getUsername() + ':' + credential.getPassword();
    // Encode to base 64
    def IBPUserEncoded = IBPUser.bytes.encodeBase64().toString();
    
    return IBPUserEncoded;
   } catch (Exception e) {
       throw new Exception(e);
   }
} 


def Message fetch_token(Message message) { 
    
    try{
        
        def headerMap = message.getHeaders();
         
        def propertiesMap = message.getProperties();
        
        def getRequest = new URL(propertiesMap.get("IBPMetadataURL")).openConnection() as HttpURLConnection;  
        
        //Read the User Name and password 
        def IBPUserEncoded = null;
        
        try{
            IBPUserEncoded = getCredentials(headerMap.get('IBPCredentials') as String);
            if(!IBPUserEncoded){
                message.setProperty("stepStatus", "error");
                message.setProperty("errorMessage", "IBP User not found - "); 
                message.setProperty("errorException", "IBP User not found - ");  
                return message;
            }
        } catch (Exception e) {
            message.setProperty("stepStatus", "error");
            message.setProperty("errorMessage", "Error getting user credentials - "); 
            message.setProperty("errorException", e);  
            return message;
            
        }
        
        //message.setProperty("IBPStep", "GOT IBP User");
        //message.setProperty("IBPUserEncoded", IBPUserEncoded);
    
        // GET Request to IBP for Transaction ID
    	getRequest.setRequestMethod("GET");
    	getRequest.setRequestProperty("User-Agent", "SAP CPI");
    	getRequest.setRequestProperty("x-csrf-token", "fetch");
        getRequest.setRequestProperty('Connection','keep-alive');
    	getRequest.setRequestProperty('Authorization','Basic ' + IBPUserEncoded);
    	
    	getRequest.connect(); 
    	
        def status = getRequest.getResponseCode();  
        
        String token = "init";
        def cookies = getRequest.getHeaderFields().get("set-cookie") as List<String>;
        message.setProperty("IBPCookie", cookies);
        
    	if (status == HttpURLConnection.HTTP_OK) {
            token = getRequest.getHeaderField("x-csrf-token"); 
            
            message.setProperty("new_csrf_token", token); 
    
            // CLEAR and SET HTTP HEaders
        	message.setHeader("CamelHttpQuery", "");
        	message.setHeader("x-csrf-token", ""); 
        
        } else {
            message.setProperty("stepStatus", "error");
            message.setProperty("errorMessage", "Error getting x-csrf-token from IBP");  
            message.setProperty("errorException", e); 
            // message.setBody(e); 
        }
    } catch (Exception e) {
        message.setProperty("stepStatus", "error");
        message.setProperty("errorMessage", "Error getting x-csrf-token from - stage 2"); 
        
        message.setProperty("errorException", e); 
        //message.setBody(e); 
    }
    return message;
        
}



def String convertMilliToDate(String millInput){

    Pattern pattern = Pattern.compile("\\d+")
    Matcher matcher = pattern.matcher(millInput)

    String simpleDate =  ""
    if (matcher.find()) {
        def millInputInLong = Long.valueOf(matcher.group())
        Date result_date = new Date( millInputInLong );
        DateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        simpleDate = simple.format(result_date);
    }

    return simpleDate;
}

def String getCounter(String counterName,Message message) {
    Integer counterValue = message.getProperty(counterName) as Integer ?:0;
    counterValue = counterValue + 1;
    message.setProperty(counterName,counterValue);
    return counterValue;
}
 

def Message logMessage(java.lang.String fileName, Message message) {
	def body = message.getBody(java.lang.String);
	def messageLog = messageLogFactory.getMessageLog(message);
	def counter = getCounter(fileName + 'Counter',message).padLeft(3,' ');
	def logCounter = getCounter('OverallLogCounter',message).padLeft(4,' ');
	if(messageLog != null){
		messageLog.addAttachmentAsString(logCounter + " " + fileName + counter, body, "text/plain");
	};
	
	return message;
} 

def Message logException(Message message) {
    def exceptionText = message.getProperty("CamelExceptionCaught");
    message.setBody(exceptionText)
    message = logMessage("Exception - ", message);
	return message;
}

def Message logIBPMessage(Message message) {
    message = logMessage("IBP Log - ", message);
	return message;
}