import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processDataCreateRCBP(Message message) {
	def map = message.getProperties();
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	def property_S4ID = map.get("S4ID");
	def property_BP_TYPE = map.get("endpoint");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
		def body = message.getBody(java.lang.String) as String;
		def messageLog = messageLogFactory.getMessageLog(message);
		def bpType = property_BP_TYPE.substring(0,property_BP_TYPE.length()-1);
		if (messageLog != null) {
			messageLog.addAttachmentAsString("S4(" + property_S4ID + ")" + "_create_" + bpType + "_req", body, "text/json");
		}
	}
	return message;
}

def Message processDataUpdateRCBP(Message message) {
	def map = message.getProperties();
	def headermap = message.getHeaders();
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	def property_S4ID = map.get("S4ID");
	def property_RCID = map.get("RCID");
	def property_BP_TYPE = map.get("endpoint");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
		def body = message.getBody(java.lang.String) as String;
		def bpType = property_BP_TYPE.substring(0,property_BP_TYPE.length()-1);
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString("S4(" + property_S4ID + ")" + "_SB(" + property_RCID + ")" + "_update_" + bpType + "_req", body, "text/json");
		}
	}
	return message;
}

def Message processDataS4ConfirmIn(Message message) {
	def map = message.getProperties();
	def property_S4ID = map.get("S4ID");
	def property_RCID = map.get("RCID");
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
		def body = message.getBody(java.lang.String) as String;
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString("S4(" + property_S4ID + ")_SB(" + property_RCID + ")_confirm_msg", body, "text/xml");
		}
	}
	return message;
}
