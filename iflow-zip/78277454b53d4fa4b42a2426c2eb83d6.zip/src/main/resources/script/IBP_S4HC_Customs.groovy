/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.List; 
import java.lang.String;
import com.sap.it.api.mapping.*;


import org.json.JSONException;

import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;

def String getTimeStamp(){
   //"yyyy-MM-dd'T'HH:mm:ss.SSSZ"
   return new Date().format("yyyy-MM-dd'T'HH:mm:ss",TimeZone.getTimeZone('GMT+2'))
}


def Message delay(Message message) {

    sleep(3500);

    return message;
}


def Message handleRequestForIBP(Message message) {
    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body); 
    
    def queryString="" as String;
     
    // Destination configuration name on BTP for IBP Instance
    if (input.IBPDestination == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPDestination", input.IBPDestination);
    }
    
    // Credentials used for the IBP instance
    if (input.IBPCredentials == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPCredentials", input.IBPCredentials);
    }
    
    // Planning area used in the IBP instance
    if (input.IBPPlanningArea == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPPlanningArea", input.IBPPlanningArea);
    } 
    
     // Planning area version ID used in the IBP instance
    if (input.IBPPAVersionID == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPPAVersionID", input.IBPPAVersionID);
    }
    
     // S4H Logical system defined in IBP
    if (input.S4HC_LogicalSystem == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("S4HC_LogicalSystem", input.S4HC_LogicalSystem);
    }
    
    // commit data in IBP
    if (input.IBP_Commit == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBP_Commit", input.IBP_Commit);
    }
    
    // IBP transaction ID
    if (input.IBPTransactionID == null) {
        message.setHeader("IBPTransactionID", '');
    } else {
        message.setHeader("IBPTransactionID", input.IBPTransactionID);
    }
    
    // OData $top
    def S4H_QUERY_TOP = 0             
    if (input.S4H_QUERY_TOP == null) {
         message.setHeader("S4H_QUERY_TOP", 0);
    } else {
        message.setHeader("S4H_QUERY_TOP", input.S4H_QUERY_TOP);
        S4H_QUERY_TOP = input.S4H_QUERY_TOP
    }
    
    // OData $skip
    def S4H_QUERY_SKIP = 0                
    if (input.S4H_QUERY_SKIP == null) {
         message.setHeader("S4H_QUERY_SKIP", 0);
    } else {
        message.setHeader("S4H_QUERY_SKIP", input.S4H_QUERY_SKIP);
        S4H_QUERY_SKIP = input.S4H_QUERY_SKIP
    }
 
    // inlinecount number of S4 result lines
    def S4H_COUNT = 0
    if (input.S4H_COUNT == null) {
         message.setHeader("S4H_COUNT", 0);
    } else {
        message.setHeader("S4H_COUNT", input.S4H_COUNT);
        S4H_COUNT =  input.S4H_COUNT
    }
    
    // calculating the next commit, the one for the next call
    def next_count = S4H_QUERY_SKIP + S4H_QUERY_TOP + S4H_QUERY_TOP
    if ( S4H_COUNT.toInteger() <= next_count.toInteger() ) {
        message.setHeader("IBP_next_Commit_counter", next_count);
        message.setHeader("IBP_next_Commit", true);
    } else {
        message.setHeader("IBP_next_Commit", false);
    }
    
    // IBP Service
    if (input.IBP_SERVICE == null) {
         message.setHeader("IBP_SERVICE", "");
    } else {
        message.setHeader("IBP_SERVICE", input.IBP_SERVICE);
    }
    
    // IBP Service Endpoint
    if (input.IBP_ENDPOINT == null) {
         message.setHeader("IBP_ENDPOINT", "");
    } else {
        message.setHeader("IBP_ENDPOINT", input.IBP_ENDPOINT);
    }
    
    message.setHeader("S4HC_Response_IBP_Request",input.S4HC_Response_IBP_Request)
    
    message.setHeader("S4H_DEST", input.S4H_DEST);
    message.setHeader("S4H_Credentials", input.S4H_Credentials);
    message.setHeader("S4H_PATH", input.S4H_PATH);
    message.setHeader("S4H_QUERY", input.S4H_QUERY);

    message.setHeader("S4H_next_SKIP", S4H_QUERY_SKIP + S4H_QUERY_TOP )
       
    message.setProperty("S4HC_Response", input.S4HC_Response);
    
    message.setProperty("CurrentTS", getTimeStamp())
    message.setProperty("iFlowId", "WRITE_IBP_USING_ODATA");
    
    message.setHeader("inputsAvailable", true);
    return message;
}


def Message getTransactionID(Message message) {
    
    
    def headerMap = message.getHeaders(); 
   
    def cookies = headerMap.get("set-cookie") as List<String>;
    
    def csrftoken = headerMap.get("x-csrf-token")
    
    message.setProperty("IBPCookie", cookies);
    message.setHeader("x-csrf-token", csrftoken);
	
	def body = message.getBody(java.io.Reader);
    Map ibpInput = new JsonSlurper().parse(body);  
       
    def transactionID = ibpInput.get("TransactionID")
    message.setHeader("IBPTransactionID", transactionID);  
	 
    return message;
    
}


def Message prepareToPost(Message message){
    
    try{
        
        def headerMap = message.getHeaders(); 
          
        message.setProperty("IBPStep", "POST Data");    
        
        def propertiesMap = message.getProperties();
        
        def jsonSlurp = new JsonSlurper();
        def S4HC_Response = jsonSlurp.parseText(propertiesMap.get("S4HC_Response")); 
        
        def ibpPayloadArray = []
        
        if (headerMap.get("IBP_ENDPOINT") == "IBPProductionDocRootAsyncWrite") {
            ibpPayloadArray = [
                TransactionID:  headerMap.get("IBPTransactionID"),
                PlanningAreaID: headerMap.get("IBPPlanningArea"),
                VersionID: headerMap.get("IBPPAVersionID"),
                SourceLogicalSystem: headerMap.get("S4HC_LogicalSystem"),
                IBPProdnDocIntegrationMode: "UPSERT",
                _IBPProdnDocAsyncWrite: S4HC_Response
            ]
            message.setProperty("IBP_MSG_ENDPOINT","IBPProductionDocAsyncWriteMsg")
        } else if (headerMap.get("IBP_ENDPOINT") == "IBPStockRootAsyncWrite") {
            ibpPayloadArray = [
                TransactionID:  headerMap.get("IBPTransactionID"),  
                PlanningAreaID: headerMap.get("IBPPlanningArea"),
                VersionID: headerMap.get("IBPPAVersionID"), 
                SourceLogicalSystem: headerMap.get("S4HC_LogicalSystem"), 
                _IBPStockHeaderAsyncWrite: S4HC_Response
            ]
            message.setProperty("IBP_MSG_ENDPOINT","IBPStockMessageAsyncWrite")
        }

        def ibpPayload = new JsonBuilder(ibpPayloadArray)
        
        message.setBody(ibpPayload.toPrettyString());
        message.setHeader("Content-Type", "application/json");
        message.setHeader("Accept", "application/json"); 
        
        
        
    } catch (JSONException e) { 
		message.setBody(e);
	    message.setProperty("IBPStep", "error");
        message.setProperty("errorMessage", "Error preparing Stock data"); 
        message.setProperty("errorException", e);  
    }
    
    return message;
}

def Message setImportStatus(Message message){
    
    def headerMap = message.getHeaders();
    
    def httpStatus = headerMap.get("CamelHttpResponseCode");
    
    if(httpStatus != 201){
        message.setProperty("IBPStep", "ERROR");
    } else {
        message.setProperty("IBPStep", "COMMIT");
    }
    
    return message;
}


def Message setCommitStatus(Message message){
    
    def headerMap = message.getHeaders(); 
    
    Reader body = message.getBody(Reader)

    def input = new JsonSlurper().parse(body)
    
    try{
        
       // TODO - If there are multiple postings - make sure to loop thru the array.
        def processingMessageType = input['TransactionStatus'] as String;
         //message.setProperty("processingStatus",  processingMessageType);
    	message.setHeader("processingStatus",  mapProcessingMessageTypeToString(processingMessageType));
		// message.setProperty("processingMessage", processingMessageType);
        message.setHeader("IBPprocessingMessageType", processingMessageType)
        message.setProperty("IBPStep", "success"); 
        
    } catch (Exception e){
        message.setProperty("IBPStep", "error");
        message.setProperty("errorMessage", "Error while parsing COMMIT response payload"); 
        message.setProperty("errorException", e); 
    } 
    return message;
}



 
 def String mapProcessingMessageTypeToString(String processingMessageType) { 
     
    switch (processingMessageType) {
        case 'PROCESSED_WITH_ERRORS': return 'PROCESSED';
        case 'PROCESSING':            return 'loop';
        case 'PROCESSED':             return 'PROCESSED'; 
        case 'INITIAL':               return 'loop'; 
        default: return processingMessageType;
    }
}
