import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper
import groovy.xml.XmlUtil

def Message processData(Message message) {
	def header = message.getHeaders();

	def body = message.getBody(java.io.Reader);
	def xml = new XmlSlurper().parse(body);
 
    def errorCode = xml.code.text();
    def errorMessage = xml.message.text();

    def responseBody='''<ns0:SFWebServiceFault xmlns:ns0="urn:fault.sfapi.successfactors.com">
							<ns0:errorCode>''' + errorCode + '''</ns0:errorCode>
							<ns0:errorMessage>''' + errorMessage + '''</ns0:errorMessage>
						</ns0:SFWebServiceFault>''';  
						
    message.setBody(responseBody);
	return message;
	
}