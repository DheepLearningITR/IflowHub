import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.*;
import groovy.xml.XmlUtil;
import groovy.util.*;

def Message processData(Message message) {

    def body = message.getBody(java.lang.String);
    def xmlObj = new XmlSlurper(false, true).parseText(body).declareNamespace('multimap':'http://sap.com/xi/XI/SplitAndMerge','ns0':'urn:sap-com:document:sap:soap:functions:mc-style','n0':'http://sap.com/xi/SAPGlobal20/Global'); 
    def UtilitiesInstallationRequest = xmlObj.'multimap:Message1'.'n0:UtilitiesInstallationBulkReplicateRequest';
    def isuContractResponse = xmlObj.'multimap:Message1'.'ns0:IsuC4cV2PremiseBpGetResponse';
    def businessPartnerId = isuContractResponse.EtBusinessPartner.item.BusinessPartner;

    UtilitiesInstallationRequest.UtilitiesInstallationReplicateRequest.UtilitiesInstallation.appendNode {
         BusinessPartner(businessPartnerId)
    }
    
    message.setBody(XmlUtil.serialize(UtilitiesInstallationRequest));

    return message;
}