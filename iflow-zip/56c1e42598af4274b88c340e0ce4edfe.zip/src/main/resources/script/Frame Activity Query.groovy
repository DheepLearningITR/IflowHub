import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
//this script is to frame the service order item filter by FSM activity code
    def SOItemFilter;

    def ServiceOrderId = message.getProperty("ServiceOrderId")
    def FSMServiceActivityCode = message.getProperty("FSMServiceActivity")

    if (ServiceOrderId && FSMServiceActivityCode) {
        SOItemFilter = """ServiceOrder eq '""" + ServiceOrderId + """' and FSMServiceActivity eq '""" + FSMServiceActivityCode + """'"""
    }

    message.setProperty("ServiceOrderItemFilter",SOItemFilter)

    return message
}
