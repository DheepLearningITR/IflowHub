import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    //this script is to set the activity externalID
    def body = message.getBody(java.lang.String) as String
    def parsedXml = new XmlParser().parseText(body);

    def ServiceOrderID = parsedXml?.A_ServiceOrderItemType?.ServiceOrder.text()
    def ServiceOrderItemID = parsedXml?.A_ServiceOrderItemType?.ServiceOrderItem.text()

    message.setProperty("ActivityExternalId",ServiceOrderID + '/' + ServiceOrderItemID)
    return message
}
