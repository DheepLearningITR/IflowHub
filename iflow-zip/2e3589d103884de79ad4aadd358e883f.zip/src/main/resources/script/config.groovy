import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.pd.BinaryData;
import java.lang.String;

def Message setProperties(Message message) {
    def siteOpenTag = "<mep:Site>";
    def siteCloseTag = "</mep:Site>";
    String urlListPropName = "COMMON_DMC_REO_ME_OP_URL_LIST";
    String securityMaterialListPropName = "COMMON_DMC_REO_ME_OP_SECURITY_MATERIAL_LIST";

    def unique_id = message.getProperty('ENDPOINT_ID');
    def PD_NAMESPACE = "DME_Generic_Processing_$unique_id";

    def body = message.getBody(String.class);

    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null);
    if (service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }

    def startIndex = body.indexOf(siteOpenTag);
    def endIndex = body.indexOf(siteCloseTag);

    def site = body.substring(startIndex + siteOpenTag.length(), endIndex).toUpperCase();
    if(site == null || site.equals('')) {
        throw new RuntimeException("Site can not be found.");
    }

    message.setProperty('SITE', site);

    def urlString = getParameterValue(urlListPropName, PD_NAMESPACE, service);
    def securityMaterialString = getParameterValue(securityMaterialListPropName, PD_NAMESPACE, service);

    if(urlString.equals('')) {
        throw new RuntimeException("Paramter \"COMMON_DMC_REO_ME_OP_URL_LIST\" can not be found.");
    }

    if(securityMaterialString.equals('')) {
        throw new RuntimeException("Paramter \"COMMON_DMC_REO_ME_OP_SECURITY_MATERIAL_LIST\" can not be found.");
    }

    setPropValue('URL', urlString, site, message);
    setPropValue('SecurityMaterial', securityMaterialString, site, message);
    return message;
}

def String getParameterValue(String propname, String pid, def service) {
    def value = service.getParameter(propname, pid, String.class);
    if (value) {
        return value;
    } else {
        return '';
    }
}

def void setPropValue(String propName, String inputStr, String site, def message) {
    def siteUrls = inputStr.split(";");
    Properties properties = new Properties();

    for (String siteInfo : siteUrls) {
        def index = siteInfo.indexOf('=');
        if (index > 0) {
            def siteName = siteInfo.substring(0, index);
            def url = siteInfo.substring(index + 1);
            properties.setProperty(siteName, url);
        }
    }
    if (properties.getProperty(site) == null){
        throw new RuntimeException("No configuration information was found for SITE:[" + site + "].");
    }
    message.setProperty(propName, properties.getProperty(site));
}
