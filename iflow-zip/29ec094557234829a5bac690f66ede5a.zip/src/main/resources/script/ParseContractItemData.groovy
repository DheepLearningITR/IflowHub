import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import groovy.util.slurpersupport.NodeChild;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message){
    def map = message.getProperties();
    def body = message.getBody(java.lang.String);
    def CRMXIF_ORDER_SAVE_U05 = new XmlSlurper().parseText(body);
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    //read status
    CRMXIF_ORDER_SAVE_U05.IDOC.E101CRMXIF_BUSTRANS.E101CRMXIF_BUSTRANS_ITEM.E102CRMXIF_STATUS_XT.E102CRMXIF_STATUS.each{
        def mappedStatus = valueMapApi.getMappedValue('ServiceContractCRM', 'ItemStatus', it.STATUS.text(), 'ServiceContractFSM', 'Status');
        if(mappedStatus != null) {
            message.setProperty("ContractItemStatus", mappedStatus);
        }
    }
    
    //read remarks
    def serviceContractTextID = map.get("ServiceContractTextID");
    def serviceContractTextLanguage = map.get("ServiceContractTextLanguage");
    def output = "";
    CRMXIF_ORDER_SAVE_U05.IDOC.E101CRMXIF_BUSTRANS.E101CRMXIF_BUSTRANS_ITEM.E102CRMXIF_TEXT_XT.E102CRMXIF_TEXT.each { text->
        if(text.TEXT_ID.text().equals(serviceContractTextID) && text.LANGUAGE_ISO.text().equals(serviceContractTextLanguage)) {
            String flag="false"; 
            text.E102CRMXIF_TLINE.each{
                if(flag=="false") {
                    output=output+it.TEXT_LINE;
                    flag="true";
                }
                else {
                    if(it.FORMAT_COL.text()=="*")
                    output=output+"\n"+it.TEXT_LINE;
                    else if(it.FORMAT_COL.text()=="=")
                    output=output+it.TEXT_LINE;
                    else
                    output=output+" "+it.TEXT_LINE;
                }
            }
        }
    }
    message.setProperty("ContractItemRemarks", output);

    return message;
}