import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.util.XmlSlurper;
import groovy.xml.XmlUtil;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def map = message.getProperties();
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def content = jsonSlurper.parseText(body);
    def mssg;
    def HttpResponseError = false;
    
    if (content.toString().contains("message")){
        content.each{
            if (it.status >= 400 && it.status < 600){
                message.setProperty("ErrorType", "FSMError");
                message.setProperty('http.StatusCode', it.status)
                message.setProperty('http.ResponseBody', body)
                if (it.status == 500) {
                    message.setProperty('http.StatusText', it.message);
                } else {
                    message.setProperty('http.StatusText', it.ex.message);
                }
                HttpResponseError = true;
            }
        }
    }
    
    if(!HttpResponseError) {
        def contractIdMap = [:];
        content.each {
            contractIdMap[it.serviceContract.code] = it.serviceContract.id;
        }
        
        def original_payload =  map.get("original-payload") as String;
        def CRMXIF_ORDER_SAVE_U05 = new XmlSlurper().parseText(original_payload);
        CRMXIF_ORDER_SAVE_U05.IDOC.E101CRMXIF_BUSTRANS.E101CRMXIF_BUSTRANS_ITEM.each { item->
            item.appendNode {
                FSM_ITEM_ID(contractIdMap[item.ITEM_GUID.text()]);
            }
        }
        message.setBody(XmlUtil.serialize(CRMXIF_ORDER_SAVE_U05));
        message.setProperty("ProcessDirect", "true");
    }
    
    return message;
}
  