import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    
    body = body.replace('<(>', "").replace('<)>', "");
    
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    message.setBody(JsonOutput.toJson(jsonObject["contract"]));
    message.setProperty("RequestPayload", JsonOutput.toJson(jsonObject["contract"]));
    
    return message;
}