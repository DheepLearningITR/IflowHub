import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

// process message
def Message processData(Message message) { 
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)
    message.setProperty("ValidData",'true')

    // Replace null values with empty strings and remove empty arrays
    replaceNullsAndRemoveEmptyArrays(jsonResult)

    jsonResult.remove("objectId")
    jsonResult.remove("objectType")
    jsonResult.data?.checklistTemplate?.remove("lastChanged")
    jsonResult.data?.checklistTemplate?.remove("owners")
    jsonResult.data?.checklistTemplate?.remove("syncObjectKPIs")
    jsonResult.data?.checklistTemplate?.remove("groups")
    jsonResult.data?.checklistTemplate?.remove("branches")
    jsonResult.data?.checklistTemplate?.remove("tags")
    jsonResult.data?.checklistTemplate?.remove("udfValues")

    //set OData url prefix path to UpdateMaintenanceOrder
    if (!jsonResult.data?.checklistTemplate || !jsonResult.data?.checklistTemplate?.id){
        message.setProperty("ValidData",'false')
    }
    message.setProperty("TemplateID",jsonResult.data?.checklistTemplate?.id)
    message.setProperty("eventType",jsonResult.eventType)
    message.setHeader("SAP_ApplicationID",jsonResult.data?.checklistTemplate?.id)

    def updatedJsonString = JsonOutput.toJson(jsonResult)
    message.setProperty("S4HRequestPayload",JsonOutput.prettyPrint(updatedJsonString))
    message.setBody(JsonOutput.prettyPrint(updatedJsonString))
    
    
    def messageLog = messageLogFactory.getMessageLog(message)
    if(jsonResult.data?.checklistTemplate?.id)
        messageLog.addCustomHeaderProperty("FSMTemplateID", jsonResult.data?.checklistTemplate?.id)
    if(jsonResult.data?.checklistTemplate?.externalId)    
        messageLog.addCustomHeaderProperty("S4InstanceID", jsonResult.data?.checklistTemplate?.externalId)

    return message
}

// Recursive function to replace all null values with empty strings and remove empty arrays
def replaceNullsAndRemoveEmptyArrays(obj) {
    if (obj instanceof Map) {
        def keysToRemove = [] // List to track empty arrays
        obj.each { key, value ->
            if (value == null || value == 'null' || value == '') {
                //obj[key] = ""
                keysToRemove.add(key) // Mark empty array for removal
            } else if (value instanceof List && value.isEmpty()) {
                keysToRemove.add(key) // Mark empty array for removal
            } else {
                replaceNullsAndRemoveEmptyArrays(value)
            }
        }
        // Remove the keys after iteration
        keysToRemove.each { key ->
            //obj.remove(key)
            obj.remove(key)
        }
    } else if (obj instanceof List) {
        def itemsToRemove = [] // List to track null and empty arrays
        obj.each { item ->
            if (item == null || item == 'null' || item == '' || (item instanceof List && item.isEmpty())) {
                itemsToRemove.add(item) // Mark for removal
            } else {
                replaceNullsAndRemoveEmptyArrays(item)
            }
        }
        // Remove the items after iteration
        itemsToRemove.each { item ->
            obj.remove(item)
        }
    }
}
