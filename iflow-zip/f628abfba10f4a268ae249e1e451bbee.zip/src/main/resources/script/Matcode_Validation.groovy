import com.sap.it.api.mapping.*;
def String Matcode_Validation(String input){
    if(input.isNumber()){
      input = ("000000000000000000" + input).substring(input.length())
 }
    return input;
}
def String Vendor_Validation(String input){
    if(input.isNumber()){
      input = ("0000000000" + input).substring(input.length())
 }
    return input;
}
def String InternalOrder(String input){
    if(input.isNumber()){
      input = ("000000000000" + input).substring(input.length())
 }
    return input;
}