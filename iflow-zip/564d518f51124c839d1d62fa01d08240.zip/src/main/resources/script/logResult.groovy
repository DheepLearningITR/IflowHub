import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;


def Message logFailedResult(Message message) {
    def props = message.getProperties();
	def property_ENABLE_MPL_LOGGING = props.get("EnableLog");
	if("TRUE".equalsIgnoreCase(property_ENABLE_MPL_LOGGING)){
	    def body = message.getBody(java.lang.String) as String;
        def messageLog = messageLogFactory.getMessageLog(message);
        def productCode = props.get("ProductCode");
	    if (messageLog != null) {
            messageLog.addAttachmentAsString("Offering(" + productCode + ") creation - failed", body, "text/xml");
	    }
	}
    return message;
}

def Message logSuccessResult(Message message) {
    def props = message.getProperties();
	def property_ENABLE_MPL_LOGGING = props.get("EnableLog");
	if("TRUE".equalsIgnoreCase(property_ENABLE_MPL_LOGGING)){
	    def body = message.getBody(java.lang.String) as String;
        def messageLog = messageLogFactory.getMessageLog(message);
        def productCode = props.get("ProductCode");
	    if (messageLog != null) {
            messageLog.addAttachmentAsString("Offering(" + productCode + ") creation - success", body, "text/xml");
	    }
	}
    return message;
}