import com.sap.it.api.mapping.*;

def String getProperty(String PropertyName, MappingContext context){
   String value = context.getProperty(PropertyName);
	return value; 
}