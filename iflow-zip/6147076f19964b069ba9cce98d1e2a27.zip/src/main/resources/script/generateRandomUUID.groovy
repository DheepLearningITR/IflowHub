import com.sap.it.api.mapping.*;

def String generateUUID(String arg1){
	return UUID.randomUUID().toString()
}