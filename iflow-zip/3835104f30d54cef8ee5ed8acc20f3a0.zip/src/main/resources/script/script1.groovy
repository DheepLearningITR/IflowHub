import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import static java.util.Calendar.*


def Message processData(Message message) {
    
    //Get Properties  
    def map = message.getProperties();

 //   def surveyIdText = map.get("SurveyID");  
    def nps = map.get("nps")
    
     def email = map.get("emailAddress")
    
    // Create message body
    def Builder = new JsonBuilder()
    
    def json = Builder {
	"key_id" 3
	"contacts": [
        {
            "100019732": nps,
            "3": email
        }
    ]
    }


    def outputJson = JsonOutput.toJson(json)
    message.setBody(outputJson)
    message.setHeader("Content-Type", "application/json");
    return message;

}