import java.util.HashMap;
import com.sap.gateway.ip.core.customdev.util.Message;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

class jsonEKPOSfix {
    
    public String logical_system = "";

    
    def String fixJson(String element) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(element);
        change(rootNode, "details");

        return rootNode.toString();
    }

    def void change(JsonNode parent, fieldName) {

        if(parent.has(fieldName) && !parent.get(fieldName).isArray()) {
             JsonNode old = parent.get(fieldName);
             parent.putArray(fieldName).add(old);
        }
        // recursively invoke this method on all properties
        for (JsonNode child : parent) {
          change(child, fieldName);
        }
        
    }

    def String fixJSONLogicalSystem(String jsonString) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(jsonString);

        if (rootNode.isArray()) {
            for (JsonNode jsonNode : rootNode) {
                if (jsonNode.get("logicalSystem") == null) {
                    jsonNode.put("logicalSystem", logical_system);
                    
                } else {
                    // this one should only occur once at the start
                    logical_system = jsonNode.get("logicalSystem").asText();
                }
            }
        }
        return rootNode.toString();
    
    }
}

def Message processData(Message message) {
    
    def ekposJsonConv = new jsonEKPOSfix()

    def messageLog = messageLogFactory.getMessageLog(message);
	def bodyString = message.getBody(java.lang.String) as String;
	
	if (bodyString[0] != "["){
	    bodyString = "["+ bodyString + "]";
	}
	
	def jsonString = ekposJsonConv.fixJson(bodyString);
	def jsonStringFixed = ekposJsonConv.fixJSONLogicalSystem(jsonString);
	message.setBody(jsonStringFixed);
	
	message.setHeader("X-User-ID", "12");
    message.setHeader("X-Tenant-ID", "0");
    message.setHeader("X-Tenant-Detail", false);
    message.setHeader("Content-Type", "application/json");

    return message;
}