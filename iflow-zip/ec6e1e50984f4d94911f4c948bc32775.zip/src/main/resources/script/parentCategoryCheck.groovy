import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.*

def Message processData(Message message) {
  def body = message.getBody(java.lang.String) as String;
  def properties = message.getProperties() as Map<String, Object>;
  def index = body.indexOf('ProductCategoryID');
  if(index > -1){
    message.setProperty("parentCategoryCodeReplicated","true");
    message.setBody(properties.get("originalPayload"));
  }else{
    message.setProperty("parentCategoryCodeReplicated","false");
    throw new Exception("Parent category not present");
  }
  return message;
}
