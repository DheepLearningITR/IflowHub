import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import javax.xml.bind.DatatypeConverter;

//This method removes the xml tag from the body and a property
def Message processData(Message message) {
  String payload = message.getBody(java.lang.String)
  
  if(payload.contains("?xml")){
	int i = payload.indexOf('>');
	payload = payload.substring(i+1);
	message.setBody(payload);
  }
  
  String originalPayload = message.getProperty("originalPayload");
  if(originalPayload.contains("?xml")){
	int i = originalPayload.indexOf('>');
	originalPayload = originalPayload.substring(i+1);
	message.setProperty("originalPayload",originalPayload);
  }
  
  return message;
}