import com.sap.it.api.mapping.*;

//Get the externalizable parameter value by passing the externalizable property name & mapping context
def String getExchangeProperty(String propertyName,MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}
