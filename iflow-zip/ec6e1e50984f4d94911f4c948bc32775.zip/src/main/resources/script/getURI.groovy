import com.sap.it.api.mapping.*;
import java.net.URLEncoder;

def String getProdCatURI(String arg1, String arg2){
    String url =  "ProductCategories(ProductHierarchyID='"+URLEncoder.encode(arg1, "UTF-8")+"',ProductCategoryID='"+URLEncoder.encode(arg2, "UTF-8")+"')";
    return url;
}
