import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
    
def Message enrichSalesAreaData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    if(body != null && !body.trim().isEmpty()){
        def products = new JsonSlurper().parseText(body);
        
        for(i = 0; i < products.size; i++) {
            def salesAreas = products[i].aspectsData.physicalProduct.salesAreaData;
            String division = null;
            String pricingReferenceProduct = null;

            // get the first division and pricingReferenceProduct values that can be found in all sales areas of a product
            salesAreas.each {  salesArea ->
                if (salesArea instanceof Map && salesArea.containsKey("division") != null && division == null) {
                    division = salesArea['division']
                };
                if (salesArea instanceof Map && salesArea.containsKey("pricingReferenceProduct") != null && pricingReferenceProduct == null) {
                    pricingReferenceProduct = salesArea['pricingReferenceProduct']
                }
            }

            if (division != null || pricingReferenceProduct != null) {
                for (int j = 0; j < salesAreas.size; j++) {
                    if (salesAreas[j] instanceof Map && !salesAreas[j].containsKey("division") != null && division != null) {
                        salesAreas[j].put("division", division);
                    }

                    if (salesAreas[j] instanceof Map && !salesAreas[j].containsKey("pricingReferenceProduct") != null && pricingReferenceProduct != null) {
                        salesAreas[j].put("pricingReferenceProduct", pricingReferenceProduct);
                    }
                }
            }
        }

        message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(products)));
    }

    return message;
}