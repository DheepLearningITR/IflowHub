import com.sap.it.api.mapping.*;

//This method returns value of a header, expects one input header_name i.e. name of the header to be retrieved
def String get_header(String header_name,MappingContext context) {

    def header = context.getHeader(header_name);

    return header;

}