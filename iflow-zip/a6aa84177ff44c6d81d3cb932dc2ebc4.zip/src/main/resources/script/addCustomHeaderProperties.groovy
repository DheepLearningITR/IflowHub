import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.util.Base64

def Message processData(Message message) {
	// Constant: Property Prefix for Custom Header Property
	final String CH_PREFIX = "customHeader_"
	def headers = message.getHeaders()
    def custHeaderProps = headers.get('customHeaderProperties') //custom headers are either stored in the standard pipeline header
	def properties = message.getProperties() //or custom headers can be defined as IFlow-step specific Exchange Propeties
	def resultCustomHeaderProperties = [:] // Start with empty map
	def messageLog = messageLogFactory.getMessageLog(message)

    try {
         // first check if header customHeaderProperties exists and already defined (only String input is expected)
		 if (custHeaderProps && custHeaderProps instanceof String && custHeaderProps?.trim()) {
            // Split by '|' and handle each part independently (backward compatibility to avoid failure of handling input like jsonInBase64|key:value 
            custHeaderProps.split(/\|/).each { part ->
                def decodedPart = decodeIfBase64(part) //if base64 and JSON - decode to Map, otherwise return String
                if (decodedPart instanceof Map) {
                    resultCustomHeaderProperties.putAll(decodedPart)
                } else if (decodedPart instanceof String && isValidKeyValueString(decodedPart)) {
					//if String - check if it is delimited as expected and if yes - split and convert to result Map
					decodedPart.split(/\|/).each { pair ->
						def kv = pair.split(":", 2)
						if (kv?.size() == 2) {
							resultCustomHeaderProperties[kv[0]?.trim()] = kv[1]?.trim()
						}
					}
                }
                // else ignore
            }
        }       
    } catch (Exception ignored) {
        // Fallback to empty map on any failure
        resultCustomHeaderProperties = [:]
    }		

    try {
        // Merge Exchange properties with prefix
        properties?.findAll { k, v -> 
            k instanceof String && k.startsWith(CH_PREFIX)
        }?.each { k, v ->
            def cleanKey = k.replaceFirst("^${CH_PREFIX}", "")
            resultCustomHeaderProperties[cleanKey] = v
        }
    } catch (Exception ignored) {
        // Ignore on failure
    }

    try { //if final Customer Headers Map exists and not empty - attach to the MPL log and store the header with potentially new or same values
        if (messageLog && resultCustomHeaderProperties && !resultCustomHeaderProperties.isEmpty()) {
            resultCustomHeaderProperties.each { key, value ->
                messageLog.addCustomHeaderProperty(key, value)
            }
			// Convert map to JSON
            def jsonString = JsonOutput.toJson(resultCustomHeaderProperties)
			// Encode JSON to Base64 and set standard header
            def base64Encoded = Base64.encoder.encodeToString(jsonString.getBytes("UTF-8"))
            message.setHeader('customHeaderProperties', base64Encoded)
        }
    } catch (Exception ignored) {
        // Log writing failed, continue
    }
	
	return message
}

def decodeIfBase64(String input) {
    def output = input

    if (input instanceof String && isBase64(input)) {
        try {
            def decoded = new String(Base64.decoder.decode(input.trim()), "UTF-8")
            try {
                def jsonParsed = new JsonSlurper().parseText(decoded)
                if (jsonParsed instanceof Map) {
                    output = jsonParsed
                } else {
                    output = decoded
                }
            } catch (Exception ignored) {
                output = decoded // Not JSON, but still decoded
            }
        } catch (Exception ignored) {
            output = input // Fall back to original
        }
    }

    return output
}

boolean isBase64(String s) {
    return s?.matches("[A-Za-z0-9+/=\\s]+")
}

boolean isValidKeyValueString(String input) {
    if (!input?.trim()) return false

    def pairs = input.split(/\|/)
    for (pair in pairs) {
        if (!pair.contains(":")) return false

        def kv = pair.split(":", 2)
        if (kv.size() != 2) return false

        def key = kv[0]?.trim()
        def value = kv[1]?.trim()

        if (!key || !value) return false
        if (key.contains(":") || key.contains("|") || value.contains(":") || value.contains("|")) return false
    }
    return true
}