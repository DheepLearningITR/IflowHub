import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
//Properties  
	def contentproperties = message.getProperties();
	def encodedGzipcontent = contentproperties.get("DocumentContent") as String;
	message.setBody(encodedGzipcontent)
    return message;
}