import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
//Properties  
	def properties = message.getProperties();
	def quoteBody = message.setBody(properties.get("Quote")); 
	
	def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
		messageLog.addAttachmentAsString("Log - quoteBody variable = ", quoteBody ,
		                                                    "text/xml");
	}
	
	message.setBody(quoteBody);
	
	return message;
}