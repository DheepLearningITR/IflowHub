import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
//Properties  
	def prop = message.getProperties();
	def externalId = prop.get("ExternalId") as String;
	def compositeNumber = prop.get("CompositeNumber") as String;
	def returnQuoteId = "";
	if(externalId == null || externalId=="") {
	    returnQuoteId = compositeNumber;
	} else {
	    returnQuoteId = externalId;
	}
	def response = "<Result><HTTPResponseCode>200</HTTPResponseCode ><Code></Code><Message></Message> <ExternalId>" +returnQuoteId+"</ExternalId></Result>";
	message.setBody(response);
    return message;
}