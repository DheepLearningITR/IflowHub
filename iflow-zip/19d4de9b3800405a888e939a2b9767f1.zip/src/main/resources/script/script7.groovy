import com.sap.gateway.ip.core.customdev.util.Message;

import java.util.HashMap;

 

def Message processData(Message message) {

 

//Body

def body = message.getBody(String.class);

 

String encoded = body.bytes.encodeBase64().toString();

message.setBody(encoded);

 

return message;

}