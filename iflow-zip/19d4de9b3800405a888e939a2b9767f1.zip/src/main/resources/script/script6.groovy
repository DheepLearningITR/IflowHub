import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {	
	def properties = message.getProperties() as Map<String, Object>;
	def value = properties.get("EncodedDocumentContent");
	def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("Log EncodedDocumentContent",   value);
	return message;
}