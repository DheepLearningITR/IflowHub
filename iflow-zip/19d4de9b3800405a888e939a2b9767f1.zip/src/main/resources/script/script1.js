importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
    var map = message.getProperties();
    var value = map.get("SavedQuote");
    message.setBody(value);
    return message;
}