import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {
    
       //Body 
       String access = message.getBody(java.lang.String);

     if(access.length() > 2)
      access = access.substring(1, access.length() - 1);
    byte[] decoded = access.decodeBase64()
    String decodeString = new String(decoded)
      message.setProperty("P_ResponseSAP", decodeString);
      message.setBody(access);
   return message;
}