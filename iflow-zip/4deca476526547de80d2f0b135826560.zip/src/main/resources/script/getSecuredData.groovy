import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;

def Message processData(Message message) {
    //Body 
    
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    if( service != null){
        
        String pUserName = message.getProperty("P_USERNAME");
        String pPassword = message.getProperty("P_PASSWD");
        

        //Get UserCredential containing user credential details deployed on the node with the given alias.
     
        String username = service.getUserCredential(pUserName).getPassword().toString();
        String password = service.getUserCredential(pPassword).getPassword().toString();
        
        message.setProperty("P_User",username );
        message.setProperty("P_Password",password );
       
    }
    
       
       return message;
}