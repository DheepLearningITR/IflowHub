import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Initial Payload", body, "text/plain");
		}
	}
	return message;
}

def Message respOlimpia(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Response Olimpia", body, "text/plain");
		}
	}
	return message;
}

def Message getDocRequest(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Doc Request Olimpia", body, "text/plain");
		}
	}
	return message;
}

def Message getDocResp(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Doc Response Olimpia", body, "text/plain");
		}
	}
	return message;
}

def Message respSAP(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Response To SAP", body, "text/plain");
		}
	}
	return message;
}

def Message authOlimpia(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Request Authenticate To Olimpia", body, "text/plain");
		}
	}
	
	return message;
}

def Message authOlimpiaResp(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Response Authenticate To Olimpia", body, "text/plain");
		}
	}
	
	return message;
}
def Message reqOlimpia(Message message) {
    
    //Reading properties
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		
	//Set payload body as attachment
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Request To Olimpia", body, "text/plain");
		}
	}
	
	return message;
}