import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    //Body 
       String access = message.getBody(java.lang.String);

     if(access.length() > 2)
      access = access.substring(1, access.length() - 1);

      message.setProperty("P_AccessToken", access);
    
      return message;
}



       





