import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {    
    
	//Body 
    def body = message.getBody(java.lang.String);  
    String msg = ""
	String edocNo = ""
	
     def jsonSlurper = new JsonSlurper()
     def content = jsonSlurper.parseText(body)
   
    content.messages.each{
	msg = msg + it
    	}
  
// 	if(content.relatedDocumentNumber != null)
// 		edocNo =  content.relatedDocumentNumber;
    if(content.documentNumber != null)
        edocNo =  content.documentNumber;

	def map = message.getProperties();
	  // Set Properties
    message.setProperty("P_firstWSRespDocNo",edocNo);
	message.setProperty("P_firstWSRespMessage",msg);
    
return message;
}