import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties*/

def void getPrefix_Invoice(String[] is, Output prefixOutput, Output invoiceOutput, MappingContext context){
	String prefix = "";
    String invoice = "";
    String body = is[0];
    for(int i=0; i<body.length(); i++){
     if (Character.isDigit(body.charAt(i)) == true){
        prefix = body.substring(0,i);
        invoice = body.substring(i);
        break;
        }
    }
    context.setProperty("P_Prefix",prefix);
    prefixOutput.addValue(prefix);
    invoiceOutput.addValue(invoice);
}