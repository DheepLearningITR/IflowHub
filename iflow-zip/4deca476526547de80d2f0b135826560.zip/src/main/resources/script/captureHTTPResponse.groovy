import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {
                
                // get a map of iflow properties
                def map = message.getProperties();
                
                // get an exception java class instance
                def ex = map.get("CamelExceptionCaught");
                if (ex!=null) {
                                
                                // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
                                if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {


                                                // copy the http error response to an iflow's property
                                                message.setProperty("http.ResponseBody",ex.getResponseBody());

                                                // copy the value of http error code (i.e. 500) to a property
                                                message.setProperty("http.StatusCode",ex.getStatusCode());

                                                // copy the value of http error text (i.e. "Internal Server Error") to a property
                                                message.setProperty("http.StatusText",ex.getStatusText());
                                                
                                                if(ex.getStatusCode()!= 400)
                                                {
                                                     message.setProperty("P_valdateRespMessage",ex.getResponseBody());
                                                }
                                                else
                                                {
                                                    def jsonSlurper = new JsonSlurper()
                                                    def content = jsonSlurper.parseText(ex.getResponseBody())
                                                    String msg = ""
                                                    content.messages.each{
		                                            msg = msg + it
                                                	}
                                                    message.setProperty("P_valdateRespMessage",msg);
                                                }
                                               
                                }
                                // HTTP 200 with Invalid Document
                                if (ex.getClass().getCanonicalName().equals("com.sap.esb.camel.error.handler.ErrorEventException")) {
                                    
                                                   // copy the value of http error code 
                                                message.setProperty("http.StatusCode","200");

                                                // copy the value of http error text 
                                                message.setProperty("http.StatusText","OK");
                                                
                                                def response = map.get("P_firstWSRespMessage");
                                              
                                                message.setProperty("P_valdateRespMessage",response);
                                              
                                    
                                }
                                
                                
                                
                }

                return message;
}