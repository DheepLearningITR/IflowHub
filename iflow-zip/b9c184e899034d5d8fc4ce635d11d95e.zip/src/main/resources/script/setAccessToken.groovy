import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def properties =  message.getProperties();
    def jsonSlurper = new JsonSlurper();
    def jsonDataObject = jsonSlurper.parseText(body);

    message.setProperty("p_token", "Bearer " + jsonDataObject.access_token);

   //Headers 
   def map = message.getHeaders();
   def value = map.get("Authorization");

   message.setHeader("Authorization", "Bearer " + jsonDataObject.access_token);
   
   //Body
   def p_body = properties.get("p_body");
   message.setHeader("Content-Type", "application/xml");
   message.setBody(p_body);

   return message;
}