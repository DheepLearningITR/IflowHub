/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageResponse = message.getProperty('LogMessageResponse');
  body = JSON.parse(body);
  var token = body.d.token;
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Token info:', body + 'Token ' + token, 'text/json');
  }
  message.setProperty('token', 'Bearer ' + token);
  return message;
}