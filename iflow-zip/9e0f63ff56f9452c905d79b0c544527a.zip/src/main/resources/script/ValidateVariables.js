/* eslint-disable quote-props*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var defaultParameters = { 'Root_Department': 'Company', 'ProjectSyncOnlyOpenProjects': 'In Planning, Contract Preparation, In Execution', 'UserTemplatesAssigned': 'Project Time Entry with Billing,Time Off,Expenses', 'UserPermissionSetsAssigned': 'Project Manager,Project Resource with Reports', 'TimesheetApprovalPath': 'Project Manager', 'UserSyncDate': '2001-01-01T00:00:00', 'ProjectSyncFrom': '2001-01-01T00:00:00', 'ClientSyncFrom': '2001-01-01T00:00:00', 'Overwrite_Global_Variables': 'NO' };
  var messageLog = messageLogFactory.getMessageLog(message);
  var configuredParameters = validateParameters(defaultParameters, message);
  var logMessageResponse = message.getProperty('LogMessageResponse');
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Adjusted Configure Variables: ', JSON.stringify(configuredParameters), 'text/json');
  }
  message = setMessageProperties(configuredParameters, message, messageLog);
  return message;
}

function validateParameters(defaultParams, message) {
  var configuredParams = {};
  var value = null;
  for (var key in defaultParams) {
    value = String(message.getProperty(key));
    if (validateString(value)) {
      value = defaultParams[key];
    }
    configuredParams[key] = value;
  }
  return configuredParams;
}

function setMessageProperties(configuredParams, message) {
  for (var key in configuredParams) {
    message.setProperty(key, configuredParams[key]);
  }
  return message;
}

function validateString(str) {
  return (str.length === 0 || !str.trim());
}
