importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageResponse = message.getProperty('LogMessageResponse');
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('DiscoveryService Response', body, 'text/json');
  }
  body = JSON.parse(body);
  var repliconUrl = body.d.applicationRootUrl;
  var tenant = body.d.tenant.slug;
  message.setProperty('repliconBaseURL', repliconUrl);
  message.setProperty('repliconTenant', tenant);
  body = '{}';
  message.setBody(body);
  return message;
}
