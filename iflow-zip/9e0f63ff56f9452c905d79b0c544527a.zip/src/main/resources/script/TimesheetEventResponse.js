importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageResponse = message.getProperty('LogMessageResponse');
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Timesheet Subscribe Response:', body, 'text/json');
  }

  body = JSON.parse(body);
  var webhookSubscriptionId = body.data.createWebhookSubscription.subscription.id;
  message.setProperty('webhookSubscriptionId', webhookSubscriptionId);
  message.setBody('');
  return message;
}