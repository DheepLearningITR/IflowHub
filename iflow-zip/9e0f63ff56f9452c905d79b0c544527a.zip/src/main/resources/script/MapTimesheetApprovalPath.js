importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var logMessageResponse = message.getProperty('LogMessageResponse');
  var timesheetApprovalPath = String(message.getProperty('TimesheetApprovalPath'));
  var messageLog = messageLogFactory.getMessageLog(message);
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Replicon Approval Paths:', body, 'text/json');
  }
  body = JSON.parse(body);
  var approvalPathUri = filterApprovalPath(timesheetApprovalPath, body.d);
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Timesheet Approval path:', approvalPathUri, 'text/json');
  }
  message.setProperty('timesheetApprovalPath', approvalPathUri);
  return message;
}

function filterApprovalPath(pathName, approvalPaths) {
  var approvalPath = approvalPaths.filter(function(path) {
    return compareStringIgnoreCase(pathName.trim(), path.displayText);
  });
  if (approvalPath && approvalPath.length) {
    return approvalPath[0].uri;
  }
  return null;
}

function compareStringIgnoreCase(str1, str2) {
  return (str1 && str2) ? str1.equalsIgnoreCase(str2) : false;
}