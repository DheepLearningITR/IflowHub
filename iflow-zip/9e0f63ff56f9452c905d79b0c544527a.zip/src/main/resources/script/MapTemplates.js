importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var userTemplatesAssigned = String(message.getProperty('UserTemplatesAssigned'));
  var messageLog = messageLogFactory.getMessageLog(message);
  body = JSON.parse(body);
  var templateUris = filterTemplates(userTemplatesAssigned, body.d);
  var logMessageResponse = message.getProperty('LogMessageResponse');
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('User TemplateUris:', templateUris, 'text/json');
  }
  message.setProperty('userTemplatesUris', templateUris);
  return message;
}

function filterTemplates(templateNames, policySets) {
  var templateUris = [];
  var templateNamesArray = templateNames.split(',');
  templateNamesArray.forEach(function(templateName) {
    var policyEntry = policySets.filter(function(p) {
      return compareStringIgnoreCase(p.name, templateName.trim());
    });
    if (policyEntry && policyEntry[0] && policyEntry[0].uri) {
      templateUris.push(policyEntry[0].uri);
    }
  });
  return templateUris.join();
}

function compareStringIgnoreCase(str1, str2) {
  return (str1 && str2) ? str1.equalsIgnoreCase(str2) : false;
}