/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageResponse = message.getProperty('LogMessageResponse');
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('OEF Response:', body, 'text/json');
  }
  body = JSON.parse(body);
  var oefDetails = body.d;
  var controllingAreaOEFName = message.getProperty('ProjectControllingAreaOEFName');
  var oefs = '';
  if (!isOefPresent(controllingAreaOEFName, oefDetails)) {
    oefs += '<oef>' + controllingAreaOEFName + '</oef>';
  }
  message.setBody(oefs);
  return message;
}

function isOefPresent(oefName, allOefs) {
  var length = allOefs.length;
  for (var i = 0; i < length; i++) {
    if (allOefs[i].name === oefName) {
      return true;
    }
  }
  return false;
}