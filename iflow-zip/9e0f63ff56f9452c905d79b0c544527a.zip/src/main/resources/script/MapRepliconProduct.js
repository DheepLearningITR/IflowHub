importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var invalidProductErrorMessage = 'You do not have the required products in the target tenant. Please ensure the required Replicon products are available and enabled.';
  var body = message.getBody(new java.lang.String().getClass());
  var validProducts = [ 'urn:replicon-saas:product:time-bill-plus' ];
  body = JSON.parse(body);
  checkValidProducts(validProducts, body.d, invalidProductErrorMessage);
  return message;
}

function checkValidProducts(validProducts, productsAssigned, invalidProductErrorMessage) {
  validProducts.forEach(function(validProduct) {
    var productEntry = productsAssigned.filter(function(p) {
      return compareUri(p.uri, validProduct);
    });
    if (productEntry.length === 0) {
      throw invalidProductErrorMessage;
    }
  });
}

function compareUri(uri1, uri2) {
  return (uri1 && uri2) ? (uri1 === uri2) : false;
}