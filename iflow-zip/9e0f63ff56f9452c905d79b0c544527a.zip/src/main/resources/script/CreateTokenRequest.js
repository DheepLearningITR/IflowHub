/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageResponse = message.getProperty('LogMessageResponse');
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('identity response:', body, 'text/json');
  }
  body = JSON.parse(body);
  var loginName = body.d.actualUser.loginName;
  message.setProperty('loginName', loginName);
  var userUri = body.d.actualUser.userUri;
  message.setProperty('userUri', userUri);
  body = {
    identity: {
      userUri: null,
      loginName: loginName
    },
    description: 'Access Token for SAP connectors',
    unitOfWorkId: makeid(6)
  };
  message.setBody(JSON.stringify(body));
  return message;
}

function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}