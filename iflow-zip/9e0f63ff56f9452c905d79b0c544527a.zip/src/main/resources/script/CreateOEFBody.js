
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageResponse = message.getProperty('LogMessageResponse');
  var logMessageRequest = message.getProperty('LogMessageRequest');
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Missing Oefs:', body, 'text/json');
  }

  var oefName = getValue('oef', body);
  var json = {
    objectExtensionTextDefinition: {
      target: {
        uri: null,
        name: oefName
      },
      name: oefName,
      code: oefName,
      description: 'Created for SAP Integration. Do not edit or delete.'
    }
  };
  if (messageLog && logMessageRequest && logMessageRequest.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('OEF Create RequestBody:', JSON.stringify(json), 'text/json');
  }
  message.setBody(JSON.stringify(json));
  return message;
}

function getValue(tag, xmlString) {
  var value = null;
  var startPos = null;
  var endPos = null;
  var startTag = '<' + tag + '>';
  var endTag = '</' + tag + '>';
  var tempString = xmlString;
  startPos = tempString.search(startTag) + startTag.length;
  endPos = tempString.search(endTag);
  value = tempString.slice(startPos, endPos);
  return value;
}
