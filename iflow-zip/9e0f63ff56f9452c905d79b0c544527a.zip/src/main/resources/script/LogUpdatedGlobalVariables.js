importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var configuredVariables = [ 'Root_Department', 'ProjectSyncOnlyOpenProjects', 'UserTemplatesAssigned', 'UserPermissionSetsAssigned', 'UserSyncDate', 'ProjectSyncFrom', 'ClientSyncFrom', 'Overwrite_Global_Variables', 'UserTimesheetApprovalPath' ];
  var messageLog = messageLogFactory.getMessageLog(message);
  var globalVariables = validateParameters(configuredVariables, message);
  var logMessageResponse = message.getProperty('LogMessageResponse');
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Updated Global Variables: ', JSON.stringify(globalVariables), 'text/json');
  }
  return message;
}

function validateParameters(configuredVariables, message) {
  var globalVariables = {};
  var value = null;
  for (var key in configuredVariables) {
    value = String(message.getProperty(configuredVariables[key]));
    globalVariables[configuredVariables[key]] = value;
  }
  return globalVariables;
}
