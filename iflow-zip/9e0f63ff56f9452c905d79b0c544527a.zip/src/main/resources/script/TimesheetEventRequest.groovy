import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def cpiCredentialName = message.getProperty("CpiCredentialName");
    def logMessageResponse = message.getProperty("LogMessageResponse");
    def secureStorageService = ITApiFactory.getApi(SecureStoreService.class, null);

    def credential = secureStorageService.getUserCredential(cpiCredentialName);
    if (credential == null){
        throw new IllegalStateException("No CpiCredentialName credential found");
    }

    String userName = credential.getUsername();
    String password = new String(credential.getPassword());

    def timesheetIflowEndpointUrl = message.getProperty("CpiUrl") + "/http/TimesheetSync";
    def query = """mutation CreateTimesheetApprovedWebhook { 
                    createWebhookSubscription (input: { 
                        eventType:TimesheetStatusChangedToApproved    
                        targetUrl:\"https://""" + timesheetIflowEndpointUrl + """\"
                        basicAuth:{
                          username:\"""" + userName + """\"
                          password:\"""" + password + """\"
                        }
                    }) { 
                    subscription { 
                      id 
                      sharedSecret 
                    } 
                  } 
                }""";
                
    def requestData = JsonOutput.toJson( [
        "operationName": "CreateTimesheetApprovedWebhook",
        "variables": {
    
        },
        "query": query
        ] );
        
    if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
        messageLog.addAttachmentAsString("Timesheet Event requestData:", requestData, "text/json");
    }
    
    message.setBody(requestData);

    return message;
}