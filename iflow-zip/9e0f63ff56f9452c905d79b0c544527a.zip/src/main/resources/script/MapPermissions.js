importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var userPermissionSetsAssigned = String(message.getProperty('UserPermissionSetsAssigned'));
  var messageLog = messageLogFactory.getMessageLog(message);
  body = JSON.parse(body);
  var permissionSetUris = filterPermissions(userPermissionSetsAssigned, body.d);
  var logMessageResponse = message.getProperty('LogMessageResponse');
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('User PermissionSetUris:', permissionSetUris, 'text/json');
  }
  message.setProperty('userPermissionSetsUris', permissionSetUris);
  message.setBody('{}');
  return message;
}


function filterPermissions(permissionNames, permissionSets) {
  var permissionSetUris = [];
  var permissionNamesArray = permissionNames.split(',');
  permissionNamesArray.forEach(function(permissionName) {
    var permissionEntry = permissionSets.filter(function(p) {
      return compareStringIgnoreCase(p.name, permissionName.trim());
    });
    if (permissionEntry && permissionEntry[0] && permissionEntry[0].uri) {
      permissionSetUris.push(permissionEntry[0].uri);
    }
  });
  return permissionSetUris.join();
}

function compareStringIgnoreCase(str1, str2) {
  return (str1 && str2) ? str1.equalsIgnoreCase(str2) : false;
}