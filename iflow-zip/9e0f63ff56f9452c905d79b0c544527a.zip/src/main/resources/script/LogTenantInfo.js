importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var repliconToken = message.getProperty('Token');
  var repliconBaseUrl = message.getProperty('BaseUrl');
  var repliconTenant = message.getProperty('Tenant');
  var messageLog = messageLogFactory.getMessageLog(message);
  var messageString = 'Token ' + repliconToken + ' RepliconBaseUrl ' + repliconBaseUrl + ' Replicon Tenant ' + repliconTenant;
  var logMessageProperty = message.getProperty('LogMessageResponse');
  if (messageLog && logMessageProperty && logMessageProperty.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('TenantMapInfo', messageString, 'text/json');
  }

  return message;
}