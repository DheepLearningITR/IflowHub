importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageResponse = message.getProperty('LogMessageResponse');
  var logMessageRequest = message.getProperty('LogMessageRequest');
  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('CreateOEFResponseBody:', body, 'text/json');
  }
  body = JSON.parse(body);
  var oefUri = body.d.uri;
  var json = {
    objectExtensionDefinitionUri: oefUri,
    bindingContextUri: 'urn:replicon:object-type:project'
  };
  if (messageLog && logMessageRequest && logMessageRequest.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('BindOEFRequest:', JSON.stringify(json), 'text/json');
  }
  message.setBody(JSON.stringify(json));
  return message;
}