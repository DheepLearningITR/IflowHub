importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var messageLog = messageLogFactory.getMessageLog(message);
  var webhookSubscriptionId = String(message.getProperty('webhookSubscriptionId'));
  var logMessageResponse = message.getProperty('LogMessageResponse');
  webhookSubscriptionId = !webhookSubscriptionId ? 'null' : webhookSubscriptionId;

  var query = 'mutation DeleteSubscription($id: String!) {\n  deleteWebhookSubscription(input: {id: $id}) {\n    id\n  }\n}\n';

  var requestData = JSON.stringify({
    operationName: 'DeleteSubscription',
    variables: {
      id: webhookSubscriptionId
    },
    query: query
  });

  if (messageLog && logMessageResponse && logMessageResponse.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Timesheet Delete Event requestData:', requestData, 'text/json');
  }

  message.setBody(requestData);

  return message;
}