importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var globalVariables = [ 'Validate_Root_Department', 'Validate_ProjectSyncOnlyOpenProjects', 'Validate_UserPermissionSetsAssigned', 'Validate_UserTemplatesAssigned', 'Validate_HanaUrl', 'Validate_UserSyncDate', 'Validate_ProjectControllingAreaOEFName', 'Validate_PolarisCompanyKey', 'Validate_ClientSyncDate', 'Validate_ProjectSyncDate', 'Validate_PolarisTenant', 'Validate_PolarisBaseUrl', 'Validate_PolarisToken', 'webhookSubscriptionId', 'Validate_UserTimesheetApprovalPath' ];
  var overwriteGlobalVariables = String(message.getProperty('Overwrite_Global_Variables'));
  message = validateGlobalVariables(globalVariables, message, overwriteGlobalVariables);
  return message;
}

function validateGlobalVariables(globalVariables, message, overwriteGlobalVariables) {
  var variableValue = '';
  var isGlobalVariableNull = false;
  for (var key in globalVariables) {
    variableValue = String(message.getProperty(globalVariables[key]));
    if (!variableValue) {
      isGlobalVariableNull = true;
      break;
    }
  }
  if (isGlobalVariableNull || (overwriteGlobalVariables && overwriteGlobalVariables.equalsIgnoreCase('yes'))) {
    message.setHeader('overwriteGlobalVars', 'Yes');
  } else {
    message.setHeader('overwriteGlobalVars', 'No');
  }
  return message;
}
