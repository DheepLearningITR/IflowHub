import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.pd.PartnerDirectoryService
import groovy.transform.Field
import groovy.util.slurpersupport.GPathResult
import groovy.xml.XmlUtil
import org.slf4j.Logger
import org.slf4j.LoggerFactory

@Field String LOG_ID = 'PLANT_VALUE_MAPPING';
@Field static final String PROPERTY_ENDPOINT_ID = "ENDPOINT_ID";
@Field static final String PD_PARAMETER_ENABLE_PLANT_CONVERSION = "ENABLE_PLANT_CONVERSION";
@Field static final String PARTNER_ID_PREFIX = "DME_Generic_Processing_";
@Field static final String VM_AGENCY_ERP = "ERP";                                       //Agency of ERP
@Field static final String VM_IDENTIFIER_ERP_WERKS = "WERKS";                           //Identifier of ERP
@Field static final String VM_AGENCY_DMC = "DMC";                                       //Agency of DMC
@Field static final String VM_IDENTIFIER_DMC_PLANTS = "PLANT";                          //Identifier of DMC
@Field static final String[] ERP_PAYLOAD_FIELDS = ['PLWRK', 'WERKS', 'MAINTPLANT', 'PLANPLANT']; //Names of ERP fields which require value mapping
@Field static final String[] DMC_PAYLOAD_FIELDS = ['site', 'plant'];                             //Names of DMC fields which require value mapping
@Field static final String[] IDOC_PARTNER_NO_FIELDS = ['SNDPRN'];
@Field static final String ERP_DESTINATION = "ErpDestination";
@Field Logger log = LoggerFactory.getLogger("com.sap.cpi.metviewer." + LOG_ID);

Message processData(Message message) {

    String endpointId = message.getProperty(PROPERTY_ENDPOINT_ID);
    String partnerId = PARTNER_ID_PREFIX + endpointId;

    PartnerDirectoryService pd = ITApiFactory.getService(PartnerDirectoryService.class, null);
    if (pd == null) {
        throw new IllegalStateException("Partner Directory Service not found");
    }
    boolean enablePlantConversion = toBoolean(pd.getParameter(PD_PARAMETER_ENABLE_PLANT_CONVERSION, partnerId, String.class));
    if (enablePlantConversion) {
        executePlantConversion(message);
    }

    return message;
}

private void executePlantConversion(Message message) {

    String vmSourceAgency;
    String vmSourceIdentifier;
    String vmTargetAgency;
    String vmTargetIdentifier;
    String[] fields;
    String prefix;

    ValueMappingApi vm = ITApiFactory.getService(ValueMappingApi.class, null);
    Reader payload = message.getBody(java.io.Reader);
    GPathResult root; 
    try{
    root = new XmlSlurper().parse(payload);
    }catch(org.xml.sax.SAXParseException e){
        message.setProperty("ExceptionMessage", "Plant conversion illegal payload please check previous step");
        return;
    }

    if (root.IDOC.isEmpty()) {                        //Source system is DMC; target system is ERP
        vmSourceAgency = VM_AGENCY_DMC;
        vmSourceIdentifier = VM_IDENTIFIER_DMC_PLANTS;
        vmTargetAgency = VM_AGENCY_ERP;
        vmTargetIdentifier = VM_IDENTIFIER_ERP_WERKS;
        fields = DMC_PAYLOAD_FIELDS;
        /**String [] parnters = IDOC_PARTNER_NO_FIELDS;
         partners.each{ String tag ->
         List<GPathResult> searchResult = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase(tag) && it.children().size() == 0 && it.next()!=null && it.next()!=""; }if(!searchResult.isEmpty()){prefix = searchResult[0];}}**/

    } else {                                        //Source system is ERP; target system is DMC
        vmSourceAgency = VM_AGENCY_ERP;
        vmSourceIdentifier = VM_IDENTIFIER_ERP_WERKS;
        vmTargetAgency = VM_AGENCY_DMC;
        vmTargetIdentifier = VM_IDENTIFIER_DMC_PLANTS;
        fields = ERP_PAYLOAD_FIELDS;

        String[] partners = IDOC_PARTNER_NO_FIELDS;

        partners.each { String tag ->
            List<GPathResult> searchResult = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase(tag) && it.children().size() == 0 && it.text() != null && it.text() != ""; }
            if (!searchResult.isEmpty()) {
                prefix = searchResult[0];
            }
        }

    }

    fields.each { String tag ->
        List<GPathResult> searchResult = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase(tag) && it.children().size() == 0; }
        if (!searchResult.isEmpty()) {
            searchResult.each { GPathResult it ->
                String plantSourceValue = it.text();

                String plantTargetValue = vm.getMappedValue(vmSourceAgency, vmSourceIdentifier, prefix + ":" + plantSourceValue, vmTargetAgency, vmTargetIdentifier);

                if (!plantTargetValue) {
                    plantTargetValue = vm.getMappedValue(vmSourceAgency, vmSourceIdentifier, plantSourceValue, vmTargetAgency, vmTargetIdentifier);
                }

                if (plantTargetValue) {
                    try {
                        plantTargetValue = plantTargetValue.split(":")[1];
                    } catch (java.lang.ArrayIndexOutOfBoundsException ex) {
                        //log.error("Can't split the plant value ", plantTargetValue);
                    }
                    it.replaceBody(plantTargetValue);
                }
            }
        }
    }

    message.setBody(XmlUtil.serialize(root));
}

private boolean toBoolean(String value) {

    if (value != null) {
        if ("TRUE".equalsIgnoreCase(value)) {
            return true;
        }
    }
    return false;
}