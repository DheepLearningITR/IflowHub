
/**
 * This script processes a CSV input and fixes malformed double quotes in each line.
 * It ensures that quotes within fields are properly escaped (by doubling them)
 * to maintain valid CSV structure and prevent parsing errors downstream.
 */

import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    def csvText = message.getBody(String)
    def reader = new BufferedReader(new StringReader(csvText))
    def result = new StringBuilder()

    reader.eachLine { line ->
        result.append(fixMalformedQuotes(line)).append("\n")
    }

    message.setBody(result.toString())
    return message
}

String fixMalformedQuotes(String line) {
    StringBuilder fixedLine = new StringBuilder()
    boolean inField = false // Tracks if we are currently inside a quoted CSV field

    for (int i = 0; i < line.length(); i++) {
        char current = line.charAt(i)

        if (current == '"') {
            if (i == 0 || (i > 0 && line.charAt(i - 1) == ',')) {
                // This could be the start of a new field, or a standalone quote
                // We assume it's the start of a field
                inField = true
                fixedLine.append('"')
            } else if (i == line.length() - 1 || (i < line.length() - 1 && line.charAt(i + 1) == ',')) {
                // This could be the end of a field
                inField = false
                fixedLine.append('"')
            } else {
                // This is a double quote encountered WITHIN a field.
                // It should be escaped by doubling it.
                fixedLine.append('""')
            }
        } else {
            fixedLine.append(current)
        }
    }
    return fixedLine.toString()
}