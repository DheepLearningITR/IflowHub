import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi


def Message processData(Message message) 
{
    //Properties
    def properties = message.getProperties();
    def SFObject = properties.get("SFObject");
    
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def value = valueMapApi.getMappedValue('Salesforce', 'EntityName', SFObject, 'Signavio', 'StartDate')
    message.setProperty("PreDefinedStartDate", value );
    
    def value2 = valueMapApi.getMappedValue('Salesforce', 'EntityName', SFObject, 'Salesforce', 'QueryFilter')
    message.setProperty("QueryFilter", value2 );
    
    return message;
}