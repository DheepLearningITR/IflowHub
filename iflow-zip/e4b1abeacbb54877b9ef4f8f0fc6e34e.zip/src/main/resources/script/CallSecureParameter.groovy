/*
 * =============================================================================
 * Logic Details 
 * =============================================================================
 * This script retrieves a password from a secure store service based on a provided credential name and sets it as a message property.

 * It retrieves a password from the secure store service based on the provided credential name and sets it as a message property.

 * ==============================================================================
*/

import com.sap.gateway.ip.core.customdev.util.Message
//import java.security.MessageDigest
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
//import com.sap.it.api.securestore.UserCredential;

def Message processData(Message message) {

    // Retrieve the dynamic column names from message properties
    def properties = message.getProperties()
    def lv_credential_Name = properties.get("Security_Material");
    
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential(lv_credential_Name);

    if (credential == null)
    {
        throw new IllegalStateException("No credential found");
    }

    String lv_password = new String(credential.getPassword());

    message.setProperty("PWD", lv_password);

    // Return the modified message
    return message
}