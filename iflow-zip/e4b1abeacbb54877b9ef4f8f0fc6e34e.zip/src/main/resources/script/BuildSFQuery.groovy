/*
 * =============================================================================
 * Logic Details 
 * =============================================================================
 *   The Groovy script dynamically generates a `WHERE` clause based on specific properties provided in the SAP message, utilizing the SAP Gateway Message class to access and set these properties. The main function, `processData`, takes a Message object as input and retrieves properties such as `Adhoc_StartDate (3)`, `ExecuteFullLoad (1)`, `last_run (4)`, and `PreDefinedStartDate (2)` from the message. It constructs a `WHERE` clause by considering conditions such as whether to execute a full load, whether a predefined start date is specified, and whether to use an ad-hoc or externalized last modified date. If `ExecuteFullLoad` is true, the load type is set to "FullLoad"; otherwise, it defaults to "DeltaLoad". Depending on the presence of specific dates and the type of object specified by `SFObject`, the script constructs the `WHERE` clause using `CreatedDate` or `LastModifiedDate`. Additionally, if a `QueryFilter` is provided, it appends this to the `WHERE` clause, handling full loads specifically. The generated `WhereClause` is then set as a property on the message. The script also extends the query for specific objects: for "Lead", it adds a subquery for `CampaignMembers`, and for "Task", it includes fields related to `Who` and `What`. Furthermore, it constructs an `ExtendedWhereClause` for "Task", adding a condition for `Who.Type` and `What.Type`. These extended query properties are then set on the message, and the modified message is returned.
 * Priorities of the if statements is mentioned beside the property names.
 * ==============================================================================
*/

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    			
        def properties = message.getProperties();
		def Adhoc_StartDate = properties.get("Adhoc_StartDate");
		def ExecuteFullLoad = properties.get("ExecuteFullLoad");
		def LastRun = properties.get("last_run");
		def PreDefinedStartDate = properties.get("PreDefinedStartDate");
		def SFObject = properties.get("SFObject");
		def QueryFilter = properties.get("QueryFilter");
		def LoadType = "";
		def LastModified = "";
		
        
		StringBuffer str1 = new StringBuffer();
	
		if(ExecuteFullLoad != null && ExecuteFullLoad.equalsIgnoreCase("TRUE"))
		{
		    str1.append();         // 1
		    LoadType = "FullLoad"
		}
		else
		{   
		    LoadType = "DeltaLoad"
		    if(PreDefinedStartDate == null || PreDefinedStartDate.equals(""))
		        {

                    if(Adhoc_StartDate == '')
                        {
                            //Assign last_run Date from variable
                            LastModified = LastRun; 
                                if(SFObject.toString().contains("History") && !SFObject.toString().contains("__c"))
                                    {
                                        str1.append("WHERE CreatedDate >= "+LastModified+"");
                                    }
                                else
                                    {
                                        str1.append("WHERE LastModifiedDate >= "+LastModified+"");
                                    }
                        }
                    else
                        {
                            //Assign last_run Date from Externalized variable
                            LastModified = Adhoc_StartDate;  
                                    if(SFObject.toString().contains("History") && !SFObject.toString().contains("__c"))
                                    {
                                        str1.append("WHERE CreatedDate >= "+LastModified+"");
                                    }
                                    else
                                    {
                                        str1.append("WHERE LastModifiedDate >= "+LastModified+"");
                                    }
                        }
		        }
		    else
		        {
		            //Assign last_run Date from Value Mapping
		            LastModified = PreDefinedStartDate;                         
                                if(SFObject.toString().contains("History") && !SFObject.toString().contains("__c"))
                                    {
                                        str1.append("WHERE CreatedDate >= "+LastModified+"");
                                    }
                                else
                                    {
                                        str1.append("WHERE LastModifiedDate >= "+LastModified+"");
                                    }
		        }
        
		}
		
		if (QueryFilter != null && !QueryFilter.isEmpty()) 
		{
            if (LoadType == "FullLoad") 
            {
                str1.append(" WHERE " +QueryFilter+"");
            } 
            
            else 
            {
                 str1.append(" AND " +QueryFilter+"");
            }
        }

		
		

		def whereClause = str1.toString()
		

	    if(!str1.toString().isEmpty())
	    {
			message.setProperty("WhereClause","  "+whereClause);
		}
		else
		{
			message.setProperty("WhereClause","  "+whereClause);
		}
		
		StringBuffer str2 = new StringBuffer();
		
		if(SFObject == "Lead")
		{
		    str2.append(",(SELECT Id FROM CampaignMembers)")
		}
		else if(SFObject == "Task")
		{
		   str2.append(",TYPEOF Who WHEN Lead THEN Id,Name END, TYPEOF What WHEN Opportunity THEN Id,Name END") 
		}
		
		StringBuffer str3 = new StringBuffer();
		
		if(SFObject == "Task")
		{
            if (LoadType == "FullLoad") 
            {
		        str3.append(" Where (Who.Type ='Lead' OR What.Type ='Opportunity')")
            }
            else
            {
                str3.append(" AND (Who.Type ='Lead' OR What.Type ='Opportunity')")   
            }
		}
		
		
		def ExtendedQuery = str2.toString()
		
		if(!str2.toString().isEmpty())
	    {
			message.setProperty("ExtendedQuery","  "+ExtendedQuery);
		}
		else
		{
			message.setProperty("ExtendedQuery","  "+ExtendedQuery);
		}
		
		def ExtendedWhereClause = str3.toString()
		
		if(!str3.toString().isEmpty())
	    {
			message.setProperty("ExtendedWhereClause","  "+ExtendedWhereClause);
		}
		else
		{
			message.setProperty("ExtendedWhereClause","  "+ExtendedWhereClause);
		}
		
	message.setProperty("LoadType", LoadType)
	
    return message;
}
