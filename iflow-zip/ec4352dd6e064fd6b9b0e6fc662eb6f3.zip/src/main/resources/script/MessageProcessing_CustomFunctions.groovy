import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import org.codehaus.groovy.runtime.EncodingGroovyMethods;
import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import java.util.Base64;
import java.security.*

def Message replaceTmp(Message message) {
    def body_in = message.getBody(java.lang.String);
    def body_replace = body_in.replaceAll("tmp_", "");
    message.setBody(body_replace);
    return message;
}

def Message setQuery(Message message) {

    //get Header
    def map = message.getHeaders();
    def httpMethod = map.get("CamelHttpMethod");
    //get property
    map = message.getProperties();
    def create_if_not_exists = map.get("create_if_not_exists");

    if (httpMethod == 'PUT') {
        message.setProperty("query", "create_if_not_exists=" + create_if_not_exists);
        return message;
    } else {
        return message;
    }

}

def Message XWSSEHeader(Message message) {

    // X-WSSE: UsernameToken Username="name", PasswordDigest="digest", Created="timestamp", Nonce="nonce"
    //
    //  * Username- The username that the user enters (the TypePad username).
    //  * Nonce. A secure token generated anew for each HTTP request.
    //  * Created. The ISO-8601 timestamp marking when Nonce was created.
    //  * PasswordDigest. A SHA-1 digest of the Nonce, Created timestamp, and the password
    //    that the user supplies, base64-encoded. In other words, this should be calculated
    //    as: base64(sha1(Nonce . Created . Password))

    //nonce - Generate a random 16-byte nonce in the 32-character hexadecimal format.
    byte[] nonceBytes = new byte[16];
    new Random().nextBytes(nonceBytes);
    def nonceHex = nonceBytes.encodeHex().toString();

    //Timestamp - Get the current timestamp in ISO 8601 format.
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
    sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
    def timestamp = sdf.format(new Date())

    //Secret - Get Secret from Security Artifact
    //Properties
    map = message.getProperties();
    artifactAlias = map.get("securityArtifact");
    //Get the Service Instance of the SecureStoreService API
    def service = ITApiFactory.getService(SecureStoreService.class, null);
    //Read the credential of a given alias
    def credential = service.getUserCredential(artifactAlias);
    //Read the User Name or password
    def APIUser = credential.getUsername();
    def secret = credential.getPassword();

    //Password Digest
    def passwordDigest = nonceHex + timestamp + secret;

    MessageDigest passwordDigestAlg = MessageDigest.getInstance("SHA-1");
    byte[] passwordDigestSHA1 = passwordDigestAlg.digest(passwordDigest.getBytes("UTF-8"));
    def passwordDigestSHA1Res = new BigInteger(1, passwordDigestSHA1).toString(16);
    def passwordDigestsha1Base64 = passwordDigestSHA1Res.bytes.encodeBase64().toString();

    message.setProperty("passwordDigest", passwordDigestsha1Base64);


    //X-WSSE Header
    def headerValue = "UsernameToken Username=\"" + APIUser + "\",PasswordDigest=\"" + passwordDigestsha1Base64 + "\",Created=\"" + timestamp + "\",Nonce=\"" + nonceHex + "\""
    def map = message.getHeaders();
    message.setHeader("X-WSSE", headerValue);

    return message
}
