import com.sap.it.api.mapping.*

def String mappingParameters(String key, MappingContext context) {
    String content = context.getProperty(key)
	return content != null ? content : ""
}