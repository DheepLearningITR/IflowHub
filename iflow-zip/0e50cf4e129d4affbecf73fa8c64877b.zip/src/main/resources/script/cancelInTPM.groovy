import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput
import groovy.util.*

import java.util.*;
import groovy.xml.*;
import java.time.LocalDateTime;
import groovy.util.slurpersupport.GPathResult
import org.w3c.dom.NodeList;


def Message sleepTime(Message message) {
    
    //Properties
    def properties = message.getProperties();
    def sleepTime = properties.get("sleepTime") as Integer;
    def retryCount = properties.get("retryCount") as Integer;
    
    if(retryCount != 0){
        new Object().sleep(sleepTime*1000);
    }

    return message;
}

def Message addCurrentTranIntoTrans(Message message) {
    def bodyVal = message.getBody(java.lang.String) as String;
    def properties = message.getProperties()
    
    def parser = new XmlParser()

    def transRootNodeStr = properties.get("transRootNode");
    def transRootNode
    
    if(transRootNodeStr == null){
        transRootNode = new Node(null, "trans")
    }else{
        transRootNode = parser.parseText(transRootNodeStr)
    }
    
  
    def dom = parser.parseText(bodyVal)


    def tpmReqStr = properties.get("tpmReqStr")
    def retryNum = properties.get("retryCount") as Integer

    def documentType = properties.get("documentType") as String
    Map attributes = new HashMap();
    attributes.put("api", documentType)
    attributes.put("callOrder", retryNum)
    
    def tranNode = new Node(transRootNode, "tran", attributes)
    
    def requestNode = new Node(tranNode, "request")
    
    def paramsNode = new Node(requestNode, "params")
    def bodyNode = new Node(requestNode, "body")
    bodyNode.append(parser.parseText(tpmReqStr))
    
    def responseNode = new Node(tranNode, "response")
    responseNode.append(dom)


    message.setProperty("transRootNode", XmlUtil.asString(transRootNode));


    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null)
    {
        messageLog.addAttachmentAsString("Log current transRootNode:", XmlUtil.asString(transRootNode), "text/plain");
    }

    return message;
}

def Message handleTPMResponse(Message message) {
    //Body
    def body = message.getBody() as String;

    //Properties
    def properties = message.getProperties();
    
    //set retry count
    def retryCount = properties.get("retryCount") as Integer;
    retryCount = retryCount + 1;
    message.setProperty("retryCount", retryCount);
    
    def parser = new XmlParser()
    def dom = parser.parseText(body)
    
    //is retry ?
    def retryRet = isRetry(body, dom)
    message.setProperty("isRetry", retryRet);
  
    
    //add documentTransactions
    if(!retryRet){
        message.setProperty("errorMsg", "")
        def documentTypeStr = properties.get("documentType") as String;
        message.setProperty("documentTransactions", generateDocumentTransactions(dom, documentTypeStr));
    } else{
        String errorContent = setErrorMsg(body, dom, message)
        message.setProperty("errorMsg", errorContent)
    }
    
    
    return message;
}

String generateDocumentTransactions(Node dom, String documentTypeStr){
    String createdOnStr = LocalDateTime.now().toString();

    Set<String> documentNumbers = new HashSet<>();

    def items = dom.ET_SETTLEMENT_RETURN.item;
    for (final def item in items) {
        documentNumbers.add(item.BILL_DOC_ID.text())
    }
    
    //build documentTransactions xml
    def documentTransactionsStr = new StringWriter()
    def builder = new MarkupBuilder(documentTransactionsStr)

    for (final def d in documentNumbers) {
        builder.documentTransactions{
            documentNumber(d)
            documentType(documentTypeStr)
            fiscalYear('')
            createdOn(createdOnStr)
            companyCode('')
        }
    }
    
    return documentTransactionsStr.toString()
}

String setErrorMsg(String body, Node dom, Message message){
    String defaultMsg = "cancel tpm failed"
    
    if (body == null || body == ""){
        return defaultMsg;
    }

    def name = dom.name()
    
    if (dom.name().localPart != 'CRM_CICLOUD_CLA_BD_CANCEL.Response') {
        return defaultMsg
    }
    
    List<String> errorResultLogs = new ArrayList<>()
    
    def settlementReturn = dom."**".find({it.name()=='ET_SETTLEMENT_RETURN'})
    
    if (settlementReturn){
        for( it in settlementReturn.item){
            if(it.ERROR.text().length() != 0){
                 errorResultLogs.add(logError(it))
            }
        }
    }
    
    def settlementMsg = dom."**".find({it.name()=='ET_SETTLEMENT_MSG'})
    
    if (settlementMsg){
        for( it in settlementMsg.item){
            if(it.ERROR.text().length() != 0){
                 errorResultLogs.add(logError(it))
            } 
        }
    }

    
    if(errorResultLogs.size() != 0){

        StringBuffer errorMessages = new StringBuffer();

        errorResultLogs.each{ error -> errorMessages.append(error+ "\n\n");}

        String errorMes = errorMessages.toString()
        def messageLog = messageLogFactory.getMessageLog(message)
        messageLog.addAttachmentAsString("errorMessages content", errorMes, "text/plain") 
        return errorMes
    }
    
    return dom.ET_SETTLEMENT_MSG.item.MESSAGE.text() 
}


def logError(Node item){
    String billDocId = item.BILL_DOC_ID.text()
    String errorMessage = item.ERROR.text()
    String itemNumber = item.ITEM_NUMBER.text()

    StringBuffer content = new StringBuffer();

    if(itemNumber != null && itemNumber.trim().length() > 0){
        content.append("ITEM_NUMBER: " + itemNumber + " ");
    }

    if(billDocId != null && billDocId.trim().length() > 0){
        content.append("BILL_DOC_ID: " + billDocId + " ");
    }


    if(errorMessage != null && errorMessage.trim().length() > 0){

        content.append("error: " + errorMessage);
    }

    return content.toString()
}

def logErrorMessage(Node item, Message message){
    def errorLog = new XmlSlurper().parseText("<error/>")
    String error = item.MESSAGE.text()
   
    errorLog.appendNode{
        errorMessage(error)
    }
    return errorLog
}


boolean isRetry(String body, Node dom){
    if (body == null || body == ""){
        return true;
    }

    def name = dom.name()
    if (dom.name().localPart != 'CRM_CICLOUD_CLA_BD_CANCEL.Response') {
        return true
    }
    
    if(dom.ET_SETTLEMENT_RETURN == null || dom.ET_SETTLEMENT_RETURN.size() == 0) {
        return true
    }
    
    if (dom.ET_SETTLEMENT_RETURN.item == null || dom.ET_SETTLEMENT_RETURN.item.size() == 0) {
        return true
    }
    
    for (def node : dom.ET_SETTLEMENT_RETURN[0].value()) {
        if (node.BILL_DOC_ID.text() == null
                || node.BILL_DOC_ID.text().isEmpty()
                || (node.ERROR[0] != null && !node.ERROR[0].text().isEmpty())) {
            return true
        }
    }

    return false;
}

def logLoopException(Message message){
     def properties = message.getProperties();
     String exception = properties.get("CamelExceptionCaught") as String
     def messageLog = messageLogFactory.getMessageLog(message)
     messageLog.addAttachmentAsString("exception in loop", exception, "text/plain")
    return message    
}


def Message processLog(Message message) {
    //Body

    //Headers
    def headers = message.getHeaders() as String;
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null)
    {
        messageLog.addAttachmentAsString("Log output Payload:", body, "text/plain");
        messageLog.addAttachmentAsString("Log output headers:", headers, "text/plain");
    }

    return message;
}

def Message setTPMRequestProperty(Message message) {
    //Headers
    def headers = message.getHeaders() as String;
    //Body
    def body = message.getBody(java.lang.String) as String;
    
    // def tpmReqStr = body.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "")
    
    def properties = message.getProperties() as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    
    message.setProperty("tpmReqStr", body)
    
    if(messageLog != null)
    {
        messageLog.addAttachmentAsString("Log tpm request Payload:", body, "text/plain");
        messageLog.addAttachmentAsString("Log tpm request headers:", headers, "text/plain");
        messageLog.addAttachmentAsString("Log tpm request properties:", properties, "text/plain");
    }

    return message;
}

def Message logException(Message message) {
    def headers = message.getHeaders() as String;
    def body = message.getBody(java.lang.String) as String;
    
    def map = message.getProperties();
    def ex = map.get("CamelExceptionCaught");
    
    //throw new Exception("test Exception");
    
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null)
    {
        messageLog.addAttachmentAsString("exception output details:", ex.toString(), "text/plain");
        messageLog.addAttachmentAsString("exception output Payload:", body, "text/plain");
        messageLog.addAttachmentAsString("exception output headers:", headers, "text/plain");
    }

    return message;
}

def Message printDbLog(Message message) {
    def headers = message.getHeaders() as String;
    def body = message.getBody(java.lang.String) as String;
    
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null)
    {
        messageLog.addAttachmentAsString("Log db Payload:", body, "text/plain");
        messageLog.addAttachmentAsString("Log db headers:", headers, "text/plain");
    }

    return message;
}

