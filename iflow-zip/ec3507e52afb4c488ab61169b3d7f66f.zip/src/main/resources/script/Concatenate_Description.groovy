import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    def xmlInput = message.getBody(java.lang.String)
    def parsedXml = new XmlParser().parseText(xmlInput)

    def concatenatedText = parsedXml.ProductMDMReplicateRequestMessage.Product.TextCollection.Text.SAPScriptLine.SAPScriptLineText*.text().join(' ')
    
    if (concatenatedText.length() >= 3000) {
        // Truncate the text to be within the limit
        concatenatedText = concatenatedText.substring(0, 3000)
    }
   
    message.setProperty("SAPScriptLineText", concatenatedText);
    return message
}