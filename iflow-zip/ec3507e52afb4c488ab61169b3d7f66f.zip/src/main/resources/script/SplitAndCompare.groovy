import com.sap.it.api.mapping.*;

def String splitAndCompare(String input, String target) {
	if (input == null || input.isEmpty() || target == null || target.isEmpty()) {
        return "false";
    }
    
    def result = input.tokenize(',');
    if (result == null || result.isEmpty()) {
        return "false";
    }
    
    for (item in result) {
        if (item.trim().equalsIgnoreCase(target)) {
            return "true";
        }
    }
    return "false";
    
}