import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def inputPayload = new JsonSlurper().parse(json)
    def eventsDataArray = []
    def endPayLoad = [:]

    message.setHeader('hasDeliverEventsData','N')

    // Only work on data if a Deliver Event is present
    if (inputPayload.EventPackage.DeliverSerialNumberEvents == null && inputPayload.EventPackage.DeliverEvents == null) {
        return message
    }    
        
    // DeliverEvents
    if (inputPayload.EventPackage.DeliverEvents) {
        message.setHeader('hasDeliverEventsData','Y')
        if (inputPayload.EventPackage.DeliverEvents instanceof List) {
            inputPayload.EventPackage.DeliverEvents.each {
                createDeliverEventsData(eventsDataArray, 'batch', it)
            }
        } else {
            createDeliverEventsData(eventsDataArray, 'batch', inputPayload.EventPackage.DeliverEvents)
        }
    }

    // DeliverSerialNumberEvents
    if (inputPayload.EventPackage.DeliverSerialNumberEvents) {
        message.setHeader('hasDeliverEventsData','Y')
        if (inputPayload.EventPackage.DeliverSerialNumberEvents instanceof List) {
            inputPayload.EventPackage.DeliverSerialNumberEvents.each {
                createDeliverEventsData(eventsDataArray, 'serial', it)
            }
        } else {
            createDeliverEventsData(eventsDataArray, 'serial', inputPayload.EventPackage.DeliverSerialNumberEvents)
        }
    }

    endPayLoad.events = eventsDataArray
    def aasJson = new JsonBuilder(endPayLoad)

    message.setBody(aasJson.toPrettyString())
    return message
}

def createDeliverEventsData(def eventsDataArray, def type, def inDeliverEvents){
    def key = new StringBuilder()
    if (type == 'serial') {
        key.append(inDeliverEvents.SerialNumbers.SerialID).append('_').append(inDeliverEvents.ProductID).append('_').append(inDeliverEvents.SystemID)
    } else {
        key.append(inDeliverEvents.VendorBatchID).append('_').append(inDeliverEvents.ProductID).append('_').append(inDeliverEvents.SystemID)
    }
    def eventsDataMap = [:]
	def event = eventsDataArray.find{it.id == key.toString()}
	boolean eventAlreadyExists = false
	if(event) {
		eventsDataMap = event
		eventAlreadyExists = true
	}
    eventsDataMap.type = type
    eventsDataMap.id = key.toString()
    eventsDataMap.systemId = inDeliverEvents.SystemID
    if (type == 'serial') {
        eventsDataMap.partInstanceId = inDeliverEvents.SerialNumbers.SerialID
    } else {
        eventsDataMap.batchId = inDeliverEvents.VendorBatchID
        eventsDataMap.partInstanceId = inDeliverEvents.VendorBatchID
    }
    eventsDataMap.manufacturerPartId = inDeliverEvents.ProductID
    if (inDeliverEvents.CustomerProductID) {
        eventsDataMap.customerProductID = inDeliverEvents.CustomerProductID
    }
    eventsDataMap.customerBPN = getKeyAssignments(inDeliverEvents.KeyAssignments, 'CATENA_X_CUSTOMER')
    eventsDataMap.assemblyPartRelation = 'N'
    if(!eventAlreadyExists){
        eventsDataArray << eventsDataMap
    }
}

def getKeyAssignments(def keyAssignments, def qualifier) {
    def  res = ''
    if (keyAssignments) {
        if (keyAssignments instanceof List) {
            keyAssignments.each {
                if (it.Qualifier == qualifier) {
                    res = it.Value
                }
            }
	    }else {
	        if (keyAssignments.Qualifier == qualifier) {
                res = keyAssignments.Value
	        } else {
                res = ''
            }
        }
    } else {
        res = ''
    }
    return res
}
