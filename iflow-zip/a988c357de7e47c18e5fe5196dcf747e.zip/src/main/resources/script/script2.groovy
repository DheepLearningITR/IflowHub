import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    def payLoadMap = [:]

    input.own_bpn = message.getProperties().get('OWN_BPN')
    getDescription(payLoadMap, input.productName)
    getGlobalAssetId(payLoadMap, input, message)
    payLoadMap.displayName = []  
    def parentIdent = UUID.randomUUID().toString()
    StringBuilder sb = new StringBuilder()
    sb.append('urn:uuid:').append(parentIdent)
    payLoadMap.idShort = 'digitalTwinRecord' 
    payLoadMap.id = sb.toString()
    getSpecificAssetIds(payLoadMap,input)
    def submodelDescriptorsArray = []
    getSubmodelDescriptors(submodelDescriptorsArray, message, input, input.type)
    if (input.components) {
        getSubmodelDescriptors(submodelDescriptorsArray, message, input, 'assembly')
    }
    payLoadMap.submodelDescriptors = submodelDescriptorsArray

    def aasJson = new JsonBuilder(payLoadMap)
    message.setBody(aasJson.toPrettyString())
    return message
}

def getDescription(def payLoad, def productName) {
    def descriptionArray = []
    def descriptionmap = [:]
    descriptionmap.language = 'en'
    descriptionmap.text = productName
    descriptionArray << descriptionmap
    payLoad.description = descriptionArray
}

def getGlobalAssetId(def payLoad, def input, def message) {
    StringBuilder sb = new StringBuilder()
    sb.append('urn:uuid:').append(input.globalAssetId)
    payLoad.globalAssetId = sb.toString()
    message.setHeader('globalAssetId', sb.toString())
}

def getSpecificAssetIds(def payLoad, def input) {
    def specificAssetIdsArray = []
    def specificAssetIdskeyValueMap = [:]

    specificAssetIdskeyValueMap = [:]
    specificAssetIdskeyValueMap.name = 'partInstanceId'
    specificAssetIdskeyValueMap.value = input.partInstanceId
    externalSubjectIdMap = [:]
    externalSubjectIdMap.type = 'ExternalReference'
    externalSubjectIdKeyArray = []
    externalSubjectIdKeyMap = [:]
    externalSubjectIdKeyMap.type = 'GlobalReference'
    externalSubjectIdKeyMap.value = 'PUBLIC_READABLE'
    externalSubjectIdKeyArray << externalSubjectIdKeyMap
    externalSubjectIdMap.keys = externalSubjectIdKeyArray
    specificAssetIdskeyValueMap.externalSubjectId = externalSubjectIdMap
    specificAssetIdsArray << specificAssetIdskeyValueMap

    if (input.type.equals('batch')) {
        batchMap = [:]
        batchMap.name = 'batchId'
        batchMap.value = input.partInstanceId
	    externalSubjectIdMap = [:]
        externalSubjectIdMap.type = 'ExternalReference'
        externalSubjectIdKeyArray = []
        externalSubjectIdKeyMap = [:]
        externalSubjectIdKeyMap.type = 'GlobalReference'
        externalSubjectIdKeyMap.value = 'PUBLIC_READABLE'
        externalSubjectIdKeyArray << externalSubjectIdKeyMap
        externalSubjectIdMap.keys = externalSubjectIdKeyArray
        batchMap.externalSubjectId = externalSubjectIdMap
        specificAssetIdsArray << batchMap
    }
    
    if (input.customerProductID && input.customerBPN) {
        specificAssetIdskeyValueMap = [:]
        specificAssetIdskeyValueMap.name = 'customerPartId'
        specificAssetIdskeyValueMap.value = input.customerProductID
        externalSubjectIdMap = [:]
        externalSubjectIdMap.type = 'ExternalReference'
        externalSubjectIdKeyArray = []
        externalSubjectIdKeyMap = [:]
        externalSubjectIdKeyMap.type = 'GlobalReference'
        externalSubjectIdKeyMap.value = input.customerBPN
        externalSubjectIdKeyArray << externalSubjectIdKeyMap
        externalSubjectIdMap.keys = externalSubjectIdKeyArray
        specificAssetIdskeyValueMap.externalSubjectId = externalSubjectIdMap
        specificAssetIdsArray << specificAssetIdskeyValueMap
    }

    if (input.own_bpn) {
        specificAssetIdskeyValueMap = [:]
        specificAssetIdskeyValueMap.name = 'manufacturerId'
        specificAssetIdskeyValueMap.value = input.own_bpn
    	externalSubjectIdMap = [:]
        externalSubjectIdMap.type = 'ExternalReference'
        externalSubjectIdKeyArray = []
        externalSubjectIdKeyMap = [:]
        externalSubjectIdKeyMap.type = 'GlobalReference'
        externalSubjectIdKeyMap.value = input.own_bpn
        externalSubjectIdKeyArray << externalSubjectIdKeyMap
        externalSubjectIdMap.keys = externalSubjectIdKeyArray
        specificAssetIdskeyValueMap.externalSubjectId = externalSubjectIdMap
        specificAssetIdsArray << specificAssetIdskeyValueMap
    }

    if (input.manufacturerPartId) {
        specificAssetIdskeyValueMap = [:]
        specificAssetIdskeyValueMap.name = 'manufacturerPartId'
        specificAssetIdskeyValueMap.value = input.manufacturerPartId
    	externalSubjectIdMap = [:]
        externalSubjectIdMap.type = 'ExternalReference'
        externalSubjectIdKeyArray = []
        externalSubjectIdKeyMap = [:]
        externalSubjectIdKeyMap.type = 'GlobalReference'
        externalSubjectIdKeyMap.value = 'PUBLIC_READABLE'
        externalSubjectIdKeyArray << externalSubjectIdKeyMap
        externalSubjectIdMap.keys = externalSubjectIdKeyArray
        specificAssetIdskeyValueMap.externalSubjectId = externalSubjectIdMap
        specificAssetIdsArray << specificAssetIdskeyValueMap
    }
    payLoad.specificAssetIds = specificAssetIdsArray
}

def getSubmodelDescriptors(def submodelDescriptorsArray, def message, def input, def event_type) {
    def descriptionArray = []
    def descriptionmap = [:]
    def submodelPartMap = [:]
    def edcDataPlaneServer = message.getProperties().get('EdcDataPlaneServer')
    def edcControlPlaneServer = message.getProperties().get('EdcControlPlaneServer')
    def idShort 
    def semanticIdValue
    def subprotocolId
    if (event_type.equals('assembly')) {
        descriptionmap.language = 'en'
        descriptionmap.text = 'Provides Single Level BOM as Built information'
        descriptionArray << descriptionmap
        semanticIdValue = message.getProperties().get('AAS_SemanticId_SingleLevelBomAsBuilt')
        def partString = semanticIdValue.split('#')
        idShort =  partString[1]
        subprotocolId = message.getProperties().get('Generic_AssetId_SingleLevelBomAsBuilt')
    } else if (event_type.equals('batch')) {
        descriptionmap.language = 'en'
        descriptionmap.text = 'Provides Batch information'
        descriptionArray << descriptionmap
        semanticIdValue = message.getProperties().get('AAS_SemanticId_Batch') 
        def partString = semanticIdValue.split('#')
        idShort =  partString[1]
        subprotocolId = message.getProperties().get('Generic_AssetId_Batch')
    } else if (event_type.equals('serial')) {
        descriptionmap.language = 'en'
        descriptionmap.text = 'Provides Serial Part information'
        descriptionArray << descriptionmap
        semanticIdValue = message.getProperties().get('AAS_SemanticId_SerialPart') 
        def partString = semanticIdValue.split('#')
        idShort =  partString[1]
        subprotocolId = message.getProperties().get('Generic_AssetId_SerialPart')
    }
    submodelPartMap.description = descriptionArray
    submodelPartMap.idShort = idShort
    def subid = UUID.randomUUID().toString()
    StringBuilder sb = new StringBuilder()
    sb.append('urn:uuid:').append(subid.trim())
    submodelPartMap.id = sb.toString()
    
    def semanticIdMap = [:]
    def semanticIdKeysMap = [:]
    def semanticIdKeysArray = []
    def securityAttributesMap = [:]
    def securityAttributesArray = []
    
    semanticIdKeysMap.type = "Submodel"
    semanticIdKeysMap.value = semanticIdValue
    semanticIdKeysArray << semanticIdKeysMap
    semanticIdMap.type = "ExternalReference"
    semanticIdMap.keys = semanticIdKeysArray
    submodelPartMap.semanticId = semanticIdMap
    submodelPartMap.displayName = []

    def endpointsArray = []
    def endpointsMap = [:]
    endpointsMap.interface = 'SUBMODEL-3.0'
    def protocolInformationMap = [:]
    sb = new StringBuilder()
    sb.append(File.separator).append('urn%3Auuid%3A').append(input.globalAssetId).append(File.separator)
    def urlPart = sb.toString()
    def queryPart = 'submodel'
    sb = new StringBuilder()
    sb.append(edcDataPlaneServer).append(urlPart).append(queryPart)
    protocolInformationMap.href = sb.toString()
    protocolInformationMap.endpointProtocol = 'HTTP'
    protocolInformationMap.endpointProtocolVersion = ['1.1']
    protocolInformationMap.subprotocol = "DSP"
    sb = new StringBuilder()
    sb.append('id=').append(subprotocolId).append(';dspEndpoint=').append(edcControlPlaneServer)
    protocolInformationMap.subprotocolBody = sb.toString()
    protocolInformationMap.subprotocolBodyEncoding = 'plain'
    securityAttributesMap.type = 'NONE'
    securityAttributesMap.key = 'NONE'
    securityAttributesMap.value = 'NONE'
    securityAttributesArray << securityAttributesMap
    protocolInformationMap.securityAttributes = securityAttributesArray
    endpointsMap.protocolInformation = protocolInformationMap
    endpointsArray << endpointsMap
    submodelPartMap.endpoints = endpointsArray
    submodelDescriptorsArray << submodelPartMap
}
