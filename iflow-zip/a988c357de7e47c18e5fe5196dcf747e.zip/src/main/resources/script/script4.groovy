import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    def collectDataRecord = message.getHeaders().get('collectDataRecord')

    if (input.relations.size() > 0) {
        def componentsArray = []
        input.relations.each {
            // Received Records
            if (it.fromEncodedKey) {
                collectDataRecord.assemblyPartRelation = 'Y'
                def fromEncodedKey = it.fromEncodedKey
                def objects = input.objects.find{ it.encodedKey == fromEncodedKey }
                if (objects.receivedBatch) {
                    collectDataRecord.vendorBPN = getKeyAssignments(objects.receivedBatch.deliveryItemKeys[0].keyAssignments, 'CATENA_X_VENDOR')
                    def componentsMap = [:]
                    componentsMap.BatchId = objects.receivedBatch.batchId
                    componentsMap.ProductId = objects.receivedBatch.productId
                    componentsMap.SystemId = objects.receivedBatch.systemId
                    componentsArray << componentsMap
                }
                if (objects.receivedSerializedProduct) {
                    collectDataRecord.vendorBPN = getKeyAssignments(objects.receivedSerializedProduct.keyAssignments, 'CATENA_X_VENDOR')
                    def componentsMap = [:]
                    componentsMap.SerialID = objects.receivedSerializedProduct.serialId
                    componentsMap.ProductId = objects.receivedSerializedProduct.productId
                    componentsMap.SystemId = objects.receivedSerializedProduct.systemId
                    componentsArray << componentsMap
                }
            }
            // Produced Records
            if (it.toEncodedKey) {
                collectDataRecord.assemblyPartRelation = 'Y'
                def toEncodedKey = it.toEncodedKey
                def objects = input.objects.find{ it.encodedKey == toEncodedKey }
                if (objects.producedBatch) {
                    collectDataRecord.globalAssetId = getKeyAssignments(objects.producedBatch.keyAssignments, 'CATENA_X_BATCH')
                    collectDataRecord.productName = objects.producedBatch.productName
                }
                if (objects.producedSerializedProduct) {
                    collectDataRecord.globalAssetId = getKeyAssignments(objects.producedSerializedProduct.keyAssignments, 'CATENA_X_PART')
                    collectDataRecord.productName = objects.producedSerializedProduct.productName
                }
            }
        }
        collectDataRecord.components = componentsArray
        message.setHeader('assemblyPartRelation',collectDataRecord.assemblyPartRelation)
    } else {
        if (input.objects instanceof List) {
            input.objects.each {
                if (it.producedBatch) {
                    collectDataRecord.globalAssetId = getKeyAssignments(it.producedBatch.keyAssignments, 'CATENA_X_BATCH')
                    collectDataRecord.productName = it.producedBatch.productName
                }
                if (it.producedSerializedProduct) {
                    collectDataRecord.globalAssetId = getKeyAssignments(it.producedSerializedProduct.keyAssignments, 'CATENA_X_PART')
                    collectDataRecord.productName = it.producedSerializedProduct.productName
                }
            }
        }
    }
    message.setHeader('collectDataRecord',collectDataRecord)

    def edcjson = new JsonBuilder(collectDataRecord)
    message.setBody(edcjson.toPrettyString())
    return message
}

def getKeyAssignments(def keyAssignments, def qualifier) {
    def  res = ''
    if (keyAssignments) {
        if (keyAssignments instanceof List) {
            keyAssignments.each {
                if (it.qualifier == qualifier) {
                    res = it.value
                }
            }
        } else if (keyAssignments.qualifier == qualifier) {
            res = keyAssignments.value
        } else {
            res = ''
        }
    } else {
        res = ''
    }
    return res
}

