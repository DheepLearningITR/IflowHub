import groovy.json.JsonSlurper
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def slurper = new JsonSlurper();
    def object = slurper.parseText(body);
    boolean checkStatus = false;
    for (int i = 0; i < object.size(); i++) {
        String temp = (object[i].status).toString();
        if (temp.equals("201")) {
            checkStatus = true;
            break;
        }
    }
    def map = message.getProperties();
    if (checkStatus == true) {
        message.setHeader("CamelHttpResponseText", "true");
    } else {
        message.setHeader("CamelHttpResponseText", "false");
    }
    return message;
}