import com.sap.it.api.mapping.*;
def String mapBP(String input,String BP){
     def query = new XmlSlurper().parseText(input);
     String output="NONE";
     query.E101CRMXIF_IBASE_PARTNER.each{
            if(it.MAIN_PARTNER.text()=="X"&&it.PARTNER_FUNCTION.text()==BP)
               output=it.PARTNER_NO.text();
        }
	return output; 
}