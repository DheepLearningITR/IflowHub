import com.sap.it.api.mapping.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String customFunc(String arg1){

    function a(str) {
   var pattern = /^(\d{1,4})(\d{1,2})(\d{1,2})(\d{1,2})(\d{1,2})(\d{2})$/;
   var datetime = str.match(pattern);
   var dt = new Date(datetime[1], datetime[2]-1, datetime[3], datetime[4], datetime[5], datetime[6]);
   return dt.toJSON();
}
}