import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;


import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    map = message.getProperties();
    def value=map.get("");
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    if(jsonObject.data.size()==0)
       {
             CamelHttpResponseCode
                
       }
    message.setBody(JsonOutput.toJson( newJsonObject));
    return message;
}