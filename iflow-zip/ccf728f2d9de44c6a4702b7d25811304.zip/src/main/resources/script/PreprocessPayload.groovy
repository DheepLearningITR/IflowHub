import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
def Message processData(Message message) {
    message.setProperty("CurrentSize", "0")
    message.setProperty("ObjectSent", "undone")
    def body = message.getBody(java.lang.String)
    def query = new XmlSlurper().parseText(body)
    query.IDOC.each{
       String ibaseNumber=it.E101CRMXIF_IBASE.IBASE_NUMBER.text()
       def storeParentId = [:]
       it.E101CRMXIF_IBASE.E101MXIF_IBASE_STRUCTURE_XT.E101CRMXIF_IBASE_STRUCTURE.each{ parent->
            storeParentId[parent.INSTANCE.text()]=parent.PARENT.text()
        }
       it.E101CRMXIF_IBASE.E101MXIF_IBASE_COMPONENT_XT.E101CRMXIF_IBASE_COMPONENT.each{component->
            if(storeParentId[component.INSTANCE]=="000000000000000000")
              component.OBJECT_ALLOCATION=ibaseNumber;
            else  
              component.OBJECT_ALLOCATION=storeParentId[component.INSTANCE]
       }
    }
    def valid_data = XmlUtil.serialize(query);
    message.setBody(valid_data);
    return message;
}