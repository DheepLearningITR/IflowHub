import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    def jsonParser = new JsonSlurper();
    if(body.indexOf('[',0) == -1 )
    {
      body = "[" + body  + "]";
    }
    def jsonObject = jsonParser.parseText(body);
    jsonObject=jsonObject["EquipmentIDOCLevel"]
    String obj="[]"
    def newjsonObject = jsonParser.parseText(obj);
    if(jsonObject.getClass()==java.util.ArrayList)
       {
           jsonObject.each{
            if(it.EQUIPMENT.getClass() == java.util.ArrayList)
               {
                  it.EQUIPMENT.each{equip->
                     newjsonObject.add(equip)
                    }
                }
            else
               newjsonObject.add(it.EQUIPMENT)    
       }
    }
    else
    newjsonObject=jsonObject.EQUIPMENT
    message.setBody(JsonOutput.toJson(newjsonObject)); 
    return message;
}











