import com.sap.it.api.mapping.*;
def String mapContact(String input,String Contact){
     def query = new XmlSlurper().parseText(input);
     String output="NONE";
     query.E101CRMXIF_IBASE_PARTNER.each{
            if(it.MAIN_PARTNER.text()=="X"&&it.PARTNER_FUNCTION.text()==Contact)
               output=it.PARTNER_NO.text();
        }
	return output; 
}