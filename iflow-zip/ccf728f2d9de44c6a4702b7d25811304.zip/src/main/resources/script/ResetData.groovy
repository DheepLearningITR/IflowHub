import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.ArrayList;

def Message processData(Message message)
{
    map = message.getProperties();
    message.setProperty("CurrentSize", "0");
    message.setProperty("ObjectSent", "undone");
    def body = message.getBody(java.lang.String);
    message.setProperty("ForwardJson", body);
    
    return message;
}
