import com.sap.it.api.mapping.*;

def String customFunc(String arg1){
	return arg1 
}