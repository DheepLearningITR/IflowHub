import com.sap.it.api.mapping.*;

//Get the exchange property value by passing the property name and the mapping context
def String getExchangeProperty(String propertyName,MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}