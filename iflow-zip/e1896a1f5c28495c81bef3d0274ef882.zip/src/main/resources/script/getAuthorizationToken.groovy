import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.AccessTokenAndUser;
import com.sap.it.api.securestore.exception.SecureStoreException;
import com.sap.it.api.ITApiFactory;

def Message processData(Message message) {
    // Get the SecureStoreService instance from the API factory
    SecureStoreService secureStoreService = ITApiFactory.getService(SecureStoreService.class, null);

    // Declare a variable to hold the OAuth2 token
    String token = null;
    
    try {
        // Retrieve the OAuth2 access token for the credential "MSBooking" from the secure store
        AccessTokenAndUser accessTokenAndUser = secureStoreService.getAccesTokenForOauth2AuthorizationCodeCredential("MSTeamsChat");

        // Extract the access token from the response object
        token = accessTokenAndUser.getAccessToken();

        // Set the Authorization header with the retrieved token for API authentication
        message.setHeader("Authorization", token);

        // Optionally, store the token in message properties for later use in the integration flow
        // message.setProperty("token", token);

        // Log the token for debugging purposes (this is optional but can be useful during development)
        // messageLog.addAttachmentAsString("Token", token, "text/plain");

    } catch (SecureStoreException e) {
        // If token retrieval fails, catch the exception and set an error property in the message
        message.setProperty("error", "Token retrieval failed: " + e.getMessage());
    }

    // Return the message object after processing
    return message;
}
