import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();
       def jsonSlurper = new JsonSlurper();
       def processData = jsonSlurper.parse(body);
       def price;
       if (!processData.root.element.isEmpty()){
          price = processData.root.element ;
       }
       processData = price ;
      message.setBody(new JsonBuilder(processData).toPrettyString());
      return message;
}