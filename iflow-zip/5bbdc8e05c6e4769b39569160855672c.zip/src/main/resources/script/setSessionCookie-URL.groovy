import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;
import java.io.*;
 
def Message processData(Message message) 
{
    def headers = message.getHeaders();
    def properties = message.getProperties();
    def cookie = headers.get("Set-Cookie");
    StringBuffer bufferedCookie = new StringBuffer();
    for (Object item : cookie) 
    {
        bufferedCookie.append(item + "; ");      
    }
    message.setHeader("Cookie", bufferedCookie.toString());
    def productID = properties.get("productID");
    def upscaleURL = properties.get("upscaleUrl");
    def url = upscaleURL + "/product-content/products/"+productID;
    message.setProperty("url",url);
    return message;
}