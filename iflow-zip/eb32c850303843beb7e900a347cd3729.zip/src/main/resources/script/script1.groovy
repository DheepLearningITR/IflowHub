import com.sap.gateway.ip.core.customdev.util.Message;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;


def Message processData(Message message) { 
    byte[] bytes = message.getBody(byte[].class);
    byte[] declarationHeader1 = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>".getBytes(StandardCharsets.UTF_8);
    byte[] declarationHeader2 = "<?xml version='1.0' encoding='ISO-8859-1'?>".getBytes(StandardCharsets.UTF_8);

    byte[] copy = Arrays.copyOf(bytes, declarationHeader1.length);

    byte[] result;
        if (Arrays.equals(declarationHeader1, copy) || Arrays.equals(declarationHeader2, copy)) {
            int nextChar = bytes[declarationHeader1.length];
            if (nextChar == 10) { // line feed
                // line break, do nothing
                result = bytes;
            } else {    
            // add line break
                result = new byte[bytes.length + 1];
                System.arraycopy(copy, 0, result, 0, copy.length);
                result[copy.length] = 10; // line break
                int index = copy.length + 1;
                int length = bytes.length - copy.length;
                System.arraycopy(bytes, copy.length, result, index, length);
            }
        } else {
            result = bytes;
       }
    message.setBody(result);
    return message;
 }