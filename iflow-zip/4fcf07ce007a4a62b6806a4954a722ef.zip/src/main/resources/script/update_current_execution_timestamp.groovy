import com.sap.gateway.ip.core.customdev.util.Message
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def currentExecutionLastProcessedS4ProductUpdatedAtTimestamp = message.getProperty("current_execution_last_processed_s4_product_updated_at_timestamp")

    def body = message.getBody(java.io.Reader)
    if (body == null) {
        return message
    }

    def xml = new XmlSlurper().parse(body)
    if (xml == null || xml.s4hanaProduct == null || xml.s4hanaProduct.size() == 0) {
        return message
    }

    LocalDateTime latestProcessedS4ProductUpdatedAt = null
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS")

    xml.s4hanaProduct.each { product ->
        def updatedAtString = product.updatedAt.text()
        if (updatedAtString != null && !updatedAtString.trim().isEmpty()) {
            LocalDateTime currentIteratedS4ProductUpdatedAt = LocalDateTime.parse(updatedAtString, formatter)

            if (latestProcessedS4ProductUpdatedAt == null || currentIteratedS4ProductUpdatedAt.isAfter(latestProcessedS4ProductUpdatedAt)) {
                latestProcessedS4ProductUpdatedAt = currentIteratedS4ProductUpdatedAt
            }
        }
    }

    if (latestProcessedS4ProductUpdatedAt != null) {
        if (currentExecutionLastProcessedS4ProductUpdatedAtTimestamp != null && !currentExecutionLastProcessedS4ProductUpdatedAtTimestamp.trim().isEmpty()) {
            LocalDateTime currentExecutionLastProcessedS4ProductUpdatedAtTime = LocalDateTime.parse(currentExecutionLastProcessedS4ProductUpdatedAtTimestamp, formatter)
            if (latestProcessedS4ProductUpdatedAt.isAfter(currentExecutionLastProcessedS4ProductUpdatedAtTime)) {
                message.setProperty("current_execution_last_processed_s4_product_updated_at_timestamp", latestProcessedS4ProductUpdatedAt.format(formatter))
            }
        } else {
            message.setProperty("current_execution_last_processed_s4_product_updated_at_timestamp", latestProcessedS4ProductUpdatedAt.format(formatter))
        }
    }

    return message
}