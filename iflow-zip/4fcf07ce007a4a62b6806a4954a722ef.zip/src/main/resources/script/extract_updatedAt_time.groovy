import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def A_Product = new XmlSlurper().parseText(body)
    def orderNode = A_Product.A_ProductType

    def currentProcessedS4ProductUpdatedAtTimestamp = orderNode.LastChangeDateTime;

    if(currentProcessedS4ProductUpdatedAtTimestamp && currentProcessedS4ProductUpdatedAtTimestamp.text()) {
        message.setProperty("currentProcessedS4ProductUpdatedAtTimestamp", currentProcessedS4ProductUpdatedAtTimestamp)
    }

    return message
}