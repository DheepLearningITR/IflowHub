import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def jsonObject = new JsonSlurper().parseText(message.getBody(String))

    if (jsonObject.variants && !(jsonObject.variants instanceof List)) {
        jsonObject.variants = [jsonObject.variants]
    }

    def jsonOutput = JsonOutput.toJson(jsonObject)

    message.setBody(jsonOutput)

    return message;
}
