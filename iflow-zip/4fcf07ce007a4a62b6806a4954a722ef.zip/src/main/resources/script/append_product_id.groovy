import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(String)

    if(body == null || body.trim().isEmpty()) {
        return message;
    }

    def jsonObject = new JsonSlurper().parseText(body)

    jsonObject.input.id = message.getProperty("shopify_product_id");
    def jsonOutput = JsonOutput.toJson(jsonObject)
    message.setBody(jsonOutput)

    return message;
}