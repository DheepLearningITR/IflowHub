import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(body)

    if (jsonObject.errors) {
        message.setProperty("has_json_errors", true)
    } else {
        message.setProperty("has_json_errors", false)
    }

    return message
}