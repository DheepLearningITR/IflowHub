import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	def body = message.getBody(java.lang.String) as String;
	message.setBody(body);

    return message;
}