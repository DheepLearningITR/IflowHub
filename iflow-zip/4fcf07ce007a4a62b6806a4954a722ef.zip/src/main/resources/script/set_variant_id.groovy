import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def productData = jsonSlurper.parseText(body)
  
    def adminGraphqlApiId = null
    if (productData.variants && productData.variants.size() > 0) {
        adminGraphqlApiId = productData.variants[0].id
    }
    
    message.setProperty("variant_admin_graphql_api_id", adminGraphqlApiId)

    return message
}