import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def currentExecutionTime = message.getProperty("current_execution_last_processed_s4_product_updated_at_timestamp")
    def requestDate = message.getProperty("lastS4ProductRequestTimestamp")

    if (currentExecutionTime == null || currentExecutionTime.trim().isEmpty()) {
        message.setProperty("current_execution_last_processed_s4_product_updated_at_timestamp", requestDate)
    } else {
        message.setProperty("current_execution_last_processed_s4_product_updated_at_timestamp", currentExecutionTime)
    }

    return message
}