import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){

		def s4hana_product_id = message.getProperty("s4hana_product_id") as String;	
		if(s4hana_product_id!=null && !s4hana_product_id.isEmpty()){
			messageLog.addCustomHeaderProperty("S4HANA Product ID Created", s4hana_product_id);		
        }
	}
	return message;
}