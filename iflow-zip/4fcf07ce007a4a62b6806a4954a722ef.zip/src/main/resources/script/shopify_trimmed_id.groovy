import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

  def shopify_product_id = message.getProperty("shopify_product_id") as String;
  def shopify_trimmed_id = shopify_product_id.split("/")[-1] as String;
  message.setProperty("shopify_trimmed_id", shopify_trimmed_id);
  return message;
}

