import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
def Message processData(Message message) {

    def body = message.getBody(String)

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)

    def hasNextPage = json.data.products.pageInfo.hasNextPage

    if(hasNextPage == true) {
        def endCursor = json.data.products.pageInfo.endCursor
        message.setProperty("lastNode", endCursor)
    } else message.setProperty("hasNextPage", false);

    return message;
}