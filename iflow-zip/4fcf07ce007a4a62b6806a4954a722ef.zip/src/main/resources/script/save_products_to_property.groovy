import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def shopifyProductList = message.getProperty("shopify_product_list") as String
    def responseBody = message.getBody(String) as String
    def jsonSlurper = new JsonSlurper()
    def existingProducts = []

    if (shopifyProductList?.trim()) {
        try {
            def parsedShopifyProductList = jsonSlurper.parseText(shopifyProductList)
            existingProducts = parsedShopifyProductList.products ?: []
        } catch (Exception e) {
            existingProducts = []
        }
    }

    def parsedResponseBody = jsonSlurper.parseText(responseBody)
    parsedResponseBody.data.products.edges.each { it.node.remove('pageInfo') }

    def incomingEdges = parsedResponseBody.data?.products?.edges ?: []

    def incomingProducts = incomingEdges.collect { edge ->
        def node = edge.node
        [
            id: node.id,
            variants: node.variants.edges.collect { variantEdge ->
                def variantNode = variantEdge.node
                [
                    id: variantNode.id,
                    sku: variantNode.sku
                ]
            }
        ]
    }

    existingProducts.addAll(incomingProducts)

    def accumulatedProductList = [products: existingProducts]

    def builder = new JsonBuilder(accumulatedProductList)
    def newProductListJson = builder.toPrettyString()

    message.setProperty("shopify_product_list", newProductListJson)

    return message
}