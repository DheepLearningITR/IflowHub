importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  message.setProperty('billingRates', []);
  var param = [];
  var jsonListData = message.getProperty('timeentries').d;

  for (var i = 0; i < jsonListData.length; i++) {
    if (jsonListData[i].customMetadata) {
      var taskMetadata = jsonListData[i].customMetadata.filter(function(item) {
        return item.keyUri === 'urn:replicon:time-entry-metadata-key:billing-rate';
      });

      for (var j = 0; j < taskMetadata.length; j++) {
        param.push({
          parameter: taskMetadata[j].value.uri
        });
      }
    }
  }

  var requestParam = {
    billingRates: param
  };

  message.setBody(JSON.stringify(requestParam));
  var logMessageBody = message.getProperty('LogMessageBody');
  var messageLog = messageLogFactory.getMessageLog(message);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('billing rate request', JSON.stringify(requestParam), 'text/json');
  }

  return message;
}