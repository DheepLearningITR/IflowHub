importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var taskdetails = JSON.parse(body);
  var param = [];
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  message.setProperty('taskdetails', taskdetails);
  for (var i = 0; i < taskdetails.d.length; i++) {
    param.push({
      uri: taskdetails.d[i].project.uri
    });
  }

  var requestParam = {
    projects: param
  };
  message.setBody(JSON.stringify(requestParam));

  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('task details response', body, 'text/json');
    messageLog.addAttachmentAsString('projecttask details request', JSON.stringify(requestParam), 'text/json');
  }
  return message;
}