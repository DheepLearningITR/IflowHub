importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  var param = [];
  var jsonListData = message.getProperty('timeentries').d;

  for (var i = 0; i < jsonListData.length; i++) {
    if (jsonListData[i].customMetadata) {
      var projectMetadata = jsonListData[i].customMetadata.filter(function(item) {
        return item.keyUri === 'urn:replicon:time-entry-metadata-key:project';
      });
      for (var j = 0; j < projectMetadata.length; j++) {
        param.push({
          uri: projectMetadata[j].value.uri
        });
      }
    }
  }

  var requestParam = {
    projects: param
  };

  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('project details request', JSON.stringify(requestParam), 'text/json');
  }
  message.setBody(JSON.stringify(requestParam));
  return message;
}