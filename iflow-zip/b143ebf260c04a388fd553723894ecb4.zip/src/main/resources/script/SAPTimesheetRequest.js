importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var logMessageBody = message.getProperty('LogMessageBody');
  var messageLog = messageLogFactory.getMessageLog(message);
  var users = message.getProperty('users');
  message.setProperty('personWorkAgreement', users.d[0] ? users.d[0].employeeId : '');
  var timesheetdaterange = message.getProperty('parameter').dateRange;
  message.setProperty('timesheetStartDate', getTimesheetDate((timesheetdaterange.startDate)));
  message.setProperty('timesheetEndDate', getTimesheetDate((timesheetdaterange.endDate)));
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('timesheetdaterange', message.getProperty('timesheetdaterange'), 'text/json');
  }
  return message;
}

function getDateObjFromRepliconDate(dt) {
  return new Date(dt.year, dt.month - 1, dt.day);
}

function getTimesheetDate(entryDate) {
  var dateObj = getDateObjFromRepliconDate(entryDate);
  return dateObj.toISOString().replace('Z', '');
}