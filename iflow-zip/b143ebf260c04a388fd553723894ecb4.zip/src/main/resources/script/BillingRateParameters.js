importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);

  var jsonData = JSON.parse(body);
  var param = {
    companyBillingRateUri: jsonData.parameter
  };

  message.setBody(JSON.stringify(param));

  var logMessageBody = message.getProperty('LogMessageBody');

  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('billing rate input request', JSON.stringify(param), 'text/json');
    messageLog.addAttachmentAsString('billing rate input message', body, 'text/json');
  }


  return message;
}