importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var parentTaskDetails = JSON.parse(body);
  message.setProperty('parentTaskDetails', parentTaskDetails);
  message.setBody('');
  var logMessageBody = message.getProperty('LogMessageBody');
  var messageLog = messageLogFactory.getMessageLog(message);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('parent Task details response', JSON.stringify(parentTaskDetails), 'text/json');
  }
  return message;
}