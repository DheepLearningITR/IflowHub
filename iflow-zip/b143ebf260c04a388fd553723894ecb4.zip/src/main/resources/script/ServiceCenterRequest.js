importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  message.setProperty('costCenters', JSON.parse(body).d);
  message.setProperty('serviceCenters', []);
  var projectdetails = message.getProperty('projectdetails');
  var serviceCentersUris = {
    serviceCenterUris: projectdetails.d.map(function(item) {
      return item.projectDetails.serviceCenter.uri;
    }).filter(function(item) {
      return item;
    })
  };
  message.setBody(JSON.stringify(serviceCentersUris));

  var logMessageBody = message.getProperty('LogMessageBody');
  var messageLog = messageLogFactory.getMessageLog(message);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('cost center response', body, 'text/json');
    messageLog.addAttachmentAsString('service center request', JSON.stringify(serviceCentersUris), 'text/json');
  }

  return message;
}