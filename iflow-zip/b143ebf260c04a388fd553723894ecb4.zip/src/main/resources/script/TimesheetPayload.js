/* eslint-disable prefer-destructuring, no-multi-str, no-loop-func*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
importClass(javax.mail.util.ByteArrayDataSource);
importClass(org.apache.camel.impl.DefaultAttachment);

function processData(message) {
  var projects = message.getProperty('projectdetails');
  var users = message.getProperty('users');
  var saptsData = (message.getBody(new java.lang.String().getClass()));
  var parentTaskDetails = message.getProperty('parentTaskDetails');
  var tasks = message.getProperty('taskdetails');
  var billingRates = message.getProperty('billingRates');
  var entries = message.getProperty('timeentries');
  var xmlList = '';

  if (entries && entries.d) {
    if (entries.d.length > 0) {
      var standardTimesheetEntries = entries.d.filter(function(entry) {
        return isStandardTimeSheetEntry(entry);
      });

      var inoutTimesheetEntries = entries.d.filter(function(entry) {
        return isInoutTimeSheetEntry(entry);
      });
      // only standard / inout timesheet template supported for now
      if (standardTimesheetEntries.length > 0) {
        entries.d = standardTimesheetEntries;
      } else if (inoutTimesheetEntries.length > 0) {
        entries.d = inoutTimesheetEntries;
      } else {
        entries.d = [];
      }
      xmlList = parseTimeEntries(entries, users, tasks, projects, message, parentTaskDetails, billingRates, xmlList);
    }
    var output = getExistingSAPTimeEntriesForDeletion(saptsData, xmlList);
    saptsData = output.saptsData;
    xmlList = output.xmlList;
    var bodyData = '<batchParts>' + xmlList + '</batchParts>';
    message.setBody(bodyData);

    var logMessageBody = message.getProperty('LogMessageBody');
    var messageLog = messageLogFactory.getMessageLog(message);

    if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
      messageLog.addAttachmentAsString('sap timesheet get request', saptsData, 'text/json');
      messageLog.addAttachmentAsString('sap timesheet post request', bodyData, 'text/json');
    }
  }


  return message;
}

function getExistingSAPTimeEntriesForDeletion(saptsData, xmlList) {
  var opNode = '<TimeSheetOperation></TimeSheetOperation>';
  var opNodeUpdate = '<TimeSheetOperation>D</TimeSheetOperation>';
  if (saptsData.indexOf(opNode) !== -1) {
    saptsData = saptsData.replaceAll('<TimeSheetEntryCollection>', '');
    saptsData = saptsData.replaceAll('</TimeSheetEntryCollection>', '');
    saptsData = saptsData.replaceAll('<TimeSheetEntry>', '\
                                                                        <batchChangeSet>\
                                                                        <batchChangeSetPart>\
                                                                        <method>POST</method>\
                                                                        <TimeSheetEntryCollection>\
                                                                        <TimeSheetEntry>');

    saptsData = saptsData.replaceAll('</TimeSheetEntry>', '\
                                                                        </TimeSheetEntry>\
                                                                        </TimeSheetEntryCollection>\
                                                                        </batchChangeSetPart> \
                                                                        </batchChangeSet>');

    xmlList = saptsData.replaceAll(opNode, opNodeUpdate) + xmlList;
  }
  return { saptsData: saptsData, xmlList: xmlList };
}

function parseTimeEntries(entries, users, tasks, projects, message, parentTaskDetails, billingRates, xmlList) {
  for (var index = 0; index < entries.d.length; index++) {
    var entry = entries.d[index];
    var recordedHours = getHours(entry);
    var timesheetDate = getTimesheetDate(entry);
    var personWorkAgreementExternalID = getEmpID(entry, users);

    var timeSheetTaskType = '';
    var timeSheetTaskComponent = '';

    var projectUri = getProjecturi(entry, tasks.d);

    var projectInfo = projects.d.filter(function(item) {
      return item && item.projectDetails.uri === projectUri;
    })[0];
    projectInfo = projectInfo ? projectInfo.projectDetails : null;
    if (!projectInfo) {
      continue;
    }
    var controllingArea = getObjectExtensionField(projectInfo, 'ControllingArea');
    var companyCode = getCodefromGroups(projectInfo.serviceCenter.uri, message.getProperty('serviceCenters'));
    var senderCostCenter = getCodefromGroups(projectInfo.costCenter.uri, message.getProperty('costCenters'));
    var wbsElement = getParentTaskCode(entry, parentTaskDetails);
    var workItem = getTaskCode(entry, tasks);
    var activityType = getBillingRateCode(entry, billingRates);

    xmlList = getXMLElement(timesheetDate, timeSheetTaskComponent, wbsElement, activityType, senderCostCenter, workItem, timeSheetTaskType, recordedHours, controllingArea, personWorkAgreementExternalID, companyCode, xmlList);
  }
  return xmlList;
}

function getXMLElement(timesheetDate, timeSheetTaskComponent, wbsElement, activityType, senderCostCenter, workItem, timeSheetTaskType, recordedHours, controllingArea, personWorkAgreementExternalID, companyCode, xmlList) {
  var xml = ' \
                    <batchChangeSet>\
                    <batchChangeSetPart>\
                    <method>POST</method>\
                    <TimeSheetEntryCollection>\
                    <TimeSheetEntry>\
                            <TimeSheetDate>' + timesheetDate + '</TimeSheetDate>\
                            <TimeSheetRecord></TimeSheetRecord>\
                            <TimeSheetIsReleasedOnSave>false</TimeSheetIsReleasedOnSave>\
                            <TimeSheetDataFields>\
                                <TimeSheetTaskComponent>' + timeSheetTaskComponent + '</TimeSheetTaskComponent>\
                                <WBSElement>' + wbsElement + '</WBSElement>\
                                <HoursUnitOfMeasure>H</HoursUnitOfMeasure>\
                                <ReceiverCostCenter></ReceiverCostCenter>\
                                <ActivityType>' + activityType + '</ActivityType>\
                                <TimeSheetWrkLocCode/>\
                                <SenderCostCenter>' + senderCostCenter + '</SenderCostCenter>\
                                <InternalOrder/>\
                                <WorkItem>' + workItem + '</WorkItem>\
                                <RejectionReason/>\
                                <BillingControlCategory/>\
                                <PurchaseOrderItem>0</PurchaseOrderItem>\
                                <TimeSheetNote/>\
                                <TimeSheetTaskType>' + timeSheetTaskType + '</TimeSheetTaskType>\
                                <RecordedQuantity>' + recordedHours + '</RecordedQuantity>\
                                <TimeSheetOvertimeCategory/>\
                                <TimeSheetTaskLevel></TimeSheetTaskLevel>\
                                <RecordedHours>' + recordedHours + '</RecordedHours>\
                                <PurchaseOrder/>\
                                <ControllingArea>' + controllingArea + '</ControllingArea>\
                            </TimeSheetDataFields>\
                            <PersonWorkAgreementExternalID>' + personWorkAgreementExternalID + '</PersonWorkAgreementExternalID>\
                            <TimeSheetPredecessorRecord/>\
                            <TimeSheetStatus>30</TimeSheetStatus>\
                            <TimeSheetIsExecutedInTestRun>false</TimeSheetIsExecutedInTestRun>\
                            <TimeSheetOperation>C</TimeSheetOperation>\
                            <CompanyCode>' + companyCode + '</CompanyCode>\
                            <PersonWorkAgreement></PersonWorkAgreement>\
                        </TimeSheetEntry>\
                    </TimeSheetEntryCollection>\
                    </batchChangeSetPart> \
                    </batchChangeSet>';

  xmlList += xml;
  return xmlList;
}

function getCodefromGroups(groupUri, groups) {
  var groupInfo = groups.filter(function(item) {
    return item.uri === groupUri;
  })[0];
  return groupInfo ? groupInfo.code : '';
}

function getDateObjFromRepliconDate(dt) {
  return new Date(dt.year, dt.month - 1, dt.day);
}

function getTimesheetDate(entry) {
  var dateObj = getDateObjFromRepliconDate(entry.entryDate);
  return dateObj.toISOString().replace('Z', '');
}

function getEmpID(entry, users) {
  var userInfo = users.d.filter(function(item) {
    return item.uri === entry.user.uri;
  })[0];
  return userInfo ? userInfo.employeeId : '';
}

function getParentTaskCode(entry, parentTaskDetails) {
  var taskUri = getTaskUri(entry);
  var parentTaskInfo = parentTaskDetails.d[0].childTasks.filter(function(x) {
    return x.childTasks.filter(function(y) {
      return y.task.uri === taskUri;
    })[0];
  })[0];

  return parentTaskInfo ? parentTaskInfo.task.code : '';
}

function getTaskCode(entry, tasks) {
  var taskUri = getTaskUri(entry);

  var taskInfo = tasks.d.filter(function(item) {
    return item.uri === taskUri;
  })[0];

  return taskInfo ? taskInfo.code : '';
}

function getBillingRateCode(entry, billingRates) {
  var billingRateUri = getBillingRateUri(entry);

  var billingInfo = billingRates.filter(function(item) {
    return item.uri === billingRateUri;
  })[0];

  return billingInfo ? billingInfo.description : '';
}

function getHours(entry) {
  var hours = 0.0;
  if (isStandardTimeSheetEntry(entry)) {
    hours = entry.interval.hours.hours + (entry.interval.hours.minutes / 60.0) +
            (entry.interval.hours.seconds / 3600.0);
    hours = parseFloat(hours.toFixed(3));
  } else if (isInoutTimeSheetEntry(entry)) {
    var timePair = entry.interval.timePair;
    var endDate = new Date(0, 0, 0, timePair.endTime.hour, timePair.endTime.minute, timePair.endTime.second);
    var startDate = new Date(0, 0, 0, timePair.startTime.hour, timePair.startTime.minute, timePair.startTime.second);
    if (startDate > endDate) {
      endDate.setDate(endDate.getDate() + 1);
    }
    const milliseconds = endDate - startDate;
    hours = milliseconds / 36e5;
    hours = parseFloat(hours.toFixed(3));
  }
  return hours;
}

function isInoutTimeSheetEntry(entry) {
  return entry && entry.interval && entry.interval.timePair && entry.interval.timePair.startTime && entry.interval.timePair.endTime;
}

function isStandardTimeSheetEntry(entry) {
  return entry && entry.interval && entry.interval.hours;
}

function getTaskUri(entry) {
  var taskUri = null;
  if (entry && entry.customMetadata) {
    for (var index = 0; index < entry.customMetadata.length; index++) {
      var metadata = entry.customMetadata[index];
      if (isValidMetadata(metadata, 'urn:replicon:time-entry-metadata-key:task')) {
        if (metadata.value && metadata.value.uri) {
          taskUri = metadata.value.uri;
          return taskUri;
        }
      }
    }
  }
  return taskUri;
}

function getBillingRateUri(entry) {
  var taskUri = null;
  if (entry && entry.customMetadata) {
    for (var index = 0; index < entry.customMetadata.length; index++) {
      var metadata = entry.customMetadata[index];
      if (isValidMetadata(metadata, 'urn:replicon:time-entry-metadata-key:billing-rate')) {
        if (metadata.value && metadata.value.uri) {
          taskUri = metadata.value.uri;
          return taskUri;
        }
      }
    }
  }
  return taskUri;
}

function isValidMetadata(customMetadata, keyUri) {
  if (customMetadata.keyUri && customMetadata.keyUri === keyUri) {
    if (customMetadata.value && customMetadata.value.uri) {
      return true;
    }
  }
  return false;
}

function getProjecturi(entry, tasks) {
  var projectUri = null;
  var taskUri = null;
  if (entry && entry.customMetadata) {
    for (var index = 0; index < entry.customMetadata.length; index++) {
      var metadata = entry.customMetadata[index];
      if (isValidMetadata(metadata, 'urn:replicon:time-entry-metadata-key:project')) {
        if (metadata.value && metadata.value.uri) {
          projectUri = metadata.value.uri;
          return projectUri;
        }
      } else if (isValidMetadata(metadata, 'urn:replicon:time-entry-metadata-key:task')) {
        taskUri = metadata.value.uri;
      }
    }
  }
  if (taskUri) {
    for (index = 0; index < tasks.length; index++) {
      var task = tasks[index];
      if (task && task.uri === taskUri && task.project.uri) {
        return task.project.uri;
      }
    }
  }
  return projectUri;
}

function getObjectExtensionField(project, objectExtensionFieldName) {
  if (!project) {
    return '';
  }
  for (var index = 0; index < project.extensionFieldValues.length; index++) {
    var customField = project.extensionFieldValues[index];
    if (customField.definition.displayText === objectExtensionFieldName) {
      return customField.textValue;
    }
  }
  return '';
}