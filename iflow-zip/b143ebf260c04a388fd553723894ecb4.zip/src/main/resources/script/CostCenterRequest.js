importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  message.setProperty('costCenters', []);
  var projectdetails = message.getProperty('projectdetails');
  var costCentersUris = {
    costCenterUris: projectdetails.d.map(function(item) {
      return item.projectDetails.costCenter.uri;
    }).filter(function(item) {
      return item;
    })
  };
  message.setBody(JSON.stringify(costCentersUris));
  var logMessageBody = message.getProperty('LogMessageBody');
  var messageLog = messageLogFactory.getMessageLog(message);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('cost center request', JSON.stringify(costCentersUris), 'text/json');
  }
  return message;
}