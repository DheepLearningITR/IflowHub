importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var activitydetails = JSON.parse(body);
  message.setProperty('activitydetails', activitydetails);
  var parameter = message.getProperty('parameter');
  var requestParam = {
    userUri: [ parameter.users[0].uri ]
  };
  message.setBody(JSON.stringify(requestParam));
  var logMessageBody = message.getProperty('LogMessageBody');
  var messageLog = messageLogFactory.getMessageLog(message);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('actvity details response', body, 'text/json');
    messageLog.addAttachmentAsString('user details request', JSON.stringify(requestParam), 'text/json');
  }
  return message;
}