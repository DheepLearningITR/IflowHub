importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var billingRates = message.getProperty('billingRates');
  billingRates = billingRates ? billingRates : [];
  billingRates.push(JSON.parse(body).d);
  message.setProperty('billingRates', billingRates);
  message.setBody('');
  var logMessageBody = message.getProperty('LogMessageBody');
  var messageLog = messageLogFactory.getMessageLog(message);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('billing rate response', body, 'text/json');
  }

  return message;
}