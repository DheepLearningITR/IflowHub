/* eslint-disable radix*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function getUTCDate() {
  var utcDate = new Date(new Date().toUTCString().slice(0, -4));
  return utcDate;
}

function getRepliconDateTimeObj(dt) {
  return {
    year: dt.getFullYear(),
    month: dt.getMonth() + 1,
    day: dt.getDate(),
    hour: dt.getHours(),
    minute: dt.getMinutes(),
    second: dt.getSeconds(),
    millisecond: dt.getMilliseconds()
  };
}

function getDateValue(dateValue) {
  try {
    var regex = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/;
    var dateArray = regex.exec(dateValue);
    var syncDate = new Date(
      (Number(dateArray[1])),
      (Number(dateArray[2])) - 1,
      (Number(dateArray[3])),
      (Number(dateArray[4])),
      (Number(dateArray[5])),
      (Number(dateArray[6]))
    );
    return syncDate;
  } catch (e) {
    return null;
  }
}

function processData(message) {
  var timesheetSyncStartUTCDateTime = message.getProperty('TimesheetSyncStartUTCDateTime');
  timesheetSyncStartUTCDateTime = timesheetSyncStartUTCDateTime ? getDateValue(timesheetSyncStartUTCDateTime) : null;
  var lastRelativeTimeInMinutes = message.getProperty('LastRelativeTimeInMinutes');
  lastRelativeTimeInMinutes = lastRelativeTimeInMinutes && !isNaN(parseFloat(lastRelativeTimeInMinutes)) ? parseFloat(lastRelativeTimeInMinutes) : 0;
  var logProperty = message.getProperty('LogProperty');
  var logMessageBody = message.getProperty('LogMessageBody');
  var lastRunDateTime = message.getProperty('QueryLastRunDateTime');
  lastRunDateTime = lastRunDateTime ? getDateValue(lastRunDateTime) : null;
  var queryLastRunDateTime = (lastRunDateTime instanceof Date) ? lastRunDateTime : (timesheetSyncStartUTCDateTime ? timesheetSyncStartUTCDateTime : getUTCDate());
  queryLastRunDateTime.setMinutes(queryLastRunDateTime.getMinutes() - lastRelativeTimeInMinutes);

  var startDateTime = getRepliconDateTimeObj(queryLastRunDateTime);
  var retryCount = parseInt(message.getProperty('RetryCount'));
  message.setProperty('RetryCount', retryCount - 1);

  var timesheetListQuery = {
    page: 1,
    pagesize: 10,
    columnUris: [ 'urn:replicon:timesheet-list-column:timesheet', 'urn:replicon:timesheet-list-column:timesheet-status', 'urn:replicon:timesheet-list-column:timesheet-owner', 'urn:replicon:timesheet-list-column:timesheet-period' ],
    sort: [],
    filterExpression: {
      leftExpression: {
        leftExpression: {
          leftExpression: null,
          operatorUri: null,
          rightExpression: null,
          value: null,
          filterDefinitionUri: 'urn:replicon:timesheet-list-filter:timesheet-status'
        },
        operatorUri: 'urn:replicon:filter-operator:equal',
        rightExpression: {
          leftExpression: null,
          operatorUri: null,
          rightExpression: null,
          value: {
            uri: 'urn:replicon:timesheet-status:approved',
            uris: [],
            bool: null,
            date: null,
            money: null,
            number: null,
            text: null,
            time: null,
            calendarDayDurationValue: null,
            workdayDurationValue: null,
            dateRange: null,
            dateTimeUtc: null,
            dateTimeUtcRange: null
          },
          filterDefinitionUri: null
        },
        value: null,
        filterDefinitionUri: null
      },
      operatorUri: 'urn:replicon:filter-operator:and',
      rightExpression: {
        leftExpression: {
          leftExpression: null,
          operatorUri: null,
          rightExpression: null,
          value: null,
          filterDefinitionUri: 'urn:replicon:timesheet-list-filter:approval-utc-date-time-range'
        },
        operatorUri: 'urn:replicon:filter-operator:in',
        rightExpression: {
          leftExpression: null,
          operatorUri: null,
          rightExpression: null,
          value: {
            uri: null,
            uris: [],
            bool: null,
            date: null,
            money: null,
            number: null,
            text: null,
            time: null,
            calendarDayDurationValue: null,
            workdayDurationValue: null,
            dateRange: null,
            dateTimeUtc: null,
            dateTimeUtcRange: {
              startDateTime: startDateTime,
              endDateTime: null
            }
          },
          filterDefinitionUri: null
        },
        value: null,
        filterDefinitionUri: null
      },
      value: null,
      filterDefinitionUri: null
    }
  };

  message.setBody(JSON.stringify(timesheetListQuery));
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setHeader('Content-Type', 'application/json');

  var messageLog = messageLogFactory.getMessageLog(message);

  if (messageLog && logProperty && logProperty.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('queryLastRunDateTime', queryLastRunDateTime, 'text/json');
    messageLog.addAttachmentAsString('timesheetSyncStartUTCDateTime', timesheetSyncStartUTCDateTime, 'text/json');
    messageLog.addAttachmentAsString('lastRelativeTimeInMinutes', lastRelativeTimeInMinutes, 'text/json');
    messageLog.addAttachmentAsString('lastRunDateTime', lastRunDateTime, 'text/json');
  }
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('timesheet approved request', JSON.stringify(timesheetListQuery), 'text/json');
  }

  return message;
}