importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);

  var eventData = JSON.parse(body);
  var requestData = {
    timesheetUri: eventData.timesheet.uri
  };
  message.setBody(JSON.stringify(requestData));

  message.setProperty('parameter', requestData);
  var logMessageBody = message.getProperty('LogMessageBody');

  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('time details request', JSON.stringify(requestData), 'text/json');
    messageLog.addAttachmentAsString('webhook event details request', body, 'text/json');
  }

  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setHeader('Content-Type', 'application/json');

  return message;
}