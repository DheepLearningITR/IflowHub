importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var param = [];
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  var jsonListData = JSON.parse(body).d;

  if (jsonListData.rows.length === 0) {
    message.setHeader('canexit', 'true');
  } else {
    for (var index = 0; index < jsonListData.rows.length; index++) {
      var requestParam = {
        users: [
          {
            uri: jsonListData.rows[index].cells[2].uri
          }
        ],
        dateRange: jsonListData.rows[index].cells[3].dateRangeValue
      };

      param.push({
        parameter: requestParam
      });
    }
  }

  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('timesheet approved response', JSON.stringify(jsonListData), 'text/json');
  }

  message.setBody(JSON.stringify({
    timesheets: param
  }));

  return message;
}