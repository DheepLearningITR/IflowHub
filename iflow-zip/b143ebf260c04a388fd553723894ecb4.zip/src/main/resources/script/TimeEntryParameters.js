importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var timesheetNotApprovedMessage = 'Timesheet is not approved';
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);

  var timesheetDetails = JSON.parse(body).d;
  var requestData = {
    users: [
      {
        uri: timesheetDetails.owner.uri
      }
    ],
    dateRange: timesheetDetails.dateRange
  };
  message.setBody(JSON.stringify(requestData));
  var isApprovedTimesheet = timesheetDetails.statusUri === 'urn:replicon:timesheet-status:approved';
  message.setProperty('isApprovedTimesheet', isApprovedTimesheet ? 'yes' : 'no');
  if (!isApprovedTimesheet) {
    throw timesheetNotApprovedMessage;
  }
  message.setProperty('parameter', requestData);
  var logMessageBody = message.getProperty('LogMessageBody');

  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('time entry request', JSON.stringify(requestData), 'text/json');
    messageLog.addAttachmentAsString('time details response', body, 'text/json');
  }

  return message;
}