importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var projectdetails = JSON.parse(body);
  var existingProjects = message.getProperty('projectdetails');
  projectdetails.d = projectdetails.d.concat(existingProjects.d);
  message.setProperty('projectdetails', projectdetails);
  var projectUris = projectdetails.d.map(function(item) {
    return item.projectDetails.uri;
  });
  var param = { parentUris: projectUris };
  message.setBody(JSON.stringify(param));
  var logMessageBody = message.getProperty('LogMessageBody');
  var messageLog = messageLogFactory.getMessageLog(message);

  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('project details response', JSON.stringify(projectdetails), 'text/json');
    messageLog.addAttachmentAsString('parent Task details request', JSON.stringify(param), 'text/json');
  }
  return message;
}