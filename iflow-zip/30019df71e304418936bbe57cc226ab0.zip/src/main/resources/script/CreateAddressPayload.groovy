/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
def Message processData(Message message) {
    def msg = message.getBody(java.lang.String) as String;
    message.setProperty("CurrentSize", "0");
    message.setProperty("ObjectSent", "undone");
    String body = "";
    int i = 0;
    for (i = 0; i < msg.length(); i++) {
        if (msg[i] == '}')
            break;
    }
    body = msg.substring(0, i + 1);
    msg = msg.substring(i + 1, msg.length());
    msg = msg.replace("[", "");
    msg = msg.replace("]", "");
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    String ID = jsonObject.name;
    String[] arr;
    arr = ID.split('-');
    String msgtemp = msg;
    if(!ID.equals(""))
     {
        for (i = 0; i < arr.size(); i++) {
           msgtemp = msgtemp + "," + msg;
          }
     }
    int INDEX = 0;
    int appendtext = 1;
    msgtemp = '[' + msgtemp + ']';
    def jsonObject1 = jsonParser.parseText(msgtemp);
    String flag = "check";
    jsonObject1.each {
        if (!flag.equals("check")) {
            it.object.objectId.externalId = arr[INDEX];
            String temp = it.externalId;
            it.externalId = arr[INDEX];
            appendtext++;
            INDEX++;
        }
        if (flag.equals("check"))
            flag = "uncheck";
    }
    message.setBody(JsonOutput.toJson(jsonObject1));
    return message;
}
