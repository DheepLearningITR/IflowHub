import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

     def map = message.getProperties();
     def resError = map.get("FSMErrorMessage");
  
     message.setBody("HTTP Response Error'\n'"+resError);
    return message;
}
