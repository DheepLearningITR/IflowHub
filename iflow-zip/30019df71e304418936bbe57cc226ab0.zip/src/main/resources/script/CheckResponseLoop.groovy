import groovy.json.JsonSlurper
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput
def Message processData(Message message) {

   def body = message.getBody(java.lang.String) as String;
   def jsonParser = new JsonSlurper();
   def jsonObject = jsonParser.parseText(body);
   map=message.getProperties();
   String currentSize=map.get("CurrentSize");
   if(currentSize!="0")
   {
       jsonObject.each
        {
          if (it.status >= 400 &&it.status < 600){
             message.setProperty("ObjectSent","done");
             message.setHeader("CamelHttpResponseCode", "FSMError");
          }
       }
   }
    return message;        
}
  
