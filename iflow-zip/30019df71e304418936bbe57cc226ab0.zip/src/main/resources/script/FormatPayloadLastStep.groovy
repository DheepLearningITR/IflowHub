import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

  def Message processMethod(Message message)
    {
     
     
     
   /*  def msg=message.getBody(java.lang.String) as String;
     String body="";
     int i=0;
     for(i=0;i<msg.length();i++)
        {
           if(msg[i]=='}')
              break;
        }
      
  
    body=msg.substring(0,i+1);
    msg=msg.substring(i+1,msg.length());
    msg.replace('[',"");
    msg.replace(']',"");
    
    
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body1);
    String ID=jsonObject.name;
    
    int components=0;
    for( i=0;i<ID.length();i++)
        {  
             if(ID[i]=='-')
                {
                    components++;
                }

       }
   
    components++;
    def arr;
    arr=ID.split('-'); 
    String msgtemp=msg;
        
        for( i=0;i<=components;i++)
         {
             
             msgtemp=msgtemp+","+msg;
             
         }
    int c=0;  
    
    msg='['+msg+']';
    def jsonObject1 = jsonParser.parseText(msg);
    def flag=0;
    jsonObject1.each{
        
        if(flag==1)
        it.object.objectId.externalId=arr[c++];
        flag=1;
        
        
        }   
    
       message.setBody(JsonOutput.toJson(jsonObject1));
       */
       return message;
    
    } 

  