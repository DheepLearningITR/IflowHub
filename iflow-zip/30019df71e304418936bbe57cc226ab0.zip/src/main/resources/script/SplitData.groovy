import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
def Message processData(Message message) {
  //  def body = message.getBody(java.lang.String) as String;
    map = message.getProperties();
    String BATCH_SIZE=map.get("BATCH_SIZE");
    def batchSize=BATCH_SIZE.toInteger();
    String body=map.get("ForwardJson");
   
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    String currentSize=map.get("CurrentSize");
     def objectSize=jsonObject.size();
    
    String newJson="[ ]";
    def jsonSlurper = new JsonSlurper();
    def newJsonObject = jsonSlurper.parseText(newJson);

    int currentSize1=currentSize.toInteger();
    if(objectSize<=batchSize)
         {
               message.setProperty("ObjectSent","done");
                 for(int i=currentSize1;i<objectSize;i++)
                       {
                              newJsonObject.add(jsonObject[i]);        
                       } 
         }
    else if(currentSize1<objectSize)
         {
                 int check=(currentSize1+batchSize)>objectSize?objectSize:(currentSize1+batchSize);
                    
                 for(int i=currentSize1;i<check;i++)
                       {
                              newJsonObject.add(jsonObject[i]);        
                       } 
                   String check1=check.toString();       
                   message.setProperty("CurrentSize",check1);
                 if(check==objectSize)
                   message.setProperty("ObjectSent","done");
             
         }

    message.setBody(JsonOutput.toJson( newJsonObject));
    return message;
}