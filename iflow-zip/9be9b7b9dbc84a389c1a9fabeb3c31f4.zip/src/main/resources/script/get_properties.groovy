import com.sap.it.api.mapping.*;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String customFunc(String prop_name,MappingContext context){

	def prop = context.getProperty(prop_name);
	
    return prop;
    }
