import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
	def camelHttpPath = getId(message.getHeaders().get('CamelHttpPath'))
	if (camelHttpPath.indexOf('/submodel') > -1 ) {
		camelHttpPath = camelHttpPath.replace('/submodel','')
	}
	if (camelHttpPath.indexOf('/$value') > -1 ) {
		message.setHeader('valueOnly','true')
		camelHttpPath = camelHttpPath.replace('/$value','')
	} else {
		message.setHeader('valueOnly', 'false')
	}
	def id = getId(camelHttpPath)
	message.setHeader('catenaxID', id)
	message.getHeaders().remove('CamelHttpPath')
    message.getHeaders().remove('CamelHttpUrl')
    return message;
}
	
def getId(def text) {
	id = ""
	if (text.indexOf('urn%3Auuid%3A') > -1 ) {
		id = text.replace('urn%3Auuid%3A','')
	} else if (text.indexOf('urn:uuid:') > -1 ) {
		id = text.replace('urn:uuid:','')
	} else {
		id = text
	}
	return id
}
