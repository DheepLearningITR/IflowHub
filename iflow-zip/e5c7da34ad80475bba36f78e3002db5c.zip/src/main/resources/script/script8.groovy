import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
	def catenaxID = message.getHeaders().get('catenaxID')
	def edc_bpn = message.getHeaders().get('Edc-Bpn')
	def toCtxId
	
	if(input.ctxProductEdges) {
		input.ctxProductEdges.each {
			if (it.fromCtxId.equals(catenaxID)) {
				toCtxId = it.toCtxId
			}
		}
	} else {
	    toCtxId = catenaxID
	}
	
	if (input.ctxObjects) {
		input.ctxObjects.each {
			if (it.ctxId.equals(toCtxId)) {
				if (it.ProductSerialNumber) {
					message.setHeader('productName', it.ProductSerialNumber.productName)
					message.setHeader('productId', it.ProductSerialNumber.productId)
				} else if (it.DeliveredSerializedProduct) {
					if (it.DeliveredSerializedProduct.ctxBPId.equals(edc_bpn)) {
						message.setHeader('edc-bpn_known', 'true')
					    message.setHeader('customerProductId', it.DeliveredSerializedProduct.customerProductId)
					}
				} else if (it.ProductBatch) {
					message.setHeader('productName', it.ProductBatch.productName)
					message.setHeader('productId', it.ProductBatch.productId)
				} else if (it.DeliveredProductBatch) {
					if (it.DeliveredProductBatch.ctxBPId.equals(edc_bpn)) {
						message.setHeader('edc-bpn_known', 'true')
					    message.setHeader('customerProductId', it.DeliveredProductBatch.customerProductId)
					}
				}
			}
		}
	}		
	return message
}
