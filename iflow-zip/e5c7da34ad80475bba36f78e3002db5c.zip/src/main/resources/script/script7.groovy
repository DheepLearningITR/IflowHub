/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {
    //Body
    body = message.getBody(String)
    properties = message.getProperties()

    mapH = message.getHeaders()
    id_in = mapH.get('id_in')

    jsonSlurper = new JsonSlurper()
    lbnAsset = jsonSlurper.parseText(body)

    submodelInstance = """{
  \"submodels\": [
    {
          \"modelType\": \"Submodel\",
          \"kind\": \"Template\",
          \"semanticId\":
                  {
                      \"keys\": [
                          {
                              \"type\": \"ConceptDescription\",
                              \"value\": \"urn:bamm:io.catenax.batch:2.0.0#Batch\"
                          }
                      ],
                      \"type\": \"ModelReference\"
                  },
          \"administration\":
                  {
                      \"revision\": \"1\",
                      \"version\": \"0\"
                  },
          \"id\": \"""" + id_in + """\",
          \"idShort\": \"Batch\",
          \"description\":  [
                  {
                      \"language\": \"en\",
                      \"text\": \"A batch is a quantity of (semi-) finished products or (raw) material product that have been produced under the same circumstances (e.g. same production location), as specified groups or amounts, within a certain time frame. Every batch can differ in the number or amount of products. Different batches can have varied specifications, e.g., different colors. A batch is identified via a Batch ID.\"
                  }
              ],
          \"submodelElements\": [
              {
                  \"modelType\": \"Property\",
                  \"kind\": \"Template\",
                  \"semanticId\":
                          {
                              \"keys\": [
                                  {
                                      \"type\": \"ConceptDescription\",
                                      \"value\": \"urn:bamm:io.catenax.batch:2.0.0#catenaXId\"
                                  }
                              ],
                              \"type\": \"ModelReference\"
                          },
                  \"value\": \"""" + lbnAsset.catenaXId + """\",
                  \"valueType\": \"xs:string\",
                  \"idShort\": \"catenaXId\",
                  \"description\":  [
                          {
                              \"language\": \"en\",
                              \"text\": \"The fully anonymous Catena-X ID of the batch, valid for the Catena-X dataspace.\"
                          }
                      ],
                  \"displayName\":  [
                          {
                              \"language\": \"en\",
                              \"text\": \"Catena-X Identifier\"
                          }
                      ]

              },
              {
                  \"modelType\": \"SubmodelElementCollection\",
                  \"kind\": \"Template\",
                  \"semanticId\": {
                      \"keys\": [
                          {

                              \"type\": \"ConceptDescription\",
                              \"value\": \"urn:bamm:io.catenax.batch:2.0.0#localIdentifiers\"
                          }
                      ],
                      \"type\": \"ModelReference\"
                  },
                  \"idShort\": \"localIdentifiers\",
                  \"displayName\": [
                      {
                          \"language\": \"en\",
                          \"text\": \"Local Identifiers\"
                      }
                  ],
                  \"description\": [
                      {
                          \"language\": \"en\",
                          \"text\": \"A local identifier enables identification of a part in a specific dataspace, but is not unique in Catena-X dataspace. Multiple local identifiers may exist.\"
                      }
                  ],
                  \"allowDuplicates\": false,
                  \"ordered\": false,
                  \"value\": [
                    """

    // loop for localIdentifiers
    for (int i = 0; i < lbnAsset.localIdentifiers.size(); i++) {
        submodelInstance = submodelInstance + """{
                      \"modelType\": \"SubmodelElementCollection\",
                      \"kind\": \"Template\",
                      \"semanticId\": {
                          \"keys\": [
                              {
                                  \"type\": \"ConceptDescription\",
                                  \"value\": \"urn:bamm:io.catenax.batch:2.0.0#KeyValueList\"
                              }
                          ],
                          \"type\": \"ModelReference\"
                      },
                      \"idShort\": \"KeyValueList\",
                      \"displayName\": [
                          {
                              \"language\": \"en\",
                              \"text\": \"Key Value List\"
                          }
                      ],
                      \"description\": [
                          {
                              \"language\": \"en\",
                              \"text\": \"A list of key value pairs for local identifiers, which are composed of a key and a corresponding value.\"
                          }
                      ],
                      \"allowDuplicates\": false,
                      \"ordered\": false,
                      \"value\": [
                          {
                              \"modelType\": \"Property\",
                              \"kind\": \"Template\",
                              \"semanticId\": {
                                  \"keys\": [
                                      {
                                          \"type\": \"ConceptDescription\",
                                          \"value\": \"urn:bamm:io.catenax.batch:2.0.0#key\"
                                      }
                                  ],
                                  \"type\": \"ModelReference\"
                              },
                              \"value\": \"""" + lbnAsset.localIdentifiers[i].key + """\",
                              \"valueType\": \"xs:string\",
                              \"idShort\": \"key\",
                              \"description\": [
                                  {
                                      \"language\": \"en\",
                                      \"text\": \"The key of a local identifier.\"
                                  }
                              ],
                              \"displayName\":  [
                                  {
                                      \"language\": \"en\",
                                      \"text\": \"Identifier Key\"
                                  }
                              ]

                          },
                          {
                              \"modelType\": \"Property\",
                              \"kind\": \"Template\",
                              \"semanticId\": {
                                  \"keys\": [
                                      {
                                          \"type\": \"ConceptDescription\",
                                          \"value\": \"urn:bamm:io.catenax.batch:2.0.0#value\"
                                      }
                                  ],
                                  \"type\": \"ModelReference\"
                              },
                              \"value\": \"""" + lbnAsset.localIdentifiers[i].value + """\",
                              \"valueType\": \"xs:string\",
                              \"idShort\": \"value\",
                              \"description\": [
                                  {
                                      \"language\": \"en\",
                                      \"text\": \"The value of an identifier.\"
                                  }
                              ],
                              \"displayName\":  [
                                  {
                                      \"language\": \"en\",
                                      \"text\": \"Identifier Value\"
                                  }
                              ]

                          }
                      ]
                    }"""
        if (lbnAsset.localIdentifiers.size() > (i + 1)) {
            submodelInstance = submodelInstance + ','
        }
    }
    // loop for localIdentifiers ending here

    submodelInstance = submodelInstance + """]
                },
                    {
                        \"modelType\": \"SubmodelElementCollection\",
                        \"kind\": \"Template\",
                        \"semanticId\": {
                            \"keys\": [
                                {

                                    \"type\": \"ConceptDescription\",
                                    \"value\": \"urn:bamm:io.catenax.batch:2.0.0#ManufacturingEntity\"
                                }
                            ],
                            \"type\": \"ModelReference\"
                        },
                        \"idShort\": \"ManufacturingEntity\",
                        \"displayName\": [
                            {
                                \"language\": \"en\",
                                \"text\": \"Manufacturing Entity\"
                            }
                        ],
                        \"description\": [
                            {
                                \"language\": \"en\",
                                \"text\": \"Encapsulates the manufacturing relevant attributes\"
                            }
                        ],
                        \"allowDuplicates\": false,
                        \"ordered\": false,
                        \"value\": [
                          {
                            \"modelType\": \"Property\",
                            \"kind\": \"Template\",
                            \"semanticId\": {
                                \"keys\": [
                                    {
                                        \"type\": \"ConceptDescription\",
                                        \"value\": \"urn:bamm:io.catenax.batch:2.0.0#date\"
                                    }
                                ],
                                \"type\": \"ModelReference\"
                            },
                            \"idShort\": \"date\",
                            \"displayName\": [
                                {
                                    \"language\": \"en\",
                                    \"text\": \"Production Date\"
                                }
                            ],
                            \"description\": [
                                {
                                    \"language\": \"en\",
                                    \"text\": \"Timestamp of the manufacturing date as the final step in production process (e.g. final quality check, ready-for-shipment event)\"
                                }
                            ],
                            \"valueType\": \"xs:dateTime\",
                            \"value\": \"""" + lbnAsset.manufacturingInformation.date + """\"
                        },
                          {
                            \"modelType\": \"Property\",
                            \"kind\": \"Template\",
                            \"semanticId\": {
                                \"keys\": [
                                    {
                                        \"type\": \"ConceptDescription\",
                                        \"value\": \"urn:bamm:io.catenax.batch:2.0.0#country\"
                                    }
                                ],
                                \"type\": \"ModelReference\"
                            },
                            \"idShort\": \"country\",
                            \"displayName\": [
                                {
                                    \"language\": \"en\",
                                    \"text\": \"Country code\"
                                }
                            ],
                            \"description\": [
                                {
                                    \"language\": \"en\",
                                    \"text\": \"Country code where the part was manufactured\"
                                }
                            ],
                            \"valueType\": \"xs:string\",
                            \"value\": \"""" + lbnAsset.manufacturingInformation.country + """\"
                        }
                  ]
              },
              {
                  \"modelType\": \"SubmodelElementCollection\",
                  \"kind\": \"Template\",
                  \"semanticId\": {
                      \"keys\": [
                          {

                              \"type\": \"ConceptDescription\",
                              \"value\": \"urn:bamm:io.catenax.batch:2.0.0#PartTypeInformationEntity\"
                          }
                      ],
                      \"type\": \"ModelReference\"
                  },
                  \"idShort\": \"PartTypeInformationEntity\",
                  \"displayName\": [
                      {
                          \"language\": \"en\",
                          \"text\": \"Part Type Information Entity\"
                      }
                  ],
                  \"description\": [
                      {
                          \"language\": \"en\",
                          \"text\": \"Encapsulation for data related to the part type\"
                      }
                  ],
                  \"allowDuplicates\": false,
                  \"ordered\": false,
                  \"value\": [
                    {
                      \"modelType\": \"Property\",
                      \"kind\": \"Template\",
                      \"semanticId\": {
                          \"keys\": [
                              {
                                  \"type\": \"ConceptDescription\",
                                  \"value\": \"urn:bamm:io.catenax.batch:2.0.0#manufacturerPartId\"
                              }
                          ],
                          \"type\": \"ModelReference\"
                      },
                      \"idShort\": \"manufacturerPartId\",
                      \"displayName\": [
                          {
                              \"language\": \"en\",
                              \"text\": \"Manufacturer Part ID\"
                          }
                      ],
                      \"description\": [
                          {
                              \"language\": \"en\",
                              \"text\": \"Part ID as assigned by the manufacturer of the part. The Part ID identifies the part (as designed) in the manufacturer`s dataspace. The Part ID does not reference a specific instance of a part and thus should not be confused with the batch number.\"
                          }
                      ],
                      \"valueType\": \"xs:string\",
                      \"value\": \"""" + lbnAsset.partTypeInformation.manufacturerPartId + """\"
                  },
                    {
                      \"modelType\": \"Property\",
                      \"kind\": \"Template\",
                      \"semanticId\": {
                          \"keys\": [
                              {
                                  \"type\": \"ConceptDescription\",
                                  \"value\": \"urn:bamm:io.catenax.batch:2.0.0#nameAtManufacturer\"
                              }
                          ],
                          \"type\": \"ModelReference\"
                      },
                      \"idShort\": \"nameAtManufacturer\",
                      \"displayName\": [
                          {
                              \"language\": \"en\",
                              \"text\": \"Name at Manufacturer\"
                          }
                      ],
                      \"description\": [
                          {
                              \"language\": \"en\",
                              \"text\": \"Name of the part as assigned by the manufacturer\"
                          }
                      ],
                      \"valueType\": \"xs:string\",
                      \"value\": \"""" + lbnAsset.partTypeInformation.nameAtManufacturer + """\"
                  },
                    {
                      \"modelType\": \"Property\",
                      \"kind\": \"Template\",
                      \"semanticId\": {
                          \"keys\": [
                              {
                                  \"type\": \"ConceptDescription\",
                                  \"value\": \"urn:bamm:io.catenax.batch:2.0.0#classification\"
                              }
                          ],
                          \"type\": \"ModelReference\"
                      },
                      \"idShort\": \"classification\",
                      \"displayName\": [
                          {
                              \"language\": \"en\",
                              \"text\": \"Classifcation\"
                          }
                      ],
                      \"description\": [
                          {
                              \"language\": \"en\",
                              \"text\": \"The classification of the part type according to STEP standard definition\"
                          }
                      ],
                      \"valueType\": \"xs:string\",
                      \"value\": \"""" + lbnAsset.partTypeInformation.classification + """\"
                  }
            ]
        }
        ]
    }
  ]
}"""

    message.setBody(submodelInstance)
    return message
}
