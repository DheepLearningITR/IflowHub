import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;
import groovy.util.*;
import groovy.xml.XmlUtil;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String getIntValue(String value){
	return Integer.parseInt(value)
}

def String getMessageId(String p1, MappingContext context){
    String messageId = context.getHeader("SapMessageIdEx")
    return messageId
}

def Message getOpptId(Message message) {

  //Body 
  def body = message.getBody(java.io.Reader)
  JsonSlurper slurper = new JsonSlurper()
  Map parsedJson = slurper.parse(body)
  message.setProperty("P_OPP_ID", parsedJson.value[0].id)
  def xml = XmlUtil.serialize(message.getProperty("P_IDOC"));
  message.setBody(xml);
  return message
}

def Message getOpptDisplayId(Message message) {

    def body_xml = message.getBody(String.class)
    def list = new XmlSlurper().parseText(body_xml) 
    def displId = list.IDOC.E1EDK02.findAll{ node-> node.QUALF == '054' }.BELNR
    message.setProperty("P_OPPT_DISP_ID", displId)
    message.setProperty("P_IDOC", body_xml)

    return message
}

def String getdefaultS4ID(String p1, MappingContext context){
	return context.getProperty(p1);
}

def String getOpptID(String p1, MappingContext context){
	return context.getProperty(p1);
}

def String generateUUID(String value){
	return UUID.randomUUID().toString()
}

