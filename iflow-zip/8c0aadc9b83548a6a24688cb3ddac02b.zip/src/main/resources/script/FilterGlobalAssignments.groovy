import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import static java.util.Calendar.*
import java.lang.String;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.text.DateFormat;
import java.text.DecimalFormat
import groovy.xml.MarkupBuilder
import com.sap.it.spi.ITApiHandler;
import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.*;
import groovy.xml.StreamingMarkupBuilder 
import java.text.SimpleDateFormat;

def Message processData(Message message) {
       //Body 
       def body = message.getBody(java.io.Reader);
       def root = new XmlSlurper().parse(body);
           root.CompoundEmployee.each{CE->
                    CE.person.employment_information.each{ 
                          if( it.assignment_class == 'GA'){
                                 it.replaceNode{}
                          }
                          
                    }
                    
                    
             }
             def newRoot = new StreamingMarkupBuilder().bind {
                    mkp.yield root
             }.toString()
             
             message.setBody(newRoot.toString())
             return message
             
       }
       
	 