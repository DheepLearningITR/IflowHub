import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
      	
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	//Reading Properties 
     def  pMap = message.getProperties();
     def EnableLogging = pMap.get("ResponseLogging");
     

    if(EnableLogging =='true') {
       messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment");
       messageLog.addAttachmentAsString("Webservice Response:", body , "text/plain");
	}
    return message;
} 