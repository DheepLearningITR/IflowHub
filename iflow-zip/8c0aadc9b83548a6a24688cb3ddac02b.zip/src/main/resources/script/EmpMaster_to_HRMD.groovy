import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import static java.util.Calendar.*
import java.lang.String;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.text.DateFormat;
import java.text.DecimalFormat
import groovy.xml.MarkupBuilder
import com.sap.it.spi.ITApiHandler;
import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.*;
import groovy.xml.StreamingMarkupBuilder 
import java.text.SimpleDateFormat;
import com.sap.it.api.mapping.MappingContext;

def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.io.Reader);
       def root = new XmlSlurper().parse(body);
       def xmlBuilder = new StreamingMarkupBuilder(); 
       //Get Headers 
       def map = message.getHeaders();
	  // def value = map.get("DocumentNumber");
	   def Properties = message.getProperties();

    //Loop for each compound employee entity
  String output = xmlBuilder.bind{
			ZHRMD_A07{
				IDOC (BEGIN : "1"){
					mkp.yieldUnescaped EDI_DC40();
					root.CompoundEmployee.each{ compoundEmployee->
						def _person = compoundEmployee.person
						String _userId = ""
						String _previousStaffID = ""
						String _empStartDate = ""
						String ObjectID = _person.person_id_external.toString().padLeft(8, "0")
						String ObjectID1 = _person.person_id_external.toString()
						def employment_home;
						employment_home = _person.snapshot[0].employment_information[0];
						_userId = _person.snapshot[0].employment_information[0].user_id.toString()
						_previousStaffID = _person.snapshot[0].employment_information[0].prevEmployeeId.toString()
						_empStartDate = _person.snapshot[0].employment_information[0].start_date.toString();
													
						E1PLOGI (SEGMENT: "1"){
							'PLVAR' '01'
							'OTYPE' 'P'
							'OBJID' (ObjectID)
							if(_person.action.toString().toUpperCase().equals("INSERT"))
							{
								'OPERA' 'I'
							}
							else
							{
								'OPERA' 'U'
							}
							if(_person.snapshot.employment_information.job_information!='')
								mkp.yieldUnescaped buildInfoType0000("0000",ObjectID1,_person.snapshot);
							if(_person.snapshot.employment_information.job_information!='')
								mkp.yieldUnescaped buildInfoType0001("0001",ObjectID1,_person.snapshot);
							if(_person.personal_information!='')
								mkp.yieldUnescaped buildInfoType0002("0002",ObjectID1,_person,_person.personal_information);
							/*if(_person.address_information != '')
								mkp.yieldUnescaped buildInfoType0006_Home("0006",_userId,_person.address_information); */
							if(_person.address_information != '')
								mkp.yieldUnescaped buildInfoType0006_current("0006",ObjectID1,_person.address_information);
							if(_person.emergency_contact_primary != '')
								mkp.yieldUnescaped buildInfoType0006_E("0006",ObjectID1,_person.emergency_contact_primary);
							if(_person.snapshot.employment_information.compensation_information != '')
								mkp.yieldUnescaped buildInfoType0008("0008",ObjectID1,_person.snapshot);
							/*if(_person.snapshot.employment_information.job_information!='')
								mkp.yieldUnescaped buildInfoType0016("0016",_userId,_person.snapshot);*/
							if(_person.dependent_information!='')
								mkp.yieldUnescaped buildInfoType0021("0021",ObjectID1,_person.dependent_information);
							if(_person.snapshot.employment_information!='')
								mkp.yieldUnescaped buildInfoType0032("0032",_userId,_person.snapshot[0].employment_information);
							if(_person.snapshot.employment_information!='')
								mkp.yieldUnescaped buildInfoType0041("0041",ObjectID1,_person.snapshot[0].employment_information);
							if(_person.snapshot.employment_information.job_information!='')
								mkp.yieldUnescaped buildInfoType0050("0050",ObjectID1,_person.snapshot);
							//if(_person.phone_information!='')
								mkp.yieldUnescaped buildInfoType0105_emp("0105",ObjectID1,_person,_person.snapshot[0].employment_information);
							if(_person.phone_information!='')
								mkp.yieldUnescaped buildInfoType0105_ph("0105",ObjectID1,_empStartDate,_person.phone_information);
							if(_person.email_information!='')
								mkp.yieldUnescaped buildInfoType0105_email("0105",ObjectID1,_empStartDate,_person.email_information);
							if(_person.national_id_card!='')
								mkp.yieldUnescaped buildInfoType0185_NationalID("0185",ObjectID1,_person.national_id_card);
							if(employment_home.personal_documents_information!='')
								mkp.yieldUnescaped buildInfoType0185_EmpDocumentID("0185",ObjectID1,employment_home);
							if(_person.snapshot.employment_information!='')
								mkp.yieldUnescaped buildInfoType0185_StaffID("0185",ObjectID1,_person.snapshot[0].employment_information);
							if(_person.snapshot.employment_information.WorkOrder!='')
								mkp.yieldUnescaped buildInfoType9007_WorkOrder("9007",ObjectID1,_person.snapshot[0].employment_information.WorkOrder);
                                             
                                       }
                                 }
                          }
                    }
             }
             
             
             message.setBody(output.toString())
             return message
             
       }
       
       
       //Function to transform the date format from yyyy-MM-dd to yyyyMMdd
    public static String transformDate(String stringDate){
			String strDate = stringDate;
			if(!stringDate.trim().equals("")){
			SimpleDateFormat simpleDateformatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = simpleDateformatter.parse(stringDate);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
			 strDate= formatter.format(date);
			}
			return strDate;
		}
		
		
       //Create Control segment in the IDOC
       public static def EDI_DC40(){
             def outputBuilder = new StreamingMarkupBuilder()
             outputBuilder.encoding = "UTF-8"
            // String docNum = "100" + DocumentNumber
             def output = outputBuilder.bind{
                    EDI_DC40 (SEGMENT: "1"){
                          TABNAM('EDI_DC40')
                          DOCNUM("")
                          SNDPRN("CPICLNT000")
                       
                    }
             }
             return output;
       }  
       
       
	// To create the Info type 0000 in the IDOC
	public static def buildInfoType0000(String infoType,String pernr, def snapShot){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean jobinfoChanged = false;
		for(int i=0; i<snapShot.size(); i++) {
			def job_info = snapShot[i].employment_information.job_information
			if(job_info.action.text() == "INSERT")
			{
				//Check if there is a new job information found in the query response
				jobinfoChanged = true;
				break;
			}
			else if(!(job_info.event_previous.isEmpty())
			|| !(job_info.event_reason_previous.isEmpty())
			|| !(job_info.emplStatus_previous.isEmpty()))
			{
				//Check if there is a Job information which has event, event reason or employment status changed
				jobinfoChanged = true;
				break;
			}
		}
		if(jobinfoChanged)
		{
			def output = outputBuilder.bind{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					BEGDA("18000101")
					ENDDA("99991231")
					def tempStartDate = ""
					def tempEndDate = ""
					for(int i=0; i<snapShot.size(); i++) {
						if((i == 0) || (snapShot[i].employment_information.job_information.start_date.text() != tempStartDate)) {
							E1P0000(SEGMENT: "1"){
								PERNR(pernr.padLeft(8, "0"))
								INFTY(infoType)
								ENDDA(transformDate(snapShot[i].employment_information.job_information.end_date.text()))
								BEGDA(transformDate(snapShot[i].employment_information.job_information.start_date.text()))
								if (snapShot[i].employment_information.job_information.event_reason.text().length() >= 4)
								{
								MASSN(snapShot[i].employment_information.job_information.event_reason.text().substring(0,2))
								MASSG(snapShot[i].employment_information.job_information.event_reason.text().substring(2,4))
								}
								STAT2(snapShot[i].employment_information.job_information.emplStatus.text())
								tempStartDate = snapShot[i].employment_information.job_information.start_date.text()
								tempEndDate = snapShot[i].employment_information.job_information.end_date.text()
							}     //Closing tag for E1P0000
						}

					} // Closing tag for for loop 

					//Closing bracket for E1PITYP
				}
			}
			return output;
		}
		else
			return '';
	}

	// To Create the Info Type 0001 in the IDOC
	public static def buildInfoType0001(String infoType,String pernr,def snapShot){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean jobInfoChanged = false;
		for(int i=0; i<snapShot.size(); i++) {
			def job_info = snapShot[i].employment_information.job_information
			def comp_info = snapShot[i].employment_information.compensation_information
			if(job_info.action.text() == "INSERT")
			{
				//Check if there is a New job information record found in the query response
				jobInfoChanged = true;
				break;
			}
			else if(!(job_info.business_unit_previous.isEmpty())
			|| !(job_info.location_previous.isEmpty())
			|| !(job_info.employee_class_previous.isEmpty())
			|| !(job_info.cost_center_previous.isEmpty())
			|| !(job_info.job_code_previous.isEmpty())
			|| !(job_info.employment_type_previous.isEmpty())
			|| !(job_info.position_previous.isEmpty())
			|| !(job_info.department_previous.isEmpty())
			|| !(job_info.custom_string6_previous.isEmpty())
			|| !(job_info.custom_string9_previous.isEmpty())
			|| !(comp_info.custom_string3_previous.isEmpty())
			|| !(comp_info.pay_group_previous.isEmpty())
			|| !(job_info.custom_string8_previous.isEmpty()))
			{
				//println "change for info type 0001 found at job_information" + i
				jobInfoChanged = true;
				break;
			}
		}
		if(jobInfoChanged)
		{
			def output = outputBuilder.bind{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					BEGDA("18000101")
					ENDDA("99991231")
					
					for(int i=0; i<snapShot.size(); i++) {
						E1P0001(SEGMENT: "1"){
							PERNR(pernr.padLeft(8, "0"))
							INFTY(infoType)
							if (i < snapShot.size()-1)
							{
								SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
								Date inputDate = formatter.parse(snapShot[i+1].asOfDate.text());
								Calendar cal = Calendar.getInstance();
								cal.setTime(inputDate);
								cal.add(Calendar.DATE, -1);
								inputDate = cal.getTime();
								ENDDA(transformDate(formatter.format(inputDate)))
							}
							else
							{
								ENDDA("99991231")
							}
							BEGDA(transformDate(snapShot[i].asOfDate.text()))
							BUKRS(snapShot[i].employment_information.job_information.business_unit.text())
							if (snapShot[i].employment_information.job_information.location.text().length() > 0)
							{
								WERKS(snapShot[i].employment_information.job_information.location.text().substring(0,4))
							}
							else
							{
								WERKS(snapShot[i].employment_information.job_information.location.text())
							}
							PERSG(snapShot[i].employment_information.job_information.employee_class.text())
							PERSK(snapShot[i].employment_information.job_information.employment_type.text())
							if (snapShot[i].employment_information.job_information.location.text().length() > 0)
							{
								BTRTL(snapShot[i].employment_information.job_information.location.text().substring(5,9))
							}
							else
							{
								BTRTL(snapShot[i].employment_information.job_information.location.text())
							}

							ABKRS(snapShot[i].employment_information.compensation_information.pay_group.text())
							if(snapShot[i].employment_information.job_information.cost_center.text().length() > 10)
							{
							KOSTL(snapShot[i].employment_information.job_information.cost_center.text().substring (snapShot[i].employment_information.job_information.cost_center.text().length() - 10))
							}
							else
							{
							KOSTL(snapShot[i].employment_information.job_information.cost_center.text().padLeft(10, "0"))
							}
							ORGEH(snapShot[i].employment_information.job_information.department.text())
							PLANS(snapShot[i].employment_information.job_information.position.text())
							if(snapShot[i].employment_information.job_information.job_code.text() != "")
							{
								STELL(snapShot[i].employment_information.job_information.job_code.text())
							}
							else
								STELL("00000000")

							Z1P0001(SEGMENT: "1")
							{
							    ZZCUSTF(snapShot[i].employment_information.job_information.custom_string8.text())
								ZZDIVISION(snapShot[i].employment_information.job_information.division.text())
								ZZDEPARTMENT(snapShot[i].employment_information.job_information.custom_string2.text())
								ZZRECF(snapShot[i].employment_information.job_information.custom_string9.text())
								ZZETRV(snapShot[i].employment_information.job_information.custom_string6.text())
							}

						}

					}
				}
				//Closing bracket for E1PITYP segment
			}
			//Closing bracket of Output Node Generation
			return output;
		}
		else
			return '';

	}

    //Create infotype 0002 for personal information delta
	public static def buildInfoType0002(String infoType,String pernr,def per,def is_per){
		def outputBuilder = new StreamingMarkupBuilder();
		outputBuilder.encoding = "UTF-8"
		boolean personInfoChanged = false;
		boolean countrySpecific = false;
	    for(int i=0; i<is_per.size(); i++) {
			def personal_info = is_per[i]
			if(((personal_info.personal_information_are.action.text() == "INSERT") || !(personal_info.personal_information_are.genericString1_previous.isEmpty()))
				|| ((personal_info.personal_information_che.action.text() == "INSERT") || !(personal_info.personal_information_che.genericString1_previous.isEmpty()))
				|| ((personal_info.personal_information_aus.action.text() == "INSERT") || !(personal_info.personal_information_aus.genericString1_previous.isEmpty()))
				|| ((personal_info.personal_information_bgd.action.text() == "INSERT") || !(personal_info.personal_information_bgd.genericString3_previous.isEmpty()))
				|| ((personal_info.personal_information_egy.action.text() == "INSERT") || !(personal_info.personal_information_egy.genericString5_previous.isEmpty()))
				|| ((personal_info.personal_information_grc.action.text() == "INSERT") || !(personal_info.personal_information_grc.genericString7_previous.isEmpty()))
				|| ((personal_info.personal_information_ind.action.text() == "INSERT") || !(personal_info.personal_information_ind.genericNumber1_previous.isEmpty()))
				|| ((personal_info.personal_information_idn.action.text() == "INSERT") || !(personal_info.personal_information_idn.genericString5_previous.isEmpty()))
				|| ((personal_info.personal_information_irq.action.text() == "INSERT") || !(personal_info.personal_information_irq.genericString5_previous.isEmpty()))
				|| ((personal_info.personal_information_irl.action.text() == "INSERT") || !(personal_info.personal_information_irl.genericString1_previous.isEmpty()))
				|| ((personal_info.personal_information_jpn.action.text() == "INSERT") || !(personal_info.personal_information_jpn.genericString14_previous.isEmpty()))
				|| ((personal_info.personal_information_jor.action.text() == "INSERT") || !(personal_info.personal_information_jor.genericString3_previous.isEmpty()))
				|| ((personal_info.personal_information_ken.action.text() == "INSERT") || !(personal_info.personal_information_ken.genericString3_previous.isEmpty()))
				|| ((personal_info.personal_information_kwt.action.text() == "INSERT") || !(personal_info.personal_information_kwt.genericString2_previous.isEmpty()))
				|| ((personal_info.personal_information_lbn.action.text() == "INSERT") || !(personal_info.personal_information_lbn.genericString13_previous.isEmpty()))
				|| ((personal_info.personal_information_mys.action.text() == "INSERT") || !(personal_info.personal_information_mys.genericString5_previous.isEmpty()))
				|| ((personal_info.personal_information_nga.action.text() == "INSERT") || !(personal_info.personal_information_nga.genericString4_previous.isEmpty()))
				|| ((personal_info.personal_information_omn.action.text() == "INSERT") || !(personal_info.personal_information_omn.genericString3_previous.isEmpty()))
				|| ((personal_info.personal_information_pak.action.text() == "INSERT") || !(personal_info.personal_information_pak.genericString2_previous.isEmpty()))
				|| ((personal_info.personal_information_phl.action.text() == "INSERT") || !(personal_info.personal_information_phl.genericString5_previous.isEmpty()))
				|| ((personal_info.personal_information_rus.action.text() == "INSERT") || !(personal_info.personal_information_rus.genericString1_previous.isEmpty()))
				|| ((personal_info.personal_information_sau.action.text() == "INSERT") || !(personal_info.personal_information_sau.genericString5_previous.isEmpty()))
				|| ((personal_info.personal_information_sgp.action.text() == "INSERT") || !(personal_info.personal_information_sgp.genericString1_previous.isEmpty()))
				|| ((personal_info.personal_information_zaf.action.text() == "INSERT") || !(personal_info.personal_information_zaf.genericString5_previous.isEmpty()))
				|| ((personal_info.personal_information_kor.action.text() == "INSERT") || !(personal_info.personal_information_kor.genericString5_previous.isEmpty()))
				|| ((personal_info.personal_information_lka.action.text() == "INSERT") || !(personal_info.personal_information_che.genericString3_previous.isEmpty()))
				|| ((personal_info.personal_information_tha.action.text() == "INSERT") || !(personal_info.personal_information_che.genericString5_previous.isEmpty()))
				|| ((personal_info.personal_information_gbr.action.text() == "INSERT") || !(personal_info.personal_information_che.genericString2_previous.isEmpty()))
				|| ((personal_info.personal_information_vnm.action.text() == "INSERT") || !(personal_info.personal_information_che.genericString6_previous.isEmpty())))
			{
			 countrySpecific = true; 
			}
			if((personal_info.action.text() == "INSERT") || (per.action.text() == "INSERT") || countrySpecific)
			{
				personInfoChanged = true;
				break;
			}
			else if(!(personal_info.last_name_previous.isEmpty())
			|| !(personal_info.first_name_previous.isEmpty())
			|| !(personal_info.employee_class_previous.isEmpty())
			|| !(personal_info.salutation_previous.isEmpty())
			|| !(personal_info.gender_previous.isEmpty())
			|| !(personal_info.nationality_previous.isEmpty())
			|| !(personal_info.second_nationality_previous.isEmpty())
			|| !(personal_info.third_nationality_previous.isEmpty())
			|| !(personal_info.native_preferred_lang_previous.isEmpty())
			|| !(personal_info.marital_status_previous.isEmpty())
			|| !(personal_info.native_preferred_lang_previous.isEmpty())
			|| !(personal_info.last_name_alt1_previous.isEmpty())
			|| !(personal_info.middle_name_alt1_previous.isEmpty())
			|| !(personal_info.custom_string10_previous.isEmpty())
			|| !(personal_info.custom_string5_previous.isEmpty())
			|| !(personal_info.custom_string6_previous.isEmpty())
			|| !(per.birth_name_previous.isEmpty())
			|| !(per.date_of_birth_previous.isEmpty())
			|| !(per.place_of_birth_previous.isEmpty())
			|| countrySpecific
			|| !(personal_info.first_name_alt1_previous.isEmpty()))
			{
				personInfoChanged = true;
				break;
			}
		}
		if(personInfoChanged) {
			def output = outputBuilder.bind{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					BEGDA("18000101")
					ENDDA("99991231")
					

					for(int i=0; i<is_per.size(); i++) {
						E1P0002(SEGMENT: "1")
						{
							PERNR(pernr.padLeft(8, "0"))
							INFTY(infoType)
							ENDDA(transformDate(is_per[i].end_date.text()))
							BEGDA(transformDate(is_per[i].start_date.text()))
							NACHN(is_per[i].last_name.text())
							VORNA(is_per[i].first_name.text())
							RUFNM(per.birth_name.text())
							KNZNM("00")
							ANRED(is_per[i].salutation.text())
							GESCH(is_per[i].gender.text())
							GBDAT(transformDate(per.date_of_birth.text()))
							GBLND(per.country_of_birth.text())
							GBORT(per.place_of_birth.text())
							VORNA_40(is_per[i].custom_string5.text())
							NACHN_40(is_per[i].custom_string6.text())
							NATIO(is_per[i].nationality.text())
							if (is_per[i].second_nationality.text().length() > 0)
							{
							NAT12(is_per[i].second_nationality.text())
							}
							if (is_per[i].third_nationality.text().length() > 0)
							{
							NAT13(is_per[i].third_nationality.text())
							}
							SPRSL(is_per[i].native_preferred_lang.text())
							if(is_per[i].personal_information_are != '')
								{
									KONFE(is_per[i].personal_information_are.genericString1.text())
								}
							if(is_per[i].personal_information_che != '')
								{
									KONFE(is_per[i].personal_information_che.genericString1.text())
								}
							if(is_per[i].personal_information_sgp != '')
								{
									KONFE(is_per[i].personal_information_sgp.genericString1.text())
								}
							if(is_per[i].personal_information_rus != '')
								{
									KONFE(is_per[i].personal_information_rus.genericString1.text())
								}
							if(is_per[i].personal_information_irl != '')
								{
									KONFE(is_per[i].personal_information_irl.genericString1.text())
								}
							if(is_per[i].personal_information_aus != '')
								{
									KONFE(is_per[i].personal_information_aus.genericString1.text())
								}
							if(is_per[i].personal_information_ind != '')
								{
									KONFE(is_per[i].personal_information_are.genericNumber1.text())
								}
							if(is_per[i].personal_information_lbn != '')
								{
									KONFE(is_per[i].personal_information_lbn.genericString13.text())
								}
							if(is_per[i].personal_information_jpn != '')
								{
									KONFE(is_per[i].personal_information_jpn.genericString14.text())
								}
							if(is_per[i].personal_information_kwt != '')
								{
									KONFE(is_per[i].personal_information_kwt.genericString2.text())
								}
							if(is_per[i].personal_information_kwt != '')
								{
									KONFE(is_per[i].personal_information_kwt.genericString2.text())
								}
							if(is_per[i].personal_information_pak != '')
								{
									KONFE(is_per[i].personal_information_pak.genericString2.text())
								}
							if(is_per[i].personal_information_gbr != '')
								{
									KONFE(is_per[i].personal_information_gbr.genericString2.text())
								}
							if(is_per[i].personal_information_bgd != '')
								{
									KONFE(is_per[i].personal_information_bgd.genericString3.text())
								}
							if(is_per[i].personal_information_jor != '')
								{
									KONFE(is_per[i].personal_information_jor.genericString3.text())
								}
							if(is_per[i].personal_information_ken != '')
								{
									KONFE(is_per[i].personal_information_ken.genericString3.text())
								}
							if(is_per[i].personal_information_omn != '')
								{
									KONFE(is_per[i].personal_information_omn.genericString3.text())
								}
							if(is_per[i].personal_information_lka != '')
								{
									KONFE(is_per[i].personal_information_lka.genericString3.text())
								}
							if(is_per[i].personal_information_nga != '')
								{
									KONFE(is_per[i].personal_information_nga.genericString4.text())
								}
							if(is_per[i].personal_information_egy != '')
								{
									KONFE(is_per[i].personal_information_egy.genericString5.text())
								}
							if(is_per[i].personal_information_idn != '')
								{
									KONFE(is_per[i].personal_information_idn.genericString5.text())
								}
							if(is_per[i].personal_information_irq != '')
								{
									KONFE(is_per[i].personal_information_irq.genericString5.text())
								}
							if(is_per[i].personal_information_mys != '')
								{
									KONFE(is_per[i].personal_information_mys.genericString5.text())
								}
							if(is_per[i].personal_information_kor != '')
								{
									KONFE(is_per[i].personal_information_kor.genericString5.text())
								}
							if(is_per[i].personal_information_phl != '')
								{
									KONFE(is_per[i].personal_information_phl.genericString5.text())
								}
							if(is_per[i].personal_information_sau != '')
								{
									KONFE(is_per[i].personal_information_sau.genericString5.text())
								}
							if(is_per[i].personal_information_zaf != '')
								{
									KONFE(is_per[i].personal_information_zaf.genericString5.text())
								}			
							if(is_per[i].personal_information_tha != '')
								{
									KONFE(is_per[i].personal_information_tha.genericString5.text())
								}
							if(is_per[i].personal_information_grc != '')
								{
									KONFE(is_per[i].personal_information_grc.genericString7.text())
								}
							if(is_per[i].personal_information_vnm != '')
								{
									KONFE(is_per[i].personal_information_vnm.genericString6.text())
								}
							FAMST(is_per[i].marital_status.text())
							FNAMR(is_per[i].first_name_alt1.text())
							LNAMR(is_per[i].last_name_alt1.text())
							NABIR(is_per[i].middle_name_alt1.text())
							NACH2(is_per[i].middle_name.text())
							if ((is_per[i].custom_string3.text() != "") || (is_per[i].custom_string10.text() != ""))
							{
								Z1P0002(SEGMENT: "1")
								{
									ZZNATIO(is_per[i].custom_string3.text())
									ZHOMAP(is_per[i].custom_string10.text())
								}
							}
						}
						//Closing bracket for E1P0002
					}

				}
			}
			return output;
			//closing bracket for if(flag)
		}
		else
			return '';
	}

/*	//Create Info Type 0006 for Home Address_information
	public static def buildInfoType0006_Home(String infoType,String pernr,def addr_info){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean addressInfoChanged = false;
		for(int i=0; i<addr_info.size(); i++) {
			if((addr_info[i].action.text() != "NO CHANGE") && (addr_info[i].address_type.text() == "0001"))
			{	//Check if there is a address_information segment which has a value other than NO CHANGE
				addressInfoChanged = true;
				break;
			}
		}
		if(addressInfoChanged) {
			def output = outputBuilder.bind{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					SUBTY("0001")
					BEGDA("18000101")
					ENDDA("99991231")
					
					for(int i=0; i<addr_info.size(); i++)
					{

						if(addr_info[i].address_type.text() == "0001")
						{
							mkp.yieldUnescaped addressLocalization(pernr,addr_info[i]);
						}

					}

				}

			}
			return output;
		}
		else
			return '';
	}
	
	*/

	//create Info Type 0006 for the current Address Information
	public static def buildInfoType0006_current(String infoType,String pernr,def addr_info){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean addressInfoChanged = false;
		for(int i=0; i<addr_info.size(); i++) {
			if((addr_info[i].action.text() != "NO CHANGE") && (addr_info[i].address_type.text() == "0002"))
			{
				//Check if there is a change in the current address of the employee
				addressInfoChanged = true;
				break;
			}
		}
		if(addressInfoChanged) {
			def output = outputBuilder.bind{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					SUBTY("0002")
					BEGDA("18000101")
					ENDDA("99991231")
					
					for(int i=0; i<addr_info.size(); i++)
					{
						if(addr_info[i].address_type.text().equals("0002"))
						{
							mkp.yieldUnescaped addressLocalization(pernr,addr_info[i]);
						}

					}

				}


			}
			return output;
		}
		else
			return '';
	}

	//Create Info Type 0006 for Home Emergency Address
	public static def buildInfoType0006_E(String infoType,String pernr,def is){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		//Generate a list to sore the relationship types of all emergency contacts
		List list = new ArrayList<String>();
		for(int i=0; i<is.size(); i++) {
			list.add(is[i].relationship.toString());
		}
		//initializing an integer to store index based on the emergency contact relationship found
		int j=0;
		boolean flag = false;
		//Checks if there is an emergency contact with relationship "01" (spouse)
		if(list.contains("01")) {
			j=list.indexOf("01");
			flag = true
		}
		//Checks if there is an emergency contact with relationship "03" (Father)
		if(!flag && list.contains("03")) {
			j=list.indexOf("03");
			flag = true
		}

		if(is[j].custom_string1.text().equals("0002"))
		{
		
		def output = outputBuilder.bindNode{
			E1PITYP(SEGMENT: "1"){
				PLVAR("01")
				OTYPE("P")
				OBJID (pernr.padLeft(8, "0"))
				INFTY(infoType)
				
					
				SUBTY("0004")
						
				BEGDA("18000101")
				ENDDA("99991231")
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY(infoType)
				   
					
					SUBTY("0004")
						
					ENDDA("99991231")
					BEGDA("18000101")
					ANSSA("0004")
					NAME2(is[j].name.text())
					STRAS(is[j].address2.text())
					ORT01(is[j].city.text())
					ORT02(is[j].county.text())
					PSTLZ(is[j].zip_code.text())
					LAND1(is[j].country.text())
					TELNR(is[j].phone.text())
					LOCAT(is[j].address4.text())
					STATE(is[j].state.text())
					if (is[j].address3.text().length() > 0)
					{
					HSNMR(is[j].address3.text())
					}
				}
			}
		}
		return output;
		}
		else
			return '';
	}

	//Info Type 0008 for compensation details
	public static def buildInfoType0008(String infoType,String pernr,def snapShot){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean compInfoChanged = false;
		for(int i=0; i<snapShot.size(); i++) {
			def job_info = snapShot[i].employment_information.job_information
			def comp_info = snapShot[i].employment_information.compensation_information
			//Check if there is a New job or compensation change was found in the given snapshot data
			if((job_info.action.text() == "INSERT") || (comp_info.action.text() == "INSERT"))
			{
				compInfoChanged = true;
				break;
			}
			else if(!(job_info.business_unit_previous.isEmpty())
			|| !(job_info.location_previous.isEmpty())
			|| !(job_info.employee_class_previous.isEmpty())
			|| !(job_info.cost_center_previous.isEmpty())
			|| !(job_info.job_code_previous.isEmpty())
			|| !(job_info.employment_type_previous.isEmpty())
			|| !(job_info.position_previous.isEmpty())
			|| !(job_info.department_previous.isEmpty())
			|| !(job_info.divison_previous.isEmpty())
			|| !(job_info.custom_string2_previous.isEmpty())
			|| !(job_info.custom_string6_previous.isEmpty())
			|| !(job_info.custom_string9_previous.isEmpty())
			|| !(job_info.payScaleType_previous.isEmpty())
			|| !(job_info.payScaleArea_previous.isEmpty())
			|| !(job_info.pay_grade_previous.isEmpty())
			|| !(job_info.payScaleLevel_previous.isEmpty())
			|| !(job_info.fte_previous.isEmpty())
			|| !(comp_info.custom_string3_previous.isEmpty())
			|| !(comp_info.pay_group_previous.isEmpty())
			|| !(comp_info.salaryCurrencyCode_previous.isEmpty())
			|| !(comp_info.paycompensation_recurring.paycompvalue_previous.isEmpty())
			|| !(job_info.custom_string8_previous.isEmpty()))
			{
				compInfoChanged = true;
				break;
			}
		}

		if(compInfoChanged)
		{
			def output = outputBuilder.bindNode{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					BEGDA("18000101")
					ENDDA("99991231")
					for(int i=0; i<snapShot.size(); i++) {
						E1P0008(SEGMENT: "1"){
							PERNR(pernr.padLeft(8, "0"))
							INFTY(infoType)
							SUBTY("0")
							if (i < snapShot.size()-1)
							{
								SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
								Date inputDate = formatter.parse(snapShot[i+1].asOfDate.text());
								Calendar cal = Calendar.getInstance();
								cal.setTime(inputDate);
								cal.add(Calendar.DATE, -1);
								inputDate = cal.getTime();
								ENDDA(transformDate(formatter.format(inputDate)))
							}
							else
							{
								ENDDA("99991231")
							}
							BEGDA(transformDate(snapShot[i].asOfDate.text()))
							TRFAR(snapShot[i].employment_information.job_information.payScaleType.text())
							TRFGB(snapShot[i].employment_information.job_information.payScaleArea.text())
							TRFGR(snapShot[i].employment_information.job_information.pay_grade.text())
							TRFST(snapShot[i].employment_information.job_information.payScaleLevel.text())
							BSGRD(snapShot[i].employment_information.job_information.fte.text())
							for(int j=0; j<snapShot[i].employment_information.compensation_information.paycompensation_recurring.size(); j++)
							{
								if (snapShot[i].employment_information.compensation_information.paycompensation_recurring[j].pay_component.text() == "1000")
								{
									LGA01 ("1000")
									BET01(snapShot[i].employment_information.compensation_information.paycompensation_recurring[j].paycompvalue.text())
								}
								if (snapShot[i].employment_information.compensation_information.paycompensation_recurring[j].pay_component.text() == "1064")
								{
									LGA02 ("1064")
									BET02(snapShot[i].employment_information.compensation_information.paycompensation_recurring[j].paycompvalue.text())
								}
							}
							ANCUR(snapShot[i].employment_information.compensation_information.salaryCurrencyCode.text())
						}
					}
				}
				//Closing bracket for E1PITYP segment
			}
			//Closing bracket of Output Node Generation
			return output;
		}
		else
			return '';

	}
/*
	// To Create the Info Type 0016 in the IDOC for the contract type and contract end date information
	public static def buildInfoType0016(String infoType,String pernr, def snapShot){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean jobinfoChanged = false;
		for(int i=0; i<snapShot.size(); i++) {
			def job_info = snapShot[i].employment_information.job_information
			if((job_info.action.text() == "INSERT") && !(job_info.contract_type.isEmpty()))
			{
				jobinfoChanged = true;
				break;
			}
			else if(!(job_info.contract_type_previous.isEmpty())
			|| !(job_info.contract_end_date_previous.isEmpty()))
			{
				jobinfoChanged = true;
				break;
			}
		}

		if(jobinfoChanged)
		{
			def output = outputBuilder.bindNode{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					BEGDA("18000101")
					ENDDA("99991231")
					def tempStartDate = ""
					def tempEndDate = ""
					for(int i=0; i<snapShot.size(); i++) {
						if((i == 0) || (snapShot[i].employment_information.job_information.start_date.text() != tempStartDate)) {
							E1P0016(SEGMENT: "1"){
								PERNR(pernr.padLeft(8, "0"))
								INFTY(infoType)
								ENDDA(transformDate(snapShot[i].employment_information.job_information.end_date.text()))
								BEGDA(transformDate(snapShot[i].employment_information.job_information.start_date.text()))
								CTTYP(snapShot[i].employment_information.job_information.contract_type.text())
								CTEDT(transformDate(snapShot[i].employment_information.job_information.contract_end_date.text()))
								tempStartDate = snapShot[i].employment_information.job_information.start_date.text()
								tempEndDate = snapShot[i].employment_information.job_information.end_date.text()
							}
						}
					}
				}
				//Closing bracket for E1PITYP segment
			}
			//Closing bracket of Output Node Generation
			return output;
		}
		else
			return '';

	}
 */
//To Create the Info Type 0021 for the dependent information
	        public static def buildInfoType0021(String infoType,String pernr,def dep_info){
             def outputBuilder = new StreamingMarkupBuilder();
             outputBuilder.encoding = "UTF-8"
             def output = ""
             boolean dependentFlag = false;
             for(int i=0; i<dep_info.size(); i++) { 
                    
                    dependentFlag = false;
                    
                    if(dep_info[i].action.text() != "NO CHANGE")
                    {
                          dependentFlag = true;
						  
                    }
                    if(dependentFlag != "true") {
                          
                          for(int j=0; j<dep_info[i].dependent_relation_information.size();j++) {
                            if(dep_info[i].dependent_relation_information[j].action.text() !="NO CHANGE")
                                 {
                                       dependentFlag = true;
                                       break;
                                 }
                          }
                    }
					if(dependentFlag != "true")  {
						
						for(int k=0; k<dep_info[i].dependent_personal_information.size();k++) {
						  if(dep_info[i].dependent_personal_information[k].action.text() !="NO CHANGE")
							   {
									 dependentFlag = true;
									 break;
							   }
						}
				  }
                    if(dependentFlag) {
                          def output1 = outputBuilder.bind{
							                                 
                                 E1PITYP(SEGMENT: "1"){
                                       PLVAR("01")
                                       OTYPE("P")
                                       OBJID (pernr.padLeft(8, "0"))
                                       INFTY(infoType)
                                 //SUBTY(dep_info[i].dependent_relation_information[0].relationship_type.text())
								 
								 
									    if(dep_info[i].dependent_relation_information[0].relationship_type.text() == "3" 
									   || dep_info[i].dependent_relation_information[0].relationship_type.text() == "5"
									   || dep_info[i].dependent_relation_information[0].relationship_type.text() == "6"
									   || dep_info[i].dependent_relation_information[0].relationship_type.text() == "8"
									   || dep_info[i].dependent_relation_information[0].relationship_type.text() == "14"
									   || dep_info[i].dependent_relation_information[0].relationship_type.text() == "15")
									   {
								       SUBTY("2")
									   }
									   else
									   SUBTY(dep_info[i].dependent_relation_information[0].relationship_type.text())
								   
                                       BEGDA("18000101")
                                       ENDDA("99991231")
									   
				   
							def startDate = []
							
							for (int j=0; j<dep_info[i].dependent_relation_information.size(); j++)
							{
								startDate.add(dep_info[i].dependent_relation_information[j].start_date.text())
							}
													
							for (int j=0; j<dep_info[i].dependent_personal_information.size(); j++)
							{
								startDate.add(dep_info[i].dependent_personal_information[j].start_date.text())
							}
							startDate = startDate.unique()
							startDate = startDate.sort()
				
							println startDate
						    for(int s=0;s<startDate.size();s++)
			
						  { int i_rel
							int i_per

							  for (int j=0; j<dep_info[i].dependent_relation_information.size(); j++)
							  {   def str=""
								 
								if(startDate[s] >= dep_info[i].dependent_relation_information[j].start_date.text() && startDate[s] <= dep_info[i].dependent_relation_information[j].end_date.text())
								{ println startDate[s]
									i_rel = j
									str =i_rel
								}
								if(str != "")
								break
							 }
							for (int k=0; k<dep_info[i].dependent_personal_information.size(); k++)
								{    def str1=""
									if(startDate[s] >= dep_info[i].dependent_personal_information[k].start_date.text() && startDate[s] <= dep_info[i].dependent_personal_information[k].end_date.text())
									{
										i_per = k
										str1=i_per							
									}
									if(str1 != "")
										break
								}
						
						
							E1P0021(SEGMENT: "1")
							 { 
								
								PERNR(pernr.padLeft(8, "0"))
								INFTY(infoType)
								
								//SUBTY(dep_info[i].dependent_relation_information[i_rel].relationship_type.text())
								
										
								if(dep_info[i].dependent_relation_information[i_rel].relationship_type.text() == "3" 
									   || dep_info[i].dependent_relation_information[i_rel].relationship_type.text() == "5"
									   || dep_info[i].dependent_relation_information[i_rel].relationship_type.text() == "6"
									   || dep_info[i].dependent_relation_information[i_rel].relationship_type.text() == "8"
									   || dep_info[i].dependent_relation_information[i_rel].relationship_type.text() == "14"
									   || dep_info[i].dependent_relation_information[i_rel].relationship_type.text() == "15")
									   {
								       SUBTY("2")
									   }
									   else
									   SUBTY(dep_info[i].dependent_relation_information[i_rel].relationship_type.text())
								
								
								
								if (!(dep_info[i].dependent_relation_information[i_rel].custom_string10.isEmpty()) && (dep_info[i].dependent_relation_information[i_rel].custom_string10.text().length() > 0))
								{
									OBJPS(dep_info[i].dependent_relation_information[i_rel].custom_string10.text())
								}
								else
								{
									OBJPS(dep_info[i].person_id.text())
								}
								/*if (s < startDate.size()-1 && dep_info[i].dependent_relation_information[i_rel].action.text() != "DELETE" && dep_info[i].dependent_personal_information[i_per].action.text() != "DELETE")
									{
										SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
										Date inputDate = formatter.parse(startDate[s+1]);
								        Calendar cal = Calendar.getInstance();
								        cal.setTime(inputDate);
								        cal.add(Calendar.DATE, -1);
								        inputDate = cal.getTime();
								        ENDDA(transformDate(formatter.format(inputDate)))
									}*/
									if(dep_info[i].dependent_relation_information[i_rel].action.text() == "DELETE" || dep_info[i].dependent_personal_information[i_per].action.text() == "DELETE")
									{
										ENDDA(transformDate(startDate[s]))
									}
									else
									{
										ENDDA(transformDate(dep_info[i].dependent_relation_information[i_rel].end_date.text()))
									}	
								BEGDA(transformDate(startDate[s]))
								FGBDT(transformDate(dep_info[i].date_of_birth.text()))
								FANAT(dep_info[i].dependent_relation_information[i_rel].custom_string15.text())
								FASEX(dep_info[i].dependent_personal_information[i_per].gender.text())
								FAVOR(dep_info[i].dependent_personal_information[i_per].first_name.text())
								FANAM(dep_info[i].dependent_personal_information[i_per].last_name.text())
								FNAC2(dep_info[i].dependent_personal_information[i_per].middle_name.text())
								Z1P0021(SEGMENT: "1")
								{
								ZZPASSCOUN1(dep_info[i].dependent_relation_information[i_rel].custom_string19.text())
								ZPSPRT(dep_info[i].dependent_relation_information[i_rel].custom_string9.text())
								ZPSISS(transformDate(dep_info[i].dependent_relation_information[i_rel].custom_date7.text()))
								ZPSEXP(transformDate(dep_info[i].dependent_relation_information[i_rel].custom_date8.text()))
								ZDONR8(dep_info[i].dependent_relation_information[i_rel].custom_string17.text())
								}
							 }
						  	 
						}   
                     }
                                      
                          } 
						  
                          output = output + output1
                    } 
                    
             }
             return output
       }
	//Create Info type for 0032 for the home employment if the previous employee id exists
	public static def buildInfoType0032(String infoType,String pernr,def employmentInfo){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean prevHomeEmployment = false;
		for(int i=0; i<employmentInfo.size(); i++) {
			println employmentInfo.size()
			if((employmentInfo.action.text() == "INSERT") && !(employmentInfo.prevEmployeeId.isEmpty()))
			{
				println "previous employment found"
				//Check if there is a Job_information segment inserted in the compound employee query response
				prevHomeEmployment = true;
				break;
			}
			else if(!(employmentInfo.prevEmployeeId_previous.isEmpty()))
			{
				prevHomeEmployment = true;
				break;
			}
		}
		if(prevHomeEmployment)
		{
			def output = outputBuilder.bind{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					BEGDA("18000101")
					ENDDA("99991231")
					E1P0032(SEGMENT: "1"){
						PERNR(pernr.padLeft(8, "0"))
						INFTY(infoType)
						BEGDA(transformDate(employmentInfo.start_date.text()))
						ENDDA("99991231")
						PNALT(employmentInfo.prevEmployeeId.text())
					}     //Closing tag for E1P0000

					//Closing bracket for E1PITYP
				}
			}
			return output;
		}
		else
			return '';
	}

	//Create Info type 0041 for Dates specific data for the employee
	public static def buildInfoType0041(String infoType,String pernr,def inputSource){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean empInfoChanged = true;
		/*if (inputSource.action.text() != "NO CHANGE")
		empInfoChanged = true;*/
		if(empInfoChanged)
		{
			def output = outputBuilder.bindNode{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					BEGDA("18000101")
					ENDDA("99991231")
					inputSource.each{ is->
						E1P0041(SEGMENT: "1"){
							PERNR(pernr.padLeft(8, "0"))
							INFTY(infoType)
							ENDDA("99991231")
							BEGDA(transformDate(is.start_date.text()))
							if ((is.start_date.text()) != "")
							{
								DAR01("01")
								DAT01(transformDate(is.start_date.text()))
							}
							if ((is.originalStartDate.text()) != "")
							{
								DAR02("Z1")
								DAT02(transformDate(is.originalStartDate.text()))
							}
							if ((is.custom_date7.text()) != "")
							{
								DAR03("Z3")
								DAT03(transformDate(is.custom_date7.text()))
							}
							if ((is.custom_date10.text()) != "")
								{
									DAR04("Z4")
									DAT04(transformDate(is.custom_date10.text()))
								}
							if ((is.start_date.text()) != "")
								{
									DAR05("Z5")
									DAT05(transformDate(is.start_date.text()))
								}
							if ((is.end_date.text()) != "")
							{
								DAR06("Z6")
								DAT06(transformDate(is.end_date.text()))
							}
							if ((is.custom_date23.text()) != "" && (is.custom_date9.text()) != "")
							{
								DAR07("Z8")
								DAT07(transformDate(is.custom_date23.text()))
							}
							if ((is.custom_date9.text()) != "")
							{
								DAR08("Z9")
								DAT08(transformDate(is.custom_date9.text()))
							}
						}
					}
	
				}
			}
			return output;
		}
		else
			return '';
	}
	
	//Create Info Type 0050 for the roaster system specific data
	public static def buildInfoType0050(String infoType,String pernr, def snapShot){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean roasterInfoChanged = false;
		for(int i=0; i<snapShot.size(); i++) {
			def job_info = snapShot[i].employment_information.job_information
			if((job_info.action.text() == "INSERT")&& !(job_info.custom_string15.isEmpty()))
			{
				//Check if there is a Job_information segment inserted in the compound employee query response
				roasterInfoChanged = true;
				break;
			}
			else if(!(job_info.custom_string15_previous.isEmpty()))
			{
				roasterInfoChanged = true;
				break;
			}
		}
		if(roasterInfoChanged)
		{
			def output = outputBuilder.bind{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					BEGDA("18000101")
					ENDDA("99991231")
					for(int i=0; i<snapShot.size(); i++) {
						E1P0050(SEGMENT: "1"){
							PERNR(pernr.padLeft(8, "0"))
							INFTY(infoType)
							if (i < snapShot.size()-1)
							{
								SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
								Date inputDate = formatter.parse(snapShot[i+1].asOfDate.text());
								Calendar cal = Calendar.getInstance();
								cal.setTime(inputDate);
								cal.add(Calendar.DATE, -1);
								inputDate = cal.getTime();
								ENDDA(transformDate(formatter.format(inputDate)))
							}
							else
							{
								ENDDA("99991231")
							}
							BEGDA(transformDate(snapShot[i].asOfDate.text()))
							ZAUSW(pernr.padLeft(8, "0"))
							BDEGR(snapShot[i].employment_information.job_information.custom_string15.text().padLeft(3, "0"))
						}

					}
				}
				//Closing bracket for E1PITYP segment
			}
			//Closing bracket of Output Node Generation
			return output;
		}
		else
			return '';

	}

//Create Info type 0105 with sub infotype 0001 for personal logon information
	public static def buildInfoType0105_emp(String infoType,String pernr,def person, def emp_info){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean empInfoChanged = true;
		/*if ((emp_info.action.text() != "NO CHANGE") || (!(person.logon_user_name_previous.isEmpty())))
		empInfoChanged = true;*/
		if(empInfoChanged)
		{
			def output = outputBuilder.bind{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					SUBTY("0001")
					BEGDA("18000101")
					ENDDA("99991231")
					E1P0105(SEGMENT: "1"){
						PERNR(pernr.padLeft(8, "0"))
						INFTY(infoType)
						SUBTY("0001")
						ENDDA("99991231")
						BEGDA(transformDate(emp_info.start_date.text()))
						USRTY("0001")
						USRID(pernr)
						UNAME(person.logon_user_name.text())
					}
	
				}
			}
			return output;
		}
		else
			return '';	
	}


	//Create Info type 0001 with sub infotype 0105 for phone information
	public static def buildInfoType0105_ph(String infoType,String pernr,String startDate,def ph_info){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean flag = false;
		def output = outputBuilder.bindNode{
		for(int i=0; i<ph_info.size(); i++) 
			{
			if(ph_info[i].action.text() != "NO CHANGE")
				{				
					E1PITYP(SEGMENT: "1")
					{
						PLVAR("01")
						OTYPE("P")
						OBJID (pernr.padLeft(8, "0"))
						INFTY(infoType)
						SUBTY(ph_info[i].phone_type.text())
					if(ph_info[i].action.text() != "DELETE")
					{		E1P0105(SEGMENT: "1")
						{
								PERNR(pernr.padLeft(8, "0"))
								INFTY(infoType)
								SUBTY(ph_info[i].phone_type.text())
								ENDDA("99991231")
								BEGDA(transformDate(startDate))
								USRTY(ph_info[i].phone_type.text())
								USRID(ph_info[i].phone_number.text())
						}
					}	
					}	
				}
			}
			return output;
		}			

	}

	//Create Info type 0105 with sub infotype 0105 for email information
	public static def buildInfoType0105_email(String infoType,String pernr,String startDate,def email_info){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean flag = false;
		def output = outputBuilder.bindNode
		{
		for(int i=0; i<email_info.size(); i++) 
		{
			if(email_info[i].action.text() != "NO CHANGE")
			{
						E1PITYP(SEGMENT: "1")
					{
							PLVAR("01")
							OTYPE("P")
							OBJID (pernr.padLeft(8, "0"))
							INFTY(infoType)
							SUBTY("E" + email_info[i].email_type.text())
					if(email_info[i].action.text() != "DELETE")
					{		E1P0105(SEGMENT: "1")
						{
								PERNR(pernr.padLeft(8, "0"))
								INFTY(infoType)
								SUBTY("E" + email_info[i].email_type.text())
								ENDDA("99991231")
								BEGDA(transformDate(startDate))
								USRTY("E" + email_info[i].email_type.text())
								USRID_LONG(email_info[i].email_address.text())
						}
					}
						
					}	
			}
		}
			
			return output;
	}
}

	//Create Infotype 0185 for the national Id of id type passport, secondary passport and emirates id
	public static def buildInfoType0185_NationalID(String infoType,String pernr,def nationalID){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		def output = outputBuilder.bind{
			for(int i=0; i<nationalID.size(); i++) {
			def nationalID_info = nationalID[i]
			if((nationalID_info.action.text() == "CHANGE" || nationalID_info.action.text() == "INSERT")
			&& ((nationalID_info.card_type.text() == "EmiratesID") 
				|| ((nationalID_info.card_type.text() == "PrimP") && (nationalID_info.isPrimary.text() == "true")) 
				|| (nationalID_info.card_type.text() == "PN") && (nationalID_info.isPrimary.text() == "true")))
					  {					
							E1PITYP(SEGMENT: "1"){
							PLVAR("01")
							OTYPE("P")
							OBJID (pernr.padLeft(8, "0"))
							INFTY(infoType)
							SUBTY(nationalID_info.card_type.text())
							BEGDA("18000101")
							ENDDA("99991231")
							E1P0185(SEGMENT: "1")
							{
								PERNR(pernr.padLeft(8, "0"))
								INFTY(infoType)
							    SUBTY(nationalID_info.card_type.text())
								ENDDA("99991231")
								BEGDA(transformDate(nationalID[i].custom_date1.text()))
								ICTYP(nationalID_info.card_type.text())
								ICNUM(nationalID[i].national_id.text())
								FPDAT(transformDate(nationalID[i].custom_date1.text()))
								EXPID(transformDate(nationalID[i].custom_date2.text()))
								ISSPL(nationalID[i].custom_string1.text())
								ISCOT(nationalID[i].country.text())
								IDCOT(nationalID[i].country.text())
							}     //Closing tag for E1P0185
						}

					//Closing bracket for E1PITYP
				}
			} //end of for loop
			return output;
		}	
	}


    //Create Infotype 0185 for the employment id for the id type VISA
	public static def buildInfoType0185_EmpDocumentID(String infoType,String pernr,def emp_info){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean documentChanged = false;
		for(int i=0; i<emp_info.personal_documents_information.size();i++) {
			if((emp_info.personal_documents_information[i].action.text() == "INSERT" || emp_info.personal_documents_information[i].action.text() == "CHANGE") 
				&& (emp_info.personal_documents_information[i].document_type.text() == "ARE3")) {
					documentChanged = true
			}
		}
		
		if(documentChanged)
		{
			def output = outputBuilder.bind{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					SUBTY("03")
					BEGDA("18000101")
					ENDDA("99991231")
					for(int i=0; i<emp_info.personal_documents_information.size(); i++)
					{
						if(emp_info.personal_documents_information[i].document_type.text() == "ARE3")
						{
							E1P0185(SEGMENT: "1")
							{
								PERNR(pernr.padLeft(8, "0"))
								INFTY(infoType)
								SUBTY("03")
								ENDDA("99991231")
								BEGDA(transformDate(emp_info.personal_documents_information[i].issue_date.text()))
								ICTYP("03")
								ICNUM(emp_info.personal_documents_information[i].custom_string5.text())
								FPDAT(transformDate(emp_info.personal_documents_information[i].issue_date.text()))
								EXPID(transformDate(emp_info.personal_documents_information[i].expiration_date.text()))
								ISSPL(emp_info.personal_documents_information[i].issue_place.text())
								ISCOT(emp_info.personal_documents_information[i].country.text())
								IDCOT(emp_info.personal_documents_information[i].country.text())
							}     //Closing tag for E1P0185
						}

					}	 // Closing for loop

					//Closing bracket for E1PITYP
				}
			}
			return output;
		}
		else
			return '';
	}
	
	//Create Infotype 0185 for the employment documents for the Staff ID
	public static def buildInfoType0185_StaffID(String infoType,String pernr,def emp_info){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		boolean empInfoChanged = true;
		/*if (emp_info.action.text() != "NO CHANGE")
		empInfoChanged = true;*/
		if (empInfoChanged)
		{
			def output = outputBuilder.bind{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					SUBTY("05")
					BEGDA("18000101")
					ENDDA("99991231")
					E1P0185(SEGMENT: "1")
							{
								PERNR(pernr.padLeft(8, "0"))
								INFTY(infoType)
								SUBTY("05")
								ENDDA("99991231")
								BEGDA(transformDate(emp_info.start_date.text()))
								ICTYP("05")
								ICNUM(pernr)
								FPDAT(transformDate(emp_info.start_date.text()))
								EXPID(transformDate(emp_info.custom_date21.text()))
							}     //Closing tag for E1P0185

					//Closing bracket for E1PITYP
				}
			}
			return output;
		}
		else 
			return '';
	}
	
	
	//Create Infotype 9007 for the work order information
	public static def buildInfoType9007_WorkOrder(String infoType,String pernr,def workorder_info){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"		
		boolean workOrderinfoChanged = false;
		for(int i=0; i<workorder_info.size(); i++) 
		{
		def workord_info = workorder_info[i]
			if(workord_info.action.text() == "INSERT")
			{
				//Check if there is a new Work Order information found in the query response
				workOrderinfoChanged = true;
				break;
			}
			//check if the start date or end date or vendor has changed in the work order since the last run date
			else if(!(workorder_info.startDate_previous.isEmpty())
			|| !(workorder_info.endDate_previous.isEmpty())
			|| !(workorder_info.vendor_previous.isEmpty()))
			{
				workOrderinfoChanged = true;
				break;
			}
		}
		if (workOrderinfoChanged)
		{
		def output = outputBuilder.bind{
				E1PITYP(SEGMENT: "1"){
					PLVAR("01")
					OTYPE("P")
					OBJID (pernr.padLeft(8, "0"))
					INFTY(infoType)
					BEGDA("18000101")
					ENDDA("99991231")
					for(int i=0; i<workorder_info.size(); i++)
						{
								Z1P9007(SEGMENT: "1")
								{
								PERNR(pernr.padLeft(8, "0"))
								INFTY(infoType)
								ENDDA(transformDate(workorder_info[i].endDate.text()))
								BEGDA(transformDate(workorder_info[i].startDate.text()))
								NAOFCOM(workorder_info[i].vendor.text())
								}     //Closing tag for E1P0185
	
						}	 // Closing for loop

				}//Closing bracket for E1PITYP
			}
		return output;
		}
		else
		return '';
	}	
	
	//Localization of the address information for multiple countries
	public static def addressLocalization(String pernr,def addressInfo){
		def outputBuilder = new StreamingMarkupBuilder()
		outputBuilder.encoding = "UTF-8"
		def output = "";
			if (addressInfo.country.text() == "ARE")
				output = outputBuilder.bind{
			E1P0006(SEGMENT: "1"){
				PERNR(pernr.padLeft(8, "0"))
				INFTY("0006")
				SUBTY(addressInfo.address_type.text())
				ENDDA("99991231")
				BEGDA(transformDate(addressInfo.start_date.text()))
				ANSSA(addressInfo.address_type.text())
				STRAS(addressInfo.address2.text())
				ORT01(addressInfo.city.text())
				ORT02(addressInfo.county.text())
				PSTLZ(addressInfo.zip_code.text())
				LAND1(addressInfo.country.text())
				LOCAT(addressInfo.address4.text())
				HSNMR(addressInfo.address3.text())
			}
					}
			if (addressInfo.country.text() == "IND")
				output = outputBuilder.bind{
			E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address4.text())
					HSNMR(addressInfo.address2.text())
				}
				
			}
			if (addressInfo.country.text() == "AUS")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())
					HSNMR(addressInfo.address2.text())
				}
					
			}
			if (addressInfo.country.text() == "BHR")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address3.text())
					ORT01(addressInfo.address4.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address5.text())
					HSNMR(addressInfo.address2.text())
				}
						
			}
			if (addressInfo.country.text() == "BGD")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address5.text())
				}						
			}
			if (addressInfo.country.text() == "BEL")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())
					HSNMR(addressInfo.address2.text())
				}								
			}
			if (addressInfo.country.text() == "BLR")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.address7.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address6.text())
					HSNMR(addressInfo.address3.text())
				}								
			}
			
			if (addressInfo.country.text() == "CAN")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address6.text())
				}									
			}
			if (addressInfo.country.text() == "CHN")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address6.text())
				}
									
			}
			if (addressInfo.country.text() == "EGY")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address3.text())
					ORT01(addressInfo.address7.text())
					ORT02(addressInfo.address4.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address5.text())
					HSNMR(addressInfo.address2.text())
				}
			}
			if (addressInfo.country.text() == "FRA")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address5.text())
					HSNMR(addressInfo.address1.text())
				}
			}
			// Address localization for Germany
			if (addressInfo.country.text() == "DEU")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.address3.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					HSNMR(addressInfo.address2.text())
				}									
			}
			// Address localization for Greece
			if (addressInfo.country.text() == "GRC")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address4.text())
					HSNMR(addressInfo.address3.text())				
				}									
			}
			// Address localization for Hong Kong
			if (addressInfo.country.text() == "HKG")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.address3.text())
					ORT02(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address1.text())					
				}									
			}
			// Address localization for Indonesia
		if (addressInfo.country.text() == "IDN")
			output = outputBuilder.bind{
			E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())	
				}									
			}			
			// Address localization for Iraq
		if (addressInfo.country.text() == "IRQ")
			output = outputBuilder.bind{
			E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address3.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.province.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address4.text())
					HSNMR(addressInfo.address2.text())				
				}									
			}
			// Address localization for Ireland
		if (addressInfo.country.text() == "IRL")
			output = outputBuilder.bind{
			E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.address3.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address2.text())
				}
			}
			// Address localization for Italy
		if (addressInfo.country.text() == "ITA")
			output = outputBuilder.bind{
			E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address2.text())
				}								
			}
			// Address localization for Japan
		if (addressInfo.country.text() == "JPN")
			output = outputBuilder.bind{
			E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())
				}
			}
			// Address localization for Jordan
		if (addressInfo.country.text() == "JOR")
			output = outputBuilder.bind{
			E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())
				}									
			}
			// Address localization for Kazakhstan
			if (addressInfo.country.text() == "KAZ")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.province.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())					
				}									
			}
					
			// Address localization for Kenya
			if (addressInfo.country.text() == "KEN")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address3.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address4.text())
					HSNMR(addressInfo.address2.text())			
				}									
			}
			
			// Address localization for Kuwait
			if (addressInfo.country.text() == "KWT")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address4.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address5.text())
					HSNMR(addressInfo.address3.text())			
				}									
			}
			
				// Address localization for Lebanon
			if (addressInfo.country.text() == "LBN")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address4.text())
					ORT01(addressInfo.address3.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address2.text())
					HSNMR(addressInfo.address5.text())				
				}									
			}
			
				// Address localization for Malasiya
			if (addressInfo.country.text() == "MYS")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address4.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.address3.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address2.text())			
				}									
			}
			
					// Address localization for Morocco
			if (addressInfo.country.text() == "MAR")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address4.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.address5.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address2.text())			
				}									
			}
			
			// Address localization for Netherlands
			if (addressInfo.country.text() == "NLD")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					STRAS(addressInfo.address3.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address5.text())
					HSNMR(addressInfo.address4.text())				
				}									
			}
			
				// Address localization for Nigeria
			if (addressInfo.country.text() == "NGA")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.address3.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address4.text())				
				}									
			}
			
			// Address localization for Oman
			if (addressInfo.country.text() == "OMN")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())
					
				}									
			}
			
			// Address localization for Pakistan
			if (addressInfo.country.text() == "PAK")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address3.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.province.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					HSNMR(addressInfo.address2.text())					
				}									
			}
			
				// Address localization for Philippines
			if (addressInfo.country.text() == "PHL")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address4.text())
					HSNMR(addressInfo.address3.text())				
				}								
			}
			
			// Address localization for Russian Federation
			if (addressInfo.country.text() == "RUS")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address3.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.address7.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address5.text())
					HSNMR(addressInfo.address2.text())			
				}									
			}
			
			// Address localization for Saudi Arabia
			if (addressInfo.country.text() == "SAU")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.address6.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address5.text())
					HSNMR(addressInfo.address4.text())				
				}									
			}
			
			// Address localization for Serbia
			if (addressInfo.country.text() == "SRB")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())
					HSNMR(addressInfo.address4.text())					
				}									
			}
			
			// Address localization for Singapore
			if (addressInfo.country.text() == "SGP")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address2.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())		
				}									
			}
			
			// Address localization for South Africa
			if (addressInfo.country.text() == "ZAF")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address5.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address2.text())
					HSNMR(addressInfo.address4.text())				
				}								
			}
			
			// Address localization for Korea, Republic of
			if (addressInfo.country.text() == "KOR")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT02(addressInfo.address4.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())					
				}									
			}
			
			
			// Address localization for Spain
			if (addressInfo.country.text() == "ESP")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address4.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.address6.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())
					HSNMR(addressInfo.address2.text())					
				}									
			}
			
			// Address localization for Sri Lanka
			if (addressInfo.country.text() == "LKA")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address3.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					HSNMR(addressInfo.address2.text())					
				}									
			}
			
				// Address localization for Switzerland
			if (addressInfo.country.text() == "CHE")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address20.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
				}									
			}
			
			// Address localization for Tanzania, United Republic of
			if (addressInfo.country.text() == "TZA")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address3.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address2.text())
					HSNMR(addressInfo.address5.text())				
				}									
			}
			
			
			// Address localization for Thailand
			if (addressInfo.country.text() == "THA")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address6.text())
					STRAS(addressInfo.address7.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())
					HSNMR(addressInfo.address5.text())				
				}									
			}
			
			// Address localization for Turkey
			if (addressInfo.country.text() == "TUR")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address3.text())
					ORT01(addressInfo.address5.text())
					ORT02(addressInfo.province.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address2.text())
					HSNMR(addressInfo.address4.text())				
				}									
			}
			
			
				// Address localization for United Kingdom
			if (addressInfo.country.text() == "GBR")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address2.text())					
				}									
			}
			
				// Address localization for United States
			if (addressInfo.country.text() == "USA")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					STRAS(addressInfo.address1.text())
					ORT01(addressInfo.city.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address2.text())				
				}									
			}
			
			// Address localization for Vietnam
			if (addressInfo.country.text() == "VNM")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.province.text())
					ORT02(addressInfo.county.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.address3.text())				
				}									
			}
			
			// Address localization for Libya
			if (addressInfo.country.text() == "LBY")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.custom_string1.text())
					STRAS(addressInfo.custom_string2.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.custom_string3.text())				
				}									
			}
			
			// Address localization for Maldives
			if (addressInfo.country.text() == "MDV")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.custom_string1.text())
					STRAS(addressInfo.custom_string2.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.custom_string3.text())			
				}									
			}
								
			// Address localization for Nepal
			if (addressInfo.country.text() == "NPL")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.custom_string1.text())
					STRAS(addressInfo.custom_string2.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.custom_string3.text())			
				}									
			}
			
				// Address localization for Sudan
			if (addressInfo.country.text() == "SDN")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.custom_string1.text())
					STRAS(addressInfo.custom_string2.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.custom_string3.text())				
				}									
			}
			
			// Address localization for Syrian Arab Republic
			if (addressInfo.country.text() == "SYR")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.custom_string1.text())
					STRAS(addressInfo.custom_string2.text())
					ORT01(addressInfo.city.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())
					LOCAT(addressInfo.custom_string3.text())
					
				}									
			}
			
				// Address localization for Azerbaijan
			if (addressInfo.country.text() == "AZE")
				output = outputBuilder.bind{
				E1P0006(SEGMENT: "1"){
					PERNR(pernr.padLeft(8, "0"))
					INFTY("0006")
					SUBTY(addressInfo.address_type.text())
					ENDDA("99991231")
					BEGDA(transformDate(addressInfo.start_date.text()))
					ANSSA(addressInfo.address_type.text())
					NAME2(addressInfo.address1.text())
					STRAS(addressInfo.address2.text())
					ORT01(addressInfo.address3.text())
					PSTLZ(addressInfo.zip_code.text())
					LAND1(addressInfo.country.text())					
				}									
			}
		return output;
	}