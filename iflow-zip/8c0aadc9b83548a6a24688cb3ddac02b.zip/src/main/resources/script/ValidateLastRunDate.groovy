/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
       //Properties 
       def Properties = message.getProperties();
       
    def messageLog = messageLogFactory.getMessageLog(message);

     def EnableLogging = Properties.get("EnableLogging");
       def FirstRunDate = Properties.get("FirstRunDate");
       def LastSuccessRunDate = Properties.get("P_LastSuccessfulRunDate");
       def TransmissionMode = Properties.get("P_TransmissionMode");
       
       if (LastSuccessRunDate =='' || LastSuccessRunDate == null)
       {
            
            if(EnableLogging =='true') {
       messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment");
       messageLog.addAttachmentAsString("QueryFilter:", FirstRunDate, "text/plain");
    	}
        message.setProperty("P_LastSuccessfulRunDate", FirstRunDate);
       }
        
      else  
        if(EnableLogging =='true') {
       messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment");
       messageLog.addAttachmentAsString("QueryFilter:", LastSuccessRunDate, "text/plain");
    	}
  
       
       return message;

    
    
}