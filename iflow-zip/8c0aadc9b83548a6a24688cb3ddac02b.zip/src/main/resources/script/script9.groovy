import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import static java.util.Calendar.*
import java.lang.String;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.text.DateFormat;
import java.text.DecimalFormat
import groovy.xml.MarkupBuilder
import com.sap.it.spi.ITApiHandler;
import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.*;
import groovy.xml.StreamingMarkupBuilder 
import java.text.SimpleDateFormat;

def Message processData(Message message) {
       //Body 
       def body = message.getBody(java.io.Reader);
       def root = new XmlSlurper().parse(body);
       def messageLog = messageLogFactory.getMessageLog(message);
       def empId = ""
       def str = ""
       def personid =""
       int count = 0
           root.CompoundEmployee.each{CE->
                          empId = CE.person.person_id_external.text()
                           personid =CE.log.log_item[0].person_id_external.text()
                          if( CE.person.employment_information.job_information == '')
                          { 
                                 count++
                               
                                if(empId == "")
                                 {
                                    str = personid + "," + str 
                                 }
                                 else
                                 str = empId + "," + str
                                 
                                 CE.replaceNode{}
                          }
                          
             }
             def newRoot = new StreamingMarkupBuilder().bind {
                    mkp.yield root
             }.toString()
             String countStr = count+"";
             if (count > 0)
             {
             def skippedEmployees = "Employees got Skipped because of invalid data or missing job information: " + countStr + "\n Employee IDs which were removed:" + str
             messageLog.addAttachmentAsString("Employees skipped:", skippedEmployees, "text/plain");
             }
             message.setBody(newRoot.toString())
             return message
             
       }
       
	 