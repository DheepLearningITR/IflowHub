import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

//Returns true if object is an array
boolean isCollectionOrArray(object) {
    [Collection, Object[]].any {
        it.isAssignableFrom(object.getClass())
    }
}

def Message processData(Message message) {
    def body = message.getBody(String.class);
    body = body.replaceAll('"@SEGMENT":"1",', ''); // To counter the JSON to XML conversion errors ()
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    def idoc_header = null;
    def idoc_header_ref_table = null;
    def referenceTexts_header = null;
    def party_header = null;

    // Assignment based on existence of the object being referenced so as to avoid runtime errors
    if (object.IDOC.E1KSJCL) {
        idoc_header = object.IDOC.E1KSJCL;
    }

    if (idoc_header) {

        idoc_header_ref_table = idoc_header.E1EDKR1;
        //idoc_item = idoc_header.E1PSJCL;
        idoc_header.reference_texts = [];
        idoc_header.party = [];
        referenceTexts_header = idoc_header.reference_texts;
        party_header = idoc_header.party;
        
        // Checking and inserting parties in the IDoc header
        if (idoc_header.PARTN) {
            def current_party = [PartyType: 'SP', SupplierPartyID: idoc_header.PARTN];
            party_header.add(current_party);
        }
        if (idoc_header.LIFNR) {
            def current_party = [PartyType: 'VN', BuyerPartyID: idoc_header.LIFNR];
            party_header.add(current_party);
        }
        if (idoc_header.KNREF) {
            def current_party = [PartyType: 'SH', BuyerPartyID: idoc_header.KNREF];
            party_header.add(current_party);
        }

        // Checking and inserting reference types and texts in the IDoc header

        if (idoc_header.RTY01) {
            def current_reference_text = [type: idoc_header.RTY01, text: idoc_header.RFN01];
            referenceTexts_header.add(current_reference_text);
        }
        if (idoc_header.RTY02) {
            def current_reference_text = [type: idoc_header.RTY02, text: idoc_header.RFN02];
            referenceTexts_header.add(current_reference_text);
        }

        if (idoc_header.RTY03) {
            def current_reference_text = [type: idoc_header.RTY03, text: idoc_header.RFN03];
            referenceTexts_header.add(current_reference_text);
        }

        if (idoc_header_ref_table) {
            // Checking and inserting reference types and texts in the IDoc header reference text table

            if (idoc_header_ref_table.RTY01) {
                def current_reference_text = [type: idoc_header_ref_table.RTY01, text: idoc_header_ref_table.RFN01];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY02) {
                def current_reference_text = [type: idoc_header_ref_table.RTY02, text: idoc_header_ref_table.RFN02];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY03) {
                def current_reference_text = [type: idoc_header_ref_table.RTY03, text: idoc_header_ref_table.RFN03];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY04) {
                def current_reference_text = [type: idoc_header_ref_table.RTY04, text: idoc_header_ref_table.RFN04];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY04) {
                def current_reference_text = [type: idoc_header_ref_table.RTY04, text: idoc_header_ref_table.RFN04];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY05) {
                def current_reference_text = [type: idoc_header_ref_table.RTY05, text: idoc_header_ref_table.RFN05];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY06) {
                def current_reference_text = [type: idoc_header_ref_table.RTY06, text: idoc_header_ref_table.RFN06];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY07) {
                def current_reference_text = [type: idoc_header_ref_table.RTY07, text: idoc_header_ref_table.RFN07];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY08) {
                def current_reference_text = [type: idoc_header_ref_table.RTY08, text: idoc_header_ref_table.RFN08];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY09) {
                def current_reference_text = [type: idoc_header_ref_table.RTY09, text: idoc_header_ref_table.RFN09];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY10) {
                def current_reference_text = [type: idoc_header_ref_table.RTY10, text: idoc_header_ref_table.RFN10];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY11) {
                def current_reference_text = [type: idoc_header_ref_table.RTY11, text: idoc_header_ref_table.RFN11];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY12) {
                def current_reference_text = [type: idoc_header_ref_table.RTY12, text: idoc_header_ref_table.RFN12];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY13) {
                def current_reference_text = [type: idoc_header_ref_table.RTY13, text: idoc_header_ref_table.RFN13];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY14) {
                def current_reference_text = [type: idoc_header_ref_table.RTY14, text: idoc_header_ref_table.RFN14];
                referenceTexts_header.add(current_reference_text);
            }

            if (idoc_header_ref_table.RTY15) {
                def current_reference_text = [type: idoc_header_ref_table.RTY15, text: idoc_header_ref_table.RFN15];
                referenceTexts_header.add(current_reference_text);
            }
        }

        //Checking if there is only one Record
        if (!isCollectionOrArray(idoc_header.E1PSJCL)) {
            //Converting Record to an array
            idoc_header.E1PSJCL = [idoc_header.E1PSJCL].toArray();
        }

        for (idoc_item in idoc_header.E1PSJCL) {

            def idoc_item_ref_table = idoc_item.E1EDPR1;
            idoc_item.reference_texts = [];
            def referenceTexts_item = idoc_item.reference_texts;

            if (idoc_item.RTY01) {
                def current_reference_text = [type: idoc_item.RTY01, text: idoc_item.RFN01];
                referenceTexts_item.add(current_reference_text);
            }

            if (idoc_item.RTY02) {
                def current_reference_text = [type: idoc_item.RTY02, text: idoc_item.RFN02];
                referenceTexts_item.add(current_reference_text);
            }

            if (idoc_item.RTY03) {
                def current_reference_text = [type: idoc_item.RTY03, text: idoc_item.RFN03];
                referenceTexts_item.add(current_reference_text);
            }
            if (idoc_item_ref_table) {
                // Checking and inserting reference types and texts in the IDoc item reference text table

                if (idoc_item_ref_table.RTY01) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY01, text: idoc_item_ref_table.RFN01];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY02) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY02, text: idoc_item_ref_table.RFN02];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY03) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY03, text: idoc_item_ref_table.RFN03];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY04) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY04, text: idoc_item_ref_table.RFN04];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY04) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY04, text: idoc_item_ref_table.RFN04];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY05) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY05, text: idoc_item_ref_table.RFN05];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY06) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY06, text: idoc_item_ref_table.RFN06];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY07) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY07, text: idoc_item_ref_table.RFN07];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY08) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY08, text: idoc_item_ref_table.RFN08];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY09) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY09, text: idoc_item_ref_table.RFN09];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY10) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY10, text: idoc_item_ref_table.RFN10];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY11) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY11, text: idoc_item_ref_table.RFN11];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY12) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY12, text: idoc_item_ref_table.RFN12];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY13) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY13, text: idoc_item_ref_table.RFN13];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY14) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY14, text: idoc_item_ref_table.RFN14];
                    referenceTexts_item.add(current_reference_text);
                }

                if (idoc_item_ref_table.RTY15) {
                    def current_reference_text = [type: idoc_item_ref_table.RTY15, text: idoc_item_ref_table.RFN15];
                    referenceTexts_item.add(current_reference_text);
                }
            }
        }
    }

    def output = JsonOutput.toJson(object);
    output = '{"SEQJIT03":' + output + '}';
    message.setBody(output);
    return message;
}