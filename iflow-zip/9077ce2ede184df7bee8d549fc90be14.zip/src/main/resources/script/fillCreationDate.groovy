import com.sap.it.api.mapping.*;

def String customFunc(String arg1){
	return '2018-08-24T12:00:00.1234567Z'; 
}