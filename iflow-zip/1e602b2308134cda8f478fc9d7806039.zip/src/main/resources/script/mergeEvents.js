importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function mergeEvents(message) {
	
	var map = message.getProperties();
    var mergedBody = map.get("mergedBody");
    if(!mergedBody){
    	mergedBody = {events:[]};
    }
    
	var body = null;
	try{
		body = JSON.parse(message.getBody().toString());
	}
	catch(e){
		message.setProperty("mergedBody", mergedBody);
		if(mergedBody.events.length){
			message.setBody(JSON.stringify(mergedBody));
		}
		return message;
	}
    
	for(var i in body.events){
		var businessPartnerExists = false;
		var eventContent = JSON.parse(body.events[i].payload);
		var yaasBPNumber = eventContent.customerNumber;
		var mergedBodyIndex = 0;
		for(var z in mergedBody.events){
			if(mergedBody.events[z].yaasBPNumber == yaasBPNumber){
				businessPartnerExists = true;
				mergedBodyIndex = z;
				
			}
		}
		if(!businessPartnerExists){
			body.events[i].yaasBPNumber = yaasBPNumber;
			mergedBody.events.push(body.events[i]);
		}
		else if(businessPartnerExists && body.events[i].createdAt > mergedBody.events[mergedBodyIndex].createdAt){
			body.events[i].yaasBPNumber = yaasBPNumber;
			mergedBody.events[mergedBodyIndex] = body.events[i];
		}
	}
	
	message.setProperty("mergedBody", mergedBody);
	if(mergedBody.events.length){
		message.setBody(JSON.stringify(mergedBody));
	}
	return message;
}