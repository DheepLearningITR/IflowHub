/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.it.api.ITApiFactory;
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.keystore.KeystoreService;
def Message processData(Message message) {
    def map = message.getProperties();
    def value = map.get("ag_prefix");
    def encryptionalias;
    def signaturealias;
    if (value == null || value.isEmpty()) {
        throw new java.lang.IllegalArgumentException("no alias defined for message");
    } else {
        encryptionalias = value + "_enc";
        signaturealias = value + "_sig";
    }
    message.setHeader("encryptionkey", encryptionalias);
    message.setHeader("signaturekey", signaturealias);
    message.setHeader("SAP_Sender", "SAP");
    message.setHeader("SAP_Receiver", "ERIC");
    message.setHeader("SAP_MessageType", "POST");
    message.setHeader("SAP_ApplicationID", "script");
    // check if the aliases exist
    def service = ITApiFactory.getApi(KeystoreService.class, null);
    if( service != null) {
        if (service.getKey(encryptionalias) == null) {
            throw new java.lang.IllegalArgumentException("no key for alias \"" + encryptionalias + "\"");
        }
        if (service.getKey(signaturealias) == null) {
            throw new java.lang.IllegalArgumentException("no key for alias \"" + signaturealias + "\"");
        }
    } else {
        throw new java.lang.IllegalStateException("KeystoreService not found");
    }
    return message;
}
