/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

import java.util.Base64;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import javax.mail.util.SharedByteArrayInputStream;
import javax.ws.rs.core.MediaType;

def Message processData(Message message) {

String finalXml = "<MultipartMixed>";
    def body=message.getBody(); 
    byte[] data1 = body.getBytes();;
    try {
		MimeMultipart mp = new MimeMultipart(new ByteArrayDataSource(data1, MediaType.MULTIPART_FORM_DATA));
		int count = mp.getCount();
		for (int i = 0; i < count; i++) {		
			BodyPart bodyPart = mp.getBodyPart(i);
			
			if(bodyPart.isMimeType("text/xml")){
				String contentType = bodyPart.getContentType();
                String temp = (String) bodyPart.getContent();
                temp = temp.replaceAll("<\\?xml.*?\\?>", "");
                temp = temp.replaceAll("<!DOCTYPE((.|\n|\r)*?)\">", "");
                finalXml =finalXml+ "<data contentType=" +"\"" + contentType  +"\"" + " currentCount=" + "\"" + i + "\""  + " maxCount=" + "\"" + count + "\"" +  ">" + temp + "</data>";				
			}
			else if(bodyPart.isMimeType("multipart/related")) {
			    finalXml = finalXml + "<MimeMultipartMsg>";
				MimeMultipart mp1 = (MimeMultipart) bodyPart.getContent();
				int count1 = mp1.getCount();
				for (int j = 0; j < count1; j++) {
					BodyPart bodyPart1 = mp1.getBodyPart(j);
					String tempTxtXML = "";
					String contentType = "";
					if(bodyPart1.isMimeType("text/xml")){
						tempTxtXML = (String) bodyPart1.getContent();
						contentType = bodyPart1.getContentType();
						tempTxtXML = tempTxtXML.replaceAll("<\\?xml.*?\\?>", "");
						tempTxtXML = tempTxtXML.replaceAll("<!DOCTYPE((.|\n|\r)*?)\">", "");
						finalXml =finalXml+  "<data contentType=" + "\"" + contentType + "\"" + " currentCount=" + "\"" + (j+1) + "\"" +  ">" + tempTxtXML + "</data>";
					}
					else if(bodyPart1.isMimeType("application/pdf")) {
						String contentType1 = bodyPart1.getContentType();
						SharedByteArrayInputStream stream = (SharedByteArrayInputStream) bodyPart1.getContent();
						ByteArrayOutputStream bOut = new ByteArrayOutputStream()
						//Reading in chunks is better performance-wise than reading one byte at once.
						int r;
						byte[] buffer = new byte[32 * 1000];
						//Read and write into the ByteArrayOutputStream
						while((r = stream.read(buffer)) != -1){
						  bOut.write(buffer, 0, r);
						}
						String  encoded= Base64.getEncoder().encodeToString(bOut.toByteArray());
						 finalXml =finalXml+ "<attachment contentType=" + "\"" + contentType1 + "\"" +" "+ "fileName=" + "\"" + bodyPart1.getFileName() + "\""+" "+ "discription=" + "\"" + bodyPart1.getDisposition() + "\"" + ">" + encoded	+ "</attachment>";
					}
				}
				finalXml= finalXml+"</MimeMultipartMsg>";
			}
		}
		 finalXml = finalXml+  "</MultipartMixed>";
		message.setBody(finalXml);
	} catch (MessagingException e) {
		// TODO Auto-generated catch block
// 		e.printStackTrace();
	}
    return message;
}
