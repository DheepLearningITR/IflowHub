/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
 
 import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.HashMap;
import java.util.UUID; 
import java.util.Iterator; 
import java.util.List; 
import java.lang.Thread;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;
import groovy.xml.XmlUtil; 

import java.util.Base64; 
import org.json.JSONObject; 
import org.json.JSONArray;
import org.json.JSONException;
import javax.ws.rs.core.MediaType;

import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

import groovy.xml.*;
 

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher
import java.util.regex.Pattern



import java.util.Base64
import java.util.Base64.Decoder

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.KeyFactory;
import java.security.PrivateKey;
 


def Message processData(Message message) {
    //Headers
    def headers = message.getHeaders();
     
    message.setHeader("ExceptionSubProcess", "Error - needed deep tracing");
    
    return message;
}

def String genUUID(){ 
 
   return UUID.randomUUID().toString().replace("-", "").toUpperCase(); 

}

def String timeStringParser(String timeString) { 
    return  timeString.substring(0, timeString.lastIndexOf("T")) + "T00:00:00" 
}

def Message prepWriteToIBP(Message message) {
    
    def headerMap = message.getHeaders();
    
    JSONObject writeObject = new JSONObject();  
    
    JSONObject metadataJSONObject = new JSONObject();
    
    writeObject.put("IBPDestination",    headerMap.get("IBPDestination"));
    writeObject.put("IBPCredentials",    headerMap.get("IBPCredentials")); 
        
    writeObject.put("IBPCommit",         headerMap.get("IBPCommit"));
    writeObject.put("IBPTransactionID",  genUUID());
    writeObject.put("IBPFieldsString",   headerMap.get("IBPFieldsString")); // "PERIODID2_TSTAMP,PRDID,CUSTID,LOCID,CONSENSUSDEMANDQTY");
    writeObject.put("IBPPlanningArea",   headerMap.get("IBPPlanningArea")); 
    
    JSONArray valueJSONArray = new JSONArray();   
     
        
    def body = message.getBody(java.lang.String);
    def MultipartMixed = new XmlSlurper().parseText(body)
    
    for(ProductActivityDetails in MultipartMixed.data.cXML.Message.ProductActivityMessage.ProductActivityDetails){
        
        JSONObject activityObject = new JSONObject();   
        
        String currentTS = timeStringParser(ProductActivityDetails.TimeSeries.Forecast.Period.@startDate as String)
        
        String planningArea = 
        
        // The below payload should be based on the IBPFieldsString
        // "PERIODID2_TSTAMP,PRDID,CUSTID,LOCID,CONSENSUSDEMANDQTY");
                   
		activityObject.put("PERIODID2_TSTAMP",   currentTS);
		activityObject.put("PRDID",              ProductActivityDetails.ItemID.BuyerPartID);
		activityObject.put("CUSTID",             headerMap.get("IBPCustomerID"));
		activityObject.put("LOCID",              "DC1");  //ProductActivityDetails.Contact.@addressID
		activityObject.put(headerMap.get("IBPKeyFigureName"), ProductActivityDetails.TimeSeries.Forecast.ForecastQuantity.@quantity as String);
		
		valueJSONArray.put(activityObject);
    }
    
    writeObject.put("Value", valueJSONArray);
    
    def newBody = writeObject.toString() as String;
    message.setBody(newBody);
    return message;
}

def String getTimeStamp(){
   //"yyyy-MM-dd'T'HH:mm:ss.SSSZ"
   return new Date().format("yyyy-MM-dd'T'HH:mm:ss",TimeZone.getTimeZone('GMT+2'))
}

def Message handleRequestToPendingQueue(Message message) {
    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body); 
    def queryString="" as String;
     
    // IBP Instance of the Supplier
    // in the format e.g. https://myXXXXXX-api.scmibp1.ondemand.com/sap/opu/odata/IBP/PLANNING_DATA_API_SRV/<<NAME of PLAN AREA>>
    if (input.IBPDestination == null) {
        message.setHeader("inputsAvailable", false);
        message.setHeader("inputsError", "IBPDestination Missing");
        return message;
    } else {
        message.setHeader("IBPDestination", input.IBPDestination);
    }
    
    // Credentials used for the IBP instance
    if (input.IBPCredentials == null) {
        message.setHeader("inputsAvailable", false);
        message.setHeader("inputsError", "IBPCredentials Missing");
        return message;
    } else {
        message.setHeader("IBPCredentials", input.IBPCredentials);
    }
    
    // Planning area used in the IBP instance
    if (input.IBPPlanningArea == null) {
        message.setHeader("inputsAvailable", false);
        message.setHeader("inputsError", "IBPPlanningArea Missing");
        return message;
    } else {
        message.setHeader("IBPPlanningArea", input.IBPPlanningArea);
    }
    
    // Name of the Key figure that needs to be sent to Business Networks
    if (input.IBPKeyFigureName == null) {
        message.setHeader("inputsAvailable", false);
        message.setHeader("inputsError", "IBPKeyFigureName Missing");
        return message;
    } else {
        message.setHeader("IBPKeyFigureName", input.IBPKeyFigureName);
    }
    
    // IBP Customer ID for this Ariba Network ID
    if (input.IBPKeyFigureName == null) {
        message.setHeader("inputsAvailable", false);
        message.setHeader("inputsError", "IBPCustomerID Missing");
        return message;
    } else {
        message.setHeader("IBPCustomerID", input.IBPCustomerID);
    }
    
    //Ariba Destination - Transaction URL
    if (input.AribaTransactionURL == null) {
        message.setHeader("inputsError", "AribaTransactionURL Missing");
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("AribaTransactionURL", input.AribaTransactionURL);
    }
    
     //Ariba Destination - Vendor data URL
    if (input.AribaVendorDataURL == null) {
        message.setHeader("inputsAvailable", false);
        message.setHeader("inputsError", "AribaVendorDataURL Missing");
        return message;
    } else {
        message.setHeader("AribaVendorDataURL", input.AribaVendorDataURL);
    } 
    
    // Ariba ANID - as a supplier
    if (input.AribaSupplierANID == null) {
        message.setHeader("inputsError", "AribaSupplierANID Missing");
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("AribaSupplierANID", input.AribaSupplierANID);
    }
    
    // Ariba Shared secret - between the parties
    if (input.AribaSharedSecret == null) {
        message.setHeader("inputsAvailable", false);
        message.setHeader("inputsError", "AribaSharedSecret Missing");
        return message;
    } else {
        message.setHeader("AribaSharedSecret", input.AribaSharedSecret);
    }
    
    // Ariba ANID - for the Buyer
    if (input.AribaBuyerANID == null) {
        message.setHeader("inputsAvailable", false);
        message.setHeader("inputsError", "AribaBuyerANID Missing");
        return message;
    } else {
        message.setHeader("AribaBuyerANID", input.AribaBuyerANID);
    }
    
    //Ariba Message type - default is ProductActivityMessage
    if (input.AribaMessageType == null) {
        message.setHeader("AribaMessageType", "ProductActivityMessage"); 
    } else {
        message.setHeader("AribaMessageType", input.AribaMessageType);
    }
    
    // Max messages to download - default is 5
    if (input.MaxToDownload == null) {
        message.setHeader("MaxToDownload", 5); 
    } else {
        message.setHeader("MaxToDownload", input.MaxToDownload);
    }
    
     // Commit to Planning area after download ?
    if (input.IBPCommit == null) {
        message.setHeader("IBPCommit", "true"); 
    } else {
        message.setHeader("IBPCommit", input.IBPCommit);
    }
    
     // IBPFieldsString to post data to IBP
    if (input.IBPFieldsString == null) {
        message.setHeader("inputsAvailable", false);
        message.setHeader("inputsError", "IBPFieldsString Missing");
        return message;
    } else {
        message.setHeader("IBPFieldsString", input.IBPFieldsString);
    }
    
    
    
    message.setProperty("IBPQueryUUID", genUUID())
    message.setProperty("CurrentTS", getTimeStamp())
    message.setProperty("iFlowId", "Ariba_Integration_IBP_GPR");
    
    // IBP WS-RFC support in future
    message.setHeader("IBPQueryTimeAggregationLevel", input.IBPQueryTimeAggregationLevel);
    message.setHeader("IBPQueryKey1", input.IBPQueryKey1);
    message.setHeader("IBPQueryOffset1", input.IBPQueryOffset1);
    message.setHeader("IBPPackageSizeInRows", input.IBPPackageSizeInRows);
    
    
    message.setHeader("inputsAvailable", true);
    return message;
} 
  


def String convertMilliToDate(String millInput){

    Pattern pattern = Pattern.compile("\\d+")
    Matcher matcher = pattern.matcher(millInput)

    String simpleDate =  ""
    if (matcher.find()) {
        def millInputInLong = Long.valueOf(matcher.group())
        Date result_date = new Date( millInputInLong );
        DateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        simpleDate = simple.format(result_date);
    }

    return simpleDate;
}

def String getCounter(String counterName,Message message) {
    Integer counterValue = message.getProperty(counterName) as Integer ?:0;
    counterValue = counterValue + 1;
    message.setProperty(counterName,counterValue);
    return counterValue;
}
 

def Message logMessage(java.lang.String fileName, Message message) {
	def body = message.getBody(java.lang.String);
	def messageLog = messageLogFactory.getMessageLog(message);
	def counter = getCounter(fileName + 'Counter',message).padLeft(3,' ');
	def logCounter = getCounter('OverallLogCounter',message).padLeft(4,' ');
	if(messageLog != null){
		messageLog.addAttachmentAsString(logCounter + " " + fileName + counter, body, "text/plain");
	};
	
	return message;
} 

def Message logException(Message message) {
    def exceptionText = message.getProperty("CamelExceptionCaught");
    message.setBody(exceptionText)
    message = logMessage("Exception - ", message);
	return message;
}

def Message logIBPMessage(Message message) {
    message = logMessage("IBP Log - ", message);
	return message;
}