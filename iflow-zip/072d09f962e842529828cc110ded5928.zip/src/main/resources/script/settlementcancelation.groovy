import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*
import java.util.HashMap
import java.time.LocalDateTime
import java.time.Clock


def Message processLastStepResponse(Message inputMessage) {

    //Body
    def body = inputMessage.getBody(java.lang.String) as String
    def parser = new XmlParser()
    def dom = parser.parseText(body)


    def messageLog = messageLogFactory.getMessageLog(inputMessage)

    def appType = inputMessage.getProperty("appType") as String
    def appOrg = inputMessage.getProperty("appOrg") as String

    inputMessage.setProperty("I_CONTINUE", "T")
    XmlSlurper xmlSlurper = new XmlSlurper()

    def settleCreditMemoDocNumList = dom.bo.root.docFlow.findAll({ it.documentType.text() == 'CREDIT_MEMO' }).collect({ it -> it.documentNumber?.text() })
    if (settleCreditMemoDocNumList == null || settleCreditMemoDocNumList.size() == 0) {
        messageLog.addAttachmentAsString("settleCreditMemoDocNumList is empty", properties as String, "text/plain")
        inputMessage.setProperty("I_CONTINUE", "F")

        def rootXml = xmlSlurper.parseText("<?xml version=\"1.0\" encoding=\"UTF-8\"?><root></root>")

        def flowBodyXml = xmlSlurper.parseText(body)
        rootXml.appendNode {
            settlementUUID(flowBodyXml.bo.root.settlementUUID.text())
            timestamp(LocalDateTime.now(Clock.systemUTC()) as String)
            status("CANCELLED")
            message("cancel settlement successfully")
        }
        rootXml.appendNode(flowBodyXml.documentTransactions)
        inputMessage.setBody(XmlUtil.serialize(rootXml))

        return inputMessage
    }


    def cancellationRequestsXml = xmlSlurper.parseText("<?xml version=\"1.0\" encoding=\"UTF-8\"?><CancellationCreditMemoRequests></CancellationCreditMemoRequests>")

    if (inputMessage.getProperty("isWithS4Settle") == 'T') {

        messageLog.addAttachmentAsString("Cancellation Call S4 Step Payload:", body, "text/plain")
        //should parse second step response
        def s4TargetTran = dom.trans.tran.findAll({ it.@api == 'S4Settlement' }).max({ it.@callOrder.toInteger() })
        String logSystem = s4TargetTran.response?.'**'.find({ it.name() == 'LOGSYSTEM' })?.text()
        String companyCode = s4TargetTran.response?.'**'.find({ it.name() == 'COMP_CODE' })?.text()

        def tpmSettlementDocNumList = dom.bo.root.docFlow.findAll({ it.documentType.text() == 'SETTLEMENT_DOCUMENT' }).collect { it.documentNumber.text()?.padLeft(10, '0') }.unique()

        tpmSettlementDocNumList.each { tpmSettlementDocNum ->
            cancellationRequestsXml.appendNode {
                CancellationCreditMemoRequest {
                    I_AWTYP(appType)
                    I_AWORG(appOrg)
                    I_XBLNR(tpmSettlementDocNum)
                    I_BUKRS(companyCode)
                    I_AWSYS(logSystem)
                }
            }
        }
    } else {
        messageLog.addAttachmentAsString("Cancellation Call TPM Step Payload:", body, "text/plain")

        def tpmTargetTran = dom.trans.tran.findAll({ it.@api == 'SETTLEMENT_CANCELLATION_DOCUMENT' }).max({ it.@callOrder.toInteger() })

        messageLog.addAttachmentAsString("Call TPM Step Payload targetTran:", XmlUtil.serialize(tpmTargetTran), "text/plain")


        def uniqueBillDocIdList = tpmTargetTran.response.'**'.findAll({ it.name() == 'BILL_DOC_ID' }).collect { it.text()?.padLeft(10, '0') }.unique()

        if (uniqueBillDocIdList.size() == 0) {
            inputMessage.setProperty("I_CONTINUE", "F")
            def rootXml = xmlSlurper.parseText("<?xml version=\"1.0\" encoding=\"UTF-8\"?><root></root>")

            def flowBodyXml = xmlSlurper.parseText(body)
            rootXml.appendNode {
                settlementUUID(flowBodyXml.bo.root.settlementUUID.text())
                timestamp(LocalDateTime.now(Clock.systemUTC()) as String)
                status("CANCELLED")
                message("cancel settlement successfully")
            }
            rootXml.appendNode(flowBodyXml.documentTransactions)
            inputMessage.setBody(XmlUtil.serialize(rootXml))

            return inputMessage
        } else {

            String logSys = tpmTargetTran.response[0].value()[0].value()[1].value()[0].LOGSYS.text()
            uniqueBillDocIdList.each { billDocId ->
                cancellationRequestsXml.appendNode {
                    CancellationCreditMemoRequest {
                        I_AWTYP(appType)
                        I_AWORG(appOrg)
                        I_AWREF(billDocId)
                        I_AWSYS(logSys)
                    }
                }

            }
        }
    }

    inputMessage.setProperty("currentFlowBody", body)
    inputMessage.setProperty("nextLoopIndex", 0)
    inputMessage.setProperty("lastLoop", false)

    def creditMemoRequestsXml = XmlUtil.serialize(cancellationRequestsXml) as String
    //Properties
    def properties = inputMessage.getProperties()

    messageLog.addAttachmentAsString("Call TPM Step properties:", properties as String, "text/plain")
    messageLog.addAttachmentAsString("Cancellation Credit Memo Requests: ", creditMemoRequestsXml, "text/plain")
    inputMessage.setProperty("cancellationCreditMemoRequests", creditMemoRequestsXml)

    return inputMessage
}

def Message spiltCancellationCreditMemoRequests(Message message) {

    def creditMemoRequestsXml = message.getProperty("cancellationCreditMemoRequests") as String

    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        //Properties
        def properties = message.getProperties()
        messageLog.addAttachmentAsString("All Cancellation Credit Memo Requests Message Properties:", properties as String, "text/plain");

    }

    def loopIndex = message.getProperty("nextLoopIndex") as Integer

    def parser = new XmlParser()

    def dom = parser.parseText(creditMemoRequestsXml)

    def creditMemoRequestList = dom.'**'.findAll({ it.name() == 'CancellationCreditMemoRequest' }).collect()

    def creditMemoRequest = creditMemoRequestList.get(loopIndex)

    def singleCreditMemoRequestBody = XmlUtil.serialize(creditMemoRequest) as String
    message.setBody(singleCreditMemoRequestBody)
    message.setProperty("nextLoopIndex", loopIndex + 1)
    message.setProperty("lastLoop", loopIndex == creditMemoRequestList.size() - 1)


    if (messageLog != null) {
        messageLog.addAttachmentAsString("Single Cancellation Credit Memo Request Message Properties:", message.getProperties() as String, "text/plain");
        messageLog.addAttachmentAsString("Single Cancellation Credit Memo Request Message Body:", singleCreditMemoRequestBody as String, "text/plain");
    }
    return message
}



def Message printLog(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        //Properties
        def properties = message.getProperties()
        messageLog.addAttachmentAsString("Get CreditMemos Flow Output Properties:", properties as String, "text/plain");
        messageLog.addAttachmentAsString("Get CreditMemos Flow Output Body:", body, "text/plain");
    }
    return message;
}


def Message buildErrorMsgBody(Message inputMessage) {

    def body = inputMessage.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(inputMessage);
    if (messageLog != null) {
        //Properties
        def properties = inputMessage.getProperties()
        messageLog.addAttachmentAsString("Get CreditMemos Flow Error Output Properties:", properties as String, "text/plain");
        messageLog.addAttachmentAsString("Get CreditMemos Flow Error Output Body:", body, "text/plain");
    }
    String flowBody = inputMessage.getProperty("currentFlowBody") as String
    XmlSlurper xmlSlurper = new XmlSlurper()
    def flowBodyXml = xmlSlurper.parseText(flowBody)

    String currentResponseBody = inputMessage.getProperty("currentResponseBody") as String
    String errMessage = ""

    if (currentResponseBody != null) {
        def parser = new XmlParser()
        def dom = parser.parseText(currentResponseBody)

        // Exception
        if ("FI_DOCUMENT_READ.Exception" == dom.name().localPart) {
            def str = XmlUtil.asString(dom)
            if (dom.Text.size() != 0) {
                errMessage = dom.Text.text()
                inputMessage.setProperty("errMsg", errMessage as String)
            }
            inputMessage.setProperty("simplyBody", str as String)
        }
    }

    def rootXml = xmlSlurper.parseText("<?xml version=\"1.0\" encoding=\"UTF-8\"?><root></root>")
    //must do not forget import java.time.LocalDateTime
    StringBuilder messageBuilder = new StringBuilder()
    messageBuilder.append("Failed to get the reversal credit memo in SAP S/4HANA. \n")
    messageBuilder.append(errMessage + "\n")
    String finalMessage = messageBuilder.toString()
    rootXml.appendNode {

        settlementUUID(flowBodyXml.bo.root.settlementUUID.text())
        timestamp(LocalDateTime.now(Clock.systemUTC()) as String)
        status("ERROR")
        message(finalMessage)
    }

    rootXml.appendNode(flowBodyXml.documentTransactions)
    inputMessage.setBody(XmlUtil.serialize(rootXml))
    messageLog.addAttachmentAsString("Get CreditMemos Error Output Message Payload:", inputMessage.getBody() as String, "text/plain")
    return inputMessage
}


def Message sleepTime(Message message) {
    //Properties
    def properties = message.getProperties();

    def retryCount = properties.get("retryCount") as Integer;
    def retryInterval = properties.get("retryInterval") as Integer;

    if (retryCount != 0) {
        new Object().sleep(retryInterval*1000);
    }

    def body = message.getBody(java.lang.String) as String

    message.setProperty("currentRequestBody", message.getBody() as String)

    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("Get CreditMemos Rfc RequestBody:", body as String, "text/plain");

    return message;
}

def Message processResponse(Message inputMessage) {
    //Body
    def msgBody = inputMessage.getBody() as String
    boolean needRetry = isRetry(msgBody)
    inputMessage.setProperty("needRetry", needRetry)

    //Properties
    def propertiesMap = inputMessage.getProperties()
    def requestBody = propertiesMap.get("currentRequestBody") as String
    inputMessage.setBody(requestBody)
    
    def messageLog = messageLogFactory.getMessageLog(inputMessage)

    def retryCount = propertiesMap.get("retryCount") as Integer
    if (needRetry) {

        retryCount = retryCount + 1

        inputMessage.setProperty("retryCount", retryCount)
        inputMessage.setProperty("currentResponseBody", msgBody)

        messageLog.addAttachmentAsString("Get CreditMemos Response Need Retry, Response Body: ", msgBody, "text/plain")
        return inputMessage
    }
    inputMessage.setProperty("retryCount", retryCount)

    LocalDateTime utcDateTime = LocalDateTime.now(Clock.systemUTC())

    XmlSlurper xmlSlurper = new XmlSlurper()

    def currentResponseBody = xmlSlurper.parseText(msgBody)
    messageLog.addAttachmentAsString("Get CreditMemos Response Body: ", msgBody, "text/plain")

    def currentRequestBody = xmlSlurper.parseText(requestBody)

    String lastFlowBody = propertiesMap.get("currentFlowBody") as String

    def messageXML = xmlSlurper.parseText(lastFlowBody)

    if (messageXML.documentTransactions.size() == 0) {
        messageXML.appendNode {
            documentTransactions()
        }
        messageXML = xmlSlurper.parseText(XmlUtil.serialize(messageXML))
    }

   
    def settleCreditMemoDocNumList =  messageXML.bo.root.docFlow.findAll({ it.documentType.text() == 'CREDIT_MEMO' }).collect({it->it.documentNumber?.text()})
    
    messageLog.addAttachmentAsString("settleCreditMemoDocNumList: ", settleCreditMemoDocNumList as String, "text/plain")

    def bkpfXml = xmlSlurper.parseText("<T_BKPF></T_BKPF>")
    currentResponseBody.T_BKPF.item.each { bkpfItem ->

        if (!(bkpfItem.BELNR.text() in settleCreditMemoDocNumList)) {
            bkpfXml.appendNode {
                item(bkpfItem.BLART + bkpfItem.BELNR + bkpfItem.BUKRS + bkpfItem.GJAHR)
            }

            if ("D".equalsIgnoreCase(bkpfItem.KOART.text())) {
                messageXML.appendNode {
                    documentTransactions {
                        documentNumber(bkpfItem.BELNR.text())
                        documentType("REVERSAL_CREDIT_MEMO")
                        fiscalYear(bkpfItem.GJAHR.text())
                        createdOn(utcDateTime)
                        companyCode(bkpfItem.BUKRS.text())
                    }
                }
            }
        }
    }

    def besgXml = xmlSlurper.parseText("<T_BSEG></T_BSEG>")
    currentResponseBody.T_BSEG.item.each { bsegItem ->
        if (!(bsegItem.BELNR.text() in settleCreditMemoDocNumList)) {
            besgXml.appendNode {
                item(bsegItem.BLART + bsegItem.BUZEI + bsegItem.BELNR + bsegItem.BUKRS + bsegItem.GJAHR + bsegItem.KOART)
            }
            if ("D".equalsIgnoreCase(bsegItem.KOART.text())) {
                messageXML.appendNode {
                    documentTransactions {
                        documentNumber(bsegItem.BELNR.text())
                        documentType("REVERSAL_CREDIT_MEMO")
                        fiscalYear(bsegItem.GJAHR.text())
                        createdOn(utcDateTime)
                        companyCode(bsegItem.BUKRS.text())
                    }
                }
            }
        }
    }

    messageXML.trans.appendNode {
        tran("api": "CreditMemo", "callOrder": retryCount) {
            request {
                body(currentRequestBody)
            }
            response(bkpfXml + besgXml)
        }
    }


    inputMessage.setProperty("currentFlowBody", XmlUtil.serialize(messageXML))


    messageLog.addAttachmentAsString("Get CreditMemos Response Properties:", propertiesMap as String, "text/plain")

    return inputMessage;
}

boolean isRetry(String body) {
    if (body == null || body == "") {
        return true
    }
    def parser = new XmlParser()
    def dom = parser.parseText(body)

    if ("FI_DOCUMENT_READ.Exception" == dom.name().localPart) {
        if (dom.Text.size() != 0) {
            errMessage = dom.Text.text()
            if (errMessage.contains("NOT_FOUND")) {
                return false
            }
        }
    }
    if (dom.name().localPart != 'FI_DOCUMENT_READ.Response') {
        return true
    }
    if (dom.T_BSEG.item.size() == 0) {
        return true
    }
    // what is the existing item refer?
    return false
}
