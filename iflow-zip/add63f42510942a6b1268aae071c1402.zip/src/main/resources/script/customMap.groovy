import com.sap.it.api.mapping.*;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String customMap(String Date_Val,String OSDate,String CStr1,String CStr2,String CStr3,String CStr4,String CStr5,String CStr6,String CStr7,String CStr8,String CStr9,String CStr10,String CStr11,String CStr12,String CStr13,String CStr14,String CStr15)
{
	
	String Original_Start_Date="";
	Map<String,String> inputValuesMap = new HashMap<String,String>();

	if(Date_Val != " ")
	{
		inputValuesMap.put("custom_date1",CStr1);
		inputValuesMap.put("custom_date2",CStr2);
		inputValuesMap.put("custom_date3",CStr3);
		inputValuesMap.put("custom_date4",CStr4);
		inputValuesMap.put("custom_date5",CStr5);
		inputValuesMap.put("custom_date6",CStr6);
		inputValuesMap.put("custom_date7",CStr7);
		inputValuesMap.put("custom_date8",CStr8);
		inputValuesMap.put("custom_date9",CStr9);
		inputValuesMap.put("custom_date10",CStr10);
		inputValuesMap.put("custom_date11",CStr11);
		inputValuesMap.put("custom_date12",CStr12);
		inputValuesMap.put("custom_date13",CStr13);
		inputValuesMap.put("custom_date14",CStr14);
		inputValuesMap.put("custom_date15",CStr15);
		
		if(inputValuesMap.get(Date_Val) != "noVal"){
			Original_Start_Date = inputValuesMap.get(Date_Val);
		}
	}
	else{
		Original_Start_Date = OSDate;
	}

	return Original_Start_Date; 
}