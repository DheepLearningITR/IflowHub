
import com.sap.it.api.mapping.*;

def void GTINS_UOM_Inter_2field_check_mapping (String[] Material_ID_General, String[] Basic_UOM,String[] Material_ID_GTINS,String[] Trading_UOM, String[] mapping_field , Output output, MappingContext context) 
{

// Map only if Trading_UOM is not same as Basic_UOM and there exists a GTIN with Basic_UOM
// check if there is GTIN for Basic_UOM or not. If it does not exists then do not map all other the GTINs with different UMO for that material.
// If a GTIN for basic exists then map all other GTINS which has Trading_UOM and Basic_UOM as not same.




Map<String,String> map = new HashMap<>();

    for(int i=0; i<Material_ID_General.length;i++){
        map.put(Material_ID_General[i],Basic_UOM[i]);
        }

Map<String,String> map_1 = new HashMap<>();
    for(int j=0; j<Material_ID_GTINS.length; j++){
        map_1.put( [ Material_ID_GTINS[j],Trading_UOM[j] ], mapping_field[j]);
    }
    
    for(int k=0;k<Material_ID_GTINS.length;k++){
        def result1=map.get(Material_ID_GTINS[k])
        def result2=map_1.get( [Material_ID_GTINS[k],result1] );
        
        //if(result2!=null && result1!=Trading_UOM[k]){
        if( !(result2 in [null]) && !(result1 in [Trading_UOM[k]]) ) {
            output.addValue( mapping_field[k])
        }
    }

}