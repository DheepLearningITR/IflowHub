import com.sap.it.api.mapping.*;

def void Tax_Type_ratetype (String[] Material_ID, String[] Country, String[] Tax_type, String[] Tax_rate_type, Output Tax_cat_1, Output Tax_cal_1,Output Tax_cat_2, Output Tax_cal_2,Output Tax_cat_3, Output Tax_cal_3,Output Tax_cat_4, Output Tax_cal_4,Output Tax_cat_5, Output Tax_cal_5, MappingContext context) 
{

//Output Tax_cat_6, Output Tax_cal_6,Output Tax_cat_7, Output Tax_cal_7,Output Tax_cat_8, Output Tax_cal_8,Output Tax_cat_9, Output Tax_cal_9,
Map<String,String> map = new HashMap<>();

for(int i=0;i<Material_ID.length;i++){
    def result1=map.get( [ Material_ID[i],Country[i] ]);
    if(result1==null){
        map.put( [ Material_ID[i],Country[i]  ], [ [Tax_type[i],Tax_rate_type[i]] ])
    }
    else{
        result1.add([Tax_type[i],Tax_rate_type[i]]);
        map.put( [ Material_ID[i],Country[i]] , result1 )
    }
}

Collection<List<List<String>>> values = map.values();

for (List<List<String>> value : values) {
    def output_string=[];
    
    def k=0;
    for(j=0;j<value.size();j++){
        output_string.add(value[j][0])
        output_string.add(value[j][1])
        k=k+2;
    }
    for(int j=k;j<18;j++){
        output_string.add('');
    }

    
    Tax_cat_1.addValue(output_string[0])
    Tax_cal_1.addValue(output_string[1])
    Tax_cat_2.addValue(output_string[2])
    Tax_cal_2.addValue(output_string[3])
    Tax_cat_3.addValue(output_string[4])
    Tax_cal_3.addValue(output_string[5])
    Tax_cat_4.addValue(output_string[6])
    Tax_cal_4.addValue(output_string[7])
    Tax_cat_5.addValue(output_string[8])
    Tax_cal_5.addValue(output_string[9])
    //Tax_cat_6.addValue(output_string[10])
    // Tax_cal_6.addValue(output_string[11])
    // Tax_cat_7.addValue(output_string[12])
    // Tax_cal_7.addValue(output_string[13])
    // Tax_cat_8.addValue(output_string[14])
    // Tax_cal_8.addValue(output_string[15])
    // Tax_cat_9.addValue(output_string[16])
    // Tax_cal_9.addValue(output_string[17])
    
}

}