import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message)
{
    def body = message.getBody(java.lang.String);
    message.setProperty("S4MapOutput", body);
    return message;
}

