import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){

		def Name = message.getHeaders().get("Name");		
		if(Name!=null){
			messageLog.addCustomHeaderProperty("Name", Name);		
        }
	}
	return message;
}