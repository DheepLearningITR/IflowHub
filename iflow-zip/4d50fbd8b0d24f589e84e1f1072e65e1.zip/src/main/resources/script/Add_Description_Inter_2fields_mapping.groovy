import com.sap.it.api.mapping.*;

def void Add_Description_Inter_2fields_mapping (String[] Material_ID_General, String[] Language_General,String[] Material_ID_Description,String[] Language_Descripition, String[] mapping_field, Output output, MappingContext context) 
{

Map<String,String> map = new HashMap<>();

    for(int i=0; i<Material_ID_General.length;i++){
        map.put( [Material_ID_General[i],Language_General[i]],Material_ID_General[i]);
        }


    for(int j=0; j<Material_ID_Description.length; j++){

        def result1 = map.get([Material_ID_Description[j],Language_Descripition[j]])
        if(result1 == null)
            output.addValue(mapping_field[j])
    }

}