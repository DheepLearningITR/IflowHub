import com.sap.it.api.mapping.*;

def void Valuation_details_Inter_mapping(String[] Main_Material_ID, String[] Main_Residence_ID, String[] Material_ID,String[] Residence_ID,String[] Book_ID,String[] Valid_to,String[] map_Field , Output output, MappingContext context) 
{


Map<String,String> map = new HashMap<>();

    for(int i=0; i<Material_ID.length;i++){
        //if(Valid_to[i]=="9999-12-31T00:00:00.000" && Book_ID[i]=="Z001"){
        if( ( Valid_to[i] in ["9999-12-31T00:00:00.000"] ) && ( Book_ID[i] in ["Z001"] ) ){
            map.put([Material_ID[i],Residence_ID[i]],map_Field[i]);
        }
    }
    
    for(int j=0; j<Main_Material_ID.length; j++){

        def result1 = map.get([Main_Material_ID[j],Main_Residence_ID[j]])
        if(result1 == null)
            output.addValue('')
        else
            output.addValue(result1)
    }

}