import com.sap.it.api.mapping.*;

def String float_to_int(String arg1){
    float n=Float.valueOf(arg1);
	return (int)n; 
}