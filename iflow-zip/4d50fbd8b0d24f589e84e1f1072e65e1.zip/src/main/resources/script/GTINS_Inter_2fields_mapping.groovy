import com.sap.it.api.mapping.*;

def void GTINS_MaterialID_Inter_2field_check_mapping (String[] Material_ID_General, String[] Basic_UOM,String[] Material_ID_GTINS,String[] Trading_UOM , Output output, MappingContext context) 
{


Map<String,String> map = new HashMap<>();

    for(int i=0; i<Material_ID_General.length;i++){
        map.put([Material_ID_General[i],Basic_UOM[i]],Material_ID_General[i]);
        }


    for(int j=0; j<Material_ID_GTINS.length; j++){

        def result1 = map.get([Material_ID_GTINS[j],Trading_UOM[j]])
        if(result1 == null)
            output.addValue(Material_ID_GTINS[j])
    }

}