import com.sap.it.api.mapping.*;

def void Tax_key_feildMapping(String[] Material_ID, String[] Country, String[] Tax_type, String[] Tax_rate_type, Output output_Material_ID, Output output_Country, MappingContext context) 
{

Map<String,String> map = new HashMap<>();

for(int i=0;i<Material_ID.length;i++){
    def result1=map.get( [ Material_ID[i],Country[i] ]);
    if(result1==null){
        map.put( [ Material_ID[i],Country[i]  ], [ [Tax_type[i],Tax_rate_type[i]] ])
    }
    else{
        result1.add([Tax_type[i],Tax_rate_type[i]]);
        map.put( [ Material_ID[i],Country[i]] , result1 )
    }
}

Set<List<String>> keys = map.keySet();
for(List<String> key : keys) {
    output_Material_ID.addValue(key[0]);
    output_Country.addValue(key[1]);
}

}