import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import java.util.Base64
import java.util.Base64.Encoder

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def lookupResponse = new JsonSlurper().parse(json)
    
    if(lookupResponse.result.size() > 0) {
        def aasid = lookupResponse.result[0] // Extract the UUID directly from the array
    
        message.setProperty('AASID', aasid)

        // Base64 encoding
        Encoder encoder = Base64.getUrlEncoder()
        String aasidEncoded = encoder.encodeToString(aasid.bytes) // Use .bytes to get byte array
        message.setProperty('AASID_Encoded', aasidEncoded)
    } else {
        message.setProperty("AASID", '')
    }
    
    message.setBody('')
    return message
}