import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    def FinalPostingBody = ''
    if(input) {
        message.setProperty('Endpoint', input.'edc:endpoint')
        message.setHeader(input.'edc:authKey', input.'edc:authCode')
	}
    message.setBody(FinalPostingBody)
    return message
}
