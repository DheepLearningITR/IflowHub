import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def catalogs = message.getProperties().get("CATALOG_RESULT")
    def index 
    def parentIndex
    try{
        def input = new JsonSlurper().parseText(catalogs)
        if (input instanceof List) {
            index = message.getProperties().get("CamelLoopIndex")
            message.setProperty('CURRENT_LOOP_INDEX',index)
            message.setProperty('CONTRACT_CONFIRMED', 'N')
            parentIndex = message.getProperties().get("PARENT_LOOP_INDEX")
            messageLog.addAttachmentAsString(" catalog INFO-"+parentIndex+"_"+index, (new JsonBuilder(input[index])).toPrettyString() , "text/xml")
            if( input.size() <= (index+1)) {
                message.setProperty('CONTINUE_CATALOG_PROCESSING',"N")
            }
            message.setProperty('assetId', input[index].'edc:id') 
            message.setProperty('CatalogEntry',input[index])
            def mtJson = new JsonBuilder(input[index])
            messageLog.addAttachmentAsString(" catalog Current-"+parentIndex+"_"+index, mtJson.toPrettyString() , "text/xml")
            message.setBody(mtJson.toPrettyString())
        } else {
            message.setProperty('CURRENT_LOOP_INDEX',0)
            message.setProperty('CONTRACT_CONFIRMED', 'N')
            parentIndex = message.getProperties().get("PARENT_LOOP_INDEX")
            message.setProperty('CONTINUE_CATALOG_PROCESSING',"N")
            message.setProperty('assetId', input.'edc:id') 
            message.setProperty('CatalogEntry',input)
            def mtJson = new JsonBuilder(input)
            messageLog.addAttachmentAsString(" catalog Current-"+parentIndex+"_singleCatalog", mtJson.toPrettyString() , "text/xml")
            message.setBody(mtJson.toPrettyString())
        }
    }catch(Exception e){
        messageLog.addAttachmentAsString(" catalog-Error "+parentIndex+"_"+index, e.getMessage(), "text/xml")

    }
    return message
}