import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    //Reader json = message.getBody(java.io.Reader)
    def body = message.getBody(java.lang.String) as String
    def index 
    def parentIndex
    try{
       // def input = new JsonSlurper().parse(json)
        index = message.getProperties().get("CURRENT_LOOP_INDEX")
        parentIndex = message.getProperties().get("PARENT_LOOP_INDEX")
        def input = new JsonSlurper().parseText(body)
        if ((input && input.globalAssetId) || (input && input.result[0] && input.result[0].globalAssetId)) {
            message.setProperty('CONTINUE_CATALOG_PROCESSING',"N")
            message.setProperty('CONTINUE_PARTNER_EDC_PROCESSING',"N")
            messageLog.addAttachmentAsString(" AAS_Result-"+parentIndex+"_"+index, (new JsonBuilder(input)).toPrettyString() , "text/xml")
        }
        //messageLog.addAttachmentAsString(" partnerEDCUrl-"+index, partnerEDCUrl , "text/xml")
        messageLog.addAttachmentAsString(" catalog INFO-Result-"+parentIndex+"_"+index, (new JsonBuilder(input)).toPrettyString() , "text/xml")
 
    }catch(Exception e){
        messageLog.addAttachmentAsString(" catalog INFO-Result-Error"+parentIndex+"_"+index, e.getMessage(), "text/xml")

    }
    return message
}