import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
 	def responseCode = message.getHeaders().get("CamelHttpResponseCode")
    message.setProperty('DATA_OFFER_EXISTS', 'N')
 	if(responseCode != 200){
 	        return message
 	}
 	
    Reader json = message.getBody(java.io.Reader)
    def catalogs = new JsonSlurper().parse(json)
    if (catalogs) {
        if (catalogs instanceof List) {
        	def var1 = 'data.core.digitalTwinRegistry'

        	Closure query1 = { it.'edc:type' == var1}
        	def filterlist = catalogs.'dcat:dataset'.findAll (query1)
            if(filterlist.size() > 0) {
                def mtJson = new JsonBuilder(filterlist)
                message.setBody(mtJson.toPrettyString())
                message.setProperty('DATA_OFFER_EXISTS', 'Y')
                message.setProperty('CATALOG_RESULT',mtJson.toPrettyString())
                message.setProperty('CONTINUE_CATALOG_PROCESSING',"Y")
            } 
        } else {
            def mtJson = new JsonBuilder(catalogs.'dcat:dataset')
            message.setBody(mtJson.toPrettyString())
            message.setProperty('DATA_OFFER_EXISTS', 'Y')
            message.setProperty('CATALOG_RESULT',mtJson.toPrettyString())
            message.setProperty('CONTINUE_CATALOG_PROCESSING',"Y")
        }
    } else {
        message.setBody('Error findig Data Offer')
    }
    return message
}