import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
 	def contract = message.getProperties().get('CatalogEntry')
    def contractOfferMap = [:]
    NegotiationInitiateRequest(contractOfferMap,contract,message)
    def contractOfferJson = new JsonBuilder(contractOfferMap)
    message.setHeader('Content-Type', 'application/json' + '; charset=utf-8' )        
    message.setBody(contractOfferJson.toPrettyString())
    return message;
}

def NegotiationInitiateRequest(def contractOfferMap, def contract, def message) {
	def contextMap = [:]
	def offerMap = [:]
	def policyMap = [:]
	def permissionMap = [:]
	def actionMap = [:]

    def partnerEDCEndPoint = message.getProperties().get('partnerEDCUrl')
    def providerDsp = message.getProperties().get('providerDsp')
    def partnerBPN = message.getProperties().get('partnerBPN')
    def offerId = contract.'odrl:hasPolicy'.'@id'
    def assetId = contract.'edc:id'
	contextMap.'odrl' = 'http://www.w3.org/ns/odrl/2/'
	contextMap.'@vocab' = 'https://w3id.org/edc/v0.0.1/ns/'
	contractOfferMap.'@context' = contextMap
	contractOfferMap.'@type' = 'NegotiationInitiateRequestDto'
	contractOfferMap.'connectorAddress' =partnerEDCEndPoint+providerDsp
	contractOfferMap.'protocol' = 'dataspace-protocol-http'
	contractOfferMap.'connectorId' = partnerBPN
	contractOfferMap.'providerId' = partnerBPN
	offerMap.'offerId' = offerId
	offerMap.'assetId' = assetId
	contractOfferMap.'offer' = offerMap
	offerMap.'policy' = contract.'odrl:hasPolicy'
}
