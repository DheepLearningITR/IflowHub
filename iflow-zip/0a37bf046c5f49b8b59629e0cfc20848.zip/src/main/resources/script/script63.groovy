import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
 	def responseCode = message.getHeaders().get("CamelHttpResponseCode")
    message.setProperty('DATA_OFFER_EXISTS', 'N')
 	if(responseCode != 200){
 	        return message
 	}
 
    return message
}