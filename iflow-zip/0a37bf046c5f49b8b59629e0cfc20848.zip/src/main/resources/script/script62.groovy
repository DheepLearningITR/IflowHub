import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    //message.setProperty('CONTINUE_CATALOG_PROCESSING',"N")
    message.setProperty('DATA_OFFER_EXISTS', 'N')
 	return message
}