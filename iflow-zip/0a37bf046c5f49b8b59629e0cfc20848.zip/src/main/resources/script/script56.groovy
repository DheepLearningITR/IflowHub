import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def json = message.getProperties().get("EDC_DISCOVERY_RESULT")
    def input = new JsonSlurper().parseText(json)
    def index = message.getProperties().get("CamelLoopIndex")
    message.setProperty('PARENT_LOOP_INDEX',index)
    message.setProperty('CATALOG_RESULT',"")
    int indexNum = index.toInteger()
    def bpnMap = [:]
    if(input instanceof List ){
        bpnMap = input[0] 
    }else{
        bpnMap = input 
    }
    if( bpnMap.connectorEndpoint && bpnMap.connectorEndpoint.size() > indexNum){
        messageLog.addAttachmentAsString(" LoopCounter-"+index, "URL List "+(new JsonBuilder(input)).toPrettyString() +"---"+indexNum+"---"+bpnMap.connectorEndpoint[indexNum], "text/xml")
        message.setProperty('partnerEDCUrl', bpnMap.connectorEndpoint[indexNum])
        message.setProperty('partnerBPN', bpnMap.bpn)
        message.setProperty('PROCESS_EDC', "Y")
        message.setProperty('CONTINUE_PARTNER_EDC_PROCESSING',"Y")
        message.setProperty('CONTINUE_CATALOG_PROCESSING',"Y")
    }else{
        messageLog.addAttachmentAsString(" LoopCounter-"+index, "URL List "+(new JsonBuilder(input)).toPrettyString() +"---"+indexNum, "text/xml")
         message.setProperty('PROCESS_EDC', "N")
         message.setProperty('CONTINUE_CATALOG_PROCESSING',"N")
    }
    if( bpnMap.connectorEndpoint && bpnMap.connectorEndpoint.size() <= (indexNum+1)){
        message.setProperty('CONTINUE_PARTNER_EDC_PROCESSING',"N")
    }
    return message
}