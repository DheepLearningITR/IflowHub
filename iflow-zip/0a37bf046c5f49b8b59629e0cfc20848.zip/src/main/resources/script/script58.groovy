import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
 	Reader json = message.getBody(java.io.Reader)
    def contractConfirmation = new JsonSlurper().parse(json)
    def continueRetry = 'Y'
    def contractTimeOut = 'N'
    def contractConfirmed = 'N'
    def startTime
    if(startTime == null) {
        Date date = new Date()
        startTime = date.getTime()
        contractTimeOut = 'N'
    } else {
        long t1 = startTime
        Date date = new Date()
        long t2 = date.getTime()
        if(t2 - t1 > 60000) {
            contractTimeOut = 'Y'
        } else {
            contractTimeOut = 'N'
        }
    }
    if(contractConfirmation.'edc:state' == 'FINALIZED') {
        contractConfirmed = 'Y'
        message.setProperty('CONTRACT_CONFIRMED', 'Y')
    } else {
        message.setProperty('CONTRACT_CONFIRMED', 'N')
        contractConfirmed = 'N'
    }
    if(contractTimeOut == 'N' && contractConfirmed == 'N') {
        continueRetry = 'Y'
        sleep(2000)
    } else {
        continueRetry = 'N'    
    } 
    if(contractConfirmation.'edc:state' == 'TERMINATED') {
        message.setProperty('CONTRACT_CONFIRMED', 'N')
        continueRetry = 'N'
    } 
    message.setProperty('CONTINUE_RETRY', continueRetry)

    return message;
}
