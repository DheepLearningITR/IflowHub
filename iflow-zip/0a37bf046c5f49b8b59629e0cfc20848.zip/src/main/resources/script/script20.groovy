import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
 	Reader json = message.getBody(java.io.Reader)
    def contractConfirmation = new JsonSlurper().parse(json)
    def Catenax_Vendor = message.getHeaders().get("catenax_vendor")
    message.setProperty('CONTRACT_CONFIRMED', 'N')

    message.setProperty('transferId', '')

    if (contractConfirmation.isEmpty()) {
        message.setProperty('EmptyJson', 'Y')
    } else {
        if (contractConfirmation instanceof List) {
            contractConfirmation.each {
                if (it.'edc:providerId' == Catenax_Vendor && it.'tx:edrState' == 'NEGOTIATED') {
                    message.setProperty('transferId', it.'edc:transferProcessId')
                    message.setProperty('CONTRACT_CONFIRMED', 'Y')
                    return message
                }
            }
        } else {
            if (contractConfirmation.'edc:providerId' == Catenax_Vendor && contractConfirmation.'tx:edrState' == 'NEGOTIATED') {
                message.setProperty('transferId', contractConfirmation.'edc:transferProcessId')
                message.setProperty('CONTRACT_CONFIRMED', 'Y')
            }
        }
    }
    return message
}
