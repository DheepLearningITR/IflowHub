import com.sap.gateway.ip.core.customdev.util.Message
//import java.util.HashMap
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def catalogMap = [:]
    getCataLogPayload(catalogMap,message)
    def mtJson = new JsonBuilder(catalogMap)
    message.setBody(mtJson.toPrettyString())
    message.getHeaders().remove('CamelHttpPath')
    message.setHeader('Content-Type', 'application/json' + '; charset=utf-8' )
    return message;
}

def getCataLogPayload(def catlogMap, def message) {
    def contextMap = [:]
    def querySpecMap = [:]
    def filterExpression = [:]
    def partnerEDCUrl = message.getProperties().get('partnerEDCUrl')
    def providerDsp = message.getProperties().get('providerDsp')
    contextMap.'edc' = 'https://w3id.org/edc/v0.0.1/ns/'
    contextMap.'@vocab' = 'https://w3id.org/edc/v0.0.1/ns/'
    catlogMap.'@context' = contextMap
    catlogMap.'@type' = 'CatalogRequest'
    catlogMap.protocol = 'dataspace-protocol-http'
    catlogMap.counterPartyAddress = partnerEDCUrl + providerDsp
    querySpecMap.offset = 0
    querySpecMap.limit = 100
    filterExpression.operandLeft = 'https://w3id.org/edc/v0.0.1/ns/type'
    filterExpression.operator = '='
    filterExpression.operandRight = 'data.core.digitalTwinRegistry'
    querySpecMap.filterExpression = filterExpression
    catlogMap.querySpec = querySpecMap
}
