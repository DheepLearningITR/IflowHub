import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.time.Instant;
import org.apache.camel.converter.stream.ByteArrayInputStreamCache;
import groovy.json.JsonSlurperClassic;

def Message processData(Message message) {
    //Body
    def body = message.getBody(String.class);
    if(body != null && !body.trim().isEmpty()){
        def parsedObj = new JsonSlurper().parseText(body);
    
    
    if(!parsedObj.value.isEmpty()){
        def finalBody = new JsonSlurper().parseText('{}');
        def slurper = new JsonSlurper();
        
        finalBody<<["supplier": slurper.parseText(JsonOutput.toJson([id: parsedObj.value[0].supplierId]))];
        finalBody<<["supplierContact": slurper.parseText(JsonOutput.toJson([id: parsedObj.value[0].id]))];
        message.setProperty("buPaFound", true);
        
        JsonBuilder builder = new JsonBuilder(finalBody);
        def json = builder.toPrettyString();

        def map = slurper.parseText(json);
    
        message.setProperty("casePayload", map);
    }
    }
    message.setBody("");
    
    return message;
}