import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    
    def body = message.getBody(String.class);
	def parsedObj = new JsonSlurper().parseText(body);
	def slurper = new JsonSlurper();
	
	def standardFields = ["description", "subject", "priority", "caseType", "email", "event"];
	
	def extensions = new JsonSlurper().parseText('{}');

	message.getProperties().put("description","");
	
	parsedObj.each {
	    if(it.getKey()=="description"){
	        message.setProperty("description", it.getValue())
	         
	    }else{
	        message.getProperties().put(it.getKey(),it.getValue());
	    }
	
	 if(!standardFields.contains(it.getKey())){
	     extensions[it.getKey()] = it.getValue();
	 }
	}

	message.setProperty("extensions", extensions);

	message.getProperties().put("templateStatus", "ACTIVE");
	
	def properties = message.getProperties();
	def languageCode = properties.get("LanguageCode");

    message.getHeaders().put("Accept-Language", languageCode);
    message.getHeaders().put("Accept", "application/json");
    
   
    return message;

}