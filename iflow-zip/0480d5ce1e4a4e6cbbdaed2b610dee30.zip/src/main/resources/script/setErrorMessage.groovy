import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    
    def headers = message.getHeaders();
    
    def ex = headers.get("CamelHttpResponseCode");
    
     if (ex!=200 && ex!=201) {
          message.setBody(headers.get("CamelHttpResponseText") + "  please check the Iflow configuration");
           message.setHeader("CamelHttpResponseCode", "400");
     }
     else{
          def email = message.getProperty("email");
          message.setBody("No Business partner found for email: " + email);
    
         message.setHeader("CamelHttpResponseCode", "400");
     }
    
   

    return message;
}