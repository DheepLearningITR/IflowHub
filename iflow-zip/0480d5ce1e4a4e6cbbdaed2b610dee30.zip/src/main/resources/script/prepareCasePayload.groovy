import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.time.Instant;
import org.apache.camel.converter.stream.ByteArrayInputStreamCache;
import groovy.json.JsonSlurperClassic;

def Message processData(Message message) {
    //Body
    def body = message.getBody(String.class);
   
    def priority = message.getProperty("priority");
    
    def finalBody = new JsonSlurper().parseText('{}');
    
    def description = new JsonSlurper().parseText('{}');
    
    if(body != ""){
        def noteObject = new JsonSlurper().parseText(body);
        description<<["noteId": noteObject.value.id];
        finalBody<<["description": description];
    }
    
    finalBody<<["subject": message.getProperty("subject")];
    finalBody<<["caseType": message.getProperty("caseType")];
    finalBody<<["origin": "FEEDBACK"];
    finalBody<<["extensions": message.getProperty("extensions")];
    
    if(priority != -1){
        finalBody<<["priority": priority];
    }
    
    finalBody.putAll(message.getProperty("casePayload"));
    
    JsonBuilder builder = new JsonBuilder(finalBody);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
    
    message.setBody(jsonBody);
     
    return message;
}