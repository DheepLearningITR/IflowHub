import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;

def Message processData(Message message) {

    def map = message.getProperties();
    
    def ex = map.get("CamelExceptionCaught");

    if (ex!=null) {
        message.setBody(ex.getResponseBody());
    }
    
    return message;
}