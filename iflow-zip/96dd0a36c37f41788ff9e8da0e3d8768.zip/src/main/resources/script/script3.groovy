import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {

    def body = message.getBody();

    def headers = message.getHeaders();

    def properties = message.getProperties();
    def count = properties.get("count");
    def resultRows = properties.get("resultRows");
    message.setProperty("projectId", resultRows[count].PARENT_PROJECT_ID);
    message.setProperty("eventId", resultRows[count].INTERNAL_ID);
    
    //get db schema
    def db_schema = properties.get('Database_Schema_Name');
    
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    
    sqlStatement.root {
        sqlStatement.SelectStatement {
            sqlStatement.app_sourcing_project_users(action: 'SELECT') {
                sqlStatement.table(db_schema + '.APP_SOURCING_PROJECT_USERS')
                sqlStatement.access {
                    sqlStatement.PROJECT_ID()
                }
                sqlStatement.key {
                    sqlStatement.PROJECT_ID(resultRows[count].PARENT_PROJECT_ID)
                }
            }
        }
    };
    
    //set body
    message.setBody(writer.toString());
    
    return message;
}