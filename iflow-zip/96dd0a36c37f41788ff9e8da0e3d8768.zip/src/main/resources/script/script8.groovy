import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();

    def properties = message.getProperties();
    def count = properties.get("countTeams");
    def resultRecords = properties.get("resultRecordsTeams");
    def projectId = properties.get("projectId");
    
    def teamContent = resultRecords[count];
    
    message.setProperty("projectTeamId", teamContent.id);    
    message.setProperty("projectTeamName", teamContent.name);    

    def hasChildsToInsert = '0';
    
    if (teamContent.childGroups && teamContent.childGroups.size()>0) {
        hasChildsToInsert = '1';
        
        message.setProperty("countGroups", 0);
        message.setProperty("totalResultGroups", teamContent.childGroups.size());
        message.setProperty("resultRecordsGroups",teamContent.childGroups);
    }
    
    message.setProperty("hasChildsToInsert", hasChildsToInsert);

    
    return message;
}