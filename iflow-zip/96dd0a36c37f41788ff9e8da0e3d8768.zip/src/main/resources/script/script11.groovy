import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def properties = message.getProperties();
    valueCount = properties.get("countGroups");
    valueCount = valueCount + 1;
    message.setProperty("countGroups", valueCount);
  
    return message;
}