import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def jsonSlurper = new JsonSlurper();
    def apiResult = jsonSlurper.parse(body);
    
    def properties = message.getProperties();
    
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    
    def projectId = properties.get("projectId");
    def projectTeamId = properties.get("projectTeamId");
    def projectTeamName = properties.get("projectTeamName");
    def userList = properties.get("userListTeamId");
     
    def db_schema = properties.get('Database_Schema_Name');
    
    def hasUserGroupsToInsert = '0';
    
    if (apiResult && apiResult.size() > 0) {
       
        
        sqlStatement.root {
            for (user in apiResult) {
                
                if (!userList.contains(user.uniqueName)) {
                    
                     //hasResultsToInsert
                     hasUserGroupsToInsert = '1';
        
                    sqlStatement.InsertStatement {
                         sqlStatement.app_sourcing_project_users(action: 'INSERT') {
                            sqlStatement.table(db_schema + '.APP_SOURCING_PROJECT_USERS')
                            sqlStatement.access {
                                sqlStatement.PROJECT_ID(projectId)
                                sqlStatement.TEAM_ID(projectTeamId)
                                sqlStatement.TEAM_NAME(projectTeamName)
                                sqlStatement.UNIQUE_NAME(user.uniqueName)
                                sqlStatement.NAME(user.name)
                                sqlStatement.EMAIL(user.emailAddress)
                            }
                        }
                    }
                }
                
            }
        }
    }
    
    //hasResultsToInsert
    message.setProperty("hasUserGroupsToInsert", hasUserGroupsToInsert);
     
    
    message.setBody(writer.toString());
    
    return message;
}