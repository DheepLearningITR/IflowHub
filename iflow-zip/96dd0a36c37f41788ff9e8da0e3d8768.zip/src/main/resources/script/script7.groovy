import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();

    def properties = message.getProperties();
    def count = properties.get("countTeams");
    def resultRecords = properties.get("resultRecordsTeams");
    def projectId = properties.get("projectId");
    
    def teamContent = resultRecords[count];
    def projectTeamId = teamContent.id;
    
    def db_schema = properties.get('Database_Schema_Name');
    
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    
    
    def hasUserTeamsToInsert = '0';
    
    if (teamContent.users && teamContent.users.size()>0) {
        sqlStatement.root {
            
            for (user in teamContent.users) {
                hasUserTeamsToInsert = '1';
                
                sqlStatement.SelectStatement {
                    sqlStatement.app_sourcing_project_users(action: 'INSERT') {
                        sqlStatement.table(db_schema + '.APP_SOURCING_PROJECT_USERS')
                        sqlStatement.access {
                            sqlStatement.PROJECT_ID(projectId)
                            sqlStatement.TEAM_ID(projectTeamId)
                            sqlStatement.TEAM_NAME(teamContent.name)
                            sqlStatement.UNIQUE_NAME(user.uniqueName)
                            sqlStatement.NAME(user.name)
                            sqlStatement.EMAIL(user.emailAddress)
                        }
                    }
                }
            }
        };
    }
    
    message.setProperty("hasUserTeamsToInsert", hasUserTeamsToInsert);
    
    //set body
    message.setBody(writer.toString());

    
    return message;
}