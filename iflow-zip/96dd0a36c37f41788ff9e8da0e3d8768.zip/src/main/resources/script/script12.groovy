import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();

    def properties = message.getProperties();

    def db_schema = properties.get('Database_Schema_Name');
    def projectId = properties.get('projectId');
    def projectTeamId = properties.get('projectTeamId');

    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    
    //6 pendingSelection state
    sqlStatement.root {
        sqlStatement.SelectStatement {
            sqlStatement.app_sourcing_project_users(action: 'SELECT') {
                sqlStatement.table(db_schema + '.APP_SOURCING_PROJECT_USERS')
                sqlStatement.access {
                    sqlStatement.PROJECT_ID()
                    sqlStatement.TEAM_ID()
                    sqlStatement.UNIQUE_NAME()
                }
                sqlStatement.key {
                    sqlStatement.PROJECT_ID(projectId)
                    sqlStatement.TEAM_ID(projectTeamId)
                }
            }
        }
    };
    
    message.setBody(writer.toString());
    
    return message;
}