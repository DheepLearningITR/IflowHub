import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody();
    
    def headers = message.getHeaders();

    def properties = message.getProperties();
    
    def userList = new ArrayList<String>();
    
    def jsonSlurper = new JsonSlurper();
    def dbResult = jsonSlurper.parse(body);
    
    if (dbResult && dbResult.SelectStatement_response && 
        dbResult.SelectStatement_response.row && dbResult.SelectStatement_response.row.size() > 0) {
      
       for (r in dbResult.SelectStatement_response.row) {
           userList.add(r.UNIQUE_NAME);
       }
    }
    
    message.setProperty("userListTeamId", userList);
    
    //filter for External Approver APIs
    def count = properties.get("countGroups");
    def resultRecords = properties.get("resultRecordsGroups");
    
    def groupContent = resultRecords[count];
    message.setProperty("userGroupName64", groupContent.uniqueName.bytes.encodeBase64().toString());
    
    return message;
}