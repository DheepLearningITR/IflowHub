import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.keystore.KeystoreService
import java.util.HashMap
import java.io.IOException
import java.util.Map
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream	 
import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.Transformer
import javax.xml.transform.TransformerFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.Source
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import javax.xml.xpath.XPath
import javax.xml.xpath.XPathConstants
import javax.xml.xpath.XPathFactory
import java.security.cert.X509Certificate
import java.security.cert.Certificate
import java.security.*
import org.w3c.dom.Document
import org.w3c.dom.Node
import org.w3c.dom.NodeList
import org.w3c.dom.Element
import org.xml.sax.InputSource
import org.apache.xml.security.c14n.Canonicalizer
import groovy.util.XmlSlurper 
import groovy.xml.XmlUtil
import java.text.NumberFormat

def Message checkVersionRequirement(Message message) {
	def properties = message.getProperties()
    def versionRequirement = properties.get("VERSION_REQUIREMENT")
    if (versionRequirement == null){
		throw new IllegalStateException("Implement latest SAP Notes as described in SAP Note 2852292.")
	} else if (compareVersions("1.3.0",versionRequirement) == -1){
		throw new IllegalStateException("SCPI content for communication with CSSZ needs to be updated to newer version.")
	}
    return message;
}

def Message modifyDefault(Message message)
{
    def messageLog = messageLogFactory.getMessageLog(message)
	def properties = message.getProperties()
	def headers = message.getHeaders()
	Document document = message.getBody(Document.class)
	if (document == null){
		throw new IllegalStateException("Unable to get Body as XML Document")
	}
    removeWhitspace(document)
	def modificator = {
		it.appendChild(it.createComment(UUID.randomUUID().toString()))		
	}
    message.setBody(modifyGovTalkMessage(document, modificator))
    return message
}

def Message modifyDZDPN(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
	def properties = message.getProperties()
	def headers = message.getHeaders()
	def service = ITApiFactory.getApi(KeystoreService.class, null)
	Document document = message.getBody(Document.class)
	if (document == null){
		throw new IllegalStateException("Unable to get Body as XML Document")
	}
    removeWhitspace(document)
    def dzdpn20_cert_alias = properties.get("dzdpn_cert_alias")
    Certificate certificate = service.getCertificate(dzdpn20_cert_alias)
	if (certificate == null){
		throw new IllegalStateException("Can not find certificate with alias: " + dzdpn20_cert_alias)
	}
    def base64Certificate = certificate.getEncoded().encodeBase64().toString()
	def modificator = {
		def xpath = XPathFactory.newInstance().newXPath()
		Node node = (Node)xpath.evaluate("/*[local-name()='DZDPN']/*[local-name()='SifrovaciCertifikat']", it, XPathConstants.NODE)
    	if (node == null){
		    throw new IllegalStateException("Can not find XPATH: /DZDPN/SifrovaciCertifikat")
	    }
		node.setTextContent(base64Certificate)
		it.appendChild(it.createComment(UUID.randomUUID().toString()))		
	}
    message.setBody(modifyGovTalkMessage(document, modificator))
    return message
}

def Message modifyDZNP(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
	def properties = message.getProperties()
	def headers = message.getHeaders()
	def service = ITApiFactory.getApi(KeystoreService.class, null)
	Document document = message.getBody(Document.class)
	if (document == null){
		throw new IllegalStateException("Unable to get Body as XML Document")
	}
    removeWhitspace(document)
    def dzdp25_cert_alias = properties.get("dznp_cert_alias")
    Certificate certificate = service.getCertificate(dzdp25_cert_alias)
	if (certificate == null){
		throw new IllegalStateException("Can not find certificate with alias: " + dzdp25_cert_alias)
	}
    def base64Certificate = certificate.getEncoded().encodeBase64().toString()
	def modificator = {
		def xpath = XPathFactory.newInstance().newXPath()
		Node node = (Node)xpath.evaluate("/*[local-name()='DZNP']/*[local-name()='SifrovaciCertifikat']", it, XPathConstants.NODE)
    	if (node == null){
		    throw new IllegalStateException("Can not find XPATH: /DZNP/SifrovaciCertifikat")
	    }
		node.setTextContent(base64Certificate)
		it.appendChild(it.createComment(UUID.randomUUID().toString()))		
	}
    message.setBody(modifyGovTalkMessage(document, modificator))
    return message
}

def modifyGovTalkMessage(Document document, Closure xmlModificator){
	def xpath = XPathFactory.newInstance().newXPath()
    Element csszBody = (Element)xpath.evaluate("/*[local-name()='BodyPart']/*[local-name()='Body']/*[local-name()='GovTalkMessage']/*[local-name()='Body']/*[local-name()='Message']/*[local-name()='Body']", document, XPathConstants.NODE)
	if (csszBody == null){
	    throw new IllegalStateException("Can not find XPATH: /BodyPart/Body/GovTalkMessage/Body/Message/Body")
    }
	def csszBodyContentEncoding = csszBody.getAttribute("contentEncoding")
	byte[] decodedCsszBody = csszBody.getTextContent().decodeBase64()
	if (csszBodyContentEncoding == 'gzip') {
        decodedCsszBody = ungzip(decodedCsszBody)	    
	}
	Document documentCsszBody = parseXml(decodedCsszBody)
	if (documentCsszBody == null){
	    throw new IllegalStateException("Can not parse CsszBody XML document")
    }
    xmlModificator.call(documentCsszBody)
    decodedCsszBody = printSingleLineXml(documentCsszBody,byte[].class)
	if (csszBodyContentEncoding == 'gzip') {
        decodedCsszBody = gzip(decodedCsszBody)	    
	}
    csszBody.setTextContent(decodedCsszBody.encodeBase64().toString())
    def modTransformer = {
        it.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes") 
	} 	    
    return printSingleLineXml(document,String.class,modTransformer)
}

def Message propagateSoapFault(Message message) {
	try {	
		def map = message.getProperties()
		def ex = map.get("CamelExceptionCaught")
		if (ex!=null) {
			String stringEnvelope = '''<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Header/>'''
			stringEnvelope += '''<soap:Body><soap:Fault><faultcode/><faultstring/><detail/></soap:Fault></soap:Body></soap:Envelope>'''
			def xmlEnvelope = new XmlSlurper().parseText(stringEnvelope)
			xmlEnvelope.Body.Fault.faultstring = ex.getMessage()
			if (ex instanceof org.apache.cxf.interceptor.Fault) {
				String stringDetail = ex.getDetail() as String
				xmlEnvelope.Body.Fault.faultcode = ex.getFaultCode().toString()
				if (stringDetail!=null) {
    				def xmlDetail = new XmlSlurper().parseText(stringDetail)
				    xmlDetail.'*'.each{ node -> xmlEnvelope.Body.Fault.detail.appendNode(node) }
				}
				message.setBody(XmlUtil.serialize(xmlEnvelope))
			} else {
                if (ex.getCause()!=null) {
				    xmlEnvelope.Body.Fault.faultcode = ex.getCause().getClass().getCanonicalName()
                } else {
    				xmlEnvelope.Body.Fault.faultcode = ex.getClass().getCanonicalName()
                }
			}
			message.setBody(XmlUtil.serialize(xmlEnvelope))
		}
	} catch (Exception ex01) {
		String exBody = '''<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Header/>'''
			exBody += '<soap:Body><soap:Fault><faultcode>SCPI_GENERAL</faultcode><faultstring>'
			exBody += XmlUtil.escapeXml(ex01.getMessage())
	        StringWriter ex01Sw = new StringWriter();
            ex01.printStackTrace(new PrintWriter(ex01Sw));
			exBody += XmlUtil.escapeXml(ex01Sw.toString())
			exBody += '</faultstring></soap:Fault></soap:Body></soap:Envelope>'
			message.setBody(exBody)
	}
	return message
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
def compareVersions(String version1, String version2) {
    int comparisonResult = 0;
    String[] version1Splits = version1.split("\\.");
    String[] version2Splits = version2.split("\\.");
    int maxLengthOfVersionSplits = Math.max(version1Splits.length, version2Splits.length);
    for (int i = 0; i < maxLengthOfVersionSplits; i++){
        Integer v1 = i < version1Splits.length ? Integer.parseInt(version1Splits[i]) : 0;
        Integer v2 = i < version2Splits.length ? Integer.parseInt(version2Splits[i]) : 0;
        int compare = v1.compareTo(v2);
        if (compare != 0) {
            comparisonResult = compare;
            break;
        }
    }
    return comparisonResult;
}

def printSingleLineXml(Document document, Class returnType = String.class, Closure modTransformer = null){
    Transformer transformer = TransformerFactory.newInstance().newTransformer()
    transformer.setOutputProperty(OutputKeys.INDENT, "no")
    if(modTransformer!=null){
        modTransformer.call(transformer)    
    }
    switch(returnType) {
        case byte[].class:
            ByteArrayOutputStream bos = new ByteArrayOutputStream()
            transformer.transform(new DOMSource(document), new StreamResult(bos))
            return bos.toByteArray()
            break
        case String.class:
        default:
            StringWriter writer = new StringWriter()
            transformer.transform(new DOMSource(document), new StreamResult(writer))
            return writer.getBuffer().toString()
            break
    }
}

def parseXml(def source){
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance()
    factory.setNamespaceAware(true)
    factory.setValidating(false)
    factory.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true)
    def builder = factory.newDocumentBuilder()
    Document document
    switch(source.class) {
        case byte[].class:
	        document = builder.parse(new ByteArrayInputStream(source))            
            break
        case String.class:
        default:
            document = builder.parse(new InputSource(new StringReader(source)))
            break
    }
    removeWhitspace(document)
    return document
}

def removeWhitspace(Document document){
	def xpath = XPathFactory.newInstance().newXPath()
    NodeList emptyTextNodes = (NodeList)xpath.evaluate("//text()[normalize-space(.) = '']", document, XPathConstants.NODESET)
    for (int i = 0; i < emptyTextNodes.getLength(); i++) {
        Node emptyTextNode = emptyTextNodes.item(i)
        emptyTextNode.getParentNode().removeChild(emptyTextNode)
    }
    document.normalize()
}

def ungzip(byte[] compressed){
    ByteArrayInputStream bis = new ByteArrayInputStream(compressed)
    ByteArrayOutputStream bos = new ByteArrayOutputStream()
    GZIPInputStream gzis = new GZIPInputStream(bis)
    byte[] buffer = new byte[1024]
    int len = 0
    while ((len = gzis.read(buffer)) > 0) {
        bos.write(buffer, 0, len)
    }
    bis.close()
    gzis.close()
    bos.close()
    return bos.toByteArray()
}

def gzip(byte[] compressed){
    ByteArrayOutputStream bos = new ByteArrayOutputStream()
 	GZIPOutputStream gzos = new GZIPOutputStream(bos)
	gzos.write(compressed)
	gzos.close()
	bos.close()
    return bos.toByteArray()
} 