import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import org.json.simple.*
import groovy.json.*
import groovy.xml.MarkupBuilder
import groovy.time.*

def Message processData(Message message) {
    //Get Body 
    def body = message.getBody(String.class)

    //Define JSONSlurper
    def jsonSlurper = new JsonSlurper()
    def list = jsonSlurper.parseText(body)

    def stringWriter = new StringWriter()
    def peopleBuilder = new MarkupBuilder(stringWriter)

    if(list.active == true) {
        
        def currentdate = new Date()
		def utcSeconds = list.exp
		def d = new Date(0) // The 0 there is the key, which sets the date to the epoch
		d.setSeconds(utcSeconds)
		def diff = d.getTime() - currentdate.getTime()
		def diff_as_date = new Date(diff) 
		def hour = diff_as_date.getHours() // hours
		def mins = diff_as_date.getMinutes() // minutes
		def sec = diff_as_date.getSeconds() // seconds	
		 
        peopleBuilder.root {
            active(list.active)
            client_id(list.client_id)
            username(list.username)
            scope(list.scope)
            sub(list.sub)
            exp(list.exp)
            iat(list.iat)
            duration(hour+":"+mins+":"+sec)
        }
    }
    
    if(list.active == false) {
		 
        peopleBuilder.root {
            active(list.active)
        }
    }
    
    def xml = stringWriter.toString()    
     
    message.setBody(xml)
    return message
}
