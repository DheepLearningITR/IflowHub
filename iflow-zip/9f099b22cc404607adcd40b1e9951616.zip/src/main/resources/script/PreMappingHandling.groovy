import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.ITApiFactory;
import groovy.xml.XmlUtil

// process message
def Message processData(Message message) {
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body)
    def textNode = "";
    def service = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    def textTypeRemarks = message.getProperty('ServiceOrderNoteType') ?: 'S002'
    def textTypeResolution = message.getProperty('ServiceOrderProbDescType') ?: 'S001'       
    def language = message.getProperty('ServiceOrderNoteLang') ?: 'EN'
    
    message.setProperty("FSMServiceCall", object.data.code);
    message.setProperty("ServiceCallId", object.data.id);

    List ServiceOrderRefObject    = new ArrayList();
    List ObjectCategory = new ArrayList();
    List isMainObject = new ArrayList();
    
  if (object.data.equipments != null){
        def equipment_node = object.data?.equipments[0]
        def ref_object = equipment_node?.externalId
        def ref_object_category = equipment_node?.objectCategory
		
        if (ref_object) {

                object.data.equipments[0].putAt("IsMainObject", "true")
        }
    } 

	object.data.equipments.each {
		if(it.externalId){
		ServiceOrderRefObject.add(it.externalId)
        
         } 
		 
		 if(it.objectCategory){
		ObjectCategory.add(it.objectCategory)
        
         } 
         if(it.IsMainObject){
		isMainObject.add(it.IsMainObject)
		 }
		else {
        isMainObject.add(null)
        }
			 
	}
	
	int i;
	
   def ReferenceObject = ""
   
   ServiceOrderRefObjectsList = ServiceOrderRefObject.unique();

    for(i=0; i<ServiceOrderRefObjectsList.size(); i++) {
         
         
		 if ((ObjectCategory[i] == null || ObjectCategory[i] == 'EQ') && (isMainObject[i] == 'true')) {
                
              ReferenceObject = """${ReferenceObject}<A_ServiceOrderRefObjectType><ServiceReferenceEquipment>${ServiceOrderRefObjectsList[i]}</ServiceReferenceEquipment><ServiceRefFunctionalLocation></ServiceRefFunctionalLocation><SrvcRefObjIsMainObject>X</SrvcRefObjIsMainObject></A_ServiceOrderRefObjectType>""";
              
		 } else if ((ObjectCategory[i] == null || ObjectCategory[i] == 'FLOC') && (isMainObject[i] == 'true')) {
			  
			  ReferenceObject = """${ReferenceObject}<A_ServiceOrderRefObjectType><ServiceReferenceEquipment></ServiceReferenceEquipment><ServiceRefFunctionalLocation>${ServiceOrderRefObjectsList[i]}</ServiceRefFunctionalLocation><SrvcRefObjIsMainObject>X</SrvcRefObjIsMainObject></A_ServiceOrderRefObjectType>""";
       
          } else if ((ObjectCategory[i] == null || ObjectCategory[i] == 'EQ')) {
			  
			  ReferenceObject = """${ReferenceObject}<A_ServiceOrderRefObjectType><ServiceReferenceEquipment>${ServiceOrderRefObjectsList[i]}</ServiceReferenceEquipment><ServiceRefFunctionalLocation></ServiceRefFunctionalLocation><SrvcRefObjIsMainObject></SrvcRefObjIsMainObject></A_ServiceOrderRefObjectType>""";
			  
			  } else if (ObjectCategory[i] == null || ObjectCategory[i] == 'FLOC') {
				  
                ReferenceObject = """${ReferenceObject}<A_ServiceOrderRefObjectType><ServiceReferenceEquipment></ServiceReferenceEquipment><ServiceRefFunctionalLocation>${ServiceOrderRefObjectsList[i]}</ServiceRefFunctionalLocation><SrvcRefObjIsMainObject></SrvcRefObjIsMainObject></A_ServiceOrderRefObjectType>""";
            }
        }
    
     def ReferenceObjects = "<to_ReferenceObject>$ReferenceObject</to_ReferenceObject>";
     
	 
    message.setProperty("ReferenceObjects", ReferenceObjects);

    if (object.data.earliestStartDateTime != null){
        message.setProperty("RequestedStartDate", object.data.earliestStartDateTime);
    }

    if (object.data.dueDateTime != null){
        message.setProperty("RequestedEndDate", object.data.dueDateTime);
    }
    
    if (object.data.subject != null) {
        message.setProperty("Description", groovy.xml.XmlUtil.escapeXml(object.data.subject.take(40)));
    }
    
    if (object.data.businessPartner && object.data.businessPartner.externalId != null) {
        message.setProperty("SoldToParty", object.data.businessPartner.externalId);
    }
    
    if (object.data.responsibles != [] && object.data.responsibles != null) {
        message.setProperty("PersonResponsible", object.data.responsibles[0].externalId);
    }
    
    if (object.data.contact && object.data.contact.externalId != null) {
        message.setProperty("ContactPerson", object.data.contact.externalId);
    }
    
    if (object.data.priority != null) {
        def prioMapped = service.getMappedValue("ServiceCall", "Priority", object.data.priority, "ServiceOrder", "ServiceDocumentPriority") ?: "";
        message.setProperty("Priority", prioMapped);
    }
    
    if (object.data.remarks != null || object.data.resolution != null) {
        remarks = object.data.remarks ?: "";
        resolution = object.data.resolution ?: "";
    
        //* Build Payload for Text Node 
        if (remarks != "" && textTypeRemarks != null && language != null) {
            textNode = textNode + '''<A_ServiceOrderTextType>'''
            textNode = textNode + '''<ServiceOrder></ServiceOrder>'''
            textNode = textNode + '''<Language>'''     + language  + '''</Language>'''
            textNode = textNode + '''<LongTextID>'''   + textTypeRemarks + '''</LongTextID>'''
            textNode = textNode + '''<LongText>'''     + groovy.xml.XmlUtil.escapeXml(remarks) + '''</LongText>'''
            textNode = textNode + '''</A_ServiceOrderTextType>'''        
        }
        
        if (resolution != "" && textTypeResolution != null && language != null) {
            textNode = textNode + '''<A_ServiceOrderTextType>'''
            textNode = textNode + '''<ServiceOrder></ServiceOrder>'''
            textNode = textNode + '''<Language>'''     + language  + '''</Language>'''
            textNode = textNode + '''<LongTextID>'''   + textTypeResolution + '''</LongTextID>'''
            textNode = textNode + '''<LongText>'''     + groovy.xml.XmlUtil.escapeXml(resolution) + '''</LongText>'''
            textNode = textNode + '''</A_ServiceOrderTextType>'''        
        }
    
        message.setProperty("TextNode", textNode);
    }
    
    return message;
}
