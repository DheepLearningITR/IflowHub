import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;

def Message parseHeaders(Message message) {

	def map = message.getHeaders();

    def getTexts = map.get("getTexts");
	message.setProperty("getTexts", getTexts);
	
	//used to default hashmap global variables
	def emptyHmap = new HashMap<String, String>();
	emptyHmap.put('null','');
	message.setProperty("emptyHmap", emptyHmap);
	
	return message;
}

def Message build_hmapTagTexts(Message message) {
	
	def body = message.getBody(java.io.Reader);
	HashMap<String, String> hmapTexts = new HashMap<String, String>();

	def Root = new XmlSlurper().parse(body);
    Root.data.each{
        String name = '';
        name = it.locale.toString()+'-'+it.tagValue.toString().trim().toLowerCase();
	    hmapTexts.put(name,it.externalId.toString()); 
    }
	message.setProperty("hmap_sfsfTagTexts", hmapTexts);

	return message;
}

def Message build_hmapTags(Message message) {
	
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
    def sfsfAttributeTag = map.get("sfsfAttributeTag"); //optional

	HashMap<String, String> hmapTags = new HashMap<String, String>();

    def sfsfTagFound = 'false';
	def Root = new XmlSlurper().parse(body);
	Root.data.each{
        if(it.externalId.toString().startsWith('cbr_') || it.externalId.toString()==sfsfAttributeTag){
            //Cobrainer, add to hmap
            hmapTags.put(it.externalId.toString(),'');
            sfsfTagFound = 'true';	            
        }else{
            it.replaceNode{};  //remove in payload, not Cobrainer
        }
	}
    message.setBody(XmlUtil.serialize(Root));
    
    message.setProperty("sfsfTagFound", sfsfTagFound); 
	message.setProperty("hmap_sfsfTags", hmapTags );           

	return message;
}
