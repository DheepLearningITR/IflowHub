import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def sfsfAttributeTag = message.getProperties().get("sfsfAttributeTag");
		if(sfsfAttributeTag!=null){
			messageLog.addCustomHeaderProperty("sfsf_AttributeTag", sfsfAttributeTag);		
        }
        def sfsfAttributeType = message.getProperties().get("sfsfAttributeType");
		if(sfsfAttributeType!=null){
			messageLog.addCustomHeaderProperty("sfsf_AttributeType", sfsfAttributeType);		
        }        
	}
	return message;
}

