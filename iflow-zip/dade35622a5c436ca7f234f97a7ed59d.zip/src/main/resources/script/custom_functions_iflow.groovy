import com.sap.gateway.ip.core.customdev.util.Message;

import java.util.HashMap;
import java.io.*;
import java.nio.*;
import java.util.*;

import groovy.util.*;
import groovy.xml.*;
import groovy.json.*;

import org.apache.camel.CamelContext;
import org.apache.commons.io.IOUtils;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.conn.params.ConnRoutePNames;



def Message setDOCXStatusInProperty(Message message) {
	def String payload = message.getBody(java.lang.String)
	message.setProperty("DOXResponse", payload)
	def json = new JsonSlurper().parseText(payload)
	def DOCXServiceCallStatus = json.status
	message.setProperty("DOCXServiceCallStatus", DOCXServiceCallStatus)
	return message;
}

def Message processTokenResponse(Message message) {
    
    def body = message.getBody(String.class);    
    def jsonSlurper = new JsonSlurper()
    def responsePayload = jsonSlurper.parseText(body)
    def token = responsePayload.access_token;
    def tokenWithType = "Bearer " + token;
    message.setProperty("Authorization", tokenWithType);
    message.setHeader("Authorization", tokenWithType);
    return message;
}

def Message processExtractionFieldsResponse(Message message){
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def response = jsonSlurper.parseText(body);
    //get document Type
    def sDocumentType = message.getProperty("documentType")
	//get HeaderFields
	def aHeaderFields = response.extraction?.headerFields;
	def aSupportedHeaderFields = new ArrayList();
	if (aHeaderFields) {
		aSupportedHeaderFields = aHeaderFields.findAll{
		it.supportedDocumentTypes.findAll{it == sDocumentType}.size()>0}.collect{it.name};
	}
	//get LineItemFields
	def aLineItemFields = response.extraction?.lineItemFields;
	def aSupportedLineItemFields = new ArrayList();
	if (aLineItemFields) {
		aSupportedLineItemFields = aLineItemFields.findAll{
		it.supportedDocumentTypes.findAll{it == sDocumentType}.size()>0}.collect{it.name};
	}

	def headerFields = JsonOutput.toJson(aSupportedHeaderFields);
	def lineItemFields =JsonOutput.toJson(aSupportedLineItemFields);
	def enrichment = JsonOutput.toJson(response.enrichment);
	message.setProperty('headerFields',headerFields);
	message.setProperty('lineItemFields',lineItemFields);
	message.setProperty('enrichment',enrichment);
	return message;
}

def Message processGet(Message message) {
    //Waiting 3 second
    Thread.sleep(3000);
        
    HttpClient client = new DefaultHttpClient();
    
    //get Job ID
	String DOX_Job_ID =  message.getHeaders().get('DOX_Job_ID');
	
	//build URL
	def String baseURL = message.getProperty("DOX_Service_URL");
	def String clientId = message.getProperty("Client_ID");
	String url = baseURL + "/document/jobs/" + DOX_Job_ID + '?clientId=' +clientId;
    HttpGet request = new HttpGet(url);

    //set token    
    String DOCXOAuthToken = message.getProperties().get('Authorization');
    request.setHeader("Authorization", DOCXOAuthToken);
    



    //def messageLog = messageLogFactory.getMessageLog(message);
	//messageLog.addAttachmentAsString("DOX GET URL", url, "text/xml");
    
    //execute request
    HttpResponse response = client.execute(request);
    // Get the response
    BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
    StringBuffer sb = new StringBuffer();
    String line = "";
    while ((line = rd.readLine()) != null) {
            sb.append(line);
    }
    int statusCode = response.getStatusLine().getStatusCode();
    String statusText = response.getStatusLine().getReasonPhrase();
    message.setHeader('HTTP_STATUS_CODE', statusCode);
    message.setHeader('HTTP_STATUS_TEXT', statusText);
    message.setBody(sb.toString());
    return message;
}

def Message prepareResultsForMail(Message message){
    def body = message.getBody(String.class);    
	def jsonSlurper = new JsonSlurper();		
	def response = jsonSlurper.parseText(body);

	//get HeaderFields
	def aHeaderFields = response.extraction?.headerFields;
	def sHeaderFieldsHTML = "";
	if (aHeaderFields) {
		aHeaderFields.each{sHeaderFieldsHTML+='<tr>'+'<td>'+ it.name +'</td>'+'<td>'+ it.value+'</td>'+'<td>'+Math.round(it.confidence * 1000)/1000 + '</td>'+'</tr>'};
	}
	
	//get LineItemFields
	def aLineItemFields = response.extraction?.lineItems;
	def sLineItemFieldsHTML = "";
	if (aLineItemFields) {
		aLineItemFields.eachWithIndex{oItem,index-> sLineItemFieldsHTML+="<tr><td>Item "+(index+1)+"<td></tr>"; oItem.each{sLineItemFieldsHTML+='<tr>'+'<td>'+ it.name +'</td>'+'<td>'+ it.value+'</td>'+'<td>'+Math.round(it.confidence * 1000)/1000 + '</td>'+'</tr>'}}
		
	}
	message.setProperty("headerFieldsHTML",sHeaderFieldsHTML);
	message.setProperty("lineItemsHTML",sLineItemFieldsHTML);
    return message;
}


