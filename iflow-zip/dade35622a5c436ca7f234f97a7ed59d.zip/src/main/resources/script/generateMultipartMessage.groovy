import com.sap.gateway.ip.core.customdev.util.Message
import javax.activation.DataHandler
import javax.mail.internet.ContentType
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMultipart
import javax.mail.util.ByteArrayDataSource

class MimeMultipartPatched extends MimeMultipart {
	MimeMultipartPatched() {
    contentType = contentType.replace("----=_Part_", "----__Part_");
	}
}


Message processIMGData(Message message) {
    String fileName =  message.getProperty("attachment_fileName");
    String contentType =  message.getProperty("attachment_type");
    byte[] bytes = message.getProperty("attachment_body");
    
    //  Construct Multipart
    MimeMultipart multipart = new MimeMultipartPatched()
    
    // Set file bodypart
    MimeBodyPart bodyPart = new MimeBodyPart()
    ByteArrayDataSource dataSource = new ByteArrayDataSource(bytes, contentType)
    DataHandler byteDataHandler = new DataHandler(dataSource)
    bodyPart.setDataHandler(byteDataHandler)
    bodyPart.setFileName(fileName)
    bodyPart.setDisposition('form-data; name="file"')
    bodyPart.setHeader("Content-Type",contentType)
    
    // Set options bodypart
    MimeBodyPart bodyPartOptions = new MimeBodyPart()
   	def String clientId = message.getProperty("Client_ID");
   	def documentType =  message.getProperty("documentType");
   	def headerFields = message.getProperty("headerFields");
   	def lineItemFields = message.getProperty("lineItemFields");
   	def enrichment = message.getProperty("enrichment");
    bodyPartOptions.setDisposition('form-data; name="options"')
    bodyPartOptions.setText("{\r\n" + 
			'    "extraction\": {\r\n' + 
			'        "headerFields": '+headerFields+',\r\n'+
			'        "lineItemFields": '+ lineItemFields+
			'    },\r\n' + 
			'    "clientId": "'+clientId+'",\r\n' + 
			'    "documentType": "'+documentType+'",\r\n' + 
			"    \"enrichment\": {\r\n" + 
			"        \"sender\": {\r\n" + 
			"            \"top\": 5,\r\n" + 
			"            \"type\": \"businessEntity\",\r\n" + 
			"            \"subtype\": \"supplier\"\r\n" + 
			"        },\r\n" + 
			"        \"employee\": {\r\n" + 
			"            \"type\": \"employee\"\r\n" + 
			"        }\r\n" + 
			"    }\r\n" + 
			'}')

    // Add bodyparts to multipart
    multipart.addBodyPart(bodyPartOptions)
    multipart.addBodyPart(bodyPart)
    
    // Set multipart into body
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream()
    multipart.writeTo(outputStream)
    //bodyPartOptions.writeTo(outputStream)
    message.setProperty("attachment_body",outputStream);

    // Set Content type with boundary
    String boundary = (new ContentType(multipart.contentType)).getParameter('boundary');
    message.setProperty("attachment_header","multipart/form-data; boundary=${boundary}");

    return message
}