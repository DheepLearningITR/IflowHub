import com.sap.it.api.mapping.*;

def String getProductCategoryUse(String name, MappingContext context){
	String value = context.getProperty(name);
	String objVal;
    
    if(value.equalsIgnoreCase("Yes")){
        objVal="true";
    }
    else{
        objVal="false";
    }
    
	return objVal; 
}
