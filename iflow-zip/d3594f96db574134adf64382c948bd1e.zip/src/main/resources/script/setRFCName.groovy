import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.*;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String) as String;
       
       map = message.getProperties();
       value = map.get("rfcName");
       
       body = body.replace("RFCNAME", value)
       message.setBody(body);
       
       return message;
}