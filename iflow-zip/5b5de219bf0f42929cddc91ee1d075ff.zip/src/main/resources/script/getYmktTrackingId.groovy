import com.sap.it.api.mapping.*;

//Read externalizable parameter value by passing the externalizable parameter key and mapping context
def String getExchangeProperty(String propertyName, MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}


