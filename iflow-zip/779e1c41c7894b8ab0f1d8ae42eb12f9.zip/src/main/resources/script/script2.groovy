import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def currentIndex = message.getProperty('CURRENT_INDEX')
    def workflowInstanceIdsProp = message.getProperty('WORKFLOW_INSTANCE_IDS')
    
    def jsonSlurper = new JsonSlurper()
    def workflowInstanceIds = jsonSlurper.parseText(workflowInstanceIdsProp);
    
    if (currentIndex < workflowInstanceIds.size()) {
        def workflowInstanceId = workflowInstanceIds.get(currentIndex)
        def event = [ 'status': 'SUSPENDED' ];
        
        message.setBody(JsonOutput.toJson(event));
        message.setProperty('workflowInstanceId', workflowInstanceId);
        message.setProperty('httpOperation', 'PATCH');
        message.setHeader('Content-Type', 'application/json')
        
        currentIndex++
        if (currentIndex == workflowInstanceIds.size()) {
            message.setProperty('EXECUTE_LOOP', 'false')
        }
        message.setProperty('CURRENT_INDEX', currentIndex)
        
        def enablePayloadLogging = message.getProperty('ENABLE_PAYLOAD_LOGGING');
        if ("true".equalsIgnoreCase(enablePayloadLogging)) {
            def messageLog = messageLogFactory.getMessageLog(message)
            if (messageLog != null)	{
    	        def log = [ 'httpOperation': message.getProperty('httpOperation'), 'workflowInstanceId': workflowInstanceId, 'event': event ]
    		    messageLog.addAttachmentAsString('Suspend event ' + currentIndex, JsonOutput.toJson(log), "application/json")
            }
        }
    }
    return message;
}