import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import javax.xml.bind.DatatypeConverter;

def Message processData(Message message) {

  /* Remove xml tag if exist  */
  def messageLog = messageLogFactory.getMessageLog(message);
  messageLog.setStringProperty("Info1", "Remove xml tag if exist..");
  String payload = message.getBody(java.lang.String)
  def map = message.getProperties();
  
   if(map.BPPayload.contains("?xml")){
	messageLog.setStringProperty("Info1", "Removing xml tag..");
	int i = map.BPPayload.indexOf('>');
	map.BPPayload = map.BPPayload.substring(i+1);
  }
  if(payload.contains("?xml")){
	messageLog.setStringProperty("Info1", "Removing xml tag..");
	int i = payload.indexOf('>');
	payload = payload.substring(i+1);
	message.setBody(payload);
  }
  
  return message;
}