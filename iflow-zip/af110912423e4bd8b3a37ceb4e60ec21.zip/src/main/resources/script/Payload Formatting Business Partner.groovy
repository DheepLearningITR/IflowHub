import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    def jsonParser = new JsonSlurper();
    if (!body.startsWith("["))
    {
       body = "[" + body  + "]";
    }
    def jsonObject = jsonParser.parseText(body);
    message.setBody(JsonOutput.toJson(jsonObject["BP"])); 
    message.setProperty("RequestPayload", JsonOutput.toJson(jsonObject["BP"]));
    return message;
    
}