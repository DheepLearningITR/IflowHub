/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
		// Get the OAuth token value from the properties
		def map = message.getProperties();
		//def clientid = map.get("Client_ID");
		//def secret = map.get("Client_Secret");
		//def key = clientid + ":" + secret; 
		//String token = key.bytes.encodeBase64().toString()
		
		map = message.getHeaders();
		map.remove("X-ConsumerKey");
		
		message.setHeader("Authorization", "Basic " + 'U0FQX1BheXJvbGw6RGgxQjBOeURwTzE=');
		//U0FQX1BheXJvbGw6RGgxQjBOeURwTzE=
		return message;

}
