import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.json.simple.*
import groovy.json.*
import groovy.xml.MarkupBuilder
import groovy.time.*

def Message processData(Message message) {
    //Get Body 
    def body = message.getBody(String.class);

    //Define JSONSlurper
    def jsonSlurper = new JsonSlurper()
    def list = jsonSlurper.parseText(body)

    def stringWriter = new StringWriter()
        def peopleBuilder = new MarkupBuilder(stringWriter)

	
		 
        peopleBuilder.root {
            	successful(list.successful)
                 error(list.error)
                error_description(list.error_description)
        }
        def xml = stringWriter.toString()    
     
    message.setBody(xml);
    return message;
}
