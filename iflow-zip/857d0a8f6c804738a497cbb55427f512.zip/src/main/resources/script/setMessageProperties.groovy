import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Body 
    def inputString = message.getProperty("InputJSONPayload");
    def jsonSlurper = new JsonSlurper()
    def dataObject = jsonSlurper.parseText(inputString);

    def targetDocumentCategoryCode = dataObject.complaintHeader.targetDocumentCategoryCode;   
    message.setProperty("targetDocumentCategoryCode", targetDocumentCategoryCode);

    def salesOrganization = dataObject.complaintHeader.salesOrganization;   
    message.setProperty("salesOrganisation", salesOrganization);

    def complaintIdentifier = dataObject.complaintHeader.complaintIdentifier;   
    message.setProperty("complaintIdentifier", complaintIdentifier);

    def complaintUUID = dataObject.complaintHeader.complaintUUID;   
    message.setProperty("complaintUUID", complaintUUID);

    def objectPageUrl = dataObject.complaintHeader.objectPageUrl;   
    message.setProperty("objectPageUrl", objectPageUrl);

    message.setBody(inputString);
    return message;
}