import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput 

def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String);
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body.toString());
    
    def root = object.get("multimap:Messages").get("multimap:Message1").root;
    def defaultRuleResult = root[0];
    def customRuleResult = root[1];
    def response = defaultRuleResult;
    def allValidations;
    try{
        if(defaultRuleResult.Result.outputResultList == "" && customRuleResult.Result.outputResultList == ""){
        allValidations = [];
    }
    else if(defaultRuleResult.Result.outputResultList == ""){
        allValidations = customRuleResult.Result.outputResultList;
    }else if(customRuleResult.Result.outputResultList == ""){
        allValidations = defaultRuleResult.Result.outputResultList;
    }else{
        if(!(defaultRuleResult.Result.outputResultList instanceof List)){
            defaultRuleResult.Result.outputResultList = [defaultRuleResult.Result.outputResultList];
        }
        if(!(customRuleResult.Result.outputResultList instanceof List)){
            customRuleResult.Result.outputResultList = [customRuleResult.Result.outputResultList];
        }
        allValidations = defaultRuleResult.Result.outputResultList + customRuleResult.Result.outputResultList;
    }
    
    response.Result.outputResultList = allValidations;
    
    if(!(response.Result instanceof List)){
        response.Result = [response.Result];
    }
    
    if(!(response.Result[0].outputResultList instanceof List)){
        response.Result[0].outputResultList = [response.Result[0].outputResultList];
    }
    
    message.setProperty("result",JsonOutput.toJson([response]));
    message.setProperty("errorMessage", "");
    message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
    
    }catch(Exception e){
        def map  = message.getProperties();
         def ex   = map.get("CamelExceptionCaught");
		 if (ex != null)
		 {
            def exceptionText    = ex.getMessage();
            message.setProperty("result", []);
            message.setProperty("errorMessage", exceptionText);
            message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
		 } else {
			message.setProperty("result", []);
            message.setProperty("errorMessage", "Exception Occurred");
		 }
    }
    
    return message;
    
    
}