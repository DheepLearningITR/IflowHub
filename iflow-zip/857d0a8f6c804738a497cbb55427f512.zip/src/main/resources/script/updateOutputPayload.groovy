import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def payload = message.getBody(java.lang.String);
    
    def inputJson= payload.replace("\"\"","null");
    def jsonSlurper = new JsonSlurper()
	
	def modifiedInputJson  = jsonSlurper.parseText(inputJson);
	
    def headerFieldsToInt = ['price'];
    headerFieldsToInt.each { f -> modifiedInputJson.complaintHeader[f] = 
    modifiedInputJson.complaintHeader[f] != null ? modifiedInputJson.complaintHeader[f].toFloat(): null; }  

    def itemFieldsToInt = ['quantity','price'];
    itemFieldsToInt.each { f -> modifiedInputJson.complaintItems.each { item -> item[f] =
            item[f] != null ? item[f].toFloat(): null;
        }
    } 
    def headerPrice = [
        price: modifiedInputJson.complaintHeader.price,
        currency: modifiedInputJson.complaintHeader.currency
    ];
    
    def itemsPriceList = [];
    modifiedInputJson.complaintItems.each { item ->
        def itemPriceInfo = [
            itemNumber: item.itemNumber,
            price: item.price,
            currency: item.currency
        ]
        itemsPriceList << itemPriceInfo;
    }
    message.setProperty("itemsPrice", JsonOutput.toJson(itemsPriceList));
    message.setProperty("headerPrice",JsonOutput.toJson(headerPrice));
    message.setBody(JsonOutput.toJson(modifiedInputJson)); 
	
    return message;
}


