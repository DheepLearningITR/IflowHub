/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
def Message processData(Message message) {

       def target = "<getUBLResponse xmlns=\"http:/fitcons.com/eInvoice/\"> </getUBLResponse>";
       def docdata = "<DocData xmlns=\"http:/fitcons.com/eInvoice/\">  </DocData>";
       def attach = "<n0:Attachements xmlns:n0=\"http:/fitcons.com/eInvoice/\"> <n0:Name > </n0:Name> <n0:Value> </n0:Value> </n0:Attachements>";
       
       def targetXML = new XmlSlurper().parseText(target);
       def docdataXML = new XmlSlurper().parseText(docdata);
       def attachXML = new XmlSlurper().parseText(attach);
       
       def source = message.getBody(java.lang.String) as String;
       def root = new XmlSlurper().parseText(source);
       
       for( def ubldoc: root.getUBLDocument)
       {
           docdataXML = new XmlSlurper().parseText(docdata);
           docdataXML.replaceBody(ubldoc.DocData.text())
           targetXML.appendNode( docdataXML );

       }

       for( def ubldoc: root.getUBLDocument)
       {
        attachXML = new XmlSlurper().parseText(attach);
           attachXML.Name.replaceBody('UUID');
           attachXML.Value.replaceBody(ubldoc.UUID.text());
           targetXML.appendNode( attachXML );
       }
       
       String outxml = groovy.xml.XmlUtil.serialize( targetXML );
       outxml.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
       message.setBody(outxml);

       return message;
}