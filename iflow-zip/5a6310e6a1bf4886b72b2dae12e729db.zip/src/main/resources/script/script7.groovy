/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def source = message.getBody(java.lang.String) as String;
       def root = new XmlSlurper().parseText(source);
       for ( def ubllist : root.UBLList ){
           String dateTime = ubllist.InsertDateTime.text();
           String date = dateTime.substring(0,10);
           date = date.replaceAll(':','-');
           dateTime = dateTime.substring(0,dateTime.length() - 1);
           String time = dateTime.substring(10,dateTime.length() - 6);
           time = time + "000";
           String zone = dateTime.substring(dateTime.length() - 6,dateTime.length());
           // time = time.replaceAll('.',zero);
           String date_time = date + time + zone;
           //dateTime = dateTime - "Z";
           ubllist.InsertDateTime.replaceBody( date_time );
       }
       String outxml = groovy.xml.XmlUtil.serialize( root );
       message.setBody( outxml );
       return message;
}