import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.*;
import groovy.json.JsonBuilder;
import groovy.lang.*;

def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String);
       def jsonSlurper = new JsonSlurper()
       def object = jsonSlurper.parseText(body.toString());
	   def bostatuses=object.businessObjectStatuses;
	   def list=[];
	   def payload;
	   def returnPurchaseOrderNumber=object.returnPurchaseOrderNumber;
	   def isAsynchronousRequest = object.isAsynchronousRequest;
	     if(null!=isAsynchronousRequest){
           isAsynchronousRequest = isAsynchronousRequest.toLowerCase().toBoolean();
       }
	   def json = new JsonBuilder();
	   if (bostatuses instanceof ArrayList) {
		       payload= json returnPurchaseOrderNumber:returnPurchaseOrderNumber, businessObjectStatuses:bostatuses, isAsynchronousRequest:isAsynchronousRequest
       }else{
        list.add(bostatuses);
        payload= json returnPurchaseOrderNumber:returnPurchaseOrderNumber, businessObjectStatuses:list, isAsynchronousRequest:isAsynchronousRequest
       }
		
      message.setBody(groovy.json.JsonOutput.toJson(payload));
      message.setProperty("payload",groovy.json.JsonOutput.toJson(payload));
      return message;
}