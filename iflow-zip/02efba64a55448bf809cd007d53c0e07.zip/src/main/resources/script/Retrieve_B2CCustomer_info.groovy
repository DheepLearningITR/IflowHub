import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import javax.xml.xpath.*
import javax.xml.parsers.DocumentBuilderFactory

// set customerId, uid, email, groups, language (BP_PAYLOAD) as properties for B2BCustomer mapping and phone1, fax, cellPhone for Contact Person Address mapping
def Message processData(Message message) {
    	
	def messageLog = messageLogFactory.getMessageLog(message);
	def body = message.getBody(java.lang.String) as String;
	def properties = message.getProperties() as Map<String, Object>;
	def messageRequest=properties.get("bpRequest");
    
    // Contact Person Address mapping
    // set telephone number and cellphone number as properties
    
//     def logStep="Splitter";
//     if(messageLog != null && properties.get("enableLog") == "true"){
// 	messageLog.addAttachmentAsString(logStep, "\n messageRequest \n ----------   \n"  + body,
// 		                                                   "text/xml");
// 	}
    
    def root = new XmlSlurper().parseText(body);
    
    def phoneNumList = root.BusinessPartnerSUITEReconciliationConfirmation.BusinessPartnerSUITEBulkReplicateRequest.BusinessPartnerSUITEReplicateRequestMessage.BusinessPartner.AddressInformation.Address.Telephone.collect{ it.MobilePhoneNumberIndicator.text()  + "|" + it.Number.SubscriberID.text() };
    
    message.setProperty("PhoneNumList", phoneNumList.join(","));
    
   return message;
}    