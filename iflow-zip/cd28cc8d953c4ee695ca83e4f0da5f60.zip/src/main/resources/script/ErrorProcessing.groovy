import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;

def Message ProcessError(Message message) {
    def map = message.getProperties();
    def messageLog = messageLogFactory.getMessageLog(message);
    def errorMessage = map.get("ErrorMessage");
    
    Date date = new Date();
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
    // get an exception java class instance
    def ex = map.get("CamelExceptionCaught");
    if(ex!=null && ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
        errorMessage = ex.getResponseBody();
        
        def title = "Error Message " + sdf.format(date); 
        
        messageLog.addAttachmentAsString(title, errorMessage, "text/plain");
        messageLog.setStringProperty("LogInfo#error", errorMessage);
        
        message.setProperty("ErrorMessage", errorMessage);
    }
    
    return message;
}