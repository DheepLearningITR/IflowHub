import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(String)
    def map = message.getProperties()
    // Replace "Timestamp: "
    body = body.replaceAll(/Timestamp: .*/, "Timestamp: " + map.get("Timestamp"))
    message.setBody(body)
    return message
}
