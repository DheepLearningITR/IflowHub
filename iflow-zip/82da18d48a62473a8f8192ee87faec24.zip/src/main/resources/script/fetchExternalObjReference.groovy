import com.sap.it.api.mapping.*;


def String fetchExternalObjRefernce(String p1,MappingContext context){
   
	return  context.getProperty(p1);

}