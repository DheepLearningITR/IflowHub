import com.sap.it.api.mapping.*;



def String fetchPaymentType(String p1, MappingContext context) {
         
         
         if(context.getProperty(p1).equals("Invoice"))
         {
             return context.getProperty(p1);
         }
         else
         {
         return context.getProperty("paymentMethod");
         }
        
}




