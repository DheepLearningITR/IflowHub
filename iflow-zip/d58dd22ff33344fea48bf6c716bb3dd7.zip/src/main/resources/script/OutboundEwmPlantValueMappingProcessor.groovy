import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.mapping.ValueMappingApi;
import java.util.HashMap;
import groovy.transform.Field;
import groovy.util.slurpersupport.GPathResult;
import groovy.xml.XmlUtil;

@Field static final String PROPERTY_ENDPOINT_ID = "ENDPOINT_ID";
@Field static final String HEADER_VM_MODE = "VM_MODE";
@Field static final String VM_MODE_REQUEST = "REQUEST";
@Field static final String VM_MODE_RESPONSE = "RESPONSE";
@Field static final String PD_PARAMETER_ENABLE_PLANT_CONVERSION = "ENABLE_PLANT_CONVERSION";
@Field static final String PARTNER_ID_PREFIX = "DME_Generic_Processing_";
@Field static final String VM_AGENCY_EWM = "EWM"; 								//Agency of EWM
@Field static final String VM_IDENTIFIER_EWM_PLANT = "PLANT"; 					//Identifier of EWM
@Field static final String VM_AGENCY_DMC = "DMC"; 								//Agency of DMC
@Field static final String VM_IDENTIFIER_DMC_PLANTS = "PLANT"; 					//Identifier of DMC
@Field static final Map FIELDS_CONFIGURATION = [
	ewmStagingRequest: ["plant"],
	ewmGoodsIssueRequest: ["Plant"], 
	ewmGoodsReceiptRequest: ["Plant"],
	ewmReadStockRequest: ["plant"],
	singleOrderStagingConfirmationResponse: ["plant"],
	ewmSingleOrderStagingRequest: ["plant"],
	wipStorageRequest: ["plant"],
	wipStagingRequest: ["plant"],
	wipGoodsIssueRequest: ["plant"]
];
//@Field static final String[] SOAP_LOGICAL_SYS_FIELDS = ['ERPLogicalSystem', 'ewmDestination', 'ewmProgramId', 'erpLogicalSystem'];
@Field static final String EWM_DESTINATION = "EwmDestination";

/**
 * Outbound DMC plant unique -> EWM:PLANT -> fetch PLANT/ duplicate DMC plant -> fetch first one
 */

Message processData(Message message) {
	
	String endpointId = message.getProperty(PROPERTY_ENDPOINT_ID);
	String partnerId = PARTNER_ID_PREFIX + endpointId;
	
	PartnerDirectoryService pd = ITApiFactory.getService(PartnerDirectoryService.class, null);
	if (pd == null){
		throw new IllegalStateException("Partner Directory Service not found");
	  }
	boolean enablePlantConversion = toBoolean(pd.getParameter(PD_PARAMETER_ENABLE_PLANT_CONVERSION, partnerId, String.class));  
	if (enablePlantConversion) {
		executePlantConversion(message);
	}
	
	return message;
}

private void executePlantConversion(Message message) {
	
	Reader payload = message.getBody(java.io.Reader);
	GPathResult root = new XmlSlurper().parse(payload);
	String entity = root.name();
	String[] fields = FIELDS_CONFIGURATION[entity];
	
	String vmSourceAgency;
	String vmSourceIdentifier;
	String vmTargetAgency;
	String vmTargetIdentifier;
	String prefix;
	String mode = message.getHeaders().get(HEADER_VM_MODE);
	if (mode.equals(VM_MODE_REQUEST)) {				   	    //OData service request: source system is DMC; target system is EWM
		vmSourceAgency = VM_AGENCY_DMC;
		vmSourceIdentifier = VM_IDENTIFIER_DMC_PLANTS;
		vmTargetAgency = VM_AGENCY_EWM;
		vmTargetIdentifier = VM_IDENTIFIER_EWM_PLANT;
	} else {												//OData service response: Source system is EWM; target system is DMC
		vmSourceAgency = VM_AGENCY_EWM;
		vmSourceIdentifier = VM_IDENTIFIER_EWM_PLANT;
		vmTargetAgency = VM_AGENCY_DMC;
		vmTargetIdentifier = VM_IDENTIFIER_DMC_PLANTS;

		prefix = message.getHeaders().get(EWM_DESTINATION);
		if (!prefix) {
			prefix = message.getHeaders().get(EWM_DESTINATION.toLowerCase());
		}

//		SOAP_LOGICAL_SYS_FIELDS.each { String tag ->
//			List<GPathResult> searchResult = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase(tag) && it.children().size() == 0 && it.text() != null && it.text() != ""; }
//			if (!searchResult.isEmpty()) {
//				prefix = searchResult[0];
//			}
//		}
	}
	
	ValueMappingApi vm = ITApiFactory.getService(ValueMappingApi.class, null);
	
	fields.each { String tag ->
		List<GPathResult> searchResult = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase(tag) && it.children().size() == 0; }
		if (!searchResult.isEmpty()) {
			searchResult.each { GPathResult it ->
				String plantSourceValue = it.text();
				
				String plantTargetValue = vm.getMappedValue(vmSourceAgency,vmSourceIdentifier, prefix + ":" + plantSourceValue, vmTargetAgency, vmTargetIdentifier);
				
				if (!plantTargetValue) {
					plantTargetValue = vm.getMappedValue(vmSourceAgency,vmSourceIdentifier, plantSourceValue, vmTargetAgency, vmTargetIdentifier);
				}
				
				if (plantTargetValue) {
					try{
						plantTargetValue = plantTargetValue.split(":")[1];
					}catch(java.lang.ArrayIndexOutOfBoundsException ex){
						//log.error("Can't split the plant value ", plantTargetValue);
					}
					it.replaceBody(plantTargetValue);
				}
			}
		}
	}
	
	message.setBody(XmlUtil.serialize(root));
}

private boolean toBoolean(String value) {
	
	if (value != null) {
		if ("TRUE".equalsIgnoreCase(value)) {
			return true;
		} 
	}
	return false;
}