import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Retrieve values from message properties
    def personIdExternal = message.getProperty("person_id_external")?.trim()
    def companyTerritoryCode = message.getProperty("company_territory_code")
    def emplStatus = message.getProperty("emplStatus")

    // Define valid values
    def validTerritoryCodes = ["USA", "CAN", "PRI"]
    def validEmplStatus = ["A", "P", "U"]

    // Check all conditions in a single if statement
    def isValid = (personIdExternal != null && !personIdExternal.isEmpty()) &&  
                  (companyTerritoryCode in validTerritoryCodes) &&  
                  (emplStatus in validEmplStatus)

    // Set the result as a message property
    message.setProperty("isValid", isValid.toString()) // "true" or "false"

    return message
}
