import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Get the body as a string
    def body = message.getBody(String);
    
    // Remove all occurrences of XML declaration from the entire payload
    body = body.replaceAll("<\\?xml[^>]*>", "");

    // Wrap the modified content in a root tag
    message.setBody("<root>" + body + "</root>");
    
    return message;
}
