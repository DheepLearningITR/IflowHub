import com.sap.gateway.ip.core.customdev.util.Message

def processData(Message message) {
    // Get the CSV body as a string
    def body = message.getBody(String)
    def lines = body.split("\n")

    if (lines.length == 0) {  // Fix: Checking length instead of isEmpty()
        throw new Exception("Invalid CSV format: Missing headers.")
    }

    // Header mapping: Correct header names
    def headerMap = [
        "Spark_Country": "Spark_Country",
        "Employee_ID": "Employee_ID",
        "Business_Email_Address": "Business_Email_Address",
        "Spark_Payroll_Group": "Spark Payroll Group",
        "EmployeeID": "EmployeeID",
        "Preferred_Language": "Preferred_Language",
        "Preferred_First_Name": "Preferred_First_Name",
        "Legal_First_Name": "Legal_First_Name",
        "Legal_Middle_Initial": "Legal_Middle_Initial",
        "Legal_Last_Name": "Legal_Last_Name",
        "Address_Line_1": "Address_Line_1",
        "Address_City": "Address_City",
        "Address_State": "Address_State",
        "Address_Country": "Address_Country",
        "Address_ZipCode": "Address_ZipCode",
        "search_city": "search_city",
        "search_stateprov": "search_stateprov",
        "search_search_country": "search_search_country",
        "location": "location",
        "function": "function",
        "Department": "Department",
        "employment_type": "employment_type",
        "pay_group": "pay_group",
        "career_level": "career level",
        "Location_type": "Location_type",
        "Division_EPC": "Division"
    ]

    // Process the first row (headers) with quotes
    def headers = lines[0].split(",")
    def modifiedHeaders = headers.collect { headerMap[it.trim()] ?: it.trim() } // Map headers
    modifiedHeaders = modifiedHeaders.collect { "\"${it}\"" } // Add double quotes to each header

    // Construct the final CSV with updated headers
    def finalCsv = modifiedHeaders.join(",") + (lines.length > 1 ? "\n" + lines.drop(1).join("\n") : "")

    // Set the modified CSV back to SAP message body
    message.setBody(finalCsv)
    return message
}
