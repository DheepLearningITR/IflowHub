import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    //Body
    def body = message.getBody(String);
    body = body.replaceAll('''<?xml version='1.0' encoding='UTF-8'?>
<queryCompoundEmployeeResponse>
</queryCompoundEmployeeResponse>''',"")
body = body.replaceAll('''<?xml version='1.0' encoding='UTF-8'?>''',"")
body = body.replaceAll('''<multimap:Messages xmlns:multimap="http://sap.com/xi/XI/SplitAndMerge">''',"")
body = body.replaceAll('''<multimap:Message1>''',"")
body = body.replaceAll('''</multimap:Messages>''',"")
body = body.replaceAll('''</multimap:Message1>''',"")
body = body.replaceAll('''<queryCompoundEmployeeResponse>''',"")
body = body.replaceAll('''</queryCompoundEmployeeResponse>''',"")
body = body.replaceAll('''<queryCompoundEmployeeResponse/>''',"")
    message.setBody(body)
    return message;
}