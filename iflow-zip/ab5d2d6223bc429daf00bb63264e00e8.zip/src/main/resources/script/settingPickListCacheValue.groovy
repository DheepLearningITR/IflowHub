import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def xmlData = message.getBody(String)  // Get the XML response as a String
    def stateCode = message.getProperties().get("state")   // Get the value from "state" property
    def countryCode = message.getProperties().get("country") // Get the value from "country" property

    if (!xmlData?.trim()) {
        return message // No XML data, return as is
    }

    def xml = new XmlSlurper().parseText(xmlData) // Parse XML

    // Fetch en_US for stateCode
    def stateName = xml.PicklistOption.find { it.externalCode.text() == stateCode }?.en_US?.text()
    message.setProperty("state_en_us", stateName ?: "")

    // Fetch en_US for countryCode
    def countryName = xml.PicklistOption.find { it.externalCode.text() == countryCode }?.en_US?.text()
    message.setProperty("country_en_us", countryName ?: "")

    return message
}
