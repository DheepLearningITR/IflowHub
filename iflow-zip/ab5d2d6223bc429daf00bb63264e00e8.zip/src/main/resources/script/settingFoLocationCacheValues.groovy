import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def xmlData = message.getBody(String)  // Get the XML response as a String
    def locationCode = message.getProperties().get("location") // Get the value from "location" property

    if (!xmlData?.trim() || !locationCode?.trim()) {
        return message // No XML or location data, return as is
    }

    def xml = new XmlSlurper().parseText(xmlData) // Parse XML

    // Fetch <name> for the matching <externalCode>
    def locationName = xml.FoLocation.find { it.externalCode.text() == locationCode }?.name?.text()

    // Set the found value or empty string if not found
    message.setProperty("locationValue", locationName ?: "")

    return message
}
