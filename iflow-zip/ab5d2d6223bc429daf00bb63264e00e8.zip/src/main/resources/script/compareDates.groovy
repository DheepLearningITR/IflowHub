import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat

def Message processData(Message message) {
    // Define date formats
    def inputDateFormat = new SimpleDateFormat("yyyy-MM-dd")  // Example: 2024-03-07
    def comparisonDateFormat = new SimpleDateFormat("yyyyMMdd HHmmss.SSS")  // Example: 20240307 120000.000

    // Get start_date from properties
    def startDateStr = message.getProperty("start_date")

    if (startDateStr) {
        // Parse start_date
        def startDate = inputDateFormat.parse(startDateStr)

        // Get current date minus 90 days
        def calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_YEAR, -90)
        def minus90Days = calendar.time

        // Convert to the comparison format
        def formattedMinus90Days = comparisonDateFormat.format(minus90Days)
        def formattedStartDate = comparisonDateFormat.format(startDate)

        // Compare dates
        boolean isStartDateSmaller = formattedStartDate < formattedMinus90Days

        // Set result property
        message.setProperty("result", isStartDateSmaller.toString())
    } else {
        message.setProperty("result", "false")  // Default if start_date is missing
    }

    return message
}
