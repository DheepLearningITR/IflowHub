import com.sap.gateway.ip.core.customdev.util.Message
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone

def Message processData(Message message) {

    // Retrieve properties and headers
    def pMap = message.getProperties()
    def hMap = message.getHeaders()

    // Extract required values
    def companyTerritoryCodeExt = pMap.get("companyTerritoryCode")  // e.g., "USA, CAN, PRI"
    def currentDate = pMap.get("currentDate")                       // e.g., "2025-05-30"
    def LastRun = hMap.get("Last_Run")                              // e.g., "2025-05-30T12:00:00Z"
    def timeZone = pMap.get("timeZone")                             // e.g., "UTC"                  

    // Default timezone to UTC if not provided
    if (timeZone == null || timeZone.trim().isEmpty()) {
        timeZone = "UTC"
    }

    // Setup date formatting
    TimeZone tz = TimeZone.getTimeZone(timeZone)
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd")
    dateFormat.setTimeZone(tz)

    // If currentDate not provided, use today's date
    if (currentDate == null || currentDate.trim().isEmpty()) {
        currentDate = dateFormat.format(new Date())
    }

    // Start building the query
    StringBuffer queryStr = new StringBuffer()
    queryStr.append("SELECT person, address_information, email_information, employment_information, ")
    queryStr.append("compensation_information, job_information, personal_information ")
    queryStr.append("FROM CompoundEmployee ")

    boolean isWhereClauseAdded = false

    // Add companyTerritoryCode filter
    if (companyTerritoryCodeExt != null && !companyTerritoryCodeExt.trim().isEmpty()) {
        def formattedCodes = companyTerritoryCodeExt.split(",")
                                .collect { "'${it.trim()}'" }
                                .join(", ")
        queryStr.append(isWhereClauseAdded ? "AND " : "WHERE ")
        queryStr.append("company_territory_code IN (" + formattedCodes + ") ")
        isWhereClauseAdded = true
    }

    // Add effective_end_date filter
    if (currentDate != null && !currentDate.trim().isEmpty()) {
        queryStr.append(isWhereClauseAdded ? "AND " : "WHERE ")
        queryStr.append("effective_end_date = to_date('" + currentDate + "', 'yyyy-mm-dd') ")
        isWhereClauseAdded = true
    }

    // Add last_modified_on filter based on LastRun and LSRD_Enable
    if (LastRun != null && !LastRun.trim().isEmpty()) {
        queryStr.append(isWhereClauseAdded ? "AND " : "WHERE ")
        queryStr.append("last_modified_on > to_date('" + LastRun + "', 'yyyy-MM-dd''T''HH24:MI:SS''Z''') ")



    }

    // Set the query as a message property
    message.setProperty("QueryFilter", queryStr.toString())

    return message
}
