import com.sap.gateway.ip.core.customdev.util.Message;

/**
    THIS IS A COMMON SCRIPT USED IN ALL ARTIFACTS TO LOG REQUEST PAYLOAD.
    PLEASE DONOT MODIFY THIS WITHOUT CONTACTING ADMIN
**/
def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def value = "No";
    def map = message.getProperties();
    if (map != null){
        value = map.get("PayloadLoggingNeeded");
        if (value == null || value == "") {
            value = "No";
        }
    }
    if(messageLog != null && value.equalsIgnoreCase("Yes"))
    {
        messageLog.addAttachmentAsString("Benevity_Process", body, "text/csv");
    }
    return message;
}