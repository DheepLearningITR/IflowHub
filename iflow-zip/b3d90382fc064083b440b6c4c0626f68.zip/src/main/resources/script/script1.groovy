/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

       //Properties 
       map = message.getProperties();
       value = map.get("dte_status");
       value1 = map.get("dte_env_status")
       if ( value1 == null ){
           message.setProperty("dte_env_status", "0");
           message.setProperty("dte_env_status_desc", "Envio Recibido Conforme");
       }
       if( value != 'DOK' ){
           message.setProperty("dte_env_status", "99");
           message.setProperty("dte_env_status_desc", "Envio Rechazado - Otros");
       }
       if( !value ){
           message.setProperty("dte_status", "FAU");
           message.setProperty("dte_status_desc", "DTE No Recibido - Otros");
       }
       
       return message;
}