import com.sap.it.api.mapping.*;
import org.json.JSONObject;
import org.json.JSONException;
import java.nio.charset.StandardCharsets
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.regex.Matcher
import java.util.regex.Pattern


def Message handle_requestpayload(Message message) {

    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body)

    def saphda_calmonth_from = URLEncoder.encode(input.calmonthFrom[0][input.calmonthFrom[0].size()-1],, StandardCharsets.UTF_8.name())
    message.setProperty("saphda_calmonth_from", saphda_calmonth_from);

    def saphda_calmonth_to = URLEncoder.encode(input.calmonthTo[0][input.calmonthTo[0].size()-1],,StandardCharsets.UTF_8.name())
    message.setProperty("saphda_calmonth_to", saphda_calmonth_to);

    def modelID = URLEncoder.encode(input.modelID,StandardCharsets.UTF_8.name())
    message.setProperty("saphda_modelid", modelID);
    return message;
}

def String convertDate(String arg1){

    Pattern pattern = Pattern.compile("\\d+")
    Matcher matcher = pattern.matcher(arg1)

    String converted_datetime =  ""
    if (matcher.find()) {
        def arg1_long = Long.valueOf(matcher.group())
        Date result_date = new Date( arg1_long );
        DateFormat simple = new SimpleDateFormat(
                "yyyyMM");
        converted_datetime = simple.format(result_date);
    }

    return converted_datetime;
}

def Message transform(Message message) {
       //Reader body = message.getBody(Reader)
    //def input = new JsonSlurper().parse(body)
    def propMap = message.getProperties()

    def saphda_prices = propMap.get('saphda_prices')
    def saphda_prices_json = new JsonSlurper().parse(new StringReader(saphda_prices))
    def saphda_prices_array = saphda_prices_json.get("d").get("results")

    def saphda_dates = propMap.get('saphda_dates')
    def saphda_dates_json = new JsonSlurper().parse(new StringReader(saphda_dates))
    def saphda_dates_array = saphda_dates_json.get("value")

    def saphda_products = propMap.get('saphda_products')
    def saphda_products_json = new JsonSlurper().parse(new StringReader(saphda_products))
    def saphda_products_array = saphda_products_json.get("value")

    def saphda_salesorgcompcode = propMap.get('saphda_salesorgcompcode')
    def saphda_salesorgcompcode_json = new JsonSlurper().parse(new StringReader(saphda_salesorgcompcode))
    HashMap<String, String> saphda_salesorgcompcode_map = new HashMap<String, String>();
    saphda_salesorgcompcode_json.d.results.each { item -> saphda_salesorgcompcode_map.put(item.SalesOrganization,item.CompanyCode);}
    HashMap<String, String> saphda_salesorgcompcode_curr_map = new HashMap<String, String>();
    saphda_salesorgcompcode_json.d.results.each { item -> saphda_salesorgcompcode_curr_map.put(item.SalesOrganization,item.SalesOrganizationCurrency);}



    def saphda_calmonth_from = propMap.get('saphda_calmonth_from')
    def saphda_calmonth_to = propMap.get('saphda_calmonth_to')


    saphda_prices_array.sort { it.ConditionValidityStartDate }

    def result_data_array = []
    saphda_prices_array.each {
        //only SAC products + only empty Customer

        if ( saphda_products_array.findAll{ f -> f.ID == it.Material }.size() > 0
                && it.Customer == ''
                && it.to_SlsPrcgConditionRecord.ConditionRateValueUnit != '%'
                && it.to_SlsPrcgConditionRecord.ConditionCurrency == saphda_salesorgcompcode_curr_map.getOrDefault(it.SalesOrganization,'#')
                && it.to_SlsPrcgConditionRecord.ConditionIsDeleted == false ) {

            def inti = 0
            saphda_dates_array.each { x ->
                if (   x.CALMONTH >= convertDate(it.ConditionValidityStartDate)
                        && x.CALMONTH <= convertDate(it.ConditionValidityEndDate)
                        && x.CALMONTH >= saphda_calmonth_from
                        && x.CALMONTH <= saphda_calmonth_to ) {

                    def indexOfMonth = result_data_array.findIndexOf { m ->
                        m.SAP_ALL_COMPCODE == saphda_salesorgcompcode_map.getOrDefault(it.SalesOrganization, '#') &&
                                m.SAP_ALL_SALESORGANISATION == it.SalesOrganization &&
                                m.DATE == x.CALMONTH &&
                                m.SAP_ALL_PRODUCT == it.Material
                    }
                    if (indexOfMonth == -1) {
                        result_data_array.add(
                                ["SAP_ALL_COMPCODE"         : saphda_salesorgcompcode_map.getOrDefault(it.SalesOrganization, '#'),
                                 "SAP_ALL_SALESORGANISATION": it.SalesOrganization,
                                 "DATE"                     : x.CALMONTH,
                                 "SAP_ALL_PRODUCT"          : it.Material,
                                 "PRICE"                    : it.to_SlsPrcgConditionRecord.ConditionRateValue
                                ]
                        )
                    } else {
                        result_data_array.set(indexOfMonth,
                                ["SAP_ALL_COMPCODE"         : saphda_salesorgcompcode_map.getOrDefault(it.SalesOrganization, '#'),
                                 "SAP_ALL_SALESORGANISATION": it.SalesOrganization,
                                 "DATE"                     : x.CALMONTH,
                                 "SAP_ALL_PRODUCT"          : it.Material,
                                 "PRICE"                    : it.to_SlsPrcgConditionRecord.ConditionRateValue
                                ]
                        )
                    }                            
                }
            }
        }
    }

    def builder = new JsonBuilder()
    builder { Data result_data_array.collect {
        [
                "Version": "public.PricesFromSource",
                "SAP_ALL_COMPANY_CODE" : it.SAP_ALL_COMPCODE,
                "SAP_ALL_SALESORGANISATION" : it.SAP_ALL_SALESORGANISATION,
                "Date" : it.DATE,
                "SAP_ALL_PRODUCT" : it.SAP_ALL_PRODUCT,
                "SAP_FI_XPA_GLAccount": "41000000",
                "SAP_MKT_MarketingCampaign": "#",
                "SAP_MKT_MarketingActivity": "#",
                "SpendType": "#",
                "SAP_FI_IFP_QUANTITY_UNIT": "#",
                "Driver": "#",
                "SAP_ALL_PLANT": "#",
                "PRICE" : it.PRICE.toFloat()
        ]
    }
    }

    def prettyBody = builder.toPrettyString()
    message.setBody(prettyBody);

    return message;
}

def Message jobStatus(Message message) {

    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body)

    def saphda_jobstatus_url = input.jobStatusURL
    message.setProperty("saphda_jobstatus_url", saphda_jobstatus_url);

    return message;
}

def Message catch_camels(Message message){

    def map  = message.getProperties();
    def ex   = map.get("CamelExceptionCaught");
    def exceptionText;

    if (ex != null) {
        exceptionText    = ex.getMessage();
        def messageLog   = messageLogFactory.getMessageLog(message);
        messageLog.addAttachmentAsString("Exception", exceptionText,"application/text");

        // copy the http error response body as a property
        message.setProperty("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());

        try {

            def mp = [
                    "modelID" :  message.getProperty('saphda_modelID'),
                    "Status" : "error",
                    "stepStatus" : "error",
                    "Message" :  exceptionText
            ];

            def ibpCommitStatus = new JSONObject(mp).toString();

            message.setProperty("http.response", ibpCommitStatus);

            message.setBody(ibpCommitStatus);

        } catch (JSONException e) {
            message.setBody(e);
        }
    }
    return message;
}