import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.*;
import groovy.json.JsonBuilder;
import groovy.lang.*;

def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String);
       def jsonSlurper = new JsonSlurper()
       def object = jsonSlurper.parseText(body.toString());
	   def bostatuses=object.businessObjectStatuses;
	   def list=[];
	   def payload;
	   def identifier=object.identifier;
	   def json = new JsonBuilder();
	   if (bostatuses instanceof ArrayList) {
		       payload= json identifier:identifier, businessObjectStatuses:bostatuses  
       }else{
        list.add(bostatuses);
        payload= json identifier:identifier, businessObjectStatuses:list  
       }
		
      message.setBody(groovy.json.JsonOutput.toJson(payload));
      message.setProperty("payload",groovy.json.JsonOutput.toJson(payload));
      return message;
}