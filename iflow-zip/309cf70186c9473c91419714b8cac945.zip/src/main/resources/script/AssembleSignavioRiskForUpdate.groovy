import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.transform.Field

@Field static final String SIGNAVIO_RISK_UPDATE_BODY_FORMAT = 'title=%s&category=%s&description=%s&force=true&attachments=%s&metaDataValues=%s&formats=%s'
@Field static final String URL_ENCODE_CHARSET = "UTF-8"

def Message processData(Message message) {
    def signavioUpdateRisk = message.getProperty('signavioRisk')
    //encodeUrlInSignavioRisk(signavioUpdateRisk)

    def attachments = JsonOutput.toJson(signavioUpdateRisk.attachments)
    def metaDataValues = JsonOutput.toJson(signavioUpdateRisk.metaDataValues)
    def formats = JsonOutput.toJson(signavioUpdateRisk.formats)
    def signavioUpdateBody = String.format(SIGNAVIO_RISK_UPDATE_BODY_FORMAT, signavioUpdateRisk.title, signavioUpdateRisk.category, signavioUpdateRisk.description?.replace("&", "%26"), attachments, metaDataValues, formats)
    message.setBody(signavioUpdateBody)

    return message
}

static void encodeUrlInSignavioRisk(signavioUpdateRisk) {
    for (def attachment : signavioUpdateRisk.attachments) {
        encodeUrl(attachment)
    }

    for (def metaData : signavioUpdateRisk.metaDataValues) {
        encodeUrl(metaData.value)
        if (metaData.value instanceof List) {
            for (def metaDataValueItem : metaData.value) {
                encodeUrl(metaDataValueItem)
            }
        }
    }
}

static void encodeUrl(def object) {
    if (object instanceof Map) {
        if (object.url != null) {
            object.url = URLEncoder.encode(object.url, URL_ENCODE_CHARSET)
        }
    }
}