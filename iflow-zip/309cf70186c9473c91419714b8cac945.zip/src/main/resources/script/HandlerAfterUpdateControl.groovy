import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody()
    int statusCode =  ((Integer) message.getHeaders().get("camelhttpresponsecode")).intValue();
    def NOT_FOUND = 'platform.dispatcher.sboNotFound'
    def signavioUpdateRisks = message.getProperty('signavioUpdateRisks')
    
    def messageLog = messageLogFactory.getMessageLog(message)
    
    if (statusCode != 200) {
        def exceptions = new JsonSlurper().parse(body)
        def errors = exceptions.errors
        if (null != errors && NOT_FOUND.equals(errors[0])) {
            def signavioCreateRisks = message.getProperty('signavioCreateRisks')
            def signavioRisk = signavioUpdateRisks[signavioUpdateRisks.size() - 1]
            signavioCreateRisks.add(signavioRisk)
        }    
    }
    
    // remove updated control
    signavioUpdateRisks.remove(signavioUpdateRisks.size() - 1)
    return message
}