import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import groovy.transform.Field

@Field static final String ATTACHMENTS_FORMAT = '[{"url": "%s","label": "RAM Risk"}]'
@Field static final String ADDRESS_FORMAT = "%s/cp.portal/site#RiskAssessment-manage?sap-ui-app-id-hint=com.sap.grc.risk.assessment&/RiskAssessment('%s')"
@Field static final String META_RAM_RISK_STATUS = 'meta-ramriskstatus'
@Field static final String META_RAM_RISK_CATEGORY = 'meta-ramriskcategory'
@Field static final String META_RAM_RISK_TECHNICAL_ID = 'meta-ramrisktechnicalid'
@Field static final String META_RAM_RISK_ID = 'meta-ramriskid'
@Field static final String META_RAM_INHERENT_RISK_LEVEL = 'meta-raminherentrisklevel'
@Field static final String META_RAM_RESIDUAL_RISK_LEVEL = 'meta-ramresidualrisklevel'
@Field static final List SUPPORT_TYPES = ["MetaDataBoolean", "MetaDataDate", "MetaDataEnum", "MetaDataNumberInfo", "MetaDataStringInfo"]


def Message processData(Message message) {
    def body = message.getBody(java.io.Reader);
    def Risks = new JsonSlurper().parse(body).value
    def signavioMetadatas = message.getProperty('metadatas')
    def ramFieldsToSignavioAttributesMaps = message.getProperty('categoryValueMappingMap')
    def extensionFieldNameForSignavioCategory = message.getProperty('extensionFieldNameForSignavioCategory')
    def defaultActiveRiskCategoryId =  message.getProperty("defaultCategoryId")
    def retiredRiskCategoryId =  message.getProperty("retiredCategoryId")
    def signavioCategoryIds = message.getProperty('signavioCategoryIds')

    def signavioCreateRisks = []
    def signavioUpdateRisks = []
    def riskCount = Risks.size()
    def topRisk = Integer.valueOf(message.getProperty('topRisk'))
    def skipRisk = Integer.valueOf(message.getProperty('skipRisk'))
    message.setProperty('skipRisk', skipRisk + topRisk)
    message.setProperty('moreRisks', topRisk == riskCount)
    for (def risk : Risks) {
        def signavioRisk = [:]
        def categoryIdInRisk
        if (risk.status?.name == 'Retired') {
            if (null == risk.externalId || risk.externalId.length() == 0) {
                continue
            } else {
                signavioRisk["category"] = retiredRiskCategoryId
            }
        } else {
            def categoryField = risk.extensionFieldValues?.find{ it.fieldName ==  extensionFieldNameForSignavioCategory }
            if (categoryField != null && categoryField["fieldName"] != null) {
                categoryIdInRisk = categoryField["fieldValue"]
            }
            if (categoryIdInRisk != null && signavioCategoryIds != null && signavioCategoryIds.contains(categoryIdInRisk)) {
                signavioRisk["category"] = categoryIdInRisk
            } else {
                signavioRisk["category"] = defaultActiveRiskCategoryId;
            }
        }


        signavioRisk["title"] = risk.name
        signavioRisk["description"] = risk.description
        signavioRisk["force"] = true
        signavioRisk["fcmRiskID"] = risk.id
        //set custom attribute

        def customAttribute = new HashMap()
        def fieldMappingsByCurrentCategory = ramFieldsToSignavioAttributesMaps.find{ it.key == "$signavioRisk.category" }?.value
        if (fieldMappingsByCurrentCategory) {
            risk.extensionFieldValues?.each{mapRAMCustomDefineFieldToSignavioCusotmAttribute(it, fieldMappingsByCurrentCategory, signavioMetadatas, customAttribute)}
        }

        customAttribute[META_RAM_RISK_STATUS] = risk.status?.name
        customAttribute[META_RAM_RISK_CATEGORY] = risk.category?.name
        customAttribute[META_RAM_RISK_ID] = risk.displayId
        customAttribute[META_RAM_RISK_TECHNICAL_ID] = risk.id
        
        def inherentRiskSummary = risk.summary?.find{it.analysisResult?.code?.equals('ir')}
        customAttribute[META_RAM_INHERENT_RISK_LEVEL] = inherentRiskSummary?.riskLevel?.name
        def residualRiskSummary = risk.summary?.find{it.analysisResult?.code?.equals('rr')}
        customAttribute[META_RAM_RESIDUAL_RISK_LEVEL] = residualRiskSummary?.riskLevel?.name

        //cdf fields and custom attributes
        def customAttributeJson = new JsonBuilder(customAttribute)
        signavioRisk["metaDataValues"] = customAttributeJson.toString()
        //set attachment URL
        setAttachmentURL(message, risk, signavioRisk)
        if (null == risk.externalId || risk.externalId.length() == 0) {
            // create
            signavioRisk.id = risk.id
            signavioCreateRisks.add(signavioRisk)
        } else {
            //update
            signavioRisk.id = risk.externalId
            signavioUpdateRisks.add(signavioRisk)
        }
    }
    message.setProperty('signavioCreateRisks', signavioCreateRisks)
    message.setProperty('signavioUpdateRisks', signavioUpdateRisks)
    return message
}


def mapRAMCustomDefineFieldToSignavioCusotmAttribute(customRAMField, fieldMappings, signavioMetadatas, customAttribute) {
    def fieldMapping = fieldMappings.find{it.sourceIdentifier.equals(customRAMField.fieldName)}
    def targetIdentifier = fieldMapping?.targetIdentifier
    def metadata
    if (targetIdentifier != null) {
        metadata = signavioMetadatas.find{it.id.equals(targetIdentifier)}
    }


    if (metadata!= null && metadata.type != null) {
        // check type supported
        if (SUPPORT_TYPES.contains(metadata.type) == false) {
            return
        }
    }


    if (metadata != null && targetIdentifier != null) {
        def handler = getRAMCustomFieldValueHandler(metadata, fieldMapping, targetIdentifier)
        def signavioCustomAttributeValue = handler.convertRAMValueToSignavioValue(customRAMField)
        if (signavioCustomAttributeValue != null) {
            customAttribute."$targetIdentifier" = signavioCustomAttributeValue
        }
    }
}


interface RAMCustomFieldValueHandler {
    void setMetadata(metadata)

    Object convertRAMValueToSignavioValue(ramField)
}

def getRAMCustomFieldValueHandler(metadata, fieldMapping, targetIdentifier) {
    def handler;
    switch (metadata.type) {
        case "MetaDataBoolean":
            handler = new SignavioMetaBooleanValueHandler()
            break
        case "MetaDataEnum":
            handler = new SignavioMetaDataEnumHandler()
            break
        case "MetaDataNumberInfo":
            handler = new SignavioMetaNumberValueHandler()
            break
        case "MetaDataStringInfo":
            handler = new SignavioMetaStringValueHandler()
            break
        default:
            break
    }

    handler?.metadata = metadata
    handler?.fieldMapping = fieldMapping
    handler?.targetIdentifier = targetIdentifier

    return handler
}

abstract class SignavioMetadataSupportedValueHandler implements RAMCustomFieldValueHandler {
    Map metadata
    Map fieldMapping
    String targetIdentifier

    void setMetadata(metadata) {
        this.metadata = metadata
    }

    protected boolean onlyWildcards(List items) {
        return items.size() == 1 && items.find {"*".equals(it.source)} != null && items.find {"*".equals(it.target)} != null
    }
}

class SignavioMetaBooleanValueHandler extends SignavioMetadataSupportedValueHandler {
    Object convertRAMValueToSignavioValue(ramField) {
        return ramField.fieldValue
    }
}

class SignavioMetaNumberValueHandler extends SignavioMetadataSupportedValueHandler {
    Object convertRAMValueToSignavioValue(ramField) {
        return ramField.fieldValue
    }
}


class SignavioMetaDataEnumHandler extends SignavioMetadataSupportedValueHandler {
    Object convertRAMValueToSignavioValue(ramField) {
        List metadataItems = metadata["items"]
        List valueMappings = fieldMapping.valueMappings

        def potentialValueMappings = valueMappings.findAll { it.source == ramField.fieldValue }
        if (potentialValueMappings.isEmpty()) {
            return
        }
        def signavioAttributeValueInFieldMapping
        if (potentialValueMappings.size() > 1) {
            signavioAttributeValueInFieldMapping = potentialValueMappings.find { it.defaultMapping == true }.target
        } else {
            signavioAttributeValueInFieldMapping = potentialValueMappings[0].target
        }

        def signavioValue = metadataItems?.find{it["title"].equals(signavioAttributeValueInFieldMapping)}.value
        return signavioValue
    }
}

class SignavioMetaStringValueHandler extends SignavioMetadataSupportedValueHandler {
    Object convertRAMValueToSignavioValue(ramField) {
        return ramField.fieldValue
    }
}

private void setAttachmentURL(Message message, risk, signavioRisk) {
    def FCMRiskAddress = message.getProperty('FCMHost')
    def fcmUrl = URLEncoder.encode(String.format(ADDRESS_FORMAT, FCMRiskAddress, risk.displayId))
    def attachments = String.format(ATTACHMENTS_FORMAT, fcmUrl)
    signavioRisk["attachments"] = attachments
}
