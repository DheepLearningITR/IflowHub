import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    int statusCode =  ((Integer) message.getHeaders().get("camelhttpresponsecode")).intValue();
    def ramRisk = message.getProperty("signavioUpdateRisk")

    if (statusCode == 200) {
        def body = message.getBody(java.io.Reader)
        def jsonBody = new JsonSlurper().parse(body)
        def ramRiskAttachmentsMap = new JsonSlurper().parseText(ramRisk.attachments)

        for (def jsonBodyAttachment : jsonBody.attachments) {
            def tempAttachment = ramRiskAttachmentsMap.find { it['label'] ==  jsonBodyAttachment.label }
            if ( tempAttachment == null) {
                ramRiskAttachmentsMap << jsonBodyAttachment
            }
        }
        ramRisk.attachments = ramRiskAttachmentsMap

        def ramRiskMetaDataValuesMap = new JsonSlurper().parseText(ramRisk.metaDataValues)
        ramRisk.metaDataValues = jsonBody.metaDataValues << ramRiskMetaDataValuesMap
        
        encodeUrlInSignavioRisk(ramRisk)
        ramRisk.formats = jsonBody.formats
    }

    message.setProperty("signavioRisk", ramRisk)
    return message
}

static void encodeUrlInSignavioRisk(signavioUpdateRisk) {
    for (def attachment : signavioUpdateRisk.attachments) {
        encodeUrl(attachment)
    }
    
    for (def metaData : signavioUpdateRisk.metaDataValues) {
        if (metaData.value instanceof List) {
            for (def metaDataValueItem : metaData.value) {
                encodeUrl(metaDataValueItem)
            }
        }
    }
}

static void encodeUrl(object) {
    if (object instanceof Map) {
        if (object.url != null && object.label != 'RAM Risk') {
            object.url = URLEncoder.encode(object.url, 'UTF-8')
        }
    }
}