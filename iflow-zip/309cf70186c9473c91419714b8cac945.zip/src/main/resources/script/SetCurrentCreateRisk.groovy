import com.sap.gateway.ip.core.customdev.util.Message
import groovy.transform.Field

@Field static final String SIGNAVIO_RISK_BODY_FORMAT = 'title=%s&category=%s&description=%s&force=true&attachments=%s&metaDataValues=%s'

def Message processData(Message message) {
    def signavioCreateRisks = message.getProperty('signavioCreateRisks')
    def signavioCreateRisk = signavioCreateRisks[signavioCreateRisks.size() - 1]
    def signavioCreateBody = String.format(SIGNAVIO_RISK_BODY_FORMAT, signavioCreateRisk.title, signavioCreateRisk.category, signavioCreateRisk.description?.replace("&", "%26"), signavioCreateRisk.attachments, signavioCreateRisk.metaDataValues)
    message.setBody(signavioCreateBody)
    return message
}