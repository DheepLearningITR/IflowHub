import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def singleCategoryValueMappingMap = new JsonSlurper().parse(body) 
    def currentCategoryId = message.getProperty('currentCategoryId');
    
    def categoryValueMappingMap =  message.getProperty("categoryValueMappingMap")
    if (categoryValueMappingMap == null) {
        categoryValueMappingMap = [:]
    }
    
    categoryValueMappingMap."$currentCategoryId" = singleCategoryValueMappingMap
    message.setProperty("categoryValueMappingMap", categoryValueMappingMap)
    
    return message
}