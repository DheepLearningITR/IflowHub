import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    def categoryValueMappingMapLoopIndex = Integer.valueOf(message.getProperty("categoryValueMappingMapLoopIndex")).intValue()
    def valueMappingMetaMapList = message.getProperty("valueMappingMetaMapList")
    def categoryIdValueMappingIdVersionMap = valueMappingMetaMapList.get(categoryValueMappingMapLoopIndex)
    
    message.setProperty("categoryValueMappingMapLoopIndex",  categoryValueMappingMapLoopIndex + 1)
    message.setProperty("currentCategoryId", categoryIdValueMappingIdVersionMap["categoryId"]);
    
    GetValueMappingRequestBody requestBody = new GetValueMappingRequestBody(categoryIdValueMappingIdVersionMap['valueMappingId'],  categoryIdValueMappingIdVersionMap['valueMappingVersion'], 'false')
    message.setBody(JsonOutput.toJson(requestBody))
    return message
}

class GetValueMappingRequestBody {
    String valueMappingId
    String valueMappingVersion
    String isSignavioToRam

    GetValueMappingRequestBody(valueMappingId, valueMappingVersion, isSignavioToRam) {
        this.valueMappingId = valueMappingId
        this.valueMappingVersion = valueMappingVersion
        this.isSignavioToRam = isSignavioToRam
    }
}