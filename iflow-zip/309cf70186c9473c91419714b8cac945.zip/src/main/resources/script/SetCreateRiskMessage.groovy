import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.transform.Field

import java.text.SimpleDateFormat

@Field static final String GRC_DATE_FORMATTER = "yyyy-MM-dd'T'HH:mm:ss'Z'"
@Field static final String RISK_UPSERT_MESSAGE_TOPIC = 'sap.grc.risk.ComplianceRisk.Update.v1'
@Field static final String SEPERATOR = '/'
@Field static final String TOPIC_FORMAT = 'topic:%s/ce/%s'
@Field static final String SUBJECT_FORMAT = 'ComplianceRisk:%s'
@Field static final String SIGNAVIO_RISK_FORMAT = '%s/p/hub/dictionary/entry/%s'

def Message processData(Message message) {
    def signavioCreateRisks = message.getProperty('signavioCreateRisks')
    def size = signavioCreateRisks.size()
    def currentRisk = signavioCreateRisks.get(size - 1)
    def responseBody = message.getBody(java.io.Reader)
    def jsonResponseBody = new JsonSlurper().parse(responseBody)
    def emNamespace = message.getProperty('emNamespace')
    def SAPMplCorrelationId = message.getHeader('SAP_MplCorrelationId', String.class)

    Map risk = new HashMap()
    def signavioRiskId = jsonResponseBody.rep.id
    risk.id = currentRisk.fcmRiskID
    risk.externalId = signavioRiskId

    // generate Signavio risk detail URL
    def signavioHost = message.getProperty('signavioHost')
    def signavioRiskURL = String.format(SIGNAVIO_RISK_FORMAT, signavioHost, signavioRiskId)
    risk.externalUrl = signavioRiskURL
    risk.sourceSystem = 'Signavio'
    def body = new EventMessageBody(risk)
    body.time = new SimpleDateFormat(GRC_DATE_FORMATTER).format(new Date())
    body.source = SEPERATOR + emNamespace
    body.subject = String.format(SUBJECT_FORMAT, currentRisk.fcmRiskID)
    body.type = RISK_UPSERT_MESSAGE_TOPIC
    body.xsapcorrelationid = SAPMplCorrelationId

    def payload = [:]
    payload.body = JsonOutput.toJson(body)
    payload.topic = String.format(TOPIC_FORMAT, emNamespace, RISK_UPSERT_MESSAGE_TOPIC.replace('.', SEPERATOR))
    message.setBody(JsonOutput.toJson(payload))

    signavioCreateRisks.remove(size - 1)
    message.setProperty('signavioCreateRisks', signavioCreateRisks)
    return message
}

class EventMessageBody {
    String xsapcorrelationid
    String id
    String specversion = '1.0'
    String datacontenttype = 'application/json'
    String contentType = 'application/json'
    String time
    String type
    String source
    String subject
    Object data

    EventMessageBody(data) {
        this.id = UUID.randomUUID().toString()
        this.data = data
    }
}