import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def signavioUpdateRisks = message.getProperty('signavioUpdateRisks')
    def signavioUpdateRisk = signavioUpdateRisks[signavioUpdateRisks.size() - 1]
    message.setProperty('signavioRiskId', signavioUpdateRisk.id)
    message.setProperty('signavioUpdateRisk', signavioUpdateRisk)
    return message
}