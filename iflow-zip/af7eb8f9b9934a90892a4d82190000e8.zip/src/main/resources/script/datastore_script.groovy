import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.String;
import javax.xml.xpath.*
import javax.xml.parsers.DocumentBuilderFactory

// set datastore namd, entry ID for BusinessPartner and BusinessPartnerRelationship
def Message processData(Message message) {

	def messageLog = messageLogFactory.getMessageLog(message);
	def body = message.getBody(java.lang.String) as String;
	def properties = message.getProperties() as Map<String, Object>;

	String RAW_RETURN_ORDER_DATASTORE_ENTRY_ID = processXml(body, "//CustomerReturn/CustomerReturnID");


	if(!RAW_RETURN_ORDER_DATASTORE_ENTRY_ID.isEmpty()){
	    message.setProperty("PROCESSED_RETURN_ORDER_DATASTORE_ENTRY_ID", RAW_RETURN_ORDER_DATASTORE_ENTRY_ID);
	}

    message.setProperty("CUSTOMER_RETURN_DATASTORE_NAME", "CustomerReturn");

    return message;
}



def processXml( String xml, String xpathQuery ) {

   def xpath = XPathFactory.newInstance().newXPath()
   def builder     = DocumentBuilderFactory.newInstance().newDocumentBuilder()
   def inputStream = new ByteArrayInputStream( xml.bytes )
   def records     = builder.parse(inputStream).documentElement

   xpath.evaluate( xpathQuery, records )
}
