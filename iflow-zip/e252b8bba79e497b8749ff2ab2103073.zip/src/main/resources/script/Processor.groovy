import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.security.MessageDigest;
import java.security.Security;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

import groovy.transform.Field;
import java.lang.Exception;
import java.text.Normalizer;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import java.net.URI;

import org.apache.commons.codec.binary.Base64;
 
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import java.lang.Object;
import java.util.zip.CRC32;
import java.util.zip.Checksum;
import java.security.DigestInputStream;
import java.util.zip.CheckedInputStream;


def Message processGetStatus( Message message ) throws Exception {

	setCredentialsAsProperties(message);
	setRequestSignatureAsProperties(message);
	
	return message;
}


def setCredentialsAsProperties( Message message ) throws Exception {

    def map = message.getProperties();
    def credentials_alias = map.get("credentials_alias");
//     def taxNumber =  map.get("taxNumber");
// 	credentials_alias = credentials_alias+taxNumber;

    def service = ITApiFactory.getApi(SecureStoreService.class, null);
	def credential = null;
	try {
		credential = service.getUserCredential( credentials_alias );
	} catch (all) {
		throw new Exception("No credentials found for alias " + credentials_alias );
	}

//Get credential from keystore
    String userName = credential.getUsername();
    
//Hash SHA-512 the pass capital letters    
    def MessageDigest digest = MessageDigest.getInstance("SHA-512");
    
    byte[] salt = (new String(credential.getPassword())).getBytes("UTF-8");
    
    digest.update(salt);
    
    def passwordHash = digest.digest().encodeHex().toString();
    def passwordHashup = passwordHash.toUpperCase();
   
    message.setProperty("login", userName);
    message.setProperty("passwordHash", passwordHashup);

 	return message;
}


def setRequestSignatureAsProperties( Message message ) throws Exception {
// Concatenate requestId value - UTC timestamp tag value using a YYYYMMDDhhmmss mask (remove separators)
// and String literal of the technical user�s signature key
    def map = message.getProperties();
    def requestId = map.get("requestId");
	def timestamp = map.get("timestampZ").replaceAll(/[^0-9]/, "").substring(0, 14);  
    def signaturekey_alias = map.get( "signaturekey_alias" );
    def taxNumber =  map.get("taxNumber");
// 	signaturekey_alias = signaturekey_alias+taxNumber;
	
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
	def signature = null;
	try {
		signature = service.getUserCredential( signaturekey_alias );
	} catch (all) {
		throw new Exception("No signaturekey credentials found for alias " + signaturekey_alias );
	}

//Get credential from keystore
    String userName = signature.getUsername();
    def requestSignature = new String(requestId + timestamp + (new String(signature.getPassword())) );

 //Hash SHA3-512 the pass capital letters    
    def MessageDigest digest = MessageDigest.getInstance("SHA3-512");
    
    byte[] salt = (new String(requestId + timestamp + (new String(signature.getPassword()))));
       
    digest.update(salt);
    
    def requestSignatureHass = digest.digest().encodeHex().toString();
    
    def requestSignatureHashup = requestSignatureHass.toUpperCase();
   
    message.setProperty("requestSignature", requestSignatureHashup ); 
    message.setProperty("requestSignatureNoHASH", requestSignature );
  
 	return message;
}
