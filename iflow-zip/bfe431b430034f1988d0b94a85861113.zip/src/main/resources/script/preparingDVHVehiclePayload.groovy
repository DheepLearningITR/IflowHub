import com.sap.gateway.ip.core.customdev.util.Message
import java.net.URLDecoder
import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import org.json.JSONObject
import org.json.XML
import java.math.MathContext
import java.math.BigDecimal

import java.util.regex.Pattern

String toDate(String str) {
    if (str.length() > 7) {
        String dateStr = str.substring(0, 4) + "-" + str.substring(4, 6) + "-" + str.substring(6, 8)
        return dateStr
    }
    return ""
}

String toTransactionalDate(String str) {
    if (str.length() > 7) {
        ArrayList<String> date = str.split('-') as List
        return date[0] + "-" + date[1] + "-" + date[2]
    }
    return ""
}

String toDateTime(String str) {
    if (str.length() > 13) {
        String dateStr = str.substring(0, 4) + "-" + str.substring(4, 6) + "-" + str.substring(6, 8) + "T" + str.substring(8, 10) + ":" + str.substring(10, 12) + ":" + str.substring(12, 14) + "Z"
        return dateStr
    }
    return ""
}

class RimSize {
    String value
    String uom
}

class OdometerReading {
    String value
    String uom
}

class Attribute {
    String id
    Object value
    String minValue
    String maxValue
    String uom
}

ArrayList getAttribute(Object attribute, Object vehicleSpecification, boolean isUsed) {
    attributeArr = []
    
    for (attributeDetails in attribute) {
        if (attributeDetails) {
            
            attr = new Attribute()
            attr.id = attributeDetails.opt("attributeid")
            
            if(attributeDetails.opt("value") instanceof String) {
                attr.value = attributeDetails.opt("value").split(',') as List
            } else {
                attr.value = attributeDetails.opt("value")
            }
            
            attr.minValue = attributeDetails.opt("minvalue")
            attr.maxValue = attributeDetails.opt("maxvalue")
            attr.uom = attributeDetails.opt("uom")
            
            attributeArr.add(attr)
        }
    }

    if(vehicleSpecification != null) {
        if(vehicleSpecification.opt("dvh_interior_color") instanceof String) {
            attr = new Attribute()
            attr.id = "DVH_INTERIOR_COLOR"
            attr.value = vehicleSpecification.opt("dvh_interior_color")
            attributeArr.add(attr)
        }

        if(vehicleSpecification.opt("dvh_upholstery_fabric") instanceof String) {
            attr = new Attribute()
            attr.id = "DVH_UPHOLSTERY"
            attr.value = vehicleSpecification.opt("dvh_upholstery_fabric")
            attributeArr.add(attr)
        }

        if(vehicleSpecification.opt("dvh_upholstery_color") instanceof String) {
            attr = new Attribute()
            attr.id = "DVH_UPHOLSTERY_COLOR"
            attr.value = vehicleSpecification.opt("dvh_upholstery_color")
            attributeArr.add(attr)
        }

        if(vehicleSpecification.opt("dvh_exterior_color") instanceof String) {
            attr = new Attribute()
            attr.id = "DVH_EXTERIOR_COLOR"
            attr.value = vehicleSpecification.opt("dvh_exterior_color")
            attributeArr.add(attr)
        }

        if(vehicleSpecification.opt("dvh_wheel_type") instanceof String) {
            attr = new Attribute()
            attr.id = "DVH_WHEEL_TYPE"
            attr.value = vehicleSpecification.opt("dvh_wheel_type")
            attributeArr.add(attr)
        }

        if(vehicleSpecification.opt("dvh_homologation_number") instanceof String) {
            attr = new Attribute()
            attr.id = "DVH_HOMOLOGATION_NUMBER"
            attr.value = vehicleSpecification.opt("dvh_homologation_number")
            attributeArr.add(attr)
        }

        if(vehicleSpecification.opt("dvh_tire_size") instanceof String) {
            attr = new Attribute()
            attr.id = "DVH_TIRE_SIZE"
            attr.value = vehicleSpecification.opt("dvh_tire_size")
            attributeArr.add(attr)
        }

        if((vehicleSpecification.opt("dvh_rim_size") instanceof Integer || vehicleSpecification.opt("dvh_rim_size") instanceof BigDecimal) && vehicleSpecification.opt("dvh_rim_size") != 0) {
            attr = new Attribute()
            attr.id = "DVH_RIM_SIZE"
            attr.value = vehicleSpecification.opt("dvh_rim_size")
            attr.uom = vehicleSpecification.opt("dvh_rim_size_uom")
            attributeArr.add(attr)
        }

        if((vehicleSpecification.opt("dvh_odometer_reading") instanceof Integer || vehicleSpecification.opt("dvh_odometer_reading") instanceof BigDecimal) && vehicleSpecification.opt("dvh_odometer_reading") != 0) {
            attr = new Attribute()
            attr.id = "DVH_ODOMETER_READING"
            attr.value = vehicleSpecification.opt("dvh_odometer_reading")
            attr.uom = vehicleSpecification.opt("dvh_odometer_reading_uom")
            attributeArr.add(attr)
        }
        
        
        attr = new Attribute()
        attr.id = "DVH_USED_VEHICLE"
        attr.value = isUsed
        attributeArr.add(attr)
    }
    
    return attributeArr
}

class AttributeGroup {
    String id
    ArrayList<Attribute> attribute
}

ArrayList getAttributeGroup(Object attributegroup, Object vehicleSpecification, boolean isUsed) {
    attributeGroupArr = []
    for (attributeGroupDetails in attributegroup) {
        if (attributeGroupDetails) {
            attributeGroupArr.add(
                new AttributeGroup(
                        id: attributeGroupDetails.attributegroupid,
                        attribute: getAttribute(attributeGroupDetails.opt("vmsvehicleattribute"), null, isUsed)
                )
            )
        }
    }

    if(vehicleSpecification != null) {
        attributeGroupArr.add(
            new AttributeGroup(
                id: "DVH_AG_VEHICLE_SPECIFICATION",
                attribute: getAttribute([], vehicleSpecification, isUsed)
            )
        )
    }
    
    return attributeGroupArr
}

class Template {
    String id
    ArrayList<AttributeGroup> attributeGroup
}

ArrayList getTemplate(Object template, Object vehicleSpecification, boolean isUsed) {
    templateArr = []
    for (temaplateDetails in template) {
        if (temaplateDetails) {
            templateArr.add(
                new Template(
                    id: temaplateDetails.opt("vmsvehicleequipmenttemplate"),
                    attributeGroup: getAttributeGroup(temaplateDetails.opt("vmsvehicleattributegroup"), null, isUsed)
                )
            )
        }
    }

    templateArr.add(
        new Template(
            id: "DVH_ET_VEHICLE_SPECIFICATION",
            attributeGroup: getAttributeGroup([], vehicleSpecification, isUsed)
        )
    )
    
    return templateArr
}

class VehicleSpecification {
    ArrayList<Template> template
}

Object getVehicleSpecification(Object vehicleJSONObject) {
    vehicleSpecification = vehicleJSONObject.opt("standardconfiguration")
    template = vehicleJSONObject.opt("configuration")
    vehicleSpecificationObject = new VehicleSpecification()
    if (vehicleSpecification) {
        vehicleSpecificationObject = new VehicleSpecification(
                template: getTemplate(template, vehicleSpecification, vehicleJSONObject.opt("vmsvehicleisused") == "X")
        )
    }
    return vehicleSpecificationObject
}

class SourceSystemStatus {
    String statusID
    String dateTime
    String code
    String sourceSystemID
}

ArrayList getSourceSystemStatus(Object vmsStatus) {
    dvhSourceSystemStatusArr = []
    for (status in vmsStatus) {
        dvhSourceSystemStatusArr.add(
                new SourceSystemStatus(
                        statusID: status.opt("attributeid"),
                        dateTime: toDateTime(status.opt("datetime").toString()),
                        code: status.opt("statuscode"),
                        sourceSystemID: status.opt("logicalsystem")
                )
        )
    }
    return dvhSourceSystemStatusArr
}

class Invoice {
    boolean cancellationInvoice
    boolean cancelledInvoice
    String cancelledInvoiceNumber
    int categoryCode
    String counterPartyID
    String currency
    String date
    String itemNumber
    String netAmount
    String number
    String sourceSystemID
    int typeCode
    String supplierInvoiceReference
    String postingDate
    String documentTypeCode
    String companyCode
    String companyName
    String plantID
    String plantName
    String salesOrganizationID
    String salesOrganizationName
    String purchasingOrganizationID
    String purchasingOrganizationName
    String counterPartyName
    String uomCode
    String quantity
    String grossAmount
    String taxCode
    String taxAmount
    String materialNumber
    String materialDescription
    String billToPartyID
    String billToPartyName
}

ArrayList getInvoices(Object vehicleJSONObject) {
    invoiceArr = []
    incomingInvoice = vehicleJSONObject.opt("incominginvoice")
    for (incoming in incomingInvoice) {
        if (incoming) {
        invoiceArr.add(new Invoice(
                cancellationInvoice: incoming.opt("supplierinvoiceiscancelled") == "X",
                cancelledInvoice: incoming.opt("vehactiondoctypeisreversed") == "X",
                cancelledInvoiceNumber: incoming.opt("reversedocument"),
                categoryCode: 1,
                counterPartyID: incoming.opt("invoicingparty"),
                currency: incoming.opt("documentcurrency"),
                date: toTransactionalDate(incoming.opt("documentdate").toString()),
                itemNumber: incoming.opt("supplierinvoiceitem"),
                netAmount: incoming.opt("supplierinvoiceitemamount"),
                number: incoming.opt("refaccountingdocument"),
                sourceSystemID: incoming.opt("logicalsystem"),
                typeCode: 10,
                supplierInvoiceReference : incoming.opt("documentreferenceid"),
                postingDate: toTransactionalDate(incoming.opt("postingdate").toString()),
                companyCode : incoming.opt("companycode"),
                companyName : incoming.opt("companycodename"),
                plantID : incoming.opt("plant"),
                plantName : incoming.opt("plantname"),
                salesOrganizationID : "",
                salesOrganizationName : "",
                purchasingOrganizationID : incoming.opt("purchasingorganization"),
                purchasingOrganizationName : incoming.opt("purchasingorganizationname"),
                counterPartyName : incoming.opt("suppliername"),
                uomCode : incoming.opt("purchaseorderquantityunit"),
                quantity : new BigDecimal(incoming.opt("quantityinpurchaseorderunit")).round(new MathContext(2)),
                grossAmount : incoming.opt("grossamount"),
                taxCode : incoming.opt("taxcode"),
                taxAmount : incoming.opt("taxamount"),
                materialNumber : incoming.opt("material"),
                materialDescription : incoming.opt("materialdescription")
            ))
        }
    }

    outgoingInvoice = vehicleJSONObject.opt("outgoinginvoice")
    for (outgoing in outgoingInvoice) {
        if (outgoing) {
        invoiceArr.add(new Invoice(
                cancellationInvoice: outgoing.opt("billingdocumentiscancelled") == "X",
                cancelledInvoice: outgoing.opt("vmsvehicleactndoctypeisrvsd") == "X",
                cancelledInvoiceNumber: outgoing.opt("cancelledbillingdocument"),
                categoryCode: 2,
                counterPartyID: outgoing.opt("soldtoparty"),
                currency: outgoing.opt("transactioncurrency"),
                date: toTransactionalDate(outgoing.opt("billingdocumentdate").toString()),
                itemNumber: outgoing.opt("billingdocumentitem"),
                netAmount: outgoing.opt("netamount"),
                number: outgoing.opt("billingdocument"),
                sourceSystemID: outgoing.opt("logicalsystem"),
                typeCode: 11,
                documentTypeCode: outgoing.opt("billingdocumenttype"),
                companyCode : outgoing.opt("companycode"),
                companyName : outgoing.opt("companycodename"),
                plantID : outgoing.opt("plant"),
                plantName : outgoing.opt("plantname"),
                salesOrganizationID : outgoing.opt("salesorganization"),
                salesOrganizationName : outgoing.opt("salesorganizationname"),
                purchasingOrganizationID : "",
                purchasingOrganizationName : "",
                counterPartyName : outgoing.opt("soldtopartyname"),
                uomCode : outgoing.opt("billingquantityunit"),
                quantity : new BigDecimal(outgoing.opt("billingquantity")).round(new MathContext(2)),
                taxCode : outgoing.opt("taxcode"),
                taxAmount : outgoing.opt("taxamount"),
                materialNumber : outgoing.opt("material"),
                billToPartyID : outgoing.opt("billtoparty"),
                billToPartyName : outgoing.opt("billtopartyname")
            ))
        }
    }
    
    return invoiceArr
}

class Procurement {
    String amount
    String companyCode
    String companyName
    String costCenterNumber
    String currency
    String date
    String documentNumber
    String groupID
    String groupName
    String itemNumber
    String organizationID
    String organizationName
    String plantID
    String plantName
    String sourceSystemID
    String statusCode
    String supplierID
    int typeCode
    String documentTypeCode
    String supplierName
    String taxCode
    String materialNumber
    String materialDescription
    String quantity
    String uomCode
}

ArrayList getProcurement(Object purchaseorder) {
    procurementArr = []
    for (purchaseOrder in purchaseorder) {
        procurementArr.add(
                new Procurement(
                        amount: purchaseOrder.opt("netpriceamount"),
                        companyCode: purchaseOrder.opt("companycode"),
                        companyName: purchaseOrder.opt("companycodename"),
                        costCenterNumber: purchaseOrder.opt("costcenter"),
                        currency: purchaseOrder.opt("documentcurrency"),
                        date: toTransactionalDate(purchaseOrder.opt("purchaseorderdate").toString()),
                        documentNumber: purchaseOrder.opt("purchaseorder"),
                        groupID: purchaseOrder.opt("purchasinggroup"),
                        groupName: purchaseOrder.opt("purchasinggroupname"),
                        itemNumber: purchaseOrder.opt("purchaseorderitem"),
                        organizationID: purchaseOrder.opt("purchasingorganization"),
                        organizationName: purchaseOrder.opt("purchasingorganizationname"),
                        plantID: purchaseOrder.opt("plant"),
                        plantName: purchaseOrder.opt("plantname"),
                        sourceSystemID: purchaseOrder.opt("logicalsystem"),
                        statusCode: purchaseOrder.opt("purchasingprocessingstatus"),
                        supplierID: purchaseOrder.opt("supplier"),
                        typeCode: 2,
                        documentTypeCode: purchaseOrder.opt("purchaseordertype"),
                        supplierName: purchaseOrder.opt("suppliername"),
                        taxCode: purchaseOrder.opt("taxcode"),
                        materialNumber: purchaseOrder.opt("material"),
                        materialDescription: purchaseOrder.opt("materialdescription"),
                        quantity: new BigDecimal(purchaseOrder.opt("orderquantity")).round(new MathContext(2)),
                        uomCode: purchaseOrder.opt("orderpriceunit")
                )
        )
    }
    return procurementArr
}

class Sales {
    String amount
    String channelID
    String currency
    String date
    String divisionID
    String documentNumber
    String itemNumber
    String organizationID
    String soldToPartyID
    String sourceSystemID
    String statusCode
    String documentTypeCode
    String customerReference
    String typeCode
    String plantID
    String plantName
    String billToPartyID
    String billToPartyName
    String shipToPartyID
    String shipToPartyName
    String deliveryDate
    String materialNumber
    String materialDescription
    String quantity
    String uomCode
    String divisionName
    String organizationName
    String channelName
    String orderReason
    String rejectionReason
    String counterPartyID
    String counterPartyName
}

ArrayList getSales(Object salesorder) {
    salesArr = []
    for (salesOrder in salesorder) {
        salesArr.add(
                new Sales(
                        amount: salesOrder.opt("netamount"),
                        channelID: salesOrder.opt("distributionchannel"),
                        currency: salesOrder.opt("salesdocumentcurrency"),
                        date: toTransactionalDate(salesOrder.opt("salesorderdate").toString()),
                        divisionID: salesOrder.opt("organizationdivision"),
                        documentNumber: salesOrder.opt("salesorder"),
                        itemNumber: salesOrder.opt("salesorderitem"),
                        organizationID: salesOrder.opt("salesorganization"),
                        soldToPartyID: salesOrder.opt("soldtoparty"),
                        sourceSystemID: salesOrder.opt("logicalsystem"),
                        statusCode: salesOrder.opt("overallsdprocessstatus"),
                        documentTypeCode: salesOrder.opt("salesordertype"),
                        customerReference: salesOrder.opt("purchasingdocreferencebycust"),
                        typeCode: 2,
                        plantID : salesOrder.opt("plant"),
                        plantName : salesOrder.opt("plantname"),
                        billToPartyID : salesOrder.opt("billtoparty"),
                        billToPartyName : salesOrder.opt("billtopartyname"),
                        shipToPartyID : salesOrder.opt("shiptoparty"),
                        shipToPartyName : salesOrder.opt("shiptopartyname"),
                        deliveryDate : toTransactionalDate(salesOrder.opt("requesteddeliverydate").toString()),
                        materialNumber : salesOrder.opt("material"),
                        materialDescription : salesOrder.opt("materialdescription"),
                        quantity : new BigDecimal(salesOrder.opt("orderquantity")).round(new MathContext(2)),
                        uomCode : salesOrder.opt("orderquantityunit"),
                        divisionName : salesOrder.opt("divisionname"),
                        organizationName : salesOrder.opt("salesorganizationname"),
                        channelName : salesOrder.opt("distributionchannelname"),
                        orderReason : salesOrder.opt("sddocumentreason"),
                        rejectionReason : salesOrder.opt("salesdocumentrjcnreason"),
                        counterPartyID: salesOrder.opt("payerparty"),
                        counterPartyName: salesOrder.opt("payerpartyname"),
                )
        )
    }
    return salesArr
}

ArrayList getDescription(Object vmsvehicleinternalid) {
    dvhDescriptionArr = []
    if (vmsvehicleinternalid) {
        parser = new JsonSlurper()
        obj = parser.parseText(
                '''{
                    "short": "",
                    "long": "",
                    "language": "en"
                }'''
            )

        obj.short = vmsvehicleinternalid
        obj.long = vmsvehicleinternalid

        dvhDescriptionArr.add(obj)
    }
    return dvhDescriptionArr

}

String clearJson(String payloadObj) {
    rimSizePattern = Pattern.compile(new String('''(\"rimSize\":\\{\"value\":\"\",\"uom\":\"\"},)'''))
    odometerReadingPattern = Pattern.compile(new String('''(\"odometerReading\":\\{\"value\":\"\",\"uom\":\"\"},)'''))

    payloadObj = payloadObj.replace("null", '''""''')

    if (payloadObj.find(rimSizePattern)) {
        payloadObj = payloadObj.replaceAll(rimSizePattern, "")
    }

    if (payloadObj.find(odometerReadingPattern)) {
        payloadObj = payloadObj.replaceAll(odometerReadingPattern, "")
    }
    
    rimSizePattern = Pattern.compile(new String('''(\"rimSize\":\\{\"value\":\"0\",\"uom\":\"\"},)'''))
    odometerReadingPattern = Pattern.compile(new String('''(\"odometerReading\":\\{\"value\":\"0\",\"uom\":\"\"},)'''))

    payloadObj = payloadObj.replace("null", '''""''')

    if (payloadObj.find(rimSizePattern)) {
        payloadObj = payloadObj.replaceAll(rimSizePattern, "")
    }

    if (payloadObj.find(odometerReadingPattern)) {
        payloadObj = payloadObj.replaceAll(odometerReadingPattern, "")
    }
    
    return payloadObj
}

Object getVehicleValidationPayload(Object vehicleIdentifyingElementsObj, Object vehicleJSONObject) {
    obj =
            '''[ {
                "externalID": "''' + vehicleIdentifyingElementsObj.externalID + '''"
                },
                {
                "externalID": "''' + URLDecoder.decode(vehicleJSONObject.opt("vmsvehicleuuid"), "UTF-8") + '''"
                }
            ]'''
    return obj
}

Message processData(Message message) {

    requestBody = message.getBody(String.class)
    JSONObject vehicleJSONObject = XML.toJSONObject(requestBody).root.vehicle

    availabilityCode = "1"
    
    if(vehicleJSONObject.opt("vmsvehicleavailabilitystatus") == "") {
        availabilityCode = null
    } else if(vehicleJSONObject.opt("vmsvehicleavailabilitystatus") == "NA") {
        availabilityCode = "2"
    }


    JsonBuilder builder = new JsonBuilder()

    payload = builder {
        vehicleIdentifyingElements(
                externalID: vehicleJSONObject.opt("vmsdvhvehicleinternalid"),
                vin: vehicleJSONObject.opt("vehicleidentificationnumber").toString()
        )
        // Condition Test
        buildDate toDate(vehicleJSONObject.vmsvehicleproductiondatetime.toString())
        batchNumber vehicleJSONObject.opt("vmsvehiclebatch")
        plantID vehicleJSONObject.opt("plant")
        plantName vehicleJSONObject.opt("plantname")
        storageLocationID vehicleJSONObject.opt("storagelocation")
        storageLocationDescription vehicleJSONObject.opt("storagelocationname")
        availabilityCode availabilityCode
        sourceSystemID vehicleJSONObject.opt("logicalsystem")
        procurementCompleteTransmissionIndicator vehicleJSONObject.opt("purchaseorder_cti") == "X"
        vehicleSpecificationCompleteTransmissionIndicator vehicleJSONObject.opt("configuration_cti") == "X"
        invoiceCompleteTransmissionIndicator vehicleJSONObject.opt("invoice_cti") == "X"
        salesCompleteTransmissionIndicator vehicleJSONObject.opt("salesorder_cti") == "X"
        sourceSystemStatusCompleteTransmissionIndicator vehicleJSONObject.opt("status_cti") == "X"
        description getDescription(vehicleJSONObject.opt("vehicledescription"))
        modelSpecification(
                modelExternalID: vehicleJSONObject.opt("vmsdigitalvehiclehubmodel")
        )
        vehicleSpecification getVehicleSpecification(vehicleJSONObject)
        location(
                externalID: vehicleJSONObject.opt("vehiclelocation")
        )
        invoice getInvoices(vehicleJSONObject)
        procurement getProcurement(vehicleJSONObject.opt("purchaseorder"))
        sales getSales(vehicleJSONObject.opt("salesorder"))
        sourceSystemStatus getSourceSystemStatus(vehicleJSONObject.opt("status"))
    }

    payloadObj = new JsonBuilder(payload).toString()
    payloadObj = clearJson(payloadObj)

    message.setProperty("dvhVehicleExternalID", vehicleJSONObject.opt("vmsdvhvehicleinternalid"))
    message.setProperty("vehicleRequest", JsonOutput.prettyPrint(payloadObj))
    message.setProperty("vehicleValidationRequest", getVehicleValidationPayload(payload.vehicleIdentifyingElements, vehicleJSONObject))

    return message
}