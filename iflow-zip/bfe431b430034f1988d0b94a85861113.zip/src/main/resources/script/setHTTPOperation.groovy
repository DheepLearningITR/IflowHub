import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import java.net.URLDecoder;

def Message processData(Message message) {
    
    def body = message.getBody(String.class);
    def list = new JsonSlurper().parseText(body);
    def vehicleID = "";

    if (!list[0].externalID.isDuplicate && !list[1].externalID.isDuplicate) {
        message.setProperty("operation", "POST")
    } else {
        def vehicleIDList = [list[0].externalID.vehicleIdentifyingElements.id, list[1].externalID.vehicleIdentifyingElements.id];
        vehicleIDList.removeAll([null]);
        vehicleIDList.removeAll([""]);
        
        vehicleID = "id=" + vehicleIDList.get(0);
        message.setProperty("operation", "PATCH")
    }

    message.setProperty("dvhVehicleID", vehicleID)
    
    return message;
}