import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def entryModelIds = message.getProperty('signavioEntryModelIds')
	
    def toBeLoopedModelIds = message.getProperty('toBeLoopedModelIds')
    toBeLoopedModelIds.addAll(entryModelIds.split(";"))
    toBeLoopedModelIds.unique()

    message.setProperty('currentModelId', toBeLoopedModelIds.size() > 0 ? toBeLoopedModelIds.remove(0) : "")

    def nonExistSignavioModelIds = []
    message.setProperty('nonExistSignavioModelIds', nonExistSignavioModelIds)
    
    def nonUpdatedSignavioModelIds = []
    message.setProperty('nonUpdatedSignavioModelIds', nonUpdatedSignavioModelIds)
    
    Map signavioProcessMap = [:]
    message.setProperty('signavioProcessMap', signavioProcessMap)

    return message
}
