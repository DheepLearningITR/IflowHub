import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def signavioProcessMap = message.getProperty("signavioProcessMap")
    def toBeLoopedModelIds = signavioProcessMap.collect{entry -> entry.getKey()}

    if (toBeLoopedModelIds){
        message.setProperty("currentModelId", toBeLoopedModelIds.remove(toBeLoopedModelIds.size() - 1))
    } 
    message.setProperty("toBeLoopedModelIds", toBeLoopedModelIds)
    
    def modelUpdatedTimeMap = [:]
    message.setProperty("modelUpdatedTimeMap", modelUpdatedTimeMap)

    return message
}
