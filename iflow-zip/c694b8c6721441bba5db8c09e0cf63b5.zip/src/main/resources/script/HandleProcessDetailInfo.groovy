import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.Field

import java.text.SimpleDateFormat

@Field public static final String SIGNAVIO_DATE_FORMATTER = "yyyy-MM-dd HH:mm:ss Z"
@Field public static final String SIGNAVIO_PROCESS_NAMESPACE = 'http://b3mn.org/stencilset/bpmn2.0#'


def Message processData(Message message) {
    def signavioProcessMap = message.getProperty("signavioProcessMap")
    def toBeLoopModelIds = message.getProperty("toBeLoopedModelIds")
    def currentModelId = message.getProperty("currentModelId")
    def nonUpdatedSignavioModelIds = message.getProperty("nonUpdatedSignavioModelIds")

    def body = message.getBody(java.io.Reader)
    def processInfo = new JsonSlurper().parse(body)
    def dateFormat = new SimpleDateFormat(SIGNAVIO_DATE_FORMATTER)

    if (processInfo?.namespace?.equals(SIGNAVIO_PROCESS_NAMESPACE)) {
        def updatedInDataStore = message.getProperty("modelUpdatedAt")

        if (updatedInDataStore == "null" || dateFormat.parse(updatedInDataStore).before(dateFormat.parse(processInfo.updated))) {
            def modelUpdatedTimeMap = message.getProperty("modelUpdatedTimeMap")
            modelUpdatedTimeMap.put(currentModelId, processInfo.updated)
            setProcessInfo(signavioProcessMap.get(currentModelId), processInfo)
        } else {
            nonUpdatedSignavioModelIds.add(currentModelId)
            signavioProcessMap.remove(currentModelId)
        }
    } else {
        signavioProcessMap.remove(currentModelId)
    }

    if (toBeLoopModelIds) {
        message.setProperty('currentModelId', toBeLoopModelIds.remove(toBeLoopModelIds.size() - 1))
    } else {
        message.setProperty('currentModelId', '')
    }

    return message
}

def void setProcessInfo(process, processInfo) {
    process.name = processInfo.name
    process.description = processInfo.description
    process.type = processInfo.type
    process.created = new SimpleDateFormat(SIGNAVIO_DATE_FORMATTER).parse(processInfo.created)
}