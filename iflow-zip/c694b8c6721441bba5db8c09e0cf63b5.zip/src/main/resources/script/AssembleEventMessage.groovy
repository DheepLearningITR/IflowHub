import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.transform.Field

import java.text.SimpleDateFormat

@Field public static final String GRC_DATE_FORMATTER = "yyyy-MM-dd'T'HH:mm:ss'Z'"
@Field public static final String PROCESS_UPSERT_MESSAGE_TYPE = "sap.grc.ophsvc.Process.BatchUpsert.v1"
@Field public static final String TOPIC_FORMAT = "topic:%s/ce/%s"
@Field public static final String SEPERATOR = "/"

def Message processData(Message message) {
    def emNamespace = message.getProperty("emNamespace")
    def grcProcesses = message.getProperty("grcProcesses")
    def SAPMplCorrelationId = message.getHeader("SAP_MplCorrelationId", String.class)
    def modelUpdatedTimeMap = message.getProperty("modelUpdatedTimeMap")
    def currentGrcProcess = grcProcesses.remove(grcProcesses.size() - 1)
    
    def dataStoreEntryId = currentGrcProcess.items.get(0).externalId.substring(0, 32)
    def modelUpdatedTime = modelUpdatedTimeMap.get(dataStoreEntryId)
    message.setProperty("dataStoreEntryId", dataStoreEntryId)
    message.setProperty("modelUpdatedTime", modelUpdatedTime)

    def body = new EventMessageBody(currentGrcProcess)
    body.time = new SimpleDateFormat(GRC_DATE_FORMATTER).format(new Date())
    body.source = SEPERATOR + emNamespace
    body.type = PROCESS_UPSERT_MESSAGE_TYPE
    body.xsapcorrelationid = SAPMplCorrelationId
    
    def payload = [:]
    payload.body = JsonOutput.toJson(body)
    payload.topic = String.format(TOPIC_FORMAT, emNamespace, PROCESS_UPSERT_MESSAGE_TYPE.replace(".", SEPERATOR))
    message.setBody(JsonOutput.toJson(payload))

    return message
}

class EventMessageBody {
    String xsapcorrelationid
    String id
    String specversion = "1.0"
    String datacontenttype = "application/json"
    String contentType = "application/json"
    String time
    String type
    String source
    String Subject = "Process:Collection"
    Object data

    EventMessageBody(data) {
        this.id = UUID.randomUUID().toString()
        this.data = data
    }
}
