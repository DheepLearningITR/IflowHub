import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.CompileStatic
import groovy.transform.Field

@Field public static final String CUSTOM_ATTRIBUTE_PROCESS_ID = 'meta-grcprocessid'
@Field public static final String CUSTOM_ATTRIBUTE_PROCESS_DISPLAY_ID = 'meta-grcprocessdisplayid'
@Field public static final String MODEL_PREFIX = '/model/'
@Field public static final String TASK_STENCIL_ID = 'Task'

def Message processData(Message message) {
    def toBeLoopedModelIds = message.getProperty('toBeLoopedModelIds')
    def currentModelId = message.getProperty('currentModelId')
    def signavioProcessMap = message.getProperty('signavioProcessMap')
    
    def body = message.getBody(java.io.Reader)
    def model = new JsonSlurper().parse(body)

    if (model.errors) {
        def nonExistSignavioModelIds = message.getProperty('nonExistSignavioModelIds')
        nonExistSignavioModelIds.add(currentModelId)

        if (signavioProcessMap.containsKey(currentModelId)) {
            signavioProcessMap.remove(currentModelId)
        }
    } else {
        if (!signavioProcessMap.containsKey(currentModelId)) {
            signavioProcessMap.put(currentModelId, new SignavioProcess(currentModelId))
        }
        def currentProcess = signavioProcessMap.get(currentModelId)
        currentProcess.grcProcessId = model.properties[CUSTOM_ATTRIBUTE_PROCESS_ID]
        currentProcess.grcProcessDisplayId = model.properties[CUSTOM_ATTRIBUTE_PROCESS_DISPLAY_ID]

        getProcessesAndActivities(model, toBeLoopedModelIds, signavioProcessMap, currentProcess.activities)
    }

    if (toBeLoopedModelIds.size() > 0) {
        message.setProperty('currentModelId', toBeLoopedModelIds.remove(0))
    } else {
        message.setProperty('currentModelId', '')
    }

    return message
}

def void getProcessesAndActivities(model, toBeLoopedModelIds, signavioProcessMap, processActivities) {
    def properties = model.properties
    if (properties?.entry?.startsWith(MODEL_PREFIX)) {
        def childModelId = properties.entry.substring(MODEL_PREFIX.length())
        if (!signavioProcessMap.containsKey(childModelId)) {
            toBeLoopedModelIds.add(childModelId)
            signavioProcessMap.put(childModelId, new SignavioProcess(childModelId))
        }
    }
    
    if (model?.stencil?.id?.equals(TASK_STENCIL_ID)) {
        SignavioActivity activity =
                new SignavioActivity(properties.name, properties.documentation, model.resourceId)
        activity.grcProcessId = properties[CUSTOM_ATTRIBUTE_PROCESS_ID]
        activity.grcProcessDisplayId = properties[CUSTOM_ATTRIBUTE_PROCESS_DISPLAY_ID]
        processActivities.add(activity)
    }
    
    model.childShapes.each{ getProcessesAndActivities(it, toBeLoopedModelIds, signavioProcessMap, processActivities) }
}

@CompileStatic
class SignavioProcess {

    String name
    String description
    String type
    String modelId
    String grcProcessId
    String grcProcessDisplayId
    Date created
    List<SignavioActivity> activities

    SignavioProcess(String modelId) {
        this.modelId = modelId
        this.activities = []
    }
}

@CompileStatic
class SignavioActivity {
    
    String name
    String description
    String type = 'Activity'
    String linkedModelId
    String elementId
    String grcProcessId
    String grcProcessDisplayId

    SignavioActivity(String name, String description, String elementId) {
        this.name = name
        this.description = description
        this.elementId = elementId
    }
}