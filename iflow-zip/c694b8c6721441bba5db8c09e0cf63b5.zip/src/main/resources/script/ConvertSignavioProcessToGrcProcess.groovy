import com.sap.gateway.ip.core.customdev.util.Message
import groovy.transform.Field

import java.text.SimpleDateFormat

@Field public static final String GRC_DATE_FORMATTER = "yyyy-MM-dd'T'HH:mm:ss'Z'"
@Field public static final String DEFAULT_PROCESS_VALID_TO = "9999-12-31T00:00:00Z"
@Field public static final Date CURRENT_TIME = new Date()
@Field public static final String EXTERNAL_ID_SEPERATOR = "/"
@Field public static final String SIGNAVIO_PROCESS_URL_FORMAT = "%s/p/hub/model/%s"
@Field public static final String SIGNAVIO_ACTIVITY_URL_FORMAT = "%s/p/hub/model/%s/elements/%s"
@Field public static final String SIGNAVIO_DISPLAY_ID_FORMAT = "Signavio_%s_%s_%s"
@Field public static final String SOURCE_SYSTEM = "Signavio"
@Field public static final String PROCESS_TYPE = "Process"
@Field public static final String SUBPROCESS_TYPE = "Subprocess"
@Field public static final Integer index = 1
@Field public static final Integer PROCESS_UPSERT_BATCH_SIZE = 100

def Message processData(message) {
    def signavioProcessMap = message.getProperty("signavioProcessMap")
    def signavioHost = message.getProperty("signavioHost")

    List grcProcesses = []
    for (def signavioProcess : signavioProcessMap) {
        grcProcesses.addAll(convertToGrcProcesses(signavioProcess.value, signavioHost, signavioProcessMap))
    }

    message.setProperty("grcProcesses", grcProcesses)

    def messageLog = messageLogFactory.getMessageLog(message)
    def toBeSyncedModelIds = signavioProcessMap.collect{ entry -> entry.getKey() }

    messageLog.addAttachmentAsString("Import Process Job Summary",
    "Configured Signavio Folder Ids:" + message.getProperty("signavioFolderIds") + 
    "\nConfigured Signavio Model Ids:" + message.getProperty('signavioEntryModelIds') + 
    "\nNot Exist Signavio Folder Ids:" + message.getProperty('nonExistSignavioFolderIds') + 
    "\nNot Exist Signavio Model Ids:" + message.getProperty('nonExistSignavioModelIds') + 
    "\nNot changed Signavio Model Ids: "+ message.getProperty("nonUpdatedSignavioModelIds") + 
    "\nSynced signavio Process Map:" + toBeSyncedModelIds, 
    "text/plain")
    
    return message
}

static List convertToGrcProcesses(signavioProcess, signavioHost, signavioProcessMap) {
    List grcProcesses = []
    def grcProcess = convertSignavioProcessToGrcProcess(signavioProcess, signavioHost)
    grcProcesses.add(grcProcess)

    for (def activity : signavioProcess.activities) {
        if (!signavioProcessMap.containsKey(activity.linkedModelId)) {
            grcProcesses.add(convertSignavioActivityToGrcProcess(activity, signavioProcess, signavioHost))
        }
    }
    List grcProcessBatchs = []
    for (int i = 0; i < grcProcesses.size(); i += PROCESS_UPSERT_BATCH_SIZE) {
        GrcProcessBatch grcProcessBatch = new GrcProcessBatch()
        grcProcessBatch.items.addAll(grcProcesses.subList(i, Math.min(i + PROCESS_UPSERT_BATCH_SIZE, grcProcesses.size())))
        for (int j = 0; j < grcProcessBatch.items.size(); j++) {
            grcProcessBatch.items[j].index = j + 1
        }
        grcProcessBatchs.add(grcProcessBatch)
    }
    return grcProcessBatchs
}

static GrcProcess convertSignavioProcessToGrcProcess(signavioProcess, signavioHost) {
    GrcProcess grcProcess = convertCommonFields(signavioProcess)

    grcProcess.validFrom = new SimpleDateFormat(GRC_DATE_FORMATTER).format(signavioProcess.created)
    grcProcess.type = PROCESS_TYPE
    grcProcess.externalId = signavioProcess.modelId
    grcProcess.externalUrl = String.format(SIGNAVIO_PROCESS_URL_FORMAT, signavioHost, signavioProcess.modelId)
    return grcProcess
}

static GrcProcess convertSignavioActivityToGrcProcess(activity, signavioProcess, signavioHost) {
    GrcProcess grcProcessActivity = convertCommonFields(activity)

    grcProcessActivity.validFrom = new SimpleDateFormat(GRC_DATE_FORMATTER).format(signavioProcess.created)
    grcProcessActivity.type = SUBPROCESS_TYPE
    grcProcessActivity.externalId = signavioProcess.modelId + EXTERNAL_ID_SEPERATOR + activity.elementId
    grcProcessActivity.externalUrl = String.format(SIGNAVIO_ACTIVITY_URL_FORMAT, signavioHost, signavioProcess.modelId, activity.elementId)
    return grcProcessActivity
}

static GrcProcess convertCommonFields(signavioProcess) {
    GrcProcess grcProcess = new GrcProcess()

    grcProcess.id = signavioProcess.grcProcessId ?: null
    grcProcess.displayId = signavioProcess.grcProcessDisplayId ?: String.format(SIGNAVIO_DISPLAY_ID_FORMAT, new SimpleDateFormat(GRC_DATE_FORMATTER).format(CURRENT_TIME).substring(0, 10), CURRENT_TIME.getTime(), index++)
    grcProcess.name = signavioProcess.name != null && signavioProcess.name.length() > 255 ? signavioProcess.name.substring(0, 255) : signavioProcess.name
    grcProcess.description = signavioProcess.description != null && signavioProcess.description.length() > 1024 ? signavioProcess.description.substring(0, 1024) : signavioProcess.description
    grcProcess.validTo = DEFAULT_PROCESS_VALID_TO
    grcProcess.externalType = signavioProcess.type
    grcProcess.sourceSystem = SOURCE_SYSTEM
    return grcProcess
}

class GrcProcessBatch {
    List<GrcProcess> items

    GrcProcessBatch() {
        items = []
    }

}

class GrcProcess {
    String index
    String id
    String displayId
    String name
    String description
    String type
    String validFrom
    String validTo
    String externalId
    String externalUrl
    String externalType
    String sourceSystem

    GrcProcess() {}
}
