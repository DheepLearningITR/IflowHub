import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def toBeLoopedFolderIds = message.getProperty('toBeLoopedFolderIds')
    def currentFolderId = message.getProperty('currentFolderId')
    def toBeLoopedModelIds = message.getProperty('toBeLoopedModelIds')

    def body = message.getBody(java.io.Reader)
    def model = new JsonSlurper().parse(body)

    if (!(model instanceof ArrayList) && model.errors) {
        def nonExistSignavioFolderIds = message.getProperty('nonExistSignavioFolderIds')
        nonExistSignavioFolderIds.add(currentFolderId)
    } else {
        for (item in model) {
            if (item?.rel == "dir") {
                toBeLoopedFolderIds.add(item.href.substring(item.href.lastIndexOf('/') + 1))
            }else if (item?.rel == "mod") {
                toBeLoopedModelIds.add(item.href.substring(item.href.lastIndexOf('/') + 1))
            }
        }
    }

    if (toBeLoopedFolderIds) {
        message.setProperty('currentFolderId', toBeLoopedFolderIds.remove(toBeLoopedFolderIds.size() - 1))
    } else {
        message.setProperty('currentFolderId', '')
    }
    
    return message
}
