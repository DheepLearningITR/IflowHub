import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def toBeLoopedModelIds = []
    message.setProperty('toBeLoopedModelIds', toBeLoopedModelIds)

    def nonExistSignavioFolderIds = []
    message.setProperty('nonExistSignavioFolderIds', nonExistSignavioFolderIds)

    def signavioFolderIds = message.getProperty('signavioFolderIds')

    def toBeLoopedFolderIds = []
    toBeLoopedFolderIds.addAll(signavioFolderIds.split(";"))

    message.setProperty('toBeLoopedFolderIds', toBeLoopedFolderIds)
    message.setProperty('currentFolderId', toBeLoopedFolderIds.size() > 0 ? toBeLoopedFolderIds.remove(0) : "")

    return message
}