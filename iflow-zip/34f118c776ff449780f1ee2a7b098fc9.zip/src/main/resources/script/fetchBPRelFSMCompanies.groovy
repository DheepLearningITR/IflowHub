import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.asdk.datastore.DataStoreService
import com.sap.it.api.asdk.runtime.Factory

def Message processData(Message message) {
    def body = message.getBody(java.lang.String)
    def query = new XmlParser().parseText(body)
    def valueMappingApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def allfsmCompanyList;
    
    def getAllCompanies = {
        def messageLog = messageLogFactory.getMessageLog(message)
        def DSservice = new Factory(DataStoreService.class).getService()
        // get the FSM Company List from data store
        def dsEntry = DSservice.get("FSMCompanyList", 'FSMCompanyList')?DSservice.get("FSMCompanyList", 'FSMCompanyList'):'NA'
		if (dsEntry != 'NA'){
			def result = new String(dsEntry.getDataAsArray())
			allfsmCompanyList = new XmlParser().parseText(result)
		}else{
		   allfsmCompanyList = new XmlParser().parseText("<FSMMultiCompany><FSMCompany>NA|NA</FSMCompany></FSMMultiCompany>")
		}
    }
    
    /*START: Logic to handle all FSM Company mapping*/
    def allCompanies = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', 'BP', 'FSM', 'AccountIDCompanyID');
    if (allCompanies == 'ALLCOMPANIES') {
		getAllCompanies();
		
        query.BusinessPartnerRelationshipSUITEReplicateRequestMessage.each { bpMessage ->
            bpMessage.BusinessPartnerRelationship.each { bp ->
                bp.append(allfsmCompanyList)
            }
        }
        /*END: Logic to handle all FSM Company mapping*/
			

    }else{

        query.BusinessPartnerRelationshipSUITEReplicateRequestMessage.each { bpMessage ->
            bpMessage.BusinessPartnerRelationship.each { bp ->
                def mcXML = new XmlParser().parseText("<FSMMultiCompany></FSMMultiCompany>")
                def map = message.getProperties();
                def fsmFromValueMap = null;            
                def bpRoles = bp.A_BusinessPartnerType.to_BusinessPartnerRole.A_BusinessPartnerRoleType.BusinessPartnerRole*.text()

                //function to append account and company to incoming message
                def appendAccountCompany = { AcctComp ->
                    def entries = AcctComp.tokenize(":")
                    entries.each { entry ->
                        def (account, companies) = entry.split("\\|")
                        def companyList = companies.split(",")
                        
                        companyList.each { company ->
	    			        def fsmXml = new XmlParser().parseText("<FSMCompany>${account}|${company}</FSMCompany>")
	    			        mcXML.append(fsmXml)
                        }
                    }
                }
                
                bpRoles.each{ bpRoleCode ->
                    /*set the FSM company and account as the default configured for the Org BP*/
                    if(bpRoleCode == "BUP004"){
                        def fsmAccountID = map.get("X-Account-ID") ?: "NA"
                        def fsmCompanyID = map.get("X-Company-ID") ?: "NA"
                        fsmFromValueMap = fsmAccountID + "|" + fsmCompanyID
                        appendAccountCompany(fsmFromValueMap);
                    }
                    
                    /*START: Logic to handle all FSM Company mapping*/
                    def bpAllKeyMap = "BP|BPROLE|${bpRoleCode}"
                    fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', bpAllKeyMap, 'FSM', 'AccountIDCompanyID')
                    if(fsmFromValueMap == 'ALLCOMPANIES'){
                        getAllCompanies();
                    	allfsmCompanyList.FSMCompany.each { fsmCompany ->
                            mcXML.append(fsmCompany)
                        }
                    }
                    /*END: Logic to handle all FSM Company mapping*/
        
                    /*identify the FSM company details using Sales Area rule type*/
                    bp.A_BusinessPartnerType.to_Customer.A_CustomerType.to_CustomerSalesArea.A_CustomerSalesAreaType.each { sa ->                
                        def salesArea = "${sa.SalesOrganization.text()}|${sa.DistributionChannel.text()}|${sa.Division.text()}"
                        def bpKeyMap = "BP|BPROLE|${bpRoleCode}|SALESAREA|${salesArea}"
                        
                        fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', bpKeyMap, 'FSM', 'AccountIDCompanyID')
                        if(fsmFromValueMap){
	    		    		appendAccountCompany(fsmFromValueMap);
	    		    	}
                    }
                    
                    /*identify the FSM company details using Customer CompanyCode rule type*/
                    bp.A_BusinessPartnerType.to_Customer.A_CustomerType.to_CustomerCompany.A_CustomerCompanyType.each { pg ->
                        def companyCode = "${pg.CompanyCode.text()}"
                        def bpKeyMap = "BP|BPROLE|${bpRoleCode}|COMPANYCODE|${companyCode}"
                        
                        fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', bpKeyMap, 'FSM', 'AccountIDCompanyID')
                        if(fsmFromValueMap){
	    		    		appendAccountCompany(fsmFromValueMap);
	    		    	}
                    }
        
                    /*identify the FSM company details using Supplier CompanyCode rule type*/
                    bp.A_BusinessPartnerType.to_Supplier.A_SupplierType.to_SupplierCompany.A_SupplierCompanyType.each { pg ->
                        def companyCode = "${pg.CompanyCode.text()}"
                        def bpKeyMap = "BP|BPROLE|${bpRoleCode}|COMPANYCODE|${companyCode}"
                        
                        fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', bpKeyMap, 'FSM', 'AccountIDCompanyID')
                        if(fsmFromValueMap){
	    		    		appendAccountCompany(fsmFromValueMap);
	    		    	}
                    }
        
                    /*identify the FSM company details using Supplier PuchasingOrg rule type*/
                    bp.A_BusinessPartnerType.to_Supplier.A_SupplierType.to_SupplierPurchasingOrg.A_SupplierPurchasingOrgType.each { pg ->
                        def purchaseOrg = "${pg.PurchasingOrganization.text()}"
                        def bpKeyMap = "BP|BPROLE|${bpRoleCode}|PURCHASEORG|${purchaseOrg}"
                        
                        fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', bpKeyMap, 'FSM', 'AccountIDCompanyID')
                        if(fsmFromValueMap){
	    		    		appendAccountCompany(fsmFromValueMap);
	    		    	}
                    }
    
                    /*identify the FSM company details using Supplier PuchasingGroup rule type*/
                    bp.A_BusinessPartnerType.to_Supplier.A_SupplierType.to_SupplierPurchasingOrg.A_SupplierPurchasingOrgType.each { pg ->
                        def purchaseGroup = "${pg.PurchasingGroup.text()}"
                        def bpKeyMap = "BP|BPROLE|${bpRoleCode}|PURCHASEGROUP|${purchaseGroup}"
                        
                        fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', bpKeyMap, 'FSM', 'AccountIDCompanyID')
                        if(fsmFromValueMap){
	    		    		appendAccountCompany(fsmFromValueMap);
	    		    	}
                    }
                    
                    /****Handle Specific Field mapping scenaiors -- START ****/
                    def BPspecfieldsize = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', 'BPSPECSIZE', 'FSM', 'AccountIDCompanyID')
                    if (BPspecfieldsize){
				        def fieldmap = [:]
                        (1..BPspecfieldsize.toInteger()).each { i ->
                            //get xpath value of each specific field
				        	def fieldnum = "BPFIELD"+i
				        	fieldmap[fieldnum] = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', fieldnum, 'FSM', 'AccountIDCompanyID')					
				        	if (fieldmap[fieldnum]){
				        		// Search specific XPath expression
				        		def splitType = fieldmap[fieldnum].split("\\|")
                                def fieldpath = splitType.size() > 1 ? splitType[1] : fieldmap[fieldnum]
				        		def searchxpath = '/BusinessPartnerRelationship/A_BusinessPartnerType' + fieldpath
				        		
				        		// Define a function to find nodes based on XPath
				        		def findNodes = { node, path ->
				        			def parts = path.tokenize('/')
				        			parts.inject([node]) { list, part ->
				        				list.findAll { it.name() == part }.collect { it.children() }.flatten()
				        			}
				        		}
				        		
				        		// Find nodes based on XPath
				        		def nodes = findNodes(bp, searchxpath)
				        		
				        		// get the Value Mappings based on the specific fields and append the FSM companies
				        		nodes.each { node ->
				        			def bpKeyMap = "BP|BPROLE|${bpRoleCode}|${fieldnum}|${node}"
                                    fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', bpKeyMap, 'FSM', 'AccountIDCompanyID')
                                    if(fsmFromValueMap){
	    		        		        appendAccountCompany(fsmFromValueMap);
	    		        	        }
	    		        	        
	    		        	        def bpspecKeyMap = "BP|||${fieldnum}|${node}"
                                    specfsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', bpspecKeyMap, 'FSM', 'AccountIDCompanyID')
                                    if(specfsmFromValueMap){
	    		        		        appendAccountCompany(specfsmFromValueMap);
	    		        	        }
				        		}
				        	}				
				        }
                    }
                    /****Handle Specific Field mapping scenaiors -- END ****/
                }
	    		
	    		if (!mcXML.FSMCompany)
	    		{
	    			def fsmXml = new XmlParser().parseText("<FSMCompany>NA|NA</FSMCompany>")
	    			mcXML.append(fsmXml)
	    		}
    
                bp.append(mcXML)
            }
        }
    }

    def FSMCompanyData = XmlUtil.serialize(query)
    message.setBody(FSMCompanyData)
    return message
}
