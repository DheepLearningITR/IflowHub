import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import com.sap.it.api.asdk.datastore.*
import com.sap.it.api.asdk.runtime.*

def Message processData(Message message) {
	/*this script is to fetch the Contact message from CPI datastore and combine the contacts in bulk*/
    def body = message.getBody(java.lang.String)
    def query = new XmlParser().parseText(body)
    def contactXML = new XmlParser().parseText("<Contact></Contact>")
    def messageLog = messageLogFactory.getMessageLog(message)
    
    //introduce delay so that contact creation in CPI DS
    sleep(5000);
    
    def DSservice = new Factory(DataStoreService.class).getService()

    query.BusinessPartnerRelationshipSUITEReplicateRequestMessage.each { bpMessage ->
        bpMessage.BusinessPartnerRelationship.each { bp ->
            def contactID = bp.RelationshipBusinessPartnerInternalID.text()			
            
            if (DSservice != null) {
                // Read data store entry via Contact ID
                def dsEntry = DSservice.get("BPContacts", contactID)?DSservice.get("BPContacts", contactID):'NA'
				if (dsEntry != 'NA'){
					def result = new String(dsEntry.getDataAsArray())
					def contactData = new XmlParser().parseText(result)
					contactXML.append(contactData.CP)
				}else{
					messageLog.addCustomHeaderProperty("ContactDSNotFound",contactID)
				}
            }
        }
    }

    message.setBody(XmlUtil.serialize(contactXML))
    return message
}