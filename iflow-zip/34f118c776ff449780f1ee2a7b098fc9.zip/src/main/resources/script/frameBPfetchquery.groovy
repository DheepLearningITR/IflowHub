import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {
    def body = message.getBody()
    def valueMappingApi = ITApiFactory.getApi(ValueMappingApi.class, null)

    // Set standard BP query 
    def select = "BusinessPartner,to_BusinessPartnerRole/BusinessPartnerRole,to_Customer/to_CustomerCompany/CompanyCode,to_Customer/to_CustomerSalesArea/DistributionChannel,to_Customer/to_CustomerSalesArea/SalesOrganization,to_Customer/to_CustomerSalesArea/Division,to_Supplier/to_SupplierCompany/CompanyCode,to_Supplier/to_SupplierPurchasingOrg/PurchasingOrganization,to_Supplier/to_SupplierPurchasingOrg/PurchasingGroup"
    def expand = "to_BusinessPartnerRole,to_Customer/to_CustomerCompany,to_Customer,to_Customer/to_CustomerSalesArea,to_Supplier/to_SupplierCompany,to_Supplier,to_Supplier/to_SupplierPurchasingOrg"
    
    // Check for specific field mapping of BP in value mapping and append those paths to the select and expand part of the query
    def BPspecfieldsize = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', 'BPSPECSIZE', 'FSM', 'AccountIDCompanyID')
    if (BPspecfieldsize) {
        def selectArray = []
        def expandArray = []

        (1..BPspecfieldsize.toInteger()).each { i ->
            def fieldnum = "BPFIELD${i}"
            def fieldmap = valueMappingApi.getMappedValue('S4HANA', 'KeyMap', fieldnum, 'FSM', 'AccountIDCompanyID')
            
            if (fieldmap && fieldmap.startsWith("ODATA|")) {
                
                def framedpath = fieldmap.tokenize("|")[1].startsWith('/') ? fieldmap.tokenize("|")[1][1..-1] : fieldmap.tokenize("|")[1]
                def selectPaths = framedpath.split('/').findAll { !(it.startsWith('A_') && it.endsWith('Type')) }.join('/')
                selectArray.addAll(selectPaths)
                
                def exPaths = framedpath.split("/").findAll { !(it.startsWith('A_') && it.endsWith('Type')) }
                def expandPaths = exPaths[0..<exPaths.size() - 1].collect { it.split("/").findAll { !(it.startsWith("A_") && it.endsWith("Type")) }.join("/") }
                expandArray.addAll(expandPaths)
            }
        }

        selectArray = selectArray.unique()
        expandArray = expandArray.unique()

        select += "," + selectArray.join(",")
        expand += "," + expandArray.join(",")
    }

    message.setProperty("selectquery", select)
    message.setProperty("expandquery", expand)

    return message
}
