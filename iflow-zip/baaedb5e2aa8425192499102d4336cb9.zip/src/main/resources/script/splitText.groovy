import com.sap.it.api.mapping.*;

//This method splits a string based on character length, expects two input parameters: Source field which needs to be split(textLines) 
//and number of characters after which it has to be split(chunkSize)

public void splitText(String[] textLines, int[] chunkSize, Output output){

	for(String textLine: textLines){
        int arraySize = (int) Math.ceil(textLine.length() / chunkSize[0]);
 
    	String[] returnArray = new String[arraySize];
 
    	int index = 0;
    	for(int i = 0; i < textLine.length(); i = i+chunkSize[0])
    	{
        	if(textLine.length() - i < chunkSize[0])
        	{
            returnArray[index++] = textLine.substring(i);
        	} 
        	else
        	{
            returnArray[index++] = textLine.substring(i, i+chunkSize[0]);
        	}
    	}

        for(String value: returnArray)
        {
        	output.addValue(value);
        }        
	} 
}