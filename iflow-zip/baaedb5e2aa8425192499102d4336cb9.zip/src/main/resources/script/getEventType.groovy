import com.sap.it.api.mapping.*;

def String getEventType(String input){
	def query = new XmlSlurper().parseText(input);
	String out;
	
	if (query.eventType.size() == 0) {
	    out = 'false';
	} else {
	    out = 'true';
	}
    
	return out;
}
