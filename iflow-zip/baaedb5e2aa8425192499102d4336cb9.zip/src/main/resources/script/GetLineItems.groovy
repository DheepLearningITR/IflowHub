import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def query = new XmlSlurper().parseText(body);
    def map = message.getProperties();
    String param = "(";
    ArrayList Item_IDs = [];
    
    query.data.activities.materials.each {
        if(it.item.externalId.text() != '') {
            Item_IDs.add(it.item.externalId.text());
        }
    }
    
    Item_IDs.each {param += "\'" + it + "\'" + ","}
    param = param.substring(0, param.length()-1);
    param += ")";
    
    String newJson="{}";
    def jsonSlurper = new JsonSlurper();
    def newJsonObject = jsonSlurper.parseText(newJson);
    
    String queryContent = "SELECT i.externalId, i.unitOfMeasure FROM Item i WHERE i.externalId IN" + param;
    newJsonObject.put("query", queryContent)
    
    message.setBody(JsonOutput.toJson(newJsonObject));
    return message;
}
