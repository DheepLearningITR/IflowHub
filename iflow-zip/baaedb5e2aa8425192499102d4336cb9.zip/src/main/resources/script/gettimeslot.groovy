import com.sap.it.api.mapping.*;

import com.sap.it.api.mapping.MappingContext;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.text.*;

def String getTimeslot(String startDateTime, String endDateTime) {

    SimpleDateFormat ymdhms = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    Date startdatetime = ymdhms.parse(startDateTime);
    Date enddatetime = ymdhms.parse(endDateTime);
    
    long timeslotinhours = Math.abs(enddatetime.getTime() - startdatetime.getTime());
    long slot = TimeUnit.HOURS.convert(timeslotinhours, TimeUnit.HOURS);

    return timeslotinhours;

}