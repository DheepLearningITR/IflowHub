import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def parsedObj = new JsonSlurper().parseText(body);
    def map = message.getProperties();
    HashMap unitOfMeasure = new HashMap<String,String>();
    
    parsedObj.data.each{
        unitOfMeasure.put(it.i.externalId, it.i.unitOfMeasure);
    }

    message.setProperty("UnitOfMeasure", unitOfMeasure);
    message.setBody(map.Item_Payload);
    return message;
}
