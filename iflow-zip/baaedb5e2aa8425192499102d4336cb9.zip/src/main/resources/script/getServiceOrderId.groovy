import com.sap.it.api.mapping.*;

def String customFunc(String externalId){
    String[] str = externalId.split("/|_");
    
	return str[0]; 
}
