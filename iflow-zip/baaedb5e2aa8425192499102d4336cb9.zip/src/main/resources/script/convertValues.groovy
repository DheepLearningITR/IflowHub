import com.sap.it.api.mapping.*;
import java.text.DecimalFormat;


def String convertValues(String duration,MappingContext context){
    
    
    String value = context.getProperty("Actual_Duration_Unit");
    double slot;
    if(value.equals("H"))
       {
           
           slot=Double.parseDouble(duration)/3600000;
           duration=Double.toString(slot);
          
       }
    else{
          slot=Double.parseDouble(duration)/60000;
          duration=Double.toString(slot);
    } 
    
    
	return duration; 
}