import com.sap.it.api.mapping.*;

import com.sap.it.api.mapping.MappingContext;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.text.*;

def String getDateTime(String DateTime) {

    SimpleDateFormat ymdhms = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    Date datetime = ymdhms.parse(DateTime);
    String newdate = datetime.format("yyyyMMddHHmmss")
    return newdate;

}