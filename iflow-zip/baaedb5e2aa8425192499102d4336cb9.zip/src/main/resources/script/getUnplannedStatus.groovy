import com.sap.it.api.mapping.*;

def String getUnplannedStatus(String objVal, MappingContext context){
    String value = context.getHeader("Update_Unplanned_Status");
    
    if(value.equalsIgnoreCase("Yes")){
        objVal="true";
    }
    else{
        objVal="false";
    }
    
	return objVal; 
}
