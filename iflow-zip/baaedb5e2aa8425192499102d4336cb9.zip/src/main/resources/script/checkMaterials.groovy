import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def query = new XmlSlurper().parseText(body);
    
    query.data.activities.each {
        if(it.materials.text() == ''){
            it.materials.replaceNode { };
        }
    }
    def xml = XmlUtil.serialize(query);
    message.setBody(xml);
    
    return message;
}
