import com.sap.it.api.mapping.*;


def String getIndustryClassificationSystemCode(String propertyName, MappingContext context) {
    
    def propertyValue = context.getProperty("P_IndustryClassificationSystemCode")
    return propertyValue
}

def String setSOAPMessageID(String id,  MappingContext context){
    context.setHeader("SapMessageIdEx", id)
	return id 
}

def String calculateChangeOrdinalNumberValue(String arg1){
                
    String changeOrdinalNumberValue = arg1.replace("T", "")
                .replace("Z", "")
                .replace("-", "")
                .replace(":", "")
                .replace(".", "")

    if (changeOrdinalNumberValue.length() >=20)
            return changeOrdinalNumberValue.substring(0,20)
    else
        return changeOrdinalNumberValue            
    
}