import groovy.json.JsonSlurper
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    
    
    def body = message.getBody(String.class)

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)
    


    json.to_Item.each {


        it.to_PricingElement.add([
                "ConditionRateValue": it.Discount,
                "ConditionType": it.DiscountConditionType
        ])
    
        it.remove("Discount")
        it.remove("DiscountConditionType")
    }

    message.setBody(JsonOutput.toJson(json))

    return message
}

