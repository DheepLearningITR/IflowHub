
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;

/* Log incoming request payload */

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    
    message.getProperties().put("uuid", java.util.UUID.randomUUID());
     
    return message;
}
