import com.sap.it.api.mapping.*;
import java.util.UUID;

def String randomUUID(String isUpperCased){
    def uuid = UUID.randomUUID().toString()
    return isUpperCased.toLowerCase()=="true" ? uuid.toUpperCase() : uuid;
}