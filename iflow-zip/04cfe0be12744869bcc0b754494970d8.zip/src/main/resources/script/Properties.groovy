import com.sap.it.api.mapping.*;

def String getProperty(String propertyName, MappingContext context){
    return context.getProperty(propertyName)?.trim();
}