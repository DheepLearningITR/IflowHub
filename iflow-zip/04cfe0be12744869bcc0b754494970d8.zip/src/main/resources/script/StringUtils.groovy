import com.sap.it.api.mapping.*;

def String substringBeforeLast(String str, String seperator){
    str = str.trim()
	def splitStrs = str.split(seperator)
	return splitStrs[splitStrs.size()-2]
}

def String substringAfterLast(String str, String seperator){
    str = str.trim()
	def splitStrs = str.split(seperator)
	return splitStrs[splitStrs.size()-1]
}