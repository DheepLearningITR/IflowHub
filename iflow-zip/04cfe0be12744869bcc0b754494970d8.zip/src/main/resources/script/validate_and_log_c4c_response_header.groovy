import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        
        def map = message.getHeaders();
        def header = "";
        map.each{ k, v -> header=header+"${k}:${v}\n" }
        
        messageLog.addAttachmentAsString("Header", header, "text");

    }
    
    return message;
    
}