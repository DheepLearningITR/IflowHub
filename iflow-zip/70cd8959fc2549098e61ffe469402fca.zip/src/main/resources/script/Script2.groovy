import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
def Message processData(Message message) {
       def source = message.getBody(java.lang.String) as String;
       def root = new XmlSlurper().parseText(source);
       String idfactura = message.getProperty( 'idfact' );
       String isincoming = message.getProperty( 'IsIncoming' );
       String temp = "";
       if(isincoming == false)
       {
       for( def idfac: root.RegistroRespuestaConsultaLRFacturasEmitidas)
       {
            temp = "<NumSerieFacturaEmisor>" + idfac.IDFactura.NumSerieFacturaEmisor.toString() + "</NumSerieFacturaEmisor>";
            if( !(idfactura.contains(temp)))
            {
                idfac.replaceNode{ };
            }
            
       } 
       }
       else
       {
       for( def idfac: root.RespuestaConsultaLRFacturasRecibidas)
       {
            temp = "<NumSerieFacturaEmisor>" + idfac.IDFactura.NumSerieFacturaEmisor.toString() + "</NumSerieFacturaEmisor>";
            if( !(idfactura.contains(temp)))
            {
                idfac.replaceNode{ };
            }
            
       }           
           
       }
       
    String outxml = groovy.xml.XmlUtil.serialize( root );   
    message.setBody(outxml);   
    return message;
}