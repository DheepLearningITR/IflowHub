import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.IOException;
import java.util.Map;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
	
	def map = message.getProperties();
	def ex = map.get("CamelExceptionCaught");
	if (ex!=null){
			String xml = ex.getDetail() as String;
			String ErrorDesc = ex.getMessage() as String;
			def detail = new XmlSlurper().parseText(xml);
		    def Code = detail.ProcessingFault.Code.text();
		    def ParamDetail = detail.ProcessingFault.Message.text();
		    message.setProperty("Code",Code);
		    message.setProperty("ParamDetail",ParamDetail);
	}

    return message;

}