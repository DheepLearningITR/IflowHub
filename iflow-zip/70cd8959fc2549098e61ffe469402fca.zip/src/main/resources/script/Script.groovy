import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
def Message processData(Message message) {
       def source = message.getBody(java.lang.String) as String;
       def root = new XmlSlurper().parseText(source);
       String idfactura = "";
       for( def idfac: root.FiltroConsulta.IDFactura)
       {
            idfactura = idfactura + "<NumSerieFacturaEmisor>" + idfac.NumSerieFacturaEmisor.toString() + "</NumSerieFacturaEmisor>";
            idfac.replaceNode{ };
       }
       message.setProperty("idfact",idfactura);
       String outxml = groovy.xml.XmlUtil.serialize( root );   
    message.setBody(outxml);   
       return message;
}    