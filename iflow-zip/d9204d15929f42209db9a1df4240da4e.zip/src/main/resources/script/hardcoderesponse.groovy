import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Hardcoded response
    def hardcodedResponse = [
        "emails": [
            [
                "email": "supplier@example.com",
                "firstName": "John",
                "lastName": "Doe"
            ],
            [
                "email": "contact@example.com",
                "firstName": "Job",
                "lastName": "Smith"
            ]
        ]
    ]

    // Convert the hardcoded response to JSON
    def jsonResponse = new groovy.json.JsonBuilder(hardcodedResponse).toPrettyString()

    // Set the JSON response as the message body
    message.setBody(jsonResponse)
    
    // Set content type to application/json
    message.setHeader("Content-Type", "application/json")
    
    return message
}