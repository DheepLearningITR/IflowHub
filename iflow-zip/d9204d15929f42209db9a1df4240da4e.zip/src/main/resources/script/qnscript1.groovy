import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.*;
import groovy.json.JsonBuilder;
import groovy.lang.*;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String);
       def jsonSlurper = new JsonSlurper()
       def object = jsonSlurper.parseText(body.toString());
       Double quantity=Double.parseDouble(object.quantity);
	   def bostatuses=object.businessObjectStatuses;
	   def list=[];
	   def payload;
       def identifier=object.identifier;
       def qnType=object.qnType;
       def unit=object.unit;
       def purchaseOrderNumber=object.purchaseOrderNumber;
       def purchaseOrderItem=object.purchaseOrderItem;
       def supplierCode=object.supplierCode;
       def personResponsibleCode=object.personResponsibleCode;
       def materialCode=object.materialCode;
       def plantCode=object.plantCode;
       def purchaseOrganisationCode=object.purchaseOrganisationCode;
       def referenceNumber=object.referenceNumber;
       def defect=object.defect;
       def defectlist=[];
       def subjectCode_code=object.subjectCode_code;
	   def subjectCode_subjectCodeGroup_code=object.subjectCode_subjectCodeGroup_code;
	   def processDescription=object.processDescription;
		
	   def json = new JsonBuilder();
	   //If both Defects and BOStatuses are multiple
	   if (bostatuses instanceof ArrayList && defect instanceof ArrayList) {
		       payload= json identifier:identifier, qnType:qnType, quantity:quantity, unit:unit, purchaseOrderNumber:purchaseOrderNumber, purchaseOrderItem:purchaseOrderItem, supplierCode:supplierCode, personResponsibleCode:personResponsibleCode, materialCode:materialCode, //createdBy:createdBy,
		plantCode:plantCode, purchaseOrganisationCode:purchaseOrganisationCode, referenceNumber:referenceNumber, defect:defect, businessObjectStatuses:bostatuses,
		subjectCode_code:subjectCode_code,subjectCode_subjectCodeGroup_code:subjectCode_subjectCodeGroup_code,processDescription:processDescription
		
	   }else{
	       //If any of Defects and BOStatuses are multiple
	       	   if(bostatuses instanceof ArrayList || defect instanceof ArrayList){
	       	       //If only BOStatuses is multiple
	            if(bostatuses instanceof ArrayList){
	                defectlist.add(defect);
	                 payload= json identifier:identifier, qnType:qnType, quantity:quantity, unit:unit, purchaseOrderNumber:purchaseOrderNumber, purchaseOrderItem:purchaseOrderItem, supplierCode:supplierCode, personResponsibleCode:personResponsibleCode, materialCode:materialCode, //createdBy:createdBy,
		                 plantCode:plantCode, purchaseOrganisationCode:purchaseOrganisationCode, referenceNumber:referenceNumber, defect:defectlist, businessObjectStatuses:bostatuses,
		                 subjectCode_code:subjectCode_code,subjectCode_subjectCodeGroup_code:subjectCode_subjectCodeGroup_code,processDescription:processDescription
	            }else { 
	                //If only defects is multiple
	                        list.add(bostatuses);
                           payload= json identifier:identifier, qnType:qnType, quantity:quantity, unit:unit, purchaseOrderNumber:purchaseOrderNumber, purchaseOrderItem:purchaseOrderItem, supplierCode:supplierCode, personResponsibleCode:personResponsibleCode, materialCode:materialCode, //createdBy:createdBy,
		                       plantCode:plantCode, purchaseOrganisationCode:purchaseOrganisationCode, referenceNumber:referenceNumber, defect:defect, businessObjectStatuses:list,
		                       subjectCode_code:subjectCode_code,subjectCode_subjectCodeGroup_code:subjectCode_subjectCodeGroup_code,processDescription:processDescription
	            }
	
               }else{
                   //If both BOStatuses and defects have single entry
                   defectlist.add(defect);
                    list.add(bostatuses);
                    payload= json identifier:identifier, qnType:qnType, quantity:quantity, unit:unit, purchaseOrderNumber:purchaseOrderNumber, purchaseOrderItem:purchaseOrderItem, supplierCode:supplierCode, personResponsibleCode:personResponsibleCode, materialCode:materialCode, //createdBy:createdBy,
		                       plantCode:plantCode, purchaseOrganisationCode:purchaseOrganisationCode, referenceNumber:referenceNumber, defect:defectlist, businessObjectStatuses:list,
		                       subjectCode_code:subjectCode_code,subjectCode_subjectCodeGroup_code:subjectCode_subjectCodeGroup_code,processDescription:processDescription
               }
	      }
		
 
      message.setBody(groovy.json.JsonOutput.toJson(payload));
      message.setProperty("payload",groovy.json.JsonOutput.toJson(payload));
      return message;
}