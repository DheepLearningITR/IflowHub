import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.util.*;
import groovy.xml.*;
import org.codehaus.*;
import java.util.HashMap;

def Message processData(Message message) {

     def body= message.getBody(java.lang.String) as String;

     try{
     message.setHeader("errorMessage", field1);
     message.setHeader("errorExists", "true");
     }
     catch(Exception e)
     {
          message.setHeader("errorMessage", e.asS);
     }
     return message;
}

