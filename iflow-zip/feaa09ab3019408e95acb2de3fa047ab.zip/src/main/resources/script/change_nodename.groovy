import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;


def Message processData(Message message) {
	
    def body = message.getBody(String.class);
  
    def root_name = 'rfc:BAPI_MATERIAL_AVAILABILITY.Response';
    def new_root_name = 'BAPI_MATERIAL_AVAILABILITY';
    body = body.replaceAll("<$root_name>", "<$new_root_name>");
    body = body.replaceAll("<$root_name ", "<$new_root_name ");
    body = body.replaceAll("</$root_name>", "</$new_root_name>");
    
    def rfc = ' xmlns:rfc="urn:sap-com:document:sap:rfc:functions"';
    def new_rfc = '';
    body = body.replaceAll("$rfc", "$new_rfc");
    
    def ns = ' xmlns:ns0="http://sap.com/xi/XI/SplitAndMerge"';
    def new_ns = '';
    body = body.replaceAll("$ns", "$new_ns");
 
    message.setBody(body)
    
    return message;
}

