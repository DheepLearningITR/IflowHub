import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def properties = message.getProperties();
    def originalPayload = properties.get("ORIGINAL_PAYLOAD");
    if(messageLog != null){
        def body = message.getBody(java.lang.String) as String
        messageLog.addAttachmentAsString("Error Message", body, "text/plain");
        messageLog.addAttachmentAsString("Original Payload", originalPayload, "text/plain");
    }
    return message;
}
