import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import java.net.URLEncoder;


def Message processData(Message message) {
    //this script is to frame the query parameter to load the codelist to the value mapping
    def body = message.getBody(java.lang.String)
    def query = new XmlParser().parseText(body)
    def createparam;
     //Properties
    def properties = message.getProperties();
    def ID = properties.get("p_ValueMapId") ? properties.get("p_ValueMapId") : 'NA';
    def SrcAgency = properties.get("p_sourceAgency") ? properties.get("p_sourceAgency")  : 'NA';
    def TgtAgency = properties.get("p_targetAgency") ? properties.get("p_targetAgency") : 'NA';
    def SrcId = properties.get("p_sourceIdentifier") ? properties.get("p_sourceIdentifier") : 'NA';
    def TgtId = properties.get("p_targetIdentifier") ? properties.get("p_targetIdentifier") : 'NA';
    def SrcValue = query.codelist.sourceval.text() ? query.codelist.sourceval.text() : 'NA';
    def TgtValue = query.codelist.targetval.text() ? query.codelist.targetval.text() : 'NA';
    //def urlencodedSrcValue = URLEncoder.encode(SrcValue, "UTF-8").replace("+", "%20")
    //def urlencodedTgtValue = URLEncoder.encode(TgtValue, "UTF-8").replace("+", "%20")

    if ( SrcAgency == 'NA' || TgtAgency == 'NA' || SrcId == 'NA' || TgtId == 'NA' || SrcValue == 'NA' || TgtValue == 'NA'){
        createparam = 'NA'
        
    }else{
        createparam = """Id='${ID}'&Version='active'&SrcAgency='${SrcAgency}'&SrcId='${SrcId}'&TgtAgency='${TgtAgency}'&TgtId='${TgtId}'&SrcValue='${SrcValue}'&TgtValue='${TgtValue}'&IsConfigured=false"""
    }
    
    message.setProperty("p_codelistparam", createparam)
    return message;
}
