import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil

def Message processData(Message message) {
    //this script to generate source value map and target value map based on the FSM company mapping from S4H
    def body = message.getBody(java.lang.String)
    def query = new XmlParser().parseText(body)
    def mcXML = new XmlParser().parseText("<VM></VM>")
    def sourceval;
    def targetval;
    def ruleValue;
    def SPECFIELD = [:]
    def counterMap = [:]
    def counter = [BP:0, PP:0, PR:0, PS:0, SO:0, MG:0, SC:0]

    query.SrvcMgmtFSMReplicationRule_Type.each { FSMrule ->
    
        def ruleType = mapRuleType(FSMrule.SrvcMgmtFSMRplctnRuleType.text());
        if (FSMrule.SrvcMgmtFSMCompanyMapping_Type.size() > 0){
            targetval = "${FSMrule.SrvcMgmtFSMCompanyMapping_Type[0].FSMAccount.text()}|${FSMrule.SrvcMgmtFSMCompanyMapping_Type[0].FSMCompany.text()}"
        }else{
            targetval = "NA|NA"
        }
        def codelistXML = new XmlParser().parseText("<codelist></codelist>")
        def SPECcodelistXML = new XmlParser().parseText("<codelist></codelist>")

        if (ruleType == 'ALLCOMPANIES'){
            if (FSMrule.SrvcMgmtFSMRplctnObjAttribVal.text()){
                sourceval = "${FSMrule.SrvcMgmtFSMReplicationObject.text()}|" +
                            "${mapAttribute(FSMrule.SrvcMgmtFSMRplctnObjAttribute.text())}|" +
                            "${FSMrule.SrvcMgmtFSMRplctnObjAttribVal.text()}"
            }else{
                sourceval = "${FSMrule.SrvcMgmtFSMReplicationObject.text()}"
            }    
            targetval = ruleType;
        }else if (ruleType == 'PLANT'){
            ruleValue = "${FSMrule.Plant.text()}"
            sourceval = "${FSMrule.SrvcMgmtFSMReplicationObject.text()}|" +
                            "${mapAttribute(FSMrule.SrvcMgmtFSMRplctnObjAttribute.text())}|" +
                            "${FSMrule.SrvcMgmtFSMRplctnObjAttribVal.text()}|" +
                            "${ruleType}|" +
                            "${ruleValue}"
        }else if (ruleType == 'SALESAREA'){
            ruleValue = "${FSMrule.SalesOrganization.text()}|" + "${FSMrule.DistributionChannel.text()}|" + "${FSMrule.OrganizationDivision.text()}"
            sourceval = "${FSMrule.SrvcMgmtFSMReplicationObject.text()}|" +
                            "${mapAttribute(FSMrule.SrvcMgmtFSMRplctnObjAttribute.text())}|" +
                            "${FSMrule.SrvcMgmtFSMRplctnObjAttribVal.text()}|" +
                            "${ruleType}|" +
                            "${ruleValue}"
        }else if (ruleType == 'COMPANYCODE'){
            ruleValue = "${FSMrule.CompanyCode.text()}"
            sourceval = "${FSMrule.SrvcMgmtFSMReplicationObject.text()}|" +
                            "${mapAttribute(FSMrule.SrvcMgmtFSMRplctnObjAttribute.text())}|" +
                            "${FSMrule.SrvcMgmtFSMRplctnObjAttribVal.text()}|" +
                            "${ruleType}|" +
                            "${ruleValue}"
        }else if (ruleType == 'PURCHASEGROUP'){
            ruleValue = "${FSMrule.PurchasingGroup.text()}"
            sourceval = "${FSMrule.SrvcMgmtFSMReplicationObject.text()}|" +
                            "${mapAttribute(FSMrule.SrvcMgmtFSMRplctnObjAttribute.text())}|" +
                            "${FSMrule.SrvcMgmtFSMRplctnObjAttribVal.text()}|" +
                            "${ruleType}|" +
                            "${ruleValue}"
        }else if (ruleType == 'PURCHASEORG'){
            ruleValue = "${FSMrule.PurchasingOrganization.text()}"
            sourceval = "${FSMrule.SrvcMgmtFSMReplicationObject.text()}|" +
                            "${mapAttribute(FSMrule.SrvcMgmtFSMRplctnObjAttribute.text())}|" +
                            "${FSMrule.SrvcMgmtFSMRplctnObjAttribVal.text()}|" +
                            "${ruleType}|" +
                            "${ruleValue}"
        }else if (ruleType == 'SPECIFICFIELD'){
            if (FSMrule.SrvcMgmtFSMRplctnRuleField.text() != ''){                
                if (!counterMap.containsKey(FSMrule.SrvcMgmtFSMReplicationObject.text() + FSMrule.SrvcMgmtFSMRplctnRuleField.text())){
                    counter[FSMrule.SrvcMgmtFSMReplicationObject.text()] += 1
                    counterMap[FSMrule.SrvcMgmtFSMReplicationObject.text() + FSMrule.SrvcMgmtFSMRplctnRuleField.text()] = "FIELD" + counter[FSMrule.SrvcMgmtFSMReplicationObject.text()]
                    SPECFIELD[FSMrule.SrvcMgmtFSMRplctnRuleField.text()] = FSMrule.SrvcMgmtFSMReplicationObject.text() + counterMap[FSMrule.SrvcMgmtFSMReplicationObject.text() + FSMrule.SrvcMgmtFSMRplctnRuleField.text()]
                    def SPECFIELDsourcevalxml = new XmlParser().parseText("<sourceval>${SPECFIELD[FSMrule.SrvcMgmtFSMRplctnRuleField.text()]}</sourceval>")
                    def SPECFIELDtgtvalxml = new XmlParser().parseText("<targetval>${FSMrule.SrvcMgmtFSMRplctnRuleField.text()}</targetval>")                    
                    SPECcodelistXML.append(SPECFIELDsourcevalxml)
                    SPECcodelistXML.append(SPECFIELDtgtvalxml)
                }
                
                ruleValue = "${FSMrule.SrvcMgmtFSMRplctnRuleFldValue.text()}"
                sourceval = "${FSMrule.SrvcMgmtFSMReplicationObject.text()}|" +
                            "${mapAttribute(FSMrule.SrvcMgmtFSMRplctnObjAttribute.text())}|" +
                            "${FSMrule.SrvcMgmtFSMRplctnObjAttribVal.text()}|" +
                            "${SPECFIELD[FSMrule.SrvcMgmtFSMRplctnRuleField.text()]}|" +
                            "${ruleValue}"
            }
        }else {
            sourceval = "${FSMrule.SrvcMgmtFSMReplicationObject.text()}|" +
                            "${mapAttribute(FSMrule.SrvcMgmtFSMRplctnObjAttribute.text())}|" +
                            "${FSMrule.SrvcMgmtFSMRplctnObjAttribVal.text()}|" +
                            "${ruleType}"
        }
        

        def sourcevalxml = new XmlParser().parseText("<sourceval>${sourceval}</sourceval>")
        def tgtvalxml = new XmlParser().parseText("<targetval>${targetval}</targetval>")
        codelistXML.append(sourcevalxml)
        codelistXML.append(tgtvalxml)

        if (targetval != "|")
            mcXML.append(codelistXML)
        
        if (SPECcodelistXML.sourceval.size() > 0)
            mcXML.append(SPECcodelistXML)
    }

    // Loop through the specific field for each object type and append its size
    counter.each { key, value ->        
        if (value != 0) {            
            def specsizecodelist = new XmlParser().parseText("<codelist></codelist>")
            def specfieldsizesrc = new XmlParser().parseText("<sourceval>${key}SPECSIZE</sourceval>")            
            def specfieldsizetgt = new XmlParser().parseText("<targetval>${value}</targetval>")            
            specsizecodelist.append(specfieldsizesrc)
            specsizecodelist.append(specfieldsizetgt)
            mcXML.append(specsizecodelist)
        }
    }
    
    message.setBody(XmlUtil.serialize(mcXML))
    return message
}


def mapAttribute(attr) {
    def attributeMap = ['01': 'MATERIALTYPE', '02': 'BPROLE']
    attributeMap[attr] ?: attr
}

def mapRuleType(ruleType) {
    def ruleTypeMap = ['00': 'ALLCOMPANIES', '01': 'PLANT', '02': 'SALESAREA', '03': 'COMPANYCODE',
                       '04': 'PURCHASEGROUP', '05': 'PURCHASEORG', '06': 'SPECIFICFIELD']
    ruleTypeMap[ruleType] ?: ruleType
}
