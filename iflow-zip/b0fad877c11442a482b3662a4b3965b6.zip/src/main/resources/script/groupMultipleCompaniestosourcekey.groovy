import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil

def Message processData(Message message) {
    //this script to generate source value map and target value map with 1:N source keymap to target values (FSM Company list)
    def body = message.getBody(java.lang.String)
    def query = new XmlParser().parseText(body)
    def mcXML = new XmlParser().parseText("<VM></VM>")
    
    // Group by sourceval and concatenate targetval
    def groupedMap = [:].withDefault { [] }
    
    query.codelist.each { codelist ->
        def sourcevalue = codelist.sourceval.text()
        def targetvalue = codelist.targetval.text()
        groupedMap[sourcevalue] << targetvalue
    }

    groupedMap.each { src, tgts ->
        def tgtvalue = tgts.unique().join(":")
        def groupAcct = [:].withDefault { [] }
        def tgtvaluelist = tgtvalue.tokenize(":")
        tgtvaluelist.each { k ->
			def parts = k.split("\\|", 2)
			if (parts.size() == 2) {
				groupAcct[parts[0]] << parts[1]
			}
		}	

        def finaltgt = groupAcct.isEmpty() ? tgtvalue : groupAcct.collect { key, values -> "${key}|${values.join(',')}" }.join(":")

        def codelistXML = new XmlParser().parseText("<codelist></codelist>")
        def sourcevalxml = new XmlParser().parseText("<sourceval>${src}</sourceval>")
        def tgtvalxml = new XmlParser().parseText("<targetval>${finaltgt}</targetval>")                    
        codelistXML.append(sourcevalxml)
        codelistXML.append(tgtvalxml)
        mcXML.append(codelistXML)
    }

    message.setBody(XmlUtil.serialize(mcXML))
    return message
}