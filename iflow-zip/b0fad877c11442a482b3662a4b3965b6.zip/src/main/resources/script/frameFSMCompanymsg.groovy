import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil

def Message processData(Message message) {
    def body = message.getBody(java.lang.String)
    def query = new XmlParser().parseText(body)
    def mcXML = new XmlParser().parseText("<FSMMultiCompany></FSMMultiCompany>")
    def distinctFSMValues = new HashSet<String>()

    query.SrvcMgmtFSMCompanyMapping_Type.each { fsmAcctComp ->
        distinctFSMValues.add(fsmAcctComp.FSMAccount.text() + '|' + fsmAcctComp.FSMCompany.text()) 
    }

    distinctFSMValues.each { value -> 
        if (value.contains("|")) {
            def fsmXml = new XmlParser().parseText("<FSMCompany>${value}</FSMCompany>")
            mcXML.append(fsmXml)
        }
    }    


    def FSMCompanyData = XmlUtil.serialize(mcXML)
    message.setBody(FSMCompanyData)
    return message
}
