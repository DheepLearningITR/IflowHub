import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.util.*

def Message processData(Message message) {
    
    def messageText = message.getBody(java.lang.String) as String
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
            //Body with new attributes
       def root = new XmlParser().parseText(messageText)
       //Get properties
       def Properties = message.getProperties()
       def Prepend    = Properties.get("EXTERNAL_COMPANY_PREPEND")
       root.appendNode("EXTERNAL_COMPANY_PREPEND", [:], Prepend)
       rootxml = XmlUtil.serialize(root)
	   message.setBody(rootxml)
       
    }
       return message
}