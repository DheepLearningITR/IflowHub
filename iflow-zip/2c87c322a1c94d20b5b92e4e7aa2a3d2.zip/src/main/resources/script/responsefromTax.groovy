import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
def Message processData(Message message) {
    def messageText = message.getBody(java.lang.String) as String
    def messageLog = messageLogFactory.getMessageLog(message)
    def Properties = message.getProperties()
    def Logging    = Properties.get("Enable_Logging_Response")
    if(messageLog != null && Logging == 'true'){
        messageLog.setStringProperty("Log 2", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("Response from Tax Engine:", messageText, "text/plain")
    }
           return message
}