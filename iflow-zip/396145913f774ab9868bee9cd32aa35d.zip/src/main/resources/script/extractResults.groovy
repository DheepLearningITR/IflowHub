import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message extractDataWithCleansing(Message message) {


    def body = message.getBody(String.class)

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)

    def finalBody

    if (json.record instanceof List){

        finalBody = json

    } else {
        finalBody = [json]

    }
    finalBody = finalBody?.findAll{it}
    message.setBody(JsonOutput.toJson(finalBody))

    return message
}
