import com.sap.it.api.mapping.*;

def String addzerosCC(String a){
def stringLen = 10
def strLen = a.toString().size()
expectedLen = stringLen.toInteger() - strLen.toInteger()
for(i = 0; i<=expectedLen-1;i++)
{
	a = "0" + a 
}


	return a 
}


