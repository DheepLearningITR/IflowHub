import com.sap.it.api.mapping.*;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Locale;


def void getFirstScheduleLineDate(String[] scheduleLineDeliveryDates, Output scheduleLineDeliveryDate) {
	scheduleLineDeliveryDate.addValue(scheduleLineDeliveryDates[0]);
}

def void getFirstScheduleLineTime(String[] scheduleLineDeliveryTimes, Output scheduleLineDeliveryTime) {
	scheduleLineDeliveryTime.addValue(scheduleLineDeliveryTimes[0]);
}

def String formatPOItemId(String input) {
    return String.format("%05d", Integer.valueOf(input));
}

def String mapNoRounding(String input) {
    if (input != null && input == "X") {
        return "X";
    }
    return " ";
}

def String convertTimeToBapiFormat(String date) {
    if (date != null && date.startsWith("PT")) {
        return date.replaceAll("[^0-9]", "");
    }
    return date;
}

def String convertDateToBapiFormat(String date) {
    if (date != null && date.startsWith("/Date(")) {
        long epochSecs = Long.parseLong(date.replaceAll("[^0-9]", "")) / 1000;
        LocalDateTime dateTime = LocalDateTime.ofEpochSecond(epochSecs, 0, ZoneOffset.UTC);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd", Locale.ENGLISH);
        return dateTime.format(formatter);
    }
    return date;
}