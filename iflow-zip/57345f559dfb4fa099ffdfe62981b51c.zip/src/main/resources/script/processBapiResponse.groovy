import com.sap.it.api.mapping.*;
import java.lang.StringBuilder;

def void createResponseMsg(String[] msgTypes, String[] msgs, Output responseMsg){
	StringBuilder sb = new StringBuilder();
	
	msgTypes.eachWithIndex { msgType, index -> 
	    switch(msgType) {
	        case 'E':
	        case 'S':
	            sb.append(msgs[index].trim());
	            sb.append('. ');
	            break;
	    }
	}
	responseMsg.addValue(sb.toString());
}