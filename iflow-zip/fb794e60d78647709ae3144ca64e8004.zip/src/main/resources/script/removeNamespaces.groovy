import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.QName
import groovy.xml.XmlUtil


def Message processData(Message message) {
	
    XmlParser parser = new XmlParser()

    // Recursive closure to replace nodes with prefix
    def replaceNodePrefix
    replaceNodePrefix = { Node node ->
        def nodeName = node.name()
        // Replace current node
        def localNodeName = (nodeName instanceof QName) ? nodeName.getLocalPart() : nodeName
        Node outputNode = parser.createNode(null, localNodeName, null)
        // Iterate and process the children of the node
        node.children().each { child ->
            switch (child){
                case Node:
                    outputNode.append(replaceNodePrefix.trampoline(child).call())
                    break
                case String:
                    outputNode.setValue(child)
                    break
            }
        }
        return outputNode
    }.trampoline()

    Node root = parser.parse(message.getBody(Reader))
    message.setBody(XmlUtil.serialize(replaceNodePrefix(root)))
    return message
}
