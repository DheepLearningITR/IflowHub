import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import groovy.util.slurpersupport.GPathResult
import groovy.transform.Field

@Field static final String VM_AGENCY_ERP = "ERP";
@Field static final String VM_AGENCY_DMC = "DMC";
@Field static final String VM_IDENTIFIER_DMC_PLANTS = "PLANT";
@Field static final String VM_IDENTIFIER_ERP_WERKS = "WERKS";
@Field static final String IDOC_PARTNER_NO_FIELD = 'SNDPRN';

@Field static final String VM_AGENCY_DM = 'DM'
@Field static final String VM_IDENTIFIER_Plant = 'Plant'
@Field static final String VM_IDENTIFIER_Destination = 'Destination';

Message processData(Message message) {

    ValueMappingApi vm = ITApiFactory.getService(ValueMappingApi.class, null);
    Reader payload = message.getBody(java.io.Reader);
    GPathResult root;
    try {
        root = new XmlSlurper().parse(payload);
    } catch (org.xml.sax.SAXParseException e) {
        message.setProperty("ExceptionMessage", "Plant conversion illegal payload please check previous step");
        return;
    }

    String prefix;
    List<GPathResult> searchResult = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase(IDOC_PARTNER_NO_FIELD) && it.children().size() == 0 && it.text() != null && it.text() != ""; }
    if (!searchResult.isEmpty()) {
        prefix = searchResult[0].text();
    }

    List<GPathResult> searchResult2 = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase(VM_IDENTIFIER_ERP_WERKS) && it.children().size() == 0; }
    String plantSourceValue = searchResult2[0].text();

    String plantTargetValue = vm.getMappedValue(VM_AGENCY_ERP, VM_IDENTIFIER_ERP_WERKS, prefix + ":" + plantSourceValue, VM_AGENCY_DMC, VM_IDENTIFIER_DMC_PLANTS);

    if (!plantTargetValue) {
        plantTargetValue = vm.getMappedValue(VM_AGENCY_ERP, VM_IDENTIFIER_ERP_WERKS, plantSourceValue, VM_AGENCY_DMC, VM_IDENTIFIER_DMC_PLANTS);
    }

    if (plantTargetValue) {
        try {
            plantTargetValue = plantTargetValue.split(":")[1];
        } catch (java.lang.ArrayIndexOutOfBoundsException ex) {
            log.error("Can't split the plant value ", plantTargetValue);
            plantTargetValue = plantSourceValue;
        }
    } else {
        plantTargetValue = plantSourceValue;
    }

    String erpDestination = vm.getMappedValue(VM_AGENCY_DM, VM_IDENTIFIER_Plant, plantTargetValue, VM_AGENCY_ERP, VM_IDENTIFIER_Destination)
    message.setHeader("erpDestination", erpDestination);

    return message;
}