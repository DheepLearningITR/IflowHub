import com.sap.gateway.ip.core.customdev.util.Message
import groovy.transform.Field
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.w3c.dom.Node


@Field String LOG_ID = 'IORDER01_STD_PREXSLT'


@Field List EXCLUDE_PROPERTIES = ['SAP_MessageProcessingLogID', 'SAP_MonitoringStateProperties', 'MplMarkers', 'SAP_MessageProcessingLog', 'ACCESS_TOKEN', 'Authorization'];
@Field List EXCLUDE_HEADERS = ['ACCESS_TOKEN', 'Authorization'];

@Field Logger log = LoggerFactory.getLogger("com.sap.cpi.metviewer." + LOG_ID);

// if you use this method, you need to copy the script for every usage and adapt the filename (000)
def Message processData(Message message) {

    try {
        processHeadersAndProperties('log_info', message);
        processBody('log_payload', message);
    } catch (Exception ex) {
        log.error("processData error", ex);
    }
    return message;
}

// you can use _010, _020 etc methods to reuse same script from multiple places in the iflow
def Message request(Message message) {

    try {
        def log_suffix = 'Request';
        processHeadersAndProperties("${log_suffix}_info", message);
        processBody("${log_suffix}_payload", message);

    } catch (Exception ex) {
        log.error("processData error", ex);
    }
    return message;
}

// you can use _010, _020 etc methods to reuse same script from multiple places in the iflow
def Message response(Message message) {

    try {
        def log_suffix = 'Response';
        processHeadersAndProperties("${log_suffix}_info", message);
        processBody("${log_suffix}_payload", message);
    } catch (Exception ex) {
        log.error("processData error", ex);
    }
    return message;
}

def Map excludeEntries(Map map, List excluded) {
    def newMap = new HashMap();
    newMap.putAll(map);
    newMap.keySet().removeAll(excluded);
    return newMap;

}

def void processBody(String prefix_with_vars, Message message) {
    def byte[] body_bytes = null;
    try {

        def prefix = prefix_with_vars;

        if (message == null) {
            body_bytes = new byte[0];
        } else if (message.getBody() == null) {
            body_bytes = new byte[0];
        } else {
            body_bytes = message.getBody(byte[].class);
        }

        def messageLog = messageLogFactory.getMessageLog(message);
        def mpl_prefix = prefix;
        messageLog.addAttachmentAsString(mpl_prefix, new String(body_bytes, "UTF-8"), "text/plain");
    } catch (Exception ex01) {
        log.error("cannot save body", ex01);
        StringWriter sw = new StringWriter();
        ex01.printStackTrace(new PrintWriter(sw));
        log.info(sw.toString());
    }
}

boolean skipNL;

String printXML(org.w3c.dom.Node rootNode) {
    String tab = "";
    skipNL = false;
    return (printXML(rootNode, tab));
}

String printXML(org.w3c.dom.Node rootNode, String tab) {
    String print = "";
    if (rootNode.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
        print += "\n" + tab + "<" + rootNode.getNodeName() + ">";
    }
    org.w3c.dom.NodeList nl = rootNode.getChildNodes();
    if (nl.getLength() > 0) {
        for (int i = 0; i < nl.getLength(); i++) {
            print += printXML(nl.item(i), tab + "  ");    // \t
        }
    } else {
        if (rootNode.getNodeValue() != null) {
            print = rootNode.getNodeValue();
        }
        skipNL = true;
    }
    if (rootNode.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
        if (!skipNL) {
            print += "\n" + tab;
        }
        skipNL = false;
        print += "</" + rootNode.getNodeName() + ">";
    }
    return (print);
}

def void processHeadersAndProperties(String prefix_with_vars, Message message) {
    try {

        log.debug("processHeadersAndProperties: " + prefix_with_vars + " START");
        def prefix = prefix_with_vars;

        def StringBuffer sb_text = new StringBuffer();

        def map = message.getHeaders();
        map = excludeEntries(map, EXCLUDE_HEADERS);
        dumpProperties_TEXT("Headers", map, sb_text);

        map = message.getProperties();

        log.debug("processHeadersAndProperties: " + prefix_with_vars + "  PROPERTIES01");
        map = excludeEntries(map, EXCLUDE_PROPERTIES);
        dumpProperties_TEXT("Properties", map, sb_text);

        def ex = map.get("CamelExceptionCaught");
        if (ex != null) {

            def exmap = new HashMap();
            exmap.put("exception", ex);
            exmap.put("getCanonicalName", ex.getClass().getCanonicalName());
            exmap.put("getMessage", ex.getMessage());

            StringWriter swe = new StringWriter();
            ex.printStackTrace(new PrintWriter(swe));
            exmap.put("stacktrace", swe.toString());

            if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
                exmap.put("responseBody", safeEscapeXml(ex.getResponseBody()));
                exmap.put("responseBody.className", safeClassName(ex));
                exmap.put("getStatusText", ex.getStatusText());
                exmap.put("getStatusCode", ex.getStatusCode());
            }

            if (ex instanceof org.apache.cxf.interceptor.Fault) {
                exmap.put("getDetail", safeEscapeXml(ex.getDetail()));
                exmap.put("getDetail.className", safeClassName(ex.getDetail()));
                exmap.put("getFaultCode", ex.getFaultCode());
                exmap.put("getMessage", ex.getMessage());
                exmap.put("getStatusCode", "" + ex.getStatusCode());
                exmap.put("hasDetails", "" + ex.hasDetails());

                //message.getHeaders().put("SoapFaultMessage", ex.getMessage());
                exmap.put("getCause", "" + ex.getCause());

                if (ex.getCause() != null) {
                    def cause_message = ex.getCause().getMessage();
                    if (ex.getCause() instanceof org.apache.cxf.transport.http.HTTPException) {
                        cause_message = ex.getCause().getResponseMessage();
                    }
                    exmap.put("getCause.getResponseMessage", "" + cause_message);
                    message.getHeaders().put("SoapFaultMessage", ex.getMessage() + ": " + ex.getCause().getResponseMessage());
                }

            }
            dumpProperties_TEXT("property.CamelExceptionCaught", exmap, sb_text);
        }

        log.debug("processHeadersAndProperties: " + prefix_with_vars + "  SAVE_MPL01");

        def messageLog = messageLogFactory.getMessageLog(message);
        def mpl_prefix = prefix;
        messageLog.addAttachmentAsString(mpl_prefix, sb_text.toString(), "text/plain");

        log.debug("processHeadersAndProperties: " + prefix_with_vars + "  SAVE_FILE01");

    } catch (Exception ex01) {
        log.error("processHeadersAndProperties: " + prefix_with_vars + " ", ex01)
        StringWriter sw = new StringWriter();
        ex01.printStackTrace(new PrintWriter(sw));
        log.info(sw.toString());
    }
}

public String safeClassName(Object obj) {
    if (obj == null) return "";
    return obj.getClass().getName();
}

public Object safeEscapeXml(Object payload) {
    if (payload instanceof java.lang.String) {
        return payload;
    } else if (payload instanceof byte[]) {
        return payload;
    } else if (payload instanceof Node) {
        return printXML(payload);
    }
    return payload;
}

public void dumpProperties_TEXT(String title, Map<String, Object> map, StringBuffer sb) {
    sb.append(title + "\n");
    for (String key : map.keySet()) {
        sb.append(String.format(" %-40s: %-40s\n", key, map.get(key)));
    }
    sb.append("\n");
}
