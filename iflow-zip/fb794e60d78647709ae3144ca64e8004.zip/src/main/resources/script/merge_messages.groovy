import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;

def Message processData(Message message) {

	def body = message.getBody(String.class);
	def request = message.getProperties().get('requestBody');

	// merge content
	def endTag = "</IORDER01>";
	def startExtTag = "<DM_EXT>";
	def endExtTag = "</DM_EXT>";
	def replaceContent = "$startExtTag" + "$body" + "$endExtTag" + "$endTag";
	request = request.replaceAll("$endTag", "$replaceContent");

	message.setBody(request);
	return message;
}
