/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;


def Message processData(Message message) { 

// read the body as byte array
    byte[] body = message.getBody(byte[].class);

// find out what tag must be split  
    byte[] tagToSplit = message.getProperty("tagToSplit").getBytes(StandardCharsets.ISO_8859_1);

    byte[] newBody = new byte[body.length + 1024];

    byte[] arrayToCompare = new byte[tagToSplit.length];

    int targetPos = 0;
    byte c_lf = 10;
    int  c_max_length = 76;
    byte c_lt = 60;  //  "<"


// loop the body searching for the tag to be split
    for(int a=0 ; a<body.length; a++ ) {
        
// transfer comparison
        for(z=0; (z<tagToSplit.length) && ( (a+z) < body.length) ;z++)
            arrayToCompare[z] = body[a+z];
        
// is it the tag and it is not split already??
        if (Arrays.equals(arrayToCompare, tagToSplit) && (body[tagToSplit.length+a] != c_lf) ) {
            
 // tag found - transfer tag
            for(z=0;z<tagToSplit.length;z++)
                newBody[targetPos++] = body[a++];
            
// add first line feed
            newBody[targetPos++] = c_lf;
            int c = 0;

//until the xml closing tag is found, split every c_max_length
            for (a; (body[a] != c_lt ) && (a < body.length); a++ ) {

                if(c < c_max_length) {
                    newBody[targetPos++] = body[a];
                    c++;
                }
                else {
                    newBody[targetPos++] = c_lf;
                    newBody[targetPos++] = body[a];
                    c = 1;
                }
            }
            if (a < body.length) {
                newBody[targetPos++] = c_lt;
            }
        }
        else
        {
//move to target            
            newBody[targetPos++] = body[a];
        }
    }


// move content to resized array  
    byte[] resultBody = new byte[targetPos];
    
    for(z=0;z<targetPos;z++) resultBody[z] = newBody[z];
    
    message.setBody(resultBody);
    
    return message;
}