import com.sap.it.api.mapping.*;

def String customFunc(String arg1){
	
	//Convert MM/DD/YYYY
	String mm = "";
	String dd = "";
	String yyyy = "";
	
	if(arg1 != "")
	{
	   yyyy = arg1.substring(0,4);
	   mm = arg1.substring(5,6);
	   dd = arg1.substring(8,9);
	   
	   arg1 = mm+"/"+dd+"/"+yyyy;
	}
	
	return arg1 
}