import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
       //Headers 
       def map = message.getHeaders();
       
       if(map.get("errorMessage")){
           message.setHeader("errorExists", true)
       }

       return message;
}