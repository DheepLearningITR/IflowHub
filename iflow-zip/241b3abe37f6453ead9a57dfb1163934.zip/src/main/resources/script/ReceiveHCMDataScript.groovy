import com.sap.gateway.ip.core.customdev.util.Message;
import elster.cpi.core.ReceiveHCMData;
import iaik.x509.X509Certificate;
import java.security.PrivateKey;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import java.security.KeyStore;
import java.security.Key;

import java.security.KeyPair;
import java.security.cert.Certificate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import groovy.transform.Field;

//@Field Logger log = LoggerFactory.getLogger("com.sap.hci.metviewer.logger");
	 
	def Message processData(Message message) {
		
		def alias2 = message.getProperty("OwnCertificates");
		if(alias2 == null){
			//default
			alias2 = "elster_hcm_ag";
		}
		def service = ITApiFactory.getApi(KeystoreService.class, null);
	    Certificate[] certChain = service.getCertificateChain(alias2);
	    
		Key key = service.getKey(alias2);
		if (key == null){
			throw new IllegalStateException("Can not find own certificate key!");
		}

	//Body
	def body = message.getBody(java.lang.String) as byte[]
	ReceiveHCMData  receiveHCMData = new ReceiveHCMData(key, certChain);
	def modifiedbody = receiveHCMData.modifyXMLData(body);
	
	message.setBody(modifiedbody);
	message.setHeader("content-type", "application/xml");
	
	
	return message;
}