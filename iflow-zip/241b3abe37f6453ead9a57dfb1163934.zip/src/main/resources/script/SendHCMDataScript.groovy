import com.sap.gateway.ip.core.customdev.util.Message;
import elster.cpi.core.SendHCMData;
import elster.cpi.util.PayloadPropertiesContainer;
import elster.cpi.util.PayloadPropertiesUtil;
import elster.cpi.util.CertificateUtil;
import java.security.PrivateKey;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import java.security.KeyStore;
import java.security.Key;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 

import java.security.KeyPair;

import java.security.cert.Certificate;
//@Field Logger log = LoggerFactory.getLogger("com.sap.hci.metviewer.logger");
     
	def Message processData(Message message) {
		Logger log = LoggerFactory.getLogger("com.sap.hci.metviewer.logger");
		def body = message.getBody(java.lang.String) as byte[]
		def alias1 = message.getProperty("PartnerCertificates");
		def alias2 = message.getProperty("OwnCertificates");
		if(alias1 == null){
			//default
			alias1 = "elster_hcm_cl";
		}
		if(alias2 == null){
			//default
			alias2 = "elster_hcm_ag";
		}
        Certificate[] certChain = null;
        Certificate partnerCert = null;
        Key key = null;
        try{
        	PayloadPropertiesContainer container = PayloadPropertiesUtil.getPropertiesFromSAPHeader(body);		
			partnerCert = container.getPartnerCertificate();
			certChain = container.getOwnCertificateChain();	
			key = container.getPrivateKey();
			if(container.getUrl() != null){
				message.setHeader("ElsterURL", container.getUrl());
				//message.setHeader("ElsterURL", "http://datenannahme3.elster.de/Elster2/EMS");
			}
		}catch(Exception e){
		    log.info("Unable to find element 'SAP' in the payload.");
		}finally{
			try{
				body = PayloadPropertiesUtil.extractActualPayload(body);
			}catch(Exception e){
		   		log.info(e.getLocalizedMessage());
			}
		    if(partnerCert == null && (partnerCert = CertificateUtil.getPartnerCertificate(alias1)) == null){
		    	throw new IllegalStateException("Partner certificate for alias alias2 not found");
		    }
		    if(certChain == null && (certChain = CertificateUtil.getOwnCertificateChain(alias2)) == null){
		    	throw new IllegalStateException("CertificateChain for alias alias2 not found");
		    }
		    if(key == null && (key = CertificateUtil.getKey(alias2)) == null){
		    	throw new IllegalStateException("Key for alias alias2 not found");
		    }
		    message.getProperties().put("OwnCertificates", alias2);
		    message.getProperties().put("PartnerCertificates", alias1);
		}

		SendHCMData sendHCMData = new SendHCMData(key, certChain, partnerCert);
		def modifiedbody = sendHCMData.modifyXMLData(body);
		message.setBody(modifiedbody);
		message.setHeader("Content-Type", "application/xml");
		message.setHeader("Accept", "*/*");
    
		return message;
	}