import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

// process message
def Message processData(Message message) { 
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)

    jsonResult.data?.serviceCall?.equipments.each { obj ->
        if (obj.objectCategory == null || obj.objectCategory == '')
            obj.objectCategory = 'EQ'
    }

    // Replace null values with empty strings and remove empty arrays
    replaceNullsAndRemoveEmptyArrays(jsonResult)

    jsonResult.data?.serviceCall?.remove("lastChanged")
    jsonResult.data?.remove("updatedProperty")
    jsonResult.data?.serviceCall?.remove("orgLevelIds")
    jsonResult.data?.serviceCall?.remove("contact")
    jsonResult.data?.serviceCall?.remove("attachments")
    jsonResult.data?.serviceCall?.remove("requirements")
    jsonResult.data?.serviceCall?.remove("chargeableEfforts")
    jsonResult.data?.serviceCall?.remove("chargeableExpenses")
    jsonResult.data?.serviceCall?.remove("chargeableMaterials")
    jsonResult.data?.serviceCall?.remove("chargeableMileages")
    
    jsonResult.data?.serviceCall?.remove("createPerson")
    
    //add objectId and objectType node
    jsonResult["objectId"] = jsonResult.data?.serviceCall?.id
    jsonResult["objectType"] = (jsonResult.eventType == "servicecall.updated")?"SERVICECALL":"ACTIVITY"

    def updatedJsonString = JsonOutput.toJson(jsonResult)
    message.setBody(JsonOutput.prettyPrint(updatedJsonString))

    //set OData url prefix path to UpdateMaintenanceOrder
    message.setProperty("updatepathprefix",'SAP__self.UpdateMaintenanceOrder')
    message.setProperty("S4HRequestPayload",JsonOutput.prettyPrint(updatedJsonString))

    return message
}

// Recursive function to replace all null values with empty strings and remove empty arrays
def replaceNullsAndRemoveEmptyArrays(obj) {
    if (obj instanceof Map) {
        def keysToRemove = [] // List to track empty arrays
        obj.each { key, value ->
            if (value == null || value == 'null' || value == '') {
                //obj[key] = ""
                keysToRemove.add(key) // Mark empty array for removal
            } else if (value instanceof List && value.isEmpty()) {
                keysToRemove.add(key) // Mark empty array for removal
            } else {
                replaceNullsAndRemoveEmptyArrays(value)
            }
        }
        // Remove the keys after iteration
        keysToRemove.each { key ->
            //obj.remove(key)
            obj.remove(key)
        }
    } else if (obj instanceof List) {
        def itemsToRemove = [] // List to track null and empty arrays
        obj.each { item ->
            if (item == null || item == 'null' || item == '' || (item instanceof List && item.isEmpty())) {
                itemsToRemove.add(item) // Mark for removal
            } else {
                replaceNullsAndRemoveEmptyArrays(item)
            }
        }
        // Remove the items after iteration
        itemsToRemove.each { item ->
            obj.remove(item)
        }
    }
}
