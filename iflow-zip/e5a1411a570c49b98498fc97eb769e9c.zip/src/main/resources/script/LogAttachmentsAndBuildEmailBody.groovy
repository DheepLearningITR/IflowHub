import com.sap.gateway.ip.core.customdev.util.Message
// Version 1.0
// save attachments to log and build error email body
def Message processData(Message message) {
    def map = message.getProperties()
    def headers = message.getHeaders()
    def add_to_log_property = message.getProperty("ErrorLogAttachments") ?: 'false'
    def add_to_log = (add_to_log_property ==~ /(?i)(true|x)/)
    def email_body = ''
    def headers_text = ''

    // get an exception java class instance
    def ex = map.get('CamelExceptionCaught')
    if (ex != null) {
        // fill only minimal information into email body
        email_body = "MPL ID: " + map.get("SAP_MessageProcessingLogID") + "\n" 
        email_body += "Correlation ID: " + headers.get("SAP_MplCorrelationId") + "\n" 
        email_body += "Timestamp: " + map.get("CamelCreatedTimestamp") + "\n" 

        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (ex.getClass().getCanonicalName().equals('org.apache.camel.component.ahc.AhcOperationFailedException')) {
            if (add_to_log) {
               // save the http error response as a log attachment
                def messageLog = messageLogFactory.getMessageLog(message)
                messageLog.addAttachmentAsString('ResponseBody', ex.getResponseBody(), 'text/plain')
            }
            message.setProperty('http.StatusCode', ex.getStatusCode())
            message.setProperty('http.StatusText', ex.getStatusText())
            message.setProperty('http.ResponseBody', ex.getResponseBody())
        }
        if (add_to_log) {
            // add headers
            headers.each{ k, v -> 
                headers_text += "${k}: ${v}" + "\n" 
            }
            // save headers as a log attachment
            def messageLog2 = messageLogFactory.getMessageLog(message)
            messageLog2.addAttachmentAsString('Headers', headers_text, 'text/plain')
            // save FSM payload as a log attachment
            if( map.get("FSMRequestPayload") != null && map.get("FSMRequestPayload") != '' ) {
                def messageLog5 = messageLogFactory.getMessageLog(message)
                messageLog5.addAttachmentAsString('FSMRequestPayload', map.get("FSMRequestPayload"), 'text/plain')
            }
            
            // save Request payload sent to S4HANA as a log attachment
            if( map.get("S4HRequestPayload") != null && map.get("S4HRequestPayload") != '' ) {
                def messageLog6 = messageLogFactory.getMessageLog(message)
                messageLog6.addAttachmentAsString('S4HRequestPayload', map.get("S4HRequestPayload"), 'text/plain')
            }
        }
    }

    message.setBody(email_body)
    return message
}