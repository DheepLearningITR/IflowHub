import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    // Get properties
    def properties = message.getProperties();
    title = properties.get("title");
    user_id = properties.get("user-id");
    
    // Headers
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("avoidItems");
    cacheData.put(title, 'false');
    
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("Error pushing " + title + " " + user_id, body, "text/plain");
    }
    return message;
}