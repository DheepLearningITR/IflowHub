import groovy.json.JsonOutput
import java.text.SimpleDateFormat
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
import groovy.xml.*

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    
    // Avoid process bad requests twice
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("avoidItems");

    //Properties
    def properties = message.getProperties();
    userID = properties.get("UserID");
    sfsfLearnings = properties.get("SFSFLearnings")
    degreedLearnings = properties.get("DegreedLearnings")
    allowedRequirementTypeIds = properties.get("allowedRequirementTypeIds")
    allowedRequirementTypeIdsList = allowedRequirementTypeIds.split(',')
    
    
    def outputDateFormat = "dd/MM/yyyy"
    def inputDateFormat = "yyyy-MM-dd'T'HH:mm:ss"
    
    def parsedSFLearnings = new XmlSlurper().parseText(sfsfLearnings);

    List<Map<String, String>> sfrlsMapList = []
    parsedSFLearnings.value.each { value ->
      def sfrlMap = [:]
      sfrlMap['title'] = value.title.text()
      def sfReqDate = value.requiredDate.text()
      if (sfReqDate) {

          def reqTimeStamp = new Date(Long.parseLong(sfReqDate)-40319600)
          sfReqDate = new SimpleDateFormat(outputDateFormat).format(reqTimeStamp)
          sfrlMap['requiredDate'] = sfReqDate
          
        
      } else {
          sfrlMap['requiredDate'] = null
      }
      
      if (sfrlMap['title'] && (value.requirementTypeId.text() in allowedRequirementTypeIdsList)) {
          sfrlsMapList.add(sfrlMap)
      }
      
      else if (sfrlMap['title'] && !(value.requirementTypeId.text()) && ("NULL" in allowedRequirementTypeIdsList)) {
          sfrlsMapList.add(sfrlMap)
      }
    }
    
    def mapListString = JsonOutput.toJson(sfrlsMapList)
    //messageLog.addAttachmentAsString('SFSF Map List', mapListString, 'application/json')
    
    List<Map<String, String>> degreedRLMapList = []
    
    try {
        def paresedDegreedLearnings = new JsonSlurper().parseText(degreedLearnings);
        paresedDegreedLearnings.data.each { eachRL ->
          def degreedrlMap = [:]
          degreedrlMap['title'] = eachRL.included[0].attributes.title
          def degreedReqDate = eachRL.attributes['due-at']
          if (degreedReqDate) {
              def inputDate = new SimpleDateFormat(inputDateFormat).parse(degreedReqDate)
              def degreedOutputDateString = new SimpleDateFormat(outputDateFormat).format(inputDate)
              degreedrlMap['requiredDate'] = degreedOutputDateString
    
          } else {
              degreedrlMap['requiredDate'] = null
          }
          degreedrlMap['id'] = eachRL.id
          degreedRLMapList.add(degreedrlMap)
        }
    }
    catch (Exception e) {
    messageLog.addAttachmentAsString("Issue in fetching the degreed learnings payload " + userID as String, degreedLearnings, "text/plain");
    }
    
    def mapListStringa = JsonOutput.toJson(degreedRLMapList)
    // messageLog.addAttachmentAsString('Degreed Map List', mapListStringa, 'application/json')
    
    
    //Compare sfrlsMapList and degreedRLMapList
    def degreedToDelete = []
    def degreedToAdd = []
    def degreedToUpdate = []
    
    List<Map<String, String>> degreedToUpdateMap = []
    List<Map<String, String>> degreedToDeleteMap = []

    degreedRLMapList.each { map1 ->
      def found = false
      sfrlsMapList.each { map2 ->
      if (map1.title == map2.title) {
          found = true
          if (map1.requiredDate != map2.requiredDate) {
              messageLog.addAttachmentAsString("Update " + userID + " deg: " + map1.requiredDate + " | sfsf: " + map2.requiredDate, "none", "text/plain");
              degreedToUpdateMap.add(map1)
              degreedToUpdate.add(map1.title)
          }
      }
      }
      
      if (!found) {
          degreedToDelete.add(map1.id)
          degreedToDeleteMap.add(map1)
      }

    }

    sfrlsMapList.each { newMap1 ->
        def found = false
        degreedRLMapList.each { newMap2 ->
        if (newMap1.title == newMap2.title) {
            found = true
        }

        }
        if (!found) {
            // Check if the title failed before
            if (cacheData.get(newMap1.title) == null) { 
                degreedToAdd.add(newMap1.title)
            }
        }

    }
    
    // Create the XML string
    def xml = new StringWriter()
    def builder = new MarkupBuilder(xml)

    
    builder.root {
    degreedToDelete.each { element ->
        user {
            id(element)
        }
    }
    }
    
    // Get the XML string
    def xmlString = xml.toString()

    message.setProperty("degreedToDelete",xmlString);
    message.setProperty("degreedToUpdateMap",degreedToUpdateMap);
    message.setProperty("degreedToAdd",degreedToAdd);
    message.setProperty("degreedToUpdate",degreedToUpdate);
    message.setProperty("degreedToDeleteMap",degreedToDeleteMap);
    message.setProperty("allowedRequirementTypeIdsList", allowedRequirementTypeIdsList)

    messageLog.addAttachmentAsString("Learnings to be Deleted in Degreed " + userID as String, degreedToDelete.join(","), "text/plain");
    messageLog.addAttachmentAsString("Learnings to be Added in Degreed " + userID as String, degreedToAdd.join(","), "text/plain");
    messageLog.addAttachmentAsString("Learnings to be Updated in Degreed " + userID as String, degreedToUpdate.join(","), "text/plain");
   // messageLog.addAttachmentAsString("Allowed Requirement Type Ids " + userID as String, allowedRequirementTypeIdsList.join(","), "text/plain");

    return message;
}
