import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Properties
    def properties = message.getProperties();
    value = properties.get("access_token");
    
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("token");
    cacheData.put("token",value)
    message.setHeader("token",cacheData);
    message.setHeader("sfsfAccessToken", 'true');

    return message;
}