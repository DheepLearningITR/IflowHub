import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

    //Properties
    def properties = message.getProperties();
    title = properties.get("title");
    
    degreedDeleteList = properties.get("degreedToDeleteMap")
    
    def degreedDeleteRecordId = ""
    degreedToDeleteMap.each { map ->
    if (map.title == title) {
        degreedDeleteRecordId = map.id
    }
    
    }
    
    message.setProperty("degreedDeleteRecordId", degreedDeleteRecordId);
    
    return message;
}