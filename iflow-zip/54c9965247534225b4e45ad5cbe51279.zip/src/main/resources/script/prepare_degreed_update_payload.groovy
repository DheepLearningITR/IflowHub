import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.net.URLEncoder;
import java.text.SimpleDateFormat
def Message processData(Message message) {
    //Properties
    def properties = message.getProperties();
    content_type = properties.get("content-type");
    is_required = properties.get("is-required");
    revision_date = properties.get("revision-date");
    content_type_id = properties.get("content-type-id");
    component_id = properties.get("component-id");
    user_id = properties.get("user-id");
    required_date = properties.get("required-date");
    cpnt_classification = properties.get("cpnt_classification");
    assigner_username = properties.get("assigner-username");
    assigner_ids_list = assigner-username.split(',').collect { it.trim() }
    def assigner_id = assigner_ids_list[0]



    title = properties.get("title");

    degreedUpdateList = properties.get("degreedToUpdateMap")

    def degreedUpdateRecordId = ""
    degreedUpdateList.each { map ->
    if (map.title == title) {
        degreedUpdateRecordId = map.id
    }

    }

    def f_req_date = ""
    def assignment_type = ""
    def books_list = ["AUDIO SUMMARY", "AUDIO BOOK", "BOOK", "BOOK SUMMARY"]
    def article_list = ["BRIEF", "DOC", "INFORMAL", "LINKED CONTENT", "SOP", "SYSTEM_QUICKGUIDE_ENTITY", "TASK"]
    def course_list = ["CHANNEL", "VIRT", "CURRICULA", "PROGRAM", "CLASS", "COURSE", "MOOC", "OJT", "ONLINE", "SELF", "SYSTEM_PROGRAM_ENTITY", "SYSTEM_COLLECTION_ENTITY", "SYSTEM_EXTERNAL_ENTITY"]
    def event_list = ["OTHER"]
    def video_list = ["VIDEO"]

    if(books_list.contains(content_type_id)){
        content_type = "book"
    }
    else if(article_list.contains(content_type_id)){
        content_type = "article"
    }
    else if(event_list.contains(content_type_id)){
        content_type = "event"
    }
    else if(course_list.contains(content_type_id)){
        content_type = "course"
    }
    else if(video_list.contains(content_type_id)){
        content_type = "video"
    }
    else{
        content_type = "course" // Course is the default content type
    }


    def content_id = "";

    if(cpnt_classification != "PROGRAM"){
        content_id = component_id + ":" + content_type_id + ":" + revision_date;
    }
    else{
        content_id = component_id
    }

    if(required_date){
        def outputDateFormat = "yyyy-MM-dd HH:mm:ss.SSSSSSS"
        def reqTimeStamp = new Date(Long.parseLong(required_date)-40319600)
        def f_date = new SimpleDateFormat(outputDateFormat).format(reqTimeStamp)
        
        //def r_date = Long.parseLong(required_date) - 40319600
        //def format_req_date = new Date(r_date)
        //def f_date = format_req_date.format("YYYY-MM-dd HH:mm:ss.SSSSSSS")
        
        replaceDate = f_date.replace(" ", "T")
        spltDate = replaceDate.split('T')
        f_req_date = spltDate[0] + "T00:00:00.0000000"
        
    } else {
        f_req_date = null
    }

    if (is_required && is_required.equals("true")) {
    assignment_type = "Required"
    payload = [
    "data": [
          "type": "required-learning",
          "attributes": [
               "user-id": user_id,
               "user-identifier-type": "EmployeeId",
               "content-id": content_id,
               "content-id-type": "ExternalId",
               "content-type": content_type,
               "assignment-type": "Required",
               "due-at": f_req_date
                        ]
            ]
        ]
      
    }
    else{
      assignment_type = "Assigned" // Only Required is allowed, with assigned we need to provide assigner id.
      payload = [
     "data": [
          "type": "required-learning",
          "attributes": [
               "user-id": user_id,
               "user-identifier-type": "EmployeeId",
               "content-id": content_id,
               "content-id-type": "ExternalId",
               "content-type": content_type,
               "assignment-type": "Assigned",
               "due-at": f_req_date,
               "assigner-id": assigner_id,
               "assigner-identifier-type": "EmployeeId"
                        ]
            ]
        ]
    }

    def json = new groovy.json.JsonBuilder(payload);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString());
    message.setBody(bodyPayload);
    message.setProperty("assignment_type", assignment_type)
    message.setProperty("degreedUpdateRecordId", degreedUpdateRecordId);
    return message;
}
