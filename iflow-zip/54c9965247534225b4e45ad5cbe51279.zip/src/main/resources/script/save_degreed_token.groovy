import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.time.TimeCategory
import java.time.LocalDateTime

def Message processData(Message message) {
    //Properties
    def properties = message.getProperties();
    value = properties.get("access_token");
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("tokenDegreed");
    cacheData.put("tokenDegreed",value)
    message.setHeader("tokenDegreed",cacheData);
    
    return message;
}