import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def properties = message.getProperties();
    degreedToAdd = properties.get("degreedToAdd");
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("Skills to be Added in Degreed", degreedToAdd.join(","), "text/plain");
    return message;
}