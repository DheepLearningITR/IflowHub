import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    // Optional: Log message (only if messageLogFactory is available in your environment)
    def messageLog = messageLogFactory?.getMessageLog(message);
    
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties() as Map<String, Object>;

    // Remove xsi:nil="true"
    body = body.replace('xsi:nil="true"', '');

    // Set cleaned body as new message body
    message.setBody(body);

    // Store cleaned body as a property named "BusinessPartnerPayload"
    message.setProperty("BusinessPartnerPayload", body);

    return message;
}