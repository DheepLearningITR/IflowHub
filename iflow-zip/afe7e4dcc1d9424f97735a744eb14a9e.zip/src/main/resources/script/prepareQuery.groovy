import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
def Message processData(Message message) {

    def jsonSlurper = new JsonSlurper();
    def properties = message.getProperties() as Map<String, Object>;
    def userKey = properties.get("User Key");

    def apiKey = properties.get("SAP Customer Data Cloud API Key");
    def secretKey = properties.get("SAP Customer Data Cloud Secret Key");
    def datacentre = properties.get("Gigya Data Centre");
    def organizationPayload = jsonSlurper.parseText(properties.get("BusinessPartnerOrganisation") as String) ;
    def org = organizationPayload.OrgData.organizations[0];

    def profilePayload = jsonSlurper.parseText(properties.get("profileJson") as String) ;
    def assocOrgPayload = jsonSlurper.parseText(properties.get("assocOrgJson") as String) ;
    def additionalDataPayload = jsonSlurper.parseText(properties.get("additionalDataJson") as String) ;
    
    def assocOrgPayloadJson = new JsonBuilder(assocOrgPayload.AssociatedOrg);
    def additionalDataJson = new JsonBuilder(additionalDataPayload.Data);
    def profilePayloadJson = new JsonBuilder(profilePayload.ProfileData);

    if (properties.get("NewAccountCreation")){

        
        message.setProperty("URL" , "https://accounts."+datacentre+".gigya.com/accounts.b2b.inviteMember");

        def query = "apiKey=" + apiKey + "&secret=" + secretKey + "&userKey="+ java.net.URLEncoder.encode(userKey, "UTF-8")  +
        "&bpid="+ java.net.URLEncoder.encode(org.BPID.toString(), "UTF-8") +
        "&accountOrganization="+ java.net.URLEncoder.encode(assocOrgPayloadJson.toString(), "UTF-8") +
        "&email="+ message.getProperty("AccountUIDEncoded") +
        "&profile="+ java.net.URLEncoder.encode(profilePayloadJson.toString(), "UTF-8");
        
        if(!additionalDataJson.toString().equals('""'))
        {
            query = query + "&data="+ java.net.URLEncoder.encode(additionalDataJson.toString(), "UTF-8");
        }
        
        message.setProperty("Query" , query);
        
    }
    else
    {

        message.setProperty("URL" , "https://accounts."+datacentre+".gigya.com/accounts.b2b.setAccountOrganizationInfo");

        def query = "apiKey=" + apiKey + "&secret=" + secretKey + "&userKey="+ java.net.URLEncoder.encode(userKey, "UTF-8")  +
            "&bpid="+ java.net.URLEncoder.encode(org.BPID.toString(), "UTF-8") +
            "&roleNames=" +
            "&uid=" +message.getProperty("uid") +
            "&organizationInfo="+ java.net.URLEncoder.encode(assocOrgPayloadJson.toString(), "UTF-8");  
            
         if(!additionalDataJson.toString().equals('""'))
        {
            query = query + "&data="+ java.net.URLEncoder.encode(additionalDataJson.toString(), "UTF-8");
        }
        
        message.setProperty("Query" , query);
        
        message.setProperty("accountUpdateURL" , "https://accounts."+datacentre+".gigya.com//accounts.setAccountInfo");
        
        def accountUpdateQuery =  "apiKey=" + apiKey + "&secret=" + secretKey + "&userKey="+ java.net.URLEncoder.encode(userKey, "UTF-8")  +
        "&profile="+ java.net.URLEncoder.encode(profilePayloadJson.toString(), "UTF-8") +
        "&uid=" +message.getProperty("uid");
            
        if(!additionalDataJson.toString().equals('""'))
        {
            accountUpdateQuery = accountUpdateQuery + "&data="+ java.net.URLEncoder.encode(additionalDataJson.toString(), "UTF-8");
        }    
        
        message.setProperty("accountUpdateQuery" , accountUpdateQuery);
        
    }

    return message;
}
