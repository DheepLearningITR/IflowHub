import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    
       def jsonSlurper = new JsonSlurper();
       def properties = message.getProperties() as Map<String, Object>;
       
       def response = jsonSlurper.parseText(message.getBody(java.lang.String) as String) ; 
       
       if (response.statusCode < 400){
         message.setProperty("OrganizationExistsInCDC" , true);
         response.remove('callId');   
         response.remove('errorCode');   
         response.remove('apiVersion');   
         response.remove('statusCode');  
         response.remove('statusReason');  
         response.remove('time'); 
         message.setProperty("OrganizationFromCDC" , response);
       }
       else {
         message.setProperty("OrganizationExistsInCDC" , false);
       }
       //Headers 
       
       message.setBody(properties.get("organizationJson"))
      
       return message;
}
