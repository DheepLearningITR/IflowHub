import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
    //Body
    def jsonSlurper = new JsonSlurper();

    def properties = message.getProperties() as Map<String, Object>;
    
    def userKey = properties.get("User Key");
    def datacentre = properties.get("Gigya Data Centre");
    def encodedEmailID = properties.get("AccountUIDEncoded");
    def apiKey = properties.get("SAP Customer Data Cloud API Key");
    def secretKey = properties.get("SAP Customer Data Cloud Secret Key");

    def url = "https://accounts."+datacentre+".gigya.com/accounts.search";
    
    message.setProperty("URL" , url);

    def query ="apiKey="+ apiKey +"&secret=" + secretKey + "&userKey="+ java.net.URLEncoder.encode(userKey, "UTF-8")  +
    "&query=SELECT * FROM accounts WHERE profile.email='"+encodedEmailID+"'";

    message.setProperty("Query" , query);

    return message;
}
