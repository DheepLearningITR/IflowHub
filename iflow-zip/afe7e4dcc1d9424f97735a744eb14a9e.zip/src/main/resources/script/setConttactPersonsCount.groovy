import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
    //Body
    def jsonSlurper = new JsonSlurper();

    def properties = message.getProperties() as Map<String, Object>;
    
    def cpPayload = properties.get("BusinessPartnerCustomer") as String;
    
    def contactPersonsData = jsonSlurper.parseText(cpPayload);
    
    if( contactPersonsData.Payload != null)
    {
        message.setProperty("contactPersonsCount" , contactPersonsData.customers.size());
        message.setProperty("isSingleContactPerson" , false);
    }
    else{
        message.setProperty("isSingleContactPerson" , true);
        message.setProperty("contactPersonsCount" , 1);
    }
    
    message.setProperty("contactPersons" , cpPayload);

    return message;
}
