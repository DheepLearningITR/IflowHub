import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;

def Message processData(Message message) {

    def body = message.getBody(java.lang.String) as String;
    
    def jsonSlurper = new JsonSlurper();
    def orgData = jsonSlurper.parseText(body);
    
    def orgJson = new JsonBuilder(orgData.OrganizationData);
    
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("Org Data : ", orgJson as String , "text/xml");
    
    message.setProperty("organizationPayloadEncoded" , java.net.URLEncoder.encode(orgJson as String, "UTF-8"));

    return message;
}
