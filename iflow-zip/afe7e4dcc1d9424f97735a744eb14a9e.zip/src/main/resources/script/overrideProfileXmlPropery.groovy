import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

    def properties = message.getProperties() as Map<String, Object>;

    def body = message.getBody(java.lang.String) as String;

    def messageLog = messageLogFactory.getMessageLog(message);


    messageLog.addAttachmentAsString("Customer Extended Profile XML", body , "text/xml");

    message.setProperty("profileXml" , body);

    message.setBody(properties.get("customerEnhancedPayload"));

    return message;


}
