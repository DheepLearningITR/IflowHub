
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
       def body = message.getBody(java.lang.String) as String;
       def object = new JsonSlurper().parseText(body);
       //Properties 
       map = message.getProperties();
       def setOrgId = map.get("OrganizationID");
       def contacts = object.Relationships.ContactIDEmail;
       if(contacts instanceof java.util.ArrayList){
        for(def contact : contacts){
          if(contact.OrganizationID.equals(setOrgId)){
              def contactId = contact.ContactPersonID;
            message.setProperty(contactId+"_EmailID", contact.Email)
            message.setProperty(contactId+"_ContactPersonID", contactId)
            message.setProperty(contactId+"_department", contact.department);
            message.setProperty(contactId+"_jobFunction", contact.jobFunction)
            message.setProperty(contactId+"_phone", contact.phone)
         }
      }
    }else{
        def contactId = contacts.ContactPersonID;
        message.setProperty(contactId+"_EmailID", contacts.Email)
      message.setProperty(contactId+"_ContactPersonID", contacts.ContactPersonID)
      message.setProperty(contactId+"_department", contacts.department);
      message.setProperty(contactId+"_jobFunction", contacts.jobFunction)
      message.setProperty(contactId+"_phone", contacts.phone)
    }
       value = map.get("BusinessPartnerPayload");
       message.setBody(value);
       return message;
}