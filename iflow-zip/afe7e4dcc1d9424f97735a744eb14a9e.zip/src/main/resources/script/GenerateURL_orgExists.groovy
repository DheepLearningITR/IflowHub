import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
   
    
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
   def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    
    def properties = message.getProperties() as Map<String, Object>;
   
    def apiKey = properties.get("API Key");
    def secretKey = properties.get("Secret Key");
    def datacentre = properties.get("Gigya Data Centre");
    def enableLog = properties.get("Enable Log");
    def organizationPayload = jsonSlurper.parseText(properties.get("BusinessPartnerOrganisation") as String) ;
    def storePayload = jsonSlurper.parseText(properties.get("BusinessPartnerCustomer") as String);
   def orgValue = organizationPayload.OrgData;
        orgValue = orgValue.organizations
    
    for(def org : orgValue){
        //org.remove('externalId');
         def orgPayload = new JsonBuilder(org);
         def url = "https://accounts."+datacentre+".gigya.com/accounts.b2b.registerOrganization?apiKey="+apiKey+"&organization="+orgPayload+"&requester="+new JsonBuilder(storePayload);
          message.setProperty("URL" , url);
    
        if(messageLog != null && enableLog.equals('true')) {
            messageLog.addAttachmentAsString("Log - Request Payload" , "\n\n" + url,
                                                        "text/xml");
        
    }
}
   
  
   
    message.setBody(object);
    return message;
}