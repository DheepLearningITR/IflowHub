
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Body 
    def jsonSlurper = new JsonSlurper();
    def properties = message.getProperties() as Map<String, Object>;

    def organizationPayload = jsonSlurper.parseText(properties.get("BusinessPartnerOrganisation") as String) ;
    
    message.setProperty("BPIDEncoded" , java.net.URLEncoder.encode(organizationPayload.OrgData.organizations[0].BPID as String ));
   
    def orgPayload = new JsonBuilder(organizationPayload.OrgData.organizations[0]);
    message.setProperty("organizationPayloadEncoded" , java.net.URLEncoder.encode(orgPayload.toString(), "UTF-8"));
                                                        
    message.setProperty("organizationJson" , orgPayload.toString());


   return message;
}