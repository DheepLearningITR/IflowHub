import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);

    def properties = message.getProperties() as Map<String, Object>;
    def storePayload = properties.get("BusinessPartnerCustomer") as String; 
    
    messageLog.addAttachmentAsString("Before Set Properties" , "\n\n" + storePayload,
                                                        "text/xml");

    

    return message;
}
