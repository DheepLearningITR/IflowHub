import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper;

def Message processData(Message message) {

	def map = message.getProperties();
	def countryDialingCodeList = map.get("countryDialingCodeList").toString();
	def countries = new XmlSlurper().parseText(countryDialingCodeList);

	countries.country.findAll{
	    p -> 
	    	p.countryDialingCodeTo.equals(map.get("phoneCode"));
	    
	}.each{
	    p -> 
	    	message.setProperty("phoneCountryCode", p.countryCode);
	}

	System.out.println("Phone Code : "+ map.get("phoneCode"));
	System.out.println("Phone Country Code : "+ map.get("phoneCountryCode"));
	return message;
}