import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
	
	def map = message.getProperties();
	def countryDialingCodeList = map.get("countryDialingCodeList").toString();
	def countries = new XmlSlurper().parseText(countryDialingCodeList);

	countries.country.findAll{
	    p -> 
	    	p.countryDialingCodeTo.equals(map.get("mobileCode"));
	    
	}.each{
	    p -> 
	    	message.setProperty("mobileCountryCode", p.countryCode);
	}
	
	System.out.println("Mobile Code : "+ map.get("mobileCode"));
	System.out.println("Mobile Country Code : "+ map.get("mobileCountryCode"));
	return message;
}