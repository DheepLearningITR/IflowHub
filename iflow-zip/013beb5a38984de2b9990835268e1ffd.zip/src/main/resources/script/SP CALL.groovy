import com.sap.gateway.ip.core.customdev.util.Message

// Function to process the message and decide on the stored procedure call
def Message processData(Message message) {
    // Get the filename from the message headers
    def fileName = message.getProperty("Filename")

    // Determine the stored procedure name or ignore the file
    def storeProcedureCall = StoreProcedureCallStatement(fileName)

    // If a valid stored procedure was found, set it as the message body
    if (storeProcedureCall != null) {
        message.setBody(storeProcedureCall)
    } else {
        // Log a message and return the original message if unsupported
        logUnsupportedFile(fileName)
    }

    return message
}

// Function to generate the stored procedure call or return null for unsupported files
def StoreProcedureCallStatement(String fileName) {
    def SPName = ""

    // Check if the filename contains specific identifiers
    if (fileName.contains("dds-expense-reports")) {
        SPName = "CONCUR_EXP_DDS_EXPENSE_SP"
    } else if (fileName.contains("dds-cards-transaction")) {
        SPName = "CONCUR_EXP_DDS_CCTRANSACTIONS_SP"
    } else if (fileName.contains("dds-attendee")) {
        SPName = "CONCUR_EXP_DDS_ATTENDEE_SP"
    } else if (fileName.contains("dds-cards-account")) {
        SPName = "CONCUR_EXP_DDS_CCACCOUNTS_SP"
    } else if (fileName.contains("dds-list-item")) {
        SPName = "CONCUR_EXP_DDS_LISTITMES_SP"
    } else if (fileName.contains("dds-spend-user")) {
        SPName = "CONCUR_EXP_DDS_SPENDUSER_SP"
    } else if (fileName.contains("dds-core-user")) {
        SPName = "CONCUR_EXP_DDS_COREUSER_SP"
    } else if (fileName.contains("dds-reference-expense-type")) {
        SPName = "CONCUR_EXP_DDS_REF_EXPENSE_TYPE_SP"
    } else if (fileName.contains("dds-reference-payment-code")) {
        SPName = "CONCUR_EXP_DDS_REF_PAYMENT_CODE_SP"
    } else if (fileName.contains("dds-reference-payment-type")) {
        SPName = "CONCUR_EXP_DDS_REF_PAYMENT_TYPE_SP"
    } else if (fileName.contains("dds-reference-spend")) {
        SPName = "CONCUR_EXP_DDS_REF_SPEND_CATEGORY_SP"
    } else if (fileName.contains("dds-reference-approval-status") || fileName.contains("dds-reference-payment-status")) {
        SPName = "CONCUR_EXP_DDS_REF_STATUS_SP"
    } else {
        throw new IllegalArgumentException("Unsupported file type")
    }

    // Construct the stored procedure call
    return """<root>
	<StatementName>
		<storedProcedureName action="EXECUTE">
			<table> "SAP_CONTENT#SAP_CONCUR_EXP_DDS"."${SPName}"</table>
		</storedProcedureName>
	</StatementName>
</root>"""
}

// Function to log unsupported file types
def logUnsupportedFile(String fileName) {
    // Log the unsupported file
    println("Ignoring unsupported file: ${fileName}")
}
