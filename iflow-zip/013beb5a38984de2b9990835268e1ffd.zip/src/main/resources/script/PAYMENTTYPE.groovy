import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def bodyReader = message.getBody(java.io.Reader)
    def content = bodyReader.text
    def json = new JsonSlurper().parseText(content)
    def lines = content.split('\n')

    // Extract the filename from the message properties
    def filename = message.getHeaders().get("CamelFileNameOnly")

    // Extract the batch timestamp from the filename
    def batchTimestamp = extractBatchTimestampFromFilename(filename)

    // Create the root element
    def writer = new StringWriter()
    writer << '<root>\n'
    lines.each { line ->
        def body = line.trim()
        writer << createInsertStatement(body, filename, batchTimestamp)
    }
    writer << '</root>'

    // Set the final XML as the new content
    message.setBody(writer.toString())
    return message
}

def createInsertStatement(body, filename, batchTimestamp) {
    // Use the "id" field from the JSON to perform upsert
    def id = extractIdFromBody(body)
    def time = extracteventtimeFromBody(body)
    def type = extracteventtypeFromBody(body)
    return """<INSERT_statement>
              <dbTableName action="INSERT">
                  <table>SAP_CONTENT#SAP_CONCUR_EXP_DDS.CONCUR_EXP_DDS_OBJ_REF_PAYMENT_TYPE</table>
              <access>
                  <JSON><![CDATA[${body}]]></JSON>
                  <id>${id}</id>
                  <batchTimestamp>${batchTimestamp}</batchTimestamp>
                  <filename>${filename}</filename>
                  <processed_flag></processed_flag>
                  <eventtime>${time}</eventtime>
                  <eventtype>${type}</eventtype>
              </access>
                 </dbTableName>
              </INSERT_statement>"""
}

def extractIdFromBody(body) {
    // Implement code to extract the "id" field from the JSON body
    // and return it as a string
    // For example, using Groovy's JSON slurper:
    def json = new groovy.json.JsonSlurper().parseText(body)
    return json.id.toString()
}
def extracteventtimeFromBody(body) {
    // Implement code to extract the "id" field from the JSON body
    // and return it as a string
    // For example, using Groovy's JSON slurper:
    def json = new groovy.json.JsonSlurper().parseText(body)
    return json.time.toString()
}

def extracteventtypeFromBody(body) {
    // Implement code to extract the "type" field from the JSON body
    // and return the last 6 characters as a string
    // For example, using Groovy's JSON slurper:
    def json = new groovy.json.JsonSlurper().parseText(body)
    def type = json.type.toString()
    return type.substring(Math.max(0, type.length() - 6))
}
def extractBatchTimestampFromFilename(filename) {
    // Extract the batch timestamp from the filename
    def matcher = (filename =~ /batchtimestamp-(\d{4}-\d{2}-\d{2}T\d{2}.\d{2}.\d{2}Z)/)
    def batchTimestamp = matcher ? matcher[0][1] : null

    // Replace dots with colons in the timestamp
    batchTimestamp = batchTimestamp?.replace('.', ':')

    return batchTimestamp
}