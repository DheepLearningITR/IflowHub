import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
def Message processData(Message message)
 {
    def Output="";
    //Get Vehicle Search response body
    def body = message.getBody(String.class);
	
   
    def list = new JsonSlurper().parseText(body);
    
    //Check existence of the vehicle and set property post or put
    
    if (list.size() == 0)
    {
    message.setProperty("dvhVehicleID","");
    message.setProperty("operation","POST")
    }
    
    else
    {
    def val =list.equipmentId.toString();
     
    val=val.substring(1,val.length()- 1);
    val="id="+val;
    message.setProperty("dvhVehicleID",val);
    message.setProperty("operation","PATCH")
    }
    return message;             
 }