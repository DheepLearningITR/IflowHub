import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
def Message processData(Message message)
 {
    def properties = message.getProperties();
    message.setProperty("S4HANAVehicleID" , java.net.URLEncoder.encode(properties.get("S4HANAVehicleID"), "UTF-8"));

    return message;             
 }