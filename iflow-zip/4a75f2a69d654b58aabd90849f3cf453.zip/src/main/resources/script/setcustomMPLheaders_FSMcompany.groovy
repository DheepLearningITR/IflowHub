import com.sap.gateway.ip.core.customdev.util.Message;
 
def Message processData(Message message) {
    /*this script is to log the FSM company IDs to which is data is loaded successfully.*/
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        def properties  = message.getProperties();		
		def multiCompFlag = properties.get("EnableMultiCompany");
        if(multiCompFlag == "true"){
			messageLog.addCustomHeaderProperty("FSMAccountCompany_Success", properties.get("X-Account-ID") + '|' + properties.get("X-Company-ID"));
        }
    }
    return message;
}