/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonOutput ;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
	
	def userId = message.getProperty("userId") ;
	def body = message.getBody(java.lang.String) as String;
	
	def jsonSlurper = new JsonSlurper();
	def inputPayload = jsonSlurper.parseText(body) ;
	assert inputPayload instanceof List ;
	
	if( inputPayload.size() == 0 ) {
		throw new Exception("User does not exists in C4C for user id " + userId) ;
	}
	
	def user = inputPayload[0] ;
	def userObjectId = user.get("ObjectID") ;
	if( userObjectId == null ) {
		throw new Exception("Retrieved user doen not have ObjectID") ;
	}
	message.setProperty("userObjectId", userObjectId) ;
	user.put("InactiveIndicator", false) ;
	
	message.setBody(JsonOutput.toJson(user)) ;
	
	return message;
}

