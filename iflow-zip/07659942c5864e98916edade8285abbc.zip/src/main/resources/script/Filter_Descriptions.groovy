/*
 * @Author: Chintan Raiyani 
 * @Date: 2019-08-21 15:38:58 
 * @Last Modified by:   Chintan Raiyani 
 * @Last Modified time: 2019-08-27 11:41:58 
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlParser;
import groovy.util.XmlNodePrinter;
import java.io.PrintWriter;
import java.io.StringWriter;

/* Filters the description other than the user provided language 
*  and also filter product categories for which product assignment is not allowed
Params:
------
    message(com.sap.gateway.ip.core.customdev.util.Message):
        input message
Returns:
--------
    message(com.sap.gateway.ip.core.customdev.util.Message):
        output message
*/

def Message processData(Message message) {
    //extract message body and remove unwanted languages
    def headers = message.getHeaders(); 
    def body = message.getBody(java.lang.String) as String;
    try{
        def languageCode = headers.get('languageCode') as String
        def response = new XmlParser().parseText(body)
        //find and remove product category which is not allowed for assignment
        def delNodes=response.'**'.findAll { it.name() == 'ProductAssignmentAllowedIndicator' && it.text().toLowerCase() == 'false' }
        for(def node : delNodes){
            def parent=node.parent()
            //exclude root node description
            parent.name()=='ProductCategory'?parent.parent().remove(parent):''
        }
        //find and remove unwanted description nodes
        delNodes=response.'**'.findAll { it.name() == 'Description' && it.@languageCode != languageCode }
        for(def node : delNodes){
            def parent=node.parent()
            //exclude root node description
            parent.name()=='ProductCategoryDescription'?parent.parent().remove(parent):''
        }
        //convert to string and setbody
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(response)
        message.setBody(stringWriter.toString())
    }catch(Exception ex){
    	//send input body in case of error
        message.setBody(body)
    }
    return message;
}