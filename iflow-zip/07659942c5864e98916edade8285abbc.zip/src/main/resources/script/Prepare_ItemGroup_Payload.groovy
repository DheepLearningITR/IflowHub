/*
 * @Author: Chintan Raiyani 
 * @Date: 2019-08-16 15:38:58 
 * @Last Modified by:   Chintan Raiyani 
 * @Last Modified time: 2019-08-19 16:41:58 
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

/*
Params:
------
    message(com.sap.gateway.ip.core.customdev.util.Message):
        input message
Returns:
--------
    message(com.sap.gateway.ip.core.customdev.util.Message):
        output message
*/

def Message processData(Message message) {
    //extract message body data field and convert it to json array
    try{
    	def body = message.getBody(java.lang.String) as String;
    	def json = new JsonSlurper().parseText(body)
    	def body_str=JsonOutput.toJson(json.ItemGroups.data)
    	
    	//if data field has only one payload, it will be as object so it need to be converted to the form of json array
    	if(!(json.ItemGroups.data instanceof List)){
    	    body_str='['+body_str+']'
    	}
    	
    	//replace message body with converted payload
    	message.setBody(body_str)
    }catch(Exception ex){
    	//send empty array in case of error
        message.setBody("[]")
    }
    return message;
}