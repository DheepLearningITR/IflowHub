/*
 * @Author: Chintan Raiyani 
 * @Date: 2019-09-05 16:00:46 
 * @Last Modified by: Chintan Raiyani
 * @Last Modified time: 2019-09-05 16:20:47
 */

import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

/*
*Raise an error message for externalIds for which errors is generated in FSM system

Params:
------
    message(com.sap.gateway.ip.core.customdev.util.Message):
        input message
Returns:
--------
    message(com.sap.gateway.ip.core.customdev.util.Message):
        output message
*/
def Message processData(Message message) {
     
    def errors = [];//Store objects of ErrorClass
    def body = message.getBody(java.lang.String) as String;//Extracts body of message
 	
    try{
        
        def json_body = new JsonSlurper().parseText(body);
        
        //check error for each response
        json_body.each{
            //Add to errors array not success(create/update:201, delete:200)
            if( it.get('status') != 201 && it.get('status') != 200 ){
                errors.add(new ErrorClass(ProductCategoryID:it.externalId,error:it.ex.message));
            }
        }
        
    } catch (Exception e){
        
        //add exception to errors
        errors.add(new ErrorClass(ProductCategoryID:null,error:"Error in respose payload format."))
        
    } finally {
        
        //throw custom exception if has errors else return message
        if(errors.size()!=0){
            throw new ErrorMessageException(JsonOutput.prettyPrint(JsonOutput.toJson(errors)));
        } else {
            return message;
        }
        
    }
       
}

/*
* Stores Product Category errors
*/
class ErrorClass {
   String ProductCategoryID;
   String error;
}

/*
* Custom Exception Class
*/
class ErrorMessageException extends Exception{
   String msg;
   ErrorMessageException(String msg) {
     this.msg = msg;
   }
   public String toString(){
     return ("C4C To FSM replication error" + " : " + this.msg);
  }
}