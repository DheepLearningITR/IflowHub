import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import groovy.json.*

def Message removeInvalidCharacters(Message message) {
    String body = message.getBody(java.lang.String);
    body = body.replaceAll("\\\\u0002", " ");
    message.setBody(body);
    return message;
}

def Message saveAribaPayload(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String body = message.getBody(String);
    debugOutput = message.properties.debugOutput == "true"
    debugOutput && mpl.addAttachmentAsString('1 - Ariba payload', body,"text/plain");
    return message;
}

def Message processWorkflowInstances(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    def listToStart = new XmlSlurper().parseText( "<root/>" )
    def listToCancel = []
    def log = []
    debugOutput = message.properties.debugOutput == "true"

    def workflowInstances = new groovy.json.JsonSlurper().parseText(message.getBody(String));
    debugOutput && mpl.addAttachmentAsString('2 -running Workflow instances', new JsonBuilder(workflowInstances).toPrettyString(),"text/plain");

    def aribaBody = message.properties.Record;
    def pageToken = message.properties.page_token;
    def xml = new XmlSlurper().parseText( aribaBody )
    
    if (!xml.Records[0].StatusString || xml.Records[0].StatusString == "") {
        // JSON-to-XML results in a single, empty Record instead of "none"
        xml = new XmlSlurper().parseText( "<?xml version='1.0' encoding='UTF-8'?><root></root>" )
    }
    log << "List of actions to be taken"
    log << "Events from Ariba: " + xml.Records.size() + (pageToken ? " (more expected, Page Token is " + pageToken + ")" : "")
    log << "Workflow definition used: " + message.properties.workflowDefinitionId
    log << "Running Workflows: " + workflowInstances.size()
    xml.Records.each {
        def RequisitionId = it.UniqueName.text()
        def status = it.StatusString.text()
        
        // Note: the businessKey is semantically unique, but this is not technically enforced on workflow side. So treat this list as if it could contain multiple instances.
        def matchingInstances = workflowInstances.findAll{ it.businessKey == RequisitionId }
        def isWorkflowStarted = (matchingInstances.size() > 0)
        if (matchingInstances.size() > 1) {
            log << "WARNING: more than one instance found for businessKey " + RequisitionId
        }
        
        if (status == "Submitted") {
            if (!isWorkflowStarted) {
                // start a new workflow
                listToStart.appendNode(it)
                log << ("Starting new workflow for " + RequisitionId)
            } else {
                // Delta-change is submitted, but workflow already running? -> assume something has changed and restart the workflow
                matchingInstances.each { listToCancel << it.id }
                listToStart.appendNode(it)
                log << ("Restarting workflow for " + RequisitionId)
            }
        } else if (isWorkflowStarted){
            // cancel the workflow
                matchingInstances.each { listToCancel << it.id }
            log << "Canceling workflow for " + RequisitionId
        } else {
            log << "Ignoring PR " + RequisitionId + " as it is in status " + status + " and no workflow is running"
        }
    }

    debugOutput && mpl.addAttachmentAsString('3 - Workflow action log', log.join('\n'),"text/plain");

    message.properties.WorkflowsToCreate = groovy.xml.XmlUtil.serialize(listToStart);
    message.setBody(listToCancel.join('\n'));


    return message;
}

def Message saveRecord(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);
    String body = message.getBody(String);
    message.properties.Record = body;
    message.setBody("");
    return message;
}

def asBool(String value) {
    if (!value) return null
    return value.toBoolean()
}

def asNumber(String value) {
    if (!value) return null
    return Float.parseFloat(value)
}

def Message convertXMLtoJSON(Message message) {
    def mpl = messageLogFactory.getMessageLog(message)
    String body = message.getBody(String)
    def xml = new XmlParser().parseText( body )
    def json = new groovy.json.JsonSlurper().parseText('{ "PurchaseRequisition": { "Header": {}, "LineItems": [] }, "isPurchaseRejected": {}, "ApprovalStepHistory": [], "Ariba": {}}')

    json.Ariba.realm = message.properties.realm;
    json.Ariba.userid = message.properties.ApproverUserid;
    json.Ariba.passwordadapter = message.properties.ApproverPasswordadapter;
    json.Ariba.APIkey = message.properties.ApprovalAPIkey;

    json.PurchaseRequisition.Header.Name = xml.Name.text()
    json.PurchaseRequisition.Header.TotalCost = Float.parseFloat(xml.TotalCost.ApproxAmountInBaseCurrency.text())

    // Header fields
    json.PurchaseRequisition.Header.RequisitionId = xml.UniqueName.text()
    json.PurchaseRequisition.Header.InitialRequisitionId = xml.InitialUniqueName.text()
    json.PurchaseRequisition.Header.Name = xml.Name.text()
    json.PurchaseRequisition.Header.VersionNumber = asNumber(xml.VersionNumber?.text())
    json.PurchaseRequisition.Header.PreviousVersion = xml.PreviousVersion?.UniqueName?.text()
    json.PurchaseRequisition.Header.NextVersion = xml.NextVersion?.UniqueName?.text()
    json.PurchaseRequisition.Header.TimeCreated = xml.TimeCreated?.text()
    json.PurchaseRequisition.Header.TimeUpdated = xml.TimeUpdated?.text()
    json.PurchaseRequisition.Header.CreateDate = xml.CreateDate.text()
    json.PurchaseRequisition.Header.SubmitDate = xml.SubmitDate.text()
    json.PurchaseRequisition.Header.RealTimeBudgetResponse = xml.RealTimeBudgetResponse.text()
    json.PurchaseRequisition.Header.Active = asBool(xml.Active.text())
    json.PurchaseRequisition.Header.ProcurementUnit = xml.ProcurementUnit.text()
    json.PurchaseRequisition.Header.Attachments = xml."Attachments.Attachments".text()
    json.PurchaseRequisition.Header.Requester = xml.Requester.UniqueName.text()
    json.PurchaseRequisition.Header.CompanyCode = xml.CompanyCode.UniqueName.text()
    json.PurchaseRequisition.Header.TotalCost = asNumber(xml.TotalCost.Amount.text())
    json.PurchaseRequisition.Header.Currency = xml.TotalCost.Currency.UniqueName.text()

    // Line item fields
    json.PurchaseRequisition.LineItems = xml.LineItems.collect {
            [ 
                CommodityCode: it.CommodityCode.UniqueName.text(),
                CommonCommodityCode: it."Description.CommonCommodityCode".Name.text(),
                SupplierPartAuxiliaryID: it."Description.SupplierPartAuxiliaryID".text(),
                OriginalPrice: asNumber(it.OriginalPrice.ApproxAmountInBaseCurrency.text()),
                IsPriceModifiedByUser: asBool(it.IsPriceModifiedByUser.text()),
                IsAdHoc: asBool(it.IsAdHoc.text()),
                AccountCategory: it.AccountCategory.UniqueName.text(),
                ChargeAmount: asNumber(it.ChargeAmount.text()),
                SupplierLocation: it.SupplierLocation.UniqueName.text(),
                BillingAddress: [
                    Name: it.BillingAddress.Name.text(),
                    Lines: it.BillingAddress.Lines.text(),
                    PostalCode: it.BillingAddress.PostalCode.text(),
                    City: it.BillingAddress.City.text(),
                    State: it.BillingAddress.State.text(),
                    Country: it.BillingAddress.Country.UniqueName.text(),
                    Phone: it.BillingAddress.Phone.text(),
                    Fax: it.BillingAddress.Fax.text(),
                ],
                Description: it."Description.Description".text(),
                ShortName: it."Description.ShortName".text(),
                TaxAmount: asNumber(it.TaxAmount.text()),
                ItemCategory: it.ItemCategory.UniqueName.text(),
                VATAmount: asNumber(it.VATAmount.text()),
                SupplierName: it.Supplier.Name.text(),
                SupplierId: it.Supplier.UniqueName.text(),
                SupplierPartNumber: it."Description.SupplierPartNumber".text(),
                Price: asNumber(it."Description.Price".Amount.text()),
                PriceCurrency: it."Description.Price".Currency.text(),
                Amount: asNumber(it.Amount.Amount.text()),
                AmountCurrency: it.Amount.Currency.UniqueName.text(),
                BoughtFromPreferredSupplier: asBool(it.BoughtFromPreferredSupplier.text()),
                Quantity: asNumber(it.Quantity.text()),
                PurchaseOrg: it.PurchaseOrg.UniqueName.text(),
                DiscountAmount: asNumber(it.DiscountAmount?.Amount?.text()),
                NeedBy: it.NeedBy.text(),
                ItemNumber: it."Description.ItemNumber".text(),
                UnitOfMeasure: it."Description.UnitOfMeasure".UniqueName.text(),
                PurchaseGroup: it.PurchaseGroup.UniqueName.text(),
                DeliverTo: it.DeliverTo.text(),
                ShipTo: [
                    Name: it.ShipTo.Name.text(),
                    Lines: it.ShipTo.Lines.text(),
                    PostalCode: it.ShipTo.PostalCode.text(),
                    City: it.ShipTo.City.text(),
                    State: it.ShipTo.State.text(),
                    Country: it.ShipTo.Country.UniqueName.text(),
                    Phone: it.ShipTo.Phone.text(),
                    Fax: it.ShipTo.Fax.text(),
                ],
                SplitAccountings: it.SplitAccountings.collect {
                    [
                        Type: it.Type.UniqueName.text(),
                        CostCenterName: it.CostCenter.UniqueName.text(),
                        CompanyCode: it.CostCenter.CompanyCode.UniqueName.text(),
                        CostCenterDescription: it.CostCenter.CostCenterDescription.text(),
                        Percentage: asNumber(it.Percentage.text()),
                        Amount: asNumber(it.Amount.ApproxAmountInBaseCurrency.text()),
                    ]
                }
            ]
        }
        
    json.PurchaseRequisition.Header.Region = lookupRegion(message, json)

    message.setBody(new JsonBuilder(json).toPrettyString())
    return message
}

def String lookupRegion(message, json) {
    def mpl = messageLogFactory.getMessageLog(message);
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    String CompanyCode = json.PurchaseRequisition.Header.CompanyCode
    def region = null
    if (valueMapApi != null && CompanyCode != null) {
        region = valueMapApi.getMappedValue('Ariba', 'CompanyCode', CompanyCode, 'Workflow', 'Region');
    }
    return region;
}

