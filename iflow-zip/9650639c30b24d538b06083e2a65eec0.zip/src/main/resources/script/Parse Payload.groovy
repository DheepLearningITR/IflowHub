import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.ITApiFactory

// check is string is empty
def boolean isEmpty(String id) {
    return (id == null || id == "" || id == "null")
}
// returns a map of external Ids by splitting the provided string extId at the slash (/)
def Map getExternalIds(String extId, String fallbackServiceOrder=null) {
    Map extIds = [:]
    List splitIds = []
    if (extId != null && extId.size() > 0) {
        splitIds = extId.split('/')
        extIds['ServiceOrder'] = splitIds[0]
        if (splitIds.size() > 1) {
            extIds['ServiceOrderItem'] = splitIds[-1]
            if (splitIds.size() == 3) {
                extIds['ServiceOrderBundleItem'] = splitIds[-2]
            }
        }
    }
    if ((extIds['ServiceOrder'] == null || extIds['ServiceOrder'] == '') 
        && (fallbackServiceOrder != null || fallbackServiceOrder != '' ) ) {
        extIds['ServiceOrder'] = fallbackServiceOrder
    }
    return extIds
}
// routes
def bulkclearRoute(def activity) {
    activity.checkErrorOccured = ""
    activity.Irrelevant = ""
    activity.serviceType = ""
    activity.CreateServiceItem = ""
    activity.SourceActivityCompleted = ""
}
def bulksetRouteUpdateServiceOrder(Message message, def activity) {
    bulkclearRoute(activity)
}
def bulksetRouteIrrelevant(Message message, def activity) {
    bulkclearRoute(activity)
    activity.Irrelevant = "X"
}
def bulksetRouteError(Message message, String event, String fields, def activity) {
    bulkclearRoute(activity)
    activity.checkErrorOccured = "X"
    activity.checkErrorMessage = "The integration flow message won’t be processed further. Event " + event + " is missing field(s): " + fields
}
def bulksetRoutePMOrderUpdate(Message message, def activity) {
    bulkclearRoute(activity)
    activity.UpdatePlantMaintenance = "X"
}
def clearRoute(message) {
    message.setProperty("checkErrorOccured", "");
    message.setProperty("Irrelevant", "")
    message.setProperty("serviceType", "")
    message.setProperty("CreateServiceItem", "")
    message.setProperty("SourceActivityCompleted", "")
}
def setRouteIrrelevant(Message message) {
    clearRoute(message)
    message.setProperty("Irrelevant", "X")
}
def setRouteUpdateServiceOrder(Message message) {
    clearRoute(message)
}
def setRouteCreateServiceConfirmation(Message message) {
    clearRoute(message)
    message.setProperty("serviceType", "ServiceConfirmation")
}
def setRouteCreateServiceItem(message) {
    clearRoute(message)
    message.setProperty("CreateServiceItem", "X")
}
def setRouteCreatePlantMaintenanceItem(message) {
    clearRoute(message)
    message.setProperty("CreatePlantMaintenanceItem", "X")
}
def setRouteError(Message message, String event, String fields) {
    clearRoute(message)
    message.setProperty("checkErrorOccured", "X");
    message.setProperty("checkErrorMessage", "The integration flow message won’t be processed further. Event " + event + " is missing field(s): " + fields);
}
def setRouteCreateServiceOrder(message) {
    clearRoute(message);
    message.setProperty("CreateServiceOrder", "X")
}
def setRoutePMOrderCreate(message) {
    clearRoute(message);
    message.setProperty("CreatePlantMaintenance", "X")
}
def setRoutePMOrderUpdate(message) {
    clearRoute(message);
    message.setProperty("UpdatePlantMaintenance", "X")
}
def setRoutePMConfirmation(message) {
    clearRoute(message);
    message.setProperty("serviceType", "PlantConfirmation")
}
// add-on routes
def addRouteSourceActivityCompleted(message) {
    message.setProperty("SourceActivityCompleted","X")
}
// set globals
def setGlobalServiceOrderIds(Message message, Map externalIds) {
    message.setProperty("ServiceOrder", externalIds.ServiceOrder ?: '')
    message.setProperty("ServiceOrderItem", externalIds.ServiceOrderItem ?: '')
    message.setProperty("ServiceOrderBundleItem", externalIds.ServiceOrderBundleItem ?: '')
    message.setProperty("ParentServiceOrderItem", (externalIds.ServiceOrderBundleItem ?: externalIds.ServiceOrderItem) ?: '')
    message.setHeader("ServiceOrder", externalIds.ServiceOrder)
    message.setHeader("ServiceOrderItem", externalIds.ServiceOrderItem)
    message.setHeader("ServiceOrderBundleItem", externalIds.ServiceOrderBundleItem)
    message.setHeader("ParentServiceOrderItem", (externalIds.ServiceOrderBundleItem ?: externalIds.ServiceOrderItem))
}
def isServiceCallStatusSupported(sStatus, sStatusList) {
    def supportedStatusList = sStatusList.split("\\|")*.trim();
    
    if (sStatus in supportedStatusList) {
        return true;
    } else {
        return false;
    }
}
def isServiceCallTypeSupported(sType,ValueMappingPrefix) {
    def service = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    if (sType == '' || sType == null) {
        sType = "<null>"
    }
    
    def ServiceOrderType = service.getMappedValue(ValueMappingPrefix + 'ServiceCallFSM', ValueMappingPrefix + 'Type', sType, ValueMappingPrefix + 'ServiceOrderS4HANA', ValueMappingPrefix + 'TransactionType') ?: null;
    
    if (ServiceOrderType != null) {
        return true;
    } else {
        return false;
    }
}

// process message
def Message processData(Message message) { 
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)
    def eventType = jsonResult.eventType?.toLowerCase()
    def externalId
    def externalIds = [:]
    def completeCompatibilityMode = false
    def sourceActivity = jsonResult.data?.serviceCall?.activity?.sourceActivity as String
    def sourceActivityCompleted = jsonResult.data?.serviceCall?.sourceActivityCompleted as String
    def activityStatus = jsonResult.data?.serviceCall?.activity?.status as String
    def statusChangeReason = jsonResult.data?.serviceCall?.activity?.statusChangeReason as String
    def updatedProperties = jsonResult.data?.updatedProperty
    def activityExecutionStage = jsonResult.data?.serviceCall?.activity?.executionStage as String
    def fallbackServiceOrder = jsonResult.data?.serviceCall?.unifiedIdentifier?.externalId as String 
    def serviceCallStatus;
    def bUnassignCase = false;
    def ValueMappingPrefix = message.getProperty("ValueMappingPrefix");
    def MaintenanceServiceCallTypeCode = message.getProperty("MaintenanceServiceCallTypeCode")
    def ServiceCallCancelledStatusCode = message.getProperty("ServiceCallCancelledStatusCode")

    message.setHeader("EventType", eventType)

    // decide on iFlow route
    switch (eventType) {
        
        case "servicecall.created":
            serviceCallStatus = jsonResult.data?.status as String ?: ''
            serviceCallType = jsonResult.data?.type as String ?: ''
            serviceCallStatusList = message.getProperty("SupportedServiceCallStatus") as String ?: ''
            
            if (isServiceCallStatusSupported(serviceCallStatus, serviceCallStatusList) && isServiceCallTypeSupported(serviceCallType,ValueMappingPrefix)) {
                if (serviceCallType == MaintenanceServiceCallTypeCode) {
                    // route: Plant Maintenance Order update
                    setRoutePMOrderCreate(message)
                }else{
                    setRouteCreateServiceOrder(message)
                }
            }
            else {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            }
            break;

        case "servicecall.updated":
            externalId = jsonResult.data?.serviceCall?.externalId as String
            externalIds = getExternalIds(externalId, fallbackServiceOrder)
            setGlobalServiceOrderIds(message, externalIds)
            serviceCallType = jsonResult.data?.serviceCall?.type as String ?: ''
            serviceCallStatus = jsonResult.data?.serviceCall?.status as String ?: ''
            
            if (isEmpty(externalIds.ServiceOrder)  || updatedProperties == null) {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            } else if (serviceCallType == MaintenanceServiceCallTypeCode && serviceCallStatus == ServiceCallCancelledStatusCode) {
                // route: Irrelevant, ignore, no error for cancelled maintenance service calls
                setRouteIrrelevant(message)
            } else if (serviceCallType == MaintenanceServiceCallTypeCode) {
                // route: Plant Maintenance Order update
                setRoutePMOrderUpdate(message)
            }
            else {
                // route: Update Service Order
                //        (iFlow Notify Service Order Update)
                setRouteUpdateServiceOrder(message)
            }
            break

        case "activity.created":
            serviceCallType = jsonResult.data?.serviceCall?.type as String ?: ''
            if (sourceActivity != null) { //Duplication Cases
                externalId = jsonResult.data?.serviceCall?.activity?.sourceActivity?.externalId as String
                externalIds = getExternalIds(externalId, fallbackServiceOrder)
                setGlobalServiceOrderIds(message, externalIds)
                if (isEmpty(externalIds.ServiceOrder)) {
                    // route: Irrelevant, ignore, no error
                    setRouteIrrelevant(message)
                } else if (isEmpty(externalIds.ServiceOrderItem)) {
                    // route: Raise error
                    setRouteError(message, eventType, 'activity.sourceActivity.externalId')
                } else {
                    // route: Create Service Item or Plant Maintenance Order Item
                    if (serviceCallType == MaintenanceServiceCallTypeCode){
                        setRouteCreatePlantMaintenanceItem(message)
                    }else {
                        setRouteCreateServiceItem(message)
                    }
                }
            } else { //Creation Case
                externalId = jsonResult.data?.serviceCall?.unifiedIdentifier?.externalId as String
                externalIds = getExternalIds(externalId, fallbackServiceOrder)
                setGlobalServiceOrderIds(message, externalIds)
                
                if (isEmpty(externalIds.ServiceOrder)) {
                    // route: Irrelevant, ignore, no error
                    setRouteIrrelevant(message)
                } else {
                    // route: Create Service Item or Plant Maintenance Order Item
                    if (serviceCallType == MaintenanceServiceCallTypeCode){
                        setRouteCreatePlantMaintenanceItem(message)
                    }else {
                        setRouteCreateServiceItem(message)
                    }
                }
            }
            break

        case "activity.updated":
            externalId = jsonResult.data?.serviceCall?.activity?.externalId as String
            externalIds = getExternalIds(externalId, fallbackServiceOrder)
            setGlobalServiceOrderIds(message, externalIds)
            serviceCallType = jsonResult.data?.serviceCall?.type as String ?: '' 
            
            if (updatedProperties && updatedProperties.contains("status") && statusChangeReason == "UNASSIGN") {
                bUnassignCase = true;
            }
            
            if (isEmpty(externalIds.ServiceOrder) || updatedProperties == null) {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            } else if (activityStatus == null || activityExecutionStage == null) {
                // route: Raise error
                setRouteError(message, eventType, 'activity.status, activity.executionStage')
            } else if (serviceCallType == MaintenanceServiceCallTypeCode && activityStatus == "DRAFT" && !bUnassignCase) {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            } else if (serviceCallType == MaintenanceServiceCallTypeCode) {
                // route: Plant Maintenance Order update
                setRoutePMOrderUpdate(message)
            } else if (activityStatus == "DRAFT" && !bUnassignCase) {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            } else if (isEmpty(externalIds.ServiceOrderItem)) {
                // route: Raise error
                setRouteError(message, eventType, 'activity.externalId')
            }
            else {
                // route: Update Service Order
                //        (iFlow Notify Service Order Update)
                setRouteUpdateServiceOrder(message)
            }
            break

        case "activities.updated":
            def bulkcheckErrorOccured = ""
            def bulkIrrelevant = ""
            def bulkcheckErrorMessage = ""
            jsonResult.data?.serviceCall?.activities.each{ act ->
                externalId = act?.externalId as String
                externalIds = getExternalIds(externalId, fallbackServiceOrder)
                setGlobalServiceOrderIds(message, externalIds)                
                serviceCallType = jsonResult.data?.serviceCall?.type as String ?: ''
                updatedProperties = act?.updatedProperty
                statusChangeReason = act?.statusChangeReason as String
                activityStatus = act?.status as String
                activityExecutionStage = act?.executionStage as String

                if (updatedProperties && updatedProperties.contains("status") && statusChangeReason == "UNASSIGN") {
                    bUnassignCase = true;
                }

                if (isEmpty(externalIds.ServiceOrder) || updatedProperties == null) {
                    // route: Irrelevant, ignore, no error
                    bulksetRouteIrrelevant(message,act)
                } else if (activityStatus == null || activityExecutionStage == null) {
                    // route: Raise error
                    bulksetRouteError(message, eventType, 'activity.status, activity.executionStage', act)
                } else if (serviceCallType == MaintenanceServiceCallTypeCode && activityStatus == "DRAFT" && !bUnassignCase) {
                    // route: Irrelevant, ignore, no error
                    bulksetRouteIrrelevant(message,act)
                } else if (serviceCallType == MaintenanceServiceCallTypeCode) {
                    // route: Plant Maintenance Order update
                    bulksetRoutePMOrderUpdate(message, act)
                } else if (activityStatus == "DRAFT" && !bUnassignCase) {
                    // route: Irrelevant, ignore, no error
                    bulksetRouteIrrelevant(message,act)
                } else if (isEmpty(externalIds.ServiceOrderItem)) {
                    // route: Raise error
                    bulksetRouteError(message, eventType, 'activity.externalId', act)
                }
                else {
                    // route: Update Service Order
                    //        (iFlow Notify Service Order Update)
                    bulksetRouteUpdateServiceOrder(message,act)
                }
                bulkcheckErrorOccured += act.checkErrorOccured
                bulkIrrelevant += act.Irrelevant
                bulkcheckErrorMessage += act.checkErrorMessage ?: ""
            }
            def validActivities = jsonResult.data?.serviceCall?.activities.findAll{it.checkErrorOccured != "X" && it.Irrelevant != "X"}
            if (bulkcheckErrorOccured && validActivities.size() == 0)
                message.setProperty("checkErrorOccured","X")            
            if (bulkIrrelevant && validActivities.size() == 0)
                message.setProperty("Irrelevant","X")            
            if (bulkcheckErrorMessage && validActivities.size() == 0)
                message.setProperty("checkErrorMessage",bulkcheckErrorMessage)
            
            message.setProperty("EventType",eventType)
            def updatedJsonString = JsonOutput.toJson(jsonResult)
            message.setBody(JsonOutput.prettyPrint(updatedJsonString))
            break

        case "activity.released":
            externalId = jsonResult.data?.serviceCall?.activity?.externalId as String
            externalIds = getExternalIds(externalId, fallbackServiceOrder)
            serviceCallType = jsonResult.data?.serviceCall?.type as String ?: '' 
            setGlobalServiceOrderIds(message, externalIds)
            if (isEmpty(externalIds.ServiceOrder)) {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            } else if (isEmpty(externalIds.ServiceOrderItem)) {
                // route: Raise error
                setRouteError(message, eventType, 'activity.externalId')
            } else if (serviceCallType == MaintenanceServiceCallTypeCode) {
                // route: Plant Maintenance Order update
                setRoutePMOrderUpdate(message)
            } else {
                // route: Update Service Order
                //        (iFlow Notify Service Order Update)
                setRouteUpdateServiceOrder(message)
            }
            break
            
        case "activities.released":
            def bulkcheckErrorOccured = ""
            def bulkIrrelevant = ""
            def bulkcheckErrorMessage = ""
            jsonResult.data?.serviceCall?.activities.each{ act ->
				externalId = act?.externalId as String
				externalIds = getExternalIds(externalId, fallbackServiceOrder)
				serviceCallType = jsonResult.data?.serviceCall?.type as String ?: '' 
				setGlobalServiceOrderIds(message, externalIds)
				if (isEmpty(externalIds.ServiceOrder)) {
					// route: Irrelevant, ignore, no error
					bulksetRouteIrrelevant(message, act)
				} else if (isEmpty(externalIds.ServiceOrderItem)) {
					// route: Raise error
					bulksetRouteError(message, eventType, 'activity.externalId', act)
				} else if (serviceCallType == MaintenanceServiceCallTypeCode) {
					// route: Plant Maintenance Order update
					bulksetRoutePMOrderUpdate(message, act)
				} else {
					// route: Update Service Order
					//        (iFlow Notify Service Order Update)
					bulksetRouteUpdateServiceOrder(message, act)
				}
                bulkcheckErrorOccured += act.checkErrorOccured
                bulkIrrelevant += act.Irrelevant
                bulkcheckErrorMessage += act.checkErrorMessage ?: ""
            }
            def validActivities = jsonResult.data?.serviceCall?.activities.findAll{it.checkErrorOccured != "X" && it.Irrelevant != "X"}
            if (bulkcheckErrorOccured && validActivities.size() == 0)
                message.setProperty("checkErrorOccured","X")            
            if (bulkIrrelevant && validActivities.size() == 0)
                message.setProperty("Irrelevant","X")            
            if (bulkcheckErrorMessage && validActivities.size() == 0)
                message.setProperty("checkErrorMessage",bulkcheckErrorMessage)

            def updatedJsonString = JsonOutput.toJson(jsonResult)
            message.setBody(JsonOutput.prettyPrint(updatedJsonString))
            break


        case "activity.completed":
            externalId = jsonResult.data?.serviceCall?.activity?.unifiedIdentifier?.externalId as String
            externalIds = getExternalIds(externalId, fallbackServiceOrder)
            serviceCallType = jsonResult.data?.serviceCall?.type as String ?: '' 
            setGlobalServiceOrderIds(message, externalIds)
            if (isEmpty(externalIds.ServiceOrder) || serviceCallType == MaintenanceServiceCallTypeCode) {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            } else if (isEmpty(externalIds.ServiceOrderItem)) {
                // route: Raise error
                setRouteError(message, eventType, 'activity.unifiedIdentifier.externalId')
            } else {
                // route: Update Service Order
                //        (iFlow Notify Service Order Update)
                setRouteUpdateServiceOrder(message)
            }
            break

        case ["activity.replannedreleased", "activity.releasedunassigned"]:
            externalId = jsonResult.data?.serviceCall?.sourceActivityCompleted?.unifiedIdentifier?.externalId as String
            if (isEmpty(externalId)) {
                externalId = jsonResult.data?.serviceCall?.activity?.sourceActivity?.externalId as String
            }
            externalIds = getExternalIds(externalId, fallbackServiceOrder)
            setGlobalServiceOrderIds(message, externalIds)
            if (isEmpty(externalIds.ServiceOrder)) {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            } else if (isEmpty(externalIds.ServiceOrderItem)) {
                // route: Raise error
                setRouteError(message, eventType, 'sourceActivityCompleted.unifiedIdentifier.externalId, activity.sourceActivity.externalId')
            } else {
                // route: Create Service Item
                //        (iFlow Update Service Order for Duplicate Activity)
                setRouteCreateServiceItem(message)
                if (sourceActivityCompleted != null && completeCompatibilityMode) {
                    // route: + Source Activity Completed 
                    //        (iFlow Notify Service Order Update)
                    addRouteSourceActivityCompleted(message)
                }
            }
            break

        case ["activity.confirmed", "activity.confirmedcompleted"]:
            externalId = jsonResult.data?.serviceCall?.activity?.unifiedIdentifier?.externalId as String
            externalIds = getExternalIds(externalId, fallbackServiceOrder)
            serviceCallType = jsonResult.data?.serviceCall?.type as String ?: '' 
            setGlobalServiceOrderIds(message, externalIds)
            
            if (isEmpty(externalIds.ServiceOrder)) {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            } else if (isEmpty(externalIds.ServiceOrderItem)) {
                // route: Raise error
                setRouteError(message, eventType, 'activity.unifiedIdentifier.externalId')
            } else if (serviceCallType == MaintenanceServiceCallTypeCode) {
                // route: Plant Maintenance Order confirmation
                setRoutePMConfirmation(message)
            } else {
                // route: Create Service Confirmantiom 
                //        (iFlow Replicate Confirmed Service)
                setRouteCreateServiceConfirmation(message)
                message.setProperty("originalPayload", body)
            }
            break

        default:
            // route: Irrelevant, ignore, no error
            setRouteIrrelevant(message)
            break
    }

    return message
}
