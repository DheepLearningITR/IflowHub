import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body
       def formOfAddress=message.getProperty("FormOfAddressCode") as String;
	   def academicTitle=message.getProperty("AcademicTitleCode") as String;
       if(formOfAddress==""){
           message.setProperty("FormOfAddressCode",null);
       }
	   if(academicTitle==""){
           message.setProperty("AcademicTitleCode",null);
       }
       return message;
}