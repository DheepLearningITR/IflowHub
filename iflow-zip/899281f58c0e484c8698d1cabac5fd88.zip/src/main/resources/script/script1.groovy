import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.List;

class JSONElementValue{
    String element;
    Object value;
    JSONElementValue(String elementParam, Object valueParam){
        element = elementParam;
        value = valueParam;
    }
}

def String getETACanonicalInvoiceFormat(Map jsonInvoice) {
    Stack<JSONElementValue> jsonStack = new Stack<JSONElementValue>();
    jsonStack.push(new JSONElementValue("\$INIT\$", jsonInvoice));
    
    //Preorder traversal considering the Map<String, Object> as a tree
    JSONElementValue jsonElementValue = null;
    String hashInput = "";
    def keySet = null;
    while(!jsonStack.empty()){
        jsonElementValue = jsonStack.pop();
        if(jsonElementValue.value instanceof List){
            hashInput = hashInput + "\"" + jsonElementValue.element + "\"";
            for(int i = jsonElementValue.value.size() - 1; i >= 0; i--){
                jsonStack.push(new JSONElementValue(jsonElementValue.element, jsonElementValue.value.get(i)));
            }
        }
        else if(jsonElementValue.value instanceof Map){
            hashInput = hashInput + "\"" + jsonElementValue.element + "\"";
            keySet = jsonElementValue.value.keySet();
            for(int i = keySet.size() - 1; i >= 0; i--){
                jsonStack.push(new JSONElementValue(keySet.getAt(i).toUpperCase(), jsonElementValue.value.getAt(keySet.getAt(i))));
            }
        }
        else if(jsonElementValue.value instanceof String) {
            hashInput = hashInput + "\"" + jsonElementValue.element + "\"" + "\"" + jsonElementValue.value + "\"";
        }
        else if(jsonElementValue.value instanceof java.math.BigDecimal) {
            hashInput = hashInput + "\"" + jsonElementValue.element + "\"" + "\"" + jsonElementValue.value.toPlainString() + "\"";
        } else if(jsonElementValue.value instanceof Integer){
            hashInput = hashInput + "\"" + jsonElementValue.element + "\"" + "\"" + jsonElementValue.value.toString() + "\"";
        }
    }
    
    hashInput = hashInput.substring(8);
    
    return hashInput;
}

void getRequestCommunicationDetails(Message message, String issuerId) {
    
    def credentials_alias_thumbprint;
    def credentials_alias_pin;
    def credentials_alias_secretkey;
    def credentials_alias_signingServer;
       
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential_thumbprint = null;
    def credential_pin = null;
    def credential_secretKey = null;
    def credential_signingServer = null;
    def errorMsg;
    
    //Thumbprint    	
    credentials_alias_thumbprint = "edoc_egypt_thumbprint_" + issuerId;
    credential_thumbprint = service.getUserCredential( credentials_alias_thumbprint);
    if(credential_thumbprint == null) {
        errorMsg = "No credentials found for alias " + credentials_alias_thumbprint;
        message.setHeader("Error", errorMsg);
        throw new IllegalStateException(errorMsg); 
    }
    
    //Pin    	
    credentials_alias_pin = "edoc_egypt_pin_" + issuerId;
    credential_pin = service.getUserCredential( credentials_alias_pin );
    if(credential_pin == null) {
        errorMsg = "No credentials found for alias " + credentials_alias_pin;
        message.setHeader("Error", errorMsg);
        throw new IllegalStateException(errorMsg); 
    }
    
    //Secret Key    	
    credentials_alias_secretkey = "edoc_egypt_secretKey_" + issuerId;
    credential_secretKey = service.getUserCredential( credentials_alias_secretkey);
    if(credential_secretKey == null) {
        errorMsg = "No credentials found for alias " + credentials_alias_secretkey;
        message.setHeader("Error", errorMsg);
        throw new IllegalStateException(errorMsg); 
    }
    
    //Signing Server        	
    credentials_alias_signingServer = "edoc_egypt_signingServer_" + issuerId;
    credential_signingServer = service.getUserCredential( credentials_alias_signingServer);
    if(credential_signingServer == null) {
        errorMsg = "No credentials found for alias " + credentials_alias_signingServer;
        message.setHeader("Error", errorMsg);
        throw new IllegalStateException(errorMsg); 
    }
    
    message.setProperty("thumbprint", credential_thumbprint.getPassword().toString());
    message.setProperty("pin", credential_pin.getPassword().toString());
    message.setProperty("secretKey", credential_secretKey.getPassword().toString());
    message.setProperty("signingServer", credential_signingServer.getPassword().toString());
}

def Message processData(Message message) {
    def bodyBuffer = message.getBody(java.nio.ByteBuffer);
    byte[] bytes = bodyBuffer.array();

    def jsonInvoice = new JsonSlurper().parse(bytes, "UTF-8").documents[0];
        
    //Get ETA Canonical Invoice Format
    String canonicalInvoiceFormat = getETACanonicalInvoiceFormat(jsonInvoice);
    message.setProperty("CanonicalInvoiceFormat", canonicalInvoiceFormat);
    
    //Base64 conversion
    String base64Content = Base64.getEncoder().encodeToString(canonicalInvoiceFormat.getBytes(StandardCharsets.UTF_8));
    
    //Get Communication Details
    getRequestCommunicationDetails(message, jsonInvoice.issuer.id);
    
    def signingServerPayload = [
                                    dataToSign: base64Content,
                                    secretKey: message.getProperty("secretKey")
                                ];    
    
    message.setBody(JsonOutput.toJson(signingServerPayload).getBytes(StandardCharsets.UTF_8));
    
    message.setHeader("Content-Type", "application/json");
    
    return message;
}