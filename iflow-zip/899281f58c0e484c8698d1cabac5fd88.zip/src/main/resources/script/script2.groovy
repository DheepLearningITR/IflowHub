import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.securestore.exception.SecureStoreException;
import java.util.HashMap;
import java.lang.String;
import groovy.xml.*;
def Message processData(Message message) {
  
    //Properties 
    def map = message.getProperties();
    
    def issuerId = map.get("IssuerID");
    
    def credentials_alias_thumbprint;
    def credentials_alias_pin;
    def credentials_alias_secretkey;
    def credentials_alias_signingServer;
       
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = null;
    def credential_thumbprint = null;
    def credential_pin = null;
    def credential_secretKey = null;
    def credential_signingServer = null;
    def errorMsg;
    def credential_Check;
       
    //Credentials check
    credential_Check = service.getUserCredential(credentials_alias);       
    
    //Thumbprint    	
    credentials_alias_thumbprint = "edoc_egypt_thumbprint_" + issuerId;
    credential_thumbprint = service.getUserCredential( credentials_alias_thumbprint);
    if(credential_thumbprint == null) {
        errorMsg = "No credentials found for alias " + credentials_alias_thumbprint;
        message.setHeader("Error", errorMsg);
        throw new IllegalStateException(errorMsg); 
    }
    
    //Pin    	
    credentials_alias_pin = "edoc_egypt_pin_" + issuerId;
    credential_pin = service.getUserCredential( credentials_alias_pin );
    if(credential_pin == null) {
        errorMsg = "No credentials found for alias " + credentials_alias_pin;
        message.setHeader("Error", errorMsg);
        throw new IllegalStateException(errorMsg); 
    }
    
    //Secret Key    	
    credentials_alias_secretkey = "edoc_egypt_secretKey_" + issuerId;
    credential_secretKey = service.getUserCredential( credentials_alias_secretkey);
    if(credential_secretKey == null) {
        errorMsg = "No credentials found for alias " + credentials_alias_secretkey;
        message.setHeader("Error", errorMsg);
        throw new IllegalStateException(errorMsg); 
    }
    
    //Signing Server        	
    credentials_alias_signingServer = "edoc_egypt_signingServer_" + issuerId;
    credential_signingServer = service.getUserCredential( credentials_alias_signingServer);
    if(credential_signingServer == null) {
        errorMsg = "No credentials found for alias " + credentials_alias_signingServer;
        message.setHeader("Error", errorMsg);
        throw new IllegalStateException(errorMsg); 
    }
    
    message.setProperty("thumbprint", credential_thumbprint.getPassword().toString());
    message.setProperty("pin", credential_pin.getPassword().toString());
    message.setProperty("secretKey", credential_secretKey.getPassword().toString());
    message.setProperty("signingServer", credential_signingServer.getPassword().toString());

    return message;
}