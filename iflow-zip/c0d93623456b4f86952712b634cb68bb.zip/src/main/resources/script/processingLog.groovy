/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;


def Message categoryIsGroupForCustomerNotSupported(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	messageLog.setStringProperty("WarningMessage", "A GROUP category bp will not be replicated!");
	return message;
}

def Message nonRelatedRolesCustomerNotSupported(Message message) {
    def map = message.getProperties();
    def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
    if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE")) {
        def property_S4ID = map.get("S4BPNumber") as String;
        def body = "The Buinsess Partner(" + property_S4ID + ") would not be replicated to SAP Subscription Billing. Please ensure BP has MKK (Contract Partner) Business Partner role.";
        def messageLog = messageLogFactory.getMessageLog(message);

        if (messageLog != null) {
            messageLog.addAttachmentAsString("S4(" + property_S4ID + ")_skip_non_related_bp", body, "text/plain");
        }
    }
    return message;
}