import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.osgi.framework.FrameworkUtil;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import com.sap.it.api.pd.BinaryData;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null);
    if(service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }

    def headers   = message.getHeaders();
	def partnerID = headers.get("SAP_TPM_ACTIVITYPARTNER_ID");

    // get parameters for partner directory.
	def recDirection = service.getParameter("SAP_TPA_BTA_Direction", partnerID , String.class);
	def recMessageType = service.getParameter("SAP_EDI_REC_Message_Type", partnerID , String.class);
	def recPartnerName = service.getParameter("SAP_TPA_SND_Trading_Partner_Name", partnerID , String.class);
	def recInterchangeControlNumber = service.getParameter("SAP_EDI_REC_Interchange_Control_Number", partnerID , String.class);
	
	// get and set custom parameters
	def customActivityParams = service.getParameter("SAP_TPM_CustomActivityParams", partnerID, BinaryData.class);
    if (customActivityParams != null){
        def customActivityParamsStr = new String(customActivityParams.getData());
        def customActivityParamsJson = new JsonSlurper().parseText(customActivityParamsStr);
        customActivityParamsJson.each{
            paramKey, paramValue -> message.setProperty(paramKey, paramValue);
        }
    }
    
	// set parameters as exchange header attributes
	message.setHeader("SAP_EDI_REC_Direction", recDirection);
	message.setHeader("SAP_EDI_REC_Message_Type", recMessageType);
	message.setHeader("SAP_TPA_SND_Trading_Partner_Name", recPartnerName);	
	message.setHeader("SAP_EDI_REC_Interchange_Control_Number", recInterchangeControlNumber);

    return message;
}