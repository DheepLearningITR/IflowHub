/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
	   def phone=message.getProperty("phone") as String;
	   def mobile=message.getProperty("mobile") as String;
	   def addressCountryCode=message.getProperty("CountryCode") as String;
	   
	   def phoneCode;
	   def mobileCode;
	   if(phone.split(" ").length>1){
	   System.out.println("step1");
	       phoneCode = phone.split(" ")[0];
	       if(phoneCode.startsWith("+")){
	          phoneCode = phoneCode.substring(1);
	       }

	   }else{
	       phoneCode = addressCountryCode;
	   }
	   
	   if(mobile.split(" ").length>1){
	       mobileCode = mobile.split(" ")[0];
	       if(mobileCode.startsWith("+")){
	           mobileCode = mobileCode.substring(1);
	       }

	   }else{
	       mobileCode = addressCountryCode;
	   } 
	   
	   message.setProperty("phoneCode",phoneCode);
	   message.setProperty("mobileCode",mobileCode);
		
	   message.setProperty("phone",phone.split(" ").length>1?phone.split(" ")[1]:phone);
	   message.setProperty("mobile",mobile.split(" ").length>1?mobile.split(" ")[1]:mobile);
	   
	   System.out.println("phoneCode"+message.getProperty("phoneCode"));
	   System.out.println("mobileCode"+message.getProperty("mobileCode"));
	   System.out.println("phone"+message.getProperty("phone"));
	   System.out.println("mobile"+message.getProperty("mobile"));
       
       return message;
}