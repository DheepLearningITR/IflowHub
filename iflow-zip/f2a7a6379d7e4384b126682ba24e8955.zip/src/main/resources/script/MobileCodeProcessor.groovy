import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
	System.out.println("step22");
	def map = message.getProperties();
	def countryDialingCodeList = map.get("countryDialingCodeList").toString();
	
	System.out.println("countryDialingCodeList : "+ countryDialingCodeList);
	def messageLog = messageLogFactory.getMessageLog(message);
	if (messageLog != null) {
		messageLog.addAttachmentAsString("countryDialingCodeList", countryDialingCodeList, "application/xml");
	}
	
	def countries = new XmlSlurper().parseText(countryDialingCodeList);

	countries.country.findAll{
	    p -> 
	    	p.countryDialingCodeTo.equals(map.get("mobileCode"));
	    
	}.each{
	    p -> 
	    	message.setProperty("mobileCountryCode", p.countryCode);
	}
	
	System.out.println("Mobile Code : "+ map.get("mobileCode"));
	System.out.println("Mobile Country Code : "+ map.get("mobileCountryCode"));
	return message;
}