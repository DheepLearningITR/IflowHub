import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    
    def taxExempt = message.getProperty("taxExempt") == 'true' ? 0 : 1
    
    message.setProperty("taxExempt",taxExempt)
    return message;
}