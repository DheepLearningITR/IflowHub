import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def map = message.getProperties()
    def logException = map.get("ExceptionLogging")?.equalsIgnoreCase("true")

    if (logException) {
        handleException(message, map)

        handleMessageBody(message, map)
    }

    return message
}

def handleException(Message message, def map) {
    def ex = map.get("CamelExceptionCaught")
    if (ex != null) {
        def shopifyCustomerID = map.get("shopify_customer_id") ?: ""
        def attachID = shopifyCustomerID ? "Error Details for Shopify Customer ID '${shopifyCustomerID}'" : "Error Details"
        def errordetails = shopifyCustomerID ? "The process with Shopify Customer ID '${shopifyCustomerID}' failed due to the following error: ${ex.toString()}" : "The process failed due to the following error: ${ex.toString()}"

        addAttachment(message, attachID, errordetails)
    }
}

def handleMessageBody(Message message, def map) {
    def messageBody = message.getBody(String)
    def shopifyCustomerID = map.get("shopify_customer_id") ?: ""
    def attachID = shopifyCustomerID ? "Error Details for Shopify Customer ID '${shopifyCustomerID}'" : "Error Details"
    def errordetails = "Message Content: \n${messageBody}"

    addAttachment(message, attachID, errordetails)
}

def addAttachment(Message message, String attachID, String errorMessage) {
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        messageLog.addAttachmentAsString(attachID, errorMessage, "text/plain")
    }
}