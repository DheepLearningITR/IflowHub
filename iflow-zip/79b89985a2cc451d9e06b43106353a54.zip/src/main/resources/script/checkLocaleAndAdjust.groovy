import groovy.util.XmlSlurper
import java.util.Locale
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def body = message.getBody(java.lang.String)

    def xmlParser = new XmlSlurper().parseText(body)

    String fallbackLanguage = message.getProperty("fallbackLanguage")

    def localeElement = xmlParser.'**'.find { it.name() == 'locale' }
    def localeCode = localeElement ? localeElement.text().trim() : fallbackLanguage

    //&& !localeElement.text().isEmpty()
    def language = extractLanguage(localeCode, fallbackLanguage)
    message.setProperty("language", language)
    return message

}
def extractLanguage(String languageCode, String fallbackLanguage) {
    try {
        def parts = languageCode.split('-')
        // Only language code (e.g., "en")
        def locale = new Locale(parts[0]) // Create a locale with just the language
        def isoLanguages = Locale.getISOLanguages()
        if (isoLanguages.contains(parts[0])) {
            return locale.getLanguage()
        } else {
            return fallbackLanguage
        }
    } catch (Exception e) {
       return fallbackLanguage
    }
}

