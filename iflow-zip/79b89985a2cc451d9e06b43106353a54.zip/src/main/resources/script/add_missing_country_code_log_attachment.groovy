import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    def body = message.getBody(java.lang.String)
    def id = message.getProperty("shopify_customer_id");
    messageLog.addAttachmentAsString("Replication error", "Customer with Shopify id: " + id + " could not be replicated due to missing country code", "text/plain");

    return message;
}