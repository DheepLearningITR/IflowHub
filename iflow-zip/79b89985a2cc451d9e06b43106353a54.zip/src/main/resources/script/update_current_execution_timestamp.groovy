import com.sap.gateway.ip.core.customdev.util.Message
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def currentExecutionLastProcessedShopifyCustomerUpdatedAtTimestamp = message.getProperty("current_execution_last_processed_shopify_customer_updated_at_timestamp")

    def body = message.getBody(java.io.Reader)
    if (body == null) {
        return message
    }

    def xml = new XmlSlurper().parse(body)
    if (xml == null || xml.shopifyCustomer == null || xml.shopifyCustomer.size() == 0) {
        return message
    }

    ZonedDateTime latestProcessedShopifyCustomerUpdatedAt = null
    xml.shopifyCustomer.each { customer ->
        def updatedAtString = customer.text()
        if (updatedAtString != null && !updatedAtString.trim().isEmpty()) {
            ZonedDateTime currentIteratedShopifyCustomerUpdatedAt = ZonedDateTime.parse(updatedAtString, DateTimeFormatter.ISO_ZONED_DATE_TIME)
            if (latestProcessedShopifyCustomerUpdatedAt == null || currentIteratedShopifyCustomerUpdatedAt.isAfter(latestProcessedShopifyCustomerUpdatedAt)) {
                latestProcessedShopifyCustomerUpdatedAt = currentIteratedShopifyCustomerUpdatedAt
            }
        }
    }

    if (latestProcessedShopifyCustomerUpdatedAt != null) {
        if (currentExecutionLastProcessedShopifyCustomerUpdatedAtTimestamp != null && !currentExecutionLastProcessedShopifyCustomerUpdatedAtTimestamp.trim().isEmpty()) {
            ZonedDateTime currentExecutionLastProcessedShopifyCustomerUpdatedAtTime = ZonedDateTime.parse(currentExecutionLastProcessedShopifyCustomerUpdatedAtTimestamp, DateTimeFormatter.ISO_ZONED_DATE_TIME)
            if (latestProcessedShopifyCustomerUpdatedAt.isAfter(currentExecutionLastProcessedShopifyCustomerUpdatedAtTime)) {
                message.setProperty("current_execution_last_processed_shopify_customer_updated_at_timestamp", latestProcessedShopifyCustomerUpdatedAt.toString())
            }
        } else {
            message.setProperty("current_execution_last_processed_shopify_customer_updated_at_timestamp", latestProcessedShopifyCustomerUpdatedAt.toString())
        }
    }

    return message
}