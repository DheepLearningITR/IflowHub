import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
import groovy.json.JsonOutput;
def Message processData(Message message) {
    //Body 
    def body_json= message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
     try{
        def workFlowResponse = jsonSlurper.parseText(body_json);
        def result = JsonOutput.toJson(workFlowResponse.decision_fetchApproverGroups_2.Output);
        message.setProperty("result",result)
        message.setProperty("errorMessage", "");
        message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
     }
     catch(Exception e)
     {
		 def map  = message.getProperties();
         def ex   = map.get("CamelExceptionCaught");
		 if (ex != null)
		 {
            exceptionText    = ex.getMessage();
            message.setProperty("result", "");
            message.setProperty("errorMessage", exceptionText);
            message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
		 } else {
			message.setProperty("result", "");
            message.setProperty("errorMessage", "Exception Occurred");
		 }
     }  
    return message;
}