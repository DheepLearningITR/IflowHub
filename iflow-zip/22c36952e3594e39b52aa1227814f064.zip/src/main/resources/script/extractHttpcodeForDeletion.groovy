import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
import groovy.json.JsonOutput;
def Message processData(Message message) {
     try{
        message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
        message.setProperty("errorMessage", "");
     }
     catch(Exception e)
     {
		 def map  = message.getProperties();
         def ex   = map.get("CamelExceptionCaught");
		 if (ex != null)
		 {
            exceptionText    = ex.getMessage();
            message.setProperty("errorMessage", exceptionText);
            message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
		 } else {
            message.setProperty("errorMessage", "Exception Occurred");
		 }
     }  
    return message;
}