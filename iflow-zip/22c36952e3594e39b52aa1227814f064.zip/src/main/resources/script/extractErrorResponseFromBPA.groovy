import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String);
    def map  = message.getProperties();
         def ex   = map.get("CamelExceptionCaught");
		 if (ex != null)
		 {
            exceptionText    = ex.getMessage();
            message.setProperty("result", "");
            message.setProperty("errorMessage", exceptionText);
            message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
		 } else {
			message.setProperty("result", "");
            message.setProperty("errorMessage", "Exception Occurred");
		 }
    return message;
}