import com.sap.it.api.mapping.*;
import org.json.JSONObject;
import org.json.JSONException;
import groovy.json.JsonBuilder
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.UUID;


def Message handleRequestBody(Message message) {
    //Body
    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body)
    //Headers
    //def headers = message.getHeaders();
    //def value = headers.get("oldHeader");
    //message.setHeader("oldHeader", value + " modified");
    //message.setHeader("newHeader", "newHeader");
    //Properties
    def properties = message.getProperties();
    //value = properties.get("oldProperty");
    //message.setProperty("oldProperty", value + " modified");

    def numberOfProcessingMonth = input.numberOfProcessingMonth
    if ( numberOfProcessingMonth instanceof Integer ) {
        saphda_numberOfProcessingMonth = numberOfProcessingMonth
    } else if ( numberOfProcessingMonth == null ) {
        saphda_numberOfProcessingMonth = 18
    } else {
        saphda_numberOfProcessingMonth = Integer.parseInt(numberOfProcessingMonth)
    }

    DateTimeFormatter pattern = DateTimeFormatter.ofPattern("yyyyMM");
    def now = LocalDate.now()
    def saphda_calmonth_from = now.format(pattern)
    now = now.plusMonths(saphda_numberOfProcessingMonth)
    def saphda_calmonth_to = now.format(pattern)
    
    message.setProperty("saphda_calmonth_from", saphda_calmonth_from);

    message.setProperty("saphda_calmonth_to", saphda_calmonth_to);

    def modelID = URLEncoder.encode(input.modelID,StandardCharsets.UTF_8.name())
    message.setProperty("saphda_modelID", modelID);
   
    Integer saphda_chunck
    def saphda_chunck2 = input.chunckSize
    if ( saphda_chunck2 instanceof Integer ) {
        saphda_chunck = saphda_chunck2    
    } else if ( saphda_chunck2 == null ) {
        saphda_chunck = Integer.parseInt(properties.get("saphda_chunck"))   
    } else {
		saphda_chunck = Integer.parseInt(saphda_chunck2)
    }       
    message.setProperty("saphda_chunck", saphda_chunck);

    Integer saphda_maxLines
    def saphda_maxLines2 = input.maxLines
    if ( saphda_maxLines2 instanceof Integer ) {
        saphda_maxLines = saphda_maxLines2
    } else if ( saphda_maxLines2 == null ) {
        saphda_maxLines = Integer.parseInt(properties.get("saphda_maxLines"))
    } else {
		saphda_maxLines = Integer.parseInt(saphda_maxLines2)
    }       
    message.setProperty("saphda_maxLines", saphda_maxLines);
    
    def queryString = input.queryString
    if ( queryString != null ) {
        message.setProperty("saphda_queryParameters2", queryString);
    }
   
    message.setProperty("saphda_price", input.load_price)
    message.setProperty("saphda_quantity", input.load_quantity)
 
    def saphda_transactionID = UUID.randomUUID().toString().replace("-", "");
    message.setProperty("saphda_transactionID", saphda_transactionID);
    
    return message;
}

def Message topskip(Message message) {
    def propMap = message.getProperties()
    def CamelLoopIndex = propMap.get("CamelLoopIndex")
    //def QueryParameters = propMap.get("QueryParameters")
    def saphda_chunck = propMap.get("saphda_chunck")
    def maxLines = propMap.get("saphda_maxLines")
    
    def calc = saphda_chunck.toInteger() * CamelLoopIndex.toInteger()
    message.setProperty("saphda_skip",calc.toString())
    
    if ( ( calc + saphda_chunck ) > maxLines ) {
        message.setProperty("saphda_chunck", maxLines - calc )
    }
    
    return message;

}

def String convertDateLong(String arg1){

    Pattern pattern = Pattern.compile("\\d+")
    Matcher matcher = pattern.matcher(arg1)

    String converted_datetime =  ""
    if (matcher.find()) {
        Date result_date = Date.parse("yyyyMM", arg1)
        DateFormat simple = new SimpleDateFormat(
                'yyyy-MM-dd\'T\'00:mm:ss');
        converted_datetime = simple.format(result_date);
    }

    return converted_datetime;
}

def Message transform(Message message) {

    Reader body = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(body)
    def result_array = input.get("value")

    def propMap = message.getProperties()

    // read company code currency from property and convert it to JSON and then to HashMap
    def saphda_companycode_curr = propMap.get("saphda_companycode_curr")
    Map companyCodeCurrMap= new JsonSlurper().parseText(saphda_companycode_curr)
    HashMap<String, String> companyCodeCurrHashMap = new HashMap<String, String>();
    companyCodeCurrMap.value.each { item -> companyCodeCurrHashMap.put(item.ID,item.currency);} //ID is company code

    def saphda_transactionID = propMap.get('saphda_transactionID')
    def commit_val = propMap.get('saphda_commit')
    def chunksize = propMap.get('saphda_chunck')
    def skip = propMap.get('saphda_skip')
    def saphda_price = propMap.get('saphda_price')
    def saphda_quantity = propMap.get('saphda_quantity')
    def saphda_ibp_url = propMap.get('saphda_ibp_url')    
    def saphda_ipb_credential = propMap.get('saphda_ipb_credential')    
    def saphda_ibp_planningarea = propMap.get('saphda_ibp_planningarea')    
    def saphda_maxLines = propMap.get('saphda_maxLines')
    
    commit_val = false
    def count = input.get("@odata.count").toInteger()
    if ( count <= ( skip.toInteger() + chunksize.toInteger() ) || saphda_maxLines.toInteger() <= ( skip.toInteger() + chunksize.toInteger() ) ) {
        message.setProperty("saphda_commit",'true')
        commit_val = true
    }
   
    def builder = new JsonBuilder();
    
    if (saphda_price == 'true') {
        builder {
            "hostName" saphda_ibp_url
            "credentialsName" saphda_ipb_credential
            "planningArea" saphda_ibp_planningarea
            "commit" commit_val.toString()
            "oData" "true"
            'fieldsString' 'PERIODID3_TSTAMP,PRDID,CURRID,CUSTID,PLANNEDPRICESAC'
            'transactionId' saphda_transactionID
            sacPayload result_array.collect {
            [
                    "PERIODID3_TSTAMP"             : convertDateLong(it.Date), 
                    "PRDID"                        : it.SAP_ALL_PRODUCT,
                    "CURRID"                       : companyCodeCurrHashMap.getOrDefault(it.SAP_ALL_COMPANY_CODE,'#'),
                    "CUSTID"                       : it.SAP_ALL_CUSTOMER,
                    "PLANNEDPRICESAC"              : ( it.PRICE * -1 ).toPlainString() 
                ]
            }
        }
    } else if (saphda_quantity == 'true') {
        builder {
            "hostName" saphda_ibp_url
            "credentialsName" saphda_ipb_credential
            "planningArea" saphda_ibp_planningarea
            "commit" commit_val.toString()
            "oData" "true"
            'fieldsString' 'PERIODID3_TSTAMP,PRDID,LOCID,CUSTID,CONSENSUSDEMANDQTYSAC'
            'transactionId' saphda_transactionID
            sacPayload result_array.collect {
            [
                    "PERIODID3_TSTAMP"             : convertDateLong(it.Date), 
                    "PRDID"                        : it.SAP_ALL_PRODUCT,
                    "CUSTID"                       : it.SAP_ALL_CUSTOMER,
                    "LOCID"                        : it.SAP_ALL_PLANT,
                    "CONSENSUSDEMANDQTYSAC"        : ( it.QUANTITY * -1 ).toPlainString() 
                ]
            }
        }        
    }

    def prettyBody = builder.toPrettyString()
    
    message.setBody(prettyBody);

    return message;
}


def Message catch_camels(Message message){

    def map  = message.getProperties();
    def ex   = map.get("CamelExceptionCaught");
    def exceptionText;

    if (ex != null)
    {
        exceptionText    = ex.getMessage();
        def messageLog   = messageLogFactory.getMessageLog(message);
        messageLog.addAttachmentAsString("Exception", exceptionText,"application/text");

        // copy the http error response body as a property
        message.setProperty("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());

        try {

            def mp              = [
            "IBP Host"          : message.getProperty('saphda_ibp_url'),
            "IBP credentials"   : message.getProperty('saphda_ipb_credential'),
            "Status"            : "error",
            "stepStatus"        : "error",
            "current/nextmonth" : message.getProperty('saphda_current_calmonth'),
            "Message"           : exceptionText
            ];

            def ibpCommitStatus = new JSONObject(mp).toString();

            message.setProperty("http.response", ibpCommitStatus);

            message.setBody(ibpCommitStatus);

        } catch (JSONException e) {
            message.setBody(e);
        }
    }
    return message;
}

