import com.sap.gateway.ip.core.customdev.util.Message;

/*
Remove message as it should not interfere the original message
Within this part of the flow just the access token is retrieved and stored in parameters or the relevance information itself is retrieved
*/
def Message processData(Message message) {
 message.setBody('');

	return message;
	
}