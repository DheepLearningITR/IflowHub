import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.mapping.ValueMappingApi;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;
import com.sap.it.api.ITApiFactory;

/*
This script will reduce the BP detail call result to the minimum information
needed later in this IFlow and will also assign the related Insured Object info to the
output XML.
*/
def Message processData(Message message) {
    
    //Constants
    def sourceAgency = 'FSPM';
    def targetAgency = 'FSA';
    def mainNamedDriver = null;

    // Get CPI-Session Properties
    def properties = message.getProperties()
    
    def sourceAgencyRel   = 'FSPM_'+ properties.get("com.sap.hybriscommerce.fsa.insurance.policyreplication.FSPM_Version")
    def targetAgencyRel = 'FSA_'+ properties.get("com.sap.hybriscommerce.fsa.insurance.policyreplication.FSA_Version")
	
	// Get Value Mapping Service
	def valueMapService = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    //Body 
    def body = message.getBody(java.lang.String);

    //Parse the incoming XML into an object
    def INrfcSet = new XmlSlurper().parseText(body);
    
    // Create new Ins Obj Set Branch
    def stringinsuredObject = '<InsuredObject></InsuredObject>'
    def OUTinsuredObject = new XmlParser().parseText(stringinsuredObject)
    
    // Should only be one Subject entity in this iteration
    def INobjInsSubject = INrfcSet.breadthFirst().find { InsSubject-> InsSubject.name() == 'item' }
    
    OUTinsuredObject.appendNode(new QName('POLICYPRODUCT_ID'), INobjInsSubject.getProperty("POLICYPRODUCT_ID").text())
    OUTinsuredObject.appendNode(new QName('COVPAC_ID'), INobjInsSubject.getProperty("COVPAC_ID").text())
    OUTinsuredObject.appendNode(new QName('COVERAGE_ID'), INobjInsSubject.getProperty("COVERAGE_ID").text())
    OUTinsuredObject.appendNode(new QName('COVCP_ID'), INobjInsSubject.getProperty("COVCP_ID").text())
    OUTinsuredObject.appendNode(new QName('SUBJECT_ID'), INobjInsSubject.getProperty("SUBJECT_ID").text())
    OUTinsuredObject.appendNode(new QName('InsuredObjectType'), 'AUTO') 
   
    def OUTinsuredObjectItemsSet = OUTinsuredObject.appendNode(new QName('insuredObjectItems'))
    
    def OUTinsuredObjectItemSet1 = OUTinsuredObjectItemsSet.appendNode(new QName('InsuredObjectItem'))
    def mappedMake = valueMapService.getMappedValue(sourceAgency, "PRODUCER_ID", INobjInsSubject.getProperty("_-MVA_-PRODUCER_INTL_ID").text(), targetAgency, "Make");
    if (mappedMake == null) {
        OUTinsuredObjectItemSet1.appendNode(new QName('externalValue'), INobjInsSubject.getProperty("_-MVA_-PRODUCER_INTL_TT").text())
    } else {
        OUTinsuredObjectItemSet1.appendNode(new QName('externalValue'), mappedMake)
    }
    OUTinsuredObjectItemSet1.appendNode(new QName('label'),         'vehicleMake' )
    
    def OUTinsuredObjectItemSet2 = OUTinsuredObjectItemsSet.appendNode(new QName('InsuredObjectItem'))
    def mappedModel = valueMapService.getMappedValue(sourceAgency, "MODEL_ID", INobjInsSubject.getProperty("_-MVA_-MODEL_INTL_ID").text(), targetAgency, "Model");
    if (mappedModel == null) {
        OUTinsuredObjectItemSet2.appendNode(new QName('externalValue'), INobjInsSubject.getProperty("_-MVA_-MODEL_INTL_ID").text())
    } else {
        OUTinsuredObjectItemSet2.appendNode(new QName('externalValue'), mappedModel)
    }
    OUTinsuredObjectItemSet2.appendNode(new QName('label'),         'vehicleModel' )
    
    def OUTinsuredObjectItemSet3 = OUTinsuredObjectItemsSet.appendNode(new QName('InsuredObjectItem'))
    def mappedType = valueMapService.getMappedValue(sourceAgency, "VEHTYP_ID", INobjInsSubject.getProperty("_-MVA_-VEHTYP_INTL_ID").text(), targetAgency, "Type");
    if (mappedType == null) {
        OUTinsuredObjectItemSet3.appendNode(new QName('externalValue'), INobjInsSubject.getProperty("_-MVA_-VEHTYP_INTL_TT").text())
    } else {
        OUTinsuredObjectItemSet3.appendNode(new QName('externalValue'), mappedType)
    }
    
    OUTinsuredObjectItemSet3.appendNode(new QName('label'),         'vehicleType' )
    
    def OUTinsuredObjectItemSet4 = OUTinsuredObjectItemsSet.appendNode(new QName('InsuredObjectItem'))
    OUTinsuredObjectItemSet4.appendNode(new QName('externalValue'), INobjInsSubject.getProperty("_-MVA_-YMILEAGE_INTL_VL"))
    OUTinsuredObjectItemSet4.appendNode(new QName('label'),         'vehicleAnnualMileage' )
    OUTinsuredObjectItemSet4.appendNode(new QName('format'),        'ML' )
    
    def OUTinsuredObjectItemSet5 = OUTinsuredObjectItemsSet.appendNode(new QName('InsuredObjectItem'))
    OUTinsuredObjectItemSet5.appendNode(new QName('externalValue'), INobjInsSubject.getProperty("_-MVA_-SDLDPRMN_AM"))
    OUTinsuredObjectItemSet5.appendNode(new QName('label'),         'vehicleValue' )
    OUTinsuredObjectItemSet5.appendNode(new QName('format'),        INobjInsSubject.getProperty("CURRENCY_ID") )

    if (INobjInsSubject.getProperty("_-MVA_-ACQUIS_DT").text( ) != '0000-00-00') {
        def OUTinsuredObjectItemSet6 = OUTinsuredObjectItemsSet.appendNode(new QName('InsuredObjectItem'))
        def lv_vehiclePurchaseDate = INobjInsSubject.getProperty("_-MVA_-ACQUIS_DT").text( )
        lv_vehiclePurchaseDate = lv_vehiclePurchaseDate + 'T00:00:00'
        OUTinsuredObjectItemSet6.appendNode(new QName('externalValue'), lv_vehiclePurchaseDate)
        OUTinsuredObjectItemSet6.appendNode(new QName('label'),         'vehiclePurchaseDate' )
        OUTinsuredObjectItemSet6.appendNode(new QName('format'),        'DATE' )
    }
    
    def OUTinsuredObjectItemSet7 = OUTinsuredObjectItemsSet.appendNode(new QName('InsuredObjectItem'))
    OUTinsuredObjectItemSet7.appendNode(new QName('externalValue'), INobjInsSubject.getProperty("_-MVA_-VEHICLE_ID"))
    OUTinsuredObjectItemSet7.appendNode(new QName('label'),         'vehicleIdentificationNumber' )
    
    def OUTinsuredObjectItemSet13 = OUTinsuredObjectItemsSet.appendNode(new QName('InsuredObjectItem'))
    OUTinsuredObjectItemSet13.appendNode(new QName('externalValue'), INobjInsSubject.getProperty("_-MVA_-LICENCE_TT"))
    OUTinsuredObjectItemSet13.appendNode(new QName('label'),         'vehicleLicenseNumber' )
    
    def OUTinsuredObjectItemSet14 = OUTinsuredObjectItemsSet.appendNode(new QName('InsuredObjectItem'))
    OUTinsuredObjectItemSet14.appendNode(new QName('externalValue'), INobjInsSubject.getProperty("_-MVA_-YEARCONSTRUCT_INTL_DT"))
    OUTinsuredObjectItemSet14.appendNode(new QName('label'),         'vehicleYear' )
    
    
    // Get Named Driver Entity
    def INobjAssignedNamDrv = INrfcSet.breadthFirst().find { node-> node.name() == 'ASSIGNED_NAMDRV' }
   
   
    def OUTchildInsuredObjectsSet = OUTinsuredObject.appendNode(new QName('childInsuredObjects'))
    
    INobjAssignedNamDrv.item.each{ namedDriver ->  
    
        def OUTchildInsuredObject = OUTchildInsuredObjectsSet.appendNode(new QName('childInsuredObject'))
        
        OUTchildInsuredObject.appendNode(new QName('POLICYPRODUCT_ID'), namedDriver.getProperty("POLICYPRODUCT_ID").text())
        OUTchildInsuredObject.appendNode(new QName('COVPAC_ID'), namedDriver.getProperty("COVPAC_ID").text())
        OUTchildInsuredObject.appendNode(new QName('COVERAGE_ID'), namedDriver.getProperty("COVERAGE_ID").text())
        OUTchildInsuredObject.appendNode(new QName('COVCP_ID'), namedDriver.getProperty("COVCP_ID").text())
        OUTchildInsuredObject.appendNode(new QName('SUBJECT_ID'), namedDriver.getProperty("SUBJECT_ID").text())
        OUTchildInsuredObject.appendNode(new QName('NAMDRV_ID'), namedDriver.getProperty("NAMDRV_ID").text())
		
		def OUTchildInsuredObjectItems = OUTchildInsuredObject.appendNode(new QName('insuredObjectItems'))
    
        // Get Main Driver Details (BP system)
        def INobjNamedDriversCentralDataPerson  = INrfcSet.breadthFirst().find { node-> node.name() == 'NamedDrivers' }
		    
		INobjNamedDriversCentralDataPerson.NamedDriver.each{ NamedDriverCentralDataPerson ->
				
			if (NamedDriverCentralDataPerson.BP_ID.text() == namedDriver.PARTNER_ID.text()) {
				INSelectedNamedDriverCentralDataPerson = NamedDriverCentralDataPerson.CENTRALDATAPERSON;
			}
		}
    
        def OUTinsuredObjectItemSet8 = OUTchildInsuredObjectItems.appendNode(new QName('InsuredObjectItem')) 
        OUTinsuredObjectItemSet8.appendNode(new QName('externalValue'), namedDriver.BIRTH_DT.text()+'T00:00:00')
        OUTinsuredObjectItemSet8.appendNode(new QName('label'),         'dateOfBirth' )
        OUTinsuredObjectItemSet8.appendNode(new QName('format'),        'DATE' )
        
        def OUTinsuredObjectItemSet9 = OUTchildInsuredObjectItems.appendNode(new QName('InsuredObjectItem'))
        OUTinsuredObjectItemSet9.appendNode(new QName('externalValue'), INSelectedNamedDriverCentralDataPerson.FIRSTNAME.text( ))
        OUTinsuredObjectItemSet9.appendNode(new QName('label'),         'firstName' )
        
        def OUTinsuredObjectItemSet10 = OUTchildInsuredObjectItems.appendNode(new QName('InsuredObjectItem'))
        OUTinsuredObjectItemSet10.appendNode(new QName('externalValue'), INSelectedNamedDriverCentralDataPerson.LASTNAME.text( ))
        OUTinsuredObjectItemSet10.appendNode(new QName('label'),         'lastName' )
        
        def OUTinsuredObjectItemSet11 = OUTchildInsuredObjectItems.appendNode(new QName('InsuredObjectItem')) 
        OUTinsuredObjectItemSet11.appendNode(new QName('externalValue'), namedDriver.DRIVERLICENCE_ID.text())
        OUTinsuredObjectItemSet11.appendNode(new QName('label'),         'driverLicenceNumber' )
        
        if (namedDriver.LICENCE_DT.text() != '0000-00-00') {
            def OUTinsuredObjectItemSet12 = OUTchildInsuredObjectItems.appendNode(new QName('InsuredObjectItem')) 
            OUTinsuredObjectItemSet12.appendNode(new QName('externalValue'), namedDriver.LICENCE_DT.text()+'T00:00:00')
            OUTinsuredObjectItemSet12.appendNode(new QName('label'),         'driverLicenceDate' )
            OUTinsuredObjectItemSet12.appendNode(new QName('format'),        'DATE' )
        }
        
        def OUTinsuredObjectItemSet20 = OUTchildInsuredObjectItems.appendNode(new QName('InsuredObjectItem')) 
        
        def mappedDriverCat = valueMapService.getMappedValue(sourceAgencyRel, 'DRIVERCATEGORY_CD', namedDriver.DRIVERCATEGORY_CD.text(), targetAgencyRel, 'DriverCategory');
        if (mappedDriverCat == null) {
            def test = sourceAgencyRel + '-' + namedDriver.DRIVERCATEGORY_CD.text() + '-' + targetAgencyRel
            OUTinsuredObjectItemSet20.appendNode(new QName('externalValue'), test)
        } else {
            OUTinsuredObjectItemSet20.appendNode(new QName('externalValue'), mappedDriverCat)
        }
        
        OUTinsuredObjectItemSet20.appendNode(new QName('label'),         'driverCategory' )
    
    }
    
    
    //parse back
    message.setBody(XmlUtil.serialize(OUTinsuredObject))
    
    return message;
        
}