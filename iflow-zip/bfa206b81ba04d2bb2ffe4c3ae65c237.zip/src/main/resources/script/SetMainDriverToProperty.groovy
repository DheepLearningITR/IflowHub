import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.mapping.ValueMappingApi;
import groovy.xml.XmlUtil;
import java.util.HashMap;

/*
Determines the MAIN driver out of the payload and stores its ID as 
property
*/
def Message processData(Message message) {
    
    def mainNamedDriver = null;
    
    //Body 
    def body = message.getBody(java.lang.String);
    
    //Parse the incoming XML into an object
    def rfcSet = new XmlSlurper().parseText(body);
    
    // Get Named Driver Entity
    def objAssignedNamDrv = rfcSet.breadthFirst().find { node-> node.name() == 'ASSIGNED_NAMDRV' }
    
    objAssignedNamDrv.item.each{ namDriver ->
            
        if (namDriver.DRIVERCATEGORY_CD.text() == '001') {
            //MainDriver
            mainNamedDriver = namDriver;
        }
    }
    
    //Properties 
    map = message.getProperties();
    
    message.setProperty("com.sap.hybriscommerce.fsa.insurance.policyreplication.InsuredObjBPID", mainNamedDriver.PARTNER_ID.text());
    
    return message;
}