import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.ITApiFactory;

/*
Mapping of the product ID from FS-PM to FSA value.
This script is used within the mapping tool of the relevance check
*/
def String mappingFunc(String valInput, MappingContext context) {

    String valueFSPMVersion   = 'FSPM_'+context.getProperty('com.sap.hybriscommerce.fsa.insurance.policyreplication.FSPM_Version');
    String valueHybrisVersion = 'FSA_'+context.getProperty('com.sap.hybriscommerce.fsa.insurance.policyreplication.FSA_Version');
	
	// Get Value Mapping Service
	def valueMapService = ITApiFactory.getApi(ValueMappingApi.class, null);
	
	valueMappedProductID = valueMapService.getMappedValue(valueFSPMVersion, "CAT_CONTRACT_PM_ID", valInput, valueHybrisVersion, "CAT_CONTRACT_PM_ID")
    if (valueMappedProductID == null) {
        valueMappedProductID = valInput
    } 
        
    return valueMappedProductID;
    
}