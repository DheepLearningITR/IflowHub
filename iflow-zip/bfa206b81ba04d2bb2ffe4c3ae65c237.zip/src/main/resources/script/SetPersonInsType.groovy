import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;

/*
Determine Insured Object Type
In future (when we will have different once) this must be based on the 
contract data received from FS-PM
*/
def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);
    
    //parse the incoming XML into an object
	def rfcSet = new XmlSlurper().parseText(body);
	
	def objCurrObject = rfcSet.breadthFirst().find { node-> node.name() == 'item' }
    
    if (objCurrObject.OBJCAT_CD.text() == '44401') {
        message.setProperty("com.sap.hybriscommerce.fsa.insurance.policyreplication.InsuredObjectType", "AUTO_US"); 
    } else {
        message.setProperty("com.sap.hybriscommerce.fsa.insurance.policyreplication.InsuredObjectType", "PERSON"); 
    }
    return message;
       
}