import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;

/*
Append the Named Driver data as XML child of the Insured Object. 
This is needed to parse the data to the Insured Object Type dependant 
Local Integration process.
*/
def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);
    
    //parse the incoming XML into an object
	def rfcSet = new XmlParser().parseText(body);
	
	//get Subject data
	def objSubject = rfcSet.breadthFirst().find { node-> node.name() == 'ET_INSRDOBJ' }
	
	//get NamDriver data
	def objNamedDriver = rfcSet.breadthFirst().find { node-> node.name() == 'ET_NAMDRV' }
	
	//Loop over Subject
    objSubject.item.each{ subject ->
    
        def objAssignedNamedDriver = subject.appendNode(new QName("ASSIGNED_NAMDRV"));
    
        //Innerloop over Named Drivers
        objNamedDriver.item.each{ namedDriver ->
        
            if (namedDriver.PPDPAC_ID.text()        == subject.PPDPAC_ID.text()        && 
                namedDriver.POLICYPRODUCT_ID.text() == subject.POLICYPRODUCT_ID.text() && 
                namedDriver.COVPAC_ID.text()        == subject.COVPAC_ID.text()        && 
                namedDriver.COVERAGE_ID.text()      == subject.COVERAGE_ID.text()      && 
                namedDriver.COVCP_ID.text()         == subject.COVCP_ID.text()         && 
                namedDriver.SUBJECT_ID.text()       == subject.SUBJECT_ID.text() ) {
                    
                    objAssignedNamedDriver.append(namedDriver);
                    
            }
            
        }
    
    }

    message.setBody(XmlUtil.serialize(rfcSet));
    return message;
    
}