import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.util.*;

/*
 As the information about relevance is stored in parameter hybrisRelevancePayload
 the original message is reduced to only contain the contracts marked as relevant.
 Irrelevant nodes are removed.
 */
def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String);
    def bodyXML = new XmlParser().parseText( body );
    
    properties = message.getProperties();
    def hybrisRelevancePayload = properties.get("com.sap.hybriscommerce.fsa.insurance.policyreplication.HybrisRelevancePayload");
    def relevanceXML = new XmlSlurper().parseText( hybrisRelevancePayload );
    
    def notRelevantContracts = []
    relevanceXML.children().each { if ( it.relevant.text() == "false" ) { notRelevantContracts <<  it.contractId.text()} }
    
    if(notRelevantContracts.containsAll("")) {
        throw new IllegalArgumentException("Wrong Input: Contract Number is empty.");
    }
    
    def nodes = bodyXML.'**'.findAll{it.name() && notRelevantContracts.containsAll(it.text()) } 
    def removeNode = { node ->    def parent = node.parent()  
            parent.remove(node) }  
    nodes.each{removeNode(it.parent())} 
    
    message.setProperty("com.sap.hybriscommerce.fsa.insurance.policyreplication.notRelevantContracts", notRelevantContracts);
    message.setBody(groovy.xml.XmlUtil.serialize(bodyXML));
    
    return message;
    
}