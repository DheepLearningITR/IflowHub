/*
This is a mapping function used to determine the formatter 
of the birthday objectitem
*/
import com.sap.it.api.mapping.MappingContext;
import com.sap.it.api.mapping.*;

def String getFormatter(String InputLabel){
    
    if (InputLabel == 'birthday' || 
        InputLabel == 'mainDriverLicenseDate' || 
        InputLabel == 'mainDriverDob' || 
        InputLabel == 'purchaseDate') {
            
        return 'DATE'
        
    } else {
        
        return ''
        
    }
    
}

def String getProperty(String property_name, MappingContext context) {

    def propValue= context.getProperty(property_name);
    return propValue;

}