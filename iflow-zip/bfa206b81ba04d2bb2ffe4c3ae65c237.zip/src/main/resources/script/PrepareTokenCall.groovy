import com.sap.gateway.ip.core.customdev.util.Message;

//  Prepare HTTP call to obtain token
def Message processData(Message message) {
    
	message.setHeader("Content-Type","application/x-www-form-urlencoded");
	message.setHeader("Accept","application/json");
	message.setBody("client_id=financial_trusted&client_secret=secret&grant_type=client_credentials");

	return message;
	
}