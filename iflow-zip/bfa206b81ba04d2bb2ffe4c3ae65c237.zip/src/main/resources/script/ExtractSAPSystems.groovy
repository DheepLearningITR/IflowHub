import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.pd.BinaryData;
import java.util.Map;
import com.sap.it.api.ITApiFactory;
import java.util.Set;

/*
This script is used to dynamically set the Cloud Connection ID used for calling the 
On-Premise systems like FS-PM or BP.
The requirement came due to the need to use one iFlow deployment for multiple SAP landscapes.
Based on the given SystemID and SystemClient (provided by the initial IFlow call) the 
Cloud Connection ID is read out of the Partner Directory.
The customer can overrule this mechanism. The Connection Attribute at the iFlow is a 
externalized Parameter (FSPM_Cloud_Connection_id). If the customer sets a fixed ID, this
ID is used. If the customer sets it to property BP_CONNECTION, this coding is used.
*/
def Message processData(Message message) {
    
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 
    if (service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }

    // Read Properties 
    map = message.getProperties();
    valueCallerSystemId     = map.get("com.sap.hybriscommerce.fsa.insurance.policyreplication.CallerSystemId");
    valueCallerSystemClient = map.get("com.sap.hybriscommerce.fsa.insurance.policyreplication.CallerSystemClient");
    valueCallerID           = valueCallerSystemId+'_'+valueCallerSystemClient;
       
    // Get mapped FS-PM Connection ID from Partner Directory
    def valueFSPMCCconnection = service.getParameter("ADDRESS_FSPM", valueCallerID , String.class);
    if (valueFSPMCCconnection == null){
        // Raise no Error. In Customer systems this parameter is not required. The connectionID is set directly at the connection.  
    } else {
        // Set mapped CC connection ID back to property
        message.setProperty("com.sap.hybriscommerce.fsa.insurance.policyreplication.FS_PM_CONNECTION", valueFSPMCCconnection);
    }
    
    // Get mapped BP Connection ID from Partner Directory
    def valueBPCCconnection = service.getParameter("ADDRESS_BP", valueCallerID , String.class);
    if (valueBPCCconnection == null){
        // Raise no Error. In Customer systems this parameter is not required. The connectionID is set directly at the connection.     
    } else {
        // Set mapped CC connection ID back to property
        message.setProperty("com.sap.hybriscommerce.fsa.insurance.policyreplication.BP_CONNECTION", valueBPCCconnection);
    }
    
    // Get mapped BP SOAP Connection ID from Partner Directory
    def valueBPSOAPCCconnection = service.getParameter("ADDRESS_BP_SOAP", valueCallerID , String.class);
    if (valueBPSOAPCCconnection == null){
        // Raise no Error. In Customer systems this parameter is not required. The connectionID is set directly at the connection.     
    } else {
        // Set mapped CC soap connection ID back to property
        valueBPSOAPCCconnection = valueBPSOAPCCconnection + valueCallerSystemClient;
        message.setProperty("com.sap.hybriscommerce.fsa.insurance.policyreplication.BP_SOAP_CONNECTION", valueBPSOAPCCconnection);
    }
    
    // Get mapped BP SOAP Connection Credentials from Partner Directory
    def valueBPCREDCCconnection = service.getParameter("ADDRESS_BP_CRED", valueCallerID , String.class);
    if (valueBPCREDCCconnection == null){
        // Raise no Error. In Customer systems this parameter is not required. The connectionID is set directly at the connection.     
    } else {
        // Set mapped CC connection credentials back to property
        message.setProperty("com.sap.hybriscommerce.fsa.insurance.policyreplication.BP_CRED_CONNECTION", valueBPCREDCCconnection);
    }
    
    //Set Scheme Agency Id for Master Data G. Key Mapping out of system- and client name.
    message.setProperty("com.sap.hybriscommerce.fsa.insurance.policyreplication.BP_SCHEME_AGENCY_ID", valueCallerID);
    
    return message;
       
}