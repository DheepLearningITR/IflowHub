import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;
import static java.util.UUID.randomUUID

/*
This script will reduce the result of FS-PM Read Policy Call and the result of the
Get Bank Details Call to BP system to the minimum information needed later in this
IFlow. 
It will also call the value mapping for certain attributes, if needed.
*/
def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);
    
    //parse the incoming XML into an object
	def rfcSet = new XmlSlurper().parseText(body);

    // Get CPI-Session Properties
    def properties = message.getProperties()
	
    //Go for error messages returned by FS-PM
    def objCurrFSPMMessages = rfcSet.breadthFirst().find { node-> node.name() == 'ET_MESSAGES' }
    def errorFSPMMessage = ''
    objCurrFSPMMessages.item.each{ loopMessage ->
        
        errorFSPMMessage = errorFSPMMessage + loopMessage.MESSAGE.text()+'|MessageClass:'+loopMessage.ID.text()+'|MessageNr:'+loopMessage.NUMBER.text()
        
    }
    if (errorFSPMMessage != '') {
        errorFSPMMessage = '|ChangeDate:'+properties.get("com.sap.hybriscommerce.fsa.insurance.policyreplication.ChangeStateDt")+'|ContractNo:'+properties.get("com.sap.hybriscommerce.fsa.insurance.policyreplication.ContractID")+errorFSPMMessage;
        throw new IllegalStateException(errorFSPMMessage);
    }
	
	// Get Value Mapping Service
	def valueMapService = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    // Construct VersionInfos into String
    valueFSPMVersion   = 'FSPM_'+ properties.get("com.sap.hybriscommerce.fsa.insurance.policyreplication.FSPM_Version")
    valueHybrisVersion = 'FSA_'+ properties.get("com.sap.hybriscommerce.fsa.insurance.policyreplication.FSA_Version")

    //Create new temp XML Body
    def stringInsurancePolicySet = '<InsurancePolicy></InsurancePolicy>'
    def InsurancePolicySet = new XmlParser().parseText(stringInsurancePolicySet)

    // Use only the polpr we are interested in
    def objCurrContract = rfcSet.breadthFirst().find { node-> node.name() == 'ET_POLPR' }
    def currContract    = objCurrContract.item[0]
    def currPolicy      = rfcSet.breadthFirst().find { node-> node.name() == 'ES_POLICY' }

    def insurancePolicySet = InsurancePolicySet.appendNode(new QName('Policy'))
    
    insurancePolicySet.appendNode(new QName('policyId'),            currPolicy.POLICYNR_TT.text( ))
    insurancePolicySet.appendNode(new QName('expiredPolicyId'),     currPolicy.POLICYNRPRDCSSR_TT.text( ))
    insurancePolicySet.appendNode(new QName('contractId'),          currContract.APPLNR_TT.text() )
    insurancePolicySet.appendNode(new QName('policyproductId'),     currContract.POLICYPRODUCT_ID.text() )
    insurancePolicySet.appendNode(new QName('policyEffectiveDate'), properties.get("com.sap.hybriscommerce.fsa.insurance.policyreplication.ChangeStateDt") + 'T00:00:00')
    insurancePolicySet.appendNode(new QName('policyStartDate'),     currContract.POLPRODBEG_DT.text() + 'T00:00:00')
    insurancePolicySet.appendNode(new QName('policyExpiryDate'),    currContract.POLPRODEND_DT.text() + 'T00:00:00')
   
    // Go for attributes with mapping
    
    // Contract status 
    valueMappedPolicyStatus = valueMapService.getMappedValue(valueFSPMVersion, currContract.PM_ID.text()+"_ACTINACTST_CD", currContract.ACTINACTST_CD.text(), valueHybrisVersion, "ACTINACTST_CD")
    if (valueMappedPolicyStatus == null) {
        // ...second try is without template ID
            valueMappedPolicyStatus = valueMapService.getMappedValue(valueFSPMVersion, "ACTINACTST_CD", currContract.ACTINACTST_CD.text(), valueHybrisVersion, "ACTINACTST_CD")
    }
    if (valueMappedPolicyStatus == null) {
        // ...last case: Use unmapped data
        valueMappedPolicyStatus = currContract.ACTINACTST_CD.text()
    }
    insurancePolicySet.appendNode(new QName('policyStatus'), valueMappedPolicyStatus )
     
    // Product category (e.g. 'insurances_life')
    valueMappedCategory = valueMapService.getMappedValue(valueFSPMVersion, "CAT_POLICY_PM_ID", currPolicy.PM_ID.text(), valueHybrisVersion, "CAT_POLICY_PM_ID")
    if (valueMappedCategory == null) {
        // ...last case: Use unmapped data
        valueMappedCategory = currPolicy.PM_ID.text()
    }
    insurancePolicySet.appendNode(new QName('category'), valueMappedCategory )
     
     
    //Append Infos out of the regular contract premium
    def objCurrPremium = rfcSet.breadthFirst().find { node-> node.name() == 'ET_PREM' }
    objCurrPremium.item.each{ premium ->
            
    if (premium.PREMTYPE_CD.text() == '01' &&    //Indicates the reqular premium
        premium.COVPAC_ID.text()   == '0' &&     // IS INITIAL
        premium.COVERAGE_ID.text() == '0' &&     // IS INITIAL
        premium.COVCP_ID.text()    == '0' &&     // IS INITIAL
        premium.SUBJECT_ID.text()  == '0' ){     // IS INITIAL
                      
            insurancePolicySet.appendNode(new QName('premiumAmount'), premium.PREMAFTERTAX_AM.text()  )
            insurancePolicySet.appendNode(new QName('currency'),      premium.CURRENCY_ID.text() )
                
            // Go for attributes with mapping (first template specific)
            valueMappedPayFrqId = valueMapService.getMappedValue(valueFSPMVersion, premium.PM_ID.text()+"_PAYFRQ_CD", premium.PAYFRQ_CD.text(), valueHybrisVersion, "PAYFRQ_CD") 
            if (valueMappedPayFrqId == null) {
                // ...second try is without template ID
                   valueMappedPayFrqId = valueMapService.getMappedValue(valueFSPMVersion, "PAYFRQ_CD", premium.PAYFRQ_CD.text(), valueHybrisVersion, "PAYFRQ_CD") 
            }
            if (valueMappedPayFrqId == null) {
                // ...last case: Use unmapped data
                valueMappedPayFrqId = premium.PAYFRQ_CD.text()
            }
            insurancePolicySet.appendNode(new QName('paymentFrequency'), valueMappedPayFrqId )
           
        }
    } 
    
    // Add main policyholder as user
    def objCurrPolicyHolder   = rfcSet.breadthFirst().find { node-> node.name() == 'ET_POLHLDR' }
    objCurrPolicyHolder.item.each{ policyHolder ->

        if (policyHolder.MAINPOLHLDR_FG.text() == 'X'){
            
            insurancePolicySet.appendNode(new QName('businessPartnerId'), policyHolder.PARTNER_ID.text()  )
                
        }
    }
    
    
    def objCurrBenefit  = rfcSet.breadthFirst().find { node-> node.name() == 'ET_BNF' }
    
    // Get coverage data from incoming message
    def INCurrCoverageSet = rfcSet.breadthFirst().find { node-> node.name() == 'ET_COV' }
    
    // Create Coverage Set for result message
    def OUTCoverageSet = insurancePolicySet.appendNode(new QName('coverages') )
    
    INCurrCoverageSet.item.each{ INCoverage ->
            
        // Create Coverage branch in result message
        OUTCoverage = OUTCoverageSet.appendNode(new QName('Coverage') )
        
        valueId = randomUUID() as String
    
        OUTCoverage.appendNode(new QName('coverageId'), valueId )
        OUTCoverage.appendNode(new QName('policyproductId'), INCoverage.POLICYPRODUCT_ID.text() )
        OUTCoverage.appendNode(new QName('covpacId'), INCoverage.COVPAC_ID.text() )
        OUTCoverage.appendNode(new QName('covId'), INCoverage.COVERAGE_ID.text() )

        // Go for attributes with mapping
        
        // Coverage Product ID
        // FIRST: PM_ID and QuoteVariant
        valueMappedCoverageProduct = valueMapService.getMappedValue(valueFSPMVersion, "CAT_COVERAGE_PM_ID_QUOTE_VARIANT", INCoverage.PM_ID.text() + '_' + currContract.QUOTEVARIANT_CD.text(), valueHybrisVersion, "CAT_COVERAGE_Code_SelectedQuoteVariant")
        if (valueMappedCoverageProduct == null) {
            // SECOND: PM_ID
            valueMappedCoverageProduct = valueMapService.getMappedValue(valueFSPMVersion, "CAT_COVERAGE_PM_ID", INCoverage.PM_ID.text(), valueHybrisVersion, "CAT_COVERAGE_PM_ID")
            if (valueMappedCoverageProduct == null) {
                // THRID: Without mapping
                valueMappedCoverageProduct = INCoverage.PM_ID.text()
            } 
        } 
        OUTCoverage.appendNode(new QName('coverageProduct'), valueMappedCoverageProduct )
        
        // Coverage Type
        valueMappedCoverageType = valueMapService.getMappedValue(valueFSPMVersion, "TYPE_COVERAGE_PM_ID", INCoverage.PM_ID.text(), valueHybrisVersion, "TYPE_COVERAGE_PM_ID")
        if (valueMappedCoverageType == null) {
            valueMappedCoverageType = INCoverage.PM_ID.text()
        } 
        OUTCoverage.appendNode(new QName('coverageType'), valueMappedCoverageType )
    
        // Quote Variant
        valueMappedQuoteVariant = currContract.QUOTEVARIANT_CD.text()
        OUTCoverage.appendNode(new QName('quoteVariant'), valueMappedQuoteVariant )
            
        // Determine assigned BNF entity
        objCurrBenefit.item.each{ benefit ->
        
        if (benefit.COVPAC_ID.text()   == INCoverage.COVPAC_ID.text()   &&
            benefit.COVERAGE_ID.text() == INCoverage.COVERAGE_ID.text() ) {
                    
                OUTCoverage.appendNode(new QName('coverageAmount'), benefit.DTHINSURED_AM.text() )
                    
            }
        }
    } 
    
    
	
	
	
	
	
	
	
	
	
	
    // Get Insured Objects Set from incoming message
    def INCurrInsObjSet  = rfcSet.breadthFirst().find { currInsObj-> currInsObj.name() == 'insuredObjects' } 
    
    // Create Insured Objects Set for result message
    def OUTinsuredObjectSet = insurancePolicySet.appendNode(new QName('insuredObjects') )
    
    // Loop over all incoming Ins Objects
    INCurrInsObjSet.InsuredObject.each{ INInsuredObject ->
    
        counter = 0
    
        // Create Insured Object for result message
        OUTinsuredObject = OUTinsuredObjectSet.appendNode(new QName('InsuredObject') )
        
        valueId = randomUUID() as String
                
        OUTinsuredObject.appendNode(new QName('insuredObjectId'),   valueId )
        OUTinsuredObject.appendNode(new QName('policyproductId'), INInsuredObject.POLICYPRODUCT_ID.text() )
        OUTinsuredObject.appendNode(new QName('covpacId'), INInsuredObject.COVPAC_ID.text() )
        OUTinsuredObject.appendNode(new QName('covId'), INInsuredObject.COVERAGE_ID.text() )
        OUTinsuredObject.appendNode(new QName('covcpId'), INInsuredObject.COVCP_ID.text() )
        OUTinsuredObject.appendNode(new QName('subjctId'), INInsuredObject.SUBJECT_ID.text() )
        OUTinsuredObject.appendNode(new QName('insuredObjectType'), INInsuredObject.InsuredObjectType.text() )
        
        // Get Insured Object Items Set from incoming message
        INCurrInsObjItemSet  = INInsuredObject.breadthFirst().find { currInsObjItem-> currInsObjItem.name() == 'insuredObjectItems' }
        
        // Create Insured Object Items Set for result message
        OUTinsuredObjectItemsSet = OUTinsuredObject.appendNode(new QName('insuredObjectItems') )
        
        // Loop over all incoming Ins Objects Items belonging to current object
        INCurrInsObjItemSet.InsuredObjectItem.each{ INinsObjItem ->
        
            counter = counter + 1
            valueItemId = valueId+'_'+counter
        
            // Create Insured Object Item for result message
            OUTinsuredObjectItem = OUTinsuredObjectItemsSet.appendNode(new QName('InsuredObjectItem') )
            
            OUTinsuredObjectItem.appendNode(new QName('externalValue'), INinsObjItem.externalValue.text() )
            OUTinsuredObjectItem.appendNode(new QName('label'),         INinsObjItem.label.text() )
            OUTinsuredObjectItem.appendNode(new QName('format'),         INinsObjItem.format.text() )
            OUTinsuredObjectItem.appendNode(new QName('itemId'),        valueItemId )
        
        }
        
        // Include child insured objects if they actually exist 
        // (Keep in mind the products which are currently relevant:
        //  - Auto product does have child insured objects (=named drivers)
        //  - Life product does not have child insured objects)
        def INCurrInsObjChildInsuredObjects  = INInsuredObject.breadthFirst().find { node-> node.name() == 'childInsuredObjects' }
        if(INCurrInsObjChildInsuredObjects) {
		    // Create Named Drivers Set for result message 
		    OUTNamedDriverSet = OUTinsuredObject.appendNode(new QName('childInsuredObjects') )
        }
		
		// Loop over Named Drivers
		INInsuredObject.childInsuredObjects.childInsuredObject.each{ INNamedDriver ->
		
			// Create Named Driver Object for result Message
			OUTNamedDriver = OUTNamedDriverSet.appendNode(new QName('childInsuredObject') )
			
			valueId = randomUUID() as String
			OUTNamedDriver.appendNode(new QName('insuredObjectId'), valueId )
			OUTNamedDriver.appendNode(new QName('policyproductId'), INNamedDriver.POLICYPRODUCT_ID.text() )
			OUTNamedDriver.appendNode(new QName('covpacId'), INNamedDriver.COVPAC_ID.text() )
			OUTNamedDriver.appendNode(new QName('covId'), INNamedDriver.COVERAGE_ID.text() )
			OUTNamedDriver.appendNode(new QName('covcpId'), INNamedDriver.COVCP_ID.text() )
			OUTNamedDriver.appendNode(new QName('subjctId'), INNamedDriver.SUBJECT_ID.text() )
			OUTNamedDriver.appendNode(new QName('namdrvId'), INNamedDriver.NAMDRV_ID.text() )
			
			// Create Insured Object Items Set for result message for Named Driver
			OUTNamDrvInsuredObjectItemsSet = OUTNamedDriver.appendNode(new QName('insuredObjectItems') )			
			
			INNamedDriverInsObjItemSet  = INNamedDriver.breadthFirst().find { namedDriverItem-> namedDriverItem.name() == 'insuredObjectItems' }
			
			INNamedDriverInsObjItemSet.InsuredObjectItem.each{ INNamDrvInsObjItem ->
			
                counter = counter + 1
                valueItemId = valueId+'_'+counter
            
                // Create Insured Object Item for result message
                OUTNamDrvInsuredObjectItemSet = OUTNamDrvInsuredObjectItemsSet.appendNode(new QName('InsuredObjectItem') )
                
                OUTNamDrvInsuredObjectItemSet.appendNode(new QName('externalValue'), INNamDrvInsObjItem.externalValue.text() )
                OUTNamDrvInsuredObjectItemSet.appendNode(new QName('label'),         INNamDrvInsObjItem.label.text() )
                OUTNamDrvInsuredObjectItemSet.appendNode(new QName('format'),        INNamDrvInsObjItem.format.text() )
                OUTNamDrvInsuredObjectItemSet.appendNode(new QName('itemId'),        valueItemId )
			}
		}
        
    }
    
	
	
	
	
	
	
	
	
	
	
	
	
    //Append Nodes out of premium payer (only one payer allowed...)     
    // PREMIUM PAYER... TODO... DECIDE WHAT TO DO IF THERE ARE MULTIPLE.
    def objBankdetail    = rfcSet.breadthFirst().find { node-> node.name() == 'BANKDETAILDATA' }
    def objCurrPremPayer = rfcSet.breadthFirst().find { node-> node.name() == 'ET_PRMPAYR' }

    objCurrPremPayer.item.each{ prmpayr ->
    
        def premiumPayerSet = insurancePolicySet.appendNode(new QName('PremiumPayer') )
        
        premiumPayerSet.appendNode(new QName('PartnerId'),     prmpayr.PARTNER_ID.text() )
        premiumPayerSet.appendNode(new QName('Name'),          prmpayr.PARTNERNAME_TT.text() )
        premiumPayerSet.appendNode(new QName('BankAccountID'), prmpayr.BANKACC_ID.text() )
        premiumPayerSet.appendNode(new QName('IBAN'),          objBankdetail.IBAN.text() )

        // Payment Method
        
        // deal with initial values of the payment method (Invoice)
        if (prmpayr.INCPAYMETHOD_CD.text() == '') {
            valuePaymentMethod = 'NULL'
        } else {
            valuePaymentMethod = prmpayr.INCPAYMETHOD_CD.text()
        }
        valueMappedPaymentMethod = valueMapService.getMappedValue(valueFSPMVersion, prmpayr.PM_ID.text()+"_INCPAYMETHOD_CD", valuePaymentMethod, valueHybrisVersion, "INCPAYMETHOD_CD")
        if (valueMappedPaymentMethod == null) {
            // ...second try is without template ID
            valueMappedPaymentMethod = valueMapService.getMappedValue(valueFSPMVersion, "INCPAYMETHOD_CD", valuePaymentMethod, valueHybrisVersion, "INCPAYMETHOD_CD")
        }
        if (valueMappedPaymentMethod == null) {
            // ...last case: Use unmapped data
            valueMappedPaymentMethod = valuePaymentMethod
        }
        premiumPayerSet.appendNode(new QName('paymentMethod'), valueMappedPaymentMethod )
                    
    }
    
    //Set InsurancePolicySet as messageBody
    message.setBody(XmlUtil.serialize(InsurancePolicySet))
    return message;
    
}
      
