import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;
import com.sap.it.api.ITApiFactory;

/*
This script will reduce the BP detail call result to the minimum information
needed later in this IFlow and will also assign the related BP ID to the
output XML.
*/
def Message processData(Message message) {
    
    //Body 
    def body = message.getBody(java.lang.String);

    //parse the incoming XML into an object
    def rfcSet = new XmlSlurper().parseText(body);
    
    // Create new Ins Obj Set Branch
    def stringinsuredObject = '<InsuredObject></InsuredObject>'
    def insuredObject = new XmlParser().parseText(stringinsuredObject)
    
    // Should only be one Subject entity in this iteration
    def objInsSubject = rfcSet.breadthFirst().find { InsSubject-> InsSubject.name() == 'item' }
    insuredObject.appendNode(new QName('POLICYPRODUCT_ID'), objInsSubject.getProperty("POLICYPRODUCT_ID").text())
    insuredObject.appendNode(new QName('COVPAC_ID'), objInsSubject.getProperty("COVPAC_ID").text())
    insuredObject.appendNode(new QName('COVERAGE_ID'), objInsSubject.getProperty("COVERAGE_ID").text())
    insuredObject.appendNode(new QName('COVCP_ID'), objInsSubject.getProperty("COVCP_ID").text())
    insuredObject.appendNode(new QName('SUBJECT_ID'), objInsSubject.getProperty("SUBJECT_ID").text())
    insuredObject.appendNode(new QName('InsuredObjectType'), 'PERSON')
    insuredObject.appendNode(new QName('BP_ID'),             objInsSubject.PARTNER_ID.text() )
   
    // Add BP data to output
    def objCentralDataPerson  = rfcSet.breadthFirst().find { node-> node.name() == 'CENTRALDATAPERSON' }
    
    def insuredObjectItemsSet = insuredObject.appendNode(new QName('insuredObjectItems'))
    
    def insuredObjectItemSet1 = insuredObjectItemsSet.appendNode(new QName('InsuredObjectItem'))
    insuredObjectItemSet1.appendNode(new QName('externalValue'), objCentralDataPerson.FIRSTNAME.text( ) )
    insuredObjectItemSet1.appendNode(new QName('label'),         'firstName' )
    
    def insuredObjectItemSet2 = insuredObjectItemsSet.appendNode(new QName('InsuredObjectItem'))
    insuredObjectItemSet2.appendNode(new QName('externalValue'), objCentralDataPerson.LASTNAME.text( ) )
    insuredObjectItemSet2.appendNode(new QName('label'),         'lastName' )
    
    def insuredObjectItemSet3 = insuredObjectItemsSet.appendNode(new QName('InsuredObjectItem'))
    insuredObjectItemSet3.appendNode(new QName('externalValue'), objCentralDataPerson.BIRTHDATE.text( )+'T00:00:00' )
    insuredObjectItemSet3.appendNode(new QName('label'),         'birthday' )
    insuredObjectItemSet3.appendNode(new QName('format'),        'DATE' )
    
    //parse back
    message.setBody(XmlUtil.serialize(insuredObject))
    
    return message;
        
}