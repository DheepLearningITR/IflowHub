import com.sap.gateway.ip.core.customdev.util.Message;

//  Prepare HTTP call to check relevance
def Message processData(Message message) {
    
    def properties = message.getProperties()
    
	message.setHeader("Content-Type","application/xml");
	message.setHeader("Accept","application/xml");
	message.setHeader("Authorization","Bearer "+ properties.get("com.sap.hybriscommerce.fsa.insurance.policyreplication.AccessToken"));
	
	return message;
	
}