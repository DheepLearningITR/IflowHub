/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
      public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Calendar.*;
import groovy.xml.*;
import com.sap.it.api.ITApiFactory; 
import com.sap.it.api.securestore.SecureStoreService; 
import com.sap.it.api.securestore.UserCredential; 
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import groovy.json.JsonSlurper;
import com.sap.it.api.mapping.ValueMappingApi;

def Message SetSecurityProperties(Message message) {
    def map = message.getProperties();
    def taxID = map.get("TaxID") as String;
    
    def service = ITApiFactory.getApi(SecureStoreService.class, null); 
    if (service == null){
        throw new IllegalStateException("SecureStoreService not found");
    }
    
    //Authorization maintained in Security Material with name like "edoc_th_stream_auth_1234567890123"
    def credentialName = "edoc_th_stream_auth_" + taxID;
    def credential = service.getUserCredential(credentialName); // exception will be raised automatically
    
    def userName = credential.getUsername();
    def password = credential.getPassword().toString(); 
    def auth2BeEncoded = userName + ":" + password;
    message.setProperty("Auth", "Basic " + auth2BeEncoded.bytes.encodeBase64().toString());
    
    //API Key maintained in Security Material with name like "edoc_th_stream_apikey_1234567890123"
    credentialName = "edoc_th_stream_apikey_" + taxID;
    def secureParameter = service.getUserCredential(credentialName); // exception will be raised automatically
    
    def apiKey = secureParameter.getPassword().toString()
    message.setProperty("ApiKey", apiKey);
	
	return message;
}

def Message GenerateRequestQuery(Message message) {
    def body = message.getBody(java.lang.String) as String; 
    
    def xmlSlurper = new XmlSlurper()
    def data = xmlSlurper.parseText(body);
    
    def issueDate = data.IssueDate.text();
    def documentNo = data.DocumentNo.text();
    def documentType = data.DocumentType.text();
    
    // DocumentType mapping
    def valueMapApi = ITApiFactory.getService(ValueMappingApi.class, null)
    def documentTypeForStream = valueMapApi.getMappedValue('SAP', 'Document Type Code', documentType, 'Application Service Provider', 'Document Type Code')

    def queryTemplate = "issueDate=${issueDate}&documentNo=${documentNo}&documentType=${documentTypeForStream}&stepCode=P015";

    message.setProperty("RequestQuery",queryTemplate.toString());

    return message;
}

def Message LogRequest(Message message) {
    def map = message.getProperties();
    def log = map.get("EnableLog") as String;
    def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	def logID = map.get("LogID") as String;
	
	if (log == 'X') {
	    messageLog.addAttachmentAsString(logID + '_get_status_request', body, "text/xml"); 
	}
     
    return message;
}

def Message LogStreamResponse(Message message) {
    def map = message.getProperties();
    def log = map.get("EnableLog") as String;
    def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	def logID = map.get("LogID") as String;
	
    if (log == 'X') {
	    messageLog.addAttachmentAsString(logID + '_get_status_response', body, "text/xml"); 
	}
    
    return message;
}

def Message PrepareCustomizedResponse(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def map = message.getProperties();
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body);

    if (object.data != null) {
        message.setProperty("DocumentNo",object.data.documentNo);
        message.setProperty("Status",object.data.status);
        message.setProperty("conversationID",object.data.conversationID);
        message.setProperty("responseMsg",groovy.xml.XmlUtil.escapeXml(object.data.responseMsg));
    }
    if (object.header != null) {
        message.setProperty("resultCode",object.header.resultCode);
        message.setProperty("resultMessage",groovy.xml.XmlUtil.escapeXml(object.header.resultMessage));
    }
    return message;
}

def Message PrepareExceptionResponse(Message message) {
    def map = message.getProperties();
    // get an exception java class instance
    def ex = map.get("CamelExceptionCaught");
    
    if (ex!=null) {
        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
            def httpResponseBody = ex.getResponseBody();
            def jsonSlurper = new JsonSlurper()
            def httpResponseBodyJson = jsonSlurper.parseText(httpResponseBody);

            message.setProperty("ExceptionStatusCode",ex.getStatusCode());
            message.setProperty("ExceptionMessage",groovy.xml.XmlUtil.escapeXml(httpResponseBodyJson.exception + " message: " + httpResponseBodyJson.message));
        } else {
            // message.setProperty("httpStatusCode",ex.getStatusCode());
            message.setProperty("ExceptionMessage",groovy.xml.XmlUtil.escapeXml("iFlow Exception: " + ex.getMessage()));
        }
    }

    return message;
}