/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util
    which includes helper methods useful for the content developer:
 
    The methods available are:
        public java.lang.Object getBody()
	    public void setBody(java.lang.Object exchangeBody)
        public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
        public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
        public void setHeader(java.lang.String name, java.lang.Object value)
        public java.util.Map<java.lang.String,java.lang.Object> getProperties()
        public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
*/
 
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
    
    map = message.getProperties();
    
    var clientNumberOfReceiver= map.get("Client_Number_of_Receiver");
	var portNumberOfSender= map.get("Port_Number_of_Sender");
	var partnerTypeOfSender= map.get("Partner_Type_of_Sender");
	var partnerNumberOfSender= map.get("Partner_Number_of_Sender");
	var portNumberOfReceiver= map.get("Port_Number_of_Receiver");
	var partnerTypeOfReceiver= map.get("Partner_Type_of_Receiver");
	var partnerNumberOfReceiver= map.get("Partner_Number_of_Receiver");
	
	var output = "true";
    
    if(clientNumberOfReceiver === null || clientNumberOfReceiver.trim().isEmpty()){
 		output = "false1";
	} else if(portNumberOfSender === null || portNumberOfSender.trim().isEmpty()){
 		output = "false2";
	} else if(partnerTypeOfSender === null || partnerTypeOfSender.trim().isEmpty()){
 		output = "false3";
	} else if(partnerNumberOfSender === null || partnerNumberOfSender.trim().isEmpty()){
 		output = "false4";
	} else if(portNumberOfReceiver === null || portNumberOfReceiver.trim().isEmpty()){
 		output = "false5";
	} else if(partnerTypeOfReceiver === null || partnerTypeOfReceiver.trim().isEmpty()){
 		output = "false6";
	} else if(partnerNumberOfReceiver === null || partnerNumberOfReceiver.trim().isEmpty()){
 		output = "false7";
	}
	
	message.setHeader("System_Check_Result", output);
    
    return message;
}