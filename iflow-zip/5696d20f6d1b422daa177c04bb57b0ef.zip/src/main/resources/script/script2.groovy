import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.gateway.ip.core.customdev.util.AttachmentWrapper;
import javax.activation.DataHandler;
import java.util.HashMap;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        def props = message.getProperties();
        def index = String.format("%03d", Integer.parseInt(props['AttachmentIndex']) + 1);
        message.setProperty('AttachmentIndex', index);
        def id = "Error Report Page " + index;
        def body = message.getBody(String.class);
        messageLog.addAttachmentAsString(id, 'Date,Integration Flow,Candidate Name,Candidate Email,Application Id,Candidate Id,User Id,Assessment Order Id,Error Code,Error Message,Exception,Integration Package,Integration Message Id' + body, "text/csv");
        def report = props['ReportContents'];
        message.setProperty('ReportContents', report + body);
    }
    return message;
}