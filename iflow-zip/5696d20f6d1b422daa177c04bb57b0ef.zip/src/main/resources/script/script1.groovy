import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.gateway.ip.core.customdev.util.AttachmentWrapper;
import javax.activation.DataHandler;

def Message processData(Message message) {
    def props = message.getProperties();
    def aw = new AttachmentWrapper(new DataHandler('Date,Integration Flow,Candidate Name,Candidate Email,Application Id,Candidate Id,User Id,Assessment Order Id,Error Code,Error Message,Exception,Integration Package,Integration Message Id' + props['ReportContents'], "text/plain"));
    message.addAttachmentObject("Error Messages.csv", aw);
    return message;
}