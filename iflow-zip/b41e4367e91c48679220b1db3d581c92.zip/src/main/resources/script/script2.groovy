/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import java.util.UUID;


def Message processData(Message message) {
    //Body
    def body = message.getBody(String);
    
    def properties = message.getProperties();
    def dataSchedulerScope = properties.get("dataSchedulerScope");
    def persistentQueueJson = properties.get("persistentQueue") ?: null;
    def persistentQueue;
    if ( persistentQueueJson != null ) {
     persistentQueue = new JsonSlurper().parseText(persistentQueueJson);
    }
    def resourceJson = properties.get("resourceConfigJson");
    def scheduledQueryType = properties.get("scheduledQueryType");
    def scheduledFromInterval = properties.get("scheduledFromInterval");
    def scheduledToInterval = properties.get("scheduledToInterval");
    def dataSchedulerTimestampmillis = properties.get("dataSchedulerTimestampmillis")
    def timezone = resourceJson?.config?.find { it.containsKey("timezone") }?.get("timezone")
    def queue = [:]
    def fromTimestamp,toTimestamp, id, queue_url;
    def dataSchedulerDeltaPeriod = properties.get("dataSchedulerDeltaPeriod")
    def retryQueue = properties.get("retryQueue") ?: null
    def retryQueueList = properties.get("retryQueueList")
     def dataSourceIn = properties.get("dataSource")
    
    if ( retryQueue != null ) {
        retryQueueList.each{ retryId -> 
            try {
                if ( !persistentQueue.containsKey(retryId) ) {
                    throw new IllegalArgumentException("Queue Item:'${retryId}' doesn't exist in persistent Queue") 
                } else {
                    persistentQueue[retryId].status = 'Scheduled'
                    persistentQueue[retryId].executionTimestamp = dataSchedulerTimestampmillis
                    persistentQueue[retryId].updatedTimestamp = dataSchedulerTimestampmillis
                    persistentQueue[retryId].retry = 0
                    if ( persistentQueue[retryId].failedReason ) {
                        persistentQueue[retryId].remove("failedReason")
                    }
                }   
        } catch ( Exception e ) {
            throw new RuntimeException("iFlow failed due to validation error: " + e.message)
        }
    }
    }
    
    if ( retryQueue == null ) {
    resourceJson.resourceItemsConfig.each { config ->
    if ( config?.get("dataSource")?.contains(dataSourceIn) ) { //contains("SAPAriba") ) {  // Using safe navigation to avoid errors
        message.setProperty("test",config)
       if ( dataSchedulerScope.size() > 0 && !( dataSchedulerScope.any { it.contains("All") } ) ) {
           dataSchedulerScope.each { scope ->
            def value = config?.get("resourceItems")?.get(scope)// each { key, value ->  
            //result[key] = config.get("dataSource")
            //if ( dataSchedulerScope.contains("All") ) {
            if ( value?.type == 'view' ) {
            def dataSource = config?.get("dataSource")   //Commenting as part of Data Source Id parameter logic
           // def dataSource = properties.get("dataSource")
            def baseURL = resourceJson?.dataSources?.find { it.containsKey(dataSource) }?.get(dataSource)?.baseURL
            def realm = resourceJson?.dataSources?.find { it.containsKey(dataSource) }?.get(dataSource)?.tenantId
            def createView = resourceJson?.dataSources?.find { it.containsKey(dataSource) }?.get(dataSource)?.apis?.get(config?.get("api"))?.createView
            def jobSubmit = resourceJson?.dataSources?.find { it.containsKey(dataSource) }?.get(dataSource)?.apis?.get(config?.get("api"))?.jobSubmit
            if ( scheduledQueryType == 'initialization' ) {
                fromTimestamp = toTimestamp = -1;
                 queue_url = baseURL + createView + "/" + scope + "?realm=" + realm
                 id = UUID.randomUUID().toString();
                def queuevalue = [
                    "dataSource": config?.get("dataSource"),
                    "api": config?.get("api"),
                    "id": id,
                    "createdTimestamp" : dataSchedulerTimestampmillis,
                    "repositoryItem" : scope,
                    "url" : queue_url,
                    "queryType" : scheduledQueryType,
                    "status" : "Scheduled",
                    "executionTimestamp" : dataSchedulerTimestampmillis,
                    "retry" : 0,
                    "fromTimestamp" : fromTimestamp,
                    "toTimestamp" : toTimestamp,
                    "updatedTimestamp" : dataSchedulerTimestampmillis
                    ]
                queue[id] = queuevalue;
            }
            if ( scheduledQueryType == 'initial' || scheduledQueryType == 'range' ) {
                if ( scheduledFromInterval ) {
                    scheduledFromInterval.eachWithIndex { fromtime, index -> 
                        fromTimestamp = fromtime
                        toTimestamp = scheduledToInterval[index]
                        if ( scheduledFromInterval.size() > 1 ) {
                        id = UUID.randomUUID().toString() + '|' + index;
                        } else {
                        id = UUID.randomUUID().toString()    
                        }
                        queue_url = baseURL + jobSubmit + "?realm=" + realm
                     def queuevalue = [
                        "dataSource": config?.get("dataSource"),
                        "api": config?.get("api"),
                        "id": id,
                        "createdTimestamp" : dataSchedulerTimestampmillis,
                        "repositoryItem" : scope,
                        "url" : queue_url,
                        "queryType" : scheduledQueryType,
                        "status" : "Scheduled",
                        "executionTimestamp" : dataSchedulerTimestampmillis,
                        "retry" : 0,
                        "fromTimestamp" : fromTimestamp,
                        "toTimestamp" : toTimestamp,
                        "updatedTimestamp" : dataSchedulerTimestampmillis
                        ]
                    queue[id] = queuevalue;
                    }
                }
            }
            if ( scheduledQueryType == 'delta' ) {
                def query = dataSource + "|" + config?.get("api") + "|" + scope
                    try {
                        if ( !persistentQueue.containsKey(query) ) {
                        throw new IllegalArgumentException("No Initial Load Executed") 
                            }    
                    //update last successkey with delta deltaPeriod
                    persistentQueue[query].deltaPeriod = dataSchedulerDeltaPeriod.toInteger();
                   if ( persistentQueue.containsKey(query) && dataSchedulerDeltaPeriod.toInteger() > 0 ) {
                     fromTimestamp = persistentQueue[query]?.toTimestamp
                     toTimestamp = dataSchedulerTimestampmillis  //changed from dataSchedulerTimestampmillis
                         // Convert 300 days to milliseconds
                        def days300InMillis = 300L * 24 * 60 * 60 * 1000  // 300 days in ms
                        if ( (toTimestamp - fromTimestamp) > days300InMillis ) {
                            throw new IllegalArgumentException("Delta date range cannot be more than 300 days, use initial load instead!") 
                     }
                     id = id = UUID.randomUUID().toString();
                     queue_url = baseURL + jobSubmit + "?realm=" + realm
                    
                        def queuevalue = [
                        "dataSource": config?.get("dataSource"),
                        "api": config?.get("api"),
                        "id": id,
                        "createdTimestamp" : dataSchedulerTimestampmillis,
                        "repositoryItem" : scope,
                        "url" : queue_url,
                        "queryType" : scheduledQueryType,
                        "status" : "Scheduled",
                        "executionTimestamp" : dataSchedulerTimestampmillis,
                        "retry" : 0,
                        "fromTimestamp" : fromTimestamp,
                        "toTimestamp" : toTimestamp,
                        "updatedTimestamp" : dataSchedulerTimestampmillis,
                        "deltaPeriod" : dataSchedulerDeltaPeriod.toInteger()
                        ]
                    queue[id] = queuevalue;
                   // queue[query]
                   }
             // Need to remove queue with other scheduled status from existing persistentQueue while scheduling for new delta or zero delta
                   persistentQueue.keySet().removeAll { rkey ->
                   def entry = persistentQueue[rkey]
                        entry.repositoryItem == scope && entry.queryType == 'delta' && entry.status == 'Scheduled' && entry.url.contains("-reporting-job/")
                                    }
                   } catch (Exception e) {
                                // Log error and fail iFlow
                                message.setProperty("ValidationStatus", "Failed")
                                message.setProperty("ErrorMessage", e.message)
                                throw new RuntimeException("iFlow failed due to validation error: " + e.message)
                            }
                        }
                     }
                    
                  }
                 //}
             } else if ( dataSchedulerScope.any { it.contains("All") } ) {
            def apilist = resourceJson?.dataSources?.find { it.containsKey(dataSourceIn) }?.get(dataSourceIn)?.apis?.keySet();
            message.setProperty("apilist",apilist)
            if ( config?.get("api") in apilist ) { // added for api check in datasource
             config?.get("resourceItems")?.each { key, value ->  
            //result[key] = config.get("dataSource")
            //if ( dataSchedulerScope.contains("All") ) {
            if ( value?.type == 'view' ) {
            def dataSource = config?.get("dataSource")
            def baseURL = resourceJson?.dataSources?.find { it.containsKey(dataSource) }?.get(dataSource)?.baseURL
            def realm = resourceJson?.dataSources?.find { it.containsKey(dataSource) }?.get(dataSource)?.tenantId
            def createView = resourceJson?.dataSources?.find { it.containsKey(dataSource) }?.get(dataSource)?.apis?.get(config?.get("api"))?.createView
            def jobSubmit = resourceJson?.dataSources?.find { it.containsKey(dataSource) }?.get(dataSource)?.apis?.get(config?.get("api"))?.jobSubmit
            if ( scheduledQueryType == 'initialization' ) {
                fromTimestamp = toTimestamp = -1;
                 queue_url = baseURL + createView + "/" + key + "?realm=" + realm
                 id = UUID.randomUUID().toString();
                def queuevalue = [
                    "dataSource": config?.get("dataSource"),
                    "api": config?.get("api"),
                    "id": id,
                    "createdTimestamp" : dataSchedulerTimestampmillis,
                    "repositoryItem" : key,
                    "url" : queue_url,
                    "queryType" : scheduledQueryType,
                    "status" : "Scheduled",
                    "executionTimestamp" : dataSchedulerTimestampmillis,
                    "retry" : 0,
                    "fromTimestamp" : fromTimestamp,
                    "toTimestamp" : toTimestamp,
                    "updatedTimestamp" : dataSchedulerTimestampmillis
                    ]
                queue[id] = queuevalue;
                          }
                if ( scheduledQueryType == 'initial' || scheduledQueryType == 'range' ) {
                    if ( scheduledFromInterval ) {
                        scheduledFromInterval.eachWithIndex { fromtime, index -> 
                        fromTimestamp = fromtime
                        toTimestamp = scheduledToInterval[index]
                        if ( scheduledFromInterval.size() > 1 ) {
                        id = UUID.randomUUID().toString() + '|' + index;
                             } else {
                        id = UUID.randomUUID().toString()    
                            }
                        queue_url = baseURL + jobSubmit + "?realm=" + realm
                    def queuevalue = [
                        "dataSource": config?.get("dataSource"),
                        "api": config?.get("api"),
                        "id": id,
                        "createdTimestamp" : dataSchedulerTimestampmillis,
                        "repositoryItem" : key,
                        "url" : queue_url,
                        "queryType" : scheduledQueryType,
                        "status" : "Scheduled",
                        "executionTimestamp" : dataSchedulerTimestampmillis,
                        "retry" : 0,
                        "fromTimestamp" : fromTimestamp,
                        "toTimestamp" : toTimestamp,
                        "updatedTimestamp" : dataSchedulerTimestampmillis
                        ]
                    queue[id] = queuevalue;
                            }
                        }
                    }
                    if ( scheduledQueryType == 'delta' ) {
                     def query = dataSource + "|" + config?.get("api") + "|" + key
                       try {
                        if ( !persistentQueue.containsKey(query) ) {
                        throw new IllegalArgumentException("No Initial Load Executed for ${query}") 
                            }
                      persistentQueue[query].deltaPeriod = dataSchedulerDeltaPeriod.toInteger();      
                   if ( persistentQueue.containsKey(query) && dataSchedulerDeltaPeriod.toInteger() > 0 ) {
                    fromTimestamp = persistentQueue[query]?.toTimestamp
                     toTimestamp = dataSchedulerTimestampmillis  //changed from dataSchedulerTimestampmillis
                         // Convert 300 days to milliseconds
                        def days300InMillis = 300L * 24 * 60 * 60 * 1000  // 300 days in ms
                        if ( (toTimestamp - fromTimestamp) > days300InMillis ) {
                            throw new IllegalArgumentException("Delta date range cannot be more than 300 days, use initial load instead!") 
                     } //changed from dataSchedulerTimestampmillis
                      id = id = UUID.randomUUID().toString();
                     queue_url = baseURL + jobSubmit + "?realm=" + realm
                    
                        def queuevalue = [
                        "dataSource": config?.get("dataSource"),
                        "api": config?.get("api"),
                        "id": id,
                        "createdTimestamp" : dataSchedulerTimestampmillis,
                        "repositoryItem" : key,
                        "url" : queue_url,
                        "queryType" : scheduledQueryType,
                        "status" : "Scheduled",
                        "executionTimestamp" : dataSchedulerTimestampmillis,
                        "retry" : 0,
                        "fromTimestamp" : fromTimestamp,
                        "toTimestamp" : toTimestamp,
                        "updatedTimestamp" : dataSchedulerTimestampmillis,
                        "deltaPeriod" : dataSchedulerDeltaPeriod.toInteger()
                        ]
                    queue[id] = queuevalue;
                    
                   }  //Error handling for delta 
             // Need to remove queue with other scheduled status from existing persistentQueue while scheduling for new delta or zero delta for specific resource item & dataSource
                persistentQueue.keySet().removeAll { rkey ->
                   def entry = persistentQueue[rkey]
                        entry.dataSource == dataSource && entry.repositoryItem == key && entry.queryType == 'delta' && entry.status == 'Scheduled' && entry.url.contains("-reporting-job/")
                                    }
                     } catch (Exception e) {
                        message.setProperty("ValidationStatus", "Failed")
                        message.setProperty("ErrorMessage", e.message)
                        throw new RuntimeException("iFlow failed due to validation error: " + e.message)
                        }
                     }
                       }
                    
                 // }
                 }
             } // added for api check in datasource
                  }   
               }
        }
        } //Added for retry queue
    message.setProperty("queue",JsonOutput.toJson(queue))
    def queue_final = [:];
    if ( persistentQueue != null ) {
    queue_final.putAll(persistentQueue)
    }
    queue_final.putAll(queue)
    
    message.setProperty("queue_final",JsonOutput.toJson(queue_final))
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(queue_final)));
    return message;
}