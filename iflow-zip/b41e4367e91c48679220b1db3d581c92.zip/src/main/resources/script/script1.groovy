/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import groovy.json.JsonSlurper;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.TimeZone;
import java.time.format.DateTimeParseException;

def Message processData(Message message) {
    //Body
    def body = message.getBody();
    def resourceJson  = new JsonSlurper().parseText(message.getBody(String))
	message.setProperty("resourceConfigJson",resourceJson)
    //Properties
    def properties = message.getProperties();
    def timezone = resourceJson?.config?.find { it.containsKey("timezone") }?.get("timezone")
    if ( !timezone ) {
        timezone = 'UTC'
    }
    def scopevalues = properties.get("dataSchedulerScope");
    def retryQueue = properties.get("retryQueue");
    scheduledToTimestamp1 = properties.get("scheduledToTimestamp1");
    scheduledFromTimestamp1 = properties.get("scheduledFromTimestamp1")
    def scheduledQueryType = properties.get("scheduledQueryType")
    def dataSchedulerTimestamp = properties.get("dataSchedulerTimestamp")
    def dataSchedulerDeltaPeriod = properties.get("dataSchedulerDeltaPeriod")
    def dataSchedulerScope = scopevalues.split(",").toList()
    def retryQueueList = retryQueue.split(",").toList();
    def scheduledFromInterval = scheduledToInterval = []
    def toDate, fromDate, scheduledToTimestamp, scheduledFromTimestamp
    def dataSourceId = properties.get("dataSource"); 
    def errorMsg
    
    def dataSchedulerTimestampmillis = convertToMillis(dataSchedulerTimestamp,timezone)
    message.setProperty("dataSchedulerTimestampmillis", dataSchedulerTimestampmillis)
// Validation on Mode parameter  
    try {
       if (!retryQueue) {
         if ( !dataSourceId || dataSourceId.isEmpty() ) { 
            throw new IllegalArgumentException("Data Source Id is mandatory field. Input one of dataSources from configuration file and try again")
           } else {
              def dataSourcelist = resourceJson?.dataSources.collect { it.keySet().first() }
            if ( !(dataSourceId in dataSourcelist) ) {
                        throw new IllegalArgumentException("Invalid Data Source: '${dataSourceId}'")
                    }
                }
            } 
        if ( retryQueue && scheduledQueryType ) {
             throw new IllegalArgumentException("Mode and 'Retry Queue ID' cannot be set together. Clear Mode or Retry Queue and try again")
        }
        message.setProperty("retryQueueList",retryQueueList)
        
        if ( !retryQueue ) {
        // Define allowed values
        def allowedValues = ["initialization", "initial", "delta", "range"]
        
        // Check if scheduledQueryType is valid
        if (!(scheduledQueryType in allowedValues)) {
            throw new IllegalArgumentException("Invalid Mode: '${scheduledQueryType}'. Allowed values: Enter any one of ${allowedValues}")
        }
    }
        // If valid, proceed with the flow
        message.setProperty("ValidationStatus", "Success")
        
    } catch (Exception e) {
        // Log error and fail iFlow
        message.setProperty("ValidationStatus", "Failed")
       // message.setProperty("ErrorMessage", e.message)
       errorMsg = e.message
        throw new RuntimeException("iFlow failed due to validation error: " + e.message)
    }
    
    //Compare Extract from and to timestamp
   // try {
        if ( scheduledQueryType != 'initialization' ) {
   // validateScheduledTimestamps(scheduledFromTimestamp1, scheduledToTimestamp1, dataSchedulerTimestamp)
    def formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")
     def dataSchedulerDate = LocalDateTime.parse(dataSchedulerTimestamp, formatter)
     try {
         if ( scheduledFromTimestamp1 != null && !scheduledFromTimestamp1.isEmpty() ) {
         fromDate = LocalDateTime.parse(scheduledFromTimestamp1, formatter)
         }
     } catch (DateTimeParseException e) {
        // If parsing fails, throw an exception with an error message.
        throw new RuntimeException("iFlow failed due to validation error: Extraction From Timestamp '${scheduledFromTimestamp1}' is not in the correct format. Expected format: yyyy-MM-dd'T'HH:mm:ss. ")
    }
    
    try {
         if ( scheduledToTimestamp1 != null && !scheduledToTimestamp1.isEmpty() ) {
         toDate = LocalDateTime.parse(scheduledToTimestamp1, formatter)
         }
     } catch (DateTimeParseException e) {
        // If parsing fails, throw an exception with an error message.
        throw new RuntimeException("iFlow failed due to validation error: Extraction To Timestamp '${scheduledToTimestamp1}' is not in the correct format. Expected format: yyyy-MM-dd'T'HH:mm:ss. ")
    }

    try {
        if ( toDate != null && fromDate != null ) {
    if (!toDate.isAfter(fromDate)) {
        throw new IllegalArgumentException("ExtractiontoTimestamp ($scheduledToTimestamp1) cannot be earlier than ExtractionFromTimestamp ($scheduledFromTimestamp1)")
    }
        }
    
     // Check if scheduledToTimestamp <= dataSchedulerTimestamp
     if ( toDate != null ) {
        if (toDate.isAfter(dataSchedulerDate)) {
            throw new IllegalArgumentException("Error: ExtractiontoTimestamp ($scheduledToTimestamp1) cannot be in future")
        }
     }
     
        // Check if scheduledToTimestamp <= dataSchedulerTimestamp
     if ( fromDate != null ) {
        if (fromDate.isAfter(dataSchedulerDate)) {
            throw new IllegalArgumentException("Error: ExtractionFromTimestamp ($scheduledFromTimestamp1) cannot be in future")
        }
     }
        
    } catch (Exception e) {
        message.setProperty("ValidationStatus", "Failed")
        message.setProperty("ErrorMessage", e.message)
        throw new RuntimeException("iFlow failed due to validation error: " + e.message)
    }
        }// test
      /*  } catch (Exception e) {
       message.setProperty("ValidationStatus", "Failed")
        message.setProperty("ErrorMessage", e.message)
        throw new RuntimeException("iFlow failed due to validation error: " + e.message)
        } */
        
        //Scope  validations
         try {
        if ( !retryQueue ) {     
        def resourceScope = resourceJson?.resourceItemsConfig?.collectMany {
      //      it.resourceItems.keySet() 
            if ( it.dataSource == dataSourceId.toString() ) { 
            it.resourceItems.keySet() 
        } else {
        return []
        }// important to avoid null return
        }
        // Normalize scopes: replace "all" (case-insensitive) with "All"
        dataSchedulerScope = dataSchedulerScope.collect { it.equalsIgnoreCase("all") ? "All" : it }
        dataSchedulerScope.each { scope ->
            //scope = scope.equalsIgnoreCase("all") ? "All" : scope
            if ( scope != "All" ) {
                if (!(scope in resourceScope)) {
                    throw new IllegalArgumentException("Invalid Scope: '${scope}'")
                }
            }
        }
        message.setProperty("dataSchedulerScope", dataSchedulerScope);
        }
        
        if ( scheduledQueryType == 'initial' ) {
            if ( !scheduledToTimestamp1.isEmpty() && scheduledFromTimestamp1.isEmpty() ) {
                 throw new IllegalArgumentException("Extraction From Timestamp needs to be defined in case Extraction To Timestamp is defined!")
            }
        }
        
        if ( scheduledQueryType == 'delta' ) {
            if ( dataSchedulerDeltaPeriod == null || dataSchedulerDeltaPeriod.isEmpty() ) {
                 throw new IllegalArgumentException("Delta Period needs to be defined for delta extraction!")
            }
        }
        
        if ( scheduledQueryType == 'range' ) {
             if ( scheduledToTimestamp1.isEmpty() || scheduledFromTimestamp1.isEmpty() ) {
                 throw new IllegalArgumentException("Both Extraction From Timestamp and Extraction To Timestamp needs to be defined for range extraction!")
            }
        }
        
        if ( scheduledQueryType == 'initial' || scheduledQueryType == 'range' ) {
        if ( !scheduledToTimestamp1.isEmpty() && scheduledToTimestamp1 != null ) {
            scheduledToTimestamp = convertToMillis(scheduledToTimestamp1, timezone)
        }
        if ( !scheduledFromTimestamp1.isEmpty() && scheduledFromTimestamp1 != null ) {
            scheduledFromTimestamp = convertToMillis(scheduledFromTimestamp1, timezone)
        }
        }
        
        if ( !scheduledToTimestamp1  ) { scheduledToTimestamp = -1 }
        if ( !scheduledFromTimestamp1  ) { scheduledFromTimestamp = -1 }
        
        if ( scheduledQueryType == 'initial') {
            if ( scheduledToTimestamp == -1 ) {
                scheduledToTimestamp = dataSchedulerTimestampmillis
            } 
        }
        
        if ( scheduledQueryType == 'delta') {
                scheduledToTimestamp = dataSchedulerTimestampmillis
        }
         message.setProperty("scheduledFromTimestamp", scheduledFromTimestamp)
          message.setProperty("scheduledToTimestamp", scheduledToTimestamp)
        if ( scheduledFromTimestamp > 0 ) {
             def oneYearInMillis = 365L * 24 * 60 * 60 * 1000  // 1 year in milliseconds
             def difference = Math.abs( scheduledToTimestamp - scheduledFromTimestamp )  // Get absolute difference
             message.setProperty("difference",difference)
            if ( difference > oneYearInMillis ) {
                def result = splitIntoOneYearIntervals(scheduledFromTimestamp, scheduledToTimestamp, timezone)
                scheduledFromInterval = result[0];
                scheduledToInterval = result[1];
            } else {
                scheduledFromInterval = [scheduledFromTimestamp];
                scheduledToInterval = [scheduledToTimestamp];
            }
        } else {
            scheduledFromInterval = [scheduledFromTimestamp]
            scheduledToInterval = [scheduledToTimestamp]
        }
        
        message.setProperty("scheduledFromInterval",scheduledFromInterval)
        message.setProperty("scheduledToInterval", scheduledToInterval)
         } catch (Exception e) {
        // Log error and fail iFlow
        message.setProperty("ValidationStatus", "Failed")
        message.setProperty("ErrorMessage", e.message)
        throw new RuntimeException("iFlow failed due to validation error: " + e.message)
    }
    if ( errorMsg != null ) {
    message.setProperty("ErrorMessage", errorMsg)
     message.setProperty("ValidationStatus", "Failed")
    }
    return message;
}

// Function to split timestamps into 1-year intervals (in millis)
def splitIntoOneYearIntervals(long timestamp1, long timestamp2, String timezone) {
    def zoneId = ZoneId.of(timezone)

    // Convert milliseconds to ZonedDateTime
    def fromTimestamp = Instant.ofEpochMilli(timestamp1).atZone(zoneId)
    def toTimestamp = Instant.ofEpochMilli(timestamp2).atZone(zoneId)

    def scheduledFromInterval1 = []
    def scheduledToInterval1 = []

    def currentFrom = fromTimestamp

    while (true) {
        def nextYear = currentFrom.plus(1, ChronoUnit.YEARS)

        // Ensure we do not exceed timestamp2
        if (!nextYear.isBefore(toTimestamp)) {
            scheduledFromInterval1 << currentFrom.toInstant().toEpochMilli()
            scheduledToInterval1 << toTimestamp.toInstant().toEpochMilli()
            break
        }

        scheduledFromInterval1 << currentFrom.toInstant().toEpochMilli()
        scheduledToInterval1 << nextYear.toInstant().toEpochMilli()

        currentFrom = nextYear
    }

    return [scheduledFromInterval1, scheduledToInterval1]
}

def convertToMillis(timestamp, timezone) {
    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")  // Define format
    sdf.setTimeZone(TimeZone.getTimeZone(timezone))  // Set timezone
    return sdf.parse(timestamp).time  // Convert to millis
}

def validateScheduledTimestamps(scheduledFromTimestamp, scheduledToTimestamp, dataSchedulerTimestamp) {
    def formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")
     try {
         if ( !scheduledFromTimestamp.isEmpty() || scheduledFromTimestamp != null ) {
        def fromDate = LocalDateTime.parse(scheduledFromTimestamp, formatter)
         }
     } catch (DateTimeParseException e) {
        // If parsing fails, throw an exception with an error message.
        throw new RuntimeException("Timestamp '${scheduledFromTimestamp}' is not in the correct format. Expected format: yyyy-MM-dd'T'HH:mm:ss. ")
    }
    
    try {
         if ( !scheduledToTimestamp.isEmpty() || scheduledToTimestamp != null ) {
        def toDate = LocalDateTime.parse(scheduledToTimestamp, formatter)
         }
     } catch (DateTimeParseException e) {
        // If parsing fails, throw an exception with an error message.
        throw new RuntimeException("Timestamp '${scheduledToTimestamp}' is not in the correct format. Expected format: yyyy-MM-dd'T'HH:mm:ss. ")
    }
    
     def dataSchedulerDate = LocalDateTime.parse(dataSchedulerTimestamp, formatter)
    try {
    if (!toDate.isAfter(fromDate)) {
        throw new IllegalArgumentException("ExtractiontoTimestamp ($scheduledToTimestamp) cannot be earlier than ExtractionFromTimestamp ($scheduledFromTimestamp)")
    }
    
     // Check if scheduledToTimestamp <= dataSchedulerTimestamp
        if (toDate.isAfter(dataSchedulerDate)) {
            throw new IllegalArgumentException("Error: ExtractiontoTimestamp ($scheduledToTimestamp) cannot be in future")
        }
        
    } catch (DateTimeParseException e) {
        throw new IllegalArgumentException("iFlow failed due to validation error: " + e.message)
    }
}
