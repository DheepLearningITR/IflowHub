import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import com.sap.it.api.mapping.MappingContext;
import com.sap.it.api.mapping.Output;
import groovy.transform.Field;

@Field Map<String, String> EXEMPT_CODE_MAP = new HashMap<String, String>();
    EXEMPT_CODE_MAP.put("01", "Federal government");
    EXEMPT_CODE_MAP.put("02", "State or local government");
    EXEMPT_CODE_MAP.put("03", "Tribal government");
    EXEMPT_CODE_MAP.put("04", "Foreign diplomat");
    EXEMPT_CODE_MAP.put("05", "Charitable organization");
    EXEMPT_CODE_MAP.put("06", "Religious or educational organization");
    EXEMPT_CODE_MAP.put("07", "Resale");
    EXEMPT_CODE_MAP.put("08", "Agricultural production");
    EXEMPT_CODE_MAP.put("09", "Industrial production/manufacturing");
    EXEMPT_CODE_MAP.put("10", "Direct pay permit");
    EXEMPT_CODE_MAP.put("11", "Direct Mail");
    EXEMPT_CODE_MAP.put("12", "Other");
    EXEMPT_CODE_MAP.put("13", "Non Profit");

def Message processData(Message message) 
{
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential("suretaxuser");
    if (credential == null) {
        throw new IllegalStateException("No credential found for alias <>");
    }
    String userName = credential.getUsername();
    String password = new String(credential.getPassword());
    
    message.setBody("userName is "+ userName  + " and password is "+password);
    return message;
}

def String customGetClientNumber(String storedUsername) {
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential(storedUsername);
    if (credential == null) {
        throw new IllegalStateException("No credential found for alias '$storedUsername'");
    }
    return credential.getUsername();
}

def String customGetVKey (String storedUsername) {
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential(storedUsername);
    if (credential == null) {
        throw new IllegalStateException("No credential found for alias '$storedUsername'");
    }
    return new String(credential.getPassword());
}


def String getDateInFormat(String primaryDate, String secondaryDate){
   SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
   simpleDateFormat.setLenient(false);
    Date date = null;
    try {
        date = Date.parse("yyyy-MM-dd", primaryDate);
    } catch(Exception e){
        try {
            date = Date.parse("yyyy-MM-dd", secondaryDate);
        } catch (Exception ex) {
            throw new Exception("Bad Date");
        }
    }
   
   // Now we have today date or from dateStr
   String dateToReturn = simpleDateFormat.format(date);
   return dateToReturn;
}

def String getDataYear(String dateStr){
   SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
   Date date = null;
   try {
        date = Date.parse("yyyy-MM-dd",dateStr);
   } catch(ParseException e){
        throw new Exception("Bad Date");
   }
   Date currentDate = new Date();
   String currentDateStr = new Date().format("yyyy-MM-dd");
   currentDate = Date.parse("yyyy-MM-dd",currentDateStr);
   // Now we have today date or from dateStr
   String dateToReturn = dateFormat.format(date);
   if(date.compareTo(currentDate) == 1)
   {
       dateToReturn = dateFormat.format(currentDate);
   }
   
   return dateToReturn.substring(0,4);
}

def String getDataMonth(String date) {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Date date1 = null;
    try{
        date1 = Date.parse("yyyy-MM-dd",date);
    } catch(ParseException e){
        throw new Exception("Bad Date");
    }
    Date currentDate = new Date();
    String currentDateStr = new Date().format("yyyy-MM-dd");
    currentDate = Date.parse("yyyy-MM-dd",currentDateStr);
    String monthToReturn = simpleDateFormat.format(date1);
    if(date1.compareTo(currentDate) == 1)
    {
       
       monthToReturn = simpleDateFormat.format(currentDate);
    }
    return monthToReturn.substring(5,7);
}

def String getYear(String primaryDate/*, String secondaryDate*/) {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    simpleDateFormat.setLenient(false);
    Date date = null;
    try {
        date = Date.parse("yyyy-MM-dd", primaryDate);
    } catch(Exception e){
        /*throw new Exception("Something went wrong here on");*/
        /*try {
            date = Date.parse("yyyy-MM-dd", secondaryDate);
        } catch (Exception ex) {*/
            throw new Exception("Bad Date");
        /*}*/
    }
   
   // Now we have today date or from dateStr
   String dateToReturn = simpleDateFormat.format(date);
   return dateToReturn.substring(0, 4);
}

def String getRuleOverrideValue(String APAR_IND, MappingContext context) {
    String ruleOverrideVal = "0";
    if("A".equalsIgnoreCase(APAR_IND)) {
        ruleOverrideVal = getExchangeProperty("exchangeARRuleOverride", context);
    } else if ("V".equalsIgnoreCase(APAR_IND)) {
        ruleOverrideVal = getExchangeProperty("exchangeAPRuleOverride", context);
    }
    return ruleOverrideVal;
}

def String setItemNumberInContext(String itemNumber, MappingContext context) {
   context.setProperty("itemno", itemNumber);
   return itemNumber;
}

def String setTaxAmovInContext(String taxAmov, MappingContext context) {
    BigDecimal val = new BigDecimal(taxAmov.trim());
    int currencyDecimalInt = 2;
    int currencyDecimalVal = 100;
    try{
        String currencyDecimalStr = getExchangeProperty("exchageCurrencyDecimal",context);
        currencyDecimalInt = Integer.parseInt(currencyDecimalStr.trim());
        currencyDecimalVal = Math.pow(10,currencyDecimalInt);
    } catch(Exception e){
        //ignore
    }
   //amount the last two digits are decimal, so convert it first.
   val = val / currencyDecimalVal;
   context.setProperty("taxamt", taxAmov);
   return val;
}

def String getItemNumber(String a, MappingContext context) {
    return context.getProperty("itemno");
}

def String getTaxAmov(String a,MappingContext context) {
    return context.getProperty("taxamt");
}

def String getMonth(String primaryDate/*, String secondaryDate*/) {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    simpleDateFormat.setLenient(false);
    Date date1 = null;
    try {
        date1 = Date.parse("yyyy-MM-dd", primaryDate);
    } catch(Exception e){
        /*try {
            date1 = Date.parse("yyyy-MM-dd", secondaryDate);
        } catch (Exception ex) {*/
            throw new Exception("Bad Date");
        /*}*/
    }
    String monthToReturn = simpleDateFormat.format(date1);
    return monthToReturn.substring(5, 7);
}

def String getResponseType(String currencyStr) {
    def intValue = (currencyStr != null && currencyStr.isInteger()) ? currencyStr.toInteger() : "2";
    return "12D"+intValue;
}

def String getNodeValue(String nodeValue){
	if (null != nodeValue && !nodeValue.trim().isEmpty()) {
        return nodeValue;
    } else {
	    return "";
    }
}

def String selectTransTypeCode(String prodCode, String matnr, String defaultTransTypeCode){
    if (!prodCode.trim().isEmpty()) {
        return prodCode;
    }
    
    // MATNR or will have exchangeTransTypeCode
    if (!matnr.trim().isEmpty()) {
        return matnr;
    }

    // above doesn't work if empty value sent in request
    if (defaultTransTypeCode != null && !defaultTransTypeCode.trim().isEmpty()) {
        return defaultTransTypeCode;
    }
    
    return "990101";
}

def String selectTransactionTypeCode(String defaultTransTypeCode, String itemNo, MappingContext context) {
    Map<String, String> ttCodeValueMap = context.getProperty("exchangeTTCodeValueMap");
    if (ttCodeValueMap.containsKey(itemNo)) {
        return ttCodeValueMap.get(itemNo);
    }

    if (defaultTransTypeCode != null && !defaultTransTypeCode.trim().isEmpty()) {
        return defaultTransTypeCode;
    }
    
    return "";
}

def String getExchangeProperty(String propertyName, MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}

def String getClientTracking(String theVersion, MappingContext context) {
    String exchangeSapVersion = getExchangeProperty("exchangeSapVersion", context);
    String exchangeServerName = getExchangeProperty("exchangeServerName", context);
    return "WK;SAPS4HC;" + exchangeSapVersion + ";v" + theVersion + ";ExternalTaxAPI;ForceUpdate;" + exchangeServerName + ";N/A;";
}

def String getDateValue(String date, int index) {
    if (index > 0) {
        return date;
    } else {
        return "";
    }
}

def void getYear1(String[] primaryDate, String[] secondaryDate, Output outputDate, MappingContext context){
    
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
	simpleDateFormat.setLenient(false);		
	int primaryDateLength = 0;
	List<String> primaryDateList = null;
	if(primaryDate != null) {
		primaryDateList = new ArrayList<String>(Arrays.asList(primaryDate));
		primaryDateList.removeAll("");
		
		
		primaryDateLength = primaryDateList.size();
	}
	int secondaryDateLength = 0;
	List<String> secondaryDateList = null;
	if(secondaryDate != null) {
		secondaryDateList = new ArrayList<String>(Arrays.asList(secondaryDate));
		secondaryDateList.removeAll("");
		secondaryDateLength = secondaryDateList.size();
	}
	Date date = null;
	try {
		if(primaryDateLength > 0){
			date = Date.parse("yyyy-MM-dd", primaryDateList.get(0));
		} else if(secondaryDateLength > 0) {
			date = Date.parse("yyyy-MM-dd", secondaryDateList.get(0));
		}
	} catch(Exception e){
			throw new Exception("Bad Date");
	}
   
   // Now we have today date or from dateStr
   String dateToReturn = simpleDateFormat.format(date);
   outputDate.addValue(dateToReturn.substring(0, 4));
}

def String notEquals(String firstValue, String secondValue) {
    String s = "true";
    BigDecimal fValue = new BigDecimal(firstValue.trim());
    BigDecimal sValue = new BigDecimal(secondValue.trim());
    if(fValue == sValue) {
        s = "false";
    } else {
        s ="true";
    }
    return s;
    
}

def String trimAndVerifyGeocodeForST(String inGeocode, String jurisdictionElementName,MappingContext context) {
	String trimmedGeo = inGeocode != null ? inGeocode.trim() : "";
	// geocode is 12 chars
	// 1st 2 chars Alpha
	// next 5 chars numbers
	// next 5 chars alphanumeric
	try {
        String jcdUnifyInd = context.getProperty("exchangeJcdUnifyInd");
        if(jcdUnifyInd != null && "X".equalsIgnoreCase(jcdUnifyInd.trim()))
        {
            //remove 3-4 chars from trimmedGeo and remove last char
            trimmedGeo = trimmedGeo.substring(0,2) + trimmedGeo.substring(4,14);
            
        }
    } catch (Exception e){
        
        throw new Exception("Tax Jurisdiction Code is not supported in external system. Invalid value for '$jurisdictionElementName' = '$inGeocode'");
    }
	def m = trimmedGeo =~ /^[a-zA-Z]{2}\d{5}[a-zA-Z0-9]{5}/;
	if (trimmedGeo.isEmpty()) {
	    if (jurisdictionElementName.equals("TXJCD_ST")) {
		    throw new Exception("Jurisdiction Code not found");
	    }
	} else if(trimmedGeo.length() != 12 || !m.find() ) {
		throw new Exception("Tax Jurisdiction Code is not supported in external system. Invalid value for '$jurisdictionElementName' = '$inGeocode'");
	}
	return trimmedGeo;
}

def String getValue(String val, String credit_ind) {
	BigDecimal value = new BigDecimal(val);
	if("1".equalsIgnoreCase(credit_ind)) {
		value = val * -1;
	} else {
		value = val;
	}
	return value;
}

def String getTaxTypeCode(String taxjlv) {
    String s = "";
    if("1".equalsIgnoreCase(taxjlv) || "2".equalsIgnoreCase(taxjlv)) {
        s = "0"+taxjlv;
    } else if ("4".equalsIgnoreCase(taxjlv)) {
        s = "03";
    } else {
        s="04";
    }
    return s;
}

def String getNegativeNormal(String inVal) {
    if(inVal == null)
        return "";
    String tVal = inVal.trim();
    if (tVal[tVal.length()-1].equals("-")) {    
        return "-" + tVal.substring(0, tVal.length()-1);
    }
    
    return tVal;
}

def String getExemptionReasonCode(String exemptReason, String externalizedExemptCode) {
    
    //Default is 12 other
    String returnExemptionReason = "12";
    if(exemptReason != null && !exemptReason.trim().isEmpty() && EXEMPT_CODE_MAP.containsKey(exemptReason.trim())) {
        returnExemptionReason = exemptReason;
    } else if(externalizedExemptCode!= null && !externalizedExemptCode.trim().isEmpty() && EXEMPT_CODE_MAP.containsKey(externalizedExemptCode.trim())) {
        returnExemptionReason = externalizedExemptCode;
    } 
    return returnExemptionReason;
}

def String getCurrencyDecimalToNumber(String currencyDecimal)
{
    int currencyDecimalToNumber = 100;
    try{
        if(null != currencyDecimal && !(currencyDecimal.trim().isEmpty())) {
            int currencyDecimalNumber = Integer.parseInt(currencyDecimal.trim());
            currencyDecimalToNumber = Math.pow(10,currencyDecimalNumber);
        }
    } catch (Exception e) {
        //ignore
    }
    return ""+currencyDecimalToNumber;
    
}
