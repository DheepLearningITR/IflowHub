import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil;
import groovy.util.slurpersupport.NodeChild;

def Message processData(Message message) {
    /* This script is to log the BP Relationship IDs that are filtered out with no FSM company. */
	
    def body = message.getBody(java.lang.String)
    def query = new XmlSlurper().parseText(body)
    def messageLog = messageLogFactory.getMessageLog(message)
	
    query.BusinessPartnerRelationshipSUITEBulkReplicateRequest.BusinessPartnerRelationshipSUITEReplicateRequestMessage.each { bpMessage ->
        bpMessage.BusinessPartnerRelationship .each { bp ->
            def BPID = bp.BusinessPartnerInternalID.text()
			def ContactID = bp.RelationshipBusinessPartnerInternalID.text()
            if (messageLog != null) {
                messageLog.addCustomHeaderProperty("FSMCompanyNotFoundForBusinessPartnerRelationWithContact", BPID + '|' +ContactID)                
            }
        }
    }
    return message
}
