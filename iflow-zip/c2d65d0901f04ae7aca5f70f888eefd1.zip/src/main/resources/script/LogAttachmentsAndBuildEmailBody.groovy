import com.sap.gateway.ip.core.customdev.util.Message
// Version 1.0
// save attachments to log and build error email body
def Message processData(Message message) {
    def map = message.getProperties()
    def headers = message.getHeaders()
    def add_to_log_property = message.getProperty("ErrorLogAttachments") ?: 'false'
    def multiCompFlag = map.get("EnableMultiCompany");
    def fsmAccountID = map.get("X-Account-ID")
    if (fsmAccountID.contains('<') || fsmAccountID == null || fsmAccountID == '')
        fsmAccountID = map.get("X-Account-Name")
    def fsmCompanyID = map.get("X-Company-ID")
    if (fsmCompanyID.contains('<') || fsmCompanyID == null || fsmCompanyID == '')
        fsmCompanyID = map.get("X-Company-Name")
        
    def exceptionmsg = map.get("exceptionmsg")
    def add_to_log = (add_to_log_property ==~ /(?i)(true|x)/)
    def email_body = ''
    def logger_MC = ''
    def headers_text = ''

    // get an exception java class instance
    def ex = map.get('CamelExceptionCaught')
    if (ex != null) {
        // fill only minimal information into email body
        email_body = "MPL ID: " + map.get("SAP_MessageProcessingLogID") + "\n" 
        email_body += "Correlation ID: " + headers.get("SAP_MplCorrelationId") + "\n" 
        email_body += "Timestamp: " + map.get("CamelCreatedTimestamp") + "\n"
        //Multi Company Scenario
        if (fsmCompanyID != null && multiCompFlag == "true")
        {
            email_body += "Business Partner replication failed to load into FSM CompanyID: " + fsmCompanyID + "\n"
            logger_MC = "Failed to load the Business Partner into FSM AccountID: " + fsmAccountID + " and CompanyID: " + fsmCompanyID +  System.lineSeparator() + "\n" 
            logger_MC += "Below are the logs" + System.lineSeparator() + "\n"
            def messageLog6 = messageLogFactory.getMessageLog(message);
            messageLog6.addCustomHeaderProperty("DataFailedtoLoad", fsmAccountID + '|' + fsmCompanyID);

        }

        exmap = ex.getProperties()
        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (ex.getClass().getCanonicalName().equals('org.apache.camel.component.ahc.AhcOperationFailedException')) {
            if (multiCompFlag == "true"){
                // save response from FSM in logger
                logger_MC += "Response Body" + System.lineSeparator()
                logger_MC += ex.getResponseBody() + System.lineSeparator() + "\n"
            }else{
                if (add_to_log) {
                   // save the http error response as a log attachment
                    def messageLog = messageLogFactory.getMessageLog(message)
                    messageLog.addAttachmentAsString('ResponseBody', ex.getResponseBody(), 'text/plain')
                }
            }
            message.setProperty('http.StatusCode', ex.getStatusCode())
            message.setProperty('http.StatusText', ex.getStatusText())
            message.setProperty('http.ResponseBody', ex.getResponseBody())
        }
        
        //log other exceptions
        if (exceptionmsg != null){
            logger_MC += "Exception" + System.lineSeparator()
            logger_MC += exceptionmsg + System.lineSeparator() + "\n"
        }
        
        if (add_to_log) {
            if (multiCompFlag == "true"){
				// add headers
                headers.each{ k, v ->
                    if (k.contains("X-") || k.startsWith("SAP_M") || k.startsWith("Camel")){
                        headers_text += "${k}: ${v}" + "\n"
                    }
                }
                // save headers in logger
                logger_MC += "Headers" + System.lineSeparator()
                logger_MC += headers_text + System.lineSeparator()
                // save Request payload to FSM in logger 
                if( map.get("RequestPayload") != null && map.get("RequestPayload") != '' ) 
                {
                    logger_MC += "Request Payload" + System.lineSeparator()
                    logger_MC += map.get("RequestPayload") + System.lineSeparator() + "\n"
                }
            }else {
                // add headers
                headers.each{ k, v -> 
                    headers_text += "${k}: ${v}" + "\n" 
                }
                // save headers as a log attachment
                def messageLog2 = messageLogFactory.getMessageLog(message)
                messageLog2.addAttachmentAsString('Headers', headers_text, 'text/plain')
                // save source payload as a log attachment
                if( map.get("OriginalPayload") != null && map.get("OriginalPayload") != '' ) {
                    def messageLog3 = messageLogFactory.getMessageLog(message)
                    messageLog3.addAttachmentAsString('OriginalPayload', map.get("OriginalPayload"), 'text/plain')
                }
                // save payload as a log attachment
                if( map.get("RequestPayload") != null && map.get("RequestPayload") != '' ) {
                    def messageLog4 = messageLogFactory.getMessageLog(message)
                    messageLog4.addAttachmentAsString('RequestPayload', map.get("RequestPayload"), 'text/plain')
                }
            }
        }
    }
    
    //log as an attachment for MultiCompany
    if (multiCompFlag == "true"){
        def loggerHeader = "ErrorLog_FSMCompanyID:" + fsmCompanyID
        def messageLog5 = messageLogFactory.getMessageLog(message)
        messageLog5.addAttachmentAsString(loggerHeader, logger_MC, 'text/plain')
    }

    message.setBody(email_body)
    return message
}