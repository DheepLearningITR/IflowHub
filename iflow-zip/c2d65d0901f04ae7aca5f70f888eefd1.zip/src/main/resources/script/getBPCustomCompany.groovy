import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.util.XmlParser
import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script is to get BP Object details*/
	
    def body = message.getBody(java.lang.String)
    def parsedXml = new XmlSlurper().parseText(body)
    def customObjects = new XmlParser().parseText("<CustomObjects></CustomObjects>")

    parsedXml.BusinessPartnerRelationshipSUITEBulkReplicateRequest.each { bpRequest ->
        //get the BP details where Custom rule type is set at the object level
		if (bpRequest.@MultiCompanyGroup.text() in ['CUSTOM', 'ATTRIBUTE']) {
		    bpRequest.BusinessPartnerRelationshipSUITEReplicateRequestMessage.each { bpMessage ->
				bpMessage.BusinessPartnerRelationship.each { bp ->
                    bp.A_BusinessPartnerType[0].to_BusinessPartnerRole[0].A_BusinessPartnerRoleType.each { role ->
                        def customObjectXml = buildCustomObjectXml(bp, role, bpRequest.@MultiCompanyGroup.text())
                        def customObjectNode = new XmlParser().parseText(customObjectXml)
                        customObjects.append(customObjectNode)
                    }
			    }
		    }
		}
    }
    
    message.setBody(XmlUtil.serialize(customObjects))
    return message
}

def String buildCustomObjectXml(bp, role, ruleType) {
    def builder = new StringBuilder()
    builder.append("<customObject>")
    builder.append("<SrvcMgmtFSMRplctnObjID>").append(bp.BusinessPartnerInternalID.text()).append("</SrvcMgmtFSMRplctnObjID>")
    builder.append("<SrvcMgmtFSMReplicationObject>BP</SrvcMgmtFSMReplicationObject>")

    if (ruleType == 'ATTRIBUTE') {
        builder.append("<SrvcMgmtFSMRplctnObjAttribute>BPROLE</SrvcMgmtFSMRplctnObjAttribute>")
        builder.append("<SrvcMgmtFSMRplctnObjAttribVal>").append(role.BusinessPartnerRole.text()).append("</SrvcMgmtFSMRplctnObjAttribVal>")
    } else {
        builder.append("<SrvcMgmtFSMRplctnObjAttribute></SrvcMgmtFSMRplctnObjAttribute><SrvcMgmtFSMRplctnObjAttribVal></SrvcMgmtFSMRplctnObjAttribVal>")
    }

    builder.append("</customObject>")
    return builder.toString()
}


