/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-IN/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-IN/index.html */

import com.sap.gateway.ip.core.customdev.util.Message;
import java.time.Instant
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

def Message processData(Message message) {
    final String s4CommSystem = message.getProperty("S4CommSystem")
    final String v2CommSystem = message.getProperty("V2CommSystem")
    
    def bpResponseXml = new XmlParser().parseText(message.getBody(String.class))
    def bpCategoryMap = new HashMap()

    bpResponseXml.batchQueryPartResponse.each{
        it -> bpCategoryMap.put(it.body.A_BusinessPartner.A_BusinessPartnerType.BusinessPartner.text(),it.body.A_BusinessPartner.A_BusinessPartnerType.BusinessPartnerCategory.text())
    }
    
    def xmlBody = message.getProperty("OriginalPayload");
    def xmlObject = new XmlParser().parseText(xmlBody)
    
    Instant currentTimestamp = Instant.now()
    
    def rootOutputXml, bodyHeaderNode, messageRequestsNode, bodyNode, tempNode, itemTempNode
    String bpCategory
    boolean isMainRefObj
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    
    //building V2 connector message header data
    def messageHeaderNode = new NodeBuilder().messageHeader{
        id(UUID.randomUUID())
        senderCommunicationSystemDisplayId(s4CommSystem)
        receiverCommunicationSystemDisplayId(v2CommSystem)
        creationDateTime(currentTimestamp)
    }
    
    rootOutputXml= new NodeBuilder().root{}
    rootOutputXml.append(messageHeaderNode)
    
    for(def s4Quote : xmlObject){
        //building cns xml body header data
        bodyHeaderNode = new NodeBuilder().messageHeader{
            messageEntityName("sap.crm.servicequotationservice.entity.serviceQuotationReplicationMessageIn")
            actionCode("SAVE")
            id(UUID.randomUUID())
        }
        
        messageRequestsNode = new NodeBuilder().messageRequests{}
        messageRequestsNode.append(bodyHeaderNode)
        bodyNode = new NodeBuilder().body{
            id(s4Quote.ServiceQuotationUUID.text())
            displayId(s4Quote.ServiceQuotation.text())
            description(s4Quote.ServiceQuotationDescription.text())
            serviceQuotationType(s4Quote.ServiceQuotationType.text())
            documentCurrency(s4Quote.TransactionCurrency.text())
            businessArea{
                salesOrganisationId(s4Quote.SalesOrganization.text())
                distributionChannel(s4Quote.DistributionChannel.text())
                division(s4Quote.Division.text())
                salesGroupId(s4Quote.SalesGroup.text())
                salesOfficeId(s4Quote.SalesOffice.text())
            }
            timePoints{
                requestedStartOn(s4Quote.RequestedServiceStartDateTime.text()+"Z")
                requestedEndOn(s4Quote.RequestedServiceStartDateTime.text()+"Z")
                validFrom(s4Quote.SrvcQtanValidityStartDateTime == null ? null : LocalDateTime.parse(s4Quote.SrvcQtanValidityStartDateTime.text(), dateTimeFormatter).toInstant(ZoneOffset.UTC).toString())
                validTo(s4Quote.SrvcQtanValidityEndDateTime == null ? null : LocalDateTime.parse(s4Quote.SrvcQtanValidityEndDateTime.text(), dateTimeFormatter).toInstant(ZoneOffset.UTC).toString())
            }
            transactionAmount{
                grossAmount{
                    content(s4Quote.ServiceDocGrossAmount.text())
                    currencyCode(s4Quote.TransactionCurrency.text())
                }
                netAmount{
                    content(s4Quote.ServiceDocNetAmount.text())
                    currencyCode(s4Quote.TransactionCurrency.text())
                }
                taxAmount{
                    content(s4Quote.ServiceDocTaxAmount.text())
                    currencyCode(s4Quote.TransactionCurrency.text())
                }
            }
        }
        
        if("X".equals(s4Quote.ServiceQuotationIsAccepted.text())){
            tempNode = new NodeBuilder().acceptanceStatus("ACCEPTED")
            bodyNode.append(tempNode)
            
            tempNode = new NodeBuilder().lifeCycleStatus("COMPLETED")
            bodyNode.append(tempNode)
        }else if("X".equals(s4Quote.ServiceQuotationIsRejected.text())){
            tempNode = new NodeBuilder().acceptanceStatus("REJECTED")
            bodyNode.append(tempNode)
            
            tempNode = new NodeBuilder().rejectionReason(s4Quote.SrvcQuotationRejectionReason.text())
            bodyNode.append(tempNode)
            
            tempNode = new NodeBuilder().lifeCycleStatus("COMPLETED")
            bodyNode.append(tempNode)
        }else {
            tempNode = new NodeBuilder().lifeCycleStatus("RELEASED")
            bodyNode.append(tempNode)
        }
        
        if(notEmpty(s4Quote.SoldToParty.text())){
          bpCategory = bpCategoryMap.get(s4Quote.SoldToParty.text())
          switch(bpCategory){
            case "1":
              tempNode = new NodeBuilder().individualCustomer{
                displayId(s4Quote.SoldToParty.text())
              }
              bodyNode.append(tempNode)
              break
            case "2":
              tempNode = new NodeBuilder().account{
                displayId(s4Quote.SoldToParty.text())
              }
              bodyNode.append(tempNode)
              break
          }
        }
    
        if(notEmpty(s4Quote.ShipToParty.text())){
          bpCategory = bpCategoryMap.get(s4Quote.ShipToParty.text())
          switch(bpCategory){
            case "1":
              tempNode = new NodeBuilder().shipToIndividualCustomer{
                displayId(s4Quote.ShipToParty.text())
              }
              bodyNode.append(tempNode)
              break
            case "2":
              tempNode = new NodeBuilder().shipToAccount{
                displayId(s4Quote.ShipToParty.text())
              }
              bodyNode.append(tempNode)
              break
          }
        }
    
        if(notEmpty(s4Quote.Contact.text())){
          tempNode = new NodeBuilder().contact{
            displayId(s4Quote.Contact.text())
          }
        }
        
        if(s4Quote.to_PersonResponsible.'*'.size() > 0){
          tempNode = new NodeBuilder().owner{
            displayId(s4Quote.to_PersonResponsible.'*'[0].PersonResponsible.text())
          }
          bodyNode.append(tempNode)
        }
        
        for(def refObj: s4Quote.to_ReferenceObject.'*'){
            isMainRefObj = false
            if(refObj.SrvcRefObjIsMainObject.text() == "true"){
                isMainRefObj = true  
            }
            if(refObj.ServiceReferenceEquipment.text()){
                tempNode = new NodeBuilder().registeredProducts{
                    displayId(refObj.ServiceReferenceEquipment.text())
                    isMain(isMainRefObj)
                }
                bodyNode.append(tempNode)
            }else{
                tempNode = new NodeBuilder().functionLocations{
                    displayId(refObj.ServiceRefFunctionalLocation.text())
                    isMain(isMainRefObj)
                }
                bodyNode.append(tempNode)
            }
        }
        
        for(def item: s4Quote.to_Item.'*'){
          itemTempNode = new NodeBuilder().items{
            id(item.ServiceQuotationItem.text())
            receiverLineNumber(item.ServiceQtanItemExtReference.text())
            description(item.ServiceQtanItemDescription.text())
            itemCategory(item.ServiceDocItemCategory.text())
            product{
              displayId(item.Product.text())
            }
            quantity{
              content(item.Quantity.text())
              unit(item.QuantityUnit.text())
            }
            serviceDuration{
              content(item.ServiceDuration.text())
              unit(item.ServiceDurationUnit.text())
            }
    
          }
    
          if("X".equals(item.ServiceQuotationItemIsAccepted.text())){
            tempNode = new NodeBuilder().acceptanceStatus("ACCEPTED")
            itemTempNode.append(tempNode)
    
            tempNode = new NodeBuilder().itemLifeCycleStatus("COMPLETED")
            itemTempNode.append(tempNode)
          }else if("X".equals(item.ServiceQuotationItemIsRejected.text())){
            tempNode = new NodeBuilder().acceptanceStatus("REJECTED")
            itemTempNode.append(tempNode)
    
            tempNode = new NodeBuilder().rejectionReason(item.SrvcQtanItmRejectionReason.text())
            itemTempNode.append(tempNode)
    
            tempNode = new NodeBuilder().itemLifeCycleStatus("COMPLETED")
            itemTempNode.append(tempNode)
          }else {
            tempNode = new NodeBuilder().lifeCycleStatus("RELEASED")
            itemTempNode.append(tempNode)
          }
          
        for(def refObj: item.to_ReferenceObject.'*'){
            isMainRefObj = false
            if(refObj.SrvcRefObjIsMainObject.text() == "true"){
                isMainRefObj = true  
            }
            if(refObj.ServiceReferenceEquipment.text()){
                tempNode = new NodeBuilder().registeredProducts{
                    displayId(refObj.ServiceReferenceEquipment.text())
                    isMain(isMainRefObj)
                }
                itemTempNode.append(tempNode)
            }else{
                tempNode = new NodeBuilder().functionLocations{
                    displayId(refObj.ServiceRefFunctionalLocation.text())
                    isMain(isMainRefObj)
                }
                itemTempNode.append(tempNode)
            }
        }
    
          bodyNode.append(itemTempNode)
        }
        
        
        messageRequestsNode.append(bodyNode)
        rootOutputXml.append(messageRequestsNode)
    }
    
    StringWriter stringWriter = new StringWriter()
    XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
    nodePrinter.setPreserveWhitespace(true)
    nodePrinter.print(rootOutputXml)    
    
    message.setBody(stringWriter.toString())
    return message;
}

private boolean notEmpty(String fieldValue){
    return !"".equals(fieldValue)
}