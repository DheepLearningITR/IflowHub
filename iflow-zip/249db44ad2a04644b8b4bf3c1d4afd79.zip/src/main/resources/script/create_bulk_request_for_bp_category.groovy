import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message){
    
    def xmlBody = message.getBody(String.class);
    def xmlObject = new XmlParser().parseText(xmlBody)
    
    if(xmlObject.'*'.size() == 0){
        message.setProperty("NoDataFetched", "X")
        return message
    }
    message.setProperty("OriginalPayload", xmlBody)
    
    def partiesSet = new HashSet() 
    
    // Loop and get list of partners involded in a Set
    for(def s4Quote : xmlObject){
        addToSet(partiesSet, s4Quote.SoldToParty.text())
        addToSet(partiesSet, s4Quote.ShipToParty.text())
    }
    
    // Form a batch query to get Business Partner from S4 
    Node batch_payload = new NodeBuilder().batchParts{}
    def tempNode
    
    partiesSet.each{
        party ->
        tempNode = new NodeBuilder().batchQueryPart{
            uri("A_BusinessPartner('" + party + "')")
        }
        batch_payload.append(tempNode)
    }
    
    message.setProperty("SAP_BatchLineSeparator","CRLF")
    message.setBody(groovy.xml.XmlUtil.serialize(batch_payload))
    return message
}

private void addToSet(Set partiesSet, String partyId){
    if(!"".equals(partyId)){
        partiesSet.add(partyId)
    }
}