import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Map;


import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Callable;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.cxf.binding.soap.SoapFault;
import org.w3c.dom.Element;

def Message handleException(Message message) {
	
    def map = message.getProperties();
	def ex = map.get("CamelExceptionCaught");
	
	if (ex != null){
	    
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
            //Error from Tax Authorities (external Error)
            message.setProperty("internal_error", "false");
            message.setBody(ex.getResponseBody());
        }
        else if (ex instanceof java.io.IOException){
            //It's not exactly an external or internal error. The error exists on SDI side but the error will be thrown on our side
            //It will be treated here as internal error because the ex.getResponseBody() not available in ioexception class
            //A custom error message will be used
            message.setProperty("internal_error", "true");
            message.setProperty("internal_error_code", map.get("SAP_ErrorModelStepID"));
            message.setProperty("internal_error_message", ex.getMessage());
        }
        else if (ex instanceof org.apache.cxf.interceptor.Fault){
            //Internal Error
            message.setProperty("internal_error", "true");
            message.setProperty("internal_error_code", ex.getFaultCode());
            message.setProperty("internal_error_message", ex.getMessage());
        }
        else{
            //internal Error
             message.setProperty("internal_error", "true");
            message.setProperty("internal_error_code", map.get("SAP_ErrorModelStepID"));
            message.setProperty("internal_error_message", ex.getMessage());
        }
	}
    
    
    
    return message;
}
