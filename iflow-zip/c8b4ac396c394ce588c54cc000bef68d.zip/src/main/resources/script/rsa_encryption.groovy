
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;


import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPublicKeySpec;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;


import org.apache.commons.codec.binary.Base64;


def Message processData(Message message) {
	
    //Properties
	def map = message.getProperties();
	//String aes_key = "1234567890123458";
	String aes_key = map.get("aes_symmetrical_key"); //"1234567890123456";
	                                                 //${date:now:yyyyMMddHHmmss}
	                                                   // 20151119165600
    String password = map.get("password");
    
    def nonce_enc = encode_rsa_base64(aes_key);
    
    String key = aes_key; // 128 bit key
    String password_enc = encrypt_aes_ecb_pkcs5_base64(aes_key, password);
    
    
    //2013-01-01T19: 20: 30.45Z
    TimeZone tz = TimeZone.getTimeZone("UTC");
    DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH: mm: ss.SSS'Z'");
    df.setTimeZone(tz);
    String nowAsISO = df.format(new Date());
    String now_enc = encrypt_aes_ecb_pkcs5_base64(aes_key, nowAsISO);
    
    
    message.setProperty("nonce", nonce_enc);
    message.setProperty("password", password_enc);
    message.setProperty("created", now_enc);
    
    return message;
}


//intentionally spoiling modulus value to simulate failing call!
def String encode_rsa_base64(String text) {
//public key valid till April 15th, 2027
    BigInteger modulus = new BigInteger("C4B05FF29E933C2D8A2BB5CBE6AEBCD50CDF6F5E7EABA99353C355160005B5849B1B737936232617877D884CDD6F1530BA797AE46A4870C7D6F0757AD486B64AE62022358CBFC6B45E413CD99BB80C8FADF0268F5EAC9A7C08DD92DED7547611475A8D3B4125E11FE565FFBFED0C17CE41500E6DD960BA280FF3522384F4182EE5EAE50DD6EF84C448A1A2CFFC7E23FF89B7923E211A2416A44C5855D92EA49A2EA888B1337C1FFE310DAB6E8CF6E023AA7404B025F3AF8CD77D0CDC9CF7C37A3AFBA91272919CC93BF32A76584C67D43AF029B6FC4DBAED3FF0C8335C8088F8CAA42CA8C55F8F72F43D6694AC0DFB0153E62D87D6ADEA9F53A572094E2FD40DD72377A8039D25DA2DA5C15216C1639FB88E9FA10374AC9475BE2D7A7B08878363BECC256CB4E7FD631019E28CF105B856D9A0C879445DFB0F8C03BE04E28CF8E89B1D984418462C187DBCE389B3DE8519A18E2E6C1A6F89FEB3BE2F30BFA48F515464C48545FD3281867917DBCA40EAD08D1A8B469E73703B42B72F7A588EA79018581244FEA5C4D82FC9C50EEF9BB8E650E552DB6C2ED455BD85AFE1EA761247134E9B9403BA806F6E39D15D4CDD0626970543F2AD80F35CBC2B32C1370B9C513C1D67BA22ED48B5A808EF39F4B41D964ED1132E1FB6ED9CD07F807FADAC5BFE50713930A50300BFFC8AFD5F7DB71C0D1277D24A8A07655F8A7080CC732339", 16 );

//public key valid till June 28th, 2025
    //BigInteger modulus = new BigInteger("E7996C4C19DEA6E2B98401044E8D3ABB15C4E78BDF45927E67767886E751769571CBA0512221FB98139D7B4CC1AAB1F13F6C22BE607348D3679DE1FE74BB06008AB66D00B0C22A06DCE6E5928A0AF95C213CBB8185957941729FC8E0691A0461575BBD574B8293FDD92E4681BCED6C1991A793F5C398694FFB2BC13879548940B2D146EEAFD52DE1F667038C68310BAA0295943ADA51C014793AED417C445B28F544830BD6371007225DA5EFD1ECDCEB65A77272A8E7D6D600048ED894D7584D6E1F52AFCE1BBF70C12C566D4DDFC4BD094A4008C3714D42E43FBDE29E3942259C3C075A7F4EFBBF27EC770B5F9DF7F884F28853E1DF143C16DCFFBC208EA45F", 16);
//public key valid till June 23rd, 2023
//    BigInteger modulus = new BigInteger("838B7022396BE72724998A55BC691CCB1B77AEABE8405327FACE1FF3D6459C52444AFD26CBFA83895D5383C1034F11DCC44508A8CF4447CFA29D82677F1A2873386BDF9CE6A3255B88D919CBB391B4565B303D6A0ED54BF9A049BC0295E7473C6706E457E692CEF636A75E48D6EDAB10A8B1155AACC30AA8D241DB4A055F096FB1F71313D500A1964F5E603109E7FBA0243DDEDEAD585829D5B06C6D2E249CF0C23928976505B77696C84E5C2D362D336BCA30C48FAD6CE50CFC014684B6B2BC0715C7D16401E618D506604B284DA43A1E8BEA249E347827260DD1CAB8DA575C330493DBBA8F6BFC7095B9B7D8F8CA84E38E27882D5DE2EF4303C5A7E381282B", 16);
//public key valid till July 23rd, 2020
//    BigInteger modulus = new BigInteger("AC166BED9A8594727C3ED4C9A578D39BBBA2943C3674121B842958521D475CC63BD8DE8AB78FC4B3E655D7690445F8F3238172A916FB4696FB9C3D201C341F7708ECDC305921428CE53C07FDE01250C0AEFE197D45FCD1BCEB5712AD827D2038747BFF307F90260EAF6D53B4FA51E5BB58F3C9B7BB7C54B19075ADADF769B1A70944FFAD473F6A436192F0F6EBEC7E7535D187500B26D40EF80D8254C9CDCDE2D31DE2FD47D98540B03AA7991A8515AB0CBF26F9B738F0B6D02505779C71BE8F8451BA3F1FCD4E3614B7CEF0432C281A1DA1A8E1B91F0CB1ED14A27452AF5C24109D5015C40C0186A82082A19FDDE02E8ED4D931EFA97493ED33CC7E3FEBEB17", 16);
    BigInteger pubExp = new BigInteger("010001", 16);
//   BigInteger pubExp = new BigInteger("65537", 16);
    
    KeyFactory keyFactory = KeyFactory.getInstance("RSA");
    RSAPublicKeySpec pubKeySpec = new RSAPublicKeySpec(modulus, pubExp);
    RSAPublicKey key = (RSAPublicKey) keyFactory.generatePublic(pubKeySpec);
    
    String result = null;
    
    byte[] cipherText = null;
    final Cipher cipher = Cipher.getInstance("RSA");
    cipher.init(Cipher.ENCRYPT_MODE, key); //key.getPublic()
    byte[] encrypted = cipher.doFinal(text.getBytes());
    result = Base64.encodeBase64String(encrypted);
    return result;
}


   
	String encrypt_aes_ecb_pkcs5_base64(String key,  String value) {
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
            
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
            byte[] encrypted = cipher.doFinal(value.getBytes());
            System.out.println("encrypted string:"
                    + Base64.encodeBase64String(encrypted));
            return Base64.encodeBase64String(encrypted);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
