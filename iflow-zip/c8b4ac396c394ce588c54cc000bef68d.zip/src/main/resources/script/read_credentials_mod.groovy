import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

def Message processData(Message message) {

	//Get TaxCode
	def map = message.getProperties();
	def value;
	
	if (map.get("TaxCode") != null && map.get("TaxCode") != ""){
	    value = map.get("TaxCode") + "_edocportugalcredentials";
	}
	else{
	    throw new IllegalStateException("No TaxCode found");
	}
	def service;
	def credential;
	
    try{
        service = ITApiFactory.getApi(SecureStoreService.class, null);
        credential = service.getUserCredential(value);
        
        if (credential == null){
            throw new IllegalStateException("No credential found for alias "+value);
        }
    }
    catch (java.lang.Exception error){
        throw new IllegalStateException("No credential found for alias "+value);
    }
   
    String userName = credential.getUsername();
    String password = new String(credential.getPassword());
    
    
    message.setProperty("username", userName);
	message.setProperty("password", password);
    
    password = null;
    
	return message;
}

