import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {

    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)
    def accessToken = json.access_token
    message.setHeader("Authorization", "Bearer ${accessToken}")

    return message
}
