import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();
       message.setBody(body + "Body is modified");
       
      XmlSlurper slurper = new XmlSlurper()
      Map quotePayload = slurper.parseText(body)
      
       //Properties 
       def map = message.getProperties();
       def digitAfterDecimal = map.digitAfterDecimal;
       
       

       return message;
}