import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    //Body 
       def body = message.getBody();
       String password;
       String Username;
       String ClientID
       String _output="";
       def service = ITApiFactory.getApi(SecureStoreService.class, null);
       def UserCredentials = message.getProperty("SNOW_User_Credentials")
       def ClientSecret =  message.getProperty("SNOW_ClientSecret");
       
       //Name of secure parameter
       def credential_password = service.getUserCredential(UserCredentials); 
        if (credential_password == null)
        { throw new IllegalStateException("No credential found for alias '" + UserCredentials+"'");             
        }
        else{
            password = new String(credential_password.getPassword());
            Username =  new String(credential_password.getUsername());
            }

        //store it in property which can be used in later stage of your integration process.
        message.setProperty("UserPassword", password);
        message.setProperty("Username",Username);
       
         
        String clientsecret;
       def credential_secret = service.getUserCredential(ClientSecret); 
        if (credential_secret == null)
        { throw new IllegalStateException("No credential found for alias '" + ClientSecret+"'");             
        }
        else{
            ClientID = new String(credential_secret.getUsername());
            clientsecret = new String(credential_secret.getPassword());
            }

        //store it in property which can be used in later stage of your integration process.
        message.setProperty("ClientID",ClientID);
        message.setProperty("ClientSecret", clientsecret);
       return message;
}
