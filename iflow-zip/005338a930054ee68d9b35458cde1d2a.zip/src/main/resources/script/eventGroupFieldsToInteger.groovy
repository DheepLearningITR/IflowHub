import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def payload = message.getBody(String)    
    def json = new JsonSlurper().parseText(payload)
    def fieldsToConvert = ['sequence', 'totalMessageCount']
    
    if (json.header.eventGroup){
        fieldsToConvert.each { f -> json.header.eventGroup[f] = json.header.eventGroup[f].toInteger() }
    }

    message.setBody(JsonOutput.toJson(json))

    return message

}