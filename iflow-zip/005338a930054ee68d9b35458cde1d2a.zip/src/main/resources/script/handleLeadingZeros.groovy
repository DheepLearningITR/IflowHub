import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper;

def isNumeric(String input) {
    return input.matches("0\\d+|-?\\d+")
}

// Function to add or remove leading zeros for a numeric field
def modifyNumericField(String input, boolean removeZeros) {
    if (removeZeros) {
        // Removing zeros
        def intValue = Integer.parseInt(input)
        def formattedValue = intValue.toString()
        return formattedValue
    }
}

Map transformToJson(Message message) {

    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    return json

}

void updateMessageBody(Message message, Map messageBody) {

    def messageBodyJson = JsonOutput.toJson(messageBody);
    def prettyMessageBody = JsonOutput.prettyPrint(messageBodyJson);

    message.setBody(prettyMessageBody)

}

def handleZerosPathTree(List pathTokens, Map tree, boolean removeZeros) {

    def FIRST_TOKEN = 0
    def REMAINING_TOKENS = 1..-1

    def token = pathTokens[FIRST_TOKEN]

    if (tree[token] == null) {
        return
    }

    if (pathTokens.size() == 1) {

        if (isNumeric(tree[token])) {
            tree[token] = modifyNumericField(tree[token], removeZeros)
        }

    } else {

        def tmpValueAtPath = tree[token]
        def newPathTokens = pathTokens[REMAINING_TOKENS]

        if (tmpValueAtPath instanceof List) {
            tmpValueAtPath.each { arrayElement ->
                if (arrayElement instanceof Map) {
                    handleZerosPathTree(newPathTokens, arrayElement, removeZeros)
                }
            }
        } else if (tmpValueAtPath instanceof Map) {
            handleZerosPathTree(newPathTokens, tmpValueAtPath, removeZeros)
        }
    }
}

Message handleZerosPaths(Message message) {

    def FIELD_DELIMITER = ";"

    def messageJson = transformToJson(message)
    def leadingZerosPaths = message.getProperty("LeadingZerosPaths")
    def removeZeros = true;

    leadingZerosPaths.split(FIELD_DELIMITER).each { path ->
        def PATH_DELIMITER = "/"
        def pathTokens = path.tokenize(PATH_DELIMITER)
        handleZerosPathTree(pathTokens, messageJson, removeZeros)
    }

    updateMessageBody(message, messageJson)

    return message

}