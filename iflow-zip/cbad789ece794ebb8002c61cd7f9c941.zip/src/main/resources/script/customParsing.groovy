import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String customGetClientNumber(String storedUsername) {
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential(storedUsername);
    if (credential == null) {
        throw new IllegalStateException("No credential found for alias '$storedUsername'");
    }
    return credential.getUsername();
}

def String customGetVKey (String storedUsername) {
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential(storedUsername);
    if (credential == null) {
        throw new IllegalStateException("No credential found for alias '$storedUsername'");
    }
    return new String(credential.getPassword());
}

def String stateMapping (String jurisdictionCode) {
    def stateMap = 
    ["01":"AL",
     "02":"AK"];
     
    def stateCode = jurisdictionCode.substring(2,4);
    def stateAbr = stateMap["01"];
    def result = jurisdictionCode.substring(0,2) + stateAbr + jurisdictionCode.substring(4, jurisdictionCode.length() -1)
    return result;
}

def String getExchangeProperty(String propertyName, MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}