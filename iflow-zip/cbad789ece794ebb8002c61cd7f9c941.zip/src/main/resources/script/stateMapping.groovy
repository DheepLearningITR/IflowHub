import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String getExchangeProperty(String propertyName, MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}

def String stateMapping (String jurisdictionCode, MappingContext context) {
    def stateMap = 
    ["00":"US",
     "01":"AL",
     "02":"AK",
     //"03":"AL",
     "04":"AZ",
     "05":"AR",
     "06":"CA",
     //"07":"AL",
     "08":"CO",
     "09":"CT",
     "10":"DE",
     "11":"DC",
     "12":"FL",
     "13":"GA",
     //"14":"AK"
     "15":"HI",
     "16":"ID",
     "17":"IL",
     "18":"IN",
     "19":"IA",
     "20":"KS",
     "21":"KY",
     "22":"LA",
     "23":"ME",
     "24":"MD",
     "25":"MA",
     "26":"MI",
     "27":"MN",
     "28":"MS",
     "29":"MO",
     "30":"MT",
     "31":"NE",
     "32":"NV",
     "33":"NH",
     "34":"NJ",
     "35":"NM",
     "36":"NY",
     "37":"NC",
     "38":"ND",
     "39":"OH",
     "40":"OK",
     "41":"OR",
     "42":"PA",
     //"43":"NV",
     "44":"RI",
     "45":"SC",
     "46":"SD",
     "47":"TN",
     "48":"TX",
     "49":"UT",
     "50":"VT",
     "51":"VA",
     //"52":"TX",
     "53":"WA",
     "54":"WV",
     "55":"WI",
     "56":"WY",
     "60":"AS",
     "64":"FM",
     "66":"GU",
     "68":"MH",
     "69":"MP",
     "70":"PW",
     "72":"PR",
     "78":"VI",
     "96":"ZZ",
     "97":"ZZ",
     "98":"ZZ"];
     
     
    String jcdUnifyIndicator = getExchangeProperty("exchangejcdunifyind", context);
    def countryCode = jurisdictionCode.substring(0,2);
    
    if(jcdUnifyIndicator != null && "X".equalsIgnoreCase(jcdUnifyIndicator) && ("US".equalsIgnoreCase(countryCode) || "ZZ".equalsIgnoreCase(countryCode))) {
        
        if ("ZZ".equalsIgnoreCase(countryCode)) {
            return "US" + jurisdictionCode;
        }
        
        def stateCode = jurisdictionCode.substring(2,4);
        def stateAbr = stateMap[stateCode];
        if (stateAbr != null) {
            return jurisdictionCode.substring(0,2) + stateAbr + jurisdictionCode.substring(2) + "-";
        }
    }
     
    return jurisdictionCode;
}