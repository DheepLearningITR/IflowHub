/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.commons.lang3.*;

def Message formatRCId(Message message) {
	//Properties  
	def map = message.getProperties();
	def value = map.get("BPNumberInRC");
	value = StringUtils.leftPad(value, 10, '0');
	message.setProperty("BPNumberInRC", value);
	return message;
}

def Message formatS4CustomerID(Message message) {
	def map = message.getProperties();
	def value = map.get("CustomerIdInS4System");
	value = StringUtils.trim(value);
	if (StringUtils.containsOnly(value, "1234567890")) {
		value = StringUtils.leftPad(value, 10, '0');
	} else {
		value = StringUtils.rightPad(value, 10, ' ');
	}
	message.setProperty("S4CustomerIDOnDatabase", value);
	return message;
}
