import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData_S4_Confirm_Request(Message message) {
	def map = message.getProperties();
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
		def body = message.getBody(java.lang.String) as String;
		
		def s4Id = map.get("BPIdInS4System");
		def rcId = map.get("BPNumberInRC");
		def bpType = map.get("BPType");
		
		bpType = bpType.substring(0, bpType.length() - 1);
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString("SB(" + rcId + ")_S4(" + s4Id + ")_" + bpType + "_externalRef_req", body, "text/json");
		}
	}
	return message;
}

def Message processData_S4_Confirm_Failed(Message message) {
	def map = message.getProperties();
	def property_ENABLE_ERROR_ONLY_LOGGING = map.get("EnableErrorLogOnly");
	def property_ENABLE_MPL_LOGGING = map.get("EnableAllLog");
	if (property_ENABLE_MPL_LOGGING.toUpperCase().equals("TRUE") && (!property_ENABLE_ERROR_ONLY_LOGGING.toUpperCase().equals("TRUE"))  ) {
	def body = message.getBody(java.lang.String) as String;
	def businessPartner = new XmlSlurper().parseText(body);
	def rcBusinessPartnerId = businessPartner.BusinessPartnerSUITEReplicateConfirmationMessage.BusinessPartner.InternalID as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	if (messageLog != null) {
			messageLog.addAttachmentAsString("SB(" + rcBusinessPartnerId + ")_skip_failed_confirm", body, "text/xml");
		}
	}
	return message;
}