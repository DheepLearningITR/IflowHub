import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


def Message prepareReceiverPayload(Message message) {

  def body = message.getBody(java.io.Reader)
  def soapResponse = new XmlSlurper().parse(body)

  def responsePayload = convertToJSON(soapResponse, message)
  message.setBody(responsePayload)

  return message

}

def convertToJSON(xml, message) {
  def properties = message.getProperties()
  def senderBusinessSystem = properties.get("SenderBusinessSystem")
  def receiverBusinessSystem = properties.get("ReceiverBusinessSystem")
  def messageEntityName = properties.get("MessageEntityName")
  def initialLoad = properties.get("InitialLoad")

  def jsonBuilder = new JsonBuilder()

  def codeList = []
  xml.ET_CODE_LIST.item.each {
    item ->
      def code = item.CODE.text()
    def descriptions = item.TEXTS.item.collect {
      [
        languageCode: it.LANGUAGE.text(),
        content: it.TEXT.text()
      ]
    }

    def resultMessage = [
      messageHeader: ["messageEntityName": messageEntityName, "actionCode": "SAVE", "id": generateRandomGUID()],
      body: [code: code, descriptions: descriptions]
    ]

    codeList.add(resultMessage)
  }
  
    if ('true'.equals(initialLoad)) {
        def cnsCodes = message.getHeader("ReceiverCodes", java.io.Reader)
        def cnsCodeList = new groovy.json.JsonSlurper().parse(cnsCodes).value
        def erpCodes = xml.ET_CODE_LIST.item.collect { it.CODE.text() }

    def codesTobeDeleted = cnsCodeList.findAll {
      cnsCode ->
        !erpCodes.any {
          it == cnsCode.code
        }
    }.collect {it}

    // Add message requests for each item in codesTobeDeleted with action code DELETE
    codesTobeDeleted.each {
      item ->
        def inactiveMessageHeader = ["messageEntityName": "sap.crm.md.integrationmetadataservice.entity.productTypeS4ReplicationMessageIn", "actionCode": "SAVE", "id": generateRandomGUID()]
        def inactiveBody = ["code": item.code, "isActive": false, "usage":item.usage, "descriptions": item.descriptions]
        
       codeList << ["messageHeader": inactiveMessageHeader, "body": inactiveBody]
    }
  }
  def creationDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))
  jsonBuilder {
    messageHeader("id": generateRandomGUID(), receiverCommunicationSystemDisplayId: receiverBusinessSystem, senderCommunicationSystemDisplayId: senderBusinessSystem, "creationDateTime": "$creationDateTime")
    messageRequests(codeList)
  }

  return JsonOutput.toJson(jsonBuilder.content)
}

def generateRandomGUID() {
  return UUID.randomUUID().toString()
}