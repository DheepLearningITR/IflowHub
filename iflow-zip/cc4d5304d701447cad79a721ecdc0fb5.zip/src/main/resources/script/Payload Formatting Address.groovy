import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

// recursive method for parsing whole json
def formatDeep(def node){
    node.each{ subnode ->
        
        // case 1: format an array containing an empty string to an empty array
        if (subnode.value == [""]){
            subnode.value = [];
            
        // case 2: format empty string and empty objects to null values
        // FSM interprets null values as a deletion
        } else if ((subnode.value instanceof Map && subnode.value.isEmpty()) || subnode.value == ""){
            subnode.value = null;
            
        // if the current node has subnodes (that means, it is a map or a list)
        //-> go further down in the tree and repeat the logic
        } else if (subnode.value instanceof Map || subnode.value instanceof List) {
            formatDeep(subnode.value);
        } else if (subnode instanceof Map) {
            formatDeep(subnode);
        }
    }
}

def Message processData(Message message){
    def body = message.getBody(java.lang.String) as String;
    body = body.replace("{\"@nil\":\"true\"}","null");
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body); 
    def String newJson = "[ ]";
    def newJsonObject = jsonParser.parseText(newJson);
    jsonObject.MultiAddress.Address.each { Multiadd->
        Multiadd.each{ Singleadd->
            newJsonObject.add(Singleadd);
        }
    }
    
    formatDeep(newJsonObject);
    message.setBody(JsonOutput.toJson(newJsonObject));
    message.setProperty("RequestPayload", JsonOutput.toJson(newJsonObject));
    
    // To access FSM, company and account are required -- either their name or their ID.
    // If the IDs are configured, they are used; otherwise, the names are used.
    def accountCompany = '';
    def accountID = message.getProperty('X-Account-ID');
    def accountName = message.getProperty('X-Account-Name');
    def companyID = message.getProperty('X-Company-ID');
    def companyName = message.getProperty('X-Company-Name');
    

    if (accountID == null || accountID == '' || accountID == '<FSM_Account_ID>' || companyID == null || companyID == '' || companyID == '<FSM_Company_ID>') {
        accountCompany = 'account='+accountName+'&company='+companyName+'&';
        message.setHeader('X-Account-Name', accountName);
        message.setHeader('X-Company-Name', companyName);
    } else {
        accountCompanyUser = '';
        message.setHeader('X-Account-ID', accountID);
        message.setHeader('X-Company-ID', companyID);
    }
    message.setProperty('AccountCompany', accountCompany);
    return message;
}