import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {

    def body = message.getBody();
    
    def headers = message.getHeaders();

    def properties = message.getProperties();
    
    def jsonSlurper = new JsonSlurper();
    def dbResult = jsonSlurper.parse(body);
    
    def hasResults = '0';
    
    if (dbResult && dbResult.SelectStatement_response && dbResult.SelectStatement_response.row) {
        hasResults = '1';
        message.setProperty("count", 0);
        message.setProperty("totalResult", dbResult.SelectStatement_response.row.size);
        message.setProperty("resultRows", dbResult.SelectStatement_response.row);
    }
    
    message.setProperty("hasResults", hasResults);

    return message;
}