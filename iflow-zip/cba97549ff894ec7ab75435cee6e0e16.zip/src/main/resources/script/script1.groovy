import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;


def Message processData(Message message) {

    def body = message.getBody();

    def headers = message.getHeaders();

    def properties = message.getProperties();

    // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    def db_schema = properties.get('Database_Schema_Name');
    
    sqlStatement.root {
        sqlStatement.SelectStatement {
            sqlStatement.app_sourcing_events(action: 'SELECT') {
                sqlStatement.table(db_schema + '.APP_SOURCING_EVENTS')
                sqlStatement.access {
                    sqlStatement.INTERNAL_ID()
                }
                sqlStatement.key {
                    sqlStatement.STEP_FLOW('PROJECT_USERS')
                }
            }
        }
    };
    
    message.setBody(writer.toString());

    return message;
}