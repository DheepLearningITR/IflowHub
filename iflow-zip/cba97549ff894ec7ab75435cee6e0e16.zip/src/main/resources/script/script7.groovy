import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

    def body = message.getBody();

    def headers = message.getHeaders();

    def properties = message.getProperties();
    def eventsInQueue = properties.get("totalResult");
    
    def executionLog = 'Total events in Queue for Item insert: ' + eventsInQueue + '. ';
    
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString('ExecutionLog', executionLog, 'text/plain');

    return message;
}