import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {

    def body = message.getBody();

    def headers = message.getHeaders();
    
    def jsonSlurper = new JsonSlurper();
    def apiResult = jsonSlurper.parse(body);
    
    def properties = message.getProperties();
    
    def eventId = properties.get("eventId");
    
     // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    def db_schema = properties.get('Database_Schema_Name');
    
    sqlStatement.root {
        for (rfxItem in apiResult.payload) {
            sqlStatement.InsertStatement {
                sqlStatement.app_sourcing_items(action: 'INSERT') {
                    sqlStatement.table(db_schema + '.APP_SOURCING_ITEMS')
                    sqlStatement.access {
                        sqlStatement.ITEM_ID(rfxItem.itemId)
                        sqlStatement.EVENT_ID(eventId)
                        if (rfxItem.description) {
                            sqlStatement.ITEM_TITLE(rfxItem.description.size() > 1000 ? rfxItem.description.substring(0,1000) : rfxItem.description)
                        }
                        else if (rfxItem.title) {
                            sqlStatement.ITEM_TITLE(rfxItem.title.size() > 1000 ? rfxItem.title.substring(0,1000) : rfxItem.title)
                        }
                        sqlStatement.ITEM_TYPE(rfxItem.itemType)
                        sqlStatement.ITEM_NUMBERING(rfxItem.numbering)
                        sqlStatement.ITEM_LINE_ITEM(rfxItem.lineItem)
                        sqlStatement.CREATEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                        sqlStatement.CREATEDBY(properties.get('Extension_User'))
                    }
                }
            }
            
            def termsList = new ArrayList<String>();
            for (rfxItemTerm in rfxItem.terms) {
                if (!termsList.contains(rfxItemTerm.fieldId)) {
                    termsList.add(rfxItemTerm.fieldId);
                    sqlStatement.InsertStatement {
                        sqlStatement.app_sourcing_item_term(action: 'INSERT') {
                            sqlStatement.table(db_schema + '.APP_SOURCING_ITEM_TERM')
                            sqlStatement.access {
                                sqlStatement.ITEM_ID(rfxItem.itemId)
                                sqlStatement.EVENT_ID(eventId)
                                sqlStatement.ITEM_TERM_ID(rfxItemTerm.fieldId)
                                sqlStatement.ITEM_TERM_TITLE(rfxItemTerm.title)
                                sqlStatement.SOURCE('Sourcing')
                                sqlStatement.ITEM_TERM_VALUE_TYPE(rfxItemTerm.valueTypeName)
                                sqlStatement.ITEM_TERM_AC_VALUES(rfxItemTerm.acceptableValues)
                                if (rfxItemTerm.listOfChoices) {
                                    def listOfValues = '';
                                    def separator = '';
                                    for (valueOfList in rfxItemTerm.listOfChoices) {
                                        listOfValues = listOfValues + separator + valueOfList.simpleValue;
                                        separator = '|';
                                    }
                                     sqlStatement.ITEM_TERM_LIST(listOfValues.size() > 2000 ? listOfValues.substring(0, 2000) : listOfValues)
                                }
                                if (rfxItemTerm.value) {
                                    if (rfxItemTerm.value.simpleValue) {
                                        sqlStatement.VALUE(rfxItemTerm.value.simpleValue.size() > 1000 ? rfxItemTerm.value.simpleValue.substring(0,1000) : rfxItemTerm.value.simpleValue)
                                    }
                                    if (rfxItemTerm.value.bigDecimalValue) {
                                        sqlStatement.VALUE_AMOUNT(rfxItemTerm.value.bigDecimalValue)
                                    }
                                    else if (rfxItemTerm.value.moneyValue) {
                                        sqlStatement.VALUE_AMOUNT(rfxItemTerm.value.moneyValue.amount)
                                    }
                                }
                                sqlStatement.HAS_PARTICIPANT_SVALUE(rfxItemTerm.hasParticipantSpecificValues)
                                
                                
                                sqlStatement.CREATEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                                sqlStatement.CREATEDBY(properties.get('Extension_User'))
                            }
                        }
                    }
                }
            }
        }
    };
    
    //itemPageId
    def itemsMaxPageSize = properties.get('Items_Max_Page_Size') as Integer;
    def itemPageId = properties.get('itemPageId');
    def lastFirstItemId = properties.get('lastFirstItemId');
    def hasPageToken = properties.get('hasPageToken');
    
    // only if the size if 50 continue to next page
    if (apiResult.payload.size() == itemsMaxPageSize 
            && !lastFirstItemId.equalsIgnoreCase(apiResult.payload[0].itemId)) {
        itemPageId = itemPageId + 1;
        //update the last first item
        message.setProperty("lastFirstItemId", apiResult.payload[0].itemId);
        hasPageToken = "1";
    }
    else {
        itemPageId = 0;
        hasPageToken = "0";
    }
    message.setProperty("itemPageId", itemPageId);
    message.setProperty("hasPageToken", hasPageToken);
     
    //set body
    message.setBody(writer.toString());
  
    return message;
}