/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.camel.impl.DefaultAttachment;
import javax.mail.util.ByteArrayDataSource;

def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def pMap = message.getProperties();

    def bytes = pMap.get("p_origPayload");
    messageLog.setStringProperty("ResponsePayload", "Printing Payload As Attachment")
    messageLog.addAttachmentAsString("Email error logging:", body, "text/plain");

    try {def dataSource = new ByteArrayDataSource(bytes, 'text/plain'); //Set MIME type
    def attachment = new DefaultAttachment(dataSource);
    message.addAttachmentObject("OriginalFile.csv", attachment);
    } catch (e){
        
    }
    
    // get an exception java class instance
    def ex = pMap.get("CamelExceptionCaught");
    if (ex!=null) {
            
    // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
    if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
                        
    // save the http error response as a message attachment 
        messageLog.addAttachmentAsString("http.ResponseBody", ex.getResponseBody(), "text/plain");

        // copy the http error response to an iflow's property
        message.setProperty("http.ResponseBody",ex.getResponseBody());

        // copy the http error response to the message body
        message.setBody(ex.getResponseBody());
        // copy the value of http error code (i.e. 500) to a property
        message.setProperty("http.StatusCode",ex.getStatusCode());

        // copy the value of http error text (i.e. "Internal Server Error") to a property
        message.setProperty("http.StatusText",ex.getStatusText());
        messageLog.addAttachmentAsString("http.ResponseBody", "ex.getResponseBody()=>"+ ex.getResponseBody() + "\nex.getStatusCode==>" + ex.getStatusCode() + "\nex.getStatusText()=>" + ex.getStatusText(), "text/plain");
                            
            }
        }


    return message;
}