/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.util.*;
import java.util.ArrayList;
import java.io.Reader;
import java.io.File;
import java.util.Map
import java.util.Iterator
import javax.activation.DataHandler;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import org.apache.camel.impl.DefaultAttachment;
import javax.mail.util.ByteArrayDataSource;

def Message initialPayload(Message message) {
    //Body 
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def pMap = message.getProperties();
    def header = message.getHeaders();
    
    
    
    //TODO read email subject
    
    def emailSubject = pMap.get("p_subject");
    def emailSubject2 = header.get("Subject");
    
    def (cbo, method, cboEntity) = emailSubject2.tokenize('|');

    def cboName = cboEntity + "_CDS";
    message.setProperty("p_cboEntity", cboEntity);
    message.setProperty("p_cboName", cboName ); 
    message.setProperty("p_method", method);
    
    
    
    def startChar = "<";
    def endChar = ">";
    def sender = pMap.get("p_sender");
    def email = "";
    def newBody = "" as String;
    
    try {
        email = sender.substring(sender.indexOf(startChar) + 1, sender.indexOf(endChar));
    } catch (Exception ex) {
        message.setProperty("p_isValidSender", "FALSE"); 
        
    }
    
    message.setProperty("p_sender", sender);
    message.setProperty("p_subject", emailSubject2);
    
    if(!method.equals("GET")) { //read Attachment
       Map<String, DataHandler> attachments = message.getAttachments();
       if (attachments.isEmpty()) {
          message.setProperty("p_validAttachment", "FALSE");
       } else {
            message.setProperty("p_validAttachment", "TRUE");
            Iterator<DataHandler> it = attachments.values().iterator();
            DataHandler attachment = it.next();
            message.setBody(attachment.getContent());
            //body = message.getBody(java.lang.String) as String;
            //message.setProperty("p_origPayload", newBody);
       }
    } else {
        //no attachment needed, set to TRUE
        message.setProperty("p_validAttachment", "TRUE");
    }
       
     if(pMap.get("p_approvedSenders").contains(email)) {
         message.setProperty("p_isValidSender", "TRUE");
     }
       
    if(pMap.get("p_isValidSender").equals("TRUE") && pMap.get("p_validAttachment").equals("TRUE") && !cboEntity.equals("") && (method.equals("GET") || method.equals("UPDATE") || method.equals("DELETE")) && cbo.contains("CBO")) {
        message.setProperty("p_isValidRequest", "TRUE");
    }  
    
     if(pMap.get("p_debugMode").toUpperCase()=='TRUE' && pMap.get("p_validAttachment")=='TRUE') {
            messageLog.setStringProperty("ResponsePayload", "Printing Payload As Attachment")
            messageLog.addAttachmentAsString("Initial Payload:" + cboName + ":" + pMap.get("p_method"), "", "text/plain");
     }
     
    
     return message;
}

def Message logCboRecords(Message message) {
    //Body 
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def pMap = message.getProperties();
    
    /*def feed = new XmlSlurper().parseText(body); 
    int i = 0;
    
    feed.entry.content.each{
         
    }*/
     if(pMap.get("p_debugMode").toUpperCase()=='TRUE') {
            messageLog.setStringProperty("ResponsePayload", "Printing Payload As Attachment")
            messageLog.addAttachmentAsString("Current CBO RecordList", body, "text/plain");
     }
     
    message.setProperty("p_subject", pMap.get("p_subject") + " - RESULTS");
    message.setProperty("p_emailBody", "Attached is the extract for CBO "+ pMap.get("p_cboEntity") + ".");

     return message;
}

def Message convertPayload(Message message) {
    //Body 
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def pMap = message.getProperties();
    
    //set Cookies
    def headers = message.getHeaders();
    def cookie = headers.get("Set-Cookie");
    StringBuffer bufferedCookie = new StringBuffer();
    for (Object item : cookie) 
    {
        bufferedCookie.append(item + "; ");     
        
    }
    message.setHeader("Cookie", bufferedCookie.toString());
    message.setHeader("X-CSRF-Token", pMap.get("p_csrfToken"));
    
    
    
    def newBody = "--batch_mybatch\nContent-Type: multipart/mixed; boundary=changeset_mychangeset1\n\n";

    def row = 0 as Integer;
    def i = 0 as Integer;
    List<String> header = null;
    List<String> fieldType = null;
    String currentMethod = "";

    def fieldTypeMap = pMap.get("p_fieldTypeMap") as Map;

    body.eachLine { String line ->
          
          
          i = 0;
          //header row
          if(row == 0) {
              header = Arrays.asList(line.split(","));
          } 
          else {
              newBody = newBody + "--changeset_mychangeset1\n" +
                        "Content-Type: application/http\n" +
                        "Content-Transfer-Encoding: binary\n\n";
                        
              String[] currLine = line.split(",");
              for (String s: currLine) {
                      if (pMap.get("p_method").equalsIgnoreCase("DELETE")) {
                          currentMethod = "DELETE";
                      }
                      else if(s == "") {
                          currentMethod = "POST";
                      } else {
                          currentMethod = "MERGE";
                      }

                        if (i==0 && currentMethod.equals("MERGE")) {
                         //todo check method
                        newBody = newBody + currentMethod + " " + pMap.get("p_cboEntity") + "(guid'"+ s + "') HTTP/1.1\n";
                        newBody = newBody + "Content-Type: application/json\n\n{\n";
                          
                         } else if (i==0 && currentMethod.equals("DELETE")) {
                             
                             newBody = newBody + currentMethod + " " + pMap.get("p_cboEntity") + "(guid'"+ s + "') HTTP/1.1\n";
                            
                         } else if(i==0 && currentMethod.equals("POST")) {
                              
                              newBody = newBody + currentMethod + " " + pMap.get("p_cboEntity") + " HTTP/1.1\n";
                              newBody = newBody + "Content-Type: application/json\n\n{\n";
                         }
                     
                      if(i > 0)  {
                          if(fieldTypeMap.get(header[i]) == "Edm.Boolean") {
                               newBody = newBody + "\"" + header[i] + "\" : " + s +",\n";
                             } /*else if(fieldTypeMap.get(header[i]) == "Edm.DateTime") {
                                 newBody = newBody + "\"" + header[i] + "\" : datetime'" + s +"',\n";
                             } else if(fieldTypeMap.get(header[i]) == "Edm.DateTimeOffset") {
                                    newBody = newBody + "\"" + header[i] + "\" : datetimeoffset'" + s +"',\n";
                             } else if (fieldTypeMap.get(header[i]) == "Edm.Decimal") {
                                    newBody = newBody + "\"" + header[i] + "\" : " + s + ",\n";
                             }*/ else {
                                
                                 if(!s.trim().equals(""))
                                 {
                                     newBody = newBody + "\"" + header[i] + "\" : \"" + s +"\",\n";
                                 }
                             }
                        }   
                  i = i+1;
            }
            StringBuffer sbuff = new StringBuffer(newBody);
                try {
                    int j = newBody.lastIndexOf(",");
                    sbuff.deleteCharAt(j);
                } catch (Exception e){ }
            
            newBody = sbuff.toString();
            if(!currentMethod.equals("DELETE")) {
                newBody = newBody + "}";
            }
            newBody = newBody + "\n\n";
         
          }
          row = row + 1;
          
    }
    newBody = newBody + "\n--changeset_mychangeset1--\n\n--batch_mybatch--\n";

    message.setBody(newBody);

     if(pMap.get("p_debugMode").toUpperCase()=='TRUE') {
            messageLog.setStringProperty("ResponsePayload", "Printing Payload As Attachment")
            messageLog.addAttachmentAsString("Batch Payload for S4:", newBody, "text/plain");
     }
     
    
     return message;
}


def Message replyFromS4(Message message) {
    //Body 
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def pMap = message.getProperties();
    
     if(pMap.get("p_debugMode").toUpperCase()=='TRUE' && messageLog != null) {
            messageLog.setStringProperty("ResponsePayload", "Printing Payload As Attachment")
            messageLog.addAttachmentAsString("Reply From S4", body, "text/plain");
     }
     
    def bytes = body; 
    try {
        def dataSource = new ByteArrayDataSource(bytes, 'text/plain'); //Set MIME type
        def attachment = new DefaultAttachment(dataSource);
        message.addAttachmentObject("Results.txt", attachment);
    } catch (e){
        
    }
    
    
    def lines = body.readLines();
    def finalPayload = "";
    
    lines.each { String line ->
        if(line.startsWith("HTTP/")) {
            
            if(line.contains("201") || line.contains("204")){
                finalPayload = finalPayload + "SUCCESS: " + line + "\n";
            } else {
                message.setProperty("p_containsError", "TRUE");
                finalPayload = finalPayload + "ERROR: " + line + "\n";
            }
        }
    }
    
    //if(pMap.get("p_containsError").equals("TRUE")) {
        message.setProperty("p_s4Reply", body);
    //}
    
    message.setProperty("p_subject", pMap.get("p_subject") + " - RESULTS");
    message.setProperty("p_emailBody", finalPayload);
    
     if(pMap.get("p_debugMode").toUpperCase()=='TRUE' && messageLog != null) {
            messageLog.setStringProperty("ResponsePayload", "Printing Payload As Attachment")
            messageLog.addAttachmentAsString("Final Payload:", finalPayload, "text/plain");
     }
    
     return message;
}


def Message logMetadata(Message message) {
    //Body 
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def pMap = message.getProperties();
    body = body.replaceAll("edmx:", "");
    
    def entityName = pMap.get("p_cboEntity") + "TYPE";
    
     if(pMap.get("p_debugMode").toUpperCase()=='TRUE') {
            messageLog.setStringProperty("ResponsePayload", "Printing Payload As Attachment")
            messageLog.addAttachmentAsString("Metadata", body, "text/plain");
     }
     def test = "";
     def Edmx = new XmlSlurper().parseText(body);  
     def fieldName = "";
     def fieldType = "";
    def fieldTypeMap = [:];
    def headerPayload = "";
    
    Edmx.DataServices.Schema.each {
        
        test = "${it.EntityType.@Name}";
         messageLog.setStringProperty("ResponsePayload", "Printing Payload As Attachment")
            messageLog.addAttachmentAsString("Name" + test, body, "text/plain");
            
        if(entityName.equalsIgnoreCase(test)){
            it.EntityType.Property.each { fields ->
                fieldName = "${fields.@Name}" as String;
                fieldType = "${fields.@Type}" as String;
                fieldTypeMap.put(fieldName, fieldType);
                headerPayload = headerPayload + fieldName + ",";

            }
            
        }
        message.setProperty("p_fieldTypeMap", fieldTypeMap);
        message.setProperty("p_headerPayload", headerPayload);
        
        
    }
     return message;
}

def Message containsRecords(Message message) {
    //Body 
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def pMap = message.getProperties();
    
     if(body.contains("m:properties")){
        
        message.setProperty("p_containsRecords", "TRUE");
     } else {
        message.setProperty("p_containsRecords", "FALSE");
     }
     
    
    
     return message;
}







