import com.sap.it.api.mapping.MappingContext

def String SystemID(String _PID, MappingContext context) {
  return context.getProperty(_PID)
}

def String generateMessageHeaderUUID(String value, MappingContext context) {
  def messageId = UUID.randomUUID().toString()
  context.setHeader("SAP_ApplicationID", messageId)
  return messageId
}

def String generateMessageRequestUUID(String value, MappingContext context) {
  return UUID.randomUUID()
}