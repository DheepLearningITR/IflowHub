import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil
def Message processData(Message message) {
    def chrmas_full_xml = message.getBody(java.lang.String) as String;
    if( chrmas_full_xml == null|| chrmas_full_xml.contains("NOTFOUND") ||chrmas_full_xml ==''){
         message.setBody("<NOTFOUND/>");
        return message;
    }

    def   clsmas_xml = message.getProperty('CLSMAS_FULL_XML') as java.lang.String;
     if(clsmas_xml == null || clsmas_xml == ''){
         clsmas_xml = message.getBody(java.lang.String) ;
    }

	def cls_root = new XmlSlurper().parseText(clsmas_xml);
    def chr_root = new XmlSlurper(false,false).parseText(chrmas_full_xml);

    def cls_category_type = message.getProperty("CLS_KLART") as String;
    def cls_class = message.getProperty("CLS_CLASS") as String;

    def parentPayload= processParentVariantCategories( cls_root, chr_root ,cls_category_type, cls_class);

    message.setBody(XmlUtil.serialize('<batchParts xmlns="">'+parentPayload+'</batchParts>') );
    return message;

}

def processParentVariantCategories(cls_root ,chr_root, cls_category_type, cls_class){

    def attr_code = chr_root.IDOC.E1CABNM.ATNAM.text();
    def parentVariantCategoryCode = cls_class +'_'+attr_code

	def batchChangeSets = [:];
	chr_root.IDOC.E1CABNM.E1CABTM.each{it->
	    batchChangeSets.put(it.SPRAS_ISO.text(), it.ATBEZ.text())
	};


	if(batchChangeSets.size()==0)
	    batchChangeSets.put('','');

    def builder = new StreamingMarkupBuilder()
  	def batchParts = builder.bind {
					 batchChangeSet {
						 batchChangeSetPart{
							 method('POST')
							 VariantCategories{
								 VariantCategory{
									 integrationKey('')
									 code(parentVariantCategoryCode)
									 localizedAttributes{
									 	batchChangeSets.each{  langKey,langValue->
									 	    Localized___VariantCategory{
									 	        language(langKey.toLowerCase())
									 	        name(langValue)
									 	    }
									 	}
									 }
									 catalogVersion{
										 CatalogVersion{
											 integrationKey('')
											 version('ERP_IMPORT')
											 catalog{
												 Catalog{
													 integrationKey('')
													 id('ERP_CLASSIFICATION_'+cls_category_type)
												 }
											 }
										 }
									 }
								 }
							 }
						 }
					 }

  	}

    return batchParts;
}
