
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil
import java.text.NumberFormat;
import java.lang.Number;
import java.text.DecimalFormat;
import java.util.Locale;

def Message processData(Message message) {
    def chrmas_full_xml = message.getBody(java.lang.String) as String;
    if( chrmas_full_xml == null|| chrmas_full_xml.contains("NOTFOUND") ||chrmas_full_xml ==''){
         message.setBody("<NOTFOUND/>");
        return message;
    }

    def chr_root = new XmlSlurper(false,false).parseText(chrmas_full_xml);


    def cls_category_type = message.getProperty("CLS_KLART") as String;
    def cls_class = message.getProperty("CLS_CLASS") as String;

	def childPayload= processChildVariantValueCategories( chr_root ,cls_category_type, cls_class);

    message.setBody(XmlUtil.serialize('<batchParts xmlns="">'+childPayload+'</batchParts>') );
    return message;

}


def processChildVariantValueCategories(groovy.util.slurpersupport.GPathResult chr_root, String cls_category_type, String cls_class){
    def batchAttributeValueLangList = [:]
    def batchLangChangeSets = [:]
    def batchSequenceMap =[:]
    def langs =[]

    def attr_code = chr_root.IDOC.E1CABNM.ATNAM.text();

    def dataType = chr_root.IDOC.E1CABNM.ATFOR.text()
    def rangesAllowed = chr_root.IDOC.E1CABNM.ATINT.text()
    chr_root.IDOC.E1CABNM.E1CABTM.each{lang->
        langs.add(lang.SPRAS_ISO.text())
    }
    
    if(dataType.equals('NUM')) {
        def unit = chr_root.IDOC.E1CABNM.MSEHI.text()
        if(null == unit){
            unit = ''
        }else{
            unit = ' '+unit
        }
	    if(rangesAllowed != null && rangesAllowed.equals('X')){
	        chr_root.IDOC.E1CABNM.E1CAWNM.each{ it->
                batchLangChangeSets.put(formatNumber(it.ATFLV.text())+' - '+formatNumber(it.ATFLB.text()) +unit,langs)
                batchAttributeValueLangList.put(convertNumberRangeForVariantValueID(it.ATFLV.text(), it.ATFLB.text() , it.ATCOD.text()),batchLangChangeSets )
                batchLangChangeSets = [:];
                batchSequenceMap.put(convertNumberRangeForVariantValueID(it.ATFLV.text(), it.ATFLB.text() , it.ATCOD.text()), it.ATZHL.text())
            }
	    }else{
	       chr_root.IDOC.E1CABNM.E1CAWNM.each{ it->
                batchLangChangeSets.put(formatNumber(it.ATFLV.text())+' '+unit,langs)
                batchAttributeValueLangList.put(convertNonLocalizedNumberForVariantValueID(it.ATFLV.text()),batchLangChangeSets )
                batchLangChangeSets = [:];
                batchSequenceMap.put(convertNonLocalizedNumberForVariantValueID(it.ATFLV.text()), it.ATZHL.text())
            }
	    }
	}else{
	    chr_root.IDOC.E1CABNM.E1CAWNM.each{it->
	    def generalName = it.ATWRT.text()
        if(it.E1CAWTM.size()>0){
            it.E1CAWTM.each { lang->
                if(null != lang.ATWTB.text()){
                    generalName = lang.ATWTB.text()
                }
                batchLangChangeSets.put(lang.SPRAS_ISO.text(),generalName)
            }
        }else{
           langs.each{val-> val
            batchLangChangeSets.put(val,generalName)
             }
        }
            batchAttributeValueLangList.put(it.ATWRT.text(),batchLangChangeSets )
            batchLangChangeSets = [:];
            batchSequenceMap.put(it.ATWRT.text(), it.ATZHL.text())
        }
	}
	
  def builder = new StreamingMarkupBuilder()
  def batchParts = builder.bind {
			  batchAttributeValueLangList.each{ key,value ->
					 batchChangeSet {
						 batchChangeSetPart{
							 method('POST')
							 VariantValueCategories{
								 VariantValueCategory{
									 integrationKey('')
									 code(cls_class+"_"+attr_code+"_"+key)
									 sequence(batchSequenceMap[key].toInteger())
									 localizedAttributes{
                                        value.each {langKey,langValue->
                                            Localized___VariantValueCategory{
                                                    name(langValue)
                                                    language(langKey.toLowerCase())
                                            }
									    }
                                    }
									 catalogVersion{
										 CatalogVersion{
											 integrationKey('')
											 version('ERP_IMPORT')
											 catalog{
												 Catalog{
													 integrationKey('')
													 id('ERP_CLASSIFICATION_'+cls_category_type)
												 }
											 }
										 }
									 }
									 supercategories{
									     	Category{
    			                                integrationKey('')
    			                                 code(cls_class+"_"+attr_code)
    			                                 catalogVersion {
    				                                CatalogVersion{
    					                                       integrationKey('')
    					                                        version('ERP_IMPORT')
    					                                        catalog{
    						                                        Catalog{
    							                                            integrationKey('')
    							                                            id('ERP_CLASSIFICATION_'+cls_category_type)
    						                                        }
    					                                        }
    				                                        }
    			                                        }
    	                                    	}
									 }
								 }
							 }
						 }
					 }
			 }

  	}
    return batchParts;
}

def formatNumber(String number){
    return convertNonLocalizedNumber(number);
}

def convertNonLocalizedNumberForVariantValueID(String number){
    return convertNonLocalizedNumber(number).replaceAll(",", "x").replaceAll("\\.", "x")
}

def convertNonLocalizedNumber(String number) {
	def maxFractionDigits = 9;

	java.text.NumberFormat numberFormat = NumberFormat.getInstance(java.util.Locale.ENGLISH);
	java.lang.Number parsedNumber = numberFormat.parse(number.replaceFirst("E\\+", "E"));
	java.text.DecimalFormat decimalFormat = (java.text.DecimalFormat)java.text.NumberFormat.getNumberInstance(java.util.Locale.ENGLISH)
	decimalFormat.setMaximumFractionDigits(maxFractionDigits);
	decimalFormat.setGroupingUsed(false);

	return decimalFormat.format(parsedNumber)

}

def convertNumberRangeForVariantValueID(String numberFrom, String numberTo, String dependencyCode){
		String rangeID;
        String formattedNumberFrom = convertNonLocalizedNumber(numberFrom);
		String formattedNumberTo = convertNonLocalizedNumber(numberTo);
		switch (dependencyCode)
		{
			case "1":
				rangeID = formattedNumberFrom;
				break;
			case "2":
				rangeID = ">=".concat(formattedNumberFrom.concat("<").concat(formattedNumberTo));
				break;
			case "3":
				rangeID = ">=".concat(formattedNumberFrom.concat("<=").concat(formattedNumberTo));
				break;
			case "4":
				rangeID = ">".concat(formattedNumberFrom.concat("<").concat(formattedNumberTo));
				break;
			case "5":
				rangeID = ">".concat(formattedNumberFrom.concat("<=").concat(formattedNumberTo));
				break;
			case "6":
				rangeID = "<".concat(formattedNumberFrom);
				break;
			case "7":
				rangeID = "<=".concat(formattedNumberFrom);
				break;
			case "8":
				rangeID = ">".concat(formattedNumberFrom);
				break;
			case "9":
				rangeID = ">=".concat(formattedNumberFrom);
				break;
		}

		return rangeID;
}
