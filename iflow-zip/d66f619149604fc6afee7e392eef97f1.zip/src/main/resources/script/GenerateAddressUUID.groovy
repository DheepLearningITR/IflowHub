import com.sap.it.api.mapping.*;
import java.security.MessageDigest;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String genAddrUUID(String UID){

    String result = MessageDigest.getInstance("MD5").digest(UID.bytes).encodeHex().toString();
 
    // Compiled regex for UUID
    def p = ~"(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})"
    return (p.matcher(result).replaceAll("\$1-\$2-\$3-\$4-\$5"))
}

