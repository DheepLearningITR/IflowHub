/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;
    
def Message processData(Message message) {
    
    //Headers 
    def headerMap = message.getHeaders();
    def CDCSignature = headerMap.get("x-gigya-sig-hmac-sha1");
    
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    if( service != null) {
        
        try{
            def body = message.getBody((byte[]).class);
            propertyMap = message.getProperties();
            def cdcAppCredential = propertyMap.get("cdcAppCredential")
            
            String encodedSecret = new String(service.getUserCredential(cdcAppCredential).getPassword());
            
            byte[] data = body;
            byte[] decodedKey = Base64.getDecoder().decode(encodedSecret);
            SecretKey secretKey = new SecretKeySpec(decodedKey, "RAW");
        
            Mac mac = Mac.getInstance("HmacSHA1");
            mac.init(secretKey);
            byte[] result = mac.doFinal(data);
            
            message.setProperty("Computed",result.encodeBase64().toString());
            
            // Raise exception if the signature doesn't match
            if(!CDCSignature.equals(result.encodeBase64().toString())){
                throw new Exception("Signature mismatch");
            }
        
        } catch (InvalidKeyException e) {
            throw new RuntimeException("Invalid key exception while converting to HMac SHA1")
        }
        
    }
    
    return message;
   
}