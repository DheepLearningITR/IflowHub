/*
Script to assign permitted URL Parameters to the corresponding message headers.
Release version 1.0.0
SAP SE 2018
*/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def headers = message.getHeaders();
    def urlQueryHeader = headers.get("CamelHttpQuery");
    if(urlQueryHeader){
        def urlQueries = urlQueryHeader.split('&');
        def mapParams = urlQueries.collectEntries { param -> param.split('=').collect { URLDecoder.decode(it) }}
        if (mapParams["mapping_id"] != null && mapParams["directory_id"] != null)
        {
            message.setHeader("x-partner-directory", mapParams["directory_id"]);
            message.setHeader("x-body-mapping", mapParams["mapping_id"]);
        }
        if (mapParams["surveyprovider"] != null) {
            message.setHeader("x-external-surveyprovider", "\r/" +  mapParams["surveyprovider"]);
        }        
    }
    
    def preProcessing = message.getProperty('PreProcessing');
    def preProcessValues = preProcessing.split('&');
    def svyIdFieldName,responseIdFieldName;
    preProcessValues.each {
        def(name,value) = it.split('=');
        if(name == "SurveyIDFieldName"){
            svyIdFieldName = value;
            message.getProperties().put("SurveyIDFieldName",value);
        }else if ( name == "ResponseIDFieldName"){
            responseIdFieldName = value;
            message.getProperties().put("ResponseIDFieldName",value);
        }
    }
   
   
    def body = message.getBody(String.class);
    def values = body.split('&');
                
    values.each {
        def (k, v) =  it.split('=', 2);
            if(k == svyIdFieldName){  //The Survey ID field name is used to determine the survey ID for post processing.
                message.getProperties().put("SurveyID",v);
            }else if(k == responseIdFieldName){
                message.getProperties().put("ResponseID",v);
            }else{
                message.getProperties().put(k,v);   
            }
    }
    return message;
}
