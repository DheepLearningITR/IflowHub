/*
Script to fetch tenant's log-mode.
Release version 1.0.0
SAP SE 2018
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    try {
        message.setHeader("Loglevel", message.properties.SAP_MessageProcessingLogConfiguration.logLevel);
        return message;
    } catch (Exception e) {
        return message;
    }
}