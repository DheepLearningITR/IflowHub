/*
Script to build the Batch Payload from the Survey Object.
Release version 1.0.0
SAP SE 2018
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil
import groovy.util.XmlSlurper
import groovy.util.slurpersupport.NodeChild

class BatchEntity {
    private String serviceRelativeURL;
    private def batchPayload;
    BatchEntity(String ServiceRelativeURL, def BatchPayload) {
        serviceRelativeURL = ServiceRelativeURL;
        batchPayload = BatchPayload;
    }

    def getServiceURL() {
        return serviceRelativeURL;
    }

    def getBatchPayload() {
        return batchPayload;
    }

    def getBatchEntity() {
        def entity = new XmlSlurper().parseText("<Entity></Entity>");
        entity.appendNode {
            ServiceName(serviceRelativeURL)
            BatchRequest(batchPayload)
        };
        return entity;
    }
}

	def surveyEntityBuilder(SurveyMetadataSet, SurveyResponseSet, SurveySet) {

//		Build Metadata Payload		
		def questionSubEntityNames = [
			[ 'Answer', 'QuestionAnswerSet', 'Choice', 'QuestionChoiceSet']
		]
		
		def surveyBatch = new XmlSlurper().parseText("<batchParts><batchChangeSet></batchChangeSet></batchParts>");

		def metadataSetParts = new XmlSlurper().parseText("<batchChangeSetPart><method>POST</method><headers><header><headerName>iv_mode</headerName><headerValue>D</headerValue></header></headers><uri>SurveySet</uri><SurveySet><Survey><SurveyQuestionSet></SurveyQuestionSet></Survey></SurveySet></batchChangeSetPart>");

		String outxml;
		
		SurveyMetadataSet.each { question ->
			if (question != "") {
				
				def questionset = new XmlSlurper().parseText("<Question></Question>");
				
				questionSubEntityNames.each { entity ->
//						append Answer to Question
						questionset.appendNode(
								MKTSurveySubEntityBuilder(question[entity[1]], entity[0], entity[1])
								);
						
						questionset.appendNode(
								MKTSurveySubEntityBuilder(question[entity[3]], entity[2], entity[3])
								);
//						append Question
						metadataSetParts.SurveySet.Survey.SurveyQuestionSet.appendNode(questionset);
						
						question.appendNode {
							SurveyId("${SurveySet.SurveyId}") 
							Provider("${SurveySet.Provider}")
							Version("${SurveySet.Version}")
						};
						
//						append Question Body
						questionset.appendNode(question.getBody());
						
//					    remove QuestionSet details
					    question[entity[1]].replaceNode {};
					    question[entity[3]].replaceNode {};
					}
				};
		};

//		append Survey details
		metadataSetParts.SurveySet.Survey.appendNode {
			SurveyId("${SurveySet.SurveyId}")
			Provider("${SurveySet.Provider}")
			Version("${SurveySet.Version}")
			IsMultipleRespAllowed("${SurveySet.IsMultipleRespAllowed}")
			Name("${SurveySet.Name}")
			NickName("${SurveySet.NickName}")
			AccountId("${SurveySet.AccountId}")
			Category("${SurveySet.Category}")
			Url("${SurveySet.Url}")
			MarketingAreaId("${SurveySet.MarketingAreaId}")
			Language("${SurveySet.Language}")
			IsSurveyAnonymous("${SurveySet.IsSurveyAnonymous}")
			CreatedOn("${SurveySet.CreatedOn}")
			ModifiedOn("${SurveySet.ModifiedOn}")
			ValidFrom("${SurveySet.ValidFrom}")
			ValidTo("${SurveySet.ValidTo}")
		};

//		append QuestionSet to Survey				
		surveyBatch.batchChangeSet.appendNode(metadataSetParts);

//		Build Response Payload		
		def responsesetSubEntityNames = [['SurveyResponseDetail', 'SurveyResponseSurveyResponseDetailSet']]
		
		SurveyResponseSet.each { response ->
				def responseBatchPart = new XmlSlurper().parseText("<batchChangeSetPart><method>POST</method><uri>SurveyResponseSet</uri><SurveyResponseSet></SurveyResponseSet></batchChangeSetPart>");
			if (response != "") {

				def responseset = new XmlSlurper().parseText("<SurveyResponse></SurveyResponse>");
				
				responsesetSubEntityNames.each { entity ->
					if(response[entity[1]] != '')
					{
//						append Survey Response Details						
						responseset.appendNode(
								MKTSurveySubEntityBuilder(response[entity[1]], entity[0], entity[1])
								);

//						append Survey details
						responseset.appendNode {
							SurveyId("${SurveySet.SurveyId}")
							Provider("${SurveySet.Provider}")
							Version("${SurveySet.Version}")
						};

//						append Response Body
						responseset.appendNode(response.getBody());

//						append Survey Response Set
						responseBatchPart.SurveyResponseSet.appendNode(responseset);
					}
//					remove Survey Response Set details					
					response[entity[1]].replaceNode {};
					}
				};
//				append SurveyResponseSet to Survey				
				surveyBatch.batchChangeSet.appendNode(responseBatchPart);
		};

		return surveyBatch;
	}

	def MKTSurveySubEntityBuilder(def SubEntity, String SingularName, String PluralName) {

		def subEntity = new XmlSlurper().parseText("<${PluralName}></${PluralName}>");
		SubEntity.each {entity ->
			if(entity != "") {
				subEntity.appendNode{ "${SingularName}"(entity.getBody()) };
			}
		};
		return subEntity;

	}
	
    def validatePayload(SurveyPayload, ResponsePayload) {
    
//		validate survey metadata				
    	if (SurveyPayload.SurveyId == '' || SurveyPayload.SurveyId == null){
    		throw new RuntimeException("Please provider Survey Id");
    	}
    
    	if (SurveyPayload.Provider == '' || SurveyPayload.Provider == null){
    		throw new RuntimeException("Please provider Survey Provider");
    	}
    
    	if (SurveyPayload.Version == '' || SurveyPayload.Version == null){
    		throw new RuntimeException("Please provider Survey Version");
    	}
    }

    def Message processData(Message message) {

        def body = message.getBody(String.class);
		def surveyPayload = new XmlSlurper().parseText(body);
		def metadataPayload = surveyPayload.SurveyQuestionSet;
		def responsePayload = surveyPayload.SurveyResponseSet;

//		validate payload		
		validatePayload(surveyPayload, responsePayload );

		def rootBatch = new XmlSlurper().parseText("<Root></Root>");
		
		//Build Survey Batch Entity
		if (metadataPayload != "" || responsePayload != "") {
			def surveyBatchPayload = surveyEntityBuilder(metadataPayload, responsePayload, surveyPayload);
			def surveyEntity = new BatchEntity("CUAN_SURVEY_IMPORT_SRV", surveyBatchPayload).getBatchEntity();
			rootBatch.appendNode(surveyEntity);
		}
		else {
			def surveyBatch = new XmlSlurper().parseText("<batchParts><batchChangeSet></batchChangeSet></batchParts>");
			def changeSetParts = new XmlSlurper().parseText("<batchChangeSetPart><method>POST</method><headers><header><headerName>iv_mode</headerName><headerValue>D</headerValue></header></headers><uri>SurveySet</uri><SurveySet><Survey></Survey></SurveySet></batchChangeSetPart>");
			changeSetParts.SurveySet.Survey.appendNode(surveyPayload.getBody());
			surveyBatch.batchChangeSet.appendNode(changeSetParts);
			def surveyEntity = new BatchEntity("CUAN_SURVEY_IMPORT_SRV", surveyBatch).getBatchEntity();
			rootBatch.appendNode(surveyEntity);
		}

    message.setBody(XmlUtil.serialize(rootBatch));
    return message;

// 	String outxml = groovy.xml.XmlUtil.serialize( rootBatch )
// 	println outxml

    }