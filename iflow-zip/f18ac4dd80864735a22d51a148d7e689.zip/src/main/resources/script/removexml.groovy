import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
    // Get the message body as a string
    String body = message.getBody(String)

    // Remove the XML declaration
    body = body.replaceFirst(/<\?xml[^>]*\?>/, "").trim()

    // Set the cleaned body back into the message
    message.setBody(body)

    return message
}
