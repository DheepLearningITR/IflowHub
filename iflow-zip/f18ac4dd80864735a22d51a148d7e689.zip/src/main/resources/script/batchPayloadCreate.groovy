import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*
import groovy.json.*


def Message processData(Message message) {
    def salesOrderId = message.getProperty("salesOrderId")
    def itemMap = message.getProperty("itemMap")
    def payloadIn = new JsonSlurper().parseText(message.getProperty("payload_in")).messageRequests[0].body
    Node batch_payload = new NodeBuilder().batchParts{}
    def returnOrderId = payloadIn.receiverDisplayId
    def soldToParty = payloadIn.individualCustomer ? payloadIn.individualCustomer.receiverDisplayId : (payloadIn.account ? payloadIn.account.receiverDisplayId : null)

    Node headerNode = new NodeBuilder().batchChangeSet{ batchChangeSetPart{
        method("PATCH")
        uri("A_CustomerReturn('" + returnOrderId + "')")
        A_CustomerReturn{
        A_CustomerReturnType{
            CustomerReturn(returnOrderId)
            CustomerReturnType(payloadIn.returnOrderType)
            SalesOrganization(payloadIn.businessArea.receiverSalesOrganisationId)
            DistributionChannel(payloadIn.businessArea.distributionChannel)
            OrganizationDivision(payloadIn.businessArea.division)
            SalesGroup(payloadIn.businessArea.receiverSalesGroupId)
            SalesOffice(payloadIn.businessArea.receiverSalesOfficeId)
            SoldToParty(soldToParty)
            CustomerReturnDate(payloadIn.customerReturnDate)
            SDDocumentReason(payloadIn.returnReason)
            ReferenceSDDocument(salesOrderId)
            ReferenceSDDocumentCategory("C")
        }}
    }}
    batch_payload.append(headerNode)

    party = payloadIn.billToIndividualCustomer ? payloadIn.billToIndividualCustomer.receiverDisplayId : (payloadIn.billToAccount ? payloadIn.billToAccount.receiverDisplayId : null)
    if(party != null){
        Node partnerNode = new NodeBuilder().batchChangeSet{ batchChangeSetPart{
            method("PATCH")
            uri("A_CustomerReturn('" + returnOrderId + "')/to_Partner")
            A_CustomerReturnPartner{ A_CustomerReturnPartnerType{
                CustomerReturn(returnOrderId)
                PartnerFunction("BP")
                Customer(party)
            }}
        }}
        batch_payload.append(partnerNode)
    }

    party = payloadIn.payerIndividualCustomer ? payloadIn.payerIndividualCustomer.receiverDisplayId : (payloadIn.payerAccount ? payloadIn.payerAccount.receiverDisplayId : null)
        if(party != null){
            Node partnerNode = new NodeBuilder().batchChangeSet{ batchChangeSetPart{
            method("PATCH")
            uri("A_CustomerReturn('" + returnOrderId + "')/to_Partner")
            A_CustomerReturnPartner{ A_CustomerReturnPartnerType{
                CustomerReturn(returnOrderId)
                PartnerFunction("PY")
                Customer(party)
            }}
        }}
        batch_payload.append(partnerNode)
    }

    party = payloadIn.shipToIndividualCustomer ? payloadIn.shipToIndividualCustomer.receiverDisplayId : (payloadIn.shipToAccount ? payloadIn.shipToAccount.receiverDisplayId : null)
        if(party != null){
           Node partnerNode = new NodeBuilder().batchChangeSet{ batchChangeSetPart{
            method("PATCH")
            uri("A_CustomerReturn('" + returnOrderId + "')/to_Partner")
            A_CustomerReturnPartner{ A_CustomerReturnPartnerType{
                CustomerReturn(returnOrderId)
                PartnerFunction("SH")
                Customer(party)
            }}
        }}
        batch_payload.append(partnerNode)
    }

    party = payloadIn.contact ? payloadIn.contact.receiverDisplayId : null
    if(party != null){
         Node partnerNode = new NodeBuilder().batchChangeSet{ batchChangeSetPart{
            method("PATCH")
            uri("A_CustomerReturn('" + returnOrderId + "')/to_Partner")
            A_CustomerReturnPartner{ A_CustomerReturnPartnerType{
                CustomerReturn(returnOrderId)
                PartnerFunction("CP")
                Customer(party)
            }}
        }}
        batch_payload.append(partnerNode)
    }

    payloadIn.items.each{item-> 
        def refundType = item.refundType == "CREDIT_MEMO" ? "":"1"
        def itemNode
        if(!item.externalItemReference){
            itemNode = new NodeBuilder().batchChangeSet{ batchChangeSetPart{
                method("POST")
                uri("A_CustomerReturn('" + returnOrderId + "')/to_Item")
                A_CustomerReturnItem{ A_CustomerReturnItemType{
                    CustomerReturn(returnOrderId)
                    CustomerReturnItem(item.lineNumber)
                    Material(item.product.receiverDisplayID)
                    RequestedQuantity(item.returnQuantity.content)
                    RequestedQuantityUnit(item.returnQuantity.uomCode)
                    ReturnReason(item.itemReturnReason)
                    ReturnsRefundType(refundType)
                    ReturnsRefundRjcnReason(item.itemCancellationReason)
                    ReferenceSDDocumentItem(itemMap[item.referenceItem])
                    ReferenceSDDocument(salesOrderId)
                    if (refundType == "1") {
                        ReplacementMaterial(item.replacementProduct.receiverDisplayId)
                        ReplacementMaterialQuantity(item.returnQuantity.content)
                        ReplacementMaterialQtyUnit(item.returnQuantity.uomCode)
                    }
                }}
            }}
        }else{
            itemNode = new NodeBuilder().batchChangeSet{ batchChangeSetPart{
                method("PATCH")
                uri("A_CustomerReturnItem(CustomerReturn='" + returnOrderId + "',CustomerReturnItem='" + item.externalItemReference + "')")
                A_CustomerReturnItem{ A_CustomerReturnItemType{
                    CustomerReturn(returnOrderId)
                    CustomerReturnItem(item.externalItemReference)
                    Material(item.product.receiverDisplayID)
                    RequestedQuantity(item.returnQuantity.content)
                    RequestedQuantityUnit(item.returnQuantity.uomCode)
                    ReturnReason(item.itemReturnReason)
                    ReturnsRefundType(refundType)
                    ReturnsRefundRjcnReason(item.itemCancellationReason)
                    ReferenceSDDocumentItem(itemMap[item.referenceItem])
                    ReferenceSDDocument(salesOrderId)
                    if (refundType == "1") {
                        ReplacementMaterial(item.replacementProduct.receiverDisplayId)
                        ReplacementMaterialQuantity(item.returnQuantity.content)
                        ReplacementMaterialQtyUnit(item.returnQuantity.uomCode)
                    }
                }}
            }}
        }
        batch_payload.append(itemNode)
    }

    def xml = new XmlParser().parseText(groovy.xml.XmlUtil.serialize(batch_payload))
    def emptyNodes = xml.'**'.findAll{it.name() && it.text()=='null'}
    def removeNode = {
        node ->
        def parent = node.parent()
        parent.remove(node)
    }
    emptyNodes.each{removeNode(it)}
    
    String payloadOut = groovy.xml.XmlUtil.serialize(xml)
    payloadOut = payloadOut.replaceFirst(/<\?xml[^>]*\?>/, "").trim()
    message.setBody(payloadOut)
    message.setProperty("createBody", payloadOut)
    message.setProperty("s4_id",returnOrderId)
    return message;
}
