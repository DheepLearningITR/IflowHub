import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*
import groovy.transform.Field
import groovy.json.*

def recursivelyRemoveEmpties(item) {
  switch(item) {
    case Map:
      return item.collectEntries { k, v ->
        [k, recursivelyRemoveEmpties(v)]
      }.findAll { k, v -> v }

    case List:
      return item.collect { 
        recursivelyRemoveEmpties(it) 
      }.findAll { v -> v }

    default: 
      return item
  }
}

def Message processData(Message message) {
    def date = new Date();
    JsonBuilder builder = new JsonBuilder();

    def input_body = new XmlParser().parseText(message.getBody(String.class))
    def batch_nodes = input_body.'**'.findAll{it.name() == 'batchQueryPartResponse'}
    def odata_body = batch_nodes[0].body.A_CustomerReturn.A_CustomerReturnType
    def senderSystem = message.getProperty('senderSystem')
    def receiverSystem = message.getProperty('receiverSystem')
    def c4cId = message.getProperty('c4cId')
    def jsonString = message.getProperty('itemUUIDMap')
    def itemUUIDMap = new JsonSlurper().parseText(jsonString) as Map


    def itemList = []
    batch_nodes[1].body.A_CustomerReturnItem.A_CustomerReturnItemType.each{item->
        def itemMap = [
            "id" : item.CustomerReturnItem.text(),
            "receiverId" : itemUUIDMap[item.CustomerReturnItem.text()],
            "rmaNumber" : item.CustRetMatlAuthzn.text(),
        ]
        itemList << itemMap 
    }
    
    def appStatus
    switch(odata_body.SalesDocApprovalStatus.text()){
        case 'A':
            appStatus = "IN_APPROVAL"
            break
        case 'C':
            appStatus = "REJECTED"
            break
        case 'B':
            appStatus = "RELEASED"
            break
        case 'D':
            appStatus = "TO_BE_REWORKED"
            break
        default:
            break
    }
    
    def refunStatus 
    switch(odata_body.RetsMgmtCompnProcgStatus.text()){
        case "4":
            refunStatus = "WITH_ERRORS"
            break
        case "3":
            refunStatus = "WAITING_FOR_CREDIT_MEMO"
            break
        case "1":
            refunStatus = "PARTIALLY_PROCESSED"
            break
        case "0":
            refunStatus = "OPEN"
            break
        case "2":
            refunStatus = "COMPLETE"
            break
        default:
            break
    }
    
    def procStatus 
    switch(odata_body.RetsMgmtProcessingStatus.text()){
        case "1":
            procStatus = "COMPLETE"
            break
        case "0":
            procStatus = "OPEN"
            break
        case "2":
            procStatus = "WITH_ERRORS"
        default:
            break
    }
    
    def cancStatus
    switch(odata_body.OverallSDDocumentRejectionSts.text()){
        case "A":
            cancStatus = "NOTHING_CANCELLED"
            break
        case "B":
            cancStatus = "PARTIALLY_CANCELLED"
            break
        case "C":
            cancStatus = "EVERYTHING_CANCELLED"
            break
        default:
            break
    }

    builder{
        messageHeader{
            id java.util.UUID.randomUUID()
            senderCommunicationSystemDisplayId senderSystem
            receiverCommunicationSystemDisplayId receiverSystem
            creationDateTime date.format("yyyy-MM-dd'T'HH:mm:ss'Z'")
        }
         messageRequests ([{
            messageHeader{
                messageEntityName "sap.crm.returnorderservice.entity.returnOrderConfirmationMessageIn"
                actionCode "CONFIRM"
                id java.util.UUID.randomUUID()
            }
            body{
                receiverDisplayId c4cId
                displayId odata_body.CustomerReturn.text()
                approvalStatus(appStatus)
                refundStatus(refunStatus)
                processingStatus(procStatus)
                cancellationStatus(cancStatus)
                documentCurrency(odata_body.TransactionCurrency.text())
                items itemList
                totalValues{
                    netAmount{
                        content(odata_body.TotalNetAmount.text())
                        currencyCode(odata_body.TransactionCurrency.text())
                    }
                }
            }
        }])
    }
    
    def json = new JsonSlurper().parseText(builder.toString());
    json = recursivelyRemoveEmpties(json);
    def outPayload = JsonOutput.prettyPrint(JsonOutput.toJson(json));
    message.setHeader("referenceMessageRequestId",message.getProperty("SAP_ApplicationID"));
    message.setHeader("isConfirmationMessage",true);
    message.setProperty("CustomerReturnId", odata_body.CustomerReturn.text());
    message.setBody(outPayload)
    return message;
}