import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def salesOrderPayload = new JsonSlurper().parse(message.getBody(java.io.Reader)).value
    def salesOrderId = salesOrderPayload.externalId.displayId
    def itemUUIDMap = [:]
    def itemMap = [:]
    salesOrderPayload.items.each{item->
        itemMap[item.id] = item.lineNumber
    }
    message.setProperty("itemMap", itemMap)
    message.setProperty("salesOrderId", salesOrderId)

    def payloadIn = new JsonSlurper().parseText(message.getProperty("payload_in"))
    def header = payloadIn.messageHeader
    def actionCode = payloadIn.messageRequests[0].body.receiverDisplayId ? "SAVE" : "CREATE"
    payloadIn = payloadIn.messageRequests[0].body

    def soldToParty = payloadIn.individualCustomer ? payloadIn.individualCustomer.receiverDisplayId : (payloadIn.account ? payloadIn.account.receiverDisplayId : null)

    def payload_out = new NodeBuilder().A_CustomerReturn{
        A_CustomerReturnType{
            CustomerReturn()
            CustomerReturnType(payloadIn.returnOrderType)
            SalesOrganization(payloadIn.businessArea.receiverSalesOrganisationId)
            DistributionChannel(payloadIn.businessArea.distributionChannel)
            OrganizationDivision(payloadIn.businessArea.division)
            SalesGroup(payloadIn.businessArea.receiverSalesGroupId)
            SalesOffice(payloadIn.businessArea.receiverSalesOfficeId)
            SoldToParty(soldToParty)
            SenderBusinessSystemName(header.senderCommunicationSystemDisplayId)
            CustomerReturnDate(payloadIn.customerReturnDate)
            SDDocumentReason(payloadIn.returnReason)
            ReferenceSDDocument(salesOrderId)
            ReferenceSDDocumentCategory("C")
        }
    }

    def item_out
    def item_payload_out = new NodeBuilder().to_Item{}
    def refundType
    payloadIn.items.each{item-> 
        itemUUIDMap[item.lineNumber.toString()] = item.id.toString()
        refundType = item.refundType == "CREDIT_MEMO" ? "":"1"
        item_out = new NodeBuilder().A_CustomerReturnItemType{
            CustomerReturn()
            CustomerReturnItem(item.lineNumber)
            Material(item.product.receiverDisplayId)
            RequestedQuantity(item.returnQuantity.content)
            RequestedQuantityUnit(item.returnQuantity.uomCode)
            ReturnReason(item.itemReturnReason)
            ReturnsRefundType(refundType)
            ReturnsRefundRjcnReason(item.itemCancellationReason)
            ReferenceSDDocumentItem(itemMap[item.referenceItem])
            ReferenceSDDocument(salesOrderId)
            if (refundType == "1") {
                ReplacementMaterial(item.replacementProduct.receiverDisplayId)
                ReplacementMaterialQuantity(item.returnQuantity.content)
                ReplacementMaterialQtyUnit(item.returnQuantity.uomCode)
            }
        }
        item_payload_out.append(item_out)
    }
    payload_out.find {it.name() == "A_CustomerReturnType"}.children().add(0, item_payload_out)

    def party 
    def partner_out
    def partner_payload_out = new NodeBuilder().to_Partner{}

    party = payloadIn.billToIndividualCustomer ? payloadIn.billToIndividualCustomer.receiverDisplayId : (payloadIn.billToAccount ? payloadIn.billToAccount.receiverDisplayId : null)
    if(party != null){
        partner_out = new NodeBuilder().A_CustomerReturnPartnerType{
            PartnerFunction("BP")
            Customer(party)
        }
        partner_payload_out.append(partner_out)
    }

    party = payloadIn.payerIndividualCustomer ? payloadIn.payerIndividualCustomer.receiverDisplayId : (payloadIn.payerAccount ? payloadIn.payerAccount.receiverDisplayId : null)
        if(party != null){
        partner_out = new NodeBuilder().A_CustomerReturnPartnerType{
            PartnerFunction("PY")
            Customer(party)
        }
        partner_payload_out.append(partner_out)
    }

    party = payloadIn.shipToIndividualCustomer ? payloadIn.shipToIndividualCustomer.receiverDisplayId : (payloadIn.shipToAccount ? payloadIn.shipToAccount.receiverDisplayId : null)
        if(party != null){
        partner_out = new NodeBuilder().A_CustomerReturnPartnerType{
            PartnerFunction("SH")
            Customer(party)
        }
        partner_payload_out.append(partner_out)
    }

    party = payloadIn.contact ? payloadIn.contact.receiverDisplayId : null
    if(party != null){
        partner_out = new NodeBuilder().A_CustomerReturnPartnerType{
            PartnerFunction("CP")
            Customer(party)
        }
        partner_payload_out.append(partner_out)
    }
    payload_out.find {it.name() == "A_CustomerReturnType"}.children().add(0, partner_payload_out)


    def parsed_payload_out = new XmlParser().parseText(groovy.xml.XmlUtil.serialize(payload_out))
    def emptyNodes = parsed_payload_out.'**'.findAll{it.name() && it.text()=='null'}
    def removeNode = {
        node ->
        def parent = node.parent()
        parent.remove(node)
    }
    emptyNodes.each{removeNode(it)}
    
    String serialised_payload_out = groovy.xml.XmlUtil.serialize(parsed_payload_out)
    serialised_payload_out = serialised_payload_out.replaceFirst(/<\?xml[^>]*\?>/, "").trim()
    message.setBody(serialised_payload_out)
    message.setProperty("createBody", serialised_payload_out)
    message.setProperty("senderSystem", header.receiverCommunicationSystemDisplayId)
    message.setProperty("receiverSystem", header.senderCommunicationSystemDisplayId)
    message.setProperty("c4cId", payloadIn.displayId)
    message.setProperty("actionCode", actionCode)
    message.setProperty("itemUUIDMap", new groovy.json.JsonBuilder(itemUUIDMap).toString())
    return message
}