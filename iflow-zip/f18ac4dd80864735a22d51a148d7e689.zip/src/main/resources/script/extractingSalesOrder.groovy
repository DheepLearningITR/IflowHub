import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def payloadIn = new JsonSlurper().parse(message.getBody(java.io.Reader))
    payloadIn = payloadIn.messageRequests[0].body
    message.setProperty("salesOrderId",payloadIn.referenceDocument.id)
    def items = []
    
    payloadIn.items.each{item->
        items.add(item.referenceItem)
    }
    message.setProperty("items",items)
    return message
}