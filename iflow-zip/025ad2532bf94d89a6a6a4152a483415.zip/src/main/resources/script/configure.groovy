
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.pd.BinaryData;
def Message processData(Message message) {

       def endpoint_id = message.getProperty("ENDPOINT_ID");

       def PD_NAMESPACE = "DME_Generic_Processing_${endpoint_id}";
       def service = ITApiFactory.getService(PartnerDirectoryService.class, null);

       if (service == null){
              throw new IllegalStateException("Partner Directory Service not found");
       }

       copy_single_parameter("DME_INT_URL", "COMMON_DME_INT_URL", PD_NAMESPACE, message, service);
       copy_single_parameter("DME_IDENTITY_ZONE_SUBDOMAIN", "COMMON_DME_IDENTITY_ZONE_SUBDOMAIN", PD_NAMESPACE, message, service);

       return message;
}

def void copy_single_parameter(String propname, String pdname, String pid, def message, def service) {

       def VALUE1 = service.getParameter(pdname, pid, String.class);
       message.setProperty(propname, VALUE1 );

}