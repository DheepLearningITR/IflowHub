/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()

*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Calendar.*;
import groovy.xml.*;
import com.sap.it.api.ITApiFactory; 
import com.sap.it.api.securestore.SecureStoreService; 
import com.sap.it.api.securestore.UserCredential; 
import groovy.json.JsonSlurper
 
def Message SetStatus(Message message) {
    def map = message.getProperties();
    def id = map.get("ConversationId");
    def send = map.get("SendComRegno") as String;
   
    def body = message.getBody(java.lang.String) as String;
    
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body);
    
   if(object.ResultDataSet.Table.size == 0){
       message.setProperty("edoc_status",'02');
   }else{
    
        def dti_status = object.ResultDataSet.Table[0].DTI_STATUS as String;
        def nts_send_status = object.ResultDataSet.Table[0].NTS_SEND_STATUS as String;
        def nts_result_code = object.ResultDataSet.Table[0].NTS_RESULT_CODE as String;
        def IssueID = object.ResultDataSet.Table[0].ISSUE_ID as String;
        def Resultmessage = object.ResultMessage as String;
        message.setProperty("IssueID", IssueID);

    switch (dti_status) {
        case 'I': 
            switch (nts_send_status) {  
                case '3': 
                   message.setProperty("edoc_status",'04'); //NTS Check error
                   
                   if(nts_result_code != null && nts_result_code.length() > 0)
                   { Resultmessage = Resultmessage + ' with NTS_RESULT_CODE ' + nts_result_code ;}
                   
                   message.setProperty("resultmessage",Resultmessage); //Received by ASP
                   break
                case '9': 
                   message.setProperty("edoc_status",'01'); //Received by ASP
                   message.setProperty("resultmessage",Resultmessage); //Received by ASP
                 break
                case '7': 
                  message.setProperty("edoc_status",'05'); //Completed     
                  message.setProperty("resultmessage",Resultmessage); //Received by ASP
                  break
                case '0': 
                  message.setProperty("edoc_status",'05'); //Completed     
                  message.setProperty("resultmessage",Resultmessage); //Received by ASP
                  break          
//              default: message.setProperty("edoc_status",'01') ;
         }
         break;
        case ' ': 
            message.setProperty("edoc_status",'02'); //Smart Bill Check error
            message.setProperty("resultmessage",Resultmessage); //Received by ASP
                break;
        case 'R': 
            message.setProperty("edoc_status",'03'); //Rejected by Customer
            message.setProperty("resultmessage",Resultmessage); //Received by ASP
                break;
        case 'C':
            
            message.setProperty("edoc_status",'06'); //Rejected by Customer
            message.setProperty("resultmessage",Resultmessage); //Received by ASP
            
            switch (nts_send_status) {  
                case '3': 
                   message.setProperty("edoc_status",'04'); //NTS Check error
                   message.setProperty("resultmessage",Resultmessage); //Received by ASP
                   break
                case '7': 
                  message.setProperty("edoc_status",'05'); //Completed     
                  message.setProperty("resultmessage",Resultmessage); //Received by ASP
                  break
                case '0': 
                  message.setProperty("edoc_status",'05'); //Completed     
                  message.setProperty("resultmessage",Resultmessage); //Received by ASP
                  break          
//              default: message.setProperty("edoc_status",'01') ;
            }
             break;
        case 'W':
            message.setProperty("edoc_status",'07'); //canceled by purchaser
            message.setProperty("resultmessage",Resultmessage); //Received by ASP
            break;
        case 'T':
            message.setProperty("edoc_status",'08'); //rejected by supplier
            message.setProperty("resultmessage",Resultmessage); //Received by ASP
            break;
        case 'V':
            message.setProperty("edoc_status",'09'); //selfbilling initial status
            message.setProperty("resultmessage",Resultmessage); //Received by ASP
            break;
    }
   
    return message;
   }
}

def Message SetProperty(Message message) {
       //Properties 
       def map = message.getProperties();
       def value = map.get("MessageId");
       def pool = ['a'..'z','A'..'Z',0..9,'-'].flatten()
       def Random rand = new Random(System.currentTimeMillis())
       def RandomChars = (0..35).collect { pool[rand.nextInt(pool.size())] }
       def MessageID = RandomChars.join()
       message.setProperty("MessageId", MessageID);

       def now = new Date()
       message.setProperty("Timestamp", now.format("yyyyMMdd", TimeZone.getTimeZone('Asia/Seoul'))); 

       def body = message.getBody(java.lang.String) as String;       
       def Sender = map.get("SendComRegno") as String;
       def documentid = map.get("ConversationId") as String;
       
      
       Sender = documentid.substring(0,10);
       def body_parse = new XmlSlurper().parseText(body)
       def bookId = body_parse.'**'.find { Attributes ->Attributes.FieldName.text() == 'SCENARIO'};
       
       if(bookId != null){ 
           if(bookId.FieldValue.text() == 'SFP'){
           Sender = documentid.substring(10,20);
           message.setProperty("is_SFP", 'X');}
       }
       
       def service = ITApiFactory.getApi(SecureStoreService.class, null); 
       def CredentialName = "edoc_kr_smartbill_token_"+Sender;
       def credential = service.getUserCredential(CredentialName ); 
       if (credential == null){ throw new IllegalStateException("No credential found for alias" + CredentialName ); }
       String token = new String(credential.getPassword()); 
      
       message.setProperty("SendComRegno", Sender);
       message.setProperty("AuthToken", token);

       return message;
       
}


def Message LogResponse(Message message) {
    def map = message.getProperties();
    def id = map.get("ConversationId");
    def log = map.get("EnableLog");
    def send = map.get("SendComRegno") as String;
   // def rec = map.get("ReceiveComRegno")as String;
   
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body);
    
   if(object.ResultDataSet.Table == null){
        message.setProperty("edoc_status",'02');
        def Resultmessage = object.ResultMessage as String;
        def messageLog = messageLogFactory.getMessageLog(message);
    	if(messageLog != null && log == 'X')
        {messageLog.addAttachmentAsString('dti', Resultmessage, "text/plain");}
        message.setProperty("resultmessage", Resultmessage);
   }
    return message;
}
