/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def map = message.getProperties();
    def id = map.get("ConversationId");
    def send = map.get("SendComRegno") as String;
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body);
    def edoc_status = map.get("edoc_status");
    
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null)
        messageLog.addAttachmentAsString("edoc_status", edoc_status, "text/plain")

   if(object.ResultDataSet.Table.size == 0){
       message.setProperty("edoc_status",'02');
   }else{
    
    def list = object.ResultDataSet.Table;
    
    switch(edoc_status)
    {
        case '03':
            def Resultmessage = list.find{it -> it.DTI_STATUS == 'T'}.REASON as String;
            message.setProperty("edoc_status",'03'); //Rejected by supplier
            message.setProperty("resultmessage",Resultmessage);
            break;
        case '07':
            def Resultmessage = list.find{it -> it.DTI_STATUS == 'O'}.REASON as String;
            message.setProperty("edoc_status",'07'); //canceled by purchaser
            message.setProperty("resultmessage",Resultmessage);
            break;
        case '08':
            def Resultmessage = list.find{it -> it.DTI_STATUS == 'T'}.REASON as String;
            message.setProperty("edoc_status",'08'); //Rejected by supplier
            message.setProperty("resultmessage",Resultmessage);
            break;
        case '09':
            def Resultmessage = list.find{it -> it.DTI_STATUS == 'V'}.REASON as String;
            message.setProperty("edoc_status",'09'); //Rejected by supplier
            message.setProperty("resultmessage",Resultmessage);
            break;
    }
     
    
   }
   
    return message;
}