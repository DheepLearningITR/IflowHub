import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Map;
import java.util.List;
import java.util.HashMap;
import groovy.transform.Field;
import java.lang.Exception;
import java.text.Normalizer;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import java.net.URI;

public interface eFacturaMessageProperty {
	
	String TAX_ID                  = 'TAX_ID';
	String keyAliasSuffix          = 'KeyAliasSuffix';
	String addTaxidtoKeyAlias      = 'addTaxidtoKeyAlias';
	String privateKeyAlias         = 'privateKeyAlias';

};

public interface eFacturaExceptionPrefix {
	String config = 'eFactura integration flow configuration error: ';
	String process = 'SII integration flow processing error: '
};

public interface eFacturaBoolean {
	String Yes = 'yes';	
	String No  = 'no';	
};


// aliases

@Field addTaxidAliasMap = 
[
	(eFacturaBoolean.Yes) : [  "YES" ],
	(eFacturaBoolean.No) : [  "NO" ]
];

def String getNormalizedName( String alias, Map map ) {
    	
	def aliasLc = Normalizer.normalize( alias ? alias : "", Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "").toLowerCase();
    return map.find{ prop -> prop.key.equalsIgnoreCase( aliasLc) ||  prop.value.contains( aliasLc ) }?.key;
}

def Message setupConfiguration( Message message ) {
    
    

def props = message.getProperties();
	
//Add dynamic private key alias
    def TAX_ID = props.get( eFacturaMessageProperty.TAX_ID );
    def kSuffix = props.get( eFacturaMessageProperty.keyAliasSuffix );	
    def addtaxid = props.get( eFacturaMessageProperty.addTaxidtoKeyAlias );	
    def addtaxid_normalized = ' ';
    
   
   addtaxid_normalized = getNormalizedName( addtaxid, addTaxidAliasMap );
    
    if ( addtaxid_normalized == '' )
		throw new Exception( eFacturaExceptionPrefix.config + 'Add TAX_ID to private key Alias cannot be empty');
    
   if( addtaxid_normalized == eFacturaBoolean.No ) {

     message.setProperty( eFacturaMessageProperty.privateKeyAlias, kSuffix ); 
      }
      else{
      
     message.setProperty( eFacturaMessageProperty.privateKeyAlias, kSuffix + '_' + TAX_ID.toLowerCase()  ); //TAX_ID
      }
      
      return message;
}
