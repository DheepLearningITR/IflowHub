import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def headers = message.getHeaders()
    def eventType = message.getProperty("eventType")
    if (eventType != null) eventType = eventType.toLowerCase()

    def sapMessage, code, body = "", isItemUpdated, isHeaderUpdated

    switch(eventType) {
        case "servicecall.updated":
        case "activities.updated":
        case "activities.released":
        case "activity.completed":
        default:
            headers.put("CamelHttpResponseCode", 202)
            message.setBody("")
            break
    }
    return message
}