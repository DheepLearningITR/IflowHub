import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import com.sap.gateway.ip.core.customdev.util.Message

// routes
/*def clearRoute(message) {
    message.setProperty("doUpdateHeader", "")
    message.setProperty("doCompleteItem", "")
    message.setProperty("doUpdateItem", "")
}
def setRouteIrrelevant(Message message) {
    clearRoute(message)
}
def setRouteUpdateHeader(message) {
    clearRoute(message)
    message.setProperty("doUpdateHeader", "X")
}
def setRouteCompleteItem(message) {
    clearRoute(message)
    message.setProperty("doCompleteItem", "X")
}
def setRouteUpdateItem(message) {
    clearRoute(message)
    message.setProperty("doUpdateItem", "X")
}*/

def Map setReferenceObject(message, equipmentNode) {
    Map ReferenceObject = [:]
    def ref_object = equipmentNode?.externalId
    def ref_object_category = equipmentNode?.objectCategory
    def isUpdated = false
    def NewEquipment = ""
    def NewFunctionalLocation = ""
    if (equipmentNode) {
        if (ref_object) {
            if (ref_object_category == null || ref_object_category == 'EQ') {
                //message.setProperty("NewEquipment", ref_object)
                //message.setProperty("NewFunctionalLocation", "")
                NewEquipment = ref_object
                isUpdated = true
            } else if (ref_object_category == 'FLOC') {
                //message.setProperty("NewEquipment", "")
                //message.setProperty("NewFunctionalLocation", ref_object)
                NewFunctionalLocation = ref_object
                isUpdated = true
            }
        } else { // empty node -> delete
            //message.setProperty("NewEquipment", "")
            //message.setProperty("NewFunctionalLocation", "")
            isUpdated = true
        }
    } else { // null node -> delete
        //message.setProperty("NewEquipment", "")
        //message.setProperty("NewFunctionalLocation", "")
        isUpdated = true
    }
    ReferenceObject['isUpdated'] = isUpdated
    ReferenceObject['NewEquipment'] = NewEquipment
    ReferenceObject['NewFunctionalLocation'] = NewFunctionalLocation
    return ReferenceObject
}

def setResultJsonAndBody(message, resultJson) {
    message.setBody(resultJson.toString())
    message.setProperty("resultJson",resultJson.toString())
}

// returns a map of external Ids by splitting the provided string extId at the slash (/)
def Map getExternalIds(String extId, String fallbackServiceOrder=null) {
    Map extIds = [:]
    List splitIds = []
    if (extId != null && extId.size() > 0) {
        splitIds = extId.split('/')
        extIds['ServiceOrder'] = splitIds[0]
        if (splitIds.size() > 1) {
            extIds['ServiceOrderItem'] = splitIds[-1]
            if (splitIds.size() == 3) {
                extIds['ServiceOrderBundleItem'] = splitIds[-2]
            }
        }
    }
    if ((extIds['ServiceOrder'] == null || extIds['ServiceOrder'] == '') 
        && (fallbackServiceOrder != null || fallbackServiceOrder != '' ) ) {
        extIds['ServiceOrder'] = fallbackServiceOrder
    }
    return extIds
}

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def sourcePayload = body
    def parser = new JsonSlurper()
    def parserResult = parser.parseText(body)
	def serviceOrder = message.getHeaders().get("ServiceOrder") ?: ''
	def fallbackServiceOrder = parserResult?.data?.serviceCall?.unifiedIdentifier?.externalId as String

    def validActivities = parserResult?.data?.serviceCall?.activities.findAll { it.Irrelevant != 'X' && it.checkErrorOccured != 'X' }
	def resultMap = [:]
    resultMap."ServiceOrder" = serviceOrder
    if (validActivities.size() > 0) {
		resultMap["ServiceOrderItems"] = ["ServiceOrderItemEntity":[]]
    }
    def ServiceOrderItemEntityNodes = []

    //process each activity
    validActivities.eachWithIndex { act, index ->        
        def currentServiceOrderItemEntity = [:]
		def responsibles, executingServiceEmployee;
		def isHeaderUpdated              = false
		def isItemUpdated                = false
		def isItemReferenceObjectUpdated = false
		def isReferenceObjectUpdated     = false
		def isResponsibleUpdated         = false
		def serviceOrderNeedsUpdate      = false
	
		// Text Handling for header and Item
		def isHeaderRemarkUpdated      = false
		def isHeaderResolutionUpdated  = false
		def isHeaderTextUpdated        = false
		def isItemRemarkUpdated        = false
	
		def ServiceOrderItemEntity = [[:]]
		def ServiceOrderItemTexts = [[:]]
		def ServiceOrderItemTextEntity = [[:]] 
	
		// get external ids from message header		
		externalId = act?.externalId as String
        externalIds = getExternalIds(externalId, fallbackServiceOrder)
        def serviceOrderItem = externalIds["ServiceOrderItem"] ?: ''
		def serviceOrderBundleItem = externalIds["ServiceOrderBundleItem"] ?: ''
		def serviceOrderParentItem = externalIds["ServiceOrderBundleItem"] ?: externalIds["ServiceOrderItem"] ?: ''
		def eventType = message.getHeaders().get("EventType") ?: ''
	
		message.setProperty("eventType", eventType)
		message.setProperty("ServiceOrder", serviceOrder)
	
		def isHeaderExtensionEnabled = (message.getProperty("HeaderExtensionEnabled") ==~ /(?i)(true|x)/);
		def isExtensionEnabled = (message.getProperty("extensionEnabled") ==~ /(?i)(true|x)/);
		def isAcceptWorkflowStepEnabled = (message.getProperty("AcceptWorkflowStepChange") ==~ /(?i)(true|x)/);
	
		switch (eventType) {
			case "activities.updated":
        		def updatedProperty, plannedServiceStartDateTime, plannedServiceEndDateTime, executionStatus = "";
				float plannedDuration
	
				updatedProperty = act.updatedProperty
				plannedServiceStartDateTime = act.plannedStartDate
				plannedServiceEndDateTime = act.plannedEndDate	
				
				if (serviceOrderItem != null) {                                        
					currentServiceOrderItemEntity."ServiceOrderItem" = serviceOrderItem
					currentServiceOrderItemEntity."FSMServiceActivity" = act.code;
				}
				if (updatedProperty.contains("plannedStartDate") && plannedServiceStartDateTime != null) {
					currentServiceOrderItemEntity."PlannedServiceStartDateTime" = plannedServiceStartDateTime
					isItemUpdated = true
				}
				if (updatedProperty.contains("plannedEndDate") && plannedServiceEndDateTime != null) {
					currentServiceOrderItemEntity."PlannedServiceEndDateTime" = plannedServiceEndDateTime
					isItemUpdated = true
				}
				if (updatedProperty.contains("plannedDurationInMinutes") && act?.plannedDurationInMinutes != null) {
					plannedDuration = Math.round(act?.plannedDurationInMinutes / 60 * 100) / 100
					currentServiceOrderItemEntity."ActualServiceDuration" = plannedDuration
					isItemUpdated = true
				}
				if (updatedProperty.contains("subject") && act.subject != null) {
					currentServiceOrderItemEntity."ServiceOrderItemDescription" = act.subject.take(40)
					isItemUpdated = true
				}
				if (updatedProperty.contains("contact") && act?.contact?.externalId != null) {
					currentServiceOrderItemEntity."ContactPersonBusinessPartnerId" = act.contact.externalId
					isItemUpdated = true
				} else if (updatedProperty.contains("contact") && act?.contact?.externalId == null){
					//send empty contact to delete contact in S4
					currentServiceOrderItemEntity."ContactPersonBusinessPartnerId" = ""
					isItemUpdated = true
				}
				if (updatedProperty.contains("equipment")) {
					ItemReferenceObjectInfo = setReferenceObject(message, act?.equipment)                    
                    isItemReferenceObjectUpdated = ItemReferenceObjectInfo["isUpdated"]
                    currentServiceOrderItemEntity."NewEquipment" = ItemReferenceObjectInfo["NewEquipment"]
                    currentServiceOrderItemEntity."NewFunctionalLocation" = ItemReferenceObjectInfo["NewFunctionalLocation"]
				}
				
				if (updatedProperty.contains("responsibles")) {
					responsibles = act?.responsibles
					if (responsibles && responsibles.size() > 0) {
						executingServiceEmployee = responsibles[0]?.externalId
					} else {
						executingServiceEmployee = null;
					}
					currentServiceOrderItemEntity."ExecutingServiceEmployee" = executingServiceEmployee;
					isItemUpdated = true
				}
				
				if (updatedProperty.contains("workflowStep") && isAcceptWorkflowStepEnabled) {
					isItemUpdated = true
				}
				
				//update Execution Status?
				if (act?.statusChangeReason == "UNASSIGN") {
					executionStatus = "02";
					isItemUpdated = true;
				} else if (updatedProperty.contains("status") && act.status != null) {
					if (act.status == "CLOSED" && act.executionStage == "CANCELLED") {
						executionStatus = "07";
						isItemUpdated = true;
					} else if (act.status == "CLOSED" && act.executionStage == "CLOSED") {
						executionStatus = "06";
						isItemUpdated = true;
					}
				}
				
				//* Transfer text elements
				if (updatedProperty.contains("remarks")) {
					ServiceOrderItemTextEntity[0].LongText                    = act.remarks
					ServiceOrderItemTextEntity[0].LongTextType                = "Remarks"
					isItemRemarkUpdated = true
				}
				if (isItemRemarkUpdated == true) {
					ServiceOrderItemTexts[0].ServiceOrderItemTextEntity       = ServiceOrderItemTextEntity
					ServiceOrderItemEntity[0].ServiceOrderItemTexts           = ServiceOrderItemTexts
					currentServiceOrderItemEntity."ServiceOrderItemTexts" = ServiceOrderItemTexts
				}
	
				currentServiceOrderItemEntity."updateItemExecutionStatus" = executionStatus
				currentServiceOrderItemEntity."isItemUpdated" = isItemUpdated
				currentServiceOrderItemEntity."isItemReferenceObjectUpdated" = isItemReferenceObjectUpdated
				currentServiceOrderItemEntity."isItemRemarkUpdated" = isItemRemarkUpdated
	
				if (isItemUpdated || isItemRemarkUpdated || isItemReferenceObjectUpdated || isExtensionEnabled) {
					currentServiceOrderItemEntity."doUpdateHeader" = ""
                    currentServiceOrderItemEntity."doCompleteItem" = ""
                    currentServiceOrderItemEntity."doUpdateItem" = "X"
                    message.setProperty("doUpdateItem","X")
				} else {
					currentServiceOrderItemEntity."doUpdateHeader" = ""
                    currentServiceOrderItemEntity."doCompleteItem" = ""
                    currentServiceOrderItemEntity."doUpdateItem" = ""
				}
				break
	
			case "activities.released":
				def plannedServiceStartDateTime, plannedServiceEndDateTime, plannedDurationInMinutes
				float plannedDuration
	
				responsibles = act?.responsibles
				if (responsibles && responsibles.size() > 0) {
					executingServiceEmployee = responsibles[0]?.externalId
				}
				plannedServiceStartDateTime = act?.plannedStartDate
				plannedServiceEndDateTime = act?.plannedEndDate
				plannedDurationInMinutes = act?.plannedDurationInMinutes

				if (serviceOrderItem != null) {
                    //resultMap["ServiceOrderItems"]["ServiceOrderItemEntity"].add(currentServiceOrderItemEntity)
					currentServiceOrderItemEntity."ServiceOrderItem" = serviceOrderItem
					currentServiceOrderItemEntity."FSMServiceActivity" = act.code;
				}
				if (executingServiceEmployee != null) {
					currentServiceOrderItemEntity."ExecutingServiceEmployee" = executingServiceEmployee
					isItemUpdated = true
				}
				if (plannedServiceStartDateTime != null) {
					currentServiceOrderItemEntity."PlannedServiceStartDateTime" = plannedServiceStartDateTime
					isItemUpdated = true
				}
				if (plannedServiceEndDateTime != null) {
					currentServiceOrderItemEntity."PlannedServiceEndDateTime" = plannedServiceEndDateTime
					isItemUpdated = true
				}
				if (plannedDurationInMinutes != null) {
					plannedDuration = Math.round(plannedDurationInMinutes / 60 * 100) / 100
					currentServiceOrderItemEntity."ActualServiceDuration" = plannedDuration
					isItemUpdated = true
				}
				if (act.subject != null) {
					currentServiceOrderItemEntity."ServiceOrderItemDescription" = act.subject.take(40)
					isItemUpdated = true
				}
				if (act?.contact?.externalId != null) {
					currentServiceOrderItemEntity."ContactPersonBusinessPartnerId" = act.contact.externalId
					isItemUpdated = true
				}
				if (act?.equipment) {
					ItemReferenceObjectInfo = setReferenceObject(message, act?.equipment) 
                    isItemReferenceObjectUpdated = ItemReferenceObjectInfo["isUpdated"]
                    currentServiceOrderItemEntity."NewEquipment" = ItemReferenceObjectInfo["NewEquipment"]
                    currentServiceOrderItemEntity."NewFunctionalLocation" = ItemReferenceObjectInfo["NewFunctionalLocation"]
				} else {
					isItemReferenceObjectUpdated = true // empty equipment could be a deletion
				}
				//* Transfer text elements
				if (act.remarks != null) {
					ServiceOrderItemTextEntity[0].LongText                    = act.remarks
					ServiceOrderItemTextEntity[0].LongTextType                = "Remarks"
					isItemRemarkUpdated = true
				}
				if (isItemRemarkUpdated == true) {
					ServiceOrderItemTexts[0].ServiceOrderItemTextEntity       = ServiceOrderItemTextEntity
					ServiceOrderItemEntity[0].ServiceOrderItemTexts           = ServiceOrderItemTexts
					currentServiceOrderItemEntity."ServiceOrderItemTexts" = ServiceOrderItemTexts
				}
				
				//released event shall set Execution Status "In Execution"
				currentServiceOrderItemEntity."updateItemExecutionStatus" = "04";	
				currentServiceOrderItemEntity."isItemUpdated" = isItemUpdated;
				currentServiceOrderItemEntity."isItemReferenceObjectUpdated" = isItemReferenceObjectUpdated
				currentServiceOrderItemEntity."isItemRemarkUpdated" = isItemRemarkUpdated
	
				if (isItemUpdated || isItemRemarkUpdated || isItemReferenceObjectUpdated || isExtensionEnabled) {
					currentServiceOrderItemEntity."doUpdateHeader" = ""
                    currentServiceOrderItemEntity."doCompleteItem" = ""
                    currentServiceOrderItemEntity."doUpdateItem" = "X"
                    message.setProperty("doUpdateItem","X")
				} else {
					currentServiceOrderItemEntity."doUpdateHeader" = ""
                    currentServiceOrderItemEntity."doCompleteItem" = ""
                    currentServiceOrderItemEntity."doUpdateItem" = ""
				}
				break
	
	
			default:
				// route: Irrelevant, ignore, no error
				currentServiceOrderItemEntity."doUpdateHeader" = ""
                currentServiceOrderItemEntity."doCompleteItem" = ""
                currentServiceOrderItemEntity."doUpdateItem" = ""
				break
   

		}

        ServiceOrderItemEntityNodes.add(currentServiceOrderItemEntity)
    }


    resultMap["ServiceOrderItems"]["ServiceOrderItemEntity"].add(ServiceOrderItemEntityNodes)
    resultMap = ["root":resultMap]
    setResultJsonAndBody(message, JsonOutput.toJson(resultMap))
    message.setProperty("SourcePayload", sourcePayload)
    return message
}