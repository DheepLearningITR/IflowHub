import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.gateway.ip.core.customdev.util.Message;


Message getFromValueMapping(Message message) {    
    
    // Event Type Mapping
    def eventTypeProperty = message.getProperty("EventType")
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def s4EventType = valueMapApi.getMappedValue("CGTO", 
                                                "EventType", 
                                                eventTypeProperty, 
                                                "S4", 
                                                "EventType")
    
    if (s4EventType == null) {
         message.setProperty("EventTypeValueMapping", "InvalidEvent")
    } else {
        message.setProperty("EventTypeValueMapping", s4EventType)
    }
    
    // Shipment Reason Mapping
    def shptReasonCodeProperty = message.getProperty("ReasonCode")
    def s4ShptReasonCode = valueMapApi.getMappedValue("CGTO", 
                                                "ShipmentReasonCode", 
                                                shptReasonCodeProperty, 
                                                "S4", 
                                                "ShipmentReasonCode")
    
    if (s4ShptReasonCode == null) {
         message.setProperty("ShptReasonCodeValueMapping", shptReasonCodeProperty)
    } else {
        message.setProperty("ShptReasonCodeValueMapping", s4ShptReasonCode)
    }
    
    return message
    
}
