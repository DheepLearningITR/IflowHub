
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message inputPayload(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);


    if(messageLog != null){
        messageLog.addAttachmentAsString("Input Payload", body , "text/plain");
     }

    return message;
}

def Message saveOutputPayload(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);


    if(messageLog != null){
        messageLog.addAttachmentAsString("BA Output Payload", body , "text/plain");
     }

    return message;
}

