/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;

import java.util.HashMap;
import java.io.*;
import java.nio.*;
import java.util.*;

import groovy.util.*;
import groovy.xml.*;
import groovy.json.*;

import org.apache.camel.CamelContext;
import org.apache.commons.io.IOUtils;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType
import org.apache.http.conn.params.ConnRoutePNames;


def Message processRequest(Message message) {
    def checkPayload = checkFileExtension(message);
    if (checkPayload == true){
        def body = message.getBody(String.class);   
        def jsonSlurper = new JsonSlurper()
        def payload = jsonSlurper.parseText(body)
        def datasetId = payload.datasetId;
        def modelTemplateId = payload.modelTemplateId;
        def modelName = payload.modelName;
        checkPayload = "false";
        
        if (datasetId && datasetId.length()>0 && modelTemplateId && modelTemplateId.length()>0 && modelName && modelName.length()>0){
            checkPayload = "true";
            message.setProperty("datasetId", datasetId);
            message.setProperty("modelTemplateId", modelTemplateId);
            message.setProperty("modelName", modelName);
        }

    }



    message.setProperty("checkPayload", checkPayload);

    return message;
}


def Message processTokenResponse(Message message) {
    
    def body = message.getBody(String.class);    
    def jsonSlurper = new JsonSlurper()
    def responsePayload = jsonSlurper.parseText(body)
    def token = responsePayload.access_token;
    def tokenWithType = "Bearer " + token;
    message.setProperty("Authorization", tokenWithType);
     return message;
}

def Message createJob(Message message) {
    def sURL = message.getProperty("DAR_Base_URL")+"/model-manager/api/v3/jobs/";
    def payload = message.getBody(String.class);

    //build URL
    HttpPost request = new HttpPost(sURL);
    
    def StringEntity entity = new StringEntity(payload,ContentType.APPLICATION_JSON)
    request.setEntity(entity);

    //set token    
    String DOCXOAuthToken = message.getProperties().get('Authorization');
    request.setHeader("Authorization", DOCXOAuthToken);
    request.setHeader("Content-Type", "application/json");

    //execute request
    HttpClient client = new DefaultHttpClient();
    HttpResponse response = client.execute(request);
    // Get the response
    BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
    StringBuffer sb = new StringBuffer();
    String line = "";
    while ((line = rd.readLine()) != null) {
            sb.append(line);
    }

    message.setBody(sb.toString());
    return message;
}

def boolean checkFileExtension(Message message){
    
    def map = message.getHeaders();
	def fileName = map.get("CamelFileNameOnly");
    message.setProperty("fileName", fileName);
    def fileCheck = false;

	def parts = fileName.split('\\.');
	//check fileName structure
	if (parts.length > 1 && parts[parts.length-1]=="json") {
       fileCheck = true;
	}
    return fileCheck;
}

def Message deployModel(Message message) {
    def sURL = message.getProperty("DAR_Base_URL")+"/model-manager/api/v3/deployments/";
    def payload = message.getBody(String.class);

    //build URL
    HttpPost request = new HttpPost(sURL);
    
    def StringEntity entity = new StringEntity(payload,ContentType.APPLICATION_JSON)
    request.setEntity(entity);

    //set token    
    String DOCXOAuthToken = message.getProperties().get('Authorization');
    request.setHeader("Authorization", DOCXOAuthToken);
    request.setHeader("Content-Type", "application/json");

    //execute request
    HttpClient client = new DefaultHttpClient();
    HttpResponse response = client.execute(request);
    // Get the response
    BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
    StringBuffer sb = new StringBuffer();
    String line = "";
    while ((line = rd.readLine()) != null) {
            sb.append(line);
    }

    message.setBody(sb.toString());
    return message;
}



def Message processCreateJobResponse(Message message){
    def body = message.getBody(String.class);    
    def jsonSlurper = new JsonSlurper()
    def responsePayload = jsonSlurper.parseText(body)
    def id = responsePayload.id;
    def status = responsePayload.status;
    if (id){
         message.setProperty("jobId",id);
    }else{
        message.setProperty("jobId","ERROR");
    }
   
    message.setProperty("jobStatus",status);

    return message;
}

def Message processCreateJobStatusResponse(Message message){
    def body = message.getBody(String.class);    
    def jsonSlurper = new JsonSlurper()
    def responsePayload = jsonSlurper.parseText(body)
    def status = responsePayload.status;
    message.setProperty("jobStatus",status)
    if (status == "RUNNING" || status=="PENDING"){
        Thread.sleep(60000);
    }

    return message;
}

def Message processDeploymentCreationResponse(Message message){
    def body = message.getBody(String.class);    
    def jsonSlurper = new JsonSlurper()
    def responsePayload = jsonSlurper.parseText(body)
    def id = responsePayload.id;
    def status = responsePayload.status;
    if (id){
         message.setProperty("deploymentId",id);
    }else{
        message.setProperty("deploymentId","ERROR");
    }
   
    message.setProperty("deploymentStatus",status);

    return message;
}

def Message processDeploymentSatusResponse(Message message){
    def body = message.getBody(String.class);    
    def jsonSlurper = new JsonSlurper()
    def responsePayload = jsonSlurper.parseText(body)
    def status = responsePayload.status;
    message.setProperty("deploymentStatus",status)
    if (status == "PENDING"){
        Thread.sleep(45000);
    }

    return message;
}
