import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
def Message processData(Message message) {
      def body = message.getBody();
      map = message.getProperties();
      
      String objectId = new String (map.get("ObjectID"));
      
      StringBuilder reverseObjectId = new StringBuilder(objectId).reverse();
      
      String SESType = new StringBuilder(reverseObjectId.substring(8,10)).reverse().toString();
      
      message.setProperty("SESType",SESType);
      
      return message;
}