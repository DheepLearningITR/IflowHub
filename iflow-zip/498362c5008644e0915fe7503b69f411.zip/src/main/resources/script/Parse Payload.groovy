import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def map = message.getProperties();
    def update_unplanned_item = map.get("Update_Unplanned_Item");
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    
    if ((object.eventType == "activity.confirmed" || object.eventType == "activity.completed") && update_unplanned_item.toLowerCase() == 'yes')
    {
        message.setProperty("serviceType", "ServiceProcessing");
        if (object.eventType == "activity.completed")
            message.setProperty("CheckoutReport", "True");
    }
    else if (object.eventType == "activity.confirmed" || object.eventType == "activity.completed")
    {
        message.setProperty("serviceType", "ServiceConfirmation");
        if (object.eventType == "activity.completed")
            message.setProperty("CheckoutReport", "True");
    }
    else if (object.eventType == "activity.created" && object.data.serviceCall.activity.sourceActivity != null)
    {
        message.setProperty("ActivityDuplicate", "X");
    }
    else if (object.eventType == "servicecall.created")
    {
        message.setProperty("serviceType", "ServiceOrder");
    }
    
    message.setProperty("Event_Type", object.eventType);
    return message;
}
