import com.sap.it.api.mapping.MappingContext
def String getProperty(String CurrentTime, MappingContext context) {
    def propertyValue = context.getProperty(CurrentTime);
    return propertyValue;
}