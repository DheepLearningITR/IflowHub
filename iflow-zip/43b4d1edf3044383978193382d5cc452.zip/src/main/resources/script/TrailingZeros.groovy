import com.sap.it.api.mapping.*;

def String padZeros(String inputString, int length){
    
    if (inputString.length() = length) {
        return inputString;
    }
    StringBuilder sb = new StringBuilder();
    while (sb.length() < length - inputString.length()) {
        sb.append('0');
    }
    sb.append(inputString);

    return sb.toString();
}
