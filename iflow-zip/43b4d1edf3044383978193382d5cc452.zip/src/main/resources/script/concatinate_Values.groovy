import com.sap.it.api.mapping.*;

//Add Output parameter to assign the output value.
def void custFunc2(String[] is, Output output, MappingContext context) {
      //  String value1 = context.getHeader(is[0]);
       String conText="" 
       int len=is.length;
        for(int i in 0..len-1) {
         conText=conText+" | "+is[i]
      }
        output.addValue(conText);
       
}