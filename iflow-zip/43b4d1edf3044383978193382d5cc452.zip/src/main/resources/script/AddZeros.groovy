import com.sap.it.api.mapping.*;
def String rightPadding(String input){
    if(input.length()<10)
    {
        output="0";
            for(int i=1;i<10-input.length();i++)
                {
                output="0"+output;
                }
             output=input+output;
    }
    else
       {
        return input;
      }
    return output;
}