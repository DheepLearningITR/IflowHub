import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.ITApiFactory
import java.io.ByteArrayInputStream

def Message processData(Message message){
    
    def service_order_ids = message.getProperty("create_list");
    
    // Get the persisted byte[] from property
    byte[] payloadBytes = message.getProperty("P_OriginalPayload") as byte[]

    // Wrap the byte[] in a ByteArrayInputStream
    def inputStream = new ByteArrayInputStream(payloadBytes)
    // parse the input stream
	def root = new XmlSlurper().parse(inputStream);
	
	String sender = message.getProperty("Conf_Sender")
	Node Ref_Node
	Node output_node = new NodeBuilder().batchParts{
	   }
	   
	//creating the body for create query 
	root.ServiceRequestFollowUpDocumentsReplicateRequestMessage.ServiceRequest.each{
	    if (service_order_ids.contains(it.ID.text())){
	        String party = it.Party.findAll({node -> node.RoleCode.text().equals("1001")}).ReceiverPartyID.text()
	        String shipto = it.Party.findAll({node -> node.RoleCode.text().equals("1005")}).ReceiverPartyID.text()
	        String emp = it.Party.findAll({ node -> node.RoleCode.text().equals("40")}).ReceiverPartyID.text()
	        
	        //mapping the priority
	        String priority = it.ServiceTerms.PriorityCode.text()
	        def description = it.Name.text().take(40)
	        def request_start = it.TicketTimeline.RequestedStart.text()
	        request_start = request_start[0..-2]
	        def request_end = it.TicketTimeline.RequestedEnd.text()
	        request_end = request_end[0..-2]
	        def reference_service = sender+ "#" + it.ID.text()
	        def language = it.Name[0].@languageCode.text()
	        def salesOrg = it.BusinessArea.ReceiverSalesOrganisationID.text()
	        def distChannel = it.BusinessArea.DistributionChannelCode.text()
	        def division = it.BusinessArea.DivisionCode.text()
	        
	        
	        //getting the ServiceObjectType value from valuemapping 
	       // def c4c_type= it.ProcessingTypeCode.text()
	       // def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
            def value = "SRVO" //valueMapApi.getMappedValue('C4C', 'ProcessingTypeCode', c4c_type, 'S4', 'ServiceObjectType')
            
           
            
	        Ref_Node= new NodeBuilder().batchChangeSet{
					batchChangeSetPart{
						method("POST")
						uri('A_ServiceOrder')
						A_ServiceOrder{
							A_ServiceOrderType{
								ServiceOrderType(value)
								ServiceOrderDescription(description)
								ServiceDocumentPriority(priority)
								RequestedServiceStartDateTime(request_start)
								RequestedServiceEndDateTime(request_end)
								SoldToParty(party)
								ShipToParty(shipto)
								ReferenceServiceOrder(reference_service)
								SalesOrganization(salesOrg)
								DistributionChannel(distChannel)
								Division(division)
								link{
                                    to_Text{
                                        A_ServiceOrderTextType{
                                            Language(language)
                                        }
                                    }
								}
							}
						}
					}
	        }
	        
	        if(emp){
                def party_node = new NodeBuilder().to_Partner{
                    A_SrvcOrdPartnerType{
                        ServiceOrder()
                        CustMgmtPartnerFunction("00000014")
                        CustMgmtBusinessPartner(emp)
                        CustMgmtPartnerIsMainPartner(true)
			        }
			    }
               Ref_Node.find { it.name() == 'batchChangeSetPart' }
                                       ?.find { it.name() == 'A_ServiceOrder' }
                                       ?.find { it.name() == 'A_ServiceOrderType' }.children().add(0, party_node)
            }

            def notesBuilder = new NodeBuilder().to_Text{}
            
            def descNode = new NodeBuilder().A_ServiceOrderTextType{
                Language(language)
                LongText(description)
            }
            notesBuilder.append(descNode)

            it.TextCollection.Text.each{ 
                def textField = it
                if(textField.TypeCode.text() == '10011'){
                    def notesNode = new NodeBuilder().A_ServiceOrderTextType{
                        Language(language)
                        LongText(textField.ContentText.text())
                        LongTextID("S001")
                    }
                    notesBuilder.append(notesNode)
                }
            }

                Ref_Node.find { it.name() == 'batchChangeSetPart' }
                                       ?.find { it.name() == 'A_ServiceOrder' }
                                       ?.find { it.name() == 'A_ServiceOrderType' }.children().add(0,notesBuilder)
            

            def referenceProductNode = new NodeBuilder().to_ReferenceObject{}
            def productNode = new NodeBuilder().to_ProductReferenceObject{}
            def Rcount = 0 
            def Pcount = 0
            it.ServiceReferenceObjects.each{
                def refObject = it 
                if(refObject.InstallationPointTypeCode.text() == "2"){
                    //registered product
                    Rcount = Rcount + 1
                    def mainIndi = refObject.MainIndicator.text() == "false" ? "" : "X"
                    def regNode = new NodeBuilder().A_ServiceOrderRefObjectType{
                        ServiceOrder()
                        ServiceReferenceEquipment(refObject.ExternalID.text())
                        SrvcRefObjIsMainObject(mainIndi)
                    }
                    referenceProductNode.append(regNode)
                }
                else{
                    if(refObject?.MaterialKey?.ExternalID){
                        //product mapping
                        Pcount = Pcount +1 
                        def proNode = new NodeBuilder().A_SrvcOrdProdRefObjectType{
                            ServiceOrder()
                            ServiceReferenceProduct(refObject.ExternalID.text())
                        }
                        productNode.append(proNode)
                    }
                }
            }
            
            if(Pcount>0){
                Ref_Node.find { it.name() == 'batchChangeSetPart' }
                                       ?.find { it.name() == 'A_ServiceOrder' }
                                       ?.find { it.name() == 'A_ServiceOrderType' }.children().add(0,productNode)
            }

            if(Rcount > 0){
                Ref_Node.find { it.name() == 'batchChangeSetPart' }
                                       ?.find { it.name() == 'A_ServiceOrder' }
                                       ?.find { it.name() == 'A_ServiceOrderType' }.children().add(0,referenceProductNode)
            }
            
	        output_node.append(Ref_Node)
	    }
		
	}
	    
	//setting body for the batch post 
    String outxml = groovy.xml.XmlUtil.serialize( output_node )
    message.setBody(outxml)
    
    message.setProperty("SAP_BatchLineSeparator","CRLF")
	
	return message 

}
