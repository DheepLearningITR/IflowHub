import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*


def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def rootNode = new XmlSlurper().parseText(body)
    Integer updateLoopIndex

    def S4PCWBSList = []
    //def projectCode = rootNode.A_EnterpriseProjectType.Project.text()
    //S4PCWBSList << projectCode

    rootNode.A_EnterpriseProjectType.to_EnterpriseProjectElement.A_EnterpriseProjectElementType.each { childElementType ->
    def projectElementValue = childElementType.ProjectElement.text()
            S4PCWBSList << projectElementValue
        }

    updateLoopIndex = S4PCWBSList.size()
    message.setProperty("S4PCWBSList", S4PCWBSList)
    message.setProperty("updateLoopIndex", updateLoopIndex)
    return message

}
