/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;
import groovy.xml.*;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties();
    //def wbsPayload = properties.get("WBSPayload");
    def jsonSlurper = new JsonSlurper();
   // def jsonObject = jsonSlurper.parseText(body);
   // def root = new XmlSlurper().parseText(body);
  //  String projectInternalID = root.Project_Type.ProjectInternalID.text();
    def wbsRoot = new XmlSlurper().parseText(body);
    def stringWriter = new StringWriter();
    def wbsBuilder = new MarkupBuilder(stringWriter);
    def level4WBSCode = []
    
    def level4WBSCount = wbsRoot.A_EnterpriseProjectElementType.to_SubProjElement.A_EnterpriseProjectElementType.size();
    def level4WBSCheck = false;
    if(level4WBSCount > 0){
        level4WBSCheck = true;
        wbsRoot.A_EnterpriseProjectElementType.to_SubProjElement.A_EnterpriseProjectElementType.each{ level4Info ->
        level4WBSCode.add(level4Info.ProjectElement.text());
        }
    }
    
    def level3Index = level3WBSCode.size();
    
    wbsBuilder.WBSElement{
        wbsRoot.A_EnterpriseProjectElementType.each{ baseInfo ->
        def wbsCode = baseInfo.ProjectElement.text();
        def wbsDescription = baseInfo.ProjectElementDescription.text();
        def companyCode = baseInfo.CompanyCode.text();
        def profitCenter = baseInfo.ProfitCenter.text();
        def WBSIsStatistical = baseInfo.WBSIsStatisticalWBSElement.text();
        def responsibleCC = baseInfo.ResponsibleCostCenter.text();
        def plant = baseInfo.Plant.text();
        def currency = baseInfo.Currency.text();
        "WBSElement_Type"{
            "WBSElementExternalID"(wbsCode)
            "WBSElementShortID"(wbsCode)
            "ProjectInternalID"(projectInternalID)
            "WBSDescription"(wbsDescription)
           // "ApplicantCode"("0")
            "CompanyCode"(companyCode)
            "RespCostCenterControllingArea"("BP01")
            "ReqgCostCenterControllingArea"("BP01")
            //"FunctionalArea"("30040")
           // "ResponsiblePerson"("1")
           // "ResponsiblePersonName"("Bill Ramsey")
            "ProfitCenter"(profitCenter)
            "ResponsibleCostCenter"(responsibleCC)
           // "CostCenter"(responsibleCC)
            "RequestingCostCenter"(responsibleCC)
            "Plant"(plant)
            "Currency"(currency)
            "FreeDefinedTableFieldSemantic"("FMG0001")
            "FreeDefinedAttribute01"("Sustaining")
            "FreeDefinedAttribute02"("Ignore")
            "FreeDefinedAttribute03"("FortPeople")
            "FreeDefinedAttribute04"("InfraServ")
            }
        };
        
    }
    
    def xmlTarget = stringWriter.toString();
    message.setBody(xmlTarget);
    message.setProperty("level4WBSCode", level4WBSCode);
    message.setProperty("level4Index", level4Index);
    return message;
}