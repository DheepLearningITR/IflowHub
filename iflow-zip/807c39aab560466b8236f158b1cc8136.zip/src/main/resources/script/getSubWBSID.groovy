/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def properties = message.getProperties();
    def listS4PCWBSElement = properties.get("listS4PCWBSElement");
    def level2WBSList = properties.get("level2WBSList");
    Integer loopIndex = properties.get("loopIndex");
    def listInterS4PCWBSCode = []
    def subWBSElement;
    def InternalID;
    def level1Check = true;
    
    loopIndex = loopIndex - 1;
        
    if(level2WBSList.size() > 0){
        subWBSElement = level2WBSList[loopIndex];
        level1Check = false;
        
    }else{
        subWBSElement = listS4PCWBSElement[loopIndex].subWBSCode;
        InternalID = listS4PCWBSElement[loopIndex].wbsCode;
    }
   
    message.setProperty("loopIndex", loopIndex);
    message.setProperty("level2WBSElement", subWBSElement);
    message.setProperty("WBSElementID", InternalID);
    message.setProperty("level1Check", level1Check);
    return message;
}