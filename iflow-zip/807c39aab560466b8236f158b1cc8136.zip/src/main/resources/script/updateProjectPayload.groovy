/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties();
    def externalNumber = properties.get("externalNumber");
    def projectCurrency = properties.get("projectCurrency");
    //def wbsPayload = properties.get("WBSPayload");
    def stringWriter = new StringWriter();
    def root = new XmlSlurper().parseText(body);
    def projectBuilder = new MarkupBuilder(stringWriter);
    def projectID = root.A_EnterpriseProjectType.Project.text();
    def projectDescr = root.A_EnterpriseProjectType.ProjectDescription.text();
    def companyCode = root.A_EnterpriseProjectType.CompanyCode.text();
    //def controllingArea = root.WBSElementReplicationRequestMessage.WBSElement[0].ControllingArea.text();
    def profitCenter = root.A_EnterpriseProjectType.ProfitCenter.text();
   // def wbsIsStatistical = root.A_EnterpriseProjectType.WBSIsStatisticalWBSElement.text();
    def plant = root.A_EnterpriseProjectType.Plant.text();
    def currency = root.A_EnterpriseProjectType.ProjectCurrency.text();
    //def FunctionalArea = root.WBSElementReplicationRequestMessage.WBSElement[0].FunctionalArea.text();
    def processingStatus = root.A_EnterpriseProjectType.ProcessingStatus.text();
    def statusCode;
    
    switch(processingStatus){
        case "00": statusCode = "13"  //CREATED
        break
        case "10": statusCode = "14" //RELEASED
        break
        case "42": statusCode = "10" //CLOSED
        default:
            statusCode = "13"
        }
    
    projectBuilder.Project_Type{
       // "Project_Type"{
            "ProjectExternalID"(projectID)
            "ProjectDescription"(projectDescr)
            "ProjectProfileCode"("FMGPC01")
            "WBSStatusProfile"("FMG00001")
            //"WBSIsMarkedForIntegratedPlng"(true)
            "CompanyCode"(companyCode)
            "ControllingArea"("BP01")
            "ProfitCenter"(profitCenter)
            //"WBSIsStatisticalWBSElement"(wbsIsStatistical)
            //"StatusCombinationCode"(statusCode)
            "Plant"(plant)
            "ResponsiblePerson"("1")
            "ResponsiblePersonName"("Bill Ramsey")
            if(currency.toString().equals("")){
                //"Currency"(projectCurrency)
            }else{
            "Currency"(currency)
            }
            "FunctionalArea"("30040")
            "PlanningMethForProjBasicDate"("2")
            "FreeDefinedTableFieldSemantic"("FMG0001")
            if(!externalNumber.toString().equals("")){
            "FreeDefinedAttribute01"(externalNumber)
            }else{
            "FreeDefinedAttribute01"("Sustaining")
            }
           // "FreeDefinedAttribute02"("Ignore")
            "FreeDefinedAttribute02"(statusCode)
            "FreeDefinedAttribute03"("FortPeople")
            "FreeDefinedAttribute04"("InfraServ")
       // }
        
    }
    
    def xmlTarget = stringWriter.toString();
    message.setBody(xmlTarget);
    return message;
}