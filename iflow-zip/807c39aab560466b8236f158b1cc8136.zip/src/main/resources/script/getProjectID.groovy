import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*


def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def rootNode = new XmlSlurper().parseText(body)

    def project = rootNode.WBSElementGroup.WBSElement[0].Project.text()

    message.setProperty("ProjectExternalID", project)
    return message

}
