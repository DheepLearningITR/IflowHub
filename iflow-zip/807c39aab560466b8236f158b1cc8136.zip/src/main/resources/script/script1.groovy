import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*


def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def properties = message.getProperties();
    def level1WBSCode = properties.get("ProjectExternalID");
   // def rootNode = new XmlSlurper().parseText(parentPayload)

  //  def wbsElementID
  //  def parentCheck = false
  //  wbsElementID = rootNode.A_EnterpriseProjectElementType.to_ParentProjElement.A_EnterpriseProjectElementType.ProjectElement.text()
  //  Integer count = rootNode.A_EnterpriseProjectElementType.to_ParentProjElement.A_EnterpriseProjectElementType.size()

    message.setProperty("WBSElementID", level1WBSCode)
    return message

}
