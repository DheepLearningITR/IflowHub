import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*


def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def rootNode = new XmlSlurper().parseText(body)

    def WBSElement
    def proCheck = true
    def ProjectExternalID
    
    //final String processingStatus1 = '00'   //CREATED
    final String processingStatus2 = '10'   //RELEASED
    final String processingStatus3 = '42'  //CLOSED
    
    def filterClause = "and (ProcessingStatus eq '" + processingStatus2 + "'" + " or ProcessingStatus eq '" + processingStatus3 +"')" ;
    
    def projectID = rootNode.WBSElementGroup.ProjectInternalID.text()
    def project = rootNode.WBSElementGroup.WBSElement[0].Project.text()
    def String wbsElement = rootNode.WBSElementGroup.WBSElement[0].WBSElement.text()
    def projectCurrency = rootNode.WBSElementGroup.WBSElement[0].Currency.text()

    /*rootNode.WBSElementGroup.WBSElement.each { childElementType ->
    def wbsElementValue = childElementType.WBSElement.text()
        if (wbsElementValue.count('-') > 1) {
            // add value to list if the value includes two dashes
            WBSElement = wbsElementValue
        }else{
           WBSElement = wbsElementValue
           proCheck = false
            }
        } */
        

    message.setProperty("ProjectExternalID", project)
    message.setProperty("ProjectID", projectID)
    message.setProperty("WBSElementID", project)
    message.setProperty("WBSPayload", body)
    message.setProperty("filterClause", filterClause)
    message.setProperty("projectCurrency", projectCurrency)
    return message

}
