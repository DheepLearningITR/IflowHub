import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*


def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def rootNode = new XmlSlurper().parseText(body)

    def level2WBSList = []
    def subWBSCodeCheck = true

    rootNode.A_EnterpriseProjectType.to_EnterpriseProjectElement.A_EnterpriseProjectElementType.each { childElementType ->
    def projectElementValue = childElementType.ProjectElement.text()
    def processingStatus = childElementType.ProcessingStatus.text()
        if (projectElementValue.count('-') == 2){ // && (processingStatus == '00' || processingStatus == '10' || processingStatus == '42')) {
            // add value to list if the value includes two dashes
            level2WBSList << projectElementValue
            }
        }

    def loopIndex = level2WBSList.size();
    if(loopIndex == 0){
        subWBSCodeCheck = false
    }
    message.setProperty("level2WBSList", level2WBSList);
    message.setProperty("subWBSCodeCheck", subWBSCodeCheck);
    message.setProperty("loopIndex", loopIndex);
    return message

}
