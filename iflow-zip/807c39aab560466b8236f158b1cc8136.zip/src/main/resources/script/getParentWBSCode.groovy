import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*


def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
  //  def properties = message.getProperties();
   // def parentPayload = properties.get("ParentPayload");
    def rootNode = new XmlSlurper().parseText(body)

    def wbsElementID
    def parentCheck = false
    wbsElementID = rootNode.A_EnterpriseProjectElementType.to_ParentProjElement.A_EnterpriseProjectElementType.ProjectElement.text()
    Integer count = rootNode.A_EnterpriseProjectElementType.to_ParentProjElement.A_EnterpriseProjectElementType.size()
    if(count > 0){
        parentCheck = true
        //wbsElementID = rootNode.A_EnterpriseProjectElementType.to_ParentProjElement.A_EnterpriseProjectElementType.ProjectElement.text()
    }
    message.setProperty("WBSElementID", wbsElementID)
    message.setProperty("parentCheck", parentCheck)
    return message

}
