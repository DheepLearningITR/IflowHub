/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;
import groovy.xml.*;
import groovy.json.JsonSlurper;

class S4OPWBSCode{
    String wbsCode;
    String wbsElementInternalID;
    S4OPWBSCode(wbsCode,wbsElementInternalID){
        this.wbsCode = wbsCode;
        this.wbsElementInternalID = wbsElementInternalID;
    }
}
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties();
    def listS4OPWBSCode = properties.get("listS4OPWBSCode");
    def jsonSlurper = new JsonSlurper();
    def wbsRoot = jsonSlurper.parseText(body);
    def stringWriter = new StringWriter();
    def wbsBuilder = new MarkupBuilder(stringWriter);

    def Level2WBSElement = wbsRoot.WBSElementExternalID;
    def Level2WBSElementInternalID = wbsRoot.WBSElementInternalID;
   // if(listS4OPWBSCode.size() == 0 ){
    listS4OPWBSCode.add(new S4OPWBSCode(Level2WBSElement,Level2WBSElementInternalID));
   // }
    
    message.setProperty("listS4OPWBSCode", listS4OPWBSCode);
    message.setProperty("Level2WBSElementInternalID", Level2WBSElementInternalID);
    // message.setProperty("subWBSCheck", subWBSCheck);
    return message;
}