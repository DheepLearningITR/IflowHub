import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory

Message processData(Message message) {
 def properties = message.getProperties();
	int errorCount = 0;
	errorCount = errorCount + 1;
	String delay_c = properties.get("WBSCodeDelay");
	Integer delay = delay_c as Integer ;
    
    //Set delay
    sleep(delay);
    
    //Set Payload
    //message.setProperty("retryCounter", errorCount);
    return message;
}