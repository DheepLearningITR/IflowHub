/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {
    //def body = message.getBody(java.lang.String) as String;
    //def root = new XmlSlurper().parseText(body);
    def properties = message.getProperties();
    def externalNumber = properties.get("externalNumber");
    def wbsPayload = properties.get("WBSPayload");
    def processingStatus = properties.get("ProcessingStatus");
    def stringWriter = new StringWriter();
    def root = new XmlSlurper().parseText(wbsPayload);
    def projectBuilder = new MarkupBuilder(stringWriter);
    def projectID = root.WBSElementGroup.WBSElement[0].Project.text();
    def projectDescr = root.WBSElementGroup.WBSElement[0].WBSDescription.text();
    def companyCode = root.WBSElementGroup.WBSElement[0].CompanyCode.text();
    def profitCenter = root.WBSElementGroup.WBSElement[0].ProfitCenter.text();
   // def wbsIsStatistical = root.WBSElementReplicationRequestMessage.WBSElement[0].WBSIsStatisticalWBSElement.text();
    def plant = root.WBSElementGroup.WBSElement[0].Plant.text();
    def currency = root.WBSElementGroup.WBSElement[0].Currency.text();
    def statusCode;
    
    switch(processingStatus){
        case "00": statusCode = "13"  //CREATED
        break
        case "10": statusCode = "14" //RELEASED
        break
        case "42": statusCode = "10" //CLOSED
        default:
            statusCode = "13"
        }
    
    projectBuilder.Project{
        "Project_Type"{
            "ProjectExternalID"(projectID)
            "ProjectDescription"(projectDescr)
            "ProjectProfileCode"("FMGPC01")
            "WBSStatusProfile"("FMG00001")
            "WBSIsMarkedForIntegratedPlng"(true)
            "CompanyCode"(companyCode)
            "ControllingArea"("BP01")
            "ProfitCenter"(profitCenter)
            //"StatusCombinationCode"(statusCode)
           // "WBSIsStatisticalWBSElement"(wbsIsStatistical)
            "Plant"(plant)
            "ResponsiblePerson"("1")
            "ResponsiblePersonName"("Bill Ramsey")
            "Currency"(currency)
            "FunctionalArea"("30040")
            "FreeDefinedTableFieldSemantic"("FMG0001")
             if(!externalNumber.toString().equals("")){
            "FreeDefinedAttribute01"(externalNumber)
            }else{
            "FreeDefinedAttribute01"("Sustaining")
            }
            //"FreeDefinedAttribute02"("Ignore")
            "FreeDefinedAttribute02"(statusCode)
            "FreeDefinedAttribute03"("FortPeople")
            "FreeDefinedAttribute04"("InfraServ")
        }
    }
    
    def xmlTarget = stringWriter.toString();
    message.setBody(xmlTarget);
    return message;
}