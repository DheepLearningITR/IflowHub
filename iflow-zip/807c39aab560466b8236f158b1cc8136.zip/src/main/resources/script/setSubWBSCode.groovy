/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import javax.mail.util.ByteArrayDataSource;
import org.apache.camel.impl.DefaultAttachment;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;


def Message processData(Message message) {
    def properties = message.getProperties();
    def totalWBSCount = properties.get("totalWBSCount");
    def listS4PCWBSCode = properties.get("listS4PCWBSCode");
    def listS4OPWBSCode = properties.get("listS4OPWBSCode");
    //def listS4PCWBSElement = properties.get("listS4PCWBSElement");
    //def listS4OPWBSElement = properties.get("listS4OPWBSElement");
    def level2WBSList = properties.get("level2WBSList");
    def listS4PCWBSElement = [];
    def listS4OPWBSElement = [];
    def subWBSCheck = false;
    
      // trace start    
  /*  def targetSW2 = new StringWriter();
    def csvPrinter2 = new CSVPrinter(targetSW2, CSVFormat.DEFAULT);
      
    csvPrinter2.flush();
    for(int i=0;i<listS4PCWBSCode.size();i++){
        if(listS4PCWBSCode.get(i).wbsCode == 'C-PRG0BRA8-005-1'){
           // def dataSource = new ByteArrayDataSource(listS4PCWBSCode, 'Text/CSV'); //Set MIME type
           // def attachment = new DefaultAttachment(dataSource);
           // message.addAttachmentObject("S4PC WBS Code List.txt", attachment); 
         csvPrinter2.printRecord(
        "WBS Code" , "Sub WBS Code"
    );
           csvPrinter2.printRecord(
            listS4PCWBSCode.get(i).wbsCode,listS4PCWBSCode.get(i).subWBSCode //materialList[i].materialId
        );
        csvPrinter2.flush();
        }
    }
    
    csvPrinter2.close();
    def materialCodeList2 = targetSW2.toString();
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("[1]S4PC WBS Code List", materialCodeList2, "text/csv");
    
    
    def targetSW3 = new StringWriter();
    def csvPrinter3 = new CSVPrinter(targetSW3, CSVFormat.DEFAULT);
       
    csvPrinter3.flush();
    
    for(int j=0;j<listS4OPWBSCode.size();j++){
        if(listS4OPWBSCode.get(j).wbsCode == 'C-PRG0BRA8-005-1'){
           // def dataSource1 = new ByteArrayDataSource(listS4OPWBSCode, 'Text/CSV'); //Set MIME type
          //  def attachment1 = new DefaultAttachment(dataSource1);
          //  message.addAttachmentObject("S4OP WBS Code List.txt", attachment1);  
           csvPrinter3.printRecord(
        "WBS Code" , "WBS Element Internal ID"
    );
            csvPrinter3.printRecord(
            listS4OPWBSCode.get(j).wbsCode,listS4OPWBSCode.get(j).wbsElementInternalID //materialList[i].materialId
        );
        csvPrinter3.flush();
        }
    }
    csvPrinter3.close();
    def materialCodeList3 = targetSW3.toString();
    messageLog.addAttachmentAsString("[2]S4OP WBS Code List", materialCodeList3, "text/csv");
   // trace end 
   
   */
    
   // listS4PCWBSElement.clear();
    if(listS4PCWBSCode.size() > 0 ){
        listS4PCWBSElement.addAll(listS4PCWBSCode);
        subWBSCheck = true;
        listS4PCWBSCode.clear();
    }
    
    //listS4OPWBSElement.clear();
    if(listS4OPWBSCode.size() > 0 ){
        listS4OPWBSElement.addAll(listS4OPWBSCode);
        listS4OPWBSCode.clear();
    }
    
    /*
    // trace start    
    def targetSW = new StringWriter();
    def csvPrinter = new CSVPrinter(targetSW, CSVFormat.DEFAULT);
      
    csvPrinter.flush();
    for(int i=0;i<listS4PCWBSElement.size();i++){
        if(listS4PCWBSElement.get(i).wbsCode == 'C-PRG0BRA8-005-1'){
           // def dataSource = new ByteArrayDataSource(listS4PCWBSCode, 'Text/CSV'); //Set MIME type
           // def attachment = new DefaultAttachment(dataSource);
           // message.addAttachmentObject("S4PC WBS Code List.txt", attachment); 
         csvPrinter.printRecord(
        "WBS Code" , "Sub WBS Code"
    );
           csvPrinter.printRecord(
            listS4PCWBSElement.get(i).wbsCode,listS4PCWBSElement.get(i).subWBSCode //materialList[i].materialId
        );
        csvPrinter.flush();
        }
    }
    
    csvPrinter.close();
    def materialCodeList = targetSW.toString();
    //def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("[3]S4PC WBS Code List", materialCodeList, "text/csv");
    
    
    def targetSW1 = new StringWriter();
    def csvPrinter1 = new CSVPrinter(targetSW1, CSVFormat.DEFAULT);
       
    csvPrinter1.flush();
    
    for(int j=0;j<listS4OPWBSElement.size();j++){
        if(listS4OPWBSElement.get(j).wbsCode == 'C-PRG0BRA8-005-1'){
           // def dataSource1 = new ByteArrayDataSource(listS4OPWBSCode, 'Text/CSV'); //Set MIME type
          //  def attachment1 = new DefaultAttachment(dataSource1);
          //  message.addAttachmentObject("S4OP WBS Code List.txt", attachment1);  
           csvPrinter1.printRecord(
        "WBS Code" , "WBS Element Internal ID"
    );
            csvPrinter1.printRecord(
            listS4OPWBSElement.get(j).wbsCode,listS4OPWBSElement.get(j).wbsElementInternalID //materialList[i].materialId
        );
        csvPrinter1.flush();
        }
    }
    csvPrinter1.close();
    def materialCodeList1 = targetSW1.toString();
//    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("[4]S4OP WBS Code List", materialCodeList1, "text/csv");
   // trace end 
    */
    
    level2WBSList.clear();
    totalWBSCount = 0;
   
    message.setProperty("subWBSCheck", subWBSCheck);
    message.setProperty("listS4PCWBSElement", listS4PCWBSElement);
    message.setProperty("listS4OPWBSElement", listS4OPWBSElement);
    message.setProperty("listS4PCWBSCode", listS4PCWBSCode);
    message.setProperty("listS4OPWBSCode", listS4OPWBSCode);
    message.setProperty("totalWBSCount", totalWBSCount);
    
    return message;
}