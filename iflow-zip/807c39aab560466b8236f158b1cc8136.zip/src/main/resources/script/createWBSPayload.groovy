/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;
import groovy.xml.*;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties();
    def projectPayload = properties.get("projectPayload");
    def wbsPayload = properties.get("WBSPayload");
    def externalNumber = properties.get("externalNumber");
    def jsonSlurper = new JsonSlurper();
    def projectInternalID = properties.get("projectInternalID");
    def projectType = properties.get("EnterpriseProjectType");
    def wbsRoot = new XmlSlurper().parseText(projectPayload);
    def root = new XmlSlurper().parseText(wbsPayload);
    def stringWriter = new StringWriter();
    def wbsBuilder = new MarkupBuilder(stringWriter);
    def responsibleCC;
    def requestingCC;
    def statusCode;
    
    root.WBSElementGroup.WBSElement.each{ wbsInfo ->
    responsibleCC = wbsInfo.ResponsibleCostCenter[0].text();
    requestingCC = wbsInfo.RequestingCostCenter[0].text();
    }
    
    wbsBuilder.WBSElement{
        wbsRoot.Project_Type.each{ baseInfo ->
        def wbsCode = baseInfo.ProjectExternalID.text();
        def wbsDescription = baseInfo.ProjectDescription.text();
        def companyCode = baseInfo.CompanyCode.text();
        def profitCenter = baseInfo.ProfitCenter.text();
        def WBSIsStatistical = baseInfo.WBSIsStatisticalWBSElement.text();
        //def responsibleCC = baseInfo.ResponsibleCostCenter.text();
        def plant = baseInfo.Plant.text();
        def currency = baseInfo.Currency.text();
        def controllingArea = baseInfo.ControllingArea.text();
        def processingStatus = baseInfo.ProcessingStatus.text();
        
        switch(processingStatus){
            case "00": statusCode = "13"  //CREATED
            break
            case "10": statusCode = "14" //RELEASED
            break
            case "42": statusCode = "10" //CLOSED
            default:
            statusCode = "13"
        }
        
        "WBSElement_Type"{
            "WBSElementExternalID"(wbsCode)
            "WBSElementShortID"(wbsCode)
            "ProjectInternalID"(projectInternalID)
            "WBSDescription"(wbsDescription)
           // "ApplicantCode"("0")
            "CompanyCode"(companyCode)
            "ControllingArea"(controllingArea)
           // "StatusCombinationCode"(statusCode)
            "RespCostCenterControllingArea"("BP01")
            "ReqgCostCenterControllingArea"("BP01")
            if(!projectType.toString().equals("")){
            "ProjectType"(projectType)
            }
            "ProfitCenter"(profitCenter)
           "ResponsibleCostCenter"(responsibleCC)
           // "CostCenter"(responsibleCC)
            "RequestingCostCenter"(requestingCC)
            "Plant"(plant)
            "Currency"(currency)
            "FreeDefinedTableFieldSemantic"("FMG0001")
            if(!externalNumber.toString().equals("")){
            "FreeDefinedAttribute01"(externalNumber)
            }else{
            "FreeDefinedAttribute01"("Sustaining")
            }
            "FreeDefinedAttribute02"("Ignore")
            "FreeDefinedAttribute03"("FortPeople")
            "FreeDefinedAttribute04"("InfraServ")
            }
        };
        
    }
    
    def xmlTarget = stringWriter.toString();
    message.setBody(xmlTarget);
    return message;
}