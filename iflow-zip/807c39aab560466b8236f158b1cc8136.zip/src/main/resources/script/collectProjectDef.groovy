import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*
import groovy.util.*

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def xml = new XmlSlurper().parseText(body);

// traverse WBSElement
def groupedElements = xml.WBSElementReplicationRequestMessage.WBSElement.groupBy { it.ProjectInternalID.text() }

// Gneerate new XML 
    def writer = new StringWriter()
    def resultXml = new MarkupBuilder(writer)
    
     resultXml.WBSElementMasterDataReplicationBulkRequest {
    groupedElements.each { projectInternalID, elements ->
        WBSElementGroup {
            ProjectInternalID(projectInternalID)
            elements.each { element ->
                WBSElement {
                    Project(element.Project.text())
                    WBSElement(element.WBSElement.text().replaceAll("\\s", ""))
                    WBSElementShortID(element.WBSElement.text().replaceAll("\\s", ""))
                    WBSDescription(element.Description.text())
                    CompanyCode(element.CompanyCode.text())
                    ResponsibleCostCenter(element.ResponsibleCostCenter.text())
                    RequestingCostCenter(element.ResponsibleCostCenter.text())
                    ProfitCenter(element.ProfitCenter.text())
                    Plant(element.Plant.text())
                    Currency(element.Currency.text())
                    ProcessingStatus(element.ProcessingStatus.text())
                }
            }
        }
    }
}

    def xmlTarget = writer.toString()
    message.setBody(xmlTarget)
    return message
}