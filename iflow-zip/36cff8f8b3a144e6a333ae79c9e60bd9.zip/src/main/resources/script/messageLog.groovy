import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData_getRCRelationship(Message message) { 
    def map = message.getProperties();
    property_EnableErrorLogOnly = map.get("EnableErrorLogOnly");
    property_EnableAllLog = map.get("EnableAllLog");
    if (property_EnableAllLog.toUpperCase().equals("TRUE") && (!property_EnableErrorLogOnly.toUpperCase().equals("TRUE"))) {
        def body = message.getBody(java.lang.String) as String;
        def messageLog = messageLogFactory.getMessageLog(message);

        if (messageLog != null) {
            messageLog.addAttachmentAsString(" SBRelationships_get_response", body, "text/json");
        }
    }
    return message;
}

def Message processData_S4_Inbound(Message message) {
	map = message.getProperties();
	property_EnableErrorLogOnly = map.get("EnableErrorLogOnly");
	property_EnableAllLog = map.get("EnableAllLog");
	if (property_EnableAllLog.toUpperCase().equals("TRUE") && (!property_EnableErrorLogOnly.toUpperCase().equals("TRUE"))) {
		def body = message.getBody(java.lang.String) as String;
		def businessRelationship = new XmlSlurper().parseText(body);
		def businessPartnerIntId = businessRelationship.BusinessPartnerRelationshipSUITEReplicateRequestMessage.BusinessPartnerRelationship.BusinessPartnerInternalID as String;
		def relationshipBPIntId = businessRelationship.BusinessPartnerRelationshipSUITEReplicateRequestMessage.BusinessPartnerRelationship.RelationshipBusinessPartnerInternalID as String;
		def messageLog = messageLogFactory.getMessageLog(message);
		
		if (messageLog != null) {
				messageLog.addAttachmentAsString("SBRelationships(" + businessPartnerIntId + "_" + relationshipBPIntId + ")_S4_structure_req", body, "text/xml");
			}
	}
	return message;
}