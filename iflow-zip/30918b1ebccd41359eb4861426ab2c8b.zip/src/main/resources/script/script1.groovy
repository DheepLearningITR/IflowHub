import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

/********************************************/
/***  Check External Quote Id from SCPI  ***/
/********************************************/
    
def Message processData(Message message) {
  

    def properties = message.getProperties() as Map<String, Object>;
	def externalQuoteId = properties.get("externalQuoteId");
	def quoteId = properties.get("quoteId");
	
	if(externalQuoteId == null || externalQuoteId == ""){
	    externalQuoteId = quoteId;
	}
   
    message.setProperty("externalQuoteId", externalQuoteId);

   return message;
  
}