import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
		def apiMethod = message.getProperties().get("apiMethod");
		def apiPath = message.getProperties().get("apiPath");
		if(apiPath!=null){
			messageLog.addCustomHeaderProperty("cbr_api", apiMethod+' '+apiPath);		
        	}
	}
	return message;
}
