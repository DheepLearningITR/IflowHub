import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message check_jsonResponse(Message message) {
	
	def body = message.getBody(java.io.Reader);
    def parsedJson = new JsonSlurper().parse(body);

    //add top-level "data" element if it doesn't exist (e.g. JobArchitecture API)
    if (!(parsedJson instanceof Map)) {  //for arrays without top-level 'data' element, add element
        parsedJson = [data: parsedJson] 
    } else if (!parsedJson.containsKey('data')) { //non-arrays without top-level 'data' element, add element
        parsedJson = [data: parsedJson]  
    }

    message.setBody(JsonOutput.toJson(parsedJson)); 
	return message;
}