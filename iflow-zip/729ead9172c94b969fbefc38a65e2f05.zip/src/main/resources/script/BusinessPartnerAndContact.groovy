import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def map = message.getProperties();
    def valueContact = map.get("Contact");
    def valueContactActual = map.get("ContactActual");
    def IbaseNumber=map.get("ParentId");
    def payload=map.get("ForwardIBaseAddress");
    def valueBusiness = map.get("BusinessPartner");
    def valueBusinessActual = map.get("BusinessPartnerActual");
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    def query = new XmlSlurper().parseText(payload);
    def jobjectmain=jsonObject.find{element-> element.externalId==IbaseNumber}
    
    if(valueBusinessActual!="none"){
        String businessactual='{ '+'''"externalId" : "'''+valueBusinessActual+'''"}'''; 
        def jsonObjectBusinessactual = jsonParser.parseText(businessactual);
        jobjectmain.put("businessPartner", jsonObjectBusinessactual);
    }
    
    if(valueContactActual!="none"){
        String contactactual='{ '+'''"externalId" : "'''+valueContactActual+'''"}'''; 
        def jsonObjectContactactual = jsonParser.parseText(contactactual);
        jobjectmain.put("contact", jsonObjectContactactual);
    }
    
    query.IDOC.E101CRMXIF_IBASE.E101MXIF_IBASE_COMPONENT_XT.E101CRMXIF_IBASE_COMPONENT.each{component->
        def jobject = jsonObject.find{element-> element.externalId==component.INSTANCE.text()};
        
        component.E101CRMXIF_IBASE_PARTNER_XT.E101CRMXIF_IBASE_PARTNER.each{partner->
             if(partner.PARTNER_FUNCTION.text() == valueBusiness && partner.MAIN_PARTNER.text() == "X"&& partner.OBJECT_TASK.text() == "C"){
                 String business = '{ '+'''"externalId" : "'''+partner.PARTNER_NO+'''"}'''; 
                 def jsonObjectBusiness = jsonParser.parseText(business);
                 jobject.put("businessPartner",jsonObjectBusiness);
             }
             if(partner.PARTNER_FUNCTION.text() == valueContact && partner.MAIN_PARTNER.text() == "X" && partner.OBJECT_TASK.text() == "C"){
                 String contact = '{ '+'''"externalId" : "'''+partner.PARTNER_NO+'''"}'''; 
                 def jsonObjectContact = jsonParser.parseText(contact); 
                 jobject.put("contact",jsonObjectContact);
             }
        }
    }
    
    def Instance = map.get("ArrayListInstance");
    def Parent = map.get("ArrayListParent");
    String value = "";
    String newJson = "[ ]";
    def jsonSlurper = new JsonSlurper();
    def newJsonObject = jsonSlurper.parseText(newJson);
    def result = jsonObject.find{it.externalId.equals(IbaseNumber)};
    newJsonObject.add(result);
        
    for(int i=0;i<Instance.size();i++){
        def caught = jsonObject.find{it.externalId==Instance[i]}
        value=Parent[i];
        if (caught != null) {
            if(value=="000000000000000000"){
                value=IbaseNumber;
            }
            String object='{ '+'''"externalId" : "'''+value+'''"}'''; 
            def jsonObjectParent = jsonParser.parseText(object);
            caught.put("parentId", jsonObjectParent);
            newJsonObject.add(caught);
        }
    }
            
    message.setBody(JsonOutput.toJson(newJsonObject));
    return message;
}
