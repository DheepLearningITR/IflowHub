import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    String value="";
    String newJson="[ ]";
    def jsonSlurper = new JsonSlurper();
    def newJsonObject = jsonSlurper.parseText(newJson);
    def query = new XmlSlurper().parseText(body);
    String CheckNullComponent= query.IDOC.E101CRMXIF_IBASE.E101MXIF_IBASE_COMPONENT_XT.E101CRMXIF_IBASE_COMPONENT;
      if(CheckNullComponent!=null)
          {
               query.IDOC.E101CRMXIF_IBASE.E101MXIF_IBASE_COMPONENT_XT.E101CRMXIF_IBASE_COMPONENT.each {
                   if(it.OBJECT_TYPE.text()=="0030")
                       {
                              String extId=it.INSTANCE.text();
                              String name=it.PRODUCT_ID;
                              String s=  '{ '+''' "externalId"'''+''': "'''+name+'''", "parentId":{"externalId":"'''+extId+'''"}}''';
                              def jsonObjectParent = jsonSlurper.parseText(s);
                              newJsonObject.add(jsonObjectParent);
                       }
               }
          }
    message.setBody(JsonOutput.toJson( newJsonObject));
    return message;
}

    