import groovy.json.JsonSlurper
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import java.text.SimpleDateFormat
import groovy.time.TimeCategory
import java.util.HashMap;
def Message processData(Message message) {
    def sdf = new SimpleDateFormat("yyyyMMddHHmmss")
    def map = message.getProperties();
    String text=map.get("ForwardOriginalIBaseAddress");
    String currentDateTime=map.get("CurrentDateTime");
    String extendedDateTime=map.get("ExtendedDateTime");
    def query = new XmlSlurper().parseText(text);
    query.IDOC.E101CRMXIF_IBASE.E101MXIF_IBASE_COMPONENT_XT.E101CRMXIF_IBASE_COMPONENT.each{
        String update="false";
        if(it.E101CRMXIF_IBASE_ADDRESS_XT.E101CRMXIF_IBASE_ADDRESS!="")
           {
             def changedAt=it.E101CRMXIF_IBASE_ADDRESS_XT.E101CRMXIF_IBASE_ADDRESS.CHANGED_AT.text().replaceAll("\\s", "");
             def createdAt=it.E101CRMXIF_IBASE_ADDRESS_XT.E101CRMXIF_IBASE_ADDRESS.CREATED_AT.text().replaceAll("\\s", "");
             SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss")
             Date dateAddedCreated = dateFormat.parse(createdAt);
             def newcreatedAt= sdf.format(dateAddedCreated);
            
             Date dateAddedCurrent = dateFormat.parse(currentDateTime);
             def currentDateTimeFormatted= sdf.format(dateAddedCurrent);
             Date dateAddedExtended = dateFormat.parse(extendedDateTime);
             def extendedDateTimeFormatted= sdf.format(dateAddedExtended);
             if(changedAt=="0"&&newcreatedAt>=extendedDateTimeFormatted&&newcreatedAt<=currentDateTimeFormatted)
               {
                      update="true";
               }
             else if(changedAt!="0")     
               {
                     Date dateAdded = dateFormat.parse(changedAt);
                     def newchangedAt= sdf.format(dateAdded);
                       if(newchangedAt>=extendedDateTimeFormatted&&newchangedAt<=currentDateTimeFormatted)
                            update="true";
               }
           } 
           if(update=="false"||it.OBJECT_TASK.text()=="U")
              it.replaceNode{};
          
    }
    def valid_data = XmlUtil.serialize(query);
    message.setBody(valid_data);
    return message;        
}
        
         