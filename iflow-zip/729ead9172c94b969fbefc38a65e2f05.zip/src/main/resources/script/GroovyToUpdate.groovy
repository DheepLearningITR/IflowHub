import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import java.text.SimpleDateFormat
import groovy.time.TimeCategory
def Message processData(Message message) {
 def body = message.getBody(java.lang.String);
 def query = new XmlSlurper().parseText(body);
 def copyList = new ArrayList();
 map = message.getProperties();
 String BUFFER_TIME=map.get("BUFFER_TIME");
 def bufferTime=BUFFER_TIME.toInteger();
 def date = new Date();
 def extendeddate;
 use( TimeCategory ) {
    extendeddate = date - bufferTime.minutes
 }
 def sdf = new SimpleDateFormat("yyyyMMddHHmmss")
 date=sdf.format(date);
 extendeddate=sdf.format(extendeddate);
 message.setProperty("CurrentDateTime",date.toString());
 message.setProperty("ExtendedDateTime",extendeddate.toString());
 String partnerUpdate;
 query.IDOC.E101CRMXIF_IBASE.E101MXIF_IBASE_COMPONENT_XT.E101CRMXIF_IBASE_COMPONENT.each {component->
     if(component.OBJECT_TASK.text()=="U")
        component.replaceNode {};
     else
         {
          def validFrom=component.VALID_FROM.text().replaceAll("\\s", "");
          SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss")
          Date dateAdded = dateFormat.parse(validFrom);
          def newvalidFrom= sdf.format(dateAdded);
          partnerUpdate="No";
          component.E101CRMXIF_IBASE_PARTNER_XT.E101CRMXIF_IBASE_PARTNER.each{partner->
            def validFromPartner=partner.VALID_FROM.text().replaceAll("\\s", "");
            Date dateAddedPartner = dateFormat.parse(validFromPartner);
            def newvalidFromPartner= sdf.format(dateAddedPartner);      
            if(newvalidFromPartner>=extendeddate&&newvalidFromPartner<=date&&partner.OBJECT_TASK.text()=="C")
                 {
                     partnerUpdate="Yes";
                     copyList.add(component.INSTANCE.text());
                 }
          }
          if(partnerUpdate=="No")
          {
             if(newvalidFrom>=extendeddate&&newvalidFrom<=date)
                copyList.add(component.INSTANCE.text());
             else
                component.replaceNode {};
          }     
         }     
 }
 query.IDOC.E101CRMXIF_IBASE.E101MXIF_IBASE_STRUCTURE_XT.E101CRMXIF_IBASE_STRUCTURE.each {
  boolean check = false;
  for (int i = 0; i < copyList.size(); i++) {
   if (copyList[i] == it.INSTANCE.text())
    check = true;
  }
  if (!check) {
   it.replaceNode {};
  }
 }
 
 def valid_data = XmlUtil.serialize(query);
 message.setBody(valid_data);
 return message;

}