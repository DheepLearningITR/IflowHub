import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
def Message processData(Message message) { 
 map = message.getProperties();
 def body=map.get("ForwardOriginalIBaseAddress");
 def query = new XmlSlurper().parseText(body);
 def valueContact = map.get("Contact");
 String value="";
 String newJson="[ ]";
 def jsonSlurper = new JsonSlurper();
 def newJsonObject = jsonSlurper.parseText(newJson);
 query.IDOC.E101CRMXIF_IBASE.E101MXIF_IBASE_COMPONENT_XT.E101CRMXIF_IBASE_COMPONENT.each {component->
     if(component.OBJECT_TASK.text()=="C")
         {
            String contactUpdated="No";
            String contactDeleted="No";
            component.E101CRMXIF_IBASE_PARTNER_XT.E101CRMXIF_IBASE_PARTNER.each{partner->
                if(partner.PARTNER_FUNCTION.text()==valueContact&&partner.OBJECT_TASK.text()=="C"&&partner.MAIN_PARTNER.text()=="X")
                         contactUpdated="Yes";
                if(partner.PARTNER_FUNCTION.text()==valueContact&&partner.OBJECT_TASK.text()=="U"&&partner.MAIN_PARTNER.text()=="X")
                         contactDeleted="Yes"
            }
     if(contactUpdated=="No"&&contactDeleted=="Yes")
          {
            String nullString="null";
            String extId=component.INSTANCE.text();
            String s=  '{ '+''' "externalId"'''+''': "'''+extId+'''", "contact":'''+nullString+'}';
            def jsonObjectChild = jsonSlurper.parseText(s);
            newJsonObject.add(jsonObjectChild);
           }
         }
 }
     String contactUpdated="No";
     String contactDeleted="No";
     query.IDOC.E101CRMXIF_IBASE.E102CRMXIF_IBASE_PARTNER_XT.E102CRMXIF_IBASE_PARTNER.each {partner->
        if(partner.PARTNER_FUNCTION.text()==valueContact&&partner.OBJECT_TASK.text()=="C"&&partner.MAIN_PARTNER.text()=="X")
            contactUpdated="Yes";
        if(partner.PARTNER_FUNCTION.text()==valueContact&&partner.OBJECT_TASK.text()=="U"&&partner.MAIN_PARTNER.text()=="X")
            contactDeleted="Yes"
      }
    if(contactUpdated=="No"&&contactDeleted=="Yes")
          {
            String nullString="null";
            String extId=map.get("ParentId");
            String s=  '{ '+''' "externalId"'''+''': "'''+extId+'''", "contact":'''+nullString+'}';
            def jsonObjectChild = jsonSlurper.parseText(s);
            newJsonObject.add(jsonObjectChild);
           }
   message.setBody(JsonOutput.toJson( newJsonObject));
 return message;
}