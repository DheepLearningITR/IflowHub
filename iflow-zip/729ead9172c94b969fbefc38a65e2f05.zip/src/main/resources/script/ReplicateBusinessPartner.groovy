import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.ArrayList;
def Message processData(Message message) {
    map = message.getProperties();
    message.setProperty("CurrentSize", "0");
    message.setProperty("ObjectSent", "undone");
    def valueContact = map.get("Contact");
    def valueBusiness = map.get("BusinessPartner");
    def body = message.getBody(java.lang.String);
    boolean flagcontact = false;
    boolean flagbusiness = false;
    def query = new XmlSlurper().parseText(body);
    ArrayList<String> list1=new ArrayList<String>();
    ArrayList<String> list2=new ArrayList<String>();
    String parentMap=query.IDOC.E101CRMXIF_IBASE.E101MXIF_IBASE_STRUCTURE_XT.E101CRMXIF_IBASE_STRUCTURE;
    if(parentMap!=null){
    query.IDOC.E101CRMXIF_IBASE.E101MXIF_IBASE_STRUCTURE_XT.E101CRMXIF_IBASE_STRUCTURE.each{
    list1.add(it.INSTANCE.text().toString());
    list2.add(it.PARENT.text().toString());
     }
    }
    message.setProperty("ArrayListInstance", list1);
    message.setProperty("ArrayListParent", list2);
    String partner = query.IDOC.E101CRMXIF_IBASE.E102CRMXIF_IBASE_PARTNER_XT.E102CRMXIF_IBASE_PARTNER;
    if (partner != null) {
        query.IDOC.E101CRMXIF_IBASE.E102CRMXIF_IBASE_PARTNER_XT.E102CRMXIF_IBASE_PARTNER.each {
            if (it.PARTNER_FUNCTION.text() == valueContact&&it.MAIN_PARTNER.text()=="X"&&it.OBJECT_TASK.text()=="C") {
                message.setProperty("ContactActual", it.PARTNER_NO);
                flagcontact = true;
            }
            if (it.PARTNER_FUNCTION.text() == valueBusiness&&it.MAIN_PARTNER.text()=="X"&&it.OBJECT_TASK.text()=="C") {
                message.setProperty("BusinessPartnerActual", it.PARTNER_NO);
                flagbusiness = true;
            }
        }
    }
    message.setBody("");
    if (flagcontact == false)
        message.setProperty("ContactActual", "none");
    if (flagbusiness == false)
        message.setProperty("BusinessPartnerActual", "none");
    return message;
}