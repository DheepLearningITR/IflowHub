import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
	    def testRun = message.getProperties().get("testRun");
		if(testRun!=null && testRun!='' && testRun!='false'){
			messageLog.addCustomHeaderProperty("cbr_testRun", testRun);		
        } 
	}
	return message;
}
