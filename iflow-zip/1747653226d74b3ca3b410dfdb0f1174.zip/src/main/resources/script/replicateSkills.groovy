import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.json.JsonOutput;

def Message parseHeaders(Message message) {

	def map = message.getHeaders();

    def sfsfAttributeType = map.get("sfsfAttributeType");
	message.setProperty("sfsfAttributeType", sfsfAttributeType);
	
    def sfsfAttributeFound = map.get("sfsfAttributeFound");
	message.setProperty("sfsfAttributeFound", sfsfAttributeFound);
	
	Set<String> hsetSkillTypeTags = map.get("hsetSkillTypeTags");
	if(hsetSkillTypeTags==null){
	    hsetSkillTypeTags = new HashSet<>();
	}
	message.setProperty("hsetSkillTypeTags", hsetSkillTypeTags);
	
    def testRun = map.get("testRun");
	message.setProperty("testRun", testRun);	
	
    def mapCBRCompetency2SFSFTag = map.get("mapCBRCompetency2SFSFTag");
	message.setProperty("mapCBRCompetency2SFSFTag", mapCBRCompetency2SFSFTag);	

	def sfsfAttributeTagIsMissing = map.get("sfsfAttributeTagIsMissing");
	message.setProperty("sfsfAttributeTagIsMissing",sfsfAttributeTagIsMissing);	

	def sfsfSkillTypeTags = message.getProperties().get("sfsfSkillTypeTags") ?: "null";
	message.setProperty("sfsfSkillTypeTags",sfsfSkillTypeTags);
	
	//used to clear hashmap global variables
	def emptyHmap = new HashMap<String, String>();
	emptyHmap.put('null','');
	message.setProperty("emptyHmap", emptyHmap);	
	
	return message;
}

def Message process_creates(Message message) {
	
	def body = message.getBody(java.lang.String);
	def map = message.getProperties();
    //def attributeType = map.get("sfsfAttributeType"); //DS compliance
    HashMap<String, String> hmapAttrib = map.get("hmap_sfsfAttributes"); 
    if(hmapAttrib==null){
        hmapAttrib = new HashMap<String, String>();
    }

	HashMap<String, String> hmapTypes = map.get("hmap_sfsfAttributeTypes"); 
    if(hmapTypes==null){
        hmapTypes = new HashMap<String, String>();
    }
    
    Set<String> duplicateAttributes = new HashSet<>();
    def sumDuplicateAttributes = 0;

	def Root = new XmlParser().parseText(body);
    Root.attribute.each{r->
        def sfsfAttribExtCode = 'cbr_'+r.id[0].text();
        def duplicateFound = false;
        if(hmapAttrib != null && hmapAttrib.containsKey(sfsfAttribExtCode)){
            r.replaceNode{}; //remove, already exists
        }else{
            //Talent Skill NOT FOUND in SFSF Attribute, check for duplicates, otherwise CREATE
            if(hmapTypes){
                //check for Duplicates = SAME ID, DIFFERENT Type
                def duplAttrType = hmapTypes.get(sfsfAttribExtCode);
                if(duplAttrType){
                    //Duplicate ID with different type found, remove Skill
                    r.replaceNode{};
                    duplicateAttributes.add(sfsfAttribExtCode+':'+duplAttrType);
                    sumDuplicateAttributes++;     
                    duplicateFound = true;
                }
            } 
            
            if(duplicateFound == false){
                //NO duplicates found, create Attribute
                r.id[0].value = sfsfAttribExtCode; //with prefix cbr_
                r.operation[0].value = "CREATE"
            }              
        }
    }
    
    message.setProperty("hmap_sfsfAttributes",null);      //clear processed data
    message.setBody(XmlUtil.serialize(Root));

    message.setHeader("sumDuplicateAttributes",sumDuplicateAttributes.toString());
    message.setHeader("duplicateAttributes",duplicateAttributes);

	return message;
}


def Message filter_attributeNames(Message message) {
	
	def body = message.getBody(java.lang.String);
	def map = message.getProperties();
    def attributeType = map.get("sfsfAttributeType");
    HashMap<String, String> hmapTexts = map.get("hmap_sfsfAttributeTexts"); 
    if(hmapTexts==null){
        hmapTexts = new HashMap<String, String>();
    }
	HashMap<String, String> hmapTypes = map.get("hmap_sfsfAttributeTypes"); 
    if(hmapTypes==null){
        hmapTypes = new HashMap<String, String>();
    }
    
    def sumCreate = 0;
    def sumDuplicateAttributes = 0;
	def sumDuplicateAttributeTexts = 0;    
	Set<String> duplicateAttributes = new HashSet<>();
    Set<String> duplicateAttributeTexts = new HashSet<>();
	
	def Root = new XmlParser().parseText(body);
    Root.file.each{
        it.attribute.each{r->
            
            def sfsfAttribExtCode = r.id[0].text();
            def duplicateFound = false;            
        
            //Talent Skill NOT FOUND in SFSF Attribute, check for duplicates, otherwise CREATE
            if(!hmapTexts.isEmpty()){
                
                //check for Duplicates = DIFFERENT ID, SAME Name, SAME Type
                //JIRA INT-326 Same name allowed as long as they're different types
                def name = attributeType+'-en_US-'+r.translation_en_US[0].title.text().trim().toLowerCase(); 
    
                String duplicateId = hmapTexts.get(name);
                if(duplicateId!=null && sfsfAttribExtCode!=duplicateId){
                    //Duplicate found, remove Skill
                    r.replaceNode{};
                    duplicateAttributes.add(sfsfAttribExtCode+':'+name.replace(',', '%2C')+'|'+duplicateId); //encode commas
                    sumDuplicateAttributes++;
                    duplicateFound = true;
                }else{
                    //JIRA INT-363 Same name Translations allowed as long as they're different types
                    //check for duplicate Translations. remove translation node if duplicate is found
                    name = attributeType+'-de_DE-'+r.translation_de_DE[0].title.text().trim().toLowerCase();
                    duplicateId = hmapTexts.get(name);
                    if(duplicateId!=null && sfsfAttribExtCode!=duplicateId){
                        //duplicate Text found, remove Translation Node
                        r.translation_de_DE.replaceNode();  
                        duplicateAttributeTexts.add(sfsfAttribExtCode+':'+name.replace(',', '%2C')+'|'+duplicateId); //encode commas
                        sumDuplicateAttributeTexts++;
                    }
                }
            }
        
            if(duplicateFound == false){
                //NO duplicates found, create Attribute
                sumCreate = sumCreate + 1; //counter
            
                r.findAll { it.name().startsWith('translation_') }.each { t ->
                    // Locate the <description> element within each translation node
                    //t.title[0].value = escapeText(t.title[0].text()); //remove ampersands, 20250331: removed, characters now supported in titles
                    
                    // Truncate the description text
                    if(t.description[0]){
                        t.description[0].value = format_desc_create(t.description[0].text());
                    }
                }    
            }   
        }
    }
    
    message.setProperty("hmap_sfsfAttributeTypes",null);  //clear processed data
    message.setBody(XmlUtil.serialize(Root));
    message.setProperty("sumCreate",sumCreate.toString());
    
    message.setProperty("sumDuplicateAttributes",sumDuplicateAttributes.toString());
    message.setProperty("duplicateAttributes",duplicateAttributes.toString());    
    
    message.setProperty("sumDuplicateAttributeTexts",sumDuplicateAttributeTexts.toString());
    message.setProperty("duplicateAttributeTexts",duplicateAttributeTexts.toString());    
    
	return message;
}

def Message gather_filenames(Message message) {
    def body = message.getBody(String);
    def root = new XmlSlurper().parseText(body);
    
    List<String> files = [
        "filenameINS",
        "filenameINSTexts",
        "filenameINSTags"
    ];

    files.each { file ->
        Set<String> filenames = new HashSet<>();
        def elements = root."$file";
        elements.each(){
            def fname = it.text().trim();
            if(fname && fname != '[]'){
                filenames.add(fname)
            }
        }
        if(!filenames.isEmpty()){
            message.setHeader(file, JsonOutput.toJson(filenames));
        }
    }
    
    return message;
}

def Message get_duplicateAttributes(Message message) {
    def body = message.getBody(String);
    def root = new XmlSlurper().parseText(body);
    
    // Check if root is empty or has no children
    if (root.children().size() > 0) {    
    
        // Collect all sumCreate values and calculate total sum
        def sumCreate = root.'**'.findAll { it.name() == 'sumCreate' }*.text()*.toInteger().sum();
        message.setHeader("sumCreate", sumCreate);
        
        // Collect all sumDuplicateAttributes values and calculate total sum
        def sumDuplicateAttributes = message.getHeaders().get('sumDuplicateAttributes').toInteger(); //get sum from process_creates
        sumDuplicateAttributes = sumDuplicateAttributes + root.'**'.findAll { it.name() == 'sumDuplicateAttributes' }*.text()*.toInteger().sum();
        message.setHeader("sumDuplicateAttributes", sumDuplicateAttributes);    
        
        // Collect all sumDuplicateAttributeTexts values and calculate total sum
        def sumDuplicateAttributeTexts = root.'**'.findAll { it.name() == 'sumDuplicateAttributeTexts' }*.text()*.toInteger().sum();
        message.setHeader("sumDuplicateAttributeTexts", sumDuplicateAttributeTexts);
        
        //collect all duplicate attributes from ALL splits
        Set<String> duplicateAttributes = extractSetFromXml(root, 'duplicateAttributes')
        
        //append duplicate attributes from process_creates
        Set<String> hsetDuplicateAttributesHDR = message.getHeaders().get('duplicateAttributes');
        if(hsetDuplicateAttributesHDR==null){
            hsetDuplicateAttributesHDR = new HashSet<>();
        }
    
        //Merge both sets
        duplicateAttributes.addAll(hsetDuplicateAttributesHDR);
        message.setHeader("duplicateAttributes", JsonOutput.toJson(duplicateAttributes).toString());
    
        Set<String> duplicateAttributeTexts = extractSetFromXml(root, 'duplicateAttributeTexts')
        message.setHeader("duplicateAttributeTexts", JsonOutput.toJson(duplicateAttributeTexts).toString());               
        
    }else{
        
        //output duplicateAttributes from process_creates
        Set<String> hsetDuplicateAttributesHDR = message.getHeaders().get('duplicateAttributes');
        if(hsetDuplicateAttributesHDR==null){
            hsetDuplicateAttributesHDR = new HashSet<>();
        }
        message.setHeader("duplicateAttributes", JsonOutput.toJson(hsetDuplicateAttributesHDR).toString());        
        message.setHeader("sumDuplicateAttributes", hsetDuplicateAttributesHDR.size().toString());  
    }

    return message;
}

// Reusable method to extract and clean up sets from XML nodes
Set<String> extractSetFromXml(def xml, String tagName) {
    
    Set<String> resultSet = new HashSet<>();
    xml.'**'.findAll { it.name() == tagName }.each { node ->
        def content = node.text().trim();
        if (content != '[]'){ 
            
            if(content.startsWith("[") && content.endsWith("]")) {
                content = content[1..-2]; // remove square brackets
                
                content.split(',').each { item ->
                    def trimmed = item.trim();
                    if (trimmed) {
                        trimmed = trimmed.replace('%2C', ','); //decode commas
                        resultSet.add(trimmed);
                    }
                }
            }
        }
    }
    return resultSet;
}

def String escapeText(String txt){
    //escape special including '&'. This is a TEMPORARY fix until SAP Fixes Note 3459488!!  
    //txt = StringEscapeUtils.escapeHtml4(txt);        
    String stxt = txt.replace("&", "&amp;")
                     .replace("<", "&lt;")
                     .replace(">", "&gt;");
    return stxt;
}

def String format_desc(String description){
    String descr = description;
    descr = descr.replaceAll(/\/n/, "\n");  //replace with actual new line
    descr = descr.replaceAll ('"','\\\\\\"'); //escape double quotes
    descr = descr.take(4000);  //4000 char limit    
    return descr;
}

//once SAP Note 3459488 is fixed by SAP, remove this section and replace calls to call the original format_desc!!
def String format_desc_create(String description){
    String descr = description;
    descr = escapeText(descr); //only required in CREATES to ensure attribute synchs back to CoC
    descr = descr.replaceAll(/\/n/, "\n");  //replace with actual new line
    descr = descr.replaceAll ('"','\\\\\\"'); //escape double quotes
    descr = descr.take(4000);  //4000 char limit    
    return descr;
}

