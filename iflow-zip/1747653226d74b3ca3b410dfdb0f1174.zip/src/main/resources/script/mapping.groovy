import com.sap.it.api.mapping.MappingContext

def String concatTags(String cbrSkillType, String comps, MappingContext context) {
    
   def sfsfAttributeTag = context.getProperty('sfsfAttributeTag') ?: ''; //default Cobrainer Tag >> optional
    def sfsfAttributeTagIsMissing = context.getProperty('sfsfAttributeTagIsMissing') ?: 'false';
    def sfsfSkillTypeTags = context.getProperty("sfsfSkillTypeTags");
    
    def sfsfCBRTags = '';
    if(sfsfAttributeTag!='' && sfsfAttributeTagIsMissing=='false'){
       //add only universal Tag is it's not missing
       sfsfCBRTags = sfsfAttributeTag;
    }
    
    
    if(cbrSkillType!='' && sfsfSkillTypeTags!="null"){
        Set<String> hsetSkillTypeTags = context.getProperty("hsetSkillTypeTags");
    	if(hsetSkillTypeTags){
            def sfsfTagId = 'cbr_'+cbrSkillType;
            if(hsetSkillTypeTags.contains(sfsfTagId)){
                //check that Tag exists in SFSF, add SkillType as Tag
                if(sfsfCBRTags==''){
                    sfsfCBRTags = sfsfTagId;
                }else{
                    sfsfCBRTags = sfsfCBRTags + ',' + sfsfTagId;
                }
            }
    	}
    }
    
    
    //pipe was used as delimiter as it's conflicting with the hmap values which has delimited by comma
    //so just replace here
    if(comps){
        comps = comps.replaceAll("\\|", ",");
        if(sfsfCBRTags==''){
            sfsfCBRTags = comps;
        }else{
            sfsfCBRTags = sfsfCBRTags + ',' + comps;
        }
    }
    
    return sfsfCBRTags;  
    
}