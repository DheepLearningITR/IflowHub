import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

def Message processData(Message message) {

      //Get message and parse to json
    def json = message.getBody(java.io.Reader)
    def data  = new JsonSlurper().parse(json)
    message.setProperty("messageRequestsCount", data.messageRequests.size())
    return message;
}

def Message splitMessageRequest(Message message) {
    def body = message.getBody(java.io.Reader)
    def parsedJson = new JsonSlurper().parse(body)
    // Split message requests into chunks
    def messageRequests = parsedJson.messageRequests
    def chunkSize = 100
    def chunks = messageRequests.collate(chunkSize)
    // Wrap chunks inside a new JSON array with unique GUIDs and timestamps
    def outputJsonArray = []
    chunks.each {
        chunk -> def newHeader = parsedJson.messageHeader.collectEntries {
            k, v -> if (k == 'id') {
                [k, UUID.randomUUID().toString()]
            } else if (k == 'creationDateTime') {
                [k, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))]
            } else {
                [k, v]
            }
        }
        def chunkJson = [
            messageHeader: newHeader,
            messageRequests: chunk
        ]
        outputJsonArray << chunkJson
    }
    // Convert to JSON
    def bundledJson = [bundledJson: outputJsonArray]
    def outputJson = JsonOutput.toJson(bundledJson)
    message.setBody(outputJson)
    return message
}

def Message removeJsonRootElement(Message message) {
    def body = message.getBody(java.io.Reader)
    def outputJson = new JsonSlurper().parse(body).bundledJson
    message.setBody(JsonOutput.toJson(outputJson))
    return message
}