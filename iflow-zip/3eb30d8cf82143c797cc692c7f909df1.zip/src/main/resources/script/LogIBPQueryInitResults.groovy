/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;

def Message processData(Message message) {

	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    def headers = message.getHeaders();
	    
	    def IBPReads = message.getProperty('IBPReadRequestsResultsIndent');
        def IBPReadsReader =  new StringReader(IBPReads);
        def xmlReads = new XmlSlurper().parse(IBPReadsReader);
	    xmlReads.children()?.IBPRead.each {}collect{it.@Status.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Read Status", it2) };
	    xmlReads.children()?.IBPRead.each { messageLog.addCustomHeaderProperty("IBP Read", "key:" + it?.@Key + " uuid:" + it?.@UUID + " destination:" + it?.@Destination + " status:" + it?.@Status ) };
	    xmlReads.children()?.IBPRead.findAll {it.@DeltaQueue!=''}.each { messageLog.addCustomHeaderProperty("IBP Read Delta Queue", it.@DeltaQueue.text()) };
	    xmlReads.children()?.IBPRead?.Messages?.Message.each { addLogCustomHeaderWithSplit(messageLog,"IBP " + it.parent()?.@Step.text() + " " + it?.@Type.text(), it.text()) };
	    
	    xmlReads.children()?.IBPRead?.Exception.each { 
	        addLogCustomHeaderWithSplit(messageLog,"IBP " + it?.@Step.text() + " Exeption", it.text());
	        addLogCustomHeaderWithSplit(messageLog,"IBP " + it?.@Step.text() + " FailureEndpoint", it?.@FailureEndpoint.text());
	        addLogCustomHeaderWithSplit(messageLog,"IBP " + it?.@Step.text() + " FailureRouteId", it?.@FailureRouteId.text());
        };

	    messageLog.addAttachmentAsString('4IBPReadRequestsResults', IBPReads, 'text/xml');
	}
	return message;
}

def void addLogCustomHeaderWithSplit(MessageLog messageLog, String headerName, String content) {
    def messageLength = content.length();
    if (messageLength<=198) messageLog.addCustomHeaderProperty(headerName, content);
    else {
        int i = 0;
        for (int j = 0; j < messageLength;j += 198) {
            def k = j + 198;
            i++;
            messageLog.addCustomHeaderProperty(headerName + '.' + i.toString(), content.substring(j,k<=messageLength?k:messageLength));
        }
    }
}




def Message raiseIBPErrorMessage(Message message) {
	def headers = message.getHeaders();
	def ibpStep = headers.get("IBPStep");	
	throw new Exception("Error in IBP step ${ibpStep}");
	return message;
}

def Message setLogCustomHeaders(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    def headers = message.getHeaders();
	    String emailBody = headers.get('emailBody') + "\r\nLog custom headers:";
    	def logCustomHeaders = headers.get("LogCustomHeaders");
    	def logCustomProperties = headers.get("LogCustomProperties");
    	def logAttachmentHeaders = headers.get("LogAttachmentHeaders");
	    if(logCustomHeaders!=null) {
    	    logCustomHeaders.tokenize(',').each() {
    	        setLogCustomHeader(headers, messageLog, it);		
    	        emailBody += "\r\n\${it}: ${headers.get(it)}"
    	    }
	    }
	    if(logCustomProperties!=null) {
    	    logCustomProperties.tokenize(',').each() {
    	        setLogCustomProperty(message, messageLog, it);
    	        emailBody += "\r\n\${it}: ${message.getProperty(it)}"
    	    }
	    }
	    if(logAttachmentHeaders!=null) {
    	    logAttachmentHeaders.tokenize(',').each() {
    	        setLogAttachmentHeader(headers, messageLog, it);		
    	    }
	    }
	    
	}
	return message;
}

def void setLogCustomHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addCustomHeaderProperty(headerName, header.toString());		
    }
}

def void setLogCustomProperty(Message message, MessageLog messageLog, String propertyName) {
    
	def property = message.getProperty(propertyName);		
	if(property!=null){
		messageLog.addCustomHeaderProperty(propertyName, property.toString());		
    }
}

def void setLogAttachmentHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addAttachmentAsString(headerName, header.toString(), 'text/plain')	
    }
}
