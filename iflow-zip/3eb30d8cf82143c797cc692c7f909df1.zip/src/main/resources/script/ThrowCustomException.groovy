import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.msglog.*;

def Message processData(Message message) {
	
	def body = message.getBody(java.io.Reader);
    def xmlResponses = new XmlSlurper().parse(body);
	def messageLog = messageLogFactory.getMessageLog(message);


	HashMap<String, HashMap<String, String[]>> destinationAndUUIDByCause = [:].withDefault { key -> [:] }
	//Get all Destination and UUID combinations for Queries that have a QueryStatusException node grouped by the Exceptions Cause Attribute
	//QueryStatusException node occurs when query status request fails
	xmlResponses.children()?.IBPRead?.QueryStatusException.each{ 
		String destination = it.parent().@Destination.text()
		String UUID = it.parent().@UUID.text()
		String cause = it.@Cause.text() ?: 'STATUS'
		if(!destinationAndUUIDByCause[cause]){
			HashMap<String, String[]> tempMap = [:]
			tempMap.put(destination, [UUID]) 
			destinationAndUUIDByCause.put(cause, tempMap) 
		}
		else{
			if (!destinationAndUUIDByCause[cause][destination]) { 
				destinationAndUUIDByCause.get(cause).put(destination, [UUID]) 
			}
			else { 
				destinationAndUUIDByCause.get(cause).get(destination).add(UUID) 
			}
		}	
	}

	//Get all Destination and UUID combinations for Queries that have a Exception node grouped by the Exceptions Cause Attribute
	//Exception node occurs when query initialization fails
	xmlResponses.children()?.IBPRead?.Exception.each{ 
		String destination = it.parent().@Destination.text()
		String UUID = it.parent().@UUID.text()
		String cause = it.@Cause.text() ?: 'INIT'
		if(!destinationAndUUIDByCause[cause]){
			HashMap<String, String[]> tempMap = [:]
			tempMap.put(destination, [UUID]) 
			destinationAndUUIDByCause.put(cause, tempMap) 
		}
		else{
			if (!destinationAndUUIDByCause[cause][destination]) { 
				destinationAndUUIDByCause.get(cause).put(destination, [UUID]) 
			}
			else { 
				destinationAndUUIDByCause.get(cause).get(destination).add(UUID) 
			}
		}	
	}	

	if(messageLog != null){	
		if(!destinationAndUUIDByCause.isEmpty()){
			//Write all queries containing init or status errors to the log
			String allQueriesWithError = ""
			destinationAndUUIDByCause.values().each{ value -> 
					value.each{ key, array ->
					allQueriesWithError += key +': '+ array.join(';') +' '
				}
			}

			String defaultMessage = "Errors occured for the following destination and UUID combination(s): " + allQueriesWithError
			addLogCustomHeaderWithSplit(messageLog, 'Queries with errors' , defaultMessage)

			//Throw exception and add logs for the worst cause
			switch (destinationAndUUIDByCause) {
				case {destinationAndUUIDByCause.containsKey("STATUS")}:
					String queryStatusErrorMessage = "Query Status exception occured for the following destination and UUID combination(s): " + formatMapReturn(destinationAndUUIDByCause.get("STATUS"),"STATUS")
					addLogCustomHeaderWithSplit(messageLog, 'Queries with status exception' , queryStatusErrorMessage)
					throw new StatusException(queryStatusErrorMessage);   
					break
				case {destinationAndUUIDByCause.containsKey("Timeout")}:
					String queryTimeoutMessage = "Query Status request timed out for the following destination and UUID combination(s): " + formatMapReturn(destinationAndUUIDByCause.get("Timeout"),"Timeout")
					addLogCustomHeaderWithSplit(messageLog, 'Timed out queries' , queryTimeoutMessage)
					throw new TimeoutException(queryTimeoutMessage);   
					break
				default:
					
					break
			}
			
		}
	}

	return message;
}


def void addLogCustomHeaderWithSplit(MessageLog messageLog, String headerName, String content) {
    def messageLength = content.length();
    if (messageLength<=198) messageLog.addCustomHeaderProperty(headerName, content);
    else {
        int i = 0;
        for (int j = 0; j < messageLength;j += 198) {
            def k = j + 198;
            i++;
            messageLog.addCustomHeaderProperty(headerName + '.' + i.toString(), content.substring(j,k<=messageLength?k:messageLength));
        }
    }
}

def String formatMapReturn(HashMap<String, String[]> inputMap,String inputkey){
	String result = ""
	inputMap.each{
		key, array ->
		result += key +': '+ array.join(';') +' '
	}
	return result
}

public class TimeoutException extends Exception {
  public TimeoutException(String message) {
    super(message);
  }
}

public class StatusException extends Exception {
  public StatusException(String message) {
    super(message);
  }
}
