import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;
import java.util.regex.*;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonException;
import org.apache.commons.io.IOUtils;

def Message processData(Message message) {
    def map = message.getProperties();
    
    def loggingEnabled = map.get("LoggingEnabled");
    def logConfig = map.get("SAP_MessageProcessingLogConfiguration");
	def logLevel = (String) logConfig.logLevel;
    
    if ((loggingEnabled != null && loggingEnabled.toUpperCase().equals("TRUE")) || logLevel.equals("DEBUG") || logLevel.equals("TRACE")) {
    
        def messageLog = messageLogFactory.getMessageLog(message);
        if (messageLog != null) {
            def payload = message.getBody(java.lang.String) as String;
            def attachmentName = map.get("AttachmentName");
            def attachmentFileFormat = map.get("AttachmentFileFormat");
            
            if(!(attachmentName != null && attachmentName != ""))
                attachmentName = "Body";
            
            if(!(attachmentFileFormat != null && attachmentFileFormat != ""))
                attachmentFileFormat = getPayloadFormat(payload);
            
            if(attachmentFileFormat != 'text/plain'){
                Reader reader = message.getBody(Reader);
                payload = IOUtils.toString(reader);
            }
            
            messageLog.addAttachmentAsString(attachmentName, payload, attachmentFileFormat);
        }
    }
    
    message.setProperty("AttachmentName", "");
    message.setProperty("AttachmentFileFormat", "");
    
    return message;
}

def getPayloadFormat(payload) {
    try {
        def xmlPayload = new XmlSlurper().parseText(payload);
        return 'application/xml';
    }
    catch (Exception e) {
        try {
            def jsonPayload = new JsonSlurper().parseText(payload)
            return 'application/json';
        }
        catch (Exception e1) {
            return 'text/plain';
        }
    }
    return 'text/plain';
}