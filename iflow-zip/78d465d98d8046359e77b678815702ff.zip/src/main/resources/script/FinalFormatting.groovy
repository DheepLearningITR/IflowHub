import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import java.util.HashMap;

def Message processData(Message message) { 

	def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	object.count = message.getProperty("count");
	if (!isCollectionOrArray(object.result)) {      
		//Converting Record to an array        
		object.result = [object.result].toArray();   
	}
	results = JsonOutput.toJson( object );
    message.setBody(results);
    return message;
}

//Returns true if object is an array
boolean isCollectionOrArray(object) {
    
	[Collection, Object[]].any {        
		it.isAssignableFrom(object.getClass())    
	}

}