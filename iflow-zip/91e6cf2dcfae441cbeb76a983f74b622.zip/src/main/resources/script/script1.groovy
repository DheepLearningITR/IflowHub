import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;


def Message setSalesQuoteDisplayId(Message message) {
    def json = message.getBody(java.io.Reader)
    def data = new JsonSlurper().parse(json)
    message.setProperty("P_SalesQuoteDisplayId", data.messageRequests[0].body.externalQuoteDetails[0].displayId)
    return message
}

