import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.ArrayList;
import java.lang.*;
import com.sap.it.api.mapping.*;
import groovy.json.*
import java.text.SimpleDateFormat

// TODO - need to be more defensive, check for null/empty values
def Message processData(Message message)
{
    Date currentdate = new Date(); 
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
    sdf.format(currentdate);
    def expiringInDays = 0; 
    
    message.setHeader("Content-Type", "application/json" + "; charset=utf-8" );
    
    def jsonBody = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def jsonObj = jsonSlurper.parseText(jsonBody);
    
    def dataResults = [];
    
    def segment1Val = 30; 
    def segment2Val = 60; 
    
    def segment1 = [:]
    segment1.name = "expiringIn" + segment1Val;         //30 days
    segment1.y = 0;
    
    def segment2 = [:]
    segment2.name = "expiringIn" + segment2Val;         //60 days
    segment2.y = 0;
    
    def openSegment = [:]
    openSegment.name = "open";
    openSegment.y = 0;
    
    //new ext data 
    def extData = [:];
    extData.expiringIn30 = [];
    extData.expiringIn60 = [];
    extData.open = [];
    
    jsonObj.get("messageResponses").get(0).get("body").get("extData").each{ val ->

       if(val.validityEndDate){
           
           def validityEndDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS",val.validityEndDate);
           
            use(groovy.time.TimeCategory) {
                def expiringIn = validityEndDate - currentdate;         
                expiringInDays = expiringIn.days;
            }
            
            if(expiringInDays>=0 && expiringInDays<=30){
                segment1.y = segment1.y + 1;
                extData.expiringIn30.push(val);
            }else if(expiringInDays>30 && expiringInDays<=60){
                segment2.y = segment2.y + 1;
                extData.expiringIn60.push(val);
            }else if(expiringInDays>60){                         
                openSegment.y = openSegment.y + 1;
                extData.open.push(val);
            }
        
       }
    }
    jsonObj.get("messageResponses").get(0).get("body").put("extData", extData);
    jsonObj.get("messageResponses").get(0).get("body").total = segment1.y + segment2.y + openSegment.y;
    
    dataResults.push(segment1);
    dataResults.push(segment2);
    dataResults.push(openSegment);
    
    
    jsonObj.get("messageResponses").get(0).get("body").put("data",dataResults);
    def newBody = JsonOutput.toJson(jsonObj);
    message.setBody(newBody);
    return message;
}