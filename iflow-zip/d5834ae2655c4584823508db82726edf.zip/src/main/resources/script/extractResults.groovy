import com.sap.gateway.ip.core.customdev.util.Message

Message countProcessedFinal(Message message){
    def body = message.getBody(String.class)
    
    if (body?.isNumber()){
        message.setProperty("totalProcessedFinal",""+(Integer.parseInt(message.getProperty("totalProcessedFinal"))+ Integer.parseInt(body)))
        message.setProperty("isError","false")
    }else{
        message.setProperty("isError","true")
    }
    
    return message
}


Message calculateKey(Message message){
    def totalReturned = message.getProperty('totalReturned') as Integer
    def batchSize = message.getProperty('batchSize') as Integer
    
    
    def key = totalReturned  / batchSize
    
    def keyInt = key as int
    def finalKey = keyInt
    
    message.setProperty('key', finalKey)
    

    return message
}


