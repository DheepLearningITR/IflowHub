/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    //define customized event type
    def event_type_lock = valueMapApi.getMappedValue('SAP S/4HANA', 'Event Type', 'sap.s4.beh.subscriptioncontract.v1.SubscriptionContract.Locked.v1', 'SAP S/4HANA Customized', 'Event Type');
    def event_type_unlock = valueMapApi.getMappedValue('SAP S/4HANA', 'Event Type', 'sap.s4.beh.subscriptioncontract.v1.SubscriptionContract.Unlocked.v1', 'SAP S/4HANA Customized', 'Event Type');
    def event_type_reject = valueMapApi.getMappedValue('SAP S/4HANA', 'Event Type', 'sap.s4.beh.subscriptioncontract.v1.SubscriptionContract.Rejected.v1', 'SAP S/4HANA Customized', 'Event Type');
    def event_type_reject_change = valueMapApi.getMappedValue('SAP S/4HANA', 'Event Type', 'sap.s4.beh.subscriptioncontract.v1.SubscriptionContract.ChangeRejected.v1', 'SAP S/4HANA Customized', 'Event Type');
    
    //define customized change process
    def change_process_cancel = valueMapApi.getMappedValue('SAP S/4HANA', 'Change Process', 'CANCEL', 'SAP S/4HANA Customized', 'Change Process');
    def change_process_lock_unlock = valueMapApi.getMappedValue('SAP S/4HANA', 'Change Process', 'LOCK_UNLOCK', 'SAP S/4HANA Customized', 'Change Process');
    
    //if no value mapping was deployed, then use the default event type code, and default change process name
    if(null == event_type_lock)
    {
        event_type_lock = 'sap.s4.beh.subscriptioncontract.v1.SubscriptionContract.Locked.v1';
    }
    if(null == event_type_unlock)
    {
        event_type_unlock = 'sap.s4.beh.subscriptioncontract.v1.SubscriptionContract.Unlocked.v1';
    }
    if(null == event_type_reject)
    {
        event_type_reject = 'sap.s4.beh.subscriptioncontract.v1.SubscriptionContract.Rejected.v1';
    }
    if(null == event_type_reject_change)
    {
        event_type_reject_change = 'sap.s4.beh.subscriptioncontract.v1.SubscriptionContract.ChangeRejected.v1';
    }
    if(null == change_process_cancel)
    {
        change_process_cancel = 'CANCEL';
    }
    if(null == change_process_lock_unlock)
    {
        change_process_lock_unlock = 'LOCK_UNLOCK';
    }
    
    message.setProperty("event_type_lock", event_type_lock);
    message.setProperty("event_type_unlock", event_type_unlock);
    message.setProperty("event_type_reject", event_type_reject);
    message.setProperty("event_type_reject_change", event_type_reject_change);
    
    message.setProperty("change_process_cancel", change_process_cancel);
    message.setProperty("change_process_lock_unlock", change_process_lock_unlock);
    
    return message;
    
}