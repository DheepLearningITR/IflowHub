import com.sap.gateway.ip.core.customdev.util.Message;

def Message addCustomerHeader(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def map = message.getProperties();
    if(messageLog != null){
        def subscriptionContractID = map.get("subscription_contract_id");
        def subscriptionContractItemID = map.get("subscription_contract_item_id");
        def eventType = map.get("event_type");
        messageLog.addCustomHeaderProperty("SubscriptionContractID", subscriptionContractID);
        messageLog.addCustomHeaderProperty("SubscriptionContractItemID", subscriptionContractItemID);
        messageLog.addCustomHeaderProperty("EventType", eventType);
    }
    return message;
}
