import com.sap.it.api.mapping.*;
def String getPropertyValue(String propertyName, MappingContext context){
    def propertyValue = context.getProperty(propertyName);
    if(!propertyValue?.trim()){
        return "Dummy";
    }
    return propertyValue;
}

def String getDate(String dateTime){
    def dateParser = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS", dateTime);
    return dateParser.format("yyyyMMdd", TimeZone.getTimeZone("UTC"));
}

// With Boolean return type will result in error
def String containsItemCategory(String itemCategory, String propertyName, MappingContext context){
    def itemCategorys = context.getProperty(propertyName).split(",");
    return Arrays.asList(itemCategorys).contains(itemCategory);
}
