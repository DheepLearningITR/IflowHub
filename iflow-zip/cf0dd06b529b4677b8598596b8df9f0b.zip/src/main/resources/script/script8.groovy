import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {	
	def body = message.getBody(java.lang.String) as String;
	
	def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    
    
    // Handling Header Parsing
     def cancellationComments = jsonObject.get("CancellationComments");
     
     def comments = cancellationComments.get("CancelComment");
     
     def finalJson = null;
     
            if(comments instanceof java.util.Map){
                def array = [];
                array.push(comments);
                finalJson = array;
            }else{
                finalJson = comments;
            }
            
        message.setBody(JsonOutput.toJson(finalJson));
        
	return message;
}