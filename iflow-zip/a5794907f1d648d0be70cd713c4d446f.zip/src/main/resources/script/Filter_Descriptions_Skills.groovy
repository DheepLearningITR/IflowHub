
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlParser;
import groovy.util.XmlNodePrinter;
import java.io.PrintWriter;
import java.io.StringWriter;

def Message processData(Message message) {
    //extract message body and remove unwanted languages
    def headers = message.getHeaders(); 
    def body = message.getBody(java.lang.String) as String;
    try{
         def map = message.getProperties();
         def languageCode = map.get("languageCode");
         def fallbackLanguageCode = map.get("fallbackLanguageCode");
        if(languageCode == ""){
            languageCode = "EN";
        }
        def response = new XmlParser().parseText(body);
        response.SkillReplicationRequest.SkillsReplicationRequestMessage.each{
        //check if description with preferred language is present 
        def preferredlangDesc = it.'**'.findAll { it.name() == 'SkillsDescription' && it.@languageCode == languageCode }
        //check if description with preferred language is present
        def fallbacklangDesc = it.'**'.findAll { it.name() == 'SkillsDescription' && it.@languageCode == fallbackLanguageCode }
        
        if(!(preferredlangDesc.isEmpty())){
            //delete all other nodes if preferred language is found
             delNodes=it.'**'.findAll { it.name() == 'SkillsDescription' && it.@languageCode != languageCode }
             for(def node : delNodes){
             def parent=node.parent()
             parent.name()=='Description'?parent.parent().remove(parent):''
            }
        }else if(!(fallbacklangDesc.isEmpty())){
            //delete all other nodes if fallback language is found
             delNodes=it.'**'.findAll { it.name() == 'SkillsDescription' && it.@languageCode != fallbackLanguageCode }
             for(def node : delNodes){
             def parent=node.parent()
             parent.name()=='Description'?parent.parent().remove(parent):''
             }
        }else{
            //delete all description nodes
             delNodes=it.'**'.findAll { it.name() == 'SkillsDescription' }
             for(def node : delNodes){
             def parent=node.parent()
             parent.name()=='Description'?parent.parent().remove(parent):''
             }
        }
        }
        //convert to string and setbody
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(response)
        message.setBody(stringWriter.toString())
    }catch(Exception ex){
    	//send input body in case of error
        message.setBody(body)
    }
    return message;
}