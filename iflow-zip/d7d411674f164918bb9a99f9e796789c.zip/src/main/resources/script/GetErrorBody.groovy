import groovy.json.JsonOutput
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // get a map of iflow properties
    def map = message.getProperties();
    // get an exception java class instance
    def ex = map.get("CamelExceptionCaught");
    def ErrorMessage;
     
    if (ex!=null)
    {
        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException"))
        {
          // copy the application error to the message body
          ErrorMessage = JsonOutput.toJson([Iflow: 'Notify Service Order Update to SAP Customer Relationship Management', MessageLogID: map.get("SAP_MessageProcessingLogID"), ErrorMssg: ex.getResponseBody(), PayloadUsed: map.get("PayloadForLog"), SetErrorFlag: 'Generic']);
        }
        else{
          // copy the sysem error to the message body
          ErrorMessage = JsonOutput.toJson([Iflow: 'Notify Service Order Update to SAP Customer Relationship Management', MessageLogID: map.get("SAP_MessageProcessingLogID"), ErrorMssg: ex.getMessage(), PayloadUsed: map.get("PayloadForLog"), SetErrorFlag: 'Generic']);
        }
        message.setBody(ErrorMessage);
    }
      
    return message;
}