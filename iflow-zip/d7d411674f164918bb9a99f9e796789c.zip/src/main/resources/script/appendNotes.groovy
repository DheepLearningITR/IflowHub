import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String);
    def properties = message.getProperties() as Map<String, Object>;
    def bodyXML = new XmlParser().parseText(body)
    
    def headerNotes = properties.get("headerNotesXML")
    if(headerNotes!=null && !headerNotes.isEmpty()){
       
        def headerNotesXML = new XmlParser().parseText(headerNotes)
    
        headerNotesXML.E101CRMXIF_TLINE.each{
            bodyXML.IDOC.E101CRMXIF_BUSTRANS.E101CRMXIF_TEXT_XT.E101CRMXIF_TEXT[0].append(it)
        }
    }
    
    
    // bodyXML.IDOC.E101CRMXIF_BUSTRANS.E101CRMXIF_BUSTRANS_ITEM.each{ item ->
        
    //     def itemNotesKey = "itemNotesXML_" + item.ITEM_GUID.text()
    //     def itemNotes = properties.get(itemNotesKey)
        
    //     if(itemNotes != null && !itemNotes.isEmpty()){
            
    //         def itemNotesXML = new XmlParser().parseText(itemNotes)
            
    //         itemNotesXML.E102CRMXIF_TLINE.each{
    //             item.E102CRMXIF_TEXT_XT.E102CRMXIF_TEXT[0].append(it)
    //         }
       // }
        
    //}
    
    String outxml= XmlUtil.serialize(bodyXML)
    outxml=outxml.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
    message.setBody(outxml)
    message.setProperty("RequestPayload", outxml);
    
    return message;
}

