import com.sap.it.api.mapping.*;

def String getExchangeProperty(String propertyName, MappingContext context){
	String propertyValue = context.getProperty(propertyName);
    return propertyValue; 
}