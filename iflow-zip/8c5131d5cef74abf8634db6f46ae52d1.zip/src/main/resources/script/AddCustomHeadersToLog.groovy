/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    def headers = message.getHeaders();
	    def properties = message.getProperties();
	    def ibpStep = properties.get('IBPStep');
    	def logCustomHeaders = properties.get("LogCustomHeaders") + ',' + properties.get("LogStandardCustomHeaders");
    	if (ibpStep !='CreateWriteBatches') logCustomHeaders.replaceAll('(^|,)(IBPDestination|IBPBatchKey[^,]*)(,|$)',',');
    	
	    if(logCustomHeaders!=null) {
    	    logCustomHeaders.tokenize(',').each() {
    	        if (it != '') addLogCustomHeaderWithSplit(messageLog, headers, it);		
    	    }
	    }
    	def logCustomProperties = properties.get("LogStandardCustomProperties");
 	    if(logCustomProperties!=null) {
   	        logCustomProperties.tokenize(',').each() {
    	        if (it !='') addLogCustomHeaderWithSplit(messageLog, properties, it);		
    	    }
	    }
   	    def logAttachmentHeaders = properties.get("LogAttachmentHeaders") + ',' + properties.get("LogStandardAttachmentHeaders");
	    if(logAttachmentHeaders!=null) {
    	    logAttachmentHeaders.tokenize(',').each() {
    	        if (it !='') setLogAttachmentHeader(messageLog, headers, it);		
    	    }
	    }

	}
	return message;
}

def void addLogCustomHeaderWithSplit(MessageLog messageLog, Map<String,Object> candidates, String name ) {
    def candidat = candidates.get(name);
    if (candidat != '' && candidat != null) {
        def messageLength = candidat.length();
        if (messageLength<=198) messageLog.addCustomHeaderProperty(name, candidat);
        else {
            int i = 0;
            for (int j = 0; j < messageLength;j += 198) {
                def k = j + 198;
                i++;
                messageLog.addCustomHeaderProperty(name + '.' + i.toString(), candidat.substring(j,k<=messageLength?k:messageLength));
            }
        }
    }
}

def void setLogAttachmentHeader(MessageLog messageLog, Map<String,Object> headers, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addAttachmentAsString(headerName, header.toString(), 'text/plain')	
    }
}
