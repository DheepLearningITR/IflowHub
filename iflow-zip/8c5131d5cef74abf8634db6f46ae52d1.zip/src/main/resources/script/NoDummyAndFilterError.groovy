import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	
	def messageLog = messageLogFactory.getMessageLog(message);
	def headers = message.getHeaders();
	throw new Exception("Please define a dummy customer ID or set a filter for replicating customers from SAP S/4HANA Cloud or both.");  	
	
	return message;
}
