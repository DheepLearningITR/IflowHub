/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.Iterator; 
import java.lang.Thread;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;

def Message processData(Message message) {
       //Body 
       def body = message.getBody();
       message.setBody(body + "Body is modified");
       //Headers 
       def map = message.getHeaders();
       def value = map.get("oldHeader");
       message.setHeader("oldHeader", value + "modified");
       message.setHeader("newHeader", "newHeader");
       //Properties 
       map = message.getProperties();
       value = map.get("oldProperty");
       message.setProperty("oldProperty", value + "modified");
       message.setProperty("newProperty", "newProperty");
       return message;
}

def String getContextProperty(String propName, MappingContext context){
    String propValue = context.getProperty(propName);
	return propValue; 
}


def String getCounter(String counterName,Message message) {
    Integer counterValue = message.getProperty(counterName) as Integer ?:0;
    counterValue = counterValue + 1;
    message.setProperty(counterName,counterValue);
    return counterValue;
}

def String addGetCounter(String counterName,Message message) {
    Integer counterValue = message.getProperty(counterName) as Integer ?:0;
    message.setProperty(counterName,++counterValue);
    return counterValue;
}

def Message logMessage(java.lang.String fileName, Message message) {
	def body = message.getBody(java.lang.String);
	def messageLog = messageLogFactory.getMessageLog(message);
	def counter = getCounter(fileName + 'Counter',message).padLeft(3,' ');
	def logCounter = getCounter('OverallLogCounter',message).padLeft(4,' ');
	if(messageLog != null){
		messageLog.addAttachmentAsString(logCounter + " " + fileName + counter, body, "text/plain");
	};
	
	return message;
}

def Message logTime(java.lang.String fileName, Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	def counter = getCounter(fileName + 'CounterTime',message).padLeft(3,' ');
	def logCounter = getCounter('OverallLogCounter',message).padLeft(4,' ');
	Date date = new Date(); 
	if(messageLog != null){
		messageLog.addAttachmentAsString(logCounter + " " +fileName + counter, date.format("YYYY-MM-dd HH:mm:ss.Ms"), "text/plain");
	};
	
	return message;
}

def Message addBodyToLog(Message message){
    
    
    	/*add message body to logs in case of an exception.*/
	def bodyAsString = message.getBody(java.lang.String);
	
	if (bodyAsString != null) {
	    def headers = message.getHeaders();	
	    def ibpStep = headers.get("IBPStep");
	
    	def messageLog = messageLogFactory.getMessageLog(message);
	    messageLog.addAttachmentAsString('Latest message body coming from step: ' + ibpStep, bodyAsString, 'text/xml');
	}
	else{
	    def error = """<?xml version="1.0" encoding="UTF-8"?><Message>Unknown error</Message>""";
	    message.setBody(error);
	}
    return message;
}


def Message logErrors(Message message) {
    message = logMessage("IBP Commit Errors", message);
	return message;
}

def Message logS4Output(Message message) {
    message = logMessage("S/4 Output", message);
	return message;
}

def Message logS4Input(Message message) {
    message = logMessage("S/4 Input", message);
	return message;
}

def Message logIBPInput(Message message) {
    message = logMessage("IBP Input", message);
	return message;
}

def Message logIBPOutput(Message message) {
    message = logMessage("IBP Output", message);
	return message;
}

def Message logS4OutputTime(Message message) {
    message = logTime("S/4 Output Time", message);
	return message;
}

def Message logS4InputTime(Message message) {
    message = logTime("S/4 Input Time", message);
	return message;
}

def Message logIBPInputTime(Message message) {
    message = logTime("IBP Input Time", message);
	return message;
}

def Message logIBPInputTimeMD(Message message) {
    def masterDataType = message.getHeader("IBPMasterDataType",String);
    message = logTime("IBP Input Time ${masterDataType}", message);
	return message;
}

def Message logIBPOutputTime(Message message) {
    message = logTime("IBP Output Time", message);
	return message;
}

def Message logIBPOutputTimeMD(Message message) {
    def masterDataType = message.getHeader("IBPMasterDataType",String);
    message = logTime("IBP Output Time ${masterDataType}", message);
	return message;
}

def Message logInMappingTime(Message message) {
    message = logTime("In Mapping Time", message);
	return message;
}

def Message logMapStepATime(Message message) {
    message = logTime("Map Step A Time", message);
	return message;
}

def Message logMapStepATimeMD(Message message) {
    def masterDataType = message.getHeader("IBPMasterDataType",String);
    message = logTime("Map Step A Time ${masterDataType}", message);
	return message;
}

def Message logMapStepBTime(Message message) {
    message = logTime("Map Step B Time", message);
	return message;
}

def Message logMapStepBTimeMD(Message message) {
    def masterDataType = message.getHeader("IBPMasterDataType",String);
    message = logTime("Map Step B Time ${masterDataType}", message);
	return message;
}

def Message logMapStepCTime(Message message) {
    message = logTime("Map Step C Time", message);
	return message;
}

def Message logMapStepA(Message message) {
    message = logMessage("Map Step A", message);
	return message;
}

def Message logMapStepB(Message message) {
    message = logMessage("Map Step B", message);
	return message;
}

def Message logMapStepC(Message message) {
    message = logMessage("Map Step C", message);
	return message;
}

def Message logBranchStepA(Message message) {
    message = logMessage("Branch Step A", message);
	return message;
}

def Message logIBPGet(Message message) {
    message = logMessage("IBP Get Interface", message);
	return message;
}

def Message logIBPResult(Message message) {
    message = logMessage("IBP Results", message);
	return message;
}

def Message logLastResponse(Message message) {
    message = logMessage("Last Response", message);
	return message;
}

def Message logErrorResponse(Message message) {
    message = logMessage("Error Response", message);
	def body = message.getBody(java.lang.String);
    def requestBody = message.getProperty('RequestBody');
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null && requestBody != null){
		messageLog.addAttachmentAsString('Request Body', requestBody, "text/plain");
	};
	if(messageLog != null && body != null){
		messageLog.addAttachmentAsString('Response Body with Error', body, "text/plain");
	};
	message = setLogCustomHeaders(message);
	return message;
}

def Message createGuid(Message message) {
    String guid = java.util.UUID.randomUUID(); 
    guid = guid.replace("-","").toLowerCase();
    message.setProperty("guid", guid);
    return message;
}

def Message addIBPTransactionGuid(Message message) {
    String guid = java.util.UUID.randomUUID(); 
    guid = guid.replace("-","").toUpperCase();
    message.setHeader("IBPTransactionGuid", guid);
    return message;
}

def Message wait(Message message) {
    Thread.sleep(5000);
    return message;
}

def Message setIBPWriteStep(Message message) {
    def step = message.getProperty("IBPStep");
    if(step == null)
      step = 'Handshake'
    else if(step == 'Handshake')
      step = 'WriteData'
    else if(step == 'WriteData') {
      def writeRunning = message.getHeader("writeRunning",String);
      if (writeRunning == 'false')
        step = 'ScheduleProcess';
    }
    else if(step == 'ScheduleProcess')
      step = 'GetProcessStatus';
    else if(step == 'GetProcessStatus') {
      def inProcess = message.getProperty("postProcessInProgress");
      if (inProcess == false)
        step = 'GetResult';
    };
    message.setProperty("IBPStep",step);
    return message;
}

def Message removeHeaderQuotes( Message message) {
	def body = message.getBody(java.lang.String);
	body = body.replaceAll("\"LOCID\",\"PRDID\",\"PERIODID4\",\"TSTFR\",\"ACTUALSQTY\"","LOCID,PRDID,PERIODID4,TSTFR,ACTUALSQTY");
    message.setBody(body);
    return message;
}

def Message addPackageSizeToOffset(Message message) {
    message.setProperty("IBPOffset", 3000); 
    return message;
}

def Message storeAddressesAndHeaders(Message message) {
    def nodeListCallsWithHeaders = message.getProperty('nodeListCallsWithHeaders');
    def listDirectProcessAddresses = [];
    def mapAddressesWithHeaders = [:];
    def numberAddresses = nodeListCallsWithHeaders.length;
    for (int i = 0; i < numberAddresses; i++) {
        def addressWithHeaders = nodeListCallsWithHeaders.item(i);
        listDirectProcessAddresses.add(addressWithHeaders.nodeName);
        def attrMap = addressWithHeaders.attributes
        def numberHeaders = attrMap.length;
        def headers = [:];
        for (int j = 0; j < numberHeaders; j++) {
            headers[attrMap.item(j).nodeName] = attrMap.item(j).nodeValue;
        }
        mapAddressesWithHeaders[addressWithHeaders.nodeName] = headers;
    }
    message.setProperty('listDirectProcessAddresses',listDirectProcessAddresses);
    message.setProperty('mapAddressesWithHeaders',mapAddressesWithHeaders);
    message.setProperty('numberDirectProcessCalls',numberAddresses);
    return message;
}

def Message setAddressAndHeaders(Message message) {
    def headers = message.getHeaders();
    def callCounter = message.getProperty('callCounter');
    def listDirectProcessAddresses = message.getProperty('listDirectProcessAddresses')
    def directProcessAddress = listDirectProcessAddresses.getAt(callCounter);
    def allDivertingHeaders = message.getProperty('mapAddressesWithHeaders');
    def divertingHeaders = allDivertingHeaders.get(directProcessAddress);
    def overwrittenHeaders = [:];
    divertingHeaders.each{ 
        overwrittenHeaders[it.key] = headers.get(it.key);
        message.setHeader(it.key,it.value);   
    }
    message.setProperty('overwrittenHeaders',overwrittenHeaders);
    message.setHeader('ProcessDirectAddress',directProcessAddress);
    
    return message;
}

def Message restoreDefaultHeaders(Message message) {
    def overwrittenHeaders = message.getProperty('overwrittenHeaders');
    overwrittenHeaders.each{ 
        message.setHeader(it.key,it.value);   
    }    
    return message;
}



def Message rememberHeaders(Message message) {
    def headers = message.getHeaders();
    message.setProperty("InputHeaders", headers);
    return message;
}

def Message rememberHeadersAndBody(Message message) {
    rememberHeaders(message);
    def body = message.getBody()?:'';
    message.setHeader("InputBody", body);
    return message;
}

/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */

def Message copyDefaultHeaders(Message message) {
    //Headers
    def headers = message.getHeaders();
    LinkedHashMap<String,Object> newHeaders = [:];
    Set<String> keys = headers.keySet();
        
    for (String key : keys) {
        if (key.startsWith('Default')) {
        def newHeaderName = key.substring(7);
            if (newHeaderName != '' && headers.get(newHeaderName) != '-keep as is-') {
                newHeaders.put(newHeaderName,headers.get(key));
            }
            newHeaders.put(key,null);
        }
    }
    
    Set headerSet = newHeaders.entrySet();
    Iterator it = headerSet.iterator();
    while (it.hasNext()) {
        def header = it.next();
        message.setHeader(header.key,header.value);
    }
    /* def value = headers.get("oldHeader");
    message.setHeader("oldHeader", value + " modified");
    message.setHeader("newHeader", "newHeader");
    //Properties
    def properties = message.getProperties();
    value = properties.get("oldProperty");
    message.setProperty("oldProperty", value + " modified");
    message.setProperty("newProperty", "newProperty"); */
    return message; 
}

def Message restoreHeaders(Message message) {
    def headers = message.getHeaders();
    def allowedHeaders = headers.get('AllowedHeaders');
    def inputHeaders = message.getProperty('InputHeaders');
    if (inputHeaders != null) {
        inputHeaders.findAll{it.key ==~ /(?i)($allowedHeaders)/}.each() {  /* case insensitive pattern search */
           message.setHeader(it.key,it.value);
        }
        /* reread, as some headers might be overwritten */
        headers = message.getHeaders();
        message.setProperty('InputHeaders',null);
    }
    
    /* start of creating calculated data */
    /*
    String guid = headers.get("IBPTransactionGuid")?:message.getProperty("SAP_MessageProcessingLogID")?:java.util.UUID.randomUUID().toString().replace("-","").toUpperCase();
    */
    def customers = (headers.get("Customers")?:'').tokenize(',');
    def customerFilterField = headers.get("CustomerFilterField");
    String eqString = '';
    String betweenString = '';
    String customerFilter = '';
    def severalSingletons = false;
    def severalIntervals = false;
    for (customer in customers) {
        def singleCustomers = customer.tokenize('-');
        if (singleCustomers.size == 1) {
            if (eqString != '') {
                eqString += ' or ';
                severalSingletons = true;
            }
            eqString += "customerFieldName eq '" + singleCustomers[0] + "'";
        } 
        else {
            if (betweenString != '') {
                betweenString += ' or ';
                severalIntervals = true;
            }
            betweenString += "customerFieldName ge '" + singleCustomers[0] + "' and customerFieldName le '" + singleCustomers[1] + "'";
        }
    }
    if (betweenString != '' && eqString != '') {
        customerFilter = '(' + eqString + ' or ' + betweenString + ')';
    } 
    else if (eqString != '') {
        customerFilter = "(" + eqString + ")";
    }
    else if (betweenString != '') {
        customerFilter = "(" + betweenString + ")";
    }
    def strategyGroups = (headers.get("PlanningStrategyGroups")?:'').tokenize(',');
    eqString = '';
    severalSingletons = false;
    for (strategyGroup in strategyGroups) {
        if (eqString != '') {
            eqString += ' or ';
            severalSingletons = true;
        }
        eqString += "strategyGroupFieldName eq '" + strategyGroup + "'";
    }
    if ( severalSingletons == true ) eqString = "(${eqString})";
    if (customerFilter == '') {
        customerFilter = eqString;
    } 
    else if (eqString != '') {
        customerFilter += " and ${eqString}";
    }
    def customerFilterWithNode = '_ProductCustomer/any(p:' + customerFilter.replaceAll("customerFieldName","p/$customerFilterField").replaceAll("strategyGroupFieldName","p/_ProductCustomerSupplyPlanning/PlanningStrategyGroup") + ')';
    customerFilter = customerFilter.replaceAll("customerFieldName",customerFilterField).replaceAll("strategyGroupFieldName","_ProductCustomerSupplyPlanning/PlanningStrategyGroup");
    message.setHeader("CustomerFilter", customerFilter); 
    message.setProperty("ProductCustomerFilterWithNode", customerFilterWithNode);
    message.setProperty("ProductCustomerFilter", customerFilter);
    String FieldsPerMDType = '<Fields>';
    String FileNamesPerMDType = '<FileNames>';
    String StagingTablesPerMDType = '<StagingTables>';
    String ColumnList = '<IT_COLUMN_LIST>';
    String iFlowStartTimestamp = headers.get("IFlowStartTimestamp");
    String iFlowStartTimestampDecimalsOnly = iFlowStartTimestamp.replaceAll("[^0-9]","").substring(0,14);
    def iFlowMainMessageId = headers.get('IFlowMainMessageId');
    def IBPMasterDataPrefix = headers.get('IBPMasterDataPrefix');
    def IBPMasterDataTypes = headers.get('IBPMasterDataTypes');
    if (IBPMasterDataTypes != null) {
        IBPMasterDataTypes.tokenize(',').each { MDType ->
            def IBPFields = headers.get('IBPFields' + MDType);
            if(IBPFields!='') {
                FieldsPerMDType += "<${MDType}>${IBPFields}</${MDType}>";
                def FileName = "Prefix_${IBPMasterDataPrefix}_MasterData_${MDType}_CI-RunId_${iFlowMainMessageId}";
                def StagingTable = "SOPMD_STAG_${IBPMasterDataPrefix}${MDType}";
                FileNamesPerMDType += "<${MDType}>${FileName}</${MDType}>";
                StagingTablesPerMDType += "<${MDType}>${StagingTable}</${MDType}>";
                IBPFields.tokenize(',').each { fieldName ->
                    ColumnList += "<item><FILE_NAME>${FileName}</FILE_NAME><TABLE_NAME>${StagingTable}</TABLE_NAME><COLUMN_NAME>${fieldName}</COLUMN_NAME></item>";
                }
            }
        }
    }
    message.setProperty("IBPFieldsPerMDType", FieldsPerMDType << '</Fields>');
    message.setProperty("IBPFileNamesPerMDType", FileNamesPerMDType << '</FileNames>');
    message.setProperty("IBPStagingTablesPerMDType", StagingTablesPerMDType << '</StagingTables>');
    message.setHeader("IFlowStartTimestampDecimalsOnly",iFlowStartTimestampDecimalsOnly);
    message.setHeader("IBPColumnList", ColumnList << '</IT_COLUMN_LIST>');
    return message;
}

def Message restoreHeadersForPlanningStrategyGroup(Message message) {
    def headers = message.getHeaders();
    def allowedHeaders = headers.get('AllowedHeaders');
    def inputHeaders = message.getProperty('InputHeaders');
    if (inputHeaders != null) {
        inputHeaders.findAll{it.key ==~ /(?i)($allowedHeaders)/}.each() {  /* case insensitive pattern search */
           message.setHeader(it.key,it.value);
        }
        /* reread, as some headers might be overwritten */
        headers = message.getHeaders();
        message.setProperty('InputHeaders',null);
    }
    /* start of creating calculated data */
    
    return message;
}

def Message restoreHeadersForEmail(Message message) {
    def headers = message.getHeaders();
    message.setHeader("EmailIFlowMessageID",headers.get("IFlowMessageID"))
    message.setHeader("EmailIFlowName",headers.get("IFlowName"))
    def allowedHeaders = headers.get('EmailAllowedHeaders');
    def inputHeaders = message.getProperty('InputHeaders');
    if (inputHeaders != null) {
        inputHeaders.findAll{it.key ==~ /(?i)($allowedHeaders)/}.each() {  /* case insensitive pattern search */
           message.setHeader(it.key,it.value);
        }
        /* reread, as some headers might be overwritten */
        headers = message.getHeaders();
        message.setProperty('InputHeaders',null);
    }
    /*
    String bodyText = "Messages from IBP steps:\r\n";
    def messagesForBody = message.getHeader("EmailIBPMessagesForBody",java.lang.String[])?:[];
    messagesForBody.each() {
        bodyText += "${it}\r\n";
    }
    message.setBody(bodyText);
    
    /* start of creating calculated data */
    
    
    return message;
}

def Message restoreHeadersForIBPProcess(Message message) {
    def inputBody = message.getProperty('InputBody');
    if (inputBody!='' && inputBody!=null) message.setBody(inputBody);
    def headers = message.getHeaders();
    def allowedHeaders = headers.get('AllowedHeaders');
    def inputHeaders = message.getProperty('InputHeaders');
    if (inputHeaders != null) {
        inputHeaders.findAll{it.key ==~ /(?i)($allowedHeaders)/}.each() {  /* case insensitive pattern search */
           message.setHeader(it.key,it.value);
        }
        /* reread, as some headers might be overwritten */
        headers = message.getHeaders();
        message.setProperty('InputHeaders',null);
    }
    
    /* start of creating calculated data */
    
    
    return message;
}


def Message addResultsToLogAndEmailList(Message message) {
	def headers = message.getHeaders();
	def messagesForEmail = headers.get("EmailIBPMessagesForBody")?:[];
	def ibpMessages = headers.get("IBPMessages");
	def messageLog = messageLogFactory.getMessageLog(message);
	def ibpStep = headers.get("IBPStep");
	def worstIBPMessageType = headers.get("IBPWorstMessageType");
	def messageTruncated = false;
	if (ibpMessages != null) {
    	for (int i = 0; i < ibpMessages.length; i++) {
    	    def content = mapAbapMessageTypeToString(ibpMessages.item(i).getFirstChild().getTextContent()) + ': ' + ibpMessages.item(i).getLastChild().getTextContent();
            messagesForEmail.push(content) ;
            if(messageLog != null){
                if (content.length() > 198) messageTruncated = true;
                messageLog.addCustomHeaderProperty('Message from IBP step ' + ibpStep, content);
            }
        }
        if (messageTruncated == true && messageLog != null) {
            messageLog.addCustomHeaderProperty('Message from IBP step ' + ibpStep, " (There is at least one truncated message. See attachment 'Response Body with Error' for the full message)");
        }
    
        message.setHeader("EmailIBPMessagesForBody",messagesForEmail);
        if (worstIBPMessageType in ['Abort','Error']) {
    	    String customStatus = '';
            switch (ibpStep) {
                case 'Handshake': customStatus = 'IBP Handshake Error'; break;
                case 'WriteData': customStatus = 'IBP WriteData Error'; break;
                case 'ScheduleProcessing': customStatus = 'IBP ScheduleProcessing Error'; break;
                case 'GetProcessingStatus': customStatus = 'IBP GetProcessingStatus Error'; break;
                case 'GetProcessingMessages': customStatus = 'IBP GetProcessingMessages Error'; break;
                default: customStatus = "Unexpected IBP Step ${ibpStep}"; break;
    	    }
    	    message.setHeader("IFlowCustomStatus",customStatus);
    	    message.setProperty("SAP_MessageProcessingLogCustomStatus",customStatus);
    	}
	}
	return message;
}

def String mapAbapMessageTypeToString(String abapMessageType) {
    switch (abapMessageType) {
        case 'A': return 'Abort';
        case 'E': return 'Error';
        case 'W': return 'Warning';
        case 'I': return 'Information';
        case 'S': return 'Success';
        default: return abapMessageType;
    }
}

def Message raiseIBPErrorMessage(Message message) {
	def headers = message.getHeaders();
	def ibpStep = headers.get("IBPStep");	
	throw new Exception("Error in IBP step ${ibpStep}");
	return message;
}


def Message setLogCustomHeaders(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    def headers = message.getHeaders();
	    String emailBody = headers.get('emailBody') + "\r\nLog custom headers:";
    	def logCustomHeaders = headers.get("LogCustomHeaders");
    	def logCustomProperties = headers.get("LogCustomProperties");
    	def logAttachmentHeaders = headers.get("LogAttachmentHeaders");
	    if(logCustomHeaders!=null) {
    	    logCustomHeaders.tokenize(',').each() {
    	        setLogCustomHeader(headers, messageLog, it);		
    	        emailBody += "\r\n\${it}: ${headers.get(it)}"
    	    }
	    }
	    if(logCustomProperties!=null) {
    	    logCustomProperties.tokenize(',').each() {
    	        setLogCustomProperty(message, messageLog, it);
    	        emailBody += "\r\n\${it}: ${message.getProperty(it)}"
    	    }
	    }
	    if(logAttachmentHeaders!=null) {
    	    logAttachmentHeaders.tokenize(',').each() {
    	        setLogAttachmentHeader(headers, messageLog, it);		
    	    }
	    }
	    
	}
	return message;
}

def void setLogCustomHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addCustomHeaderProperty(headerName, header.toString());		
    }
}

def void setLogCustomProperty(Message message, MessageLog messageLog, String propertyName) {
    
	def property = message.getProperty(propertyName);		
	if(property!=null){
		messageLog.addCustomHeaderProperty(propertyName, property.toString());		
    }
}

def void setLogAttachmentHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addAttachmentAsString(headerName, header.toString(), 'text/plain')	
    }
}

def String subStringRobust(String sourceString, String beginIndex, String endIndex, MappingContext context) {
    String stringNotNull = "";
    if(sourceString != null){
        stringNotNull = sourceString;
    };
    Integer beginInt = beginIndex.toInteger();
    Integer endInt = endIndex.toInteger();
    String stringResult;
    if(stringNotNull.length( ) <= beginIndex) {
      stringResult = '';
    } 
    else {
        if(stringNotNull.length( ) <= endIndex) {
            stringResult = stringNotNull.substring(beginInt);
        } 
        else{
            stringResult = stringNotNull.substring(beginInt,endInt);
        }
    }
    return stringResult;
}

def String subString0to5(String sourceString, MappingContext context) {
    String stringNotNull = "";
    if(sourceString != null){
        stringNotNull = sourceString;
    }
    String stringResult;
    if(stringNotNull.length( ) <= 5) {
      stringResult = stringNotNull;
    } else{
        stringResult = stringNotNull.substring(0,5);
    }
    return stringResult;
}

def String subString5to10(String sourceString, MappingContext context) {
    String stringNotNull = "";
    if(sourceString != null){
        stringNotNull = sourceString;
    }
    String stringResult;
    if(stringNotNull.length( ) <= 5) {
      stringResult = '';
    } else{
        if(stringNotNull.length( ) <= 10) {
            stringResult = stringNotNull.substring(5);
        } else{
            stringResult = stringNotNull.substring(5,10);
        }
    }
    return stringResult;
}

def String subString10to20(String sourceString, MappingContext context) {
    String stringNotNull = "";
    if(sourceString != null){
        stringNotNull = sourceString;
    }
    String stringResult;
    if(stringNotNull.length( ) <= 10) {
      stringResult = '';
    } 
    else{
        if(stringNotNull.length( ) <= 20) {
            stringResult = stringNotNull.substring(10);
        } 
        else{
            stringResult = stringNotNull.substring(10,20);
        }
    }
    return stringResult;
}
