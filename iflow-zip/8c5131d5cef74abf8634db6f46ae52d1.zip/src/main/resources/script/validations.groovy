import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import com.sap.it.api.mapping.*;


def validateFieldExtensions(Message message) {
    
    def headers = message.getHeaders();
    def field_list = headers.get('AttributesinSAPIBP');
    def field_extensions = headers.get('FieldExtensions');

if (!field_extensions.isEmpty()) {

//check if field extensions starts with < and ends with >

    if (field_extensions.startsWith('<') && field_extensions.endsWith('>')) {
        
    } else {
        throw new Exception ("Start the Field Extensions parameter with '<' and end it with '>'.")
    }   
    
//check if all tag names in field extensions are included in the Fields to Update in SAP IBP parameter      

// Define a pattern to match tag names: it gets every string which is directly following the '<' sign
    def pattern = /<(\w+)\s/

// Find all matches for the pattern in the string
    def matches = (field_extensions =~ pattern)

// Extract tag names
    def tagNames = matches.collect { it[1] }

//check if all tag names are included    
    boolean allTagsInFieldList = tagNames.every { tagName -> field_list.split(',').contains(tagName) }

    if (allTagsInFieldList) {
        
    } else {
        def missingTags = tagNames.findAll { tagName -> !field_list.split(',').contains(tagName) }
        throw new Exception ("Fields are missing from the Fields to Update in SAP IBP parameter which are included in the Field Extensions parameter. Missing fields: $missingTags")
    }
    //only checks the syntax
    def fieldExtensionsXML = '<Root>'+field_extensions+'</Root>'
    def xmlVal = new XmlSlurper().parse(new StringReader(fieldExtensionsXML))
		
  }   
    return message;
}
