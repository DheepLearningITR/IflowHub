import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import com.sap.it.api.mapping.*;

def Message processData(Message message) {
    def headers = message.getHeaders();
    def customers = (headers.get("CustomerFilter")?:'').tokenize(',');
    def customerFilters=[];
    def filters = '';
    
    for (customer in customers) {
        def singleCustomers = customer.findAll('(?<=(?:^|-))(([^-\"]*?)|(\"(?:[^\"]+|\"\")*\"))(?=(?:-|$))');
        customerFilters += (singleCustomers.size() <= 1) ? "Customer eq '${singleCustomers[0].replaceAll('^\"|\"$','')}'":"Customer ge '${singleCustomers[0].replaceAll('^\"|\"$','')}' and Customer le '${singleCustomers[1].replaceAll('^\"|\"$','')}'";
    }
    
    if (customerFilters.size() > 0) filters += (((customerFilters.size() > 1)?'(':'') + customerFilters.join(' or ') + ((customerFilters.size() > 1)?')':'')); 
    message.setHeader("S4CustomerFilter",filters );
    return message;

}
