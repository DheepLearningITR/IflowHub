/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.HashMap;
import java.util.UUID; 
import java.util.Iterator; 
import java.util.List; 
import java.lang.Thread;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;
import groovy.xml.XmlUtil;


def Message processData(Message message) {
    def headers = message.getHeaders();
    def props = message.getProperties();

    def plants = (headers.get("S4Plants")?:'').tokenize(',');
    def productPlantNodeShortcut = props.get('S4ProductPlantNodeShortcut') ?: '';
    def supplyPlanningNodeShortcut = props.get('S4ProductPlantSupplyPlanningNodeShortcut') ?: '';
    def productShortcutString = props.get('S4ProductNodeShortcut') ?: '';
    def productIdFrom = headers.get('S4ProductIdFrom');
    def productIdAfter = headers.get('S4ProductIdAfter');
    def productIdTo = headers.get('S4ProductIdTo');   
    def productPlantFurtherFilters = ('(' + (headers.get('S4ProductPlantFurtherFilters')?:'') + ')').replaceFirst('^[(][)]$','');
    def productFurtherFilters = ('(' + (headers.get('S4ProductFurtherFilters')?:'') + ')').replaceFirst('^[(][)]$','');
        
    String eqString = '';
    String betweenString = '';
    String plantIdFilter = '';
    String locationIdFilter = '';
    String eqStringShortcut = '';
    String betweenStringShortcut = '';
    String plantFilterShortcut = '';
    def severalSingletons = false;
    def severalIntervals = false;
    def addBrackets = false;
    for (plant in plants) {
        def singlePlants = plant.tokenize('-');
        if (plantIdFilter != '') {
            plantIdFilter += ' or ';
            addBrackets = true;
        }
        plantIdFilter += (singlePlants.size == 1) ? "sp/Plant eq '${singlePlants[0]}'":"sp/Plant ge '${singlePlants[0]}' and sp/Plant le '${singlePlants[1]}'";
    }
    if (addBrackets) plantIdFilter = '(' + plantIdFilter + ')';
    
    def strategyGroups = (headers.get("PlanningStrategyGroups")?:'').tokenize(',');
    addBrackets = (strategyGroups.size >= 2);
    eqString = strategyGroups.findAll{it!=''}.join("' or sp/_ProductPlantSupplyPlanning/PlanningStrategyGroup eq '");
    eqString = eqString != '' ? "sp/_ProductPlantSupplyPlanning/PlanningStrategyGroup eq '${eqString}'": '';
    if (addBrackets) eqString = "(${eqString})";
    def plantFilter = [productPlantFurtherFilters,plantIdFilter,eqString].findAll{it!=''}.join(' and ');

    def productIdFilter = '';
    
    if (productPlantFurtherFilters != null) {
        message.setHeader("S4PlantFilter", plantFilter.replaceAll('sp/',''));
    }
    else {
        message.setHeader("S4ProductPlantFilter", plantFilter);
        productIdFilter = [(productIdAfter != '' && productIdAfter >= productIdFrom)?"Product gt '${productIdAfter}'":(productIdFrom == '')?'':(productIdFrom != '' && productIdFrom == productIdTo)?"Product eq '${productIdFrom}'":"Product ge '${productIdFrom}'"
        ,(productIdTo > productIdFrom)?"Product le '${productIdTo}'":''].findAll{it!=''}.join(' and ');
        message.setHeader("S4ProductIdFilter", productIdFilter);
        def productFilter = [productFurtherFilters,productIdFilter].findAll{it!=''}.join(' and ');
        def productPlantCountFilter = [productFilter,plantFilter].findAll{it!=''}.join(' and ').replaceAll("(^|[^a-zA-Z0-9])(sp\\/Plant)([^a-zA-Z0-9])",'$1Plant$3').replaceAll("(^|[^a-zA-Z0-9])(pr\\/)",'$1_Product/').replaceAll("(^|[^a-zA-Z0-9])(pl\\/)",'$1_ProductPlant/').replaceAll("(^|[^a-zA-Z0-9])(sp\\/)",'$1');
        message.setHeader("S4ProductFilter", productFilter);
        message.setHeader("S4ProductPlantCountFilter", productPlantCountFilter);
        String FieldsPerMDType = '<Fields>';
        String FileNamesPerMDType = '<FileNames>';
        String StagingTablesPerMDType = '<StagingTables>';
        String ColumnList = '<IT_COLUMN_LIST>';
        String iFlowStartTimestamp = headers.get("IFlowStartTimestamp");
        String iFlowStartTimestampDecimalsOnly = iFlowStartTimestamp.replaceAll("[^0-9]","").substring(0,14);
        def iFlowMainMessageId = headers.get('IFlowMainMessageId');
        def IBPMasterDataPrefix = headers.get('IBPMasterDataPrefix');
        def IBPMasterDataTypes = headers.get('IBPMasterDataTypes');
        if (IBPMasterDataTypes != null) {
            IBPMasterDataTypes.tokenize(',').each { MDType ->
                def IBPFields = headers.get('IBPFields' + MDType);
                if(IBPFields!='' && IBPFields!=null) {
                    FieldsPerMDType += "<${MDType}>${IBPFields}</${MDType}>";
                    def FileName = "Prefix_${IBPMasterDataPrefix}_MasterData_${MDType}_CI-RunId_${iFlowMainMessageId}";
                    def StagingTable = "SOPMD_STAG_${IBPMasterDataPrefix}${MDType}";
                    FileNamesPerMDType += "<${MDType}>${FileName}</${MDType}>";
                    StagingTablesPerMDType += "<${MDType}>${StagingTable}</${MDType}>";
                    IBPFields.tokenize(',').each { fieldName ->
                        ColumnList += "<item><FILE_NAME>${FileName}</FILE_NAME><TABLE_NAME>${StagingTable}</TABLE_NAME><COLUMN_NAME>${fieldName}</COLUMN_NAME></item>";
                    }
                }
            }
        }
        message.setProperty("IBPFieldsPerMDType", FieldsPerMDType << '</Fields>');
        message.setProperty("IBPFileNamesPerMDType", FileNamesPerMDType << '</FileNames>');
        message.setProperty("IBPStagingTablesPerMDType", StagingTablesPerMDType << '</StagingTables>');
        message.setHeader("IFlowStartTimestampDecimalsOnly",iFlowStartTimestampDecimalsOnly);
        message.setHeader("IBPColumnList", ColumnList << '</IT_COLUMN_LIST>');
    }

    return message;
}

def Message getSalesHistoryParams(Message message) {
    def headers = message.getHeaders();
    def props = message.getProperties();

    def salesHistoryFilter = headers.get('S4SalesHistoryFilter')?:'';
    def dateFrom = headers.get('S4DateFrom')?:'';
    def dateTo = headers.get('S4DateTo')?:'';
    def dateAndQuantityType = headers.get('S4DateAndQuantityType')?:'';
    def timeAggregationLevel = headers.get('S4TimeAggregationLevel')?:'';
    def productFrom = headers.get('S4ProductFrom')?:'';
    def productTo = headers.get('S4ProductTo')?:'';
    def customerSourceField = headers.get('S4CustomerSourceField')?:'';

    def plants = (headers.get("S4Plants")?:'').tokenize(',');
    def ibpLocations = headers.get("IBPLocations") ?:'';
    def locations = (ibpLocations == "-same as S4Plants-")? plants: ibpLocations == ''? []:ibpLocations.tokenize(',');
    def filters=[];
    def plantFilters=[];
    for (plant in plants) {
        def singlePlants = plant.tokenize('-');
        plantFilters += (singlePlants.size() <= 1) ? "Plant eq '${singlePlants[0]}'":"Plant ge '${singlePlants[0]}' and Plant le '${singlePlants[1]}'";
    }
    def locationFilter = [];
    for (location in locations) {
        def locationList = location.tokenize('-');
        locationFilter += (locationList.size() <= 1) ? "LOCID eq '${locationList[0]}'":"LOCID ge '${locationList[0]}' and LOCID le '${locationList[1]}'";
    }
    def locationIdFilter = ((locationFilter.size() > 1)?'(':'') + locationFilter.join(' or ') + ((locationFilter.size() > 1)?')':'');
    message.setHeader("IBPLocationIdFilter", locationIdFilter );
    if (salesHistoryFilter!='')
      filters += '(' + salesHistoryFilter + ')';
    if (plantFilters.size() > 0) filters += (((plantFilters.size() > 1)?'(':'') + plantFilters.join(' or ') + ((plantFilters.size() > 1)?')':'')); 
    def orderByGroupByFields = ['Product','Plant'];
    if (!(customerSourceField in ['','DUMMY'])) orderByGroupByFields << customerSourceField;
    def quantityField = (dateAndQuantityType='R') ? 'ScheduleLineOrderQuantity' : (dateAndQuantityType='C') ? 'ConfdOrderQtyByMatlAvailCheck' : '';
    def dateAndQuantityTypeUpper = dateAndQuantityType.length()>0?dateAndQuantityType.substring(0,1).toUpperCase():' ';
    def timeAggregationLevelUpper = timeAggregationLevel.length()>0?timeAggregationLevel.substring(0,1).toUpperCase():' ';
    if (dateAndQuantityTypeUpper == 'R') filters += "IsRequestedDelivSchedLine eq true";
    if (dateAndQuantityTypeUpper == 'C') filters += "IsConfirmedDelivSchedLine eq true";
    switch (dateAndQuantityTypeUpper + timeAggregationLevelUpper) {
        case 'RD': /* requested, date */
            orderByGroupByFields << 'RequestedDeliveryDate';
            if (dateFrom!='') filters += "RequestedDeliveryDate ge " + dateFrom;
            if (dateTo!='') filters += "RequestedDeliveryDate le " + dateTo;
            break;
        case 'RT':    /* requested, technical week */
            orderByGroupByFields << 'FirstDayOfWeekDate';
            orderByGroupByFields << 'FirstDayOfMonthDate';
            if (dateFrom!='') filters += "(FirstDayOfWeekDate ge " + dateFrom + " or FirstDayOfMonthDate ge " + dateFrom + ")";
            if (dateTo!='') filters += "FirstDayOfWeekDate le " + dateTo + " and FirstDayOfMonthDate le " + dateTo + "";
            break;
        case 'RW':    /* requested, week */
        case 'RC':    /* requested, calendar week */
            orderByGroupByFields << 'FirstDayOfWeekDate';
            if (dateFrom!='') filters += "FirstDayOfWeekDate ge " + dateFrom;
            if (dateTo!='') filters += "FirstDayOfWeekDate le " + dateTo;
            break;
        case 'RM':    /* requested, technical week */
            orderByGroupByFields << 'FirstDayOfMonthDate';
            if (dateFrom!='') filters += "FirstDayOfMonthDate ge " + dateFrom;
            if (dateTo!='') filters += "FirstDayOfMonthDate le " + dateTo;
            break;
        case 'CD': /* requested, date */
            orderByGroupByFields << 'ConfirmedDeliveryDate';
            if (dateFrom!='') filters += "ConfirmedDeliveryDate ge " + dateFrom;
            if (dateTo!='') filters += "ConfirmedDeliveryDate le " + dateTo;
            break;
        default:
            throw new Exception("Unsupported combination of S4DateAndQuantityType = '$dateAndQuantityType' and S4TimeAggregationLevel = '$timeAggregationLevel'");
            break;
    }
    message.setHeader("S4Filters",filters.join(' and '));
    message.setHeader("S4QuantityField",quantityField);
    message.setHeader("S4OrderByGroupByFields",orderByGroupByFields.join(','));
    
    return message;
}



def String mapAbapMessageTypeToString(String abapMessageType) {
    switch (abapMessageType) {
        case 'A': return 'Abort';
        case 'E': return 'Error';
        case 'W': return 'Warning';
        case 'I': return 'Information';
        case 'S': return 'Success';
        default: return abapMessageType;
    }
}

def Message raiseIBPErrorMessage(Message message) {
	def headers = message.getHeaders();
	def ibpStep = headers.get("IBPStep");	
	throw new Exception("Error in IBP step ${ibpStep}");
	return message;
}


def Message setLogCustomHeaders(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    def headers = message.getHeaders();
	    String emailBody = headers.get('emailBody') + "\r\nLog custom headers:";
    	def logCustomHeaders = headers.get("LogCustomHeaders");
    	def logCustomProperties = headers.get("LogCustomProperties");
    	def logAttachmentHeaders = headers.get("LogAttachmentHeaders");
	    if(logCustomHeaders!=null) {
    	    logCustomHeaders.tokenize(',').each() {
    	        setLogCustomHeader(headers, messageLog, it);		
    	        emailBody += "\r\n\${it}: ${headers.get(it)}"
    	    }
	    }
	    if(logCustomProperties!=null) {
    	    logCustomProperties.tokenize(',').each() {
    	        setLogCustomProperty(message, messageLog, it);
    	        emailBody += "\r\n\${it}: ${message.getProperty(it)}"
    	    }
	    }
	    if(logAttachmentHeaders!=null) {
    	    logAttachmentHeaders.tokenize(',').each() {
    	        setLogAttachmentHeader(headers, messageLog, it);		
    	    }
	    }
	    
	}
	return message;
}

def void setLogCustomHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addCustomHeaderProperty(headerName, header.toString());		
    }
}

def void setLogCustomProperty(Message message, MessageLog messageLog, String propertyName) {
    
	def property = message.getProperty(propertyName);		
	if(property!=null){
		messageLog.addCustomHeaderProperty(propertyName, property.toString());		
    }
}

def void setLogAttachmentHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addAttachmentAsString(headerName, header.toString(), 'text/plain')	
    }
}





