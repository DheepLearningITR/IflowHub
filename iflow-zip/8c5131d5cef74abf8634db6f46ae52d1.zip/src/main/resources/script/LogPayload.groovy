import com.sap.gateway.ip.core.customdev.util.Message


//function CreateIBPBatches definition
Message CreateIBPBatches(Message message) {
    def map = message.headers
    def property_EnableLogging = map.get('DetailedTraceLog')
    message.setHeader('SAP_IsIgnoreProperties', true)
    //logs if EnableLogging property is set as true
    if(property_EnableLogging){
        if (property_EnableLogging.toUpperCase() == 'TRUE') {
            String body = message.getBody(String) as String
            def messageLog = messageLogFactory.getMessageLog(message)
            //name of the file
            messageLog.addAttachmentAsString('Create IBP Batches Log', body, 'text/plain')
        }
    }

    return message
}
