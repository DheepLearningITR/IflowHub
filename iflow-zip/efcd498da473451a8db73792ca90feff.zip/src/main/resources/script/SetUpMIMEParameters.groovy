import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Iterator;
import javax.activation.DataHandler;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*
import com.sap.gateway.ip.core.customdev.util.Message


def Message processData(Message message) {
    
    //Fetch the parameters
    
     def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)
     def path = message.getProperties().get("SharedSecretPath")
     def secureParameter = secureStorageService.getUserCredential(path)
     def SharedSecret = secureParameter.getPassword().toString()
    // message.setProperty("sharedsecretariba", SharedSecret) 
    
    
    
    //def SharedSecret = message.getProperties().get("SharedSecret")
    def Event = message.getProperties().get("Event")
    def Operation=message.getProperties().get("Operation")
    def ANID=message.getProperties().get("ANID")
    def SystemID=message.getProperties().get("SystemID")
    def erp_type=message.getProperties().get("erp_type")
    def Attachment = message.getProperties().get("Attachment");
        
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream()
    
    try{
    
        byte[] bytes = message.getBody(byte[])
        //  Construct Multipart
        MimeBodyPart bodyPartHead1 = new MimeBodyPart()
        bodyPartHead1.setText(SharedSecret)
        bodyPartHead1.setDisposition('form-data; name="sharedSecret"')
        
        MimeBodyPart bodyPartHead2 = new MimeBodyPart()
        bodyPartHead2.setText(Event)
        bodyPartHead2.setDisposition('form-data; name="event"')
        
        MimeBodyPart bodyPartHead3 = new MimeBodyPart()
        bodyPartHead3.setText(Operation)
        bodyPartHead3.setDisposition('form-data; name="operation"')
        
        MimeBodyPart bodyPartHead4 = new MimeBodyPart()
        bodyPartHead4.setText(ANID)
        bodyPartHead4.setDisposition('form-data; name="ANID"')
        
        MimeBodyPart bodyPartHead5 = new MimeBodyPart()
        bodyPartHead5.setText(SystemID)
        bodyPartHead5.setDisposition('form-data; name="SystemID"')
        
        MimeBodyPart bodyPartHead6 = new MimeBodyPart()
        bodyPartHead6.setText(erp_type)
        bodyPartHead6.setDisposition('form-data; name="erp_type"')
        
        MimeBodyPart bodyPart = new MimeBodyPart()
        ByteArrayDataSource dataSource = new ByteArrayDataSource(bytes, 'application/zip')
        DataHandler byteDataHandler = new DataHandler(dataSource)
        bodyPart.setDataHandler(byteDataHandler)
        bodyPart.setFileName(Attachment)
        bodyPart.setDisposition('form-data; name="content"')
    
        MimeMultipart multipart = new MimeMultipart()
        multipart.addBodyPart(bodyPartHead1)
        multipart.addBodyPart(bodyPartHead2)
        multipart.addBodyPart(bodyPartHead3)
        multipart.addBodyPart(bodyPartHead4)
        multipart.addBodyPart(bodyPartHead5)
        multipart.addBodyPart(bodyPartHead6)

        
        multipart.addBodyPart(bodyPart)
        
        multipart.updateHeaders()
        
        multipart.writeTo(outputStream)
        message.setBody(outputStream.toByteArray()); 
        
      
        // Set Content type with boundary
        String boundary = (new ContentType(multipart.contentType)).getParameter('boundary');
        message.setHeader('Content-Type', "multipart/form-data; boundary=\"${boundary}\"")
         //Calculate message size
      //  message.setHeader('Content-length', message.getBodySize())
      
    }catch(Exception e){
        
    }finally{
        outputStream.close()
    }


    return message
}