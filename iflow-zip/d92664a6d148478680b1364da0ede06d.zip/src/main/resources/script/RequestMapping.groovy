import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Retrieve headers from the message
    def headers = message.getHeaders()
    // Extract the JSON string from the header named 'FormattedHTTPQuery'
    def jsonString = headers.get("FormattedHTTPQuery")
    
    // Parse the JSON string into a JSON object
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(jsonString)

    // Initialize a writer for building the XML string
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.setDoubleQuotes(true) // Use double quotes for XML attributes

    // Build the XML structure with the root element and namespace
    xml.'n0:IsuC4cV2PaymentsGet'('xmlns:n0': 'urn:sap-com:document:sap:soap:functions:mc-style') {
        // Handle dueDateFrom and dueDateTo if present in the JSON object
        if (jsonObject.dueDateFrom || jsonObject.dueDateTo) {
            ItDueDate {
                'item' {
                    Sign('I') 
                    Option('BT') 
                    DateFrom(jsonObject.dueDateFrom?.get(0)?.value ?: '') 
                    DateTo(jsonObject.dueDateTo?.get(0)?.value ?: '') 
                }
            }
        }

        // Iterate through each key-value pair in the JSON object
        jsonObject.each { key, value ->
            switch (key) {

                case 'contractAccountId':
                    IvContractAccount(value[0].value)
                    break
                case 'dateFrom':
                    IvDateFrom(value[0].value) 
                    break
                case 'dateTo':
                    IvDateTo(value[0].value)
                    break
                case 'documentNumber':
                    IvDocumentNumber(value[0].value)
                    break
                case 'maximumCount':
                    IvMaxCount(value[0].value) 
                    break
                case 'postingDateFrom':
                    IvPostingDateFrom(value[0].value)
                    break
                case 'postingDateTo':
                    IvPostingDateTo(value[0].value)
                    break
                case 'language':
                    IvLanguage(value[0].value)
                    break

                    
                default:
                    // Handle any additional dynamic fields here if necessary
                    break
            }
        }

        // Always include ItAdditionalFilter with constant values
        ItAdditionalFilter {
            'item' {
                Fieldname('QueryFilter') 
                FieldValue(headers.get("QueryFilter")) 
                Sign('I') 
                Option('') 
                Low("") 
                High("") 
            }
        }
    }

    // Set the XML output as the message body
    message.setBody(writer.toString())

    // Return the modified message
    return message
}
