import src.main.resources.script.HelperClass;
import groovy.time.TimeCategory
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.regex.Pattern;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.text.DecimalFormat;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat


def Message processData(Message message) {

	def messageLog = messageLogFactory.getMessageLog(message);

	messageLog.setStringProperty("Logging#2", "Printing Input Payload As Attachment")
	messageLog.addAttachmentAsString("#SFTPFILEPOSTING",message.getBody(String), "text/plain");

	return message;
}

