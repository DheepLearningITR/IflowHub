
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {

	message.setBody("<Empty/>")

	def messageLog = messageLogFactory.getMessageLog(message);
	def jobs = message.getProperty("analyzeJobs")
	def logging = message.getProperty("logging")

	def xmlGo = new StringWriter()

	def buildXMLG0 = new MarkupBuilder(xmlGo)

	int flag = 0

	buildXMLG0.FetchData {
		jobs.each { key, value ->
			List<String> xmlValues = value.split("\\|")
                def files = xmlValues[1]
                
                if(files!=null && !files.toString().equalsIgnoreCase(""))
                {
                files.split(",").eachWithIndex{ String entry, int i ->

                    FetchJob {
                        JobID(key)
                        Process(xmlValues[2])
                        FileName(entry)
                        flag++
                    }
                }
                }
		}
	}

	if(flag==0)
	    message.setProperty("ProcessMessage",'false')
	else
        message.setProperty("ProcessMessage",'true')
			

	message.setBody(xmlGo.toString())
	
	if(logging.equalsIgnoreCase("Yes"))
	{
	    messageLog.setStringProperty("Logging#2", "Printing Input Payload As Attachment")
	    messageLog.addAttachmentAsString("#AnalyzeJobs", jobs.toString(), "text/plain");
	    messageLog.addAttachmentAsString("#FormDataFetchPayload", xmlGo.toString(), "text/xml");
	}
	
	return message;
}

