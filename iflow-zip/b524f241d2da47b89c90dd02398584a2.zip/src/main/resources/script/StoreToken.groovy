import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper

def Message processData(Message message) {
	
	//Body 
    def body = message.getBody(java.lang.String) as String;
	
	def messageLog = messageLogFactory.getMessageLog(message);
	
    def jsonSlurper = new JsonSlurper()
    def parseJson = jsonSlurper.parseText(body)
	
	def token = parseJson.'access_token'.toString()
	
	def authToken = "Bearer " + token
	
	message.setProperty("BearerToken",authToken)
	
	messageLog.setStringProperty("Logging#2", "Printing Input Payload As Attachment")
	messageLog.addAttachmentAsString("#1Token",authToken, "text/json");
	
	
	message.setBody("<TEST/>")
	
	return message
	   
}

