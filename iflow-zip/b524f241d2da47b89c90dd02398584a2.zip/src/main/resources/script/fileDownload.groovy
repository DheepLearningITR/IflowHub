import com.sap.gateway.ip.core.customdev.util.Message;
import groovyx.net.http.RESTClient
import java.util.HashMap;
import java.io.InputStream
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.List;
import java.util.ArrayList;
import java.nio.charset.StandardCharsets;
import groovy.json.JsonSlurper


def Message processData(Message message) {

    def messageHeaders = message.getHeaders()
    def apikeyOpenAPI = messageHeaders.get("apikey");
    def authorizationOpenAPI = messageHeaders.get("Authorization")
    def p2pHost = message.getProperty("p2pHost")
    def realm = message.getProperty("realm")
    def logging = message.getProperty("logging")
    
    def sleepTime_FileFetch = message.getProperty("sleepTime_FileFetch")

    def messageLog = messageLogFactory.getMessageLog(message);

    String xmlContent = message.getBody(String)

    def xmlSlurper = new XmlSlurper().parseText(xmlContent)
    def jsonSlurper = new JsonSlurper()
    def invoiceReconcilationMap = [:]
    String _reportingContent = ''

    def fileHeader = messageHeaders.get("ReportHeaders")
    def fileContents = ''

    xmlSlurper.FetchJob.each { eachJob ->


        def uriJobID = eachJob.JobID.toString()
        def uriFileName = eachJob.FileName.toString()

        String fetchURI = 'https://' + p2pHost + '/api/analytics-reporting-jobresult/v1/prod/jobs/' + uriJobID + '/files/' + uriFileName + '?realm=' + realm

        if(logging.equalsIgnoreCase("Yes"))
            messageLog.addAttachmentAsString("#ZIP Fetch Input", apikeyOpenAPI + "\n" + authorizationOpenAPI + "\n\n" + fetchURI, "text/json");


        RESTClient client = new RESTClient(fetchURI)

        def response = client.get(
                headers: ["Authorization": authorizationOpenAPI,
                          "apikey"       : apikeyOpenAPI]
        )

        def out = response.data


        InputStream is2 = out
        ZipInputStream zipStream = new ZipInputStream(is2);
        ZipEntry entry = zipStream.getNextEntry();
        byte[] buf = new byte[1024];
        while (entry != null) {
            if (entry.getName().equals("records.txt")) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                int m;
                while ((m = zipStream.read(buf, 0, 1024)) > -1) {
                    baos.write(buf, 0, m);
                }
                _reportingContent = new String(baos.toByteArray(), StandardCharsets.UTF_8)
                if(logging.equalsIgnoreCase("Yes"))
                    messageLog.addAttachmentAsString("#ZIP OUTPUT RAWCONTENT", fileHeader + "\n\nOnline=>" + new String(baos.toByteArray(), StandardCharsets.UTF_8), "text/json");
            }
            zipStream.closeEntry();
            entry = zipStream.getNextEntry();
        }

        message.setProperty("JOBID_PURGE", uriJobID.toString())
        message.setHeader("JOBID_PURGE", uriJobID.toString())
        
        message.setHeader("SAP_ApplicationID",uriJobID.toString())
        
        sleep(sleepTime_FileFetch.toInteger())
    }

    message.setBody(_reportingContent)

    return message;
}