import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper


def Message processData(Message message) {

	def content = message.getBody(String)

	def xmlParse = new XmlSlurper().parseText(content)

	def jobID = xmlParse.Job.JobID.toString()

	message.setProperty("APIJobID",jobID)

	return message;
}

