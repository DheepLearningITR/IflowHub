
import com.sap.gateway.ip.core.customdev.util.Message;
import groovyx.net.http.RESTClient
import java.util.HashMap;
import java.io.InputStream
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.List;
import java.util.ArrayList;
import java.nio.charset.StandardCharsets;
import groovy.json.JsonSlurper


def Message processData(Message message) {
	
	def messageHeaders = message.getHeaders()
	def apikeyOpenAPI = messageHeaders.get("apikey");
	def authorizationOpenAPI = messageHeaders.get("Authorization")
	def realm = message.getProperty("realm")
	
	
	def messageLog = messageLogFactory.getMessageLog(message);

	String xmlContent = message.getBody(String)

	def xmlSlurper = new XmlSlurper().parseText(xmlContent)
	def jsonSlurper = new JsonSlurper()
	def invoiceReconcilationMap = [:]


	xmlSlurper.FetchJob.each { eachJob->


		def uriJobID = eachJob.JobID.toString()
		def uriFileName = eachJob.FileName.toString()
		
		String fetchURI = 'https://eu.openapi.ariba.com/api/procurement-reporting-jobresult/v2/prod/jobs/'+ uriJobID + '/files/'+uriFileName+'?realm='+realm

		RESTClient client = new RESTClient(fetchURI)

		def response = client.get(
				headers: ["Authorization": authorizationOpenAPI,
					"apikey" : apikeyOpenAPI ]
				)

		def out = response.data
		
		String _IRContent = ''

		InputStream is2 = out
		ZipInputStream zipStream = new ZipInputStream(is2);
		ZipEntry entry=zipStream.getNextEntry();
		byte[] buf=new byte[1024];
		while (entry != null) {
			if (entry.getName().equals("records.txt")) {
				ByteArrayOutputStream baos=new ByteArrayOutputStream();
				int m;
				while ((m=zipStream.read(buf,0,1024)) > -1) {
					baos.write(buf,0,m);
				}
				_IRContent = new String(baos.toByteArray(),StandardCharsets.UTF_8)
				//messageLog.addAttachmentAsString("#ZIP OUTPUT IR FileName",new String(baos.toByteArray(),StandardCharsets.UTF_8), "text/json");
			}
			zipStream.closeEntry();
			entry=zipStream.getNextEntry();
		}


		def jsonSlupIR = jsonSlurper.parseText(_IRContent)
		
		jsonSlupIR.each { eachInvoiceR ->

			def (IR_TimeCreated, IR_Tax_AmountInReportingCurrency, IR_Tax_ApproxAmountInBaseCurrency, IR_Tax_Amount, IR_Tax_ConversionDate, IR_Tax_Currency, IR_Tax_Currency_UName, IR_InvoiceNum, IR_PUName, IR_ResumbitData, IR_SupplierUName, IR_UN) = [];

			IR_TimeCreated = eachInvoiceR.TimeCreated.toString()

			if (eachInvoiceR.'TaxAmount' != null) {
				IR_Tax_AmountInReportingCurrency = eachInvoiceR.'TaxAmount'.'AmountInReportingCurrency'.toString()
				IR_Tax_ApproxAmountInBaseCurrency = eachInvoiceR.TaxAmount.ApproxAmountInBaseCurrency.toString()
				IR_Tax_Amount = eachInvoiceR.TaxAmount.Amount.toString()
				IR_Tax_ConversionDate = eachInvoiceR.TaxAmount.ConversionDate.toString()
				IR_Tax_Currency_UName = eachInvoiceR.TaxAmount.Currency.UniqueName.toString()
			}
			IR_InvoiceNum = eachInvoiceR.Invoice.UniqueName.toString()
			IR_PUName = eachInvoiceR.ProcurementUnit.UniqueName.toString()
			IR_ResumbitData = eachInvoiceR.ResubmitDate.toString()
			IR_SupplierUName = eachInvoiceR.Supplier.UniqueName.toString()
			IR_UN = eachInvoiceR.UniqueName.toString()

			invoiceReconcilationMap.put(IR_InvoiceNum, IR_UN + '|' + IR_TimeCreated + '|' + IR_SupplierUName + '|' + IR_ResumbitData + '|' + IR_PUName + '|' + IR_Tax_Currency_UName + '|' + IR_Tax_ConversionDate + '|' + IR_Tax_Amount + '|' + IR_Tax_ApproxAmountInBaseCurrency + '|' + IR_Tax_AmountInReportingCurrency)

		}
		sleep(3000)
	}

	message.setProperty("invoiceR_LV",invoiceReconcilationMap.toString())
	messageLog.addAttachmentAsString("#ZIP OUTPUT IR FileName",invoiceReconcilationMap.toString(), "text/json");
	

	return message;
}

