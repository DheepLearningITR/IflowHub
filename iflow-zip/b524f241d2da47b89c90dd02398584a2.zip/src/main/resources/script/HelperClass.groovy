package src.main.resources.script
import groovy.time.TimeCategory
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.regex.Pattern;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.text.DecimalFormat;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat
import java.util.Date;
import java.util.TimeZone;


class HelperClass {

    public String ComputeUT(String InvoiceAmount,String cusTotalTax){

        if (cusTotalTax == null || cusTotalTax.equals("")){
            cusTotalTax="0";
        }

        if (InvoiceAmount == null || InvoiceAmount.equals("")){
            InvoiceAmount="0";
        }

        InvoiceAmount=InvoiceAmount.replace(',','')
        cusTotalTax=cusTotalTax.replace(',','')


        return (((Float.parseFloat(InvoiceAmount)-Float.parseFloat(cusTotalTax)).round(2)).toString().replace('.',','))
    }


    public String dateSubstractInHours(String date1,String date2,String oldformat){

        if (date1 == null || date1.equalsIgnoreCase("null") || date1.equals("") || date2 == null || date2.equals("") || date2.equalsIgnoreCase("null")){
            return "";
        }
        date1 = date1.replace("\"","").replace(",","");
        date2 = date2.replace("\"","").replace(",","");

        SimpleDateFormat sdf = new SimpleDateFormat(oldformat);
        Date d1 = sdf.parse(date1);
        Date d2 = sdf.parse(date2);

        def diffHours;
        def diffDays;

        use(groovy.time.TimeCategory) {
            def duration = d1 - d2
            diffHours="${duration.hours}";
            diffDays="${duration.days}";
        }

        diffHours=(diffDays.toInteger()*24)+diffHours.toInteger()
        return (diffHours);
    }

    public String dateAddandFormat(String oldDate,String oldFormat,String hours){

        String newFormat = "dd/MM/yyyy";
        if (oldDate == null || oldDate.equals("") || oldDate.equalsIgnoreCase("null")){
            return "";
        }
        oldDate = oldDate.replace("\"","").replace(",","");

        SimpleDateFormat sdf = new SimpleDateFormat(oldFormat);
        Date d = sdf.parse(oldDate);

        use( TimeCategory ) {
            d = d + 9.hours
        }
        sdf.applyPattern(newFormat);
        String newDateString = sdf.format(d);
        return newDateString;
    }

    public String dateFormat(String oldDate,String oldFormat){

        String newFormat = "dd/MM/yyyy";
        if (oldDate == null || oldDate.equals("") || oldDate.equalsIgnoreCase("null")){
            return "";
        }

        oldDate = oldDate.replace("\"","").replace(",","");

        SimpleDateFormat sdf = new SimpleDateFormat(oldFormat);
        Date d = sdf.parse(oldDate);
        sdf.applyPattern(newFormat);
        String newDateString = sdf.format(d);
        return newDateString;
    }

    public String dateFormatAriba(String oldDate,String oldFormat){

        String newFormat = "EEE MMM dd HH:mm:ss zzz yyyy";
        if(oldDate == null || oldDate.equalsIgnoreCase("") || oldDate.equalsIgnoreCase("null"))
            return ""

        oldDate = oldDate.replace("\"","").replace(",","");

        SimpleDateFormat sdf = new SimpleDateFormat(oldFormat);
        Date d = sdf.parse(oldDate);
        sdf.applyPattern(newFormat);
        String newDateString = sdf.format(d);
        return newDateString;
    }

    public String amountFormat(String oldAmountFormat){
        if (oldAmountFormat == null || oldAmountFormat.equals('null') || oldAmountFormat.equals("")){
            return "0.0";
        }

        oldAmountFormat = oldAmountFormat.replace("\"","");
        String newAmountFormat = NumberFormat.getNumberInstance().parse(oldAmountFormat);
        newAmountFormat = NumberFormat.getNumberInstance(Locale.GERMAN).format(Double.parseDouble(newAmountFormat));
        newAmountFormat = newAmountFormat.replace(".","");
        return newAmountFormat;
    }

    public String  dateToPST (String oldDate){
        if(oldDate == null || oldDate.equalsIgnoreCase("") || oldDate.equalsIgnoreCase("null"))
            return ""

        //SimpleDateFormat format = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy",Locale.US);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:dd'Z'",Locale.US);        Date newDate = format.parse(oldDate);
        format.setTimeZone(TimeZone.getTimeZone("PST"));
        return format.format(newDate).replace("PDT", "PST");
    }

}
