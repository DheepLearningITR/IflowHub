import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

	def service = ITApiFactory.getApi(SecureStoreService.class, null);

	def apiKey = service.getUserCredential("ANALYTICAL_OPENAPI_APIKEY");
	def oAuthClient = service.getUserCredential("ANALYTICAL_OPENAPI_OAuthClient");
	def oAuthSecret = service.getUserCredential("ANALYTICAL_OPENAPI_OAuthSecret");
	def apiGrantType = service.getUserCredential("ANALYTICAL_OPENAPI_GrantType");


	if (apiKey == null || oAuthClient == null || oAuthSecret == null || apiGrantType == null) {
		throw new IllegalStateException("No credential found for alias 'Login' ");
	}

	String apiKey_Value = new String(apiKey.getPassword());
	String oAuthClient_Value = new String(oAuthClient.getPassword());
	String oAuthSecret_Value = new String(oAuthSecret.getPassword());
	String apiGrantType_Value = new String(apiGrantType.getPassword());
	
	String authorization = 'Basic' + ' ' + (oAuthClient_Value+':'+oAuthSecret_Value).bytes.encodeBase64().toString()
	String grantType = 'grant_type='+apiGrantType_Value
	
	message.setHeader("Content-Type","application/json")
	message.setHeader("Authorization",authorization)
	message.setHeader("CamelHttpQuery",grantType)
	message.setProperty("ApiKeyOAuth",apiKey_Value)
	
	
	
	//def messageLog = messageLogFactory.getMessageLog(message);
	//messageLog.addAttachmentAsString("#Values",authorization+"\n"+apiKey_Value+'|'+oAuthClient_Value+"|"+oAuthSecret_Value+'|'+grantType, "text/json");

	return message;
}