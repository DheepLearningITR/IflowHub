import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.InputStream
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.List;
import java.util.ArrayList;
import java.nio.charset.StandardCharsets;

def Message processData(Message message) {
	
	def messageLog = messageLogFactory.getMessageLog(message);
	
	InputStream is = message.getBody(InputStream.class);
	ByteArrayOutputStream out=new ByteArrayOutputStream();
	int n;
	boolean canRead = false;
	while ((n = is.read()) > -1){
		if (n==80 && !canRead)
		{
			canRead = true;
		}
		if (!canRead){
			continue;
		}
		out.write(n);
	}
	InputStream is2 = new ByteArrayInputStream(out.toByteArray());
	ZipInputStream zipStream = new ZipInputStream(is2);
	ZipEntry entry=zipStream.getNextEntry();
	byte[] buf=new byte[1024];
	while (entry != null) {
		messageLog.addAttachmentAsString("#ZIP OUTPUT IR FileName",entry.getName().toString(), "text/json");
	  if (entry.getName().equals("response/records.txt")) {
		  ByteArrayOutputStream baos=new ByteArrayOutputStream();
		int m;
		while ((m=zipStream.read(buf,0,1024)) > -1) {
		  baos.write(buf,0,m);
		}
		   message.setBody(new String(baos.toByteArray(),StandardCharsets.UTF_8).replace("\"UTF-8\"\n",""));
	  }
	  zipStream.closeEntry();
	  entry=zipStream.getNextEntry();
	}
	
	messageLog.setStringProperty("Logging#2", "Printing Input Payload As Attachment")
	messageLog.addAttachmentAsString("#ZIP OUTPUT IR", message.getBody(String), "text/json");
	

	return message;
	

}

