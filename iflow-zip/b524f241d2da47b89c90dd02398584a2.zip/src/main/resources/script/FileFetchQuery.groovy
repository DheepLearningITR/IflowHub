
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	def contents = message.getBody(String)
	def xmlSlurp = new XmlSlurper().parseText(contents)
	
	//def jobID = xmlSlurp.FetchJob.JobID.toString()
	//def process = xmlSlurp.FetchJob.Process.toString()
	//def fileName = xmlSlurp.FetchJob.FileName.toString()
	
	def process = xmlSlurp.FetchJob[0].Process.toString()
	def runMode = message.getProperty("fetchJobs")
	
	
	//message.setProperty("FileName",fileName)
	//message.setProperty("JobID",jobID)
	message.setProperty("ProcessName",process)
	message.setProperty("runMode",runMode.toLowerCase())
	
	
	return message;
}

