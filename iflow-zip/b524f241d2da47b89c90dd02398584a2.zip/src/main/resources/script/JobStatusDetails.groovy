import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper


def Message processData(Message message) {
	//Body
	def body = message.getBody(java.lang.String) as String;

	def messageLog = messageLogFactory.getMessageLog(message);

	def jsonSlurper = new JsonSlurper()
	def parseJson = jsonSlurper.parseText(body)
	
	def sleepTime_JobFetch = message.getProperty("sleepTime_JobFetch")



	def (statusJobs) = []

	statusJobs = message.getProperty("statusJobs_LV")

	if(statusJobs.isEmpty())
		statusJobs = [:]

	def files = parseJson['files']
	def template = parseJson['viewTemplateName']
	def jobId = parseJson['jobId']
	def jobStatus = parseJson['status']
	def fileNames = ''

	if(files!=null)
	{
		if(!files.isEmpty())
			fileNames = files.join(",").toString()
	}
	
	
        def selectClauseFields = parseJson['selectAttributesSnap']
        def selectClauseFields_P = ''

        selectClauseFields.eachWithIndex { def entry, int i ->
            if (i == 0)
                selectClauseFields_P = selectClauseFields_P + '"' + entry
            else {
                if (i == (selectClauseFields.size() - 1)) {
                    if (selectClauseFields.size() == 2)
                        selectClauseFields_P = selectClauseFields_P + '","' + entry + '"'
                    else
                        selectClauseFields_P = selectClauseFields_P + '","' + entry + '"'
                } else
                    selectClauseFields_P = selectClauseFields_P + '","' + entry
            }

            if(selectClauseFields.size() == 1)
                selectClauseFields_P = selectClauseFields_P + '"'

        }

    message.setProperty("selectClauseFields_P",selectClauseFields_P)
	


	statusJobs.put(jobId,(jobStatus+'|'+fileNames+'|'+template))

	message.setProperty("jobStatusDetails",statusJobs)
	message.setProperty("jobId_FN",jobId)

	messageLog.addAttachmentAsString("#3JobStatusPayload", body, "text/json");


	message.setBody("<Test/>")

	sleep(sleepTime_JobFetch.toInteger())

	return message;
}

