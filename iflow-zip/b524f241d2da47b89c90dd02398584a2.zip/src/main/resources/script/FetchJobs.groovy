
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*

def Message processData(Message message) {

	//Body
	def body = message.getBody();
	def messageLog = messageLogFactory.getMessageLog(message);
	
	def runMode = message.getProperty("fetchJobs")
	
	def (adhocJobs,scheduledJobs,jobsAdhoc,jobsScheduled) = []
	def jobList = []
	
	def logging = message.getProperty("logging")
	
	if(runMode.equalsIgnoreCase("Adhoc"))
	 adhocJobs = message.getProperty("AdhocJob")
	 else
	 scheduledJobs = message.getProperty("ScheduledJob")
	
	if(runMode.equalsIgnoreCase("Adhoc"))
		message.setProperty("runMode","adhoc")
		else
		message.setProperty("runMode","timer")
		
    if(logging.equalsIgnoreCase("Yes"))
	    messageLog.addAttachmentAsString("#1APICallPayload", scheduledJobs.toString() + "\n" + adhocJobs.toString(), "text/xml");
	

	if((adhocJobs.toString().equalsIgnoreCase("null")|| adhocJobs.toString().equalsIgnoreCase("")) && (scheduledJobs.toString().equalsIgnoreCase("null") || scheduledJobs.toString().equalsIgnoreCase("")))
	{
		message.setProperty("ProcessMessage",'false')
		if(logging.equalsIgnoreCase("Yes"))
		    messageLog.addAttachmentAsString("#JobsToBeProcessed",'No Jobs Scheduled Currently', "text/xml");
		message.setBody("<Test/>")
	}
	else
	{
	
 	if(!(adhocJobs.toString().equalsIgnoreCase("null") || adhocJobs.toString().equalsIgnoreCase("")))
 	{
	    jobsAdhoc = adhocJobs.keySet()
	    jobList.addAll(jobsAdhoc)	    
    }
    

    
	if(!(scheduledJobs.toString().equalsIgnoreCase("null") || scheduledJobs.toString().equalsIgnoreCase("")))
	{
	    jobsScheduled = scheduledJobs.keySet()
	    jobList.addAll(jobsScheduled)	    
    }
    
	def xmlWriter = new StringWriter()

	def xmlBuild = new MarkupBuilder(xmlWriter)

	xmlBuild.Jobs {


		jobList.each { String entry ->
			Job{ JobID(entry) }
		}

	}
	message.setProperty("ProcessMessage",'true')
	message.setBody(xmlWriter.toString())
	if(logging.equalsIgnoreCase("Yes"))
	    messageLog.addAttachmentAsString("#JobsRequest",jobList.toString() + "\n" + xmlWriter.toString(), "text/xml");	
	}
	

	return message;

}

