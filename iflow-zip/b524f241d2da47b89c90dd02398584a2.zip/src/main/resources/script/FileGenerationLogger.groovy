import src.main.resources.script.HelperClass;
import groovy.time.TimeCategory
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.regex.Pattern;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.text.DecimalFormat;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat


def Message processData(Message message) {

	def messageLog = messageLogFactory.getMessageLog(message);
	def logging = message.getProperty("logging")
    
    if(logging.equalsIgnoreCase("logging"))
    {
	    messageLog.setStringProperty("Logging#2", "Printing Input Payload As Attachment")
	    messageLog.addAttachmentAsString("#SFTPFILEPOSTING","JOBID =>:" + message.getProperty("JOBID_PURGE") + "\n\n" + message.getBody(String),"text/plain");
    }

	return message;
}

