import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.QName;
import groovy.xml.XmlUtil;

/*
Handling of raised exceptions: Get runtime infos and 
convert them to the IFlow error message format.
*/
def Message processData(Message message) {
    
    def objNewErrorMessageSet = null;
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);

    // Get CPI-Session Properties
    map = message.getProperties();
    
    def exceptionText = map.get('com.sap.commercecloud.fsa.insurance.underwritequotation.ExceptionText');
    def exceptionStack =map.get('com.sap.commercecloud.fsa.insurance.underwritequotation.ExceptionStack');
    
    String appUrl = System.getenv('HC_APPLICATION_URL');
    String TMN_ShortName = appUrl.substring(8,13);
    message.setProperty('P_Tenant_Name',TMN_ShortName);
    
    def errorStep = map.get('SAP_ErrorModelStepID');
    
    cException = map.get('CamelExceptionCaught');
    
    if (cException == null) {
        // There is no Exception
        return message;
    }
    
    if (cException.metaClass.respondsTo(cException, 'getStatusCode')) {
        lStatusCode = cException.getStatusCode()
    } else {
        lStatusCode = ''
    }
    
    // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
    if (cException.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")){
        def businessError = cException.getResponseBody();
        if (businessError != null) {
            def error = new XmlSlurper().parseText(businessError);
            if (error != null && error.code != null && error.message != null) {
                def errorMsg = error.message.text();
                if (errorMsg != ''){
                    exceptionText = errorMsg;
                    exceptionStack = '';
                }
            }
        }
    }
    
    if (body?.trim())  {
        
        //parse the incoming XML into an object
    	def rfcSet = new XmlParser().parseText(body);
    	
    	//get Error Message list
    	objNewErrorMessageSet = rfcSet.breadthFirst().find { node-> node.name() == 'ErrorMessages' }
	
    }
	
	if (objNewErrorMessageSet == null) {
	    
	    //Create new Error message List
        stringNewErrorMessageSet = '<ErrorMessages></ErrorMessages>'
        objNewErrorMessageSet = new XmlParser().parseText(stringNewErrorMessageSet)
	
	    
	} else {
        
        //Add error step in case it is not yet set
        objNewErrorMessageSet.each{ stepMessage ->
        
            if (stepMessage.CpiProcessStep.text() == '') {
                stepMessage.appendNode(new QName('CpiProcessStep'), errorStep) ;
            }
        }
	}
    
            
    def objNewMessage = objNewErrorMessageSet.appendNode(new QName('Message')) 
    
    objNewMessage.appendNode(new QName('CpiProcessStep'), errorStep)  
    objNewMessage.appendNode(new QName('Type'),     'A')  
    objNewMessage.appendNode(new QName('Id'),       '')  
    objNewMessage.appendNode(new QName('Number'),   '')
    objNewMessage.appendNode(new QName('MessageText'),  exceptionText)
    objNewMessage.appendNode(new QName('SystemId'),  'CPI')
    objNewMessage.appendNode(new QName('ErrorStack'),    exceptionStack)
    objNewMessage.appendNode(new QName('StatusCode'), lStatusCode )


    //Set objNewErrorMessageSett as messageBody
    message.setBody(XmlUtil.serialize(objNewErrorMessageSet))
    return message;
    
}