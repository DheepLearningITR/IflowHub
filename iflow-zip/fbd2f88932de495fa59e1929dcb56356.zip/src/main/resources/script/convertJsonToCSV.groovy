import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.Reader;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Body 
    
    // 		def messageLog = messageLogFactory.getMessageLog(message);
    //       messageLog.addAttachmentAsString("QRAWQQ", message.getBody(String), "text/xml");
    
       def body = message.getBody(java.io.Reader);
    //messageLog.addAttachmentAsString("QRAW",body, "text/xml");
        
        // def camelLoopIndex_P = message.getProperty("CamelSplitIndex")
        // if(camelLoopIndex_P% 10 == 0)
        //     sleep(60000);
            
       def root = new JsonSlurper().parse(body);
		String output = "";
		
		def headerQ = '"active","itemId","alternative","externalSystemCorrelationId","processId","documentId","searchTerm","answer","enumerationCodeDelimiters","dataType","multiValued","smVendorId","workspaceType","workspaceId","type","totalQuestions","questionnaireLabel","questionLabel","answerType","rootId","timeUpdated"'
		//	root.access_token
		root._embedded.questionAnswerResourceList.each{
			question->
output = output + '"'+question.questionAnswerApi.active.toString() + '","' + question.questionAnswerApi.itemId.toString()+ '","' + question.questionAnswerApi.alternative.toString()+ '","' + question.questionAnswerApi.externalSystemCorrelationId.toString()		+ '","' + question.questionAnswerApi.processId.toString()		+ '","' + question.questionAnswerApi.documentId.toString()		+ '","' + question.questionAnswerApi.searchTerm.toString()		+ '","' + question.questionAnswerApi.answer.toString().replaceAll('"','')		+ '","' + question.questionAnswerApi.enumerationCodeDelimiters.toString()		+ '","' + question.questionAnswerApi.dataType.toString()		+ '","' + question.questionAnswerApi.multiValued.toString()		+ '","' + question.questionAnswerApi.smVendorId.toString()		+ '","' + question.questionAnswerApi.workspaceType.toString()		+ '","' +question.questionAnswerApi.workspaceId.toString()		+ '","' +question.questionAnswerApi.type.toString()		+ '","' + question.questionAnswerApi.totalQuestions.toString()		+ '","' + question.questionAnswerApi.questionnaireLabel.toString().replaceAll('"','')		+ '","' + question.questionAnswerApi.questionLabel.toString().replaceAll('"','')	+ '","' + question.questionAnswerApi.answerType.toString()		+ '","' + question.questionAnswerApi.rootId.toString()		+ '","' + question.questionAnswerApi.timeUpdated.toString()	+'"'	+"\n";

		}
		
		message.setBody(output);
       return message;
}