import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.Reader;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
 
       def body = message.getBody(java.io.Reader);
       def root = new JsonSlurper().parse(body);
       String token = root.access_token.toString();
       message.setProperty("ARIBATOKEN", token);
       message.setBody('<Test/>');
       return message;
}