/*******************************************************************************************
*** This groovy script is used to parsing the API response and prepare the Questionnaire file
*** and reset SKIP value as page token for fetching next set of Questionnaire details
*******************************************************************************************/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import java.io.Reader;


def Message processData(Message message) {
    
   
    def messageLog = messageLogFactory.getMessageLog(message);
    def pMap = message.getProperties();
    sleep(1000); 
    def generateFile = false
    def body = message.getBody(java.lang.String) as String;
    //messageLog.addAttachmentAsString("JSON_QnA_Payload", body, "text/plain"); 
    if(body != null & body.length()>10)
    {
    String input = body.substring(7)
     
    def root = new JsonSlurper().parseText(input);
    
    StringBuilder output= new StringBuilder();
    def pageToken = ''
    
            if (root != null)
            {
                if (root.pageToken != null)
                {
                    pageToken = root.pageToken
                    message.setProperty("pageToken", pageToken);
                }
                else
                message.setProperty("isPageToken", "false");
                
            }
            else
            {
                pageToken = ''
                message.setProperty("isPageToken", "false");
            }


                root._embedded.questionAnswerList.each {
                    
                    question ->
                        output.append('"').append(question.questionAnswer.active.toString()).append('","').append(question.questionAnswer.itemId.toString()).append('","').append(question.questionAnswer.alternative.toString()).append('","').append(question.questionAnswer.externalSystemCorrelationId.toString()).append('","').append(question.questionAnswer.processId.toString()).append('","').append(question.questionAnswer.questionnaireId.toString()).append('","').append(question.questionAnswer.searchTerm.toString()).append('","').append(question.questionAnswer.answer.toString().replaceAll('"', '')).append('","').append(question.questionAnswer.enumerationCodeDelimiters.toString()).append('","').append(question.questionAnswer.dataType.toString()).append('","').append(question.questionAnswer.multiValued.toString()).append('","').append(question.questionAnswer.smVendorId.toString()).append('","').append(question.questionAnswer.workspaceType.toString()).append('","').append(question.questionAnswer.workspaceId.toString()).append('","').append(question.questionAnswer.type.toString()).append('","').append(question.questionAnswer.totalQuestions.toString()).append('","').append(question.questionAnswer.questionnaireLabel.toString().replaceAll('"', '')).append('","').append(question.questionAnswer.questionLabel.toString().replaceAll('"', '')).append('","').append(question.questionAnswer.answerType.toString()).append('","').append(question.questionAnswer.rootId.toString()).append('","').append(question.questionAnswer.timeUpdated.toString()).append('"').append("\n");

                        generateFile = true
                        
                    }

       // messageLog.addAttachmentAsString("output", output.toString(), "text/plain");         
            //String strResponse = pMap.get("QnAResponse");
            //strResponse = strResponse + output.toString();
        //message.setProperty("QnAResponse",output.toString());

        message.setBody(output.toString());
        message.setProperty("postQFile", generateFile.toString())
    
        return message;
    }
    else
    {
        generateFile = true;
        message.setBody("");
        message.setProperty("postQFile", generateFile.toString())
        message.setProperty("isPageToken", "false");
        return message;
        
    }
    
        
    
}