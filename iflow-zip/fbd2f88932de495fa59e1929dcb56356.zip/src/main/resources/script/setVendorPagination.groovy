/*********************************************************************************
*** This groovy script is used to set SKIP value 
*** and this value is used as page token for fetching Vendor details
*********************************************************************************/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {


        def paginationToken = message.getProperty("P_venderPageToken");
        if(!paginationToken.equals("0")){
           message.setProperty("skipVendor", paginationToken);
           //message.setHeader("x-pagination-token", paginationToken);
        }
        else
            {
               message.setProperty("skipVendor", "0" ); 
            }
      
       return message;
}