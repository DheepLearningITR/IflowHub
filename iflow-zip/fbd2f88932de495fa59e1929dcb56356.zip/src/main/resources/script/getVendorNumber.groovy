/*********************************************************************************
*** This groovy script is used to parsing the API response and prepare the Vendor file
*** and reset SKIP value as page token for fetching next set of Vendor details
*********************************************************************************/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.Reader;
import groovy.json.JsonSlurper;
import groovy.xml.StreamingMarkupBuilder;

def Message processData(Message message) {
    //Body 

    def body = message.getBody(java.io.Reader);
    def root = new JsonSlurper().parse(body);
    def strSkip = message.getProperty("skipVendor");

    def xmlBuilder = new StreamingMarkupBuilder();
    xmlBuilder.encoding = "UTF-8";
    def nextToken = 0;
    String finalOutput = "";
    String fileCreateFlag = "false";
    String qnaInvalidStatus = message.getProperty("qnaInvalidStatus")
    def qnaInvalidStatus_List = qnaInvalidStatus.split(",")
    def qnaQualified_List = []
    
// Added the extra 15 fields at the end  fields on 5th March 2020
    String headerVendor = '"Supplier Name","SM Vendor ID","ERP Vendor ID","An Id","ACM ID","Registration Status","Qualification Status","Integrated to ERP","Address - Line1","Address - Line2","Address - Line3","Address - City","Address - Country Code","Address - Region Code","Address - PO Box","Address - Postal Code","Qualification Status","Preferred Status","Category","Region","Business Unit","Source System","Master Vendor Id","Duns Id","Record Created Date","Creator","Blocked Status","Last Review Date","Last Update Date","Last Status Change Date","Primary Supplier Manager","Alternate Supplier Manager","Primary contact first name","Primary contact middle name","Primary contact last name","Primary contact email"'



    String output = xmlBuilder.bind {
        Records {
            root.each { record ->
                if (record.nextToken == null) {
                    //Added the code to remove the filter record.qualifications != null to get all vendors whose Registration Status other than Notinvited edited on10th Dec 2019 
                    
                    def regStatus = record."Registration Status"
                            
                        
                            //Ensuring - Vendor# is Passed Once as Well as Only the Vendor with Required Registration Statuses are fetched
                            if (!qnaInvalidStatus_List.contains(regStatus)) {
                                if (!qnaQualified_List.contains(record."SM Vendor ID")) {
                                    SupplierRecord {
                                        VendorId(record."SM Vendor ID");
                                    }

                                    qnaQualified_List.add(record."SM Vendor ID")
                                
                                }
                                
                          }
                          // Added the extra 15 fields at the end  fields on 5th March 2020
                    if (record.qualifications != null) {
                        record.qualifications.each { qualification ->
                            finalOutput = finalOutput + '"' + record."Supplier Name" + '","' + record."SM Vendor ID" + '","' + record."ERP Vendor ID" + '","' + record."An Id" + '","' + record."ACM ID" + '","' + record."Registration Status" + '","' + record."Qualification Status" + '","' + record."Integrated to ERP" + '","' + record."Address - Line1" + '","' + record."Address - Line2" + '","' + record."Address - Line3" + '","' + record."Address - City" + '","' + record."Address - Country Code" + '","' + record."Address - Region Code" + '","' + record."Address - PO Box" + '","' + record."Address - Postal Code" + '","' + qualification."Qualification Status" + '","' + record."Preferred Status" + '","' + qualification."Category" + '","' + qualification."Region" + '","' + qualification."Business Unit" + '","' +record."Source System"+ '","' +record."Master Vendor Id" + '","'+ record."Duns Id" + '","'+ record."Record Created Date" + '","'+ qualification."Creator" + '","'+ record."Blocked Status"+ '","' + record."Last Review Date" + '","'+ record."Last Update Date" + '","'+ record."Last Status Change Date" + '","'+ record."Primary Supplier Manager" + '","'+ record."Alternate Supplier Manager" + '","'+ record."Primary contact first name" + '","'+ record."Primary contact middle name" + '","'+ record."Primary contact last name" +'","'+record."Primary contact email" +'"\n';
                          
                           /* Commented the code to remove the filter record.qualifications != null changes edited on 10th Dec 2019
                           def regStatus = record."Registration Status"
                            
                            // Ensuring - Vendor# is Passed Once as Well as Only the Vendor with Required Registration Statuses are fetched
                            if (!qnaInvalidStatus_List.contains(regStatus)) {
                                if (!qnaQualified_List.contains(record."SM Vendor ID")) {
                                    SupplierRecord {
                                        VendorId(record."SM Vendor ID");
                                    }

                                    qnaQualified_List.add(record."SM Vendor ID")
                                }
                            }*/

                        }
                    } else {
                        String _null = "";
                        
                        // Added the extra 15 fields at the end  fields on 5th March 2020
                        
finalOutput = finalOutput + '"' + record."Supplier Name" + '","' + record."SM Vendor ID" + '","' + record."ERP Vendor ID" + '","' + record."An Id" + '","' + record."ACM ID" + '","' + record."Registration Status" + '","' + record."Qualification Status" + '","' + record."Integrated to ERP" + '","' + record."Address - Line1" + '","' + record."Address - Line2" + '","' + record."Address - Line3" + '","' + record."Address - City" + '","' + record."Address - Country Code" + '","' + record."Address - Region Code" + '","' + record."Address - PO Box" + '","' + record."Address - Postal Code" + '","' + _null + '","' + _null + '","' + _null + '","' + _null + '","' + _null + '","' +record."Source System"+ '","' +record."Master Vendor Id" + '","'+ record."Duns Id" + '","'+ record."Record Created Date" + '","'+ _null+ '","'+ record."Blocked Status"+ '","' + record."Last Review Date" + '","'+ record."Last Update Date" + '","'+ record."Last Status Change Date" + '","'+ record."Primary Supplier Manager" + '","'+ record."Alternate Supplier Manager" + '","'+ record."Primary contact first name" + '","'+ record."Primary contact middle name" + '","'+ record."Primary contact last name" +'","'+record."Primary contact email" + '"\n';
                    }
                } else {
                    nextToken = record.nextToken;
                }

            } // End of record loop
        } // End of Record Node
    }
    if (nextToken != 0) {
        message.setProperty("P_venderPageToken", nextToken);
        message.setProperty("P_VendorNextToken", "true");
    } else {
        message.setProperty("P_VendorNextToken", "false");
    }
    message.setProperty("outputPayload", output);
    if (!finalOutput.isEmpty()) {
        fileCreateFlag = true;
    }

    //fileCreateFlag = "false" //TEMP

    message.setProperty("P_FileCreate", fileCreateFlag)

    def messageLog = messageLogFactory.getMessageLog(message);

    messageLog.setStringProperty("Logging#1", "VendorFile");
    if (message.getProperty("P_ENABLE_LOGGING").equalsIgnoreCase("TRUE")) {
        messageLog.addAttachmentAsString("VendorFile_"+strSkip, headerVendor.toString() + "\n" + finalOutput.toString(), "text/xml");
        messageLog.addAttachmentAsString("QnA(VALID)_"+strSkip, output.toString(), "text/xml");
    }
    message.setBody(headerVendor.toString() + "\n" + finalOutput.toString());

    return message;
}