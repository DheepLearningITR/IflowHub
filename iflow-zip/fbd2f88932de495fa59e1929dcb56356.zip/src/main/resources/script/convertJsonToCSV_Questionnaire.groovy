/*********************************************************************************
*** This groovy script is used to prepare the complete URL and related headers
*** for fetching Questionnaire details for a Vendor
*********************************************************************************/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovyx.net.http.RESTClient
import static groovyx.net.http.ContentType.URLENC


def Message processData(Message message) {


    def messageLog = messageLogFactory.getMessageLog(message);

    try {

        def messageLog_T = messageLogFactory.getMessageLog(message);
        def bearerToken = oAuthTokenGeneration(message.getProperty("P_Authorization").toString(), message.getProperty("oauthTokenURL").toString())
        def apikeyOpenAPI = message.getProperty("P_ApiKeyOAuth");
        def authorizationOpenAPI = 'Bearer ' + bearerToken
        def generateFile = false
        String fetchURI = message.getProperty("supplierPaginationURL")
        fetchURI = fetchURI.replaceAll('vendorId', message.getProperty("vendorId").toString())
        
        message.setHeader("apikey", apikeyOpenAPI);
        message.setHeader("Authorization", authorizationOpenAPI);
        message.setHeader("Content-Type", "application/json");
        
        message.setProperty("fetchURI",fetchURI);
        message.setProperty("pageToken", "0");
        message.setProperty("isPageToken", "true");
     
        return message;
    }
    
    catch (Exception ex) {

        def messageLog_C = messageLogFactory.getMessageLog(message);
        messageLog_C.addAttachmentAsString("Exception-Block", "Exception-String=>" + ex.toString() + "\nException-Message=>" + ex.getMessage() + "\nStackTrace=>" + ex.getStackTrace(), 'text/plain');
        throw new Exception("Please check Message Log Attachment for more details!")
    }
    
         
        
    
}

def static oAuthTokenGeneration(String authentication, String oAuthURL) {

    String postURI = oAuthURL //'https://api-eu.ariba.com/v2/oauth/token'
    RESTClient oAuth = new RESTClient(postURI)

    def response = oAuth.post(
            headers: ["Authorization": authentication,
                      "Accept"       : "application/json"],
            body: [grant_type: 'openapi_2lo'],
            requestContentType: URLENC)

    def root = response.getData()
    //def root = new JsonSlurper().parse(root)
    String token = root.access_token.toString()
    return token
}