import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    if(message.getProperty("P_ENABLE_LOGGING").equalsIgnoreCase("TRUE")){
       def body = message.getBody(java.lang.String);
       
       def messagelog = messageLogFactory.getMessageLog(message);
       messagelog.addAttachmentAsString("CSV File", body, 'text/xml');
    }
       return message;
}

def Message processVendorNumber(Message message) {
     if(message.getProperty("P_ENABLE_LOGGING").equalsIgnoreCase("TRUE")){

       def body = message.getBody(java.lang.String);
      
       def messagelog = messageLogFactory.getMessageLog(message);
       messagelog.addAttachmentAsString("Questionnaire1234", body, 'text/xml');
     }
       return message;
}