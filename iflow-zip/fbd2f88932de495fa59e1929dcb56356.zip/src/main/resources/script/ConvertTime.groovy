import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.time.*
def Message processData(Message message) {
    
       
     def currentDateTime = message.getProperty("currentDateTime");
     def time=Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS", currentDateTime)

    // get epoch milis
      def epoch_milis = time.getTime()
       message.setProperty("currentDateTime", epoch_milis);
       
       return message;
}