/*********************************************************
*** This groovy script is used to remove the vendor ids 
*** whose value is null or empty venor IDs.
**********************************************************/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import java.util.regex.*;
import java.io.*;

def Message processData(Message message) {
	
	def body = message.getBody(java.io.Reader);
	def messageLog = messageLogFactory.getMessageLog(message);
	
   	def root = new XmlParser().parse(body);

    root.SupplierRecord.findAll { it.VendorId.text() == "null"}.each{
       it.replaceNode {}
    } 
    root.SupplierRecord.findAll { it.VendorId.text() == ""}.each{
       it.replaceNode {}
    } 
 
 
	message.setBody(XmlUtil.serialize(root));
   // messageLog.addAttachmentAsString("Before Mapping xml Output:",message.getBody().toString(), "text/plain");   
   	return message;
}

