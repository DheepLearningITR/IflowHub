/*********************************************************************************
*** This groovy script is used to read the API key & OAuth details 
*** and form the vendor Query based on the last run date & time and full load
*********************************************************************************/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;
def Message processData(Message message) {

       def pMap = message.getProperties();
       String fullLoadIndicator = pMap.get("P_FullLoad");
       String lastRunDateTime = pMap.get("P_LastRunDateTime");
       String currentDateTime = pMap.get("currentDateTime");
       String _apikey = pMap.get("SUPPLIER_OPENAPI_APIKEY");
       String _oAuthClient = pMap.get("SUPPLIER_OPENAPI_OAuthClient");
       String _oAuthSecret = pMap.get("SUPPLIER_OPENAPI_OAuthSecret");
       String _grantType = pMap.get("SUPPLIER_OPENAPI_GrantType");
       
       if(fullLoadIndicator.equalsIgnoreCase("TRUE")) {
           message.setProperty("P_VendorQuery","");
       }
       else if(lastRunDateTime.equals("") ){
           message.setProperty("P_VendorQuery","");
       }
       else{
           String query = "&\$filter=updatedDateFrom ge $lastRunDateTime'Z' and updatedDateTo le $currentDateTime'Z'";
           message.setProperty("P_VendorQuery",query);
       }
 
       // Get the Secure Parameters
       def service = ITApiFactory.getApi(SecureStoreService.class, null);

	def apiKey = service.getUserCredential(_apikey);
	def oAuthClient = service.getUserCredential(_oAuthClient);
	def oAuthSecret = service.getUserCredential(_oAuthSecret);
	def apiGrantType = service.getUserCredential(_grantType);
	
	if (apiKey == null || oAuthClient == null || oAuthSecret == null || apiGrantType == null) {
		throw new IllegalStateException("No credential found for alias 'Login' ");
	}

	String apiKey_Value = new String(apiKey.getPassword());
	String oAuthClient_Value = new String(oAuthClient.getPassword());
	String oAuthSecret_Value = new String(oAuthSecret.getPassword());
	String apiGrantType_Value = new String(apiGrantType.getPassword());
	
	String authorization = 'Basic' + ' ' + (oAuthClient_Value+':'+oAuthSecret_Value).bytes.encodeBase64().toString()
	String grantType = 'grant_type='+apiGrantType_Value
	
	message.setProperty("P_Authorization",authorization)
	message.setProperty("P_GrantType",grantType)
	message.setProperty("P_ApiKeyOAuth",apiKey_Value)
      
       return message;
}