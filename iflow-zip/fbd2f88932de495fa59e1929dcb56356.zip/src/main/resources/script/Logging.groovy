import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    if(message.getProperty("P_ENABLE_LOGGING").equalsIgnoreCase("TRUE")){
       def body = message.getBody(java.lang.String);
       
       def messagelog = messageLogFactory.getMessageLog(message);
       messagelog.addAttachmentAsString("CSV File", body, 'text/xml');
    }
       return message;
}

def Message processVendorNumber(Message message) {
     if(message.getProperty("P_ENABLE_LOGGING").equalsIgnoreCase("TRUE")){

       def body = message.getBody(java.lang.String);
       // Added the code to remove the tags "<Records></Records>" present in empty Questionaire files on 10th Dec 2019 
       def strSkip = message.getProperty("skipVendor")
       def tempBody = body;
       def areRecordsEmpty = body.contains("<Records></Records>");
       if(areRecordsEmpty) {
         tempBody = body.substring(0,(body.indexOf("<")-1));
       }
       def messagelog = messageLogFactory.getMessageLog(message);
       messagelog.addAttachmentAsString("Questionnaire_"+strSkip, tempBody, 'text/xml');
      message.setBody(tempBody);
     }
     
     
       return message;
}