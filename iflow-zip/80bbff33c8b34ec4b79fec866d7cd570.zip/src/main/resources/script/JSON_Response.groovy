import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    // Get the JSON payload from the message body
    def body = message.getBody(String);
    
    // Parse the JSON payload
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    
    // Extract the 'status' value
    def statusValue = jsonObject.status;
    def statusMessage = jsonObject.message;
   
    // Set the 'status' value as a message property or header if needed
    message.setProperty("statusValue", statusValue);
    message.setProperty("statusMessage", statusMessage);
    
    return message;
}
