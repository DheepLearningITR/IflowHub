import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def Message processData(Message message) {
    // Parse the XML content from the message body
    def body = new XmlParser().parseText(message.getBody(String))

    // Extract the <cXML> element
    def cxmlElement = body.Payload.cXML

    // Serialize the extracted <cXML> element and remove the XML declaration
    def targetPayload = ""
    if (cxmlElement) {
        targetPayload = XmlUtil.serialize(cxmlElement[0]).replaceFirst("<\\?xml version=\"1.0\".*\\?>", "")
    }

    // Extract the <AttachmentList> element and serialize it if present
    def attachDetails = ""
    if (body.'AttachmentList') {
        attachDetails = XmlUtil.serialize(body.'AttachmentList'[0]).replaceFirst("<\\?xml version=\"1.0\".*\\?>", "")
    }

    // Set the target payload and attachment details to message properties
    message.setProperty("targetPayload", targetPayload)
    message.setProperty("attachDetails", attachDetails)

    return message
}
