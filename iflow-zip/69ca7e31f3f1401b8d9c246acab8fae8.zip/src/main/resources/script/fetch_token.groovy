import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

def Message processData(Message message) {
	def  body =message.getBody(java.lang.String.class);
	JsonParser parser = new JsonParser();
	JsonObject token = (JsonObject)parser.parse(body);

	def access_token = token.get("access_token");
	if (access_token!=null) {
		message.setProperty("ACCESS_TOKEN", access_token.getAsString());
	} else {
		message.setProperty("ACCESS_TOKEN", "EMPTY");
	}
	message.setBody(message.getProperty("requestBody"));
	return message;
}
