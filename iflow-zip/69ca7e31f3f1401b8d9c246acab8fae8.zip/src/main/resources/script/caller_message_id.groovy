import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Map;
import java.lang.String;

import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;

def Message processData(Message message) {
	def callerId = message.getHeaders().get("DME_CallerMessageID");
	def msgId = message.getHeaders().get("SAP_MessageProcessingLogID");
	message.setHeader("SAP_Sender", callerId );
	message.setHeader("DME_CallerMessageID", msgId );

	def service = ITApiFactory.getApi(SecureStoreService.class, null);
	
	def credential = service.getUserCredential("CF_AUTH");
	
	if (credential == null){
		throw new IllegalStateException("No credential found for alias 'CF_AUTH'");
	}

	Map<String, String> credentialProp = credential.getCredentialProperties();

	String clientID = credential.getUsername();
    String clientSecret = new String(credential.getPassword());
	
	message.setBody("client_id=" + encode(clientID) + "&client_secret=" + encode(clientSecret) + "&grant_type=client_credentials");
	return message;
}

def String encode(String input){
	return java.net.URLEncoder.encode(input, "UTF-8");
}
