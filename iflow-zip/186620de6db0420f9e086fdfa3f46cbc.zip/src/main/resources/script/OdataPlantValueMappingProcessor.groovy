import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.pd.PartnerDirectoryService
import groovy.transform.Field
import groovy.util.slurpersupport.GPathResult
import groovy.xml.XmlUtil

import java.util.regex.Matcher
import java.util.regex.Pattern
import java.util.stream.Collectors
import java.util.stream.Stream

@Field static final String PROPERTY_ENDPOINT_ID = "ENDPOINT_ID";
@Field static final String HEADER_VM_MODE = "VM_MODE";
@Field static final String VM_MODE_REQUEST = "REQUEST";
@Field static final String VM_MODE_RESPONSE = "RESPONSE";
@Field static final String PD_PARAMETER_ENABLE_PLANT_CONVERSION = "ENABLE_PLANT_CONVERSION";
@Field static final String PARTNER_ID_PREFIX = "DME_Generic_Processing_";
@Field static final String VM_AGENCY_ERP = "ERP";                                //Agency of ERP
@Field static final String VM_IDENTIFIER_ERP_WERKS = "WERKS";                    //Identifier of ERP
@Field static final String VM_AGENCY_DMC = "DMC";                                //Agency of DMC
@Field static final String VM_IDENTIFIER_DMC_PLANTS = "PLANT";                    //Identifier of DMC
@Field static final Map FIELDS_CONFIGURATION = [Batch                      : ["BatchIdentifyingPlant", "Plant"],
                                                BatchCharcValue            : ["BatchIdentifyingPlant", "Plant"],
                                                ProdnOrdConf2              : ["Plant", "ProductionPlant"],
                                                ProcOrdConf2               : ["Plant"],
                                                RepetitiveMfgConfirmation  : ["ProductionPlant", "PlanningPlant"],
                                                maintainInventoryRequest   : ["site"],
                                                componentAddRequest        : ["site"],
                                                A_MaterialDocumentHeader   : ["plant", "IssuingOrReceivingPlant", "MOVE_PLANT"],
                                                A_InspectionLot            : ["Plant", "InspLotSelectionPlant", "InspectionLotPlant"],
                                                A_InspectionOperation      : ["InspectionOperationPlant", "InspectionMethodPlant", "InspectionSpecificationPlant", "SelectedCodeSetPlant"],
                                                A_InspectionCharacteristic : ["InspectionMethodPlant", "InspectionSpecificationPlant", "SelectedCodeSetPlant"],
                                                A_CharcAttribSeldSetCode   : ["SelectedCodeSetPlant"],
                                                A_CharcAttribSeldSetCodeT  : ["SelectedCodeSetPlant"],
                                                ERP_CONSOLID_INV_READ_OP_V2: ["Plant"],
                                                ERP_CONSOLID_INV_READ_OP_V3: ["Plant"],
                                                orderCompleteRequest       : ["plant"],
                                                yieldConfirmationRequest   : ["plant"],
                                                inDirectLaborRecord: ["plant"],
                                                prodTimeConfirmationRequest: ["plant"],
                                                prodTimeDirLabCancellationRequest: ["plant"],
                                                directLaborRecord: ["plant"],
                                                serviceOrderConfirmationRequest: ["plant"],
                                                srvOrderComponentAddRequest: ["site"],
                                                srvOrderComponentRemovalRequest: ["plant"],
                                                directLaborRecordRequest: ["plant"],
                                                indirectLaborCancellationRequest: ["plant"],
                                                directLaborSrvOrderCancellationRequest: ["plant"],
                                                erpGoodsReceiptRequest: ["plant"],
                                                erpBulkComponent: ["plant"]
];
@Field static final String ERP_DESTINATION = "erpdestination";
@Field static final String CONTENT_TYPE_APPLICATION_JSON = "application/json";
@Field static final String CONTENT_TYPE_MULTIPART_MIX = "multipart/mixed;boundary=batch_sep";
@Field static final String CONTENT_TYPE_XML = "application/xml";
@Field static final String CAMEL_HTTP_PATH = "CamelHttpPath";
@Field static final String CAMEL_HTTP_QUERY = "CamelHttpQuery";
@Field static final String ENTRY_COMPONENT = "EntryComponent";

@Field static final String PLANT_REGEX_STR = "(?! )[0-9A-Z_\$!)(+~@^=\\-*. ]+(?<! )";


Message processData(Message message) {

    String endpointId = message.getProperty(PROPERTY_ENDPOINT_ID);
    String partnerId = PARTNER_ID_PREFIX + endpointId;
    String contentType = message.getHeaders().get("Content-Type");

    PartnerDirectoryService pd = ITApiFactory.getService(PartnerDirectoryService.class, null);
    if (pd == null) {
        throw new IllegalStateException("Partner Directory Service not found");
    }
    boolean enablePlantConversion = toBoolean(pd.getParameter(PD_PARAMETER_ENABLE_PLANT_CONVERSION, partnerId, String.class));

    if (enablePlantConversion) {

        String vmSourceAgency;
        String vmSourceIdentifier;
        String vmTargetAgency;
        String vmTargetIdentifier;
        String prefix;
        String mode = message.getHeaders().get(HEADER_VM_MODE);
        if (mode.equals(VM_MODE_REQUEST)) {
            //OData service request: source system is DMC; target system is ERP
            vmSourceAgency = VM_AGENCY_DMC;
            vmSourceIdentifier = VM_IDENTIFIER_DMC_PLANTS;
            vmTargetAgency = VM_AGENCY_ERP;
            vmTargetIdentifier = VM_IDENTIFIER_ERP_WERKS;
        } else {
            //OData service response: Source system is ERP; target system is DMC
            vmSourceAgency = VM_AGENCY_ERP;
            vmSourceIdentifier = VM_IDENTIFIER_ERP_WERKS;
            vmTargetAgency = VM_AGENCY_DMC;
            vmTargetIdentifier = VM_IDENTIFIER_DMC_PLANTS;
            prefix = message.getHeaders().get(ERP_DESTINATION);
        }

        String requestPath = message.getHeaders().get(CAMEL_HTTP_PATH);
        String query = message.getHeaders().get(CAMEL_HTTP_QUERY);
        //mapping path if request
        if (mode.equals(VM_MODE_REQUEST)) {
            if (requestPath) {
                mappingPath(message, vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier);
            }
            if (query) {
                mappingQuery(message, vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier);
            }
        }
        if (CONTENT_TYPE_APPLICATION_JSON.equalsIgnoreCase(contentType)) {
            //In 2402 release, there is application/json added in header to support S4 odata in CPI
            executePlantConversionJson(message, vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier);
        } else if (contentType && contentType.startsWith(CONTENT_TYPE_MULTIPART_MIX)) {
            // $batch type, format payload with regex
            executePlantConversionBatchPlainText(message, vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier, mode);
        } else {
            executePlantConversionXml(message, vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier);
        }
    }
    return message;
}

private void mappingPath(Message message, String vmSourceAgency, String vmSourceIdentifier, String prefix, String vmTargetAgency, String vmTargetIdentifier) {
    String path = message.getHeaders().get(CAMEL_HTTP_PATH);
    String entity = message.getHeaders().get(ENTRY_COMPONENT);
    String[] fields = FIELDS_CONFIGURATION[entity];
    //type: Batch(Material='SHA4_FG_BATCH_PI',BatchIdentifyingPlant='SH42PC',Batch='0000000475',Plant='SH42PC')
    fields.each { String field ->
        path = executeRegexMapping("([,(]" + field + "=')(" + PLANT_REGEX_STR + ")(')", path, 2, "\$1%s\$3"
                , vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier);
    }
    message.setHeader(CAMEL_HTTP_PATH, path);
}

private void mappingQuery(Message message, String vmSourceAgency, String vmSourceIdentifier, String prefix, String vmTargetAgency, String vmTargetIdentifier) {
    String entity = message.getHeaders().get(ENTRY_COMPONENT);
    String query = message.getHeaders().get(CAMEL_HTTP_QUERY);
    String[] fields = FIELDS_CONFIGURATION[entity];
    //type: Plant=SH42PC&name=xxxx&$filter=Plant eq 'SH42PC' And(and) Plant eq 'SH42PC'
    if (query.trim().length() > 1) {
        query = URLDecoder.decode(query, "UTF-8");
        fields.each { String field ->
            query = executeRegexMapping("(^" + field + "=|&" + field + "=)(" + PLANT_REGEX_STR + ")", query, 2, "\$1%s"
                    , vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier);
            query = executeRegexMapping("((=|[Aa][Nn][Dd]|[Oo][Rr])+[\\s]*" + field + "[\\s]*[Ee][Qq][\\s]*')(" + PLANT_REGEX_STR + ")(')", query, 3, "\$1%s\$4"
                    , vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier);
        }
    }
    message.setHeader(CAMEL_HTTP_QUERY, query);
}


private void executePlantConversionJson(Message message, String vmSourceAgency, String vmSourceIdentifier, String prefix, String vmTargetAgency, String vmTargetIdentifier) {
    String body = message.getBody(String.class);
    String entity = message.getHeaders().get(ENTRY_COMPONENT);

    String[] fields = FIELDS_CONFIGURATION[entity];
    //mapping body
    fields.each { String field ->
        body = executeRegexMapping("(\"" + field + "\"[\\s]*:[\\s]*\")(" + PLANT_REGEX_STR + ")(\")", body, 2, "\$1%s\$3",
                vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier);
    }
    message.setBody(body);
}


private String executeRegexMapping(String regex, String payload, int matcherGroup, String replacementString, String vmSourceAgency, String vmSourceIdentifier, String prefix, String vmTargetAgency, String vmTargetIdentifier) {
    Pattern pattern = Pattern.compile(regex);
    Matcher matcher = pattern.matcher(payload);
    if (matcher.find()) {
        String sourceValue = matcher.group(matcherGroup);
        String targetValue = getValueMapping(vmSourceAgency, vmSourceIdentifier, prefix, sourceValue, vmTargetAgency, vmTargetIdentifier);
        if (targetValue) {
            payload = payload.replaceAll(regex, String.format(replacementString, targetValue));
        }
    }
    return payload;
}

private void executePlantConversionBatchPlainText(Message message, String vmSourceAgency, String vmSourceIdentifier, String prefix, String vmTargetAgency, String vmTargetIdentifier, String mode) {

    String payload = message.getBody(String.class);
    String entity = message.getHeaders().get(ENTRY_COMPONENT);

    String[] fields = FIELDS_CONFIGURATION[entity];
    fields.each { String field ->
        payload = executeRegexMapping("([,(]" + field + "=')(" + PLANT_REGEX_STR + ")(')", payload, 2, "\$1%s\$3"
                , vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier)
        payload = executeRegexMapping("(^" + field + "=|&" + field + "=)(" + PLANT_REGEX_STR + ")", payload, 2, "\$1%s"
                , vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier);
        payload = executeRegexMapping("((?:=|%3D|\\\\u003d|[Aa][Nn][Dd]|[Oo][Rr])+(?:%20|\\s)*" + field + "(?:%20|\\s)*[Ee][Qq](?:%20|\\s)*(?:%27|'))(" + PLANT_REGEX_STR + ")(%27|')", payload, 2, "\$1%s\$3"
                , vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier);
        payload = executeRegexMapping("(\"" + field + "\"[\\s]*:[\\s]*\")(" + PLANT_REGEX_STR + ")(\")", payload, 2, "\$1%s\$3",
                vmSourceAgency, vmSourceIdentifier, prefix, vmTargetAgency, vmTargetIdentifier);
    }
    //if response in batch response, it is required to change the Content-length header of the payload after value mapping since this value is mandatory to parse the response;
    if (mode.equals(VM_MODE_RESPONSE)) {
        payload = afterRefiningContentLength(payload);
    }
    message.setBody(payload);
}

private String mappingPattern(String payload, String entityPrefix, String braceSymbol, String plantPattern, String vmSourceAgency, String vmSourceIdentifier, String prefix, String vmTargetAgency, String vmTargetIdentifier) {
    String patternStr = entityPrefix + braceSymbol + plantPattern + braceSymbol;
    Pattern pattern = Pattern.compile(patternStr)
    Matcher matcher = pattern.matcher(payload);
    if (matcher.find()) {
        String plantMatched = matcher.group(0);
        String plant = plantMatched.replaceAll(entityPrefix, "").replaceAll(braceSymbol, "").trim();
        String targetValue = getValueMapping(vmSourceAgency, vmSourceIdentifier, prefix, plant, vmTargetAgency, vmTargetIdentifier);
        if (targetValue) {
            String newPlantEntity = entityPrefix + braceSymbol + targetValue + braceSymbol;
            payload = payload.replaceAll(pattern, newPlantEntity);
        }
    }
    return payload;
}


private void executePlantConversionXml(Message message, String vmSourceAgency, String vmSourceIdentifier, String prefix, String vmTargetAgency, String vmTargetIdentifier) {

    Reader payload = message.getBody(java.io.Reader);
    GPathResult root = new XmlSlurper().parse(payload);
    String entity = root.name();
    String[] fields = FIELDS_CONFIGURATION[entity];

    fields.each { String tag ->
        List<GPathResult> searchResult = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase(tag) && it.children().size() == 0; }
        if (!searchResult.isEmpty()) {
            searchResult.each { GPathResult it ->
                String plantSourceValue = it.text();
                plantTargetValue = getValueMapping(vmSourceAgency, vmSourceIdentifier, prefix, plantSourceValue, vmTargetAgency, vmTargetIdentifier);
                if (plantTargetValue) {
                    it.replaceBody(plantTargetValue);
                }
            }
        }
    }
    message.setBody(XmlUtil.serialize(root));
}


String getValueMapping(String vmSourceAgency, String vmSourceIdentifier, String prefix, String plantSourceValue, String vmTargetAgency, String vmTargetIdentifier) {
    ValueMappingApi vm = ITApiFactory.getService(ValueMappingApi.class, null);

    String plantTargetValue = vm.getMappedValue(vmSourceAgency, vmSourceIdentifier, prefix + ":" + plantSourceValue, vmTargetAgency, vmTargetIdentifier);

    if (!plantTargetValue) {
        plantTargetValue = vm.getMappedValue(vmSourceAgency, vmSourceIdentifier, plantSourceValue, vmTargetAgency, vmTargetIdentifier);
    }

    if (plantTargetValue) {
        try {
            plantTargetValue = plantTargetValue.split(":")[1];
        } catch (java.lang.ArrayIndexOutOfBoundsException ex) {
            //log.error("Can't split the plant value ", plantTargetValue);
        }
    }
    return plantTargetValue;
}

private boolean toBoolean(String value) {

    if (value != null) {
        if ("TRUE".equalsIgnoreCase(value)) {
            return true;
        }
    }
    return false;
}


private String afterRefiningContentLength(String payload) {
    String boundaryDelimiter = getBoundaryDelimiter(payload);
    String regex = "--" + boundaryDelimiter;
    Pattern pattern = Pattern.compile(regex);
    String regexContent = "(Content-Length:\\s*)([(0-9)]*)"

    Matcher matcher = pattern.matcher(payload);
    if (matcher.find()) {
        return Stream.of(payload.split(regex)).map { str ->
            if (str.contains("Content-Length")) {
                String newLine = "\r\n";
                String[] resParts = str.split(newLine);
                if (resParts.size() > 1) {
                    String responseContent = resParts[resParts.size() - 1]
                    int contentLength = responseContent.size();
                    return str.replaceAll(regexContent, "\$1" + contentLength);
                }
            } else {
                return str;
            }
        }.collect(Collectors.joining(regex));
    } else {
        return payload;
    }
}

private String getBoundaryDelimiter(String responseString) {
    Pattern BOUNDARY_DELIMITER_PATTERN = Pattern.compile("[\\w\\W]*--([-A-Za-z0-9_]*)--[\\s]*");
    Matcher headerMatcher = BOUNDARY_DELIMITER_PATTERN.matcher(responseString);
    if (headerMatcher.matches()) {
        return headerMatcher.group(1);
    } else {
        throw new Exception("no boundaryDelimiterPattern found");
    }
}
