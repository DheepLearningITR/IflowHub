
import com.sap.gateway.ip.core.customdev.util.Message;



import groovy.json.JsonSlurper


def String getFilter(products){

    def filter = ""
    if (products instanceof List){

        products?.each {
            it ->
                if (filter) filter = filter + ',"' + it +'"'
                else filter = '"' + it + '"'
        }
    } else {
        filter = '"' + products + '"'
    }

    return filter

}

def Message buildFilter(Message message) {


    def body = message.getBody(String.class)

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)

    def filter = getFilter(json?.Product)

    message.setProperty("filter", filter)

    return message
}