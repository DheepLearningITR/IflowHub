
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    message.setBody(JsonOutput.toJson(jsonObject["data"]));
    message.setProperty("RequestPayload", JsonOutput.toJson(jsonObject["data"]));
    
    def AccountCompany = message.getProperty("AccountCompany");
    def deletionQuery
    
    if (AccountCompany){
        deletionQuery = AccountCompany + '&forceDelete=true'
    }else{
        deletionQuery = 'forceDelete=true'
    }
    
    message.setProperty("deletionQuery",deletionQuery)

    return message;
}
