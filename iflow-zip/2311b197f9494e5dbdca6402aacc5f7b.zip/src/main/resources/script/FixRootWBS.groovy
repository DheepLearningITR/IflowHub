/*

    This script fixes the assocation between the first WBS element and the project, where the UUID is not pointing to the correct element

*/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;


def Message processData(Message message) {
    
    // get projectUuid from properties
    def projectUuid = message.getProperty("ProjectUuid");
    
    // parse XML body
    def body = message.getBody(java.lang.String);
    def xml = new XmlSlurper().parseText(body);
    

    // collect all unique IDs in a Set    
    Set uniqueIds = [];
    def nodes = xml.'**'.findAll { it.name() == 'uniqueId' };
    nodes.each{ uniqueIds << it.text() };
    
    // find all parentObjectUniqueIds and check whether they contain something valid
    nodes = xml.'**'.findAll { it.name() == 'parentObjectUniqueId' };
    nodes.each{
        // if an invalid unique ID is found, replace it with the projectUuid
        if (!(it.text() in uniqueIds)) {
            it.replaceBody(projectUuid);
        }
    };

    // update message body    
	message.setBody(XmlUtil.serialize(xml)); 

    return message;
    
}