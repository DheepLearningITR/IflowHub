/*
 * Copyright (C) 2020 SAP SE
 * All Rights Reserved
 */
import com.sap.it.api.mapping.*;

/*
 * Generates from a url template "ApplicationBaseUrl" the backend project navigation url.
 * - "ApplicationBaseUrl" is defined as externalized parameter in the iflow content package.
 *   and will be read from the mapping context. The base url property name is defined by 
 *   the function parameter "baseUrlPropertyName"
 * - parameter "%projectUUID% will be replaced with the real project UUID
 * 
 * Prerequisite: The parameter "ApplicationBaseUrl" has to be written to the message. 
 * This can be done through a "Content Modifier" transformation in the iFlow.
 * More infos: https://blogs.sap.com/2018/08/01/sap-cpi-externalizing-a-parameter-in-content-modifier-from-web-gui/
 *
*/


/*def String getNavigationURL(String baseUrlPropertyName, String projectUniqueID, MappingContext context) {
     return context.getProperty( baseUrlPropertyName ).replace("%projectUUID%", projectUniqueID);
}
*/

def String getNavigationURL( String baseUrlPropertyNameEnterpriseProjects, String baseUrlPropertyNameCustomerProjects, String baseUrlPropertyNameInternalProjects, String projectUniqueID, String projectProfileCode, String project, MappingContext context ) {
     if( projectProfileCode == "P001" ){
        return context.getProperty( baseUrlPropertyNameCustomerProjects ).replace("%project%", project);
     }
     else if ( projectProfileCode == "P002" ){
        return context.getProperty( baseUrlPropertyNameInternalProjects ).replace("%project%", project);
     }
     else if ( projectProfileCode.startsWith("YP0")){
        return context.getProperty( baseUrlPropertyNameEnterpriseProjects ).replace("%projectUUID%", projectUniqueID);
     }
     else {
         return "https://sap.com";
     }
     
}