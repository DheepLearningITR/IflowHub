
import com.sap.gateway.ip.core.customdev.util.Message;
import org.apache.commons.csv.CSVFormat
import org.apache.commons.csv.CSVParser
 
def Message processData(Message message) {
     
    def properties = message.getProperties()
    def fileContentMap = properties.get("fileContentMap")
    def userContent = fileContentMap.get('BasicUser.csv')
    
    def empIdList = ''
    
    CSVParser parser = CSVParser.parse(userContent, CSVFormat.DEFAULT)
		
	parser.each{
		empIdList += it.get(1) + '\n'
	}
	
	empIdList = empIdList.substring(0, empIdList.length() - 1)
    
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString('empIdList', empIdList, "text/plain");
    
    message.setBody(empIdList)
    return message
}