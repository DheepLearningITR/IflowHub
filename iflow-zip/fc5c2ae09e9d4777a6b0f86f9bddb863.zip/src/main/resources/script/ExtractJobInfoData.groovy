import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	
	def xml = message.getBody(String)
	def properties = message.getProperties()
	
	def EmpJob = new XmlSlurper().parseText(xml)
	
	def positions = EmpJob.EmpJob.position.collect{"'$it'"}.join(',')
	message.setProperty('positions', positions)
	
	def eventReasons = EmpJob.EmpJob.eventReason.collect{"'$it'"}.join(',')
	message.setProperty('eventReasons', eventReasons)
	
	def messageLog = messageLogFactory.getMessageLog(message)
	messageLog.addAttachmentAsString("positions", positions, "text/plain")
	messageLog.addAttachmentAsString("eventReasons", eventReasons, "text/plain")
	
	return message
}