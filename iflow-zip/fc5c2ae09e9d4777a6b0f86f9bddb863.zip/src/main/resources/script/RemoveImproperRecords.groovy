import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil

def Message processData(Message message) {
		
		def xml = message.getBody(String)
		def properties = message.getProperties()
		def entityName = properties.get('entityName')
		def entityColumns = properties.get('entityColumnsMap').get(entityName)
		def effectiveDatedEntities = properties.get('effectiveDatedEntities')
		def empIdList = properties.get('empIdList')
		def summaryReport = properties.get('summaryMap').get('summaryReport')
		
		def combinedEntity = new XmlParser().parseText(xml)
		
		def upsertData = combinedEntity.'multimap:Message1'."$entityName"
		def existData = combinedEntity.'multimap:Message2'."$entityName"
		def seqMap = new HashMap()
		
		upsertData."${entityName}".findAll{ upsertRecord ->
			//remove record with DELETE operation
			if(upsertRecord.operation.text() == 'DELETE'){
				def keyColumn = getPersonIdColumn(entityName)
				def personId = upsertRecord."${keyColumn}".text()
				summaryReport << "Entity: ${entityName} Upsert skipped for EmpId: ${personId} because operation is DELETE\n"
				return true
			}
	        if(entityName == 'EmpJob'){
	            def existRecsForSeq = existData."$entityName".findAll{
				    def keyColumn = getPersonIdColumn(entityName)
			        def startDateColumn = entityName == 'PaymentInformationV3' ? 'effectiveStartDate' : 'startDate'
				    def existStartDate = it."${startDateColumn}".text().split('T')[0]
				    it."${keyColumn}".text() == upsertRecord."${keyColumn}".text() && existStartDate == upsertRecord."${startDateColumn}".text()
	            }
	            existRecsForSeq.each{ existRecForSeq ->
	                def existStartDate = existRecForSeq.startDate.text().split('T')[0]
	                def seqNum = seqMap.get(existRecForSeq.userId.text()+existStartDate)
	                if(seqNum == null){
	                    seqNum = existRecForSeq.seqNumber.text() as int
	                    seqMap.put(existRecForSeq.userId.text()+existStartDate, seqNum)
	                }
					else if(existRecForSeq.seqNumber.text() > seqNum){
	                    seqMap.put(existRecForSeq.userId.text()+existStartDate, existRecForSeq.seqNumber.text())
	                }
	            }
	            def seqNum = seqMap.get(upsertRecord.userId.text()+upsertRecord.startDate.text())
				seqNum = seqNum == null ? 1 : seqNum + 1
	            seqMap.put(upsertRecord.userId.text()+upsertRecord.startDate.text(), seqNum)
	            new Node(upsertRecord, 'seqNumber', seqNum)
	        }
			def existRecords = existData."$entityName".findAll{
				def keyColumn = getPersonIdColumn(entityName)
				it."${keyColumn}".text() == upsertRecord."${keyColumn}".text()
			}
			if(existRecords == null || existRecords.isEmpty()){
				if(entityName in ['EmpCompensation', 'EmpPayCompRecurring']){
					new Node(upsertRecord, 'seqNumber', 1)
				}
				return false
			}
			existRecords.any{ existRecord ->
				//For effective dated entity, remove record with existRecord startDate > upsertRecord startDate
				if(entityName in effectiveDatedEntities){
					def startDateColumn = entityName == 'PaymentInformationV3' ? 'effectiveStartDate' : 'startDate'
					def existStartDate = existRecord."${startDateColumn}".text().split('T')[0]
					if(existStartDate > upsertRecord."${startDateColumn}".text() && entityName != 'PerGlobalInfoUSA'){
						def keyColumn = getPersonIdColumn(entityName)
						def personId = existRecord."${keyColumn}".text()
						summaryReport << "Entity: ${entityName} Upsert skipped for EmpId: ${personId} because an existing record startDate: ${existStartDate} is greater than the record's startDate.\n"
						return true
					}
					//set seqNumber
					if(entityName in ['EmpCompensation', 'EmpPayCompRecurring']){
						def seqNum = 1
						if(existStartDate == upsertRecord."${startDateColumn}".text() && (entityName in ['EmpCompensation'] || (entityName == 'EmpPayCompRecurring' && existRecord.payComponent.text() == upsertRecord.payComponent.text())) ){
							seqNum = (existRecord.seqNumber.text() as int) + 1
						}
						new Node(upsertRecord, 'seqNumber', seqNum)
					}
				}
				//remove same record
				def isSame = entityColumns.split(',').every{ column ->
					if(entityName == 'User' && column in ['manager', 'matrixManager', 'secondManager', 'customManager', 'hr', 'proxy']){
						return upsertRecord.link."${column}".User.userId.text() == existRecord."${column}".User.userId.text()
					}
					//skip blank value
					if(upsertRecord."${column}".text() == ''){
						return true
					}
					if(entityName == 'PerPerson' && column == 'userId'){ //PerPerson.userId is not viewable
						return true
					}
					//skip startDate for effective dated record
					if(column == 'startDate' && entityName in effectiveDatedEntities){
						return true
					}
					if(column == 'endDate' && upsertRecord."${column}".text() in ['9999-12-31','']){
						return true
					}
					if(column == 'operation'){
						return true
					}
					if(entityName in ['EmpJob', 'EmpCompensation', 'EmpPayCompRecurring'] && column == 'seqNumber'){
					    return true
					}
					if(existRecord."${column}".text() ==~ /\d{4}-(0[1-9]|1[0-2])-([0-3][0-9])T00:00:00\.000/){
						return upsertRecord."${column}".text() == existRecord."${column}".text().split('T')[0]
					}
					if(entityName == 'EmpPayCompRecurring' && column == 'payComponent'){
						if(upsertRecord."${column}".text() == '' || existRecord."${column}".text() == ''){
							return upsertRecord."${column}".text() == existRecord."${column}".text()
						}
						return upsertRecord."${column}".text() as int == existRecord."${column}".text() as int
					}
					upsertRecord."${column}".text() == existRecord."${column}".text()
				}
				if(isSame){
					def keyColumn = getPersonIdColumn(entityName)
					def personId = existRecord."${keyColumn}".text()
					summaryReport << "Entity: ${entityName} Upsert skipped for EmpId: ${personId} because the existing data is same.\n"
					return true
				}
				else{
					return false
				}
			}
			
		}.each{
			upsertData[0].remove(it)
			def keyColumn = getPersonIdColumn(entityName)
			def personId = it."${keyColumn}".text()
			empIdList.remove(personId)
		}
		
		if(upsertData[0] == null || upsertData[0].children().isEmpty()){
			properties.put('hasRecords', 'N')
			message.setBody('')
		}
		else{
			properties.put('hasRecords', 'Y')
			message.setBody(XmlUtil.serialize(upsertData[0]))
		}
		
		return message
	}
	
	def String getPersonIdColumn(String entityName){
		def keyColumn = 'personIdExternal'
		if(entityName in ['User', 'EmpJob', 'EmpPayCompNonRecurring', 'EmpJobRelationships', 'EmpCompensation', 'EmpPayCompRecurring']){
			keyColumn = 'userId'
		}
		return keyColumn
	}