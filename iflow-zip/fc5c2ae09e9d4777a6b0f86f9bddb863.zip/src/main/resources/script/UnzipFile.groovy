import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream

import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {

	def properties = message.getProperties()
	def fileContentMap = properties.get("fileContentMap")

	def body = message.getBody(InputStream.class);
	def zipStream = new ZipInputStream(body);
	
	StringBuffer fileNames = new StringBuffer();
	
	try{
		for(ZipEntry entry; entry = zipStream.getNextEntry();){
			String fname = entry.getName();
			fileNames.append(fname+"\n");
			
			ByteArrayOutputStream out
			try{
				out = new ByteArrayOutputStream()
				byte[] buf=new byte[1024];
				int n;
				while ((n=zipStream.read(buf,0,1024)) != -1) {
					out.write(buf,0,n);
				}
				fileContentMap.put(fname, out.toString())
			}
			finally{
				zipStream.closeEntry()
			}
		}
	}
	finally{
		zipStream.close()
	}
	
	def enableLogging = 'true'.equalsIgnoreCase(properties.get('Enable_Logging'))
	if(enableLogging){
		def messageLog = messageLogFactory.getMessageLog(message)
		messageLog.addAttachmentAsString("fileNames", fileNames.toString(), "text/plain")
	}
	
	message.setBody(fileNames.toString())
	return message;
}