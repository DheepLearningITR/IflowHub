import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    def body = message.getBody()
    def encodedBody = body.getBytes().encodeBase64().toString()
    message.setBody(encodedBody)
    
    return message
}