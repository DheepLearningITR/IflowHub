import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def responseXml = message.getBody(java.lang.String) as String
    def UpsertResponses = new XmlSlurper().parseText(responseXml)
    
    def properties = message.getProperties()
    def entityName = properties.get('entityName')
    def empIdList = properties.get('empIdList')
    def entityFailedEmpMap = properties.get('entityFailedEmpMap')
    def summaryMap = properties.get('summaryMap')
	def summaryReport = summaryMap.get('summaryReport')
    
    def failedEmpList = new ArrayList()
    
    UpsertResponses.children().eachWithIndex{ response, index ->
        if(response.status.text() == 'ERROR'){
            failedEmpList.add(empIdList.get(index))
            summaryReport << "Entity: ${entityName} Upsert Failed for empId: ${empIdList.get(index)}. Error msg: ${response.message.text()}\n"
        }
        else if(response.status.text() == 'OK'){
            summaryReport << "Entity: ${entityName} Upsert Success for empId: ${empIdList.get(index)}.\n"
        }
    }
    if(!failedEmpList.isEmpty()){
        entityFailedEmpMap.put(entityName, failedEmpList)
    }
    
    return message
}