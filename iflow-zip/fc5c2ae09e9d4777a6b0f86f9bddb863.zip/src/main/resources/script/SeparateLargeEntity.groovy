import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	def xml = message.getBody(String)
	Node entity = new XmlParser().parseText(xml)
	
	def messageLog = messageLogFactory.getMessageLog(message)
//	messageLog.addAttachmentAsString("BeforeResult", groovy.xml.XmlUtil.serialize(entity), "text/plain")
	
	int limitSize = 500
	
	def entityName = entity.name()
	if(entity."$entityName".size() <= limitSize){
		return message
	}
	
	Node dummyRoot = new Node(null, 'root')
	def root
	entity."$entityName".eachWithIndex{ node, index  ->
		if(index % limitSize == 0){
			root = new Node(dummyRoot, entity.name())
			new Node(dummyRoot, '_separator_')
		}
		root.children().add(node)
	}
		
	String result = groovy.xml.XmlUtil.serialize(dummyRoot)
	
//	messageLog.addAttachmentAsString("SplitResult", result.toString(), "text/plain")
	
	def resultList = result.readLines()
	resultList.remove(0)
	resultList.remove(resultList.size()-1)
	StringBuilder sb = new StringBuilder()
	resultList.each{
		if(it.contains('_separator_')){
			sb << '\n'
		}
		else{
			sb << it
		}
	}
	
	messageLog.addAttachmentAsString("SplitResult", sb.toString(), "text/plain")
	
	message.setBody(sb.toString())
    return message
}