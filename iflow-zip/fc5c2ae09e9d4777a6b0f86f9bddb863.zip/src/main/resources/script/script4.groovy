
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
   def body = message.getBody(java.lang.String) as String
   
   def User = new XmlSlurper().parseText(body)
   String userId = User.User.userId
   
   def properties = message.getProperties()
   def empId = properties.get('empId')
   def empStatusMap = properties.get('empStatusMap')
   
   if(userId != null || userId != ''){
       empStatusMap.put(empId, 'CHG')
   }
   else{
       empStatusMap.put(empId, 'NEW')
   }
   
   return message
}