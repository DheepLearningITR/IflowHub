
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();
    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addAttachmentAsString("body", body, "text/plain")
    
       return message;
}