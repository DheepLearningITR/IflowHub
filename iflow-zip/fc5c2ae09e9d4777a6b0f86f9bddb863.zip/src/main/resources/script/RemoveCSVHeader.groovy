package cpi.shutterfly.workday

import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
	
	def properties = message.getProperties()
	
	def fileName = message.getBody(String)
	def csvContent = properties.get('fileContentMap').get(fileName)
	def contentNoHeader = csvContent.replace(csvContent.substring(0, csvContent.indexOf('\n')+1), '')
	
// 	def messageLog = messageLogFactory.getMessageLog(message)
// 	messageLog.addAttachmentAsString("contentNoHeader", contentNoHeader, "text/plain")
	
	message.setBody(contentNoHeader)
	
	return message
}