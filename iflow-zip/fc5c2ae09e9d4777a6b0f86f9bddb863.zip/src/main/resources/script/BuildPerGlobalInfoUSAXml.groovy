import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.xml.XmlUtil

def Message processData(Message message) {
    
    def xmlReader = message.getBody(Reader)
	def PerGlobalInfoUSA = new XmlSlurper().parse(xmlReader)
	
	PerGlobalInfoUSA.PerGlobalInfoUSA.each{ globalInfo ->
		if(globalInfo.PerPersonal != ''){
			globalInfo.startDate.replaceNode{
				'startDate'("${globalInfo.PerPersonal.startDate.text()}")
			}
			globalInfo.PerPersonal.replaceNode{}
		}
	}
	
	message.setBody(XmlUtil.serialize(PerGlobalInfoUSA))
    return message
}
