import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    def properties = message.getProperties()
    // def empStatusMap = properties.get('empStatusMap')
    
    def fileEntityOrderMap = properties.get('fileEntityOrderMap')
    message.setBody(fileEntityOrderMap.keySet().join('\n'))
    
    return message
}