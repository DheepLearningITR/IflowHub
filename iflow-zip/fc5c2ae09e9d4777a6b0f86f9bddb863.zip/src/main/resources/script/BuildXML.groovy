import com.sap.gateway.ip.core.customdev.util.Message;
import org.apache.commons.csv.CSVFormat
import org.apache.commons.csv.CSVParser
import groovy.xml.MarkupBuilder

def Message processData(Message message) {

//        def fileName = message.getBody(String)

        def properties = message.getProperties()
		def fileName = properties.get('fileName')
        def entityName = properties.get('fileEntityOrderMap').get(fileName)
        message.setProperty('entityName', entityName)

//        def csvContent = properties.get('fileContentMap').get(fileName)
		def csvContent = message.getBody(String)
		
        def entityColumns = properties.get('entityColumnsMap').get(entityName)
		def effectiveDatedEntities = properties.get('effectiveDatedEntities')
		def columnPicklistMap = properties.get('columnPicklistMap')
		def picklistMap = properties.get('picklistMap')
		def today = properties.get('today')
        
        def summaryReport = properties.get('summaryMap').get('summaryReport')
        
        def enableLogging = 'true'.equalsIgnoreCase(properties.get('Enable_Logging'))
        
        def messageLog = messageLogFactory.getMessageLog(message)
        if(enableLogging){
//            messageLog.addAttachmentAsString("entityName", entityName, "text/plain")
//            messageLog.addAttachmentAsString("csvContent", csvContent, "text/plain")
        }

        def writer = new StringWriter()
        def builder = new MarkupBuilder(writer)

//        CSVParser parser = CSVParser.parse(csvContent, CSVFormat.DEFAULT.withHeader().withSkipHeaderRecord())
		CSVParser parser = CSVParser.parse(csvContent, CSVFormat.DEFAULT)

        def empIdList = new ArrayList()
        builder."${entityName}"{
            parser.eachWithIndex{ line, index  ->
                def personIdIndex = entityColumns.split(',').findIndexOf{
					if(entityName in ['User', 'EmpJob', 'EmpPayCompNonRecurring', 'EmpJobRelationships']){
						return it == 'userId'
					}
                    it == 'personIdExternal'
                }
                def personId = line.get(personIdIndex)
				if(personId == ''){
					summaryReport << "Entity: ${entityName} Upsert skipped for row number: ${index+1} because personId is blank.\n"
					return
				}
				if(entityName != 'User'){
					def failedEntity = findFailedEntity(personId, entityName, properties)
					if(failedEntity != null){
						summaryReport << "Entity: ${entityName} Upsert skipped for EmpId: ${personId} because ${failedEntity} upsert failed.\n"
						return
					}
				}
                
                def i = 0
				boolean isCanAddr = false
                "${entityName}"{
                    entityColumns.split(',').each{ column ->
                        if(entityName == 'User' && column in ['manager', 'matrixManager', 'secondManager', 'customManager', 'hr', 'proxy']){
							if(column in ['matrixManager', 'secondManager', 'customManager', 'hr', 'proxy']){
								return
							}
							if(line.get(i) != ''){  //skip blank value
								'link'{
									"${column}"{
										'User'{
											'userId' (line.get(i))
										}
									}
								}
							}
                        }
                        else{
							//set startDate as today if not specified
							if(column == 'startDate' && line.get(i) == '' && entityName in effectiveDatedEntities){
								"${column}" today
							}
							else{
								def columnValue = line.get(i)
								//get picklist optionId
								if(columnPicklistMap.keySet().contains("$entityName.$column" as String) && columnValue != ''){
									def picklistId = columnPicklistMap."$entityName.$column"
									if(isCanAddr){
										picklistId = columnPicklistMap."PerAddressDEFLT.state_can"
									}
									columnValue = picklistMap."$picklistId"?."$columnValue"
									//picklist value may be null due to an non-existent picklist externalCode input
									if(columnValue == null || columnValue == ''){
										summaryReport << "Entity: ${entityName} picklist value is null for input value: ${line.get(i)}, picklistId: ${picklistId}.\n"
									}
								}
								if(entityName == 'PerAddressDEFLT' && column == 'country' && columnValue == 'CAN'){
									isCanAddr = true
								}
								if(entityName in ['EmpJob', 'EmpCompensation', 'EmpEmploymentTermination'] && column == 'eventReason'){
									def eventReasonMap = properties.get('eventReasonMap')
									columnValue = eventReasonMap.get(columnValue)
								}
								//skip blank value
								if(columnValue != ''){
									"${column}" (columnValue)
								}
							}
                        }
                        //set empId
                        if(isEmpIdColumn(entityName, column)){
                            empIdList.add(line.get(i))
                        }
						i++
                    }
                }
            }
        }
        
        message.setProperty('empIdList', empIdList)
		
		def filterClause = getFilterClause(empIdList, entityName)
		message.setProperty('filterClause', filterClause)
		if(enableLogging){
//		    messageLog.addAttachmentAsString("filterClause", filterClause, "text/plain")
		}
        
        def selectColumns = getSelectColumns(entityName, entityColumns)
        message.setProperty('selectColumns', selectColumns)
        if(enableLogging){
//            messageLog.addAttachmentAsString("selectColumns", selectColumns, "text/plain")
        }
        def expandColumns = getExpandColumns(entityName)
        message.setProperty('expandColumns', expandColumns)
		if(enableLogging){
//			messageLog.addAttachmentAsString("expandColumns", expandColumns, "text/plain")
		}
        
        message.setBody(writer.toString())
        return message
    }

    def Boolean isEmpIdColumn(entityName, column){
        if(entityName in ['User', 'EmpJob', 'EmpPayCompNonRecurring', 'EmpJobRelationships', 'EmpCompensation', 'EmpPayCompRecurring']){
            if(column == 'userId'){
                return true
            }
        }
        else{
            if(column == 'personIdExternal'){
                return true
            }
        }
        return false
    }
    
    def String findFailedEntity(personId, entityName, properties){
        Map entityFailedEmpMap = properties.get('entityFailedEmpMap')
        def allSkipEntityList = properties.get('allSkipEntityList')
        def groupSkipEntityList = properties.get('groupSkipEntityList')
        def paymentSkipEntityList = properties.get('paymentSkipEntityList')
        
        def failedEntity = null
        failedEntity = getFailedSkipEntity(allSkipEntityList, entityFailedEmpMap, personId)
        
        if(failedEntity == null){
            if(groupSkipEntityList.contains(entityName)){
                failedEntity = getFailedSkipEntity(groupSkipEntityList, entityFailedEmpMap, personId)
            }
            else if(paymentSkipEntityList.contains(entityName)){
                failedEntity = getFailedSkipEntity(paymentSkipEntityList, entityFailedEmpMap, personId)
            }
        }
        
        return failedEntity
    }
    
    def String getFailedSkipEntity(entityList, entityFailedEmpMap, personId){
        return entityList.find{ entity ->
            def empList = entityFailedEmpMap.get(entity)
            empList != null && empList.contains(personId)
        }
    }
    
     def String getFilterClause(empIdList, entityName){
		 if(empIdList.isEmpty()){
			 return ''
		 }
		 def filterEmpId = empIdList.collect{"'${it}'"}.join(',')
		 def filterColumn = entityName in ['User', 'EmpJob', 'EmpPayCompNonRecurring', 'EmpJobRelationships', 'EmpCompensation', 'EmpPayCompRecurring'] ? 'userId' : 'personIdExternal'
		 return "${filterColumn} in ${filterEmpId}"
     }
    
    def String getSelectColumns(entityName, entityColumns){
        // some columns are not viewable
        def selectColumns = entityColumns.split(',').findAll{
            ( entityName != 'EmpJob' && !(entityName == 'PerPerson' && it == 'userId') &&
			it != 'operation' &&
			!(entityName == 'EmpEmployment' && it == 'jobNumber') &&
			!(entityName == 'EmpCompensation' && it == 'personIdExternal') &&
			!(entityName == 'EmpPayCompRecurring' && it == 'personIdExternal') &&
			!(entityName == 'PerEmergencyContacts' && it in ['addressAddress1', 'addressAddress2', 'addressAddress3', 'addressCity', 'addressCountry', 'addressCounty', 'addressNotes', 'addressProvince', 'addressState', 'addressZipCode'])
			&& !(entityName == 'EmpEmploymentTermination' && it in ['eventReason', 'newMainEmploymentId']) ) ||
			(entityName == 'EmpJob' && it in ['userId', 'startDate', 'position', 'eventReason', 'seqNumber', 'shiftCode', 'customString2'])
        }.collect{
            if(entityName == 'User' && it in ['manager', 'matrixManager', 'secondManager', 'customManager', 'hr', 'proxy']){
                "${it}/userId"
            }
            else{
                it
            }
        }.join(',')
		if(entityName in ['EmpCompensation']){
			selectColumns += ',seqNumber'
		}
        return selectColumns
    }
    
    def String getExpandColumns(entityName){
        def expandColumns = ''
        if(entityName == 'User'){
            expandColumns = 'manager,matrixManager,secondManager,customManager,hr,proxy'
        }
        return expandColumns
    }