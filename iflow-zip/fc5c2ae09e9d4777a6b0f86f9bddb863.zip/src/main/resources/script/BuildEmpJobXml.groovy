import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.xml.XmlUtil

def Message processData(Message message) {
    
    def xmlReader = message.getBody(Reader)
	def EmpJob = new XmlSlurper().parse(xmlReader)
	
	def properties = message.getProperties()
	def columnPicklistMap = properties.get('columnPicklistMap')
	def picklistMap = properties.get('picklistMap')
	def summaryReport = properties.get('summaryMap').get('summaryReport')
	
	EmpJob.EmpJob.each{ empJob ->
		empJob.FOEventReason.replaceNode{}
		empJob.Position.cust_FullTime.replaceNode{
			if(it.text() == ''){
				return ''
			}
			'isFulltimeEmployee'("${it.text()}")
		}
		empJob.Position.cust_employmentType.replaceNode{
			def employmentTypeValue = getPicklistOptionId('employmentType', it.text(), columnPicklistMap, picklistMap, summaryReport)
			employmentTypeValue == '' ? '' : 'employmentType'("$employmentTypeValue")
		}
		empJob.Position.cust_payscaleArea.replaceNode{
			if(it.text() == ''){
				return ''
			}
			'payScaleArea' it.text()
		}
		empJob.Position.cust_payscaleType.replaceNode{
			if(it.text() == ''){
				return ''
			}
			'payScaleType' it.text()
		}
		empJob.Position.employeeClass.replaceNode{
			def employmentClassValue = getPicklistOptionId('employeeClass', it.text(), columnPicklistMap, picklistMap, summaryReport)
			employmentClassValue == '' ? '' : 'employeeClass'("$employmentClassValue")
		}
		empJob.Position.cust_RemoteEmployee.replaceNode{
			def remoteEmployeeValue = getPicklistOptionId('customString3', it.text(), columnPicklistMap, picklistMap, summaryReport)
			remoteEmployeeValue == '' ? '' : 'customString3'("$remoteEmployeeValue")
		}
		empJob.Position.cust_incentivePlan.replaceNode{
			def incentivePlanValue = getPicklistOptionId('customString9', it.text(), columnPicklistMap, picklistMap, summaryReport)
			incentivePlanValue == '' ? '' : 'customString9'("$incentivePlanValue")
		}
		empJob.Position.cust_TargetBonusPercentage.replaceNode{
			if(it.text() == ''){
				return ''
			}
			'customString7' it.text()
		}
		empJob.Position.parentPosition.replaceNode{
			def manager = it.Position.EmpJob.userId.text()
			if(manager == ''){
				manager = 'NO_MANAGER'
			}
			'managerId'("$manager")
		}
		
		empJob.Position.code.replaceNode{}
		empJob.appendNode(empJob.Position.children())
		empJob.Position.replaceNode{}
		empJob.appendNode{'workingDaysPerWeek' 5}
	}
	
	message.setBody(XmlUtil.serialize(EmpJob))
    return message
}

def String getPicklistOptionId(column, columnValue, columnPicklistMap, picklistMap, summaryReport){
	if(columnPicklistMap.keySet().contains("EmpJob.$column" as String) && columnValue != ''){
		def picklistId = columnPicklistMap."EmpJob.$column"
// 		if(picklistId == 'employmentType~%251'){
// 			picklistId = 'employmentType~%1'
// 		}
		columnValue = picklistMap."$picklistId"?."$columnValue"
		if(columnValue == null || columnValue == ''){
			summaryReport << "Entity: EmpJob picklist value is null for column: $column, picklistId: ${picklistId}.\n"
		}
		return columnValue ?: ''
	}
	return ''
}
