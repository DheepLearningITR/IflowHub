import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	
	def xml = message.getBody(String)
	def properties = message.getProperties()
	
	def EmpJob = new XmlSlurper().parseText(xml)
	
	def parentPositions = EmpJob.EmpJob.Position.parentPosition.Position.code.collect{"'$it'"}.join(',')
	message.setProperty('parentPositions', parentPositions)
	
	def messageLog = messageLogFactory.getMessageLog(message)
	messageLog.addAttachmentAsString("parentPositions", parentPositions, "text/plain")
	
	return message
}