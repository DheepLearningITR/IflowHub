import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.SimpleDateFormat
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.msglog.MessageLog

import groovy.transform.Field

@Field static final String VM_AGENCY_SF = "SF_EC_for_Workday"
@Field static final String VM_IDENTIFIER_ENTITY = "EC_OData_Entity"
@Field static final String VM_IDENTIFIER_FIELDS = "EC_OData_Entity_Fields"

@Field static final String PICKLIST_MAPPING = 'Picklist_Mapping'
@Field static final String EVENTREASON_MAPPING = 'EventReason_Mapping'

def Message processData(Message message) {
    
    def fileContentMap = new HashMap()
    message.setProperty("fileContentMap", fileContentMap)
    
    def fileEntityOrderMap = initFileEntityOrder()
    message.setProperty("fileEntityOrderMap", fileEntityOrderMap)
    
    def entityColumnsMap = initEntityColumns(fileEntityOrderMap.values())
    message.setProperty("entityColumnsMap", entityColumnsMap)
    
	def effectiveDatedEntities = ['PerAddressDEFLT', 'EmpJob', 'EmpJobRelationships', 'EmpCompensation', 'EmpPayCompRecurring', 'PerPersonal', 'PerGlobalInfoUSA', 'PaymentInformationV3']
	message.setProperty("effectiveDatedEntities", effectiveDatedEntities)
	
	// entity.column -> picklistId mapping
	def columnPicklistMap = initPicklistMapping(message.getProperty(PICKLIST_MAPPING))
	message.setProperty("columnPicklistMap", columnPicklistMap)
	
	def picklistIds = columnPicklistMap.values().collect{"'$it'"}.join(',')
	message.setProperty("picklistIds", picklistIds)
	
	def eventReasonMap = initEventReasonMapping(message.getProperty(EVENTREASON_MAPPING))
	message.setProperty("eventReasonMap", eventReasonMap)
	
    def entityFailedEmpMap = new HashMap()  //key=entityName, value=empId...
    message.setProperty("entityFailedEmpMap", entityFailedEmpMap)
    
    def allSkipEntityList = ['User']
    def groupSkipEntityList = ['PerPerson', 'EmpEmployment', 'EmpJob', 'EmpCompensation', 'EmpPayCompRecurring']
    def paymentSkipEntityList = ['PaymentInformationV3', 'PaymentInformationDetailV3', 'PaymentInformationDetailV3USA']
    message.setProperty("allSkipEntityList", allSkipEntityList)
    message.setProperty("groupSkipEntityList", groupSkipEntityList)
    message.setProperty("paymentSkipEntityList", paymentSkipEntityList)
    
    def summaryMap = new HashMap()
    summaryMap.put('summaryReport', new StringBuffer())
    message.setProperty('summaryMap', summaryMap)
    
	def dateFormat = new SimpleDateFormat('yyyy-MM-dd')
	dateFormat.setTimeZone(TimeZone.getTimeZone("GMT-05:00"))
    message.setProperty('today', dateFormat.format(Calendar.getInstance().getTime()))
    
    return message
}

def initEntityColumns(Collection entityList){
    def entityColumnsMap = new HashMap()
    ValueMappingApi vm = ITApiFactory.getService(ValueMappingApi.class, null)
    
    entityList.each{
        String columns = vm.getMappedValue(VM_AGENCY_SF, VM_IDENTIFIER_ENTITY, it, VM_AGENCY_SF, VM_IDENTIFIER_FIELDS)
        entityColumnsMap.put(it, columns)
    }
    
    return entityColumnsMap
}

def initFileEntityOrder(){
	
	[
		'BasicUserInfoImportTemplate.csv': 'User',
		'PersonInfoImportTemplate.csv': 'PerPerson',
		'EmploymentInfoImportTemplate.csv': 'EmpEmployment',
		'JobInfoImport.csv': 'EmpJob',
		'CompInfoImport.csv': 'EmpCompensation',
		'PayComponentRecurringImport.csv': 'EmpPayCompRecurring',
		'PayComponentNonRecurringImport.csv': 'EmpPayCompNonRecurring',
		'PersonalInformationTemplate.csv': 'PerPersonal',
		'EmailInfoImportTemplate.csv': 'PerEmail',
		'EmergencyContactImportTemplate.csv': 'PerEmergencyContacts',
		'GlobalInfoImportTemplate.csv': 'PerGlobalInfoUSA',
		'JobRelationship.csv': 'EmpJobRelationships',
		'NationalIdCardImportTemplate.csv': 'PerNationalId',
		'PhoneInfoImportTemplate.csv': 'PerPhone',
		'AddressImportTemplate.csv': 'PerAddressDEFLT',
		'EmpEmploymentTermination.csv': 'EmpEmploymentTermination'
//		'WD-SAP-PaymentInformationCountrySpecific.csv': 'PaymentInformationDetailV3USA'
//		'WorkPermit.csv': 'EmpWorkPermit'
	]
    
}

def initPicklistMapping(String picklistMapping){
    Eval.me("[$picklistMapping]")
	/*['User.custom05':'HH', 'PerAddressDEFLT.state':'STATE_USA', 'PerAddressDEFLT.state_can':'PROVINCE_CAN', 'PerEmail.emailType':'ecEmailType', 'PerPersonal.customString2':'genderidentity',
		'PerPersonal.salutation':'salutation', 'PerPersonal.suffix':'namesuffix', 'EmpEmploymentTermination.customString20':'Benefits_Eligibility',
		'PerEmergencyContacts.relationship':'relation', 'PerGlobalInfoUSA.genericString1':'ETHNICGROUP_USA', 'EmpJobRelationships.relationshipType':'jobRelType',
		 'PerPhone.phoneType':'ecPhoneType', 'EmpWorkPermit.country':'ISOCountryList', 'EmpWorkPermit.documentType':'permitdoctype', 'EmpEmployment.customString2':'YesNo',
		 'EmpEmployment.customString5':'YesNo', 'EmpJob.customString2':'ShiftDifferential', 'EmpJob.customString20':'YesNo', 'EmpJob.customString21':'Benefits_Eligibility',
		 'EmpJob.customString3':'YesNo', 'EmpJob.customString9':'IncentivePlan', 'EmpJob.employeeClass':'EmployeeClass', 'EmpJob.employmentType':'employmentType',
		 'EmpJob.flsaStatus':'FLSASTATUS_USA', 'EmpJob.shiftCode':'shiftcode']*/
}

def initEventReasonMapping(String eventReasonMapping){
    Eval.me("[$eventReasonMapping]")
	/*[
		'Change_Job_Details':'DATACHG',
		'Change_Job_Details_RECLS':'JOBRECLS',
		'Change_Shift_Differential':'DATASHIFT',
		'Decrease_in_Responsibility':'DEMONPAY',
		'GENERAL_EVENT_CATEGORY-6-9':'HIRNEW',
		'Move_to_Another_Position_on_My_Team':'TRANLATL',
		'Promotion':'PROPWP',
		'Rehire':'REHREH',
		'Move_to_Another_Manager':'MANAGERCHG',
		'Terminate_Employee_Involuntary_Attendance':'TERM_I_ATT',
		'TERMINATION_SUBCATEGORY-3-48':'TERM_I_JOBELIM',
		'Terminate_Employee_Involuntary_Performance':'TERM_I_PERF',
		'Terminate_Employee_Involuntary_Violation of Company Policy':'TERM_I_POLICY',
		'Terminate_Employee_Involuntary_Workforce_Reduction':'TERM_I_REDUCT',
		'Terminate_Employee_Voluntary_Abandoned Job':'TERM_V_ABANDON',
		'Terminate_Employee_Voluntary_Better_Career_Opportunity':'TERM_V_CAREER',
		'Terminate_Employee_Voluntary_Commute_Time':'TERM_V_TRANS',
		'Terminate_Employee_Voluntary_Death':'TERIDEAT',
		'Terminate_Employee_Voluntary_Education':'TERM_V_EDUC',
		'Terminate_Employee_Voluntary_Family_Reasons':'TERM_V_PERS',
		'Terminate_Employee_Voluntary_Retirement':'TERRTMNT',
		'TERMINATION_SUBCATEGORY-3-47':'TERM_V_JOBRESP',
		'Voluntary_Not_Provided':'TERVRES',
		'Terminate_Employee_Voluntary_Relocation':'TERM_V_RELO',
		'Layoff':'LOA_P_LAY',
		'LOA_DTO':'LOA_P_DTO',
		'Workers_Compensation':'LOA_P_WCLD',
		'Workers_Compensation_U_WC':'LOA_U_WC',
		'Request_Compensation_Change_Base_Salary_Change_Partial_Pay_During_LOA':'LOA_P_PAY',
		'Not Incorporating PTO':'LOA_U_PERS',
		'Personal Leave Med':'LOA_U_MED',
		'Personal Leave':'LOA_U_PERS',
		'Incorporating PTO':'LOA_P_PTO',
		'Family Medical Leave Act (FMLA) U':'LOA_P_STD ',
		'Family Medical Leave Act (FMLA) P':'LOA_U_FMLA',
		'FamilyMedicalLeaveActFMLA Intermittent Leave':'LOA_P_FMLAI',
		'Regulatory_Military_Service_P':'LOA_P_MIL',
		'Regulatory_Military_Service_U':'LOA_U_MIL',
		'Request_Compensation_Change_Base_Salary_Change_Correction':'PAYCORR',
		'Request_Compensation_Change_Base_Salary_Change_Job_Reclassification':'PAYMGI',
		'Request_Compensation_Change_Base_Salary_Change_Merit':'PAYANN',
		'REQUEST_COMPENSATION_CHANGE_Temporary_Adjustment_Increase':'PAYTEMP',
		'COMPENSATION_CHANGE_FOR_MERIT_PLAN_Promotion':'PAYANN',
		'Conversion':'JOBRECLS',
		'GENERAL_EVENT_SUBCATEGORY-3-123':'PAYCORR',
		'GENERAL_EVENT_SUBCATEGORY-3-155':'PAYCORR',
		'GENERAL_EVENT_SUBCATEGORY-3-156':'PAYCORR',
		'GENERAL_EVENT_SUBCATEGORY-3-157':'PAYCORR',
		'Request_Compensation_Change_Base_Salary_Change_Brought_to_a_Minimum':'PAYMGI',
		'Request_Compensation_Change_Base_Salary_Change_Correction':'PAYCORR',
		'Request_Compensation_Change_Base_Salary_Change_Cost_of_Living_Adjustment':'PAYMKT',
		'Request_Compensation_Change_Base_Salary_Change_Decrease_in_Hours_Worked':'PAYCORR',
		'Request_Compensation_Change_Base_Salary_Change_Increase_in_Hours_Worked':'PAYCORR',
		'Request_Compensation_Change_Base_Salary_Change_Job_Reclassification':'JOBRECLS',
		'Request_Compensation_Change_Base_Salary_Change_Market_Adjustment':'PAYMKT',
		'Request_Compensation_Change_Base_Salary_Change_Merit':'PAYANN',
		'Request_Compensation_Change_Base_Salary_Change_Partial_Pay_During_LOA':'PAYTEMP',
		'REQUEST_COMPENSATION_CHANGE_Temporary_Adjustment_Decrease':'PAYTEMP',
		'REQUEST_COMPENSATION_CHANGE_Temporary_Adjustment_Increase':'PAYTEMP',
		'Request_Compensation_Change_Variable_Compensation_Change_Allowance_Change':'PAYCORR',
		'Request_Compensation_Change_Variable_Compensation_Change_Bonus_Pool_Change':'PAYCORR',
		'Request_Compensation_Change_Variable_Compensation_Change_Commission_Structure_Change':'PAYCORR',
		'Request_Compensation_Change_Variable_Compensation_Change_Target_%_Change':'PAYCORR'
	]*/
}

