import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	def xml = message.getBody(String)
	def picklistEntity = new XmlSlurper().parseText(xml)
	def picklistMap = new HashMap()
	
	picklistEntity.Picklist.each{ picklist ->
		def picklistOptionMap = new HashMap()
		picklist.picklistOptions.PicklistOption.each{
			picklistOptionMap.put(it.externalCode.text(), it.id.text())
		}
		picklistMap.put(picklist.picklistId.text(), picklistOptionMap)
	}
	
//	def messageLog = messageLogFactory.getMessageLog(message)
//	messageLog.addAttachmentAsString("picklistEntity", picklistEntity.toString(), "text/plain")
	
	message.setProperty('picklistMap', picklistMap)
    return message
}