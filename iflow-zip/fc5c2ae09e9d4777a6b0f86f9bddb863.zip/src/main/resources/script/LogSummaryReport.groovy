import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def properties = message.getProperties()
    def summaryMap = properties.get('summaryMap')
	def summaryReport = summaryMap.get('summaryReport')
    
    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addAttachmentAsString("SummaryReport", summaryReport.toString(), "text/plain")
    
    message.setBody(summaryReport.toString())
    return message
}