import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	
	def xml = message.getBody(String)
	def properties = message.getProperties()
	
	def PerGlobalInfoUSA = new XmlSlurper().parseText(xml)
	
	def personIds = PerGlobalInfoUSA.PerGlobalInfoUSA.personIdExternal.collect{"'$it'"}.join(',')
	message.setProperty('personIds', personIds)
	
	return message
}