import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def properties = message.getProperties()
	def summaryReport = properties.get('summaryMap').get('summaryReport')
	
	def exceptionMsg = message.getBody(String)
	summaryReport << "$exceptionMsg\n"
    
    return message
}