import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import groovy.json.*

def Message processData(Message message) {
    def ebody = message.getBody(String);
// unescape the JSON body    
    def body=StringEscapeUtils.unescapeJava(ebody)
    map = message.getProperties();
    
// Define JSON extracter
    def jsonSlurper = new JsonSlurper()
    def rpn = jsonSlurper.parseText(body as String);
// Store required values into properties    
       message.setProperty("EmployerRegistrationNumber", rpn.employerRegistrationNumber);
       message.setProperty("TaxYear", rpn.taxYear);
       message.setProperty("PayrollRunReference", rpn.payrollRunReference);
        message.setProperty("EmployeeId", rpn.employeeID);
        message.setProperty("SoftwareUsed", rpn.softwareUsed.name);
       message.setProperty("SoftwareVersion", rpn.softwareUsed.version);
       message.setProperty("AgentTain", rpn.agentTain);
       def output = JsonOutput.toJson(rpn.requestBody)
       message.setProperty("gBody", output);   
// Get Partner Directory Data
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 
       if (service == null){
          throw new IllegalStateException("Partner Directory Service not found");
       }
       def map = message.getProperties();
        def empRegNumber = map.get("EmployerRegistrationNumber");
       if (empRegNumber == null){
          throw new IllegalStateException("Employee Registration ID could not be read from body'")      
       }

     def parameterValue = service.getParameter("CName", empRegNumber , String.class);
     if (parameterValue == null){
        throw new IllegalStateException("CName parameter not found in the Partner Directory for the partner ID "+empRegNumber);      
     }
      message.setProperty("CertificateName", parameterValue );
// Set the field agentTain dynamically for the query string if value is found in the incoming message      
    def agentTainValue = map.get("AgentTain");
    if (agentTainValue != null) {
      message.setProperty("FieldAgentTain", "agentTain=");
    }

   return message;
}  



