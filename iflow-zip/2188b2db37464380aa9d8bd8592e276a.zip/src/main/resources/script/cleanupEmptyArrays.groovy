import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Retrieve the payload as a string
    def body = message.getBody(java.lang.String) as String
    
    // Parse the JSON payload
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(body)
    

    // Rename odata.context to @odata.context
    if (jsonObject.containsKey("odata.context")) {
        jsonObject["@odata.context"] = jsonObject.remove("odata.context")
    }
    
    // Rename odata.metadataEtag to @odata.metadataEtag
    if (jsonObject.containsKey("odata.metadataEtag")) {
        jsonObject["@odata.metadataEtag"] = jsonObject.remove("odata.metadataEtag")
    }
    
    // Update the SAP_RETURN and LOG fields
    if (jsonObject.SAP_RETURN instanceof List && jsonObject.SAP_RETURN.size() == 1 && jsonObject.SAP_RETURN[0] == "") {
        jsonObject.SAP_RETURN = []
    }
    if (jsonObject.LOG instanceof List && jsonObject.LOG.size() == 1 && jsonObject.LOG[0] == "") {
        jsonObject.LOG = []
    }


    
    // Convert the modified JSON back to a string
    def modifiedJson = JsonOutput.toJson(jsonObject)
    
    // Pretty-print the JSON (optional)
    modifiedJson = JsonOutput.prettyPrint(modifiedJson)
    
    // Set the modified payload back to the message
    message.setBody(modifiedJson)
  
    return message
}
