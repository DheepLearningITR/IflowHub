import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.time.*;
def Message processData(Message message) {
    def map = message.getHeaders();
     def keyId = message.getProperties().get('keyId');
     def signBody = message.getHeaders().get('Signature');
     	message.getProperties().put('signBody', signBody);

     Signature = "keyId=" + '"' + keyId + '"';
     Signature = Signature + ",algorithm="  + '"' + "rsa-sha512" + '"' + ",headers="  + '"' + "(request-target) x-date host digest"  + '"' +",signature=";
     Signature = Signature + '"' + signBody  + '"';
    
    message.setHeader("Content-Type", "application/json");
    message.setHeader("Signature", Signature);
//    def body = message.getBody(String);
//    body = ""; 
//    message.setBody(body);

  return message;
}