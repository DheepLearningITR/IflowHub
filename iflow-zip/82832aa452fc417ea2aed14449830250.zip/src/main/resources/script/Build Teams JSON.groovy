import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder

def Message processData(Message message) {

    def assigneeName = message.getProperty("AssigneeName")
    def title = message.getProperty("Title")
    def dueDate = message.getProperty("DueDate")
    def projectName = message.getProperty("ProjectName")
    def subject = message.getProperty("Subject")
    def involvedParties = message.getProperty("InvolvedParties")

    def builder = new JsonBuilder()

    builder {
        "@type" "MessageCard"
        "@context" "http://schema.org/extensions"
        "summary" "SAP Cloud ALM Notification"
        sections ([
            [
                activityTitle: subject
            ],
            [
                facts: [
                    [
                        name: "Assignee Name",
                        value: assigneeName
                    ],
                    [
                        name: "Project",
                        value: projectName
                    ],
                    [
                        name: "Task",
                        value: title
                    ],
                    [
                        name: "Due Date",
                        value: dueDate
                    ],
                    [
                        name: "Involved Parties",
                        value: involvedParties
                    ]
                ],
                markdown: true
            ]
        ])
    }

    message.setBody(builder.toPrettyString())
    
    return message
}