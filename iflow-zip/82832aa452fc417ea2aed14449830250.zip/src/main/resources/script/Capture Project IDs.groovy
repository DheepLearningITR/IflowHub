import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    def headers = message.getHeaders()
    def projectIds = headers.get("ProjectIDs").split(',')
    def taskStatus = headers.get("TaskStatus").split(',')

    def xmlString = new StringWriter()
    def xmlBuilder = new MarkupBuilder(xmlString)

    xmlBuilder.Projects {
        projectIds.each { id ->
            taskStatus.each { status ->
                Project {
                    ProjectId(id)
                    TaskStatus(status)
                }
            }
        }
    }

    message.setBody(xmlString.toString())

    return message
}