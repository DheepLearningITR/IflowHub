import com.sap.gateway.ip.core.customdev.util.Message
import java.util.Date
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def inputBody = new JsonSlurper().parseText(message.getBody(java.lang.String))
    def tasks = inputBody

    def today = new Date().clearTime()

    def openTasks = tasks.findAll { task ->
        Date.parse("yyyy-MM-dd", task.dueDate).clearTime() >= today
    }
    def lateTasks = tasks.findAll { task ->
        Date.parse("yyyy-MM-dd", task.dueDate).clearTime() < today
    }

    def outputJson = new JsonBuilder()
    outputJson(openTasks: openTasks.collect { task ->
        [id: task.id, projectId: task.projectId, title: task.title, status: task.status, assigneeId: task.assigneeId, assigneeName: task.assigneeName, dueDate: task.dueDate, involvedParties: task.involvedParties]
    }, lateTasks: lateTasks.collect { task ->
        [id: task.id, projectId: task.projectId, title: task.title, status: task.status, assigneeId: task.assigneeId, assigneeName: task.assigneeName, dueDate: task.dueDate, involvedParties: task.involvedParties]
    })

    message.setBody(outputJson.toPrettyString())
    return message
}
