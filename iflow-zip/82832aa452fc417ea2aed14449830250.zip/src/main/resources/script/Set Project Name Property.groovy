import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def inputBody = new JsonSlurper().parseText(message.getProperty("ProjectsResponse"))
    def projectId = message.getProperty("ProjectId")

    message.setProperty("ProjectName", inputBody.find { it.id == projectId }?.name)

    return message
}