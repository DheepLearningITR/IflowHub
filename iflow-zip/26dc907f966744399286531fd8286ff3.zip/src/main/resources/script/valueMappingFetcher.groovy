import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.gateway.ip.core.customdev.util.Message;


Message getFromValueMapping(Message message) {    

    def eventTypeProperty = message.getProperty("EventType")
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def s4EventType = valueMapApi.getMappedValue("CGTO", 
                                                "EventType", 
                                                eventTypeProperty, 
                                                "S4", 
                                                "EventType")
    
    if (s4EventType == null) {
         message.setProperty("EventTypeValueMapping", "InvalidEvent")
    } else {
        message.setProperty("EventTypeValueMapping", s4EventType)
    }

    return message
    
}
