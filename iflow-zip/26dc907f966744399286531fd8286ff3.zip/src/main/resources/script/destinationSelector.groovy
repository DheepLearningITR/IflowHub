import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.gateway.ip.core.customdev.util.Message;


Message selectDestinationTopic(Message message) {    

    def eventTypeProperty = message.getProperty("EventType")
    def eventMeshNamespaceProperty = message.getProperty("EventMeshNamespace")
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def s4TopicName = valueMapApi.getMappedValue("CGTO", "BusinessObjectTopic", eventTypeProperty, "S4", "BusinessObjectTopic")
    

    message.setProperty("destinationTopic", "topic:" + eventMeshNamespaceProperty + "/" + s4TopicName)
    
    return message
    
}