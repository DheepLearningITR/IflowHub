import com.sap.gateway.ip.core.customdev.util.Message; 
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

def Message prepareQueryFilter(Message message) {
    def properties = message.getProperties()
    def sapClient = properties.get("Client")
    def languages = properties.get("Language")

    def textFilter = ""

    if (languages && languages.trim()) {
        // Split and build filter only if languages is not empty
        def languageArray = languages.split(',')*.trim().findAll { it }  // remove blanks
        if (languageArray) {
            def languageFilter = languageArray.collect { "Language%20eq%20%27$it%27" }
                                             .join('%20or%20')
            textFilter = "\$filter=%28${languageFilter}%29"
        }
    }

    // Append sap-client if available
    if (sapClient) {
        textFilter += (textFilter ? "&" : "") + "sap-client=$sapClient"
    }

    // Only set property if we actually built something
    if (textFilter) {
        message.setProperty("P_queryFilter", textFilter)
    }

    return message
}

def Message setVariableNames(Message message) {
    def body = message.getBody(java.io.Reader)
    def data = new JsonSlurper().parse(body)
    def senderId = data.messageHeader.senderCommunicationSystemDisplayId
    def receiverId = data.messageHeader.receiverCommunicationSystemDisplayId
    message.setProperty("SenderBusinessSystem", receiverId)
    message.setProperty("ReceiverBusinessSystem", senderId)
    return message
}
   
def Message splitMessageRequest(Message message) {
    def body = message.getBody(java.io.Reader)
    def parsedJson = new JsonSlurper().parse(body)
    // Split message requests into chunks
    def messageRequests = parsedJson.messageRequests
    def chunkSize = 100
    def chunks = messageRequests.collate(chunkSize)
    // Wrap chunks inside a new JSON array with unique GUIDs and timestamps
    def outputJsonArray = []
    chunks.each {
        chunk -> def newHeader = parsedJson.messageHeader.collectEntries {
            k, v -> if (k == 'id') {
                [k, UUID.randomUUID().toString()]
            } else if (k == 'creationDateTime') {
                [k, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))]
            } else {
                [k, v]
            }
        }
        def chunkJson = [
            messageHeader: newHeader,
            messageRequests: chunk
        ]
        outputJsonArray << chunkJson
    }
    // Convert to JSON
    def bundledJson = [bundledJson: outputJsonArray]
    def outputJson = JsonOutput.toJson(bundledJson)
    message.setBody(outputJson)
    return message
}
    
def Message removeJsonRootElement(Message message) {
    def body = message.getBody(java.io.Reader)
    def outputJson = new JsonSlurper().parse(body).bundledJson
    message.setBody(JsonOutput.toJson(outputJson))
    return message
}

def Message prepareResponse (Message message) {
    
    def properties = message.getProperties()
    def senderBusinessSystem = properties.get("SenderBusinessSystem")
    def receiverBusinessSystem = properties.get("ReceiverBusinessSystem")
    def initialLoad = properties.get("InitialLoad")
    
    def body = message.getBody(java.io.Reader)
    def s4RegionCodes = new JsonSlurper().parse(body).value
    
    // Group entries by region + country
    def grouped = s4RegionCodes.groupBy {
        "${it.Region}\$XDP\$${it.Country}"
    }
    
    
    def currentMessage = createMessageHeader(senderBusinessSystem,receiverBusinessSystem)
    def messageRequests = []
    def codeActiveMap= [:]
    
     if (initialLoad?.toString().equalsIgnoreCase("true")) {
            def cnsRegionCodes = new JsonSlurper().parse(properties.get("cnsCodes")).value
            // Build a lookup map: code -> isActive
            codeActiveMap = cnsRegionCodes.collectEntries { [(it.code):it.descriptions] }
        }
    
    grouped.each {
        code, entries -> def descriptions = entries.collect {
            [content: it.RegionName, languageCode: it.Language]
        }
       
        def messageRequest = [
            body: [
                code: code,
                descriptions: descriptions,
                isActive: true
            ],
            messageHeader: [
                actionCode: "CREATE",
                creationDateTime: LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")),
                id: UUID.randomUUID().toString(),
                messageEntityName: "sap.crm.i18nservice.entity.regionCodeS4ReplicationMessageIn"
            ]
        ]
        messageRequests << messageRequest
    }
    
    if (initialLoad?.toString().equalsIgnoreCase("true")) {
                // Add messageRequests for codes in codeActiveMap but not in grouped
                def missingCodes = codeActiveMap.keySet() - grouped.keySet()
                missingCodes.each { missingCode ->
                    def missingCodeMessageRequest = [
                            body         : [
                                    code    : missingCode,
                                    descriptions: codeActiveMap[missingCode],
                                    isActive: false
                            ],
                            messageHeader: [
                                    actionCode       : "CREATE",
                                    creationDateTime : LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")),
                                    id               : UUID.randomUUID().toString(),
                                    messageEntityName: "sap.crm.i18nservice.entity.regionCodeS4ReplicationMessageIn"
                            ]
                    ]
                    messageRequests << missingCodeMessageRequest

            }
        }
   
    currentMessage.messageRequests = messageRequests
   
    def outputJson = JsonOutput.toJson(currentMessage)
    message.setBody(outputJson)
    
    return message
}

def createMessageHeader(senderBusinessSystem,receiverBusinessSystem) {
        def creationDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))
        return [
                messageHeader  : [
                        creationDateTime                    : creationDateTime,
                        id                                  : UUID.randomUUID().toString(),
                        receiverCommunicationSystemDisplayId: receiverBusinessSystem,
                        senderCommunicationSystemDisplayId  : senderBusinessSystem
                ],
                messageRequests: []
        ]
    }
    
def postProcessing (Message message){
        def body = message.getBody(java.io.Reader)
        def parsedJson = new JsonSlurper().parse(body).bundledJson
        parsedJson.messageRequests.each { request ->
            request.body.isActive = request.body.isActive?.toBoolean()
        }
        message.setBody(JsonOutput.toJson(parsedJson))
        return message
    }