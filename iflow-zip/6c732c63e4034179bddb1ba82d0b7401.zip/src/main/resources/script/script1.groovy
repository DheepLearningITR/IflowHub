import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.securestore.*;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.Transformer
import javax.xml.transform.TransformerFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.Source
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import javax.xml.xpath.XPath
import javax.xml.xpath.XPathConstants
import javax.xml.xpath.XPathFactory
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import groovy.xml.XmlUtil;
import groovy.xml.MarkupBuilder;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder
import groovy.util.XmlSlurper
import org.w3c.dom.Document
import org.w3c.dom.Node
import org.w3c.dom.NodeList
import org.w3c.dom.Element
import org.xml.sax.InputSource
import src.main.resources.script.CPILogger;

def Message finalizeInitialContent(Message message) {
	def props = message.getProperties();
	def headers = message.getHeaders();
	def inContentType = (headers.get("Content-Type") ?:"application/hal+xml").toLowerCase();
	def inAccept = (headers.get("Accept") ?:"application/hal+xml,application/xml").toLowerCase();
	message.setProperty("IN_ACCEPT", inAccept);
	message.setProperty("IN_CONTENT_TYPE", inContentType);
	message.setProperty("IN_BODY", message.getBody(String.class));
	URI altinnURI = new URI(props.get("ALTINN_URL"));
	URI tenantURI = new URI(headers.get("CamelHttpUrl"));
	def tenantPath = tenantURI.getPath();
	def index = tenantPath.lastIndexOf(headers.get("CamelHttpPath"));
	def sourcePath;
	if (index > 0) {
		sourcePath = tenantPath.substring(0, index);
	} else {
		sourcePath = "/http" + headers.get("CamelServletContextPath");
		throw new IllegalStateException("Unable to prepare source URI");
	}
	URI baseUrlCpi = new URI(tenantURI.getScheme(), null, tenantURI.getHost(), tenantURI.getPort(), sourcePath, null, null);
	URI baseUrlAltinn = new URI(altinnURI.getScheme(), null, altinnURI.getHost(), altinnURI.getPort(), "/", null, null);
	message.setProperty("BASE_URL_CPI", baseUrlCpi.toURL().toString());
	message.setProperty("BASE_URL_ALTINN", baseUrlAltinn.toURL().toString());
	def paramsMap = Utils.urlParamsToParamsMap(props.get("IN_HTTP_QUERY"));
	def cpiParams = [];
	Pattern pattern = Pattern.compile("^\\\$cpi_((\\d*)_?)(.*)\$");
	for ( entry in paramsMap ) {
		Matcher matcher = pattern.matcher(entry.name);
		if (matcher.find()) {
			def id = matcher.group(2) ? matcher.group(2) as int : 0;
			cpiParams << [id: id, type: matcher.group(3), value: entry.value];
		}
	}
	cpiParams.sort { a, b -> a.id <=> b.id };
	def jsonBuilder = new JsonBuilder();
	jsonBuilder(cpiParams);
	message.setProperty("DO_PP_LIST", jsonBuilder.toString() );
	return message;
}

def Message prepareExecuteDetails(Message message) {
	def props = message.getProperties();
	Utils.setInExecuteDetails(message);
	//	if ("application/hal+xml".equalsIgnoreCase(props.get("IN_CONTENT_TYPE") ?:"application/hal+xml"))
	//	    message.setBody(Utils.printSingleLineXml(Utils.parseXml(props.get("IN_BODY")),String.class));
	//	else
	message.setBody(props.get("IN_BODY"));
	return message;
}

def Message preparePostProcessLoop(Message message) {
	Utils.evaluatePostProcessLoop(message);
	return message;
}

def Message preparePostProcessExecuteDetails(Message message) {
	def postProcessLoop = Utils.getPostProcessLoop(message)
	postProcessLoop.prepareExecuteDetails(message);
	return message;
}

def Message prepareNextPostProcessLoop(Message message) {
	def postProcessLoop = Utils.getPostProcessLoop(message)
	postProcessLoop.prepareNextLoop(message);
	return message;
}

def Message evaluatePostProcessLoop(Message message) {
	def props = message.getProperties();
	if ("yes".equalsIgnoreCase(props.get("PP_LOOP_EVALUATE"))) {
		Utils.evaluatePostProcessLoop(message);
		message.setProperty("PP_LOOP_EVALUATE", null );
	}
	return message;
}

def Message evaluateEmptyPayload(Message message) {
	def body = message.getBody(String.class)
	message.setProperty("EMPTY_PAYLOAD", body == null || body.isEmpty());
	return message;
}

def Message setFinalResponseDetails(Message message) {
	return message;
}

def Message storeHttpHeaderDetails(Message message) {
	def props = message.getProperties();
	def headers = message.getHeaders();
	def locationAltinn = headers.get("Location");
	def locationCpi = "";
	if (locationAltinn!=null) {
		locationCpi = locationAltinn.replaceFirst("(?i)"+props.get("BASE_URL_ALTINN"),props.get("BASE_URL_CPI"));
	}
	def prefix = headers.containsKey("MAIN") ? "LAST" : ( headers.containsKey("AUTH") ? "MAIN" : "AUTH" );
	headers.put(prefix,"${props.get(prefix+'_ORIGIN')}|${headers.get('CamelHttpResponseCode')}|${locationCpi}|${headers.get('CamelHttpResponseText')}");
	props.put(prefix+"_RESPONSE_CODE",headers.get("CamelHttpResponseCode"));
	props.put(prefix+"_CONTENT_TYPE",headers.get("Content-Type"));
	if (locationAltinn!=null) {
		headers.put("Location",locationCpi);
		props.put(prefix+"_LOCATION_ALTINN",locationAltinn);
		props.put(prefix+"_LOCATION_CPI",locationCpi);
	}
	return message;
}

def Message cleanupHeaders(Message message) {
	def headers = message.getHeaders();
	def remove = [];
	for (header in headers) {
		switch(header.key) {
			case "AUTH":
			case "MAIN":
			case "LAST":
			case "CamelHttpResponseCode":
			case "Location":
			case "Content-Type":
				break;
			default:
				remove << header.key;
		}
	}
	remove.each {
		headers.remove(it);
	}
	return message;
}


def Message getECUserFromPD(Message message) {
	def headers = message.getHeaders();
	def props = message.getProperties();
	def ecuid = headers.get("ECUID");
	if (ecuid != null){
		def pdService = ITApiFactory.getApi(PartnerDirectoryService.class, null);
		if (pdService == null){
			throw new IllegalStateException("Partner Directory Service not found");
		}
		def ecUserJson = pdService.getParameter("EC_USER", "HRNO_ECUID_"+ecuid , String.class);
		if (ecUserJson != null){
			JsonSlurper slurper = new JsonSlurper();
			def object = slurper.parseText(ecUserJson);
			def ecUser = new ECUser(object);
			message.setProperty("EC_USER_NAME", ecUser.name );
			def secureService = ITApiFactory.getApi(SecureStoreService.class, null);
			if (secureService == null){
				throw new IllegalStateException("Secure Store Service not found");
			}
			def pdMasterPasswordAlias = props.get("EC_USER_MASTER_PASSWORD_ALIAS");
			def credential = secureService.getUserCredential(pdMasterPasswordAlias);
			if (credential == null){
				throw new IllegalStateException("No credential found for alias '${pdMasterPasswordAlias}'");
			}
			message.setProperty("EC_USER_PASSWORD", ecUser.getPass( new String(credential.getPassword()) ) );
		}
	}
	return message;
}

def Message handleHttpException(Message message) {
	def props = message.getProperties();
	def exc = props.get("CamelExceptionCaught");
	if (exc!=null) {
		if (exc.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
			def body = exc.getResponseBody();
			message.setBody(body);
			try {
				new JsonSlurper().parseText(body);
				message.setHeader("Content-Type", "application/json");
			} catch (ignored1) {
				try {
					Utils.parseXml(props.get(body));
					message.setHeader("Content-Type", "application/xml");
				} catch (ignored2) {
				}
			}
		} else {
			throw new Exception(exc);
		}
	}
	return message;
}

def Message log_auth_in(Message message) {
	def log_suffix = 'auth_in';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_auth_out(Message message) {
	def log_suffix = 'auth_out';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_auth_exc(Message message) {
	def log_suffix = 'auth_exc';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_exec_in(Message message) {
	def log_suffix = 'exec_in';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_exec_out(Message message) {
	def log_suffix = 'exec_out';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_exec_exc(Message message) {
	def log_suffix = 'exec_exc';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_req_in(Message message) {
	def log_suffix = 'req_in';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

def Message log_res_out(Message message) {
	def log_suffix = 'res_out';
	CPILogger cpiLogger = new CPILogger(logFactory: messageLogFactory);
	cpiLogger.logMessage("{LOG_ID}_{COUNTER}_${log_suffix}", message);
	return message;
}

class Utils {

	static printSingleLineXml(Document document, Class returnType = String.class, Closure modTransformer = null){
		Transformer transformer = TransformerFactory.newInstance().newTransformer()
		transformer.setOutputProperty(OutputKeys.INDENT, "no")
		//        transformer.setOutputProperty(OutputKeys.CDATA_SECTION_ELEMENTS, "resource");
		if(modTransformer!=null){
			modTransformer.call(transformer)
		}
		switch(returnType) {
			case byte[].class:
				ByteArrayOutputStream bos = new ByteArrayOutputStream()
				transformer.transform(new DOMSource(document), new StreamResult(bos))
				return bos.toByteArray()
				break
			case String.class:
			default:
				StringWriter writer = new StringWriter()
				transformer.transform(new DOMSource(document), new StreamResult(writer))
				return writer.getBuffer().toString()
				break
		}
	}

	static parseXml(def source){
		Document document = null;
		if (source != null) {
			def builder = DocumentBuilderFactory.newInstance().newDocumentBuilder()
			switch(source.class) {
				case byte[].class:
					document = builder.parse(new ByteArrayInputStream(source))
					break
				case String.class:
				default:
					document = builder.parse(new InputSource(new StringReader(source)))
					break
			}
			removeWhitspace(document)
		}
		return document
	}

	static removeWhitspace(Document document){
		def xpath = XPathFactory.newInstance().newXPath()
		NodeList emptyTextNodes = (NodeList)xpath.evaluate("//text()[normalize-space(.) = '']", document, XPathConstants.NODESET)
		for (int i = 0; i < emptyTextNodes.getLength(); i++) {
			Node emptyTextNode = emptyTextNodes.item(i)
			emptyTextNode.getParentNode().removeChild(emptyTextNode)
		}
		document.normalize()
	}

	static def urlParamsToParamsMap(String urlParams) {
		def paramsMap = [];
		if (urlParams != null) {
			String[] pairs = urlParams.split("&");
			for (String pair : pairs) {
				int idx = pair.indexOf("=");
				paramsMap << [name: URLDecoder.decode(pair.substring(0, idx), "UTF-8"), value: URLDecoder.decode(pair.substring(idx + 1), "UTF-8")];
			}
		}
		return paramsMap;
	}

	static String paramsMapToUrlParams(def params) {
		if (params.size()==0)
			return null;
		def urlParams = ''<<''
		for ( entry in params ) {
			if (urlParams.length() != 0)
				urlParams <<= "&";
			urlParams <<= URLEncoder.encode(entry.name, "UTF-8");
			urlParams <<= "=";
			urlParams <<= URLEncoder.encode(String.valueOf(entry.value), "UTF-8");
		}
		return urlParams.toString();
	}

	static void setInExecuteDetails(Message message, Closure modParamsMap = null){
		def props = message.getProperties();
		URI defaultURI = new URI(props.get("ALTINN_URL"));
		def urlParams = props.get("IN_HTTP_QUERY");
		def paramsMap = Utils.urlParamsToParamsMap(urlParams);
		paramsMap = paramsMap.findAll{ !it.name.startsWith("\$cpi_") };
		if(modParamsMap!=null){
			modParamsMap.call(paramsMap)
		}
		urlParams = Utils.paramsMapToUrlParams(paramsMap);
		URI restURI = new URI(defaultURI.getScheme(), null, defaultURI.getHost(), defaultURI.getPort(), '/' + props.get("IN_HTTP_PATH"), urlParams, null);
		message.setProperty("DYN_HTTP_URL", restURI.toURL().toString());
		message.setProperty("DYN_ACCEPT", props.get("IN_ACCEPT"));
		message.setProperty("DYN_CONTENT_TYPE", props.get("IN_CONTENT_TYPE"));
		message.setProperty("DYN_HTTP_METHOD", props.get("IN_HTTP_METHOD"));
	}

	static PostProcessLoop getPostProcessLoop(Message message) {
		def props = message.getProperties();
		//		if ("GET".equals(props.get("IN_HTTP_METHOD"))) {
		def jsonSlurper = new JsonSlurper()
		def ppList = jsonSlurper.parseText(props.get("DO_PP_LIST"));
		if (ppList.size() > 0) {
			if ("GET_ALL".equalsIgnoreCase(ppList.getAt(0).type))
				return new postProcessGetAll(ppList.getAt(0).value,"${ppList.getAt(0).id}_${ppList.getAt(0).type}");
			if ("ADD_LINK_REL".equalsIgnoreCase(ppList.getAt(0).type))
				return new postProcessAddLinkRel(ppList.getAt(0).value,"${ppList.getAt(0).id}_${ppList.getAt(0).type}");
			if ("REPLACE_BY_LINK_REL".equalsIgnoreCase(ppList.getAt(0).type))
				return new postProcessReplaceByLinkRel(ppList.getAt(0).value,"${ppList.getAt(0).id}_${ppList.getAt(0).type}");
			if ("REMOVE_XPATH".equalsIgnoreCase(ppList.getAt(0).type))
				return new postProcessRemoveXpath(ppList.getAt(0).value,"${ppList.getAt(0).id}_${ppList.getAt(0).type}");
			if ("GET_LINK_REL".equalsIgnoreCase(ppList.getAt(0).type))
				return new postProcessGetLinkRel(ppList.getAt(0).value,"${ppList.getAt(0).id}_${ppList.getAt(0).type}");
		}
		//		}
		return null;
	}

	static void evaluatePostProcessLoop(Message message) {
		def postProcessLoop = Utils.getPostProcessLoop(message)
		while(postProcessLoop!=null && !postProcessLoop.prepareFirstLoop(message)) {
			postProcessLoop = Utils.getPostProcessLoop(message);
		}
		postProcessLoop == null ? message.setProperty("DO_PP_LOOP", null ) : message.setProperty("DO_PP_LOOP", "yes" );
	}

	static void removeFirstPostProcessLoop(Message message) {
		def props = message.getProperties();
		def jsonSlurper = new JsonSlurper()
		def ppList = jsonSlurper.parseText(props.get("DO_PP_LIST"));
		if (ppList.size() > 0) {
			ppList.removeAt(0);
			def jsonBuilder = new JsonBuilder();
			jsonBuilder(ppList);
			message.setProperty("DO_PP_LIST", jsonBuilder.toString() );
		}
	}
}

class ECUser {
	String name;
	String data_v1;
	def void setPass(String pass, String key) {
		Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, aesKey);
		data_v1 = cipher.doFinal(pass.getBytes()).encodeBase64().toString();
	}
	def String getPass(String key) {
		Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, aesKey);
		return new String(cipher.doFinal(data_v1.decodeBase64()));
	}
}

interface PostProcessLoop {
	boolean prepareFirstLoop(Message message)
	void prepareExecuteDetails(Message message)
	void prepareNextLoop(Message message)
}

class postProcessGetAll implements PostProcessLoop {
	String value;
	String ppID;

	postProcessGetAll(value,ppID) {
		this.value = value;
		this.ppID = ppID;
	}

	boolean prepareFirstLoop(Message message) {
		def props = message.getProperties();
		def xpath = XPathFactory.newInstance().newXPath()
		Document actualDocument = message.getBody(Document.class)
		if (actualDocument == null)
			throw new IllegalStateException("Unable to get Body as XML Document");
		Utils.removeWhitspace(actualDocument);
		def actualResourceCount = xpath.evaluate("count(/resource/resource)",actualDocument, XPathConstants.NUMBER) as int;
		if ( actualResourceCount.intValue() == 50 ) {
			message.setProperty("PP_GET_ALL_COUNT", actualResourceCount as String );
			message.setProperty("PP_FULL_DOCUMENT", Utils.printSingleLineXml(actualDocument) );
			return true;
		}
		Utils.removeFirstPostProcessLoop(message);
		return false;
	}

	void prepareExecuteDetails(Message message) {
		def props = message.getProperties();
		def modParamsMap = {
			if (it.find { it.name.equalsIgnoreCase("\$skip") } != null)
				throw new IllegalStateException("PostProcessGetAll cannot be used with param \$skip");
			it << [name: "\$skip", value: props.get("PP_GET_ALL_COUNT")];
		}
		Utils.setInExecuteDetails(message,modParamsMap);
	}

	void prepareNextLoop(Message message) {
		def props = message.getProperties();
		def xpath = XPathFactory.newInstance().newXPath()
		Document actualDocument = message.getBody(Document.class)
		if (actualDocument == null) {
			throw new IllegalStateException("Unable to get Body as XML Document")
		}
		Utils.removeWhitspace(actualDocument);
		def actualResourceCount = xpath.evaluate("count(/resource/resource)",actualDocument, XPathConstants.NUMBER) as int;
		Document fullDocument = Utils.parseXml(props.get("PP_FULL_DOCUMENT"));
		if (fullDocument == null) {
			throw new IllegalStateException("Unable to PP_FULL_DOCUMENT as XML Document");
		}
		def fullRoot = fullDocument.getDocumentElement();
		NodeList actualNodes = (NodeList)xpath.evaluate("/resource/resource", actualDocument, XPathConstants.NODESET);
		for (int i = 0; i < actualNodes.getLength(); i++) {
			fullRoot.appendChild(fullDocument.importNode(actualNodes.item(i), true));
		}
		def fullResourceCount = xpath.evaluate("count(/resource/resource)",fullDocument, XPathConstants.NUMBER) as int;
		if ( actualResourceCount.intValue() == 50 ) {
			message.setProperty("PP_GET_ALL_COUNT", fullResourceCount as String );
			message.setProperty("PP_FULL_DOCUMENT", Utils.printSingleLineXml(fullDocument) );
		} else {
			fullRoot.setAttribute("cpi_pp",fullRoot.hasAttribute("cpi_pp") ? fullRoot.getAttribute("cpi_pp")+","+ppID : ppID);
			message.setProperty("PP_GET_ALL_COUNT", null );
			message.setProperty("PP_FULL_DOCUMENT", null );
			Utils.removeFirstPostProcessLoop(message);
			message.setBody(fullDocument);
			//			message.setBody(Utils.printSingleLineXml(fullDocument,byte[].class));
			message.setProperty("PP_LOOP_EVALUATE", "yes" );
		}
	}
}

class postProcessAddLinkRel implements PostProcessLoop {
	String value;
	String ppID;

	postProcessAddLinkRel(value,ppID) {
		this.value = value;
		this.ppID = ppID;
	}

	boolean prepareFirstLoop(Message message) {
		def props = message.getProperties();
		def xpath = XPathFactory.newInstance().newXPath()
		Document actualDocument = message.getBody(Document.class)
		if (actualDocument == null)
			throw new IllegalStateException("Unable to get Body as XML Document");
		Utils.removeWhitspace(actualDocument);
		def actualCount = xpath.evaluate("count(${this.value})",actualDocument, XPathConstants.NUMBER) as int;
		message.setProperty("PP_ADD_LINK_REL_COUNT", actualCount as String );
		if ( actualCount.intValue() > 0 ) {
			return true;
		}
		Utils.removeFirstPostProcessLoop(message);
		return false;
	}

	void prepareExecuteDetails(Message message) {
		message.setProperty("DYN_HTTP_URL", null);
	}

	void prepareNextLoop(Message message) {
		def props = message.getProperties();
		def xpath = XPathFactory.newInstance().newXPath()
		Document actualDocument = message.getBody(Document.class)
		if (actualDocument == null)
			throw new IllegalStateException("Unable to get Body as XML Document");
		Utils.removeWhitspace(actualDocument);
		def addLinkTo = [];
		NodeList nodeList = (NodeList)xpath.evaluate(this.value, actualDocument, XPathConstants.NODESET);
		for (int i = 0; i < nodeList.getLength(); i++) {
			Element element = (Element)nodeList.item(i);
			addLinkTo << element
		}
		addLinkTo.each {
			def link = actualDocument.createElement("link");
			link.setAttribute("cpi_pp",link.hasAttribute("cpi_pp") ? link.getAttribute("cpi_pp")+","+ppID : ppID);
			it.setAttribute("cpi_pp",ppID);
			link.setAttribute("href",it.getAttribute("href"));
			link.setAttribute("rel",it.getAttribute("rel"));
			def child = it.getFirstChild();
			if (child == null)
				it.appendChild(link);
			else
				it.insertBefore(link, it.getFirstChild());
		}
		Utils.removeFirstPostProcessLoop(message);
		message.setBody(actualDocument);
		//		message.setBody(Utils.printSingleLineXml(actualDocument,byte[].class));
		message.setProperty("PP_LOOP_EVALUATE", "yes" );
	}
}

class postProcessReplaceByLinkRel implements PostProcessLoop {
	String value;
	String ppID;

	postProcessReplaceByLinkRel(value,ppID) {
		this.value = value;
		this.ppID = ppID;
	}

	boolean prepareFirstLoop(Message message) {
		def props = message.getProperties();
		def xpath = XPathFactory.newInstance().newXPath()
		Document actualDocument = message.getBody(Document.class)
		if (actualDocument == null)
			throw new IllegalStateException("Unable to get Body as XML Document");
		Utils.removeWhitspace(actualDocument);
		def actualCount = xpath.evaluate("count(${this.value})",actualDocument, XPathConstants.NUMBER) as int;
		message.setProperty("PP_REPLACE_BY_LINK_REL_COUNT", actualCount as String );
		if ( actualCount.intValue() > 0 ) {
			return true;
		}
		Utils.removeFirstPostProcessLoop(message);
		return false;
	}

	void prepareExecuteDetails(Message message) {
		message.setProperty("DYN_HTTP_URL", null);
	}

	void prepareNextLoop(Message message) {
		def props = message.getProperties();
		def xpath = XPathFactory.newInstance().newXPath()
		Document actualDocument = message.getBody(Document.class)
		if (actualDocument == null)
			throw new IllegalStateException("Unable to get Body as XML Document");
		Utils.removeWhitspace(actualDocument);
		def addLinkTo = [];
		NodeList nodeList = (NodeList)xpath.evaluate(this.value, actualDocument, XPathConstants.NODESET);
		for (int i = 0; i < nodeList.getLength(); i++) {
			Element element = (Element)nodeList.item(i);
			addLinkTo << element
		}
		addLinkTo.each {
			def link = actualDocument.createElement("link");
			link.setAttribute("cpi_pp",link.hasAttribute("cpi_pp") ? link.getAttribute("cpi_pp")+","+ppID : ppID);
			it.setAttribute("cpi_pp",ppID);
			link.setAttribute("href",it.getAttribute("href"));
			link.setAttribute("rel",it.getAttribute("rel"));
			it.getParentNode().replaceChild(link, it);
			//    	    link.appendChild(it);
		}
		Utils.removeFirstPostProcessLoop(message);
		message.setBody(actualDocument);
		//		message.setBody(Utils.printSingleLineXml(actualDocument,byte[].class));
		message.setProperty("PP_LOOP_EVALUATE", "yes" );
	}
}

class postProcessRemoveXpath implements PostProcessLoop {
	String value;
	String ppID;

	postProcessRemoveXpath(value,ppID) {
		this.value = value;
		this.ppID = ppID;
	}

	boolean prepareFirstLoop(Message message) {
		def props = message.getProperties();
		def xpath = XPathFactory.newInstance().newXPath()
		Document actualDocument = message.getBody(Document.class)
		if (actualDocument == null)
			throw new IllegalStateException("Unable to get Body as XML Document");
		Utils.removeWhitspace(actualDocument);
		def actualCount = xpath.evaluate("count(${this.value})",actualDocument, XPathConstants.NUMBER) as int;
		message.setProperty("PP_REMOVE_XPATH_COUNT", actualCount as String );
		if ( actualCount.intValue() > 0 ) {
			return true;
		}
		Utils.removeFirstPostProcessLoop(message);
		return false;
	}

	void prepareExecuteDetails(Message message) {
		message.setProperty("DYN_HTTP_URL", null);
	}

	void prepareNextLoop(Message message) {
		def props = message.getProperties();
		def xpath = XPathFactory.newInstance().newXPath()
		Document actualDocument = message.getBody(Document.class)
		if (actualDocument == null)
			throw new IllegalStateException("Unable to get Body as XML Document");
		Utils.removeWhitspace(actualDocument);
		def addLinkTo = [];
		NodeList nodeList = (NodeList)xpath.evaluate(this.value, actualDocument, XPathConstants.NODESET);
		for (int i = 0; i < nodeList.getLength(); i++) {
			Element element = (Element)nodeList.item(i);
			addLinkTo << element
		}
		addLinkTo.each {
			it.getParentNode().removeChild(it);
		}
		Utils.removeFirstPostProcessLoop(message);
		message.setBody(actualDocument);
		message.setProperty("PP_LOOP_EVALUATE", "yes" );
	}
}

class postProcessGetLinkRel implements PostProcessLoop {
	String value;
	String ppID;

	postProcessGetLinkRel(value,ppID) {
		this.value = value;
		this.ppID = ppID;
	}

	boolean prepareFirstLoop(Message message) {
		def props = message.getProperties();
		def xpath = XPathFactory.newInstance().newXPath()
		Document actualDocument = message.getBody(Document.class)
		if (actualDocument == null)
			throw new IllegalStateException("Unable to get Body as XML Document");
		Utils.removeWhitspace(actualDocument);
		def actualLinkCount = xpath.evaluate("count(${this.value})",actualDocument, XPathConstants.NUMBER) as int;
		message.setProperty("PP_GET_LINK_REL_COUNT", actualLinkCount as String );
		if ( actualLinkCount.intValue() > 0 ) {
			message.setProperty("PP_FULL_DOCUMENT", Utils.printSingleLineXml(actualDocument) );
			return true;
		}
		Utils.removeFirstPostProcessLoop(message);
		return false;
	}

	void prepareExecuteDetails(Message message) {
		def props = message.getProperties();
		def xpath = XPathFactory.newInstance().newXPath();
		Document fullDocument = Utils.parseXml(props.get("PP_FULL_DOCUMENT"));
		if (fullDocument == null) {
			throw new IllegalStateException("Unable to PP_FULL_DOCUMENT as XML Document");
		}
		NodeList nodeList = (NodeList)xpath.evaluate(this.value, fullDocument, XPathConstants.NODESET);
		Element element = (Element)nodeList.item(0);
		String href = element.getAttribute("href");
		String mimeType = element.hasAttribute("mime-type") ? element.getAttribute("mime-type") : "application/hal+xml";
		message.setProperty("DO_PP_GET_LINK_HREF", href );

		message.setProperty("DYN_HTTP_URL", href);
		message.setProperty("DYN_ACCEPT", mimeType );
		message.setProperty("DYN_HTTP_METHOD", "GET");
		if ("application/hal+xml".equals(mimeType))
			message.setProperty("DO_PP_GET_LINK_MIME_TYPE", null );
		else
			message.setProperty("DO_PP_GET_LINK_MIME_TYPE", mimeType.toLowerCase() );
	}

	void prepareNextLoop(Message message) {
		def props = message.getProperties();
		def headers = message.getHeaders();
		def xpath = XPathFactory.newInstance().newXPath();
		Document fullDocument = Utils.parseXml(props.get("PP_FULL_DOCUMENT"));
		if (fullDocument == null) {
			throw new IllegalStateException("Unable to PP_FULL_DOCUMENT as XML Document");
		}
		def injectElements = [];
		NodeList nodeList = (NodeList)xpath.evaluate(this.value, fullDocument, XPathConstants.NODESET);
		for (int i = 0; i < nodeList.getLength(); i++) {
			Element element = (Element)nodeList.item(i);
			if (element.getAttribute("href") == props.get("DO_PP_GET_LINK_HREF"))
				injectElements << element
		}
		String mimeType = props.get("DO_PP_GET_LINK_MIME_TYPE") ?: (headers.get("Content-Type") ?:"application/octet-stream").toLowerCase();
		if ("application/hal+xml".equals(mimeType)) {
			Document actualDocument = message.getBody(Document.class);
			if (actualDocument == null) {
				throw new IllegalStateException("Unable to get Body as XML Document");
			}
			Utils.removeWhitspace(actualDocument);
			def actualRoot = actualDocument.getDocumentElement();
			injectElements.each {
				it.setAttribute("cpi_pp",it.hasAttribute("cpi_pp") ? it.getAttribute("cpi_pp")+","+ppID : ppID);
				if (it.getAttribute("rel") != actualRoot.getAttribute("rel")) {
					if (it.hasAttribute("rel"))
						it.setAttribute("cpi_rel",it.hasAttribute("cpi_rel") ? it.getAttribute("cpi_rel")+","+it.getAttribute("rel") : it.getAttribute("rel"));
					it.setAttribute("rel",actualRoot.getAttribute("rel"));
				}
				Node child = actualRoot.getFirstChild();
				while (child != null) {
					if (child instanceof Element) {
						it.appendChild(fullDocument.importNode(child, true));
					}
					child = child.getNextSibling();
				}
				fullDocument.renameNode(it, actualRoot.getNamespaceURI(), actualRoot.getNodeName());
			}
		} else if ("application/xml".equals(mimeType)) {
			def body = message.getBody(String.class);
			injectElements.each {
				it.setAttribute("cpi_pp",it.hasAttribute("cpi_pp") ? it.getAttribute("cpi_pp")+","+ppID : ppID);
				it.appendChild(fullDocument.createCDATASection(body));
				fullDocument.renameNode(it, "", "resource");
			}
		} else {
			def base64Body = message.getBody(byte[].class).encodeBase64().toString();
			injectElements.each {
				it.setAttribute("cpi_pp",it.hasAttribute("cpi_pp") ? it.getAttribute("cpi_pp")+","+ppID : ppID);
				it.setTextContent(base64Body);
				fullDocument.renameNode(it, "", "resource");
			}
		}
		def fullLinkCount = xpath.evaluate("count(${this.value})",fullDocument, XPathConstants.NUMBER) as int;
		if ( fullLinkCount.intValue() > 0 ) {
			message.setProperty("PP_GET_LINK_REL_COUNT", fullLinkCount as String );
			message.setProperty("PP_FULL_DOCUMENT", Utils.printSingleLineXml(fullDocument) );
		} else {
			message.setProperty("PP_GET_LINK_REL_COUNT", null );
			message.setProperty("PP_FULL_DOCUMENT", null );
			Utils.removeFirstPostProcessLoop(message);
			message.setBody(fullDocument);
			//			message.setBody(Utils.printSingleLineXml(fullDocument,byte[].class));
			message.setProperty("PP_LOOP_EVALUATE", "yes" );
		}
	}
}