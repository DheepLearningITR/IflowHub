import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader);
    def json = new JsonSlurper().parse(body)
    message.setProperty('senderBpn',json.header.senderBpn)
    
    def method = "PUT"
    if("SENT" == json."content"."status"){
        method = "POST"
    }
    message.setHeader("CamelHttpMethod", method);
    
    def payloadJson = new JsonBuilder(json)
    message.setProperty("Notification_Payload",payloadJson.toPrettyString())
    
    return message;
}