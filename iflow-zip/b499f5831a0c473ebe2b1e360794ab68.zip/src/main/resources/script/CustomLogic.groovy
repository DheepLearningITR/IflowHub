/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message
import java.util.Date
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.HashMap
import groovy.xml.XmlUtil
import groovy.util.XmlParser
import com.sap.it.api.mapping.*
import com.sap.it.api.securestore.*
import com.sap.it.api.ITApiFactory
import java.util.HashMap;


def Message formatCompanyTerritoryCode(Message message){
//This script is to add single quotes to each of the company codes

   def pMap = message.getProperties()
    def companyTerritoryCode = pMap.get("CompanyTerritoryCode")
    if(!(companyTerritoryCode.trim().isEmpty())){
        //Split the multiple company codes inputted from the exernal parameter
        def ids = companyTerritoryCode.split(',')
        def formattedIDs = ""
        //Add single quotes
        for (int i = 0; i < ids.size(); i++){
            formattedIDs = formattedIDs + "'" + ids[i] + "'" + ","
        }
        
        formattedCompanyTerritoryCodes =  formattedIDs.reverse().drop(1).reverse()
    }
    else{
        def exceptionBody = "Please maintain value for CompanyTerritoryCode"
        throw new Exception(exceptionBody)
    }
    message.setProperty("formattedCompanyTerritoryCodes", formattedCompanyTerritoryCodes)
    return message
}


def Message concatPayload(Message message) 
{
    //This script merges payload fetched on every loop execution  
    
    map = message.getProperties();
    def  value = map.get("ConcatPayload")
    String mergePayload = '';
    String str1 = message.getBody(String.class)
	if (value != null)
	{
    	mergePayload = value + str1;
	}
	else
	{ 
	   mergePayload = str1;
	    
	}
	
    message.setProperty("ConcatPayload", mergePayload);
   	return message;
}


def Message querybuilt(Message message) {
  
    def pmap = message.getProperties();
	def messageLog = messageLogFactory.getMessageLog(message);
	
	String lastModifiedDate = pmap.get("LAST_MODIFIED_DATE");
	//String adhocRun = pmap.get("ADHOC_RUN");
	String paramlastModifiedDate = pmap.get("LAST_MODIFIED_DATE_PARAM");
	String formattedCompanyTerritoryCodes = pmap.get("formattedCompanyTerritoryCodes")
	
  	  if(!(paramlastModifiedDate.equals("")))
  		{
  		     		queryLastModifiedDate = "last_modified_on > to_datetime('" + paramlastModifiedDate +"')";
  			        lastModifiedDate = paramlastModifiedDate;
  		}
  	else
  		{
  		             queryLastModifiedDate = "last_modified_on > to_datetime('" + lastModifiedDate.replaceAll(".000Z","Z") +"')";
  		}
    //Effective End Date
  	effective_end_date = new Date().format("YYYY-MM-dd");
  	
  	// CountryCode Filter
    CountryCode = " and company_territory_code IN (" + formattedCompanyTerritoryCodes + ")"
  	message.setProperty("CountryCode", CountryCode);
  	
  	//Delta parameter
  	parameter = "queryMode=Delta;resultOptions=renderPreviousTags"
  	message.setProperty("parameter", parameter);
  	
  	//Set EFFECTIVE_END_DATE_PARAMETER
    queryEffectiveEndDate = " AND fromDate=to_date('" + lastModifiedDate.substring(0,10) + "','YYYY-MM-DD') AND toDate=to_date('"+ effective_end_date + "','YYYY-MM-DD')";
  		message.setProperty("EFFECTIVE_END_DATE_PARAMETER", queryEffectiveEndDate);
  		if(messageLog != null)
  		{
  			messageLog.setStringProperty("EFFECTIVE_END_DATE_PARAMETER ", queryEffectiveEndDate);
  		}
    
  	//Set LAST_MODIFIED_DATE_PARAMETER	
	message.setProperty("QUERY_LAST_MODIFIED_DATE", queryLastModifiedDate);
	if(messageLog != null)
	{
		messageLog.setStringProperty("QUERY_LAST_MODIFIED_DATE", queryLastModifiedDate);
	}
  	
  return message;
}


def Message storeComapny(Message message){
    
    //This script is to fetch the names of the currency  from EC and store them in HashMaps
    
    //message Body
    def records = message.getBody(java.io.Reader);
    
    // Define XML parser for records
    def xmlRecords = new XmlParser().parse(records);
    
    //Add values in currency HashMap
    def company = [:];
    xmlRecords.each { p -> company.put(p.externalCode[0].text().toString(),(p.currency[0].text().toString()))};
    
    //Add values in name HashMap
     def companyname = [:];
    xmlRecords.each { p -> companyname.put(p.externalCode[0].text().toString(),(p.name[0].text().toString()))};
    
    //Store the currency HashMap as a property
    message.setProperty("company", company);
    message.setProperty("companyname", companyname);
  
    
    return message;
}

def Message storeCostcenter(Message message){
    
    //This script is to fetch the names of the CostcenterId from EC and store them in HashMaps
    
    //message Body
    def records = message.getBody(java.io.Reader);
    
    // Define XML parser for records
    def xmlRecords = new XmlParser().parse(records);
    
    //Add values in CostcenterId HashMap
    def costcenter = [:];
    xmlRecords.each { p -> costcenter.put(p.externalCode[0].text().toString(),(p.costcenterExternalObjectID[0].text().toString()))};
    
    //Store the CostcenterId HashMap as a property
    message.setProperty("costcenter", costcenter);
  
    
    return message;
}

def Message storeCountryCodes(Message message){
    
    //This script is to store the 2 character country codes in a HashMap
    
    //message Body
    def records = message.getBody(java.io.Reader);
    
    // Define XML parser for records
    def xmlRecords = new XmlParser().parse(records);
    
    //Add values in countryCodes HashMap
    def countryCodes = [:]
    xmlRecords.each { p -> countryCodes.put(p.code[0].text().toString(),(p.twoCharCountryCode[0].text().toString()))}
    
    //Store the locations HashMap as a property
    message.setProperty("countryCodes", countryCodes)
    
    return message
}

def Message storeDivision(Message message){
    
    //This script is to fetch the names of the head of unit  from EC and store them in HashMaps
    
    //message Body
    def records = message.getBody(java.io.Reader);
    
    // Define XML parser for records
    def xmlRecords = new XmlParser().parse(records);
    
    //Add values in curency HashMap
    def division = [:];  
    def divisionDescription = [:] ;
    
    xmlRecords.each { p -> 
    divisionDescription.put(p.externalCode[0].text().toString(),(p.name_defaultValue[0].text().toString()))};
    
    xmlRecords.each { p -> 
    //division.put(p.externalCode[0].text().toString(),(p.headOfUnitNav.User.userId[0].text().toString()))};
    
    if(p.headOfUnitNav.User.userId[0] != null)
     
    {division.put(p.externalCode[0].text().toString(),(p.headOfUnitNav.User.userId[0].text().toString()))};
    
    else
    
    {division.put(p.externalCode[0].text().toString(),("Head of unit is not mapped to OME -"+p.externalCode[0].text()))};
    
    }
    //Store the head of unit HashMap as a property
    message.setProperty("division", division);
    message.setProperty("divisionDescription", divisionDescription);
    
    return message;
}



def Message storeLocations(Message message){
    
    //This script is to fetch the address names of the location from EC and store them in a HashMap
    
    //message Body
    def records = message.getBody(java.io.Reader);
    
    // Define XML parser for records
    def xmlRecords = new XmlParser().parse(records);
    
    //Add values in locations HashMap
    def locations = [:]
    xmlRecords.each { p 
    -> locations.put(p.externalCode[0].text().toString(),
                    (p.addressNavDEFLT.FOCorporateAddressDEFLT.address1[0].text().toString() + '' 
                     +  p.addressNavDEFLT.FOCorporateAddressDEFLT.address2[0].text().toString()))}
    
    //Add values in locationscity HashMap
         def locationscity = [:]
    xmlRecords.each { p 
    -> locationscity.put(p.externalCode[0].text().toString(),
    (p.addressNavDEFLT.FOCorporateAddressDEFLT.city[0].text().toString()))}
    
    //Add values in locationsstate HashMap
      def locationsstate = [:]
    xmlRecords.each { p 
    -> locationsstate.put(p.externalCode[0].text().toString(),
       (p.addressNavDEFLT.FOCorporateAddressDEFLT.state[0].text().toString()))}
      //Add values in locationszipcode HashMap
    def locationszipcode = [:]
    xmlRecords.each { p 
    -> locationszipcode.put(p.externalCode[0].text().toString(),
    (p.addressNavDEFLT.FOCorporateAddressDEFLT.zipCode[0].text().toString()))}
    //Add values in locationscountry HashMap
     def locationscountry = [:]
    xmlRecords.each { p 
    -> locationscountry.put(p.externalCode[0].text().toString(),
    (p.addressNavDEFLT.FOCorporateAddressDEFLT.country[0].text().toString()))} 
   
    
    //Store the locations HashMap as a property
    message.setProperty("locations", locations)
    
     //Store the locationscity HashMap as a property
    message.setProperty("locationscity", locationscity)
     //Store the locationsstate HashMap as a property
    message.setProperty("locationsstate", locationsstate)
     //Store the locationszipcode HashMap as a property
    message.setProperty("locationszipcode", locationszipcode)
     //Store the locationscountry HashMap as a property
    message.setProperty("locationscountry", locationscountry)
    return message
}

def Message replaceCodes(Message message){
    
    //This script is to replace location,city,state,contry,zipcode codes with the names from the HashMaps
    
    //message Body
    def records = message.getBody(java.io.Reader);
    
    def map = message.getProperties()
    String locationAdress,locationCity,locationsState,locationsZipcode,locationsCountry,companyCode,divisionCode,divisionName,costcenterExternalId,companyDescription,twocharCountry
  /* String WorkStreetAddress ="";
   String WorkCity ="";
   String WorkState ="";
   String WorkPostalCode ="";
   String WorkCountry ="";
   String Reimbursement_CRN_Code ="";*/
    
    def company = map.get("company")
    def division = map.get("division")
    def divisiondesription = map.get("divisionDescription")
    def locations = map.get("locations")
    def locationscity = map.get("locationscity")
    def locationscountry = map.get("locationscountry")
    def locationsstate = map.get("locationsstate")
    def locationszipcode = map.get("locationszipcode")
   // def costcenter = map.get("costcenter")
    def companyname = map.get("companyname")
    def countryCodes =  map.get("countryCodes")
   
    // Define XML parser for records
    def xmlRecords = new XmlParser().parse(records);
    
    xmlRecords.each
	{   
	    it ->
	    if(it.WorkStreetAddress[0]!= null){
	        locationAdress = locations.get(it.WorkStreetAddress[0].text())
	        it.appendNode("WorkStreetAddress",[:], locationAdress)
	    }
	    if(it.WorkCity[0] != null){
	        locationCity = locationscity.get(it.WorkCity[0].text())
	        it.appendNode("WorkCity",[:], locationCity)
	    }
	    if(it.WorkState[0] != null){
	        locationsState = locationsstate.get(it.WorkState[0].text())
	        it.appendNode("WorkState",[:], locationsState)
	    }
	    if(it.WorkPostalCode[0] != null){
	        locationsZipcode = locationszipcode.get(it.WorkPostalCode[0].text())
	        it.appendNode("WorkPostalCode",[:], locationsZipcode)
	    }
	     /*if(it.WorkCountry[0] != null){
	        locationsCountry = locationscountry.get(it.WorkCountry[0].text())
	        it.appendNode("WorkCountry",[:], locationsCountry)
	    }*/
	     if(it.Reimbursement_CRN_Code[0] != null){
	        companyCode = company.get(it.Reimbursement_CRN_Code[0].text())
	        it.appendNode("Reimbursement_CRN_Code",[:], companyCode)
	    }
	    
	    if(it.Request_Approver_Employee_ID_2[0] != null){
	        divisionCode = division.get(it.Request_Approver_Employee_ID_2[0].text())
	        it.appendNode("Request_Approver_Employee_ID_2",[:], divisionCode)
	    }
	    if(it.OrgUnitDivision[0] != null){
	        divisionName = divisiondesription.get(it.OrgUnitDivision[0].text())
	        it.appendNode("OrgUnitDivision",[:], divisionName)
	    }
	   /* if(it.Org_Unit_5[0] != null){
	        costcenterExternalId = costcenter.get(it.Org_Unit_5[0].text())
	        it.appendNode("Org_Unit_5",[:], costcenterExternalId)
	    }*/
	    
	    if(it.OrgUnitDivision[0] != null){
	        companyDescription = companyname.get(it.OrgUnitDivision[0].text())
	        it.appendNode("OrgUnitDivision",[:], companyDescription)
	    }
	    
	       if(it.WorkCountry[0] != null){
	        twocharCountry = countryCodes.get(it.WorkCountry[0].text())
	        it.appendNode("WorkCountry",[:], twocharCountry)
	    }
	    
	     if(it.Custom_21[0] != null){
	        twocharCountry = countryCodes.get(it.Custom_21[0].text())
	        it.appendNode("Custom_21",[:], twocharCountry)
	    }
	    
	     if(it.Org_Unit_2[0] != null){
	        twocharCountry = countryCodes.get(it.Org_Unit_2[0].text())
	        it.appendNode("Org_Unit_2",[:], twocharCountry)
	    }
	    
	     if(it.Ctry_Code[0] != null){
	        twocharCountry = countryCodes.get(it.Ctry_Code[0].text())
	        it.appendNode("Ctry_Code",[:], twocharCountry)
	    }
	    
	    
	}
	message.setBody(XmlUtil.serialize(xmlRecords))
	return message
}


def String getProperties(String propertyname, MappingContext context) {
    
    //get property
    def String propValue = context.getProperty(propertyname);
    return propValue;
    
}

    
def String replaceCodes(int index, String value, MappingContext context)
{
    
    //This script is to replace the codes with the names from the HashMaps
    switch(index)
    {
        case 1:
            String costcenterExternalId
            def costcenter = context.getProperty("costcenter")
            costcenterExternalId = costcenter.get(value)
            return costcenterExternalId
            
            default:
            return "null"
            
    }
}

//This script is to filter GA Records     
    
def Message filteringGAEmployees(Message message) {
    def body = message.getBody(java.lang.String);
    def list = new XmlSlurper().parseText(body);

     def personcount = list.CompoundEmployee.person.size()
     
     for(int j=0; j<=personcount-1; j++)
     {
    def loopVariablelimit = list.CompoundEmployee.person[j].employment_information.size()
    if(loopVariablelimit>=2)
   {
       for(int i=0; i<=loopVariablelimit-1; i++)
   {
    def es = list.CompoundEmployee.person[j].employment_information[i].job_information[0].emplStatus.text();
    if(es != 'A')
   {
     list.CompoundEmployee.person[j].employment_information[i].replaceNode{}
    }
   }
   }
     }
   message.setBody(XmlUtil.serialize(list));
       return message;
}
    