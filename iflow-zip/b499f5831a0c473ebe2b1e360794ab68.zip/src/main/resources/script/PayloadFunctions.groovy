/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date

def Message processCompletedMessage(Message message) {
    // For setting up custom headers with success message and Filename
    
    def messageLog = messageLogFactory.getMessageLog(message)
	def map = message.getProperties()
	def fname = map.get("FileName")
	def totalEmpCount = map.get("TotalEmpCount")
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssz",Locale.ENGLISH)
	sdf.setTimeZone(TimeZone.getTimeZone("GMT"))
	String date = sdf.format(new Date()).replace("GMT","Z")
	message.setProperty("ProcessCompleted","Process Completed")
	message.setProperty("eventTime",date)
	String summary = "Total No. of Employees: "+totalEmpCount
	messageLog.addCustomHeaderProperty("Summary Report",summary)
	messageLog.addCustomHeaderProperty("Status","Success")
	messageLog.addCustomHeaderProperty("SuccessMsg", "File posted successfully to Concur")
	messageLog.addCustomHeaderProperty("FileName", fname)
	return message
}

def Message processErrorMessage(Message message) {  
    //For EMEvent type FAILED
    
	def msg = message.getProperties().get("CamelExceptionCaught").getMessage().toString() //Extract exception message
	def messageLog = messageLogFactory.getMessageLog(message)
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssz",Locale.ENGLISH)
	sdf.setTimeZone(TimeZone.getTimeZone("GMT"))
	String date = sdf.format(new Date()).replace("GMT","Z")
	message.setProperty("exceptionMessage",msg)   //store exception message as a property
	messageLog.addCustomHeaderProperty("ErrorMsg",msg)
	messageLog.addCustomHeaderProperty("Status","Error")
	message.setProperty("eventTime",date)
	
	return message
}

def Message logEmptyFileMessage(Message message)
{   //When record count is 0
	def messageLog = messageLogFactory.getMessageLog(message)

	//Add below custom header logs on monitor
	messageLog.addCustomHeaderProperty("Msg", "No records were changed since last run")
	
	return message;
}

def Message logSFPayload(Message message) {
    
	def body = message.getBody(java.lang.String) as String    
    def map = message.getProperties()
	def isLogEnabled=map.get("enableLogging")
	def logConfig = map.get("SAP_MessageProcessingLogConfiguration")
	def logLevel = (String) logConfig.logLevel
	
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
        // Only log when LogLevel of iFlow == Debug || Trace
        if(((logLevel.equals("DEBUG") || logLevel.equals("TRACE")) && ( isLogEnabled .equalsIgnoreCase("Y")))) {
            //def formattedData = XmlUtil.serialize(body) 
            messageLog.addAttachmentAsString("Step 1: Input from SF EC", body, "text/xml")
        } 
    }
    
    return message
}

def Message logcsvPayload(Message message) {
    
	def body = message.getBody(java.lang.String) as String    
    def map = message.getProperties()
	def isLogEnabled=map.get("enableLogging")
	def logConfig = map.get("SAP_MessageProcessingLogConfiguration")
	def logLevel = (String) logConfig.logLevel
	
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
        // Only log when LogLevel of iFlow == Debug || Trace
        if(((logLevel.equals("DEBUG") || logLevel.equals("TRACE") || logLevel.equals("INFO")) && ( isLogEnabled .equalsIgnoreCase("Y")))) {
            //def formattedData = XmlUtil.serialize(body) 
            messageLog.addAttachmentAsString("Step 2: Output CSV File ", body, "text/xml")
        } 
    }
    
    return message
}

def Message logCSVPayloadtoConcur(Message message) {
    
	def body = message.getBody(java.lang.String) as String    
    def map = message.getProperties()
	def isLogEnabled=map.get("enableLogging")
	def logConfig = map.get("SAP_MessageProcessingLogConfiguration")
	def logLevel = (String) logConfig.logLevel
	
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
        // Only log when LogLevel of iFlow == Debug || Trace
        if(((logLevel.equals("DEBUG") || logLevel.equals("TRACE")) && ( isLogEnabled .equalsIgnoreCase("Y")))) {
            //def formattedData = XmlUtil.serialize(body) 
            messageLog.addAttachmentAsString("Step 2: Output CSV File to Concur ", body, "text/xml")
        } 
    }
    
    return message
}


def Message csvPayload(Message message) {
    
	def body = message.getBody(java.lang.String) as String    
    def map = message.getProperties()
	def isLogEnabled=map.get("enableLogging")
	def logConfig = map.get("SAP_MessageProcessingLogConfiguration")
	def logLevel = (String) logConfig.logLevel
	
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
        // Only log when LogLevel of iFlow == Debug || Trace
        if(((logLevel.equals("DEBUG") || logLevel.equals("TRACE")) && ( isLogEnabled .equalsIgnoreCase("Y")))) {
            //def formattedData = XmlUtil.serialize(body) 
            messageLog.addAttachmentAsString("Step 3: Successful EmployeeID csv ", body, "text/xml")
        } 
    }
    
    return message
}