import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

 
def Message processData(Message message) {
    
    def map = message.getProperties();
    def ex = map.get("CamelExceptionCaught");
    
    if (ex!=null){
        
        if (ex instanceof org.apache.cxf.interceptor.Fault) {
            message.getProperties().put("faultCode", ex.getFaultCode());
        }
        if (ex.getCause() instanceof org.apache.cxf.transport.http.HTTPException){
            message.getProperties().put("detail", ex.getCause().getMessage());
            message.getProperties().put("statusCode", ex.getCause().getResponseCode());
        }    
    }
return message;

}