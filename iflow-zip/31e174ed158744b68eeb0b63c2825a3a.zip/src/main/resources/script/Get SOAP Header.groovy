import com.sap.gateway.ip.core.customdev.util.Message;
import javax.xml.namespace.QName;
import com.sap.gateway.ip.core.customdev.util.SoapHeader;
import javax.xml.datatype.*;
import java.security.*;
import java.time.Instant;
import java.util.Base64;
import javax.xml.soap.*;
import java.text.SimpleDateFormat;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.UUID; 
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
 
    def Message processData(Message message) {
        
        def username  = message.getHeaders();
        def uservalue = username.get("CredentialName");
        userValue = uservalue.toString();
        def service = ITApiFactory.getApi(SecureStoreService.class, null);
        def credential = service.getUserCredential(userValue);
        def apikey = credential.getPassword().toString();
        if (credential == null)
        {
            throw new IllegalStateException("No credential found for alias ");
            
        }

        def userName = new StringBuffer(credential.getUsername());

        def headers = new ArrayList();
        
        def xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><wsse:Security xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"><wsse:UsernameToken wsu:Id=\"UserNameTokenValue/\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\"><wsse:Username>userNameValue</wsse:Username><wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\">passwordValue</wsse:Password><wsse:Nonce EncodingType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary\">nonceValue</wsse:Nonce><wsu:Created>createdTimeStamp</wsu:Created></wsse:UsernameToken></wsse:Security>";
        
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        def created = null;
        synchronized(dateFormatter){ 
        created = dateFormatter.format(new Date());
        }
        def userNameTokenValue = "UsernameToken-"+UUID.randomUUID().toString().replaceAll("-", "");
        SecureRandom rand = new SecureRandom();
        StringBuffer wsseHeader = new StringBuffer();
        ByteArrayOutputStream digest = new ByteArrayOutputStream(40);
        byte[] nonce = new byte[20];
        rand.nextBytes(nonce);
        try {
        digest.write(nonce);    
        digest.write(created.getBytes());
        } catch(IOException e) {
        throw new IllegalStateException("No authorized NONCE value generated"); 
        } 
        def xmlWithUserNameToken = xml.replace("UserNameTokenValue/", userNameTokenValue);
        def xmlWithNonce = xmlWithUserNameToken.replace("nonceValue",Base64.getEncoder().encodeToString(nonce));
        def xmlWithTimestamp = xmlWithNonce.replace("createdTimeStamp", created);
        def xmlWithUserName = xmlWithTimestamp.replace("userNameValue", userName);
        def xmlWithKey = xmlWithUserName.replace("passwordValue", apikey);
        
       def header = new SoapHeader(new QName("http://DataCollectionLibrary/org/unjspf/ws/datacollection/Hr", "wsse:security"),  xmlWithKey, true, "");
       headers.add(header);
       message.setSoapHeaders(headers);
       apikey = null;
       xmlWithKey = null;
       return message;
    }    

