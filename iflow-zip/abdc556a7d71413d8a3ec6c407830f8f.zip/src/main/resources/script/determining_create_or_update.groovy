import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message){
    def cns_body = new JsonSlurper().parse(message.getBody(java.io.Reader))
    def xmlRoot =new XmlSlurper().parseText(message.getProperty("mappedPayload") as String)
    
    if(cns_body.value.size() > 0){
        //case of update
        xmlRoot.messageRequests.messageHeader.actionCode.replaceBody('SAVE')
        xmlRoot.messageRequests.body.receiverDisplayId.replaceBody(cns_body.value[0].displayId)
        
    }
    message.setProperty("mappedPayload",groovy.xml.XmlUtil.serialize(xmlRoot))
    return message
}