import com.sap.gateway.ip.core.customdev.util.Message

def String mapCreditStatus(String s4_creditStatus){
    switch(s4_creditStatus){
        case "A":
            return "CREDIT_CHECK_PENDING_FOR_ALL_RELEVANT_ITEMS"
        case "B":
            return "CREDIT_CHECK_OK_FOR_ALL_RELEVANT_ITEMS"
        case "C":
            return "CREDIT_CHECK_NOT_OK_FOR_ALL_RELEVANT_ITEMS"
        case "D":
            return "CREDIT_CHECK_NOT_OK_FOR_SOME_ITEMS"
        case "E":
            return "CREDIT_CHECK_OK_FOR_SOME_ITEMS_AND_PENDING_FOR_SOME_ITEMS"
        default:
            return "NO_ITEM_IS_RELEVANT_FOR_CREDIT_CHECK"
    }
}

def String mapItemCreditStatus(String s4_creditStatus){
    switch(s4_creditStatus){
        default:
            return "NOT_RELEVANT_FOR_CREDIT_CHECK"
        case "A":
            return "RELEVANT_FOR_CREDIT_CHECK_BUT_CREDIT_CHECK_NOT_EXECUTED"
        case "B":
            return "CREDIT_CHECK_OK"
        case "C":
            return "CREDIT_CHECK_NOT_OK"
        case "D":
            return "CREDIT_RELEASED"
    }
}

def void mappingItems(Node xmlBodyNode, def s4_body){
    def item
    def itemBuilder
    def lifeCycleStatus
    def s4_creditStatus
    def s4_requestedStartOn
    def s4_requestedEndOn
    def s4_plannedFrom
    def s4_plannedTo
    def s4_serviceDueByDateTime
    def equipment
    def isRejected_cns = false
    s4_body.Item.each{
        //extracting data
        item = it
        s4_requestedStartOn = item.RequestedServiceStartDateTime.text() ? item.RequestedServiceStartDateTime.text()+"Z" : null 
        s4_requestedEndOn = item.RequestedServiceEndDateTime.text() ? item.RequestedServiceEndDateTime.text()+"Z" : null
        s4_plannedFrom = item.PlannedServiceStartDateTime.text() ? item.PlannedServiceStartDateTime.text()+"Z" : null
        s4_plannedTo = item.PlannedServiceEndDateTime.text() ? item.PlannedServiceEndDateTime.text()+"Z" : null
        s4_serviceDueByDateTime = item.ServiceDueByDateTime.text() ? item.ServiceDueByDateTime.text()+"Z" : null
        
        //LifeCycle status determination 
        if(item.ServiceOrderItemIsCompleted.text()=="true"){
            lifeCycleStatus = "COMPLETED"
        }else if(item.ServiceOrderItemIsReleased.text()=="true"){
            lifeCycleStatus = "RELEASED"
        }else if(item.ServiceOrderItemIsRejected.text()=="true"){
            lifeCycleStatus = "COMPLETED"
            isRejected_cns = true
        }
        
        s4_creditStatus = mapItemCreditStatus(item.SrvcOrdItemCreditStatus.text())
        // Item header builder
        itemBuilder = new NodeBuilder().items{
            receiverLineNumber(item.ReferenceServiceOrderItem.text())
            id(item.ServiceOrderItem.text())
            parentId(item.ParentServiceOrderItem.text())
            description(item.ServiceOrderItemDescription.text())
            itemCategory(item.ServiceOrderItemCategory.text())
            itemStatus(item.ServiceOrderItemUserStatus.text())
            itemLifeCycleStatus(lifeCycleStatus)
            isRejected(isRejected_cns)
            rejectionCode(item.ServiceOrdItemRejectionReason.text())
            creditStatus(s4_creditStatus)
        }
        
        //item time points builder 
        def itemTimePointsBuilder = new NodeBuilder().timePoints{
            requestedStartOn(s4_requestedStartOn)
            requestedEndOn(s4_requestedEndOn)
            plannedFrom(s4_plannedFrom)
            plannedTo(s4_plannedTo)
            serviceDue(s4_serviceDueByDateTime)
        }
        itemBuilder.append(itemTimePointsBuilder)
        
        //Adding quantity field if it exists
        if(item.Quantity){
            def tempBuilder = new NodeBuilder().quantity{
                content(item.Quantity.text())
                uomCode(item.Quantity.@unitCode[0])
            }
            itemBuilder.append(tempBuilder)
        }
        
        //Adding service duration field if it exists
        if(item.ServiceDuration){
            def tempBuilder = new NodeBuilder().serviceDuration{
                content(item.ServiceDuration.text())
                uomCode(item.ServiceDuration.@unitCode[0])
            }
            itemBuilder.append(tempBuilder)
        }
        
        //Adding product information
        def tempBuilder = new NodeBuilder().product{
            displayId(item.Material.text())
        }
        itemBuilder.append(tempBuilder)
        
        //Adding registered product
        item.ServiceReferenceObject.each{
            equipment = it.ServiceReferenceEquipment.text()
            if(it.SrvcRefObjIsMainObject.text() == "true"){
                tempBuilder = new NodeBuilder().registeredProduct{
                    displayId(equipment)
                }
                itemBuilder.append(tempBuilder)
            }
        }
        
        //Adding item price amounts
        def tempItemTotalValuesBuilder = new NodeBuilder().totalValues{
            grossAmount{ 
                content(item.ServiceDocItemGrossAmount.text())
                currencyCode(item.ServiceDocItemGrossAmount.@currencyCode[0])
            }
            netAmount{
                content(item.ServiceDocumentItemNetAmount.text())
                currencyCode(item.ServiceDocumentItemNetAmount.@currencyCode[0])
            }
            taxAmount{
                content(item.ServiceDocumentItemTaxAmount.text())
                currencyCode(item.ServiceDocumentItemTaxAmount.@currencyCode[0])
            }
        }
        itemBuilder.append(tempItemTotalValuesBuilder)

        //Adding item in header node
        xmlBodyNode.append(itemBuilder)
    }
    
}


def void mappingRegisteredProducts(Node xmlBodyNode, def s4_body){
    def regProduct
    def xmlIndRegProductBuilder 
    s4_body.ServiceReferenceObject.each{
        regProduct = it.ServiceReferenceEquipment
        if(regProduct){
           
            xmlIndRegProductBuilder = new NodeBuilder().registeredProduct{
                displayId(regProduct.text())
            }
            xmlBodyNode.append(xmlIndRegProductBuilder)
        }
    }
}

def String getLifeCycleStatus(def s4_body){
    if(s4_body.ServiceOrderStatus.ServiceOrderIsCompleted.text()=="true"){
        return "COMPLETED"
    }else if(s4_body.ServiceOrderStatus.ServiceOrderIsReleased.text()=="true"){
        return "RELEASED"
    }else if(s4_body.ServiceOrderStatus.ServiceOrderIsRejected.text()=="true"){
        return "COMPLETED"
    }else{
        return ""
    }
}

def void collectingInvolvedParties(Message message, String useEnterpriseOrg, Node xmlBodyNode, def s4_body){
    def xmlInvPartyBuilder
    def involvedParties = [:]
    def businessPartnerExists= false
    if(s4_body.Partners){
        if(s4_body.Partners.SoldToParty.text()){
            businessPartnerExists = true
            involvedParties.put("SoldToParty",s4_body.Partners.SoldToParty.text())
        }
        if(s4_body.Partners.ShipToParty.text()){
            businessPartnerExists = true
            involvedParties.put("ShipToParty",s4_body.Partners.ShipToParty.text())
        }
        if(s4_body.Partners.BillToParty.text()){
            businessPartnerExists = true
            involvedParties.put("BillToParty",s4_body.Partners.BillToParty.text())
        }
        if(s4_body.Partners.PayerParty.text()){
            businessPartnerExists = true
            involvedParties.put("PayerParty",s4_body.Partners.PayerParty.text())
        }
        if(s4_body.Partners.ContactPerson.text()){
            xmlInvPartyBuilder = new NodeBuilder().contact{
                displayId(s4_body.Partners.ContactPerson.text())
            }
            xmlBodyNode.append(xmlInvPartyBuilder)
        }
        if(s4_body.Partners.PersonResponsible.PersonResponsible.text()){
            xmlInvPartyBuilder = new NodeBuilder().owner{
                displayId(s4_body.Partners.PersonResponsible.PersonResponsible.text())
            }
            xmlBodyNode.append(xmlInvPartyBuilder)
        }
    }
    
    if("true".equals(useEnterpriseOrg)){
        if(s4_body.ServiceOrgUnit.EnterpriseServiceOrganization){
            xmlInvPartyBuilder = new NodeBuilder().serviceOrganisation{
                displayId(s4_body.ServiceOrgUnit.EnterpriseServiceOrganization.text())
            }
            xmlBodyNode.append(xmlInvPartyBuilder)
        }
    }else {
        if(s4_body.ServiceOrgUnit.ServiceOrganization){
            xmlInvPartyBuilder = new NodeBuilder().serviceOrganisation{
                displayId(s4_body.ServiceOrgUnit.ServiceOrganization.text())
            }
            xmlBodyNode.append(xmlInvPartyBuilder)
        }
    } 
    
    message.setProperty("businessPartnerExists",businessPartnerExists)
    message.setProperty("involvedParties",involvedParties)
}

def void mappingTransactionHistory(Node xmlBodyNode, def s4_body){
    def xmlTransactionHistory
    def Tid = null 
    def Ttype = null
    s4_body.TransactionHistory.each{
        Tid = it.BusinessTransactionDocument.text()
        Ttype = it.BusTransDocumentIsPredecessor.text() == 'true' ? "PREDECESSOR" : "SUCCESSOR"
        if(it.BusinessObjectType.text() == 'BUS2000116'){
            
            xmlTransactionHistory = new NodeBuilder().externalTransactionReference{
                type("SERVICE_QUOTATION")
                displayId(Tid)
                role(Ttype)
            }
            xmlBodyNode.append(xmlTransactionHistory)
        }
    }
}

def Message processData(Message message){
    //extracting data from s4 body
    def s4_body = new XmlParser().parseText(message.getBody(String.class))
    def header_body = s4_body.MessageHeader
    //Important for troubleshooting messages
    message.setHeader("SAP_ApplicationID", header_body.ID.text())
    s4_body = s4_body.ServiceOrder
    def cns_displayId = s4_body.ReferenceServiceOrder.text()? s4_body.ReferenceServiceOrder.text().split("#")[1] : ''
    def date = new Date()
    def s4_lifeCycleStatus = getLifeCycleStatus(s4_body)
    def s4_isRejected = s4_body.ServiceOrderStatus.ServiceOrderIsRejected.text()=="true" ? true: false
    def cns_actionCode
    def sapClient = message.getProperty("sap-client")
    if(cns_displayId){
        cns_actionCode = "SAVE"
    }else{
        cns_actionCode = "CREATE"
        if(s4_lifeCycleStatus == ''){
            s4_lifeCycleStatus = "IN_PROCESS"
        }
    }
    def s4_creditStatus = mapCreditStatus(s4_body.SrvcOrdCreditStatus.text())
    def s4_receiverDisplayId = header_body.ReceiverBusinessSystemID ? header_body.ReceiverBusinessSystemID.text() : message.getProperty("receiverDisplayId")
    
    //building cns xml header data
    def xmlHeaderNode = new NodeBuilder().messageHeader{
        id(java.util.UUID.randomUUID())
        senderCommunicationSystemDisplayId(header_body.SenderBusinessSystemID.text())
        receiverCommunicationSystemDisplayId(s4_receiverDisplayId)
        creationDateTime(date.format("yyyy-MM-dd'T'HH:mm:ss'Z'"))
    }
    
    //building cns xml body header data
    def xmlBodyHeaderNode = new NodeBuilder().messageHeader{
        messageEntityName("sap.crm.serviceorderservice.entity.serviceOrderReplicationMessageIn")
        actionCode(cns_actionCode)
        id(java.util.UUID.randomUUID())
    }
    
    //building cns xml body data
    Node xmlBodyNode = new NodeBuilder().body{
        isMainExternalIntegration(true)
        displayId(s4_body.ServiceOrder.text())
        receiverDisplayId(cns_displayId)
        description(s4_body.ServiceOrderDescription.text())
        lifeCycleStatus(s4_lifeCycleStatus)
        isRejected(s4_isRejected)
        FSMServiceCall(s4_body.FSMServiceCall.text())
        creditStatus(s4_creditStatus)
        rejectionCode(s4_body.ServiceOrderRejectionReason.text())
        //userStatus(s4_body.ServiceOrderUserStatus.text())
        priority(s4_body.ServiceDocumentPriority.text())
        serviceOrderType(s4_body.ServiceOrderType.text())
    }
    
    if(s4_body.ServiceOrderUserStatus.text()){
        def xmlUserStatusNode = new NodeBuilder().userStatus(s4_body.ServiceOrderUserStatus.text())
        xmlBodyNode.append(xmlUserStatusNode)
    }
    
    //building business area body node
    final String useEnterpriseOrg = message.getProperty("useEnterpriseOrg")?.toLowerCase()
    if("true".equals(useEnterpriseOrg)){
        
       if(s4_body.OrgUnit){
            def xmlBusinessAreaNode = new NodeBuilder().businessArea{
                salesOrganisationId(s4_body.OrgUnit.SalesOrganization.text())
                distributionChannel(s4_body.OrgUnit.DistributionChannel.text())
                division(s4_body.OrgUnit.Division.text())
                salesGroupId(s4_body.OrgUnit.SalesGroup.text())
                salesOfficeId(s4_body.OrgUnit.SalesOffice.text())
            }
            xmlBodyNode.append(xmlBusinessAreaNode)
        } 
    } else {
        if(s4_body.SalesAreaInService){
            def xmlBusinessAreaNode = new NodeBuilder().businessArea{
                salesOrganisationCenterId(s4_body.SalesAreaInService.SalesOrganizationOrgUnitID.text())
                distributionChannel(s4_body.SalesAreaInService.DistributionChannel.text())
                division(s4_body.SalesAreaInService.Division.text())
                salesGroupOrganisationCenterId(s4_body.SalesAreaInService.SalesGroupOrgUnitID.text())
                salesOfficeOrganisationCenterId(s4_body.SalesAreaInService.SalesOfficeOrgUnitID.text())
            }
            xmlBodyNode.append(xmlBusinessAreaNode)
        }
    }
    
    //building total values dto 
    def xmlTotalValuesNode = new NodeBuilder().totalValues{
        grossAmount{
            content(s4_body.ServiceDocGrossAmount.text())
            currencyCode(s4_body.ServiceDocGrossAmount.@currencyCode[0])
        }
        netAmount{
            content(s4_body.ServiceDocNetAmount.text())
            currencyCode(s4_body.ServiceDocNetAmount.@currencyCode[0])
        }
        taxAmount{
            content(s4_body.ServiceDocTaxAmount.text())
            currencyCode(s4_body.ServiceDocTaxAmount.@currencyCode[0])
        }
    }
    xmlBodyNode.append(xmlTotalValuesNode)
    
    //building time points body node
    def xmlTimePointsNode = new NodeBuilder().timePoints{
        requestedStartOn(s4_body.RequestedServiceStartDateTime.text() ? s4_body.RequestedServiceStartDateTime.text()+"Z": null)
        requestedEndOn(s4_body.RequestedServiceEndDateTime.text()? s4_body.RequestedServiceEndDateTime.text()+"Z": null)
    }
    xmlBodyNode.append(xmlTimePointsNode)
    
    //mapping subnodes
    mappingItems(xmlBodyNode, s4_body)
    mappingRegisteredProducts(xmlBodyNode, s4_body)
    collectingInvolvedParties(message, useEnterpriseOrg, xmlBodyNode, s4_body)
    
    //Adding TransactionHistory nodes 
    mappingTransactionHistory(xmlBodyNode, s4_body)
    
    //making xml payload
    def xmlRoot = new NodeBuilder().root{}
    xmlRoot.append(xmlHeaderNode)
    
    def xmlMessageRequests = new NodeBuilder().messageRequests{}
    xmlMessageRequests.append(xmlBodyHeaderNode)
    xmlMessageRequests.append(xmlBodyNode)
    xmlRoot.append(xmlMessageRequests)
    
    // setting message properties anf body
    if(s4_body.ReferenceServiceOrder){
        message.setProperty("exists",true)
    }else{
        message.setProperty("exists",false)
    }
    message.setProperty("cns_actionCode",cns_actionCode)
    message.setProperty("S4ID",s4_body.ServiceOrder.text())
    message.setHeader("referenceMessageRequestId",header_body.ReferenceID.text())
    message.setProperty("mappedPayload",groovy.xml.XmlUtil.serialize(xmlRoot))
    
    //building custom query
    def s4id = s4_body.ServiceOrder.text();
    message.setProperty("custom_query", "\$" + "filter=ServiceOrder eq '$s4id' & sap-client=$sapClient")
    return message
}
