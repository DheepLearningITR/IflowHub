import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def removeEmptyFields(def json) {
    if (json instanceof Map) {
        json.entrySet().removeAll { it.value == null || it.value == 'null' || it.value == [] || (it.value instanceof String && it.value.trim() == "") }
        json.collectEntries { [it.key, removeEmptyFields(it.value)] }
    } else if (json instanceof List) {
        json.collect { removeEmptyFields(it) }.findAll { it != null }
    } else {
        json
    }
}

def Message processData(Message message){
    def json = new JsonSlurper().parse(message.getBody(java.io.Reader.class))
    // def noOfItems =0 
    // def noOfRegProduct =0
    // def noOfTransNodes = 0
    
    // if(json.messageRequests.body.items){
    //     if(json.messageRequests.body.items.item instanceof List){
    //         noOfItems = json.messageRequests.body.items.item.size()
    //     }else{
    //         noOfItems = 1
    //     }
    // }
    
    // if(json.messageRequests.body.registeredProducts){
    //     if(json.messageRequests.body.registeredProducts.registeredProduct instanceof List){
    //         noOfRegProduct = json.messageRequests.body.registeredProducts.registeredProduct.size()
    //     }else{
    //         noOfRegProduct = 1
    //     }
    // }
    
    // if(json.messageRequests.body.externalTransactionReference){
    //     if(json.messageRequests.body.externalTransactionReference.externalTransactionRef instanceof List){
    //         noOfTransNodes = json.messageRequests.body.externalTransactionReference.externalTransactionRef.size()
    //     }else{
    //         noOfTransNodes = 1
    //     }
    // }
    
    // //making item node as array
    // if( noOfItems== 1){
    //     json.messageRequests.body.items = [json.messageRequests.body.items.item]
    // }else if(noOfItems > 1){
    //     json.messageRequests.body.items = json.messageRequests.body.items.item
    // }
    
    // //making registered product node as array 
    // if(noOfRegProduct == 1){
    //     json.messageRequests.body.registeredProducts = [json.messageRequests.body.registeredProducts.registeredProduct]
    // }else if(noOfRegProduct > 1){
    //     json.messageRequests.body.registeredProducts = json.messageRequests.body.registeredProducts.registeredProduct
    // }
    
    // //making transaction history node as array
    // if(noOfTransNodes == 1){
    //      json.messageRequests.body.externalTransactionReference = [json.messageRequests.body.externalTransactionReference.externalTransactionRef]
    // }else if(noOfTransNodes > 1){
    //     json.messageRequests.body.externalTransactionReference = json.messageRequests.body.externalTransactionReference.externalTransactionRef
    // }
    // //making message requests as array
    // json.messageRequests = [json.messageRequests]
    
    removeEmptyFields(json)
    sleep(5000)
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(json)))
    return message
}