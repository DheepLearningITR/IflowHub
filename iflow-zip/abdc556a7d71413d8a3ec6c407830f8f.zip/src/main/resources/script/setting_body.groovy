import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message){
    def xmlRoot =new XmlSlurper().parseText(message.getProperty("mappedPayload") as String)
    def s4Body = new XmlParser().parse(message.getBody(java.io.Reader.class)).A_ServiceOrderType.ServiceOrderUUID.text()

    xmlRoot.messageRequests.body.appendNode{
        id(s4Body)
    }
    
    message.setBody(groovy.xml.XmlUtil.serialize(xmlRoot))
    return message
}