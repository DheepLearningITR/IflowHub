import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message){
    def xmlRoot =new XmlSlurper().parseText(message.getProperty("mappedPayload") as String)
    def involvedParties = message.getProperty("involvedParties")
    
    def body = new XmlParser().parse(message.getBody(java.io.Reader.class))
    def batchNodes =  body.'**'.findAll { it.name() == 'batchQueryPartResponse' }
    def count =0 
    def bpCategory 
    def bpID 
    
   involvedParties.each{
        party ->
            bpCategory = batchNodes[count].body.A_BusinessPartner.A_BusinessPartnerType.BusinessPartnerCategory.text()
            bpID = batchNodes[count].body.A_BusinessPartner.A_BusinessPartnerType.BusinessPartner.text()
            if(party.key == 'BillToParty'){
                switch(bpCategory){
                    case "1":
                        xmlRoot.messageRequests.body.appendNode{
                            billToIndividualCustomer{
                                displayId(bpID)
                            }
                        }
                        break
                    case "2":
                        xmlRoot.messageRequests.body.appendNode{
                            billToAccount{
                                displayId(bpID)
                            }
                        }
                        break
                }
            }
            if(party.key == 'ShipToParty'){
                switch(bpCategory){
                    case "1":
                        xmlRoot.messageRequests.body.appendNode{
                            shipToIndividualCustomer{
                                displayId(bpID)
                            }
                        }
                        break
                    case "2":
                        xmlRoot.messageRequests.body.appendNode{
                            shipToAccount{
                                displayId(bpID)
                            }
                        }
                        break
                }
            }
            if(party.key == 'SoldToParty'){
                switch(bpCategory){
                    case "1":
                        xmlRoot.messageRequests.body.appendNode{
                            individualCustomer{
                                displayId(bpID)
                            }
                        }
                        break
                    case "2":
                        xmlRoot.messageRequests.body.appendNode{
                            account{
                                displayId(bpID)
                            }
                        }
                        break
                }
            }
            if(party.key == 'PayerParty'){
                switch(bpCategory){
                    case "1":
                        xmlRoot.messageRequests.body.appendNode{
                            payerIndividualCustomer{
                                displayId(bpID)
                            }
                        }
                        break
                    case "2":
                        xmlRoot.messageRequests.body.appendNode{
                            payerAccount{
                                displayId(bpID)
                            }
                        }
                        break
                }
            }
            count = count + 1
        }
    
    message.setProperty("mappedPayload", groovy.xml.XmlUtil.serialize(xmlRoot))
    return message
}