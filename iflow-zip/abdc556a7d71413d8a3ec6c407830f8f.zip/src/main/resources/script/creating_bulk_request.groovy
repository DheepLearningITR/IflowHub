import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message){
    def involvedParties = message.getProperty("involvedParties")
    Node batch_payload = new NodeBuilder().batchParts{}
    def tempNode
    
    involvedParties.each{
        party ->
        tempNode = new NodeBuilder().batchQueryPart{
            uri("A_BusinessPartner('" + party.value + "')")//?$select=BusinessPartner,BusinessPartnerCategory
        }
        batch_payload.append(tempNode)
    }
    
    def xml = new XmlParser().parseText(groovy.xml.XmlUtil.serialize(batch_payload))
    String outxml = groovy.xml.XmlUtil.serialize(xml)
    message.setProperty("SAP_BatchLineSeparator","CRLF")
    message.setBody(outxml)
    return message
}