import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;



def Message processData(Message message) {
    def map = message.getProperties();
    def contactId = map.get("contactId");
    def accountId = map.get("C4C_account_Id");
    def externalId = contactId+"~ID-JOIN~"+accountId;
    message.getProperties().put("FSM_ExternalId",externalId);
    return message;
}