package settle.s4settle

import groovy.util.slurpersupport.GPathResult
import groovy.xml.XmlUtil
import groovy.xml.StreamingMarkupBuilder
import com.sap.gateway.ip.core.customdev.util.Message

import java.time.LocalDateTime


String toSettleGet(xmlTpmResp) {
    def mkpBuilder = new StreamingMarkupBuilder()
    mkpBuilder.encoding = 'utf-8'

    def xmlGetSettle = mkpBuilder.bind { bld ->
        mkp.xmlDeclaration()
        mkp.declareNamespace(ns_func: 'urn:sap-com:document:sap:rfc:functions')

        ns_func.BAPI_SINGLESETTREQS_GETLIST {
            MAXLINES(500) // Only load 500 record lines

            def billDocIds = xmlTpmResp.'**'.find({ it.name() == 'ET_SETTLEMENT_RETURN' })?.item?.'BILL_DOC_ID'?.collect({ it.text() })
            def billDocIdSet = billDocIds == null ? [] : billDocIds.findAll({ it }).toSet()

            REFDOCNORANGE {
                for (def billDocId in billDocIdSet) {
                    item {
                        SIGN('I')
                        OPTION('EQ')
                        LOW(billDocId.padLeft(10, '0'))
                    }
                }
            }
        }
    }

    return XmlUtil.serialize(xmlGetSettle)
}

def getLastTpm(xmlMsgBody) {
    def xmlLastTpmTran = xmlMsgBody.trans.tran.findAll({ it.@api == 'Tpm' }).max({ it.@callOrder.toInteger() })
    def xmlLastTpmResponse = xmlLastTpmTran.response

    return xmlLastTpmResponse
}

String appendRequestResponseInto(origBody, req, resp, docTrans) { // re-use
    def mkpBuilder = new StreamingMarkupBuilder()

    mkpBuilder.encoding = 'utf-8'

    def appendMsgXml = mkpBuilder.bind { bld ->
        mkp.xmlDeclaration()

        message {
            // append original bo
            origBody.bo.build(bld)

            // append documentTransactions
            for (documentTransactions in origBody.documentTransactions) {
                documentTransactions.build(bld)
            }

            for (def docTran in docTrans) {
                if (docTran instanceof String) {
                    mkp.yieldUnescaped(docTran.replaceFirst(/<\?xml.+\?>/, ''))
                } else {
                    docTran.build(bld)
                }
            }

            // append current tran
            trans {
                for (tran in origBody.trans.tran) {
                    tran.build(bld)
                }

                if (null != req && null != resp) {
                    def apiName = 'S4Settlement'
                    def curCallOrder = origBody.trans.tran.findAll({ it.@api == apiName }).size()

                    tran(api: apiName, callOrder: curCallOrder) {
                        request {
                            body(req)
                        }
                        response(resp)
                    }
                }
            }
        }
    }

    return XmlUtil.serialize(appendMsgXml)
}

/**
 * Step(0)
 *
 * */
def sleepBetweenEachCall(Message msg) {
    // get the retry times & setting
    def propMap = msg.getProperties()
    def retryTime = propMap.getOrDefault('retryTime', 0)
    def isExpDelay = propMap.getOrDefault('isExpDelay', 'F')
    def errorRetryInterval = Integer.parseInt(propMap.getOrDefault('retryInterval', '30').toString())

    // sleep given time
    if (retryTime > 0) {
        def obj = new Object()
        if (isExpDelay in ['T', 't', 'True', 'true', 'TRUE']) {
            obj.sleep((2**retryTime) * 1000)
        } else {
            obj.sleep(errorRetryInterval*1000)
        }
    }

    // set back the retry time
    msg.setProperty('retryTime', ++retryTime)

    return msg
}

class MsgWrapper {

    private Message msg;
    private XmlSlurper xmlSlp;

    MsgWrapper(Message msg) {
        this.msg = msg
        this.xmlSlp = new XmlSlurper()
    }

    def getMsg() {
        return msg
    }

    private GPathResult getXmlGPathFromMsgProperty(String property) {
        def propertyVal = msg.getProperty(property) as String

        return propertyVal ? xmlSlp.parseText(propertyVal) : null
    }

    GPathResult getRequest() {
        return xmlSlp.parseText(msg.getProperty('request') as String)
    }

    void setRequest(String request) {
        msg.setProperty('request', request)
    }

    GPathResult getResponse() {
        return xmlSlp.parseText(msg.getProperty('response') as String)
    }

    void setResponse(String response) {
        msg.setProperty('response', response)
    }

    GPathResult getOrigBody() {
        return getXmlGPathFromMsgProperty('origBody')
    }

    void setOrigBody(String origBody) {
        msg.setProperty('origBody', origBody)
    }

    String getSettleStatus() {
        return msg.getProperty('settleStatus') as String
    }

    void setSettleStatus(String status) {
        msg.setProperty('settleStatus', status)
    }

    String getSettleErrMsg() {
        return msg.getProperty('settleErrMsg') as String
    }

    void setSettleErrMsg(String status) {
        msg.setProperty('settleErrMsg', status)
    }

    boolean getNeedRetry() {
        return 'T' == (msg.getProperty('needRetry') as String)
    }

    void setNeedRetry(boolean needRetry) {
        msg.setProperty('needRetry', needRetry ? 'T' : 'F')
    }

    void setTenantId(String tenantId) {
        msg.setProperty('X-Tenant-ID', tenantId)
    }

    String getTenantId() {
        return msg.getProperty('X-Tenant-ID') as String
    }

    void setStepInfo(String step) {
        msg.setProperty('stepInfo', step)
    }

    String getStepInfo() {
        return msg.getProperties().getOrDefault('stepInfo', null) as String
    }

    GPathResult getBody() {
        return xmlSlp.parseText(msg.getBody(String.class) as String)
    }

    void setBody(String body) {
        msg.setBody(body)
    }
}

def transferS4SettleGetRequest(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'prepare get S4 settle request'

    // get the whole body and saved into a property 'origBody'
    msgWrapper.origBody = msg.getBody(String)
    msgWrapper.tenantId = msg.getHeader('X-Tenant-ID', String)

    // fetch and build request for get settle
    def xmlTpmResp = getLastTpm(msgWrapper.origBody)
    def strSettleRequest = toSettleGet(xmlTpmResp)
    msgWrapper.body = strSettleRequest

    // keep the request payload into a property 'request'
    msgWrapper.request = strSettleRequest

    // set the property 'needRetry'
    msgWrapper.needRetry = true

    return msg
}

def handleResponseNeedRetry(GPathResult resp) {
    def headItemNode = resp.HEADDATAOUT
    def docTranSet = new HashSet<String>()

    for (head in headItemNode.item) {
        def docNumber = head.DOCUMENT_NUMBER.text()
        def companyCode = head.COMP_CODE.text()
        def billDateStr = head.BILL_DATE.text()
        def docDateStr = head.DOC_DATE.text()

        if ([docNumber, companyCode, billDateStr, docDateStr].every({!it.isEmpty()})) {
            def docTranDateTime = LocalDateTime.now()

            def docTran = responseToDocumentTransaction(docNumber, companyCode, '', docTranDateTime)

            docTranSet.add(docTran)
        }
    }

    if (docTranSet.size() > 0) {
        return [false, docTranSet.toList(), 'successful']
    }

    def returnNode = resp.RETURN
    def returnItem = returnNode.item.find({ !it.MESSAGE.text().isEmpty() })
    def errMsg = returnItem != null ? returnItem.MESSAGE.text() : ''

    return [true, new ArrayList<String>(), errMsg]
}

String responseToDocumentTransaction(docNumber, companyCode, fiscalYear, settleDT) {
    // Build documentTransaction
    def mkpBuilder = new StreamingMarkupBuilder();

    mkpBuilder.encoding = 'utf-8'

    def docTranXml = mkpBuilder.bind { bld ->
        mkp.xmlDeclaration()

        bld.documentTransactions {
            bld.documentNumber(docNumber)
            bld.documentType('SETTLEMENT_S4_DOCUMENT')
            bld.fiscalYear(fiscalYear)
            bld.createdOn(settleDT)
            bld.companyCode(companyCode)
        }
    }

    return XmlUtil.serialize(docTranXml)
}

String toClaimsSettlementCallback(origBody, settleStatus, settleErrMsg) {
    def mkpBuilder = new StreamingMarkupBuilder();

    mkpBuilder.encoding = 'utf-8'

    def callbackXml = mkpBuilder.bind { bld ->
        mkp.xmlDeclaration()

        bld.root {
            mkp.comment("the settle process")

            def settlement = origBody.bo

            bld.settlementUUID(settlement.settlementUUID.text())
            bld.timestamp(LocalDateTime.now())
            bld.status(settleStatus)

            origBody.documentTransactions.build(bld)

            bld.message(settleErrMsg)
        }
    }

    return XmlUtil.serialize(callbackXml)
}

def mergeGetSettleResponse(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'merge S4 response into orig-body'

    // get the response from message body & keep the response payload into property 'response'
    msgWrapper.response = msg.getBody(String)

    def appendedBody = appendRequestResponseInto(msgWrapper.origBody, msgWrapper.request, msgWrapper.response, new ArrayList<String>())
    msgWrapper.body = appendedBody
    msgWrapper.origBody = appendedBody

    return msg
}

def handleSettleResponseForRetry(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'calc settle response for needRetry'

    def (needRetry, documentTransactions, errMsg) = handleResponseNeedRetry(msgWrapper.response)

    // merge current documentTransaction if settle successful
    if (!needRetry) {
        def appendBody = appendRequestResponseInto(msgWrapper.origBody, null, null, documentTransactions)

        msgWrapper.origBody = appendBody
        msgWrapper.body = appendBody
    }

    // set the property 'needRetry' & 'settleErrMsg'
    msgWrapper.settleStatus = needRetry ? 'ERROR' : ''
    msgWrapper.settleErrMsg = errMsg
    msgWrapper.needRetry = needRetry

    return msg
}

def transferToClaimsSettlementCallback(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'prepare callback message for error settle'

    msgWrapper.body = toClaimsSettlementCallback(msgWrapper.origBody, msgWrapper.settleStatus, msgWrapper.settleErrMsg)
    msg.setHeader('X-Tenant-ID', msgWrapper.tenantId)

    return msg
}

def transferExceptionToClaimsSettlementCallback(Message msg) {
    def msgWrapper = new MsgWrapper(msg)

    msgWrapper.stepInfo = 'prepare callback message for exception'

    // If there is exception happened in following step, the 'origBody' might be empty.
    if (msgWrapper.origBody == null) {
        msgWrapper.origBody = msg.getBody(String)
    }
    if (msgWrapper.settleStatus == null) {
        msgWrapper.settleStatus = 'ERROR'
    }

    def errMsg = ''

    if ((msg.getProperty('CamelExceptionCaught') as String)?.trim()) {
        errMsg += msg.getProperty('CamelExceptionCaught') as String
        errMsg += '\r\n'
    }
    if (msgWrapper.settleErrMsg?.trim()) {
        errMsg += msgWrapper.settleErrMsg
    }

    msgWrapper.body = toClaimsSettlementCallback(msgWrapper.origBody, msgWrapper.settleStatus, errMsg.trim())
    msg.setHeader('X-Tenant-ID', msgWrapper.tenantId)

    return msg
}

/**
 * Log all these message part
 *
 * */
def logFormatStr(String body, boolean compactXml) {
    if (body.startsWith('<?xml')) {
        if (!compactXml) {
            return XmlUtil.serialize(new XmlSlurper().parseText(body))
        } else {
            return body.replaceAll(/>\s+</, '><').trim()
        }
    }

    return body
}

def logFormatHeaderOrProperty(Map<String, Object> headerOrProperty) {
    def allStringValKeys = headerOrProperty.findAll({ it.value instanceof String }).collect({ it.key })
    allStringValKeys = allStringValKeys.sort()

    def maxKeyLen = allStringValKeys.collect({ it.size() }).max()
    return allStringValKeys.collect({ "${it.padRight(maxKeyLen)} : ${logFormatStr(headerOrProperty.get(it), true)}" }).join('\n')
}

def logAllOfMessage(Message msg) {
    // get log execute times
    def propMap = msg.getProperties()

    def printLogTimes = propMap.getOrDefault('printLogTimes', new HashMap<String, Integer>()) as Map<String, Integer>
    def msgWrapper = new MsgWrapper(msg)

    // get Header, Property & Body
    def headers = logFormatHeaderOrProperty(msg.getHeaders())
    def properties = logFormatHeaderOrProperty(msg.getProperties())
    def body = logFormatStr(msg.getBody(java.lang.String) as String, false)

    def stepTime = msgWrapper.stepInfo ? printLogTimes.getOrDefault(msgWrapper.stepInfo, 0) : 0
    def stepName = msgWrapper.stepInfo ? "${msgWrapper.stepInfo} ($stepTime)" : ''
    def globalStepTime = printLogTimes.getOrDefault('_GlobalStepTime', 0)
    def messageLog = messageLogFactory.getMessageLog(msg)
    if (messageLog != null)
    {
        def logText = '--------------------- Header ---------------------\n' + headers
        logText += '\n-------------------- Property --------------------\n' + properties
        logText += '\n---------------------- Body ----------------------\n' + body
        messageLog.addAttachmentAsString("Log ($globalStepTime) at $stepName:", logText, "text/plain")
    }

    if (msgWrapper.stepInfo) {
        printLogTimes.put(msgWrapper.stepInfo, ++stepTime)
    }
    printLogTimes.put('_GlobalStepTime', ++globalStepTime)
    msg.setProperty('printLogTimes', printLogTimes)

    return msg
}
