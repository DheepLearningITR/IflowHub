
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {
    def body = message.getBody();
    def headers = message.getHeaders();
    def statusCode = headers.get("CamelHttpResponseCode");
    def errorBody = {};
    message.setProperty("statusCode",statusCode);
    if(statusCode == 403){
        message.setBody("{\"status\":\"fail\",\"statuscode\":403,\"message\":\"forbidden\"}");
    }else if(statusCode == 404){
        message.setBody("{\"status\":\"fail\",\"statuscode\":404,\"message\":\"folder path not found\"}");
    }else{
        message.setBody("{\"status\":\"fail\",\"statuscode\":500,\"message\":\"internel server error\"}");
    }
    message.setHeader("Content-Type","application/json");
    return message;
}