import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def objectId = "";

    def params = [:]
    (message.getHeaders().CamelHttpQuery =~ /(\w+)=?([^&]+)?/)[0..-1].each{
        params[it[1]] = it[2]
    }

	if(params.objectId!=null){
		objectId = params.objectId;
		message.setProperty("objectId", objectId);	
	}

    def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        messageLog.addAttachmentAsString("Payload:", "objectId - " + objectId, "text/plain");
	}
	return message;
}