import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    //Body
    def body = message.getBody(String.class);
	def parsedObj = new JsonSlurper().parseText(body);
    
    parsedObj.each {
        if(it.getKey() == "LanguageCode"){
            message.setHeader("Accept-Language", it.getValue().toLowerCase());
        }
        
        if(it.getKey() == "caseTypeOnly"){
	        message.getProperties().put(it.getKey(),it.getValue());
        }
	}
    //Headers
    message.setHeader("Accept","application/json");
    
    //Properties
    message.getProperties().put("templateStatus","ACTIVE");
    return message;
}