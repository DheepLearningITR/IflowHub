import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {
    //Body
    def priorityResponseBody = message.getBody(String.class);
    def priorityList = new JsonSlurper().parseText(priorityResponseBody);

    def finalResponse = new JsonSlurper().parseText('{}');
    
    if(priorityList != null){    
    
        def priorityValueArray = priorityList.value;
        def filteredArray = priorityValueArray.collect{ jsonObject ->
                ["code": jsonObject.code, "description": jsonObject.description]
        }
            
        finalResponse <<[priorities:filteredArray];
    
        JsonBuilder builder = new JsonBuilder(finalResponse);
        String jsonBody = JsonOutput.prettyPrint(builder.toString());
        
        message.setBody(jsonBody);
    }
    return message;
}