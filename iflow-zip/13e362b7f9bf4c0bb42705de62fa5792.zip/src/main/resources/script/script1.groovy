import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.List;

def Message processData(Message message) {
               
               //Body 
               def body = message.getBody();
               List<String> validEmployee = new ArrayList<String>();
               List<String> employeeDataWarning = new ArrayList<String>();
               List<String> invalidEmployee = new ArrayList<String>();
               List<String> persist_time_List = new ArrayList<String>();
               
               message.setProperty("invalidEmployeeProperty",invalidEmployee);
               message.setProperty("employeeDataWarningProperty",employeeDataWarning);
               message.setProperty("validEmployeeProperty",validEmployee);
               message.setProperty("persist_time_ListProperty",persist_time_List);
               
               return message;
}
