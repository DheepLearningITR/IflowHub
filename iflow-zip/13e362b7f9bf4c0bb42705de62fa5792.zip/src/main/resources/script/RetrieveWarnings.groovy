import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.List;

def Message processData(Message message) {
               
               //Body 
               def body = message.getBody();
               def map = message.getProperties();
               
               List<String> p = map.get("employeeDataWarningProperty");
               StringBuilder dataWarning = new StringBuilder();
               
               dataWarning.append("The following employees have been returned with some warnings.  \n\n")
               
               for(String entry : p)
               {
                              dataWarning.append(entry);
               
               }
               def count = p.size();
               message.setProperty("emptyCheckWarning",count);
               
               
               message.setBody(dataWarning.toString());
               
               return message;
}
