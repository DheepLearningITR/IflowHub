import com.sap.it.api.mapping.*;

def String addzeros(String a, int b){
def stringLen = b
def strLen = a.toString().size()
expectedLen = stringLen.toInteger() - strLen.toInteger()
for(i = 0; i<=expectedLen-1;i++)
{
	a = "0" + a 
}


	return a 
}