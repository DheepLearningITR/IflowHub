import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    HashMap<String, String> token = new HashMap<String, String>();

    message.setHeader("token", token);
    return message;
}