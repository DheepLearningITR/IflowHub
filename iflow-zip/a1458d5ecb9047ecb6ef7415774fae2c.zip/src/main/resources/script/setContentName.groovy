import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;


def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def payload = jsonSlurper.parseText(body);
    def tyOfValue = payload['root']['value']['componentTypeID']
    message.setProperty("contentName", tyOfValue);
    
    return message;
}