import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;
import groovy.json.JsonOutput;
import groovy.json.JsonSlurper;

class ShopifyOrder {
    String shopifyOrderID
    String shopifyOrderIDTrimmed
    String s4HanaCloudOrderID
    String shopifyFulfillmentOrderID
    List<String> alreadyLinkedS4HanaCloudOutboundDeliveries = []
    List<Product> products = []
}

class Product {
    String shopifySKU;
    String shopifyOrderLineItemID;
    Integer shopifyRemainingQuantity;
    Integer s4FulfilledQuantity;
}

def Message processData(Message message) {

    def body = message.getBody(java.io.Reader)
    def xml = new XmlSlurper().parse(body)

    def orderInformation = xml.data.orders.edges.node;
    def shopifyOrderID = orderInformation.id.text();
    def shopifyOrderIDPaths = shopifyOrderID.split("/");

    def shopifyOrder = new ShopifyOrder()

    if(shopifyOrderID && shopifyOrderIDPaths && shopifyOrderIDPaths.size() > 0){
        def shopifyOrderIDTrimmed = shopifyOrderIDPaths[shopifyOrderIDPaths.size()-1]
        
        shopifyOrder.shopifyOrderIDTrimmed = shopifyOrderIDTrimmed;
        shopifyOrder.shopifyOrderID = shopifyOrderID;
        
        message.setProperty("shopifyOrderIDTrimmed", shopifyOrderIDTrimmed);
        message.setProperty("shopifyOrderID", shopifyOrderID)
    }

    def s4HanaCloudOrderId = orderInformation.s4HanaCloudOrderId;

    if(s4HanaCloudOrderId && s4HanaCloudOrderId.key.text() == "shopifyaccelerator.s_4hana_cloud_order_id") {
        shopifyOrder.s4HanaCloudOrderID = s4HanaCloudOrderId.value.text();
        message.setProperty("S4HanaCloudOrderID", s4HanaCloudOrderId.value.text());
    }
    
    def alreadyLinkedS4HanaCloudOutboundDeliveries = orderInformation.s4HanaCloudOutboundDeliveries;

    if (alreadyLinkedS4HanaCloudOutboundDeliveries && alreadyLinkedS4HanaCloudOutboundDeliveries.key.text() == "shopifyaccelerator.s_4hana_cloud_outbound_deliveries") {
        def deliveriesString = alreadyLinkedS4HanaCloudOutboundDeliveries.value.text()
        def deliveriesList = new JsonSlurper().parseText(deliveriesString)
        shopifyOrder.alreadyLinkedS4HanaCloudOutboundDeliveries = deliveriesList
        message.setProperty("alreadyLinkedS4HanaCloudOutboundDeliveries", deliveriesList)
    }

    def fulfillmentOrderId = extractShopifyFulfillmentOrderID(orderInformation);
    shopifyOrder.shopifyFulfillmentOrderID = fulfillmentOrderId;

    def products = extractShopifyFulfillmentOrderLineItems(orderInformation);
    shopifyOrder.products = products;
    def shopifyOrderJson = JsonOutput.toJson(shopifyOrder)
    message.setProperty("shopifyOrderJson", shopifyOrderJson);

    println(shopifyOrderJson);
    return message;
}

def String extractShopifyFulfillmentOrderID(def orderInformation){
    if(orderInformation.fulfillmentOrders.edges && orderInformation.fulfillmentOrders.edges[0]){
        def fulfillmentOrder = orderInformation.fulfillmentOrders.edges[0];
        def fulfillmentOrderNode = fulfillmentOrder.node
        def fulfillmentOrderId = fulfillmentOrderNode.id.text();
        return fulfillmentOrderId;
    }
}

def List<Product> extractShopifyFulfillmentOrderLineItems(def orderInformation) {
    List<Product> shopifyOrderProducts = [];

        if(orderInformation.fulfillmentOrders.edges && orderInformation.fulfillmentOrders.edges[0]){
            def fulfillmentOrderEdge = orderInformation.fulfillmentOrders.edges[0];
            def fulfillmentOrderNode = fulfillmentOrderEdge.node

            fulfillmentOrderNode.lineItems.edges.each { lineItemEdge ->
                def fulfillmentLineItem = new Product();
                def lineItemNode = lineItemEdge.node
                
                fulfillmentLineItem.shopifyOrderLineItemID = lineItemNode.id.text();
                fulfillmentLineItem.shopifySKU = lineItemNode.sku.text();
                
                def remainingQuantityText = lineItemNode.remainingQuantity.text()

                if (remainingQuantityText && remainingQuantityText.isInteger()) {
                    def remainingQuantity = remainingQuantityText.toInteger()
                    fulfillmentLineItem.shopifyRemainingQuantity = remainingQuantity;
                }
                shopifyOrderProducts.add(fulfillmentLineItem);
            }
        }
    
    return shopifyOrderProducts;
}