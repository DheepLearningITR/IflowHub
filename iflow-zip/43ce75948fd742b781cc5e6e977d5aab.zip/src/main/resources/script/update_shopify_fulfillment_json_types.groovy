import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader);
    def json = new JsonSlurper().parse(body)
    def lineItems = json.fulfillment.lineItemsByFulfillmentOrder.fulfillmentOrderLineItems

    if (lineItems instanceof List) {
        lineItems.each { item ->
            if (item.quantity != null) {
                item.quantity = Integer.parseInt(item.quantity.toString())
            }
        }
    } else if (lineItems instanceof Map) {
        if (lineItems.quantity != null) {
            lineItems.quantity = Integer.parseInt(lineItems.quantity.toString())
        }
    } else {
        throw new Exception('Unexpected data structure for fulfillmentOrderLineItems.')
    }
    
    def updatedJson = JsonOutput.toJson(json)

    message.setBody(updatedJson)

    return message
}