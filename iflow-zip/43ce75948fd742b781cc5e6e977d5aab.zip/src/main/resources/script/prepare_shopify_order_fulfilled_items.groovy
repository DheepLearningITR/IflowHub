import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

class ShopifyOrder {
    String shopifyOrderID
    String shopifyOrderIDTrimmed
    String s4HanaCloudOrderID
    String shopifyFulfillmentOrderID
    List<Product> products = []
}

class Product {
    String shopifySKU;
    String shopifyOrderLineItemID;
    Integer shopifyRemainingQuantity;
    Integer s4FulfilledQuantity;
    Boolean s4ProductFullyFulfilled;
}

def Message processData(Message message) {
    def shopifyOrderJson = message.getProperty('shopifyOrderJson');

    if (shopifyOrderJson) {
        def String shopifyOrderWithFulfilledItemsJson = filterProductsByFulfillment(shopifyOrderJson);
        message.setProperty('shopifyOrderWithFulfilledItemsJson', shopifyOrderWithFulfilledItemsJson);
    }

    return message;
}

def String filterProductsByFulfillment(String shopifyOrderJson){
    try {
        def ShopifyOrder shopifyOrderWithFulfilledItems = new JsonSlurper().parseText(shopifyOrderJson);
        if (shopifyOrderWithFulfilledItems.products) {
            // Filter the products to only include those fully fulfilled
            shopifyOrderWithFulfilledItems.products = shopifyOrderWithFulfilledItems.products.findAll { product ->
                product.s4ProductFullyFulfilled == true;
            }
            return JsonOutput.toJson(shopifyOrderWithFulfilledItems);
        } else {
            return '';
        }
    } catch (Exception e) {
        return '';
    }
}