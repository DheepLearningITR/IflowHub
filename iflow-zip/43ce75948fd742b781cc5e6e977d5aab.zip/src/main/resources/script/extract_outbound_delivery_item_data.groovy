import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.xml.MarkupBuilder;
import java.io.StringWriter;

class ShopifyOrder {
    String shopifyOrderID
    String shopifyOrderIDTrimmed
    String s4HanaCloudOrderID
    String shopifyFulfillmentOrderID
    String s4OutboundDeliveryDocument
    List<String> alreadyLinkedS4HanaCloudOutboundDeliveries = []
    List<Product> products = []
    List<Product> fulfilledProductsInDeliveryDocument = []
}

class Product {
    String shopifySKU;
    String shopifyOrderLineItemID;
    Integer shopifyRemainingQuantity;
    Integer s4FulfilledQuantity;
}

class DeliveryDocumentDetail {
    String material;
    int deliveryQuantity;

    DeliveryDocumentDetail(String material, int quantity) {
        this.material = material;
        this.deliveryQuantity = quantity;
    }
}

class DeliveryDocument {
    String deliveryDocumentID;
    List<DeliveryDocumentDetail> details = [];

    DeliveryDocument(String deliveryDocumentID) {
        this.deliveryDocumentID = deliveryDocumentID;
    }

    void addOrUpdateMaterial(String material, int quantity) {
        def detail = details.find { it.material == material }
        if (detail) {
            detail.deliveryQuantity += quantity;
        } else {
            details.add(new DeliveryDocumentDetail(material, quantity));
        }
    }
}

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader);
    def xml = new XmlSlurper().parse(body);
    
    def shopifyOrderJson = message.getProperty("shopifyOrderJson");
    List<String> alreadyLinkedS4HanaCloudOutboundDeliveries = [];
    if (shopifyOrderJson) {
        def ShopifyOrder shopifyOrder = new JsonSlurper().parseText(shopifyOrderJson);
        
        alreadyLinkedS4HanaCloudOutboundDeliveries = shopifyOrder.alreadyLinkedS4HanaCloudOutboundDeliveries ?: [];
    }

    def deliveryDocuments = extractUniqueDeliveryDocuments(xml, alreadyLinkedS4HanaCloudOutboundDeliveries);
    def outputXml = buildOutputXml(deliveryDocuments);
    
    message.setBody(outputXml);
    
    return message;
}

def HashMap<String, Integer> extractMaterialsWithQuantity(def xml) {
    def HashMap<String, Integer> materialsMap = new HashMap<String, Integer>();

    xml.A_OutbDeliveryItemType.each { item ->
        def goodsMovementStatus = item.GoodsMovementStatus?.text();
        def material = item.Material?.text();
        def quantityText = item.ActualDeliveryQuantity?.text();

        if (goodsMovementStatus && goodsMovementStatus == "C" && material && quantityText) {
            def quantityDecimal = new BigDecimal(quantityText);
            def quantity = quantityDecimal.intValueExact();

            if (materialsMap.containsKey(material)) {
                materialsMap.put(material, materialsMap.get(material) + quantity);
            } else {
                materialsMap.put(material, quantity);
            }
        }
    }

    return materialsMap;
}

def List<DeliveryDocument> extractUniqueDeliveryDocuments(def xml, List<String> alreadyLinked) {
    def deliveryDocumentsMap = new HashMap<String, DeliveryDocument>();

    xml.A_OutbDeliveryItemType.each { item ->
        def deliveryDocumentID = item.DeliveryDocument?.text();
        def material = item.Material?.text();
        def quantityText = item.ActualDeliveryQuantity?.text();

        if (deliveryDocumentID && !alreadyLinked.contains(deliveryDocumentID) && material && quantityText) {
            def quantityDecimal = new BigDecimal(quantityText);
            def quantity = quantityDecimal.intValueExact();

            if (!deliveryDocumentsMap.containsKey(deliveryDocumentID)) {
                deliveryDocumentsMap.put(deliveryDocumentID, new DeliveryDocument(deliveryDocumentID));
            }
            
            deliveryDocumentsMap.get(deliveryDocumentID).addOrUpdateMaterial(material, quantity);
        }
    }

    return deliveryDocumentsMap.values().toList();
}

def String buildOutputXml(List<DeliveryDocument> deliveryDocuments) {
    def writer = new StringWriter();
    def xml = new MarkupBuilder(writer);

    xml.DeliveryDocuments {
        deliveryDocuments.each { document ->
            DeliveryDocument {
                DeliveryDocumentID(document.deliveryDocumentID)
                document.details.each { detail ->
                    MaterialDetail {
                        Material(detail.material)
                        DeliveryQuantity(detail.deliveryQuantity)
                    }
                }
            }
        }
    }

    return writer.toString();
}