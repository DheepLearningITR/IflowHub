import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.json.JsonOutput


class FulfillmentRequest {
    Fulfillment fulfillment
}

class Fulfillment {
    List<LineItemsByFulfillmentOrder> lineItemsByFulfillmentOrder = []
    Boolean notifyCustomer
    Address originAddress
    TrackingInfo trackingInfo
}

class LineItemsByFulfillmentOrder {
    String fulfillmentOrderId
    List<FulfillmentOrderLineItem> fulfillmentOrderLineItems = []
}

class FulfillmentOrderLineItem {
    String id
    Integer quantity
}

class Address {
    String address1
    String address2
    String city
    String countryCode
    String provinceCode
    String zip
}

class TrackingInfo {
    String company
    String number
    List<String> numbers = []
    String url
    List<String> urls = []
}

def Message processData(Message message) {
    def xmlPayload = message.getBody(java.io.Reader)
    def xml = new XmlSlurper().parse(xmlPayload)

    def fulfillmentRequest = new FulfillmentRequest()
    def fulfillment = new Fulfillment()

    xml.fulfillment.lineItemsByFulfillmentOrder.each { lineItemsNode ->
        def lineItems = new LineItemsByFulfillmentOrder()
        lineItems.fulfillmentOrderId = lineItemsNode.fulfillmentOrderId.text()

        lineItemsNode.fulfillmentOrderLineItems.each { itemNode ->
            def lineItem = new FulfillmentOrderLineItem()
            lineItem.id = itemNode.id.text()
            lineItem.quantity = itemNode.quantity.text().toInteger()

            lineItems.fulfillmentOrderLineItems.add(lineItem)
        }

        fulfillment.lineItemsByFulfillmentOrder.add(lineItems)
    }

    if (xml.fulfillment.notifyCustomer) {
        fulfillment.notifyCustomer = xml.fulfillment.notifyCustomer.text().toBoolean()
    }

    fulfillmentRequest.fulfillment = fulfillment

    def fulfillmentRequestMap = buildFulfillmentRequestMap(fulfillmentRequest)
    def fulfillmentJson = JsonOutput.toJson(fulfillmentRequestMap)

    message.setBody(fulfillmentJson)

    return message
}

// Method to build the result map for FulfillmentRequest, excluding null values
def buildFulfillmentRequestMap(FulfillmentRequest fulfillmentRequest) {
    def fulfillmentRequestMap = [:]

    // Construct map for Fulfillment if not null
    if (fulfillmentRequest.fulfillment != null) {
        def fulfillmentMap = [:]
        def fulfillment = fulfillmentRequest.fulfillment

        if (fulfillment.lineItemsByFulfillmentOrder) {
            fulfillmentMap.lineItemsByFulfillmentOrder = fulfillment.lineItemsByFulfillmentOrder
        }
        if (fulfillment.notifyCustomer != null) {
            fulfillmentMap.notifyCustomer = fulfillment.notifyCustomer
        }
        if (fulfillment.originAddress != null) {
            fulfillmentMap.originAddress = fulfillment.originAddress
        }
        if (fulfillment.trackingInfo != null) {
            fulfillmentMap.trackingInfo = fulfillment.trackingInfo
        }

        fulfillmentRequestMap.fulfillment = fulfillmentMap
    }

    return fulfillmentRequestMap
}