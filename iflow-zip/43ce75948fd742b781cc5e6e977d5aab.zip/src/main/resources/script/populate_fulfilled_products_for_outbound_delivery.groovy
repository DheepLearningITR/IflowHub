import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

class ShopifyOrder {
    String shopifyOrderID
    String shopifyOrderIDTrimmed
    String s4HanaCloudOrderID
    String shopifyFulfillmentOrderID
    List<String> alreadyLinkedS4HanaCloudOutboundDeliveries = []
    List<Product> products = []
}

class Product {
    String shopifySKU
    String shopifyOrderLineItemID
    Integer shopifyRemainingQuantity
    Integer s4FulfilledQuantity
}

class ShopifyOrderWithFulfilledItems extends ShopifyOrder {
    String s4OutboundDeliveryDocument
    List<Product> fulfilledProductsInDeliveryDocument = []

    ShopifyOrderWithFulfilledItems() {
        super()
    }
}

def Message processData(Message message) {
    def xml = new XmlSlurper().parseText(message.getBody(String));

    def shopifyOrderJson = message.getProperty("shopifyOrderJson");
    def ShopifyOrderWithFulfilledItems shopifyOrderWithFulfilledItems = new JsonSlurper().parseText(shopifyOrderJson);
    
    def deliveryDocumentID = xml.DeliveryDocument.DeliveryDocumentID.text();
    
    message.setProperty("deliveryDocumentID", deliveryDocumentID)
    
    shopifyOrderWithFulfilledItems.s4OutboundDeliveryDocument = deliveryDocumentID;

    xml.DeliveryDocument.MaterialDetail.each { materialDetail ->
        def material = materialDetail.Material.text();
        def deliveryQuantity = materialDetail.DeliveryQuantity.text().toInteger();

        // Find corresponding product in the shopify order
        def product = shopifyOrderWithFulfilledItems.products.find { it.shopifySKU == material }
        if (product) {
            def fulfilledProduct = new Product(
                shopifySKU: product.shopifySKU,
                shopifyOrderLineItemID: product.shopifyOrderLineItemID,
                shopifyRemainingQuantity: product.shopifyRemainingQuantity,
                s4FulfilledQuantity: deliveryQuantity
            )
            shopifyOrderWithFulfilledItems.fulfilledProductsInDeliveryDocument.add(fulfilledProduct);
        }
    }

    def shopifyOrderWithFulfilledItemsJson = JsonOutput.toJson(shopifyOrderWithFulfilledItems);

    message.setProperty("shopifyOrderWithFulfilledItemsJson", shopifyOrderWithFulfilledItemsJson);
    message.setBody(shopifyOrderWithFulfilledItemsJson)
    
    return message;
}