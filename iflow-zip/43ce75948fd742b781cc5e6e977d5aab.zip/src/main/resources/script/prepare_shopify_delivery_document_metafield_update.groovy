import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    String responseJson = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def responseObject = jsonSlurper.parseText(responseJson);

    def orderNode = responseObject.data.orders.edges[0].node;
    def shopifyOrderId = message.getProperty("shopifyOrderID");
    def outboundDeliveryDocumentID = message.getProperty("deliveryDocumentID");

    def existingValue = orderNode?.s4HanaCloudOutboundDeliveries?.value;
    def outboundDeliveryDocumentsValueList;

    if (existingValue) {
        outboundDeliveryDocumentsValueList = jsonSlurper.parseText(existingValue);
    } else {
        outboundDeliveryDocumentsValueList = [];
    }

    if (outboundDeliveryDocumentID && !outboundDeliveryDocumentsValueList.contains(outboundDeliveryDocumentID)) {
        outboundDeliveryDocumentsValueList.add(outboundDeliveryDocumentID);
    }

    def value = JsonOutput.toJson(outboundDeliveryDocumentsValueList);
    
    def outboundDeliveryDocument = [
        key      : "s_4hana_cloud_outbound_deliveries",
        ownerId  : shopifyOrderId,
        value    : value,
        type     : "list.single_line_text_field",
        namespace: "shopifyaccelerator"
    ];

    def outboundDeliveryDocumentJson = JsonOutput.toJson(outboundDeliveryDocument);

    message.setProperty("shopifyOrderOutboundDeliveryMetafieldUpdate", outboundDeliveryDocumentJson)

    return message;
}