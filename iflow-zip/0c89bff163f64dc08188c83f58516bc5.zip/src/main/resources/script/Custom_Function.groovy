import com.sap.it.api.mapping.*;
import java.util.UUID; 
import java.util.Arrays;
import java.util.Set;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;

// Script to get number range group code of business partner
def String getInternalId(String arg1, MappingContext context){
    
    def getInternalId = context.getProperty("businessPartnerInternalId");
    
    return getInternalId;
	
}

// Script to get number range group code of business partner
def String getBPUUID(String arg1, MappingContext context){
    
    def getBPUUID = context.getProperty("businessPartnerInternalUUID");
    
    return getBPUUID;
	
}


// Script to get number range group code of business partner
def String getCustomerId(String arg1, MappingContext context){
    
    def getCustomerId = context.getProperty("customerId");
    
    return getCustomerId;
	
}


// Script to get number range group code of business partner
def String getEmail(String arg1, MappingContext context){
    
    def getEmail = context.getProperty("customerEmail");
    
    return getEmail;
	
}

// Script to get number range group code of business partner
def String getfirstName(String arg1, MappingContext context){
    
    def getfirstName = context.getProperty("fname");
    
    return getfirstName;
	
}

// Script to get number range group code of business partner
def String getlastName(String arg1, MappingContext context){
    
    def getlastName = context.getProperty("lname");
    
    return getlastName;
	
}


