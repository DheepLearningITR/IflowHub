import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import javax.xml.bind.DatatypeConverter;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

def Message processData(Message message) {
    
    def map = message.getProperties();
    def CPQCredentials = map.get("CPQCredentials");
    
  def service = ITApiFactory.getApi(SecureStoreService.class, null);
  def credential = service.getUserCredential(CPQCredentials);
  
  if (credential == null){
    String error = "No credential found for alias" + CPQCredentials;
    throw new IllegalStateException(error);
  }
  
  String user = credential.getUsername();
  int index = user.indexOf("#");
  String domain = user.substring(index + 1);
  String username = user.substring(0,index);
  String password = new String(credential.getPassword());

 
  def body = message.getBody();
   body = "grant_type=password";
   body = body + "&username=" + username;
   body = body + "&password=" + password;
   body = body + "&domain=" + domain;
   message.setBody(body);
   
  return message;
  
}
