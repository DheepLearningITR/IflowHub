import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message)
{
    def body = message.getProperties().get("fileContent") as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null)
    {
        messageLog.addAttachmentAsString(message.getProperties().get("fileName"),body,"text/plain");
    }
    messageLog.addCustomHeaderProperty("File Error Archiving Status","Failed");
    return message;
}