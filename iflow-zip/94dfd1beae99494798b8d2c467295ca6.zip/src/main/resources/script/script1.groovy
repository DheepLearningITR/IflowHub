import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Calendar;
import java.text.SimpleDateFormat;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    //Properties
    map = message.getProperties();
    def checkrun_DT = map.get("checkRun_dateTime");
    def lastrun_DT = map.get("lastRun_dateTime");
    def offset_txt = map.get("offset");
	def send_email;
	
	//default offset hours to 0 if not maintained
	if(offset_txt == null || offset_txt == '' || offset_txt.contains(".")){
            offset_txt = "0"
            message.setProperty("offset",offset_txt)
    }
    
    def offset = '-' + offset_txt as Integer;
	
	//set DateFormat for checkrun_DT
    SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
    Calendar calendar = new GregorianCalendar();
    Date dateToFormat = dateformat.parse(checkrun_DT);
	
	//set calendar to checkrun_DT
    calendar.setTime(dateToFormat);
	//subtract offset hours from checkrun_DT
    calendar.add(Calendar.HOUR, offset);
	//subtract additional 1 minute for buffer
    calendar.add(Calendar.MINUTE, -1);
	//get result for cutoff_DT
    Date result = calendar.getTime();
	//format result
    String cutoff_DT = dateformat.format(result);

    if (lastrun_DT == 'null' || lastrun_DT == '') {
        send_email = 'false';
    } else if (cutoff_DT > lastrun_DT) {
        send_email = 'true';
    } else {
        send_email = 'false';
    }
	
	message.setProperty("send_email",send_email)
	messageLog.addCustomHeaderProperty("Run mode", "Status check");
	messageLog.addCustomHeaderProperty("Send email", send_email);

    return message;
}
