import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message) throws Exception {

  def keepGoing = true;
  int count = 1;
  def BillerIdList = [];
  String BillerId;

  while (keepGoing) {
    BillerId = dynamicValueMap("Id", "name", "BillerId", "name", count.toString());

    if (BillerId == null) {
      keepGoing = false;
    } else {
      message.setHeader('BillerID', BillerId );
    }

    count++;
  }


  if (BillerId == null && count == 2 ) {
    throw new IllegalStateException("Biller Id could not be determined");
  }

  return message;
}

def Message GetBillers(Message message) throws Exception {

	def keepGoing = true;
	int count = 1;
	def BillerIdList = [];
	
	while( keepGoing ){
	    String BillerId = dynamicValueMap("Id","name", "BillerId", "name", count.toString());

		if (BillerId == null) {
           keepGoing = false;
        } else {
		 BillerIdList.add(BillerId)
		}
		
		count++;
	}
	
	int countBillerId = BillerIdList.size;
    
    if (countBillerId == 0){
        throw new IllegalStateException("Biller Id could not be determined");
    } 
	
	//build xml based on Biller list
	def writer = new StringWriter()
    def xml = new groovy.xml.MarkupBuilder(writer)

    xml.BillerIds {
    setOmitEmptyAttributes(true)
    setOmitNullAttributes(true)
    
    for(item in BillerIdList){
    BillerId{
            Id(item)
        }
    }
    
}
	
	
	message.setBody(writer.toString());

	return message;
}

def String dynamicValueMap(String sAgency, String sSchema, String tAgency, String tSchema, String key) {
  def service = ITApiFactory.getApi(ValueMappingApi.class, null);
  if (service != null) {
    return service.getMappedValue(sAgency, sSchema, key, tAgency, tSchema);
  }
  throw new Exception("Service is null");
  return null;
}



