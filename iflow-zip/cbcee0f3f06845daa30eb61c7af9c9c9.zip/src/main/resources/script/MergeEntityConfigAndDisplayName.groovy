import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    
    def body = message.getBody(String.class);
    def parseObjEntityDisplayset = new JsonSlurper().parseText(body);
    
    // Reading the Property
    def map = message.getProperties();
    String EntitySetConfig = map.get('EntitySetConfig') as String;
    def entitySetConfig = new JsonSlurper().parseText(EntitySetConfig);	

    def finalObj = new JsonSlurper().parseText('{}');
    def objID;

    // get the Display Name for the corresponding entity 
    Iterator<String> it = entitySetConfig.iterator();
    def element;
    while (it.hasNext()) {
        element = it.next();
        ObjectID = element.ObjectID;
        parseObjEntityDisplayset.d.results.each{
            if(it.ParentObjectID == ObjectID){
                element.DisplayNameDescription = it.DisplayNameDescription
            }
        }
    }

	JsonBuilder builder = new JsonBuilder(entitySetConfig);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
    message.setBody(jsonBody);
	return message;
}