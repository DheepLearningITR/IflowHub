import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {
 
	    def body = message.getBody(String.class);
        def EntitySetConfig = new JsonSlurper().parseText(body);
        
        if(EntitySetConfig.d.results.size()){
            // Declaration
            def finalObj = new JsonSlurper().parseText('{}');
	        String ObjectIDList;
	        String ParentObjectId = "ParentObjectID eq ";
	        String OR = " or ";
	
            EntitySetConfig.d.results.each{
                //remove the metadata block
                it.remove('__metadata');
    
                // Preparing the Filter String
                if(ObjectIDList == null){
                    ObjectIDList = ParentObjectId + "'" + it.ObjectID + "'" + OR
	            }
	            else
	            {
		            ObjectIDList = ObjectIDList + ParentObjectId + "'" + it.ObjectID + "'" + OR
	            }
            }
            
            if(ObjectIDList != null){
                // Remove the keyword "or" at last position
                String finalResult = ObjectIDList.substring(0,ObjectIDList.lastIndexOf(" or "));

                message.setProperty("FilterString",finalResult);

                finalObj <<[EntitySetConfig:EntitySetConfig.d.results];
    
	            JsonBuilder builder = new JsonBuilder(finalObj.EntitySetConfig);
                String jsonBody = JsonOutput.prettyPrint(builder.toString());
    
                message.setBody(jsonBody);
	            message.setProperty("EntitySetConfig",jsonBody);
    	        return message;
            }
        }
        else
        {
            // No Active Entity Set Config found
            throw new Exception("NO_ACTIVE_ENTITY_SET");
        }
    }