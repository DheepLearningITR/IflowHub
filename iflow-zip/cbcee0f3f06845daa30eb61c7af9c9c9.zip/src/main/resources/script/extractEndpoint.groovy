import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
	
	def map = message.getProperties();
	def parsedObj = map.get('endpoints');
	
	if(parsedObj.size() > 0){
		message.getProperties().put("codeListKey",parsedObj[0].keySet()[0]);
		message.getProperties().put("endpoint",parsedObj[0].values()[0]);
		parsedObj.remove(0);
	}
	if(parsedObj.size() > 0){
		//message.getProperties().put("LoopConditon","true");
		message.getProperties().put("endpoints",parsedObj);
	}else{
	    message.getProperties().put("LoopCondition","false");
	}
	return message;
}