import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {
    
	def body = message.getBody(String.class);
    def EntitySetFeildConfig = new JsonSlurper().parseText(body);
    def finalObj = new JsonSlurper().parseText('{}');
    def map = message.getProperties();
    def tempArray = [];
    String actionCode = map.get('actionCode') as String;
	String ObjectIDList;
	String ParentObjectId = "ParentObjectID eq ";
	String OR = " or ";
	
    EntitySetFeildConfig.d.results.each{
        if(actionCode == '01'){
            if(it.IsCreatable == true){
            it.remove('__metadata');  
                if(ObjectIDList == null){
                    ObjectIDList = ParentObjectId + "'" + it.ObjectID + "'" + OR
	            }else{
		            ObjectIDList = ObjectIDList + ParentObjectId + "'" + it.ObjectID + "'" + OR
	            }
	            
	            tempArray.add(it);
            }
        }else{
            // Update Case
            if(it.IsUpdatable == true || it.IsKey == true){
                it.remove('__metadata');
                    if(ObjectIDList == null){
                        ObjectIDList = ParentObjectId + "'" + it.ObjectID + "'" + OR
	                }else{
		                ObjectIDList = ObjectIDList + ParentObjectId + "'" + it.ObjectID + "'" + OR
	                }      
	            
	            tempArray.add(it);
            }
        }
        
    }
    if(ObjectIDList != null){
        String finalResult = ObjectIDList.substring(0,ObjectIDList.lastIndexOf(" or "));
        message.setProperty("ParentIDFilterString",finalResult);
    }
    finalObj <<[EntitySetFeildConfig:tempArray];
    
	JsonBuilder builder = new JsonBuilder(finalObj.EntitySetFeildConfig);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
    message.setBody(jsonBody);
	message.setProperty("EntitySetFeildConfig",jsonBody);
	return message;

}