import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    
    def body = message.getBody(String.class);
    def parseObjEntityFieldset = new JsonSlurper().parseText(body);
    // Redeing the Properties
    def map = message.getProperties();
    String EntitySetFeildConfig = map.get('EntitySetFeildConfig') as String;

    // Parsing as Json Obj
    def fieldSetConfig = new JsonSlurper().parseText(EntitySetFeildConfig);	

    def finalObj = new JsonSlurper().parseText('{}');
    def objID;
    
    //Iterating two arrays to get the final array
    Iterator<String> it = fieldSetConfig.iterator();
    def element;
    while (it.hasNext()) {
        element = it.next();
        objID = element.ObjectID;
        parseObjEntityFieldset.d.results.each{
            if(it.ParentObjectID == objID){
                element.EntityFieldDisplayName = it.DisplayNameDescription
                element.PlaceholderDescription = it.PlaceholderDescription
                element.ToolTipDescription = it.ToolTipDescription
            }
        }
    }

    finalObj <<[fieldSetConfig:fieldSetConfig];

	JsonBuilder builder = new JsonBuilder(finalObj);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
    message.setBody(jsonBody);
	return message;
}