import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
     //Get Body and parse it.
       def body = message.getBody(java.lang.String)as String;
      
       message.getProperties().put("error message",body);
       
       return message;
       
}