import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
// 	def map = message.getProperties();
// 	String priorityBody = map.get('priorityBody') as String;
// 	def processingTypeCode = new JsonSlurper().parseText(body);
// 	def priority = new JsonSlurper().setType(JsonParserType.LAX).parseText(priorityBody);
// 	def finalObj = new JsonSlurper().parseText('{}');
	
// 	priority.d.results.each{
//     it.remove('__metadata');
//     }
    
//     processingTypeCode.d.results.each{
//     it.remove('__metadata');
//     }
    
//     finalObj <<[priority:priority.d.results];
//     finalObj <<[processingTypeCode:processingTypeCode.d.results];

// 	JsonBuilder builder = new JsonBuilder(finalObj);
//     String jsonBody = JsonOutput.prettyPrint(builder.toString());
//     message.setBody(jsonBody);

def sampleMessage = "This is Groovy"; 
	return sampleMessage;
}