import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
     
       def body = message.getBody(java.lang.String)as String;
       def error_msg = "error";
     
       message.getProperties().put("error message","");
       
       if(body.contains("NO_ACTIVE_PROFILE")){
           error_msg = "NO_ACTIVE_PROFILE";
       }else if(body.contains("NO_ACTIVE_ENTITY_SET")){
           error_msg = "NO_ACTIVE_ENTITY_SET";
       }else{
           error_msg = "WRONG_CONFIG";
       }
       
       message.getProperties().put("error message",error_msg);
       return message;
       
}