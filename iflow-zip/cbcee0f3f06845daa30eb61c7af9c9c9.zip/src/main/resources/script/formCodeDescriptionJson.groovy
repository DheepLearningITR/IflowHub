import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def map = message.getProperties();
	def CodeListBody = new JsonSlurper().parseText(body);
	def finalObj;
	def finalResult = new JsonSlurper().parseText('{}');
	
	CodeListBody.d.results.each{
    it.remove('__metadata');
    }
	
	finalObj = map.get('codelistArr');
	//finalObj = new JsonSlurper().parseText(codelistArr);
	def loopCondition = map.get('LoopCondition');
	def key = map.get('codeListKey');
	if(finalObj == '{}'){
	    finalObj = new JsonSlurper().parseText('{}');
	}
	finalObj <<[(key):CodeListBody.d.results];
	if(loopCondition == 'false'){
	    //finalResult <<[CodeListValues:finalObj];
	    JsonBuilder builder = new JsonBuilder(finalObj);
        String jsonBody = JsonOutput.prettyPrint(builder.toString());
        message.setBody(jsonBody);
	}else{
	    message.getProperties().put("codelistArr",finalObj)
	}

	return message;
}