/**
 * This script is used to handle the exceptions raised at any of the steps 
 * 
 * Change Details
 * 
 * Date		  |	Information
 * ------------------------------------------------------------------------ 
 * 13-08-2017 | Initial Version
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder

def Message processData(Message message) {
	def map = message.getHeaders();
	def map1 = message.getProperties();
	def ex = map1.get("CamelExceptionCaught");
	def jsonString = new JsonBuilder();

	map.put("Content-Type",   "application/json");
	map.put("CamelHttpResponseCode",   200);

	if (ex!=null) {

		if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
			message.setProperty("status", "0");
			message.setProperty("errorCodes", "502");
		} 
		else if (ex.getClass().getCanonicalName().equals("com.sap.esb.datastore.MessageNotFoundException")) {
			message.setHeader("AUTH", "X");
		}
		else if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.directvm.DirectVmConsumerNotAvailableException")) {
			message.setProperty("status", "0");
			message.setProperty("errorCodes", "503");
		} 
		else {
			if (ex.toString().contains("com.sap.it.nm.types.NodeManagerException")) {
				message.setProperty("status", "0");
				message.setProperty("errorCodes", "501");
			}
			else {
				message.setProperty("status", "0");
				message.setProperty("errorCodes", "500");
			}			
		}
	}

	return message;
}