import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    // Get the XML body
    def body = message.getBody(java.lang.String);
    
    // Parse the XML payload
    def xmlSlurper = new XmlSlurper();
    def xml = xmlSlurper.parseText(body);

    // Process the "longDesciptions" node
    if (xml.JobProfile.longDesciptions) {
        xml.JobProfile.longDesciptions.JobProfileLocalizedData.children().each { node ->
            if (node.name().startsWith('desc_')) {
                def desc = trimWhitespacesInHtmlTags(node.text());
                node.replaceBody(truncateHtml(desc, 3800)); 
            }
        }
    }

    message.setBody(XmlUtil.serialize(xml));
    return message;
}


def trimWhitespacesInHtmlTags(String input) {
    // Define a regular expression to match HTML tags with optional spaces
    def regex = /<(\w+)([^>]*)\s*(\/?)>/
    
    // Replace the matched HTML tags with trimmed versions
    def output = input.replaceAll(regex) { match ->
        def tagName = match[1] // Extract tag name (e.g., 'br')
        def attributes = match[2] // Extract attributes
        def selfClosing = match[3] // Extract self-closing slash
        
        // Reconstruct the tag with trimmed spaces
        "<${tagName}${attributes.trim()}${selfClosing}>"
    }
    
    // Replace <\/ with </
    //when there's embedded html tags in XML "<desc_en_US>development&lt;/p&gt;</desc_en_US>" and converted to JSON, it ends up with: 
    output = output.replaceAll(/<\\\//, '</')
    
    return output
}

String truncateHtml(String html, int limit) {
    
    if (html.length() <= limit) {
        // If the input is already within the limit, return it as is
        return html
    }
    
    int length = 0
    StringBuilder result = new StringBuilder()
    Stack<String> openTags = new Stack<>()

    // Regular expression to match HTML tags and text
    def matcher = (html =~ /(<\/?\w+[^>]*>)|([^<]+)/)

    while (matcher.find()) {
        String tag = matcher.group(1)
        String text = matcher.group(2)

        if (tag != null) {
            // Handling the HTML tag part
            if (tag.startsWith("</")) {
                // Closing tag: pop from open tags if it's valid
                String tagName = tag.replace("</", "").replace(">", "")
                if (!openTags.isEmpty() && openTags.peek().equals(tagName)) {
                    openTags.pop()
                    if (length + tag.length() > limit) break
                    result.append(tag)
                    length += tag.length()
                }
            } else if (tag.endsWith("/>")) {
                // Self-closing tag (e.g., <br/>)
                if (length + tag.length() > limit) break
                result.append(tag)
                length += tag.length()
            } else {
                // Opening tag: push to open tags stack
                String tagName = tag.replace("<", "").replace(">", "").split(" ")[0]
                openTags.push(tagName)
                if (length + tag.length() > limit) break
                result.append(tag)
                length += tag.length()
            }
        } else if (text != null) {
            // Handling the text part
            int remaining = limit - length
            int charsToTake = Math.min(remaining, text.length())
            result.append(text.take(charsToTake))
            length += charsToTake
            if (length >= limit) break
        }
    }

    // Close only those tags that were opened during the truncation process
    while (!openTags.isEmpty()) {
        String tagName = openTags.pop()
        result.append("</").append(tagName).append(">")
    }

    return result.toString()
}
