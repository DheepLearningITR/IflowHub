import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
	    def testRun = message.getHeaders().get("testRun");
		if(testRun != null && testRun != 'false' && testRun != ''){
			messageLog.addCustomHeaderProperty("cbr_testRun", testRun);		
        }
		def jobProfileId = message.getProperties().get("cbrJobProfileId");
		if(jobProfileId){
			messageLog.addCustomHeaderProperty("cbr_jobProfileId", jobProfileId);		
        }
        def extCode = message.getProperties().get("sfsfJobProfileExtCode");
		if(extCode){
			messageLog.addCustomHeaderProperty("sfsf_jobProfileExtCode", extCode);		
        }
        def sfsfRoleExtCode = message.getProperties().get("sfsfRoleExtCode");
		if(sfsfRoleExtCode){
			messageLog.addCustomHeaderProperty("sfsf_RoleExtCode", sfsfRoleExtCode);		
        }        
        def sfsfJobProfileStatus = message.getProperties().get("sfsfJobProfileStatus");
		if(sfsfJobProfileStatus){
			messageLog.addCustomHeaderProperty("sfsf_JobProfileStatus", sfsfJobProfileStatus);		
        }
	}
	return message;
}
