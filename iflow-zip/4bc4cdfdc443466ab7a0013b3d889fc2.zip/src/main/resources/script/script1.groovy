import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import groovy.json.*

def Message processData(Message message) {
    //Body 
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper()
    def list = jsonSlurper.parseText(body)
    
    // Default datetime
    String defaultTime =  ' 00:00:00';
    
    // Date time format
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
   
    // Batch Payload 
    String completePayload = "";
  
    // Generate Random Id to be used in Batch Code
    String batchId = UUID.randomUUID().toString();
  
    // Prepare Batch Code
    String batchCode = "batch_" + batchId; 
    
    //get all the Headers of the message
    def map = message.getHeaders();
    //Reading SSID header from collection
    String sourceSystemId = map.get("SSID");
   
    list.ContractExecutionPlans.ContractExecutionPlan.each
    {   
        
       if (it.creationDate == '') 
        {
            it.creationDate = null
        }   else{
            it.creationDate =  ('/Date(').concat(((sdf.parse((it.get('creationDate').toString()).concat(defaultTime))).getTime()).toString()).concat(')/')
        }
        // Remove empty string
        it.contractExecutionPlanItems.remove('')
        
        it.contractExecutionPlanItems.each
        {
            if (it.dateFrom == '') {
                it.dateFrom = null
            } else {
                it.dateFrom =  ('/Date(').concat(((sdf.parse((it.get('dateFrom').toString()).concat(defaultTime))).getTime()).toString()).concat(')/')
            }

            if (it.dateTo == '') {
                it.dateTo = null
            } else {
                it.dateTo =  ('/Date(').concat(((sdf.parse((it.get('dateTo').toString()).concat(defaultTime))).getTime()).toString()).concat(')/')
            }
            
            if (it.loadingDate == '') {
                    it.loadingDate = null
            } else {
                it.loadingDate =  ('/Date(').concat(((sdf.parse((it.get('loadingDate').toString()).concat(defaultTime))).getTime()).toString()).concat(')/')
            }
                
                it.contractExecutionPlanItemUoMConversions.remove('')
        
                it.contractExecutionPlanItemUoMConversions.each
                {   
                    it.orderQuantity = handleDoubleQuantity(it.get('orderQuantity').toString(), true)
                    
                    if(it.isOriginalUnitOfMeasure == "True")
                    {
                        it.isOriginalUnitOfMeasure = true
                    }
                    else
                    {
                        it.isOriginalUnitOfMeasure = false
                    }
                }
                
                // Remove empty string
                it.tradingContractLinks.remove('')
        
                it.tradingContractLinks.each
                {
                    it.baseQuantity = handleDoubleQuantity(it.get('baseQuantity').toString(), true)
                    
                    it.tradingContractLinkUoMConversions.remove('')
                    it.tradingContractLinkUoMConversions.each
                    {   
                        it.callOffQuantity = handleDoubleQuantity(it.get('callOffQuantity').toString(), true)
                        
                        if(it.isOriginalUnitOfMeasure == "True")
                        {
                            it.isOriginalUnitOfMeasure = true
                        }
                        else
                        {
                            it.isOriginalUnitOfMeasure = false
                        }
                    }
                }   
                
                // Remove empty string
                it.deliveryAssignments.remove('')
        
                it.deliveryAssignments.each
                {
                    it.deliveryAssignmentUoMConversions.remove('')
                    it.deliveryAssignmentUoMConversions.each
                    {   
                        it.deliveredQuantity = handleDoubleQuantity(it.get('deliveredQuantity').toString(), true)
                        
                        if(it.isOriginalUnitOfMeasure == "True")
                        {
                            it.isOriginalUnitOfMeasure = true
                        }
                        else
                        {
                            it.isOriginalUnitOfMeasure = false
                        }
                    }
                }   
                
        }
        
        
        String changeset = "changeset_0"
        
        // Prepare Payload for containing employee id in current loop pass
        String tempPayload = "--batch_" + batchId + "\r\n"
        tempPayload = tempPayload + "Content-Type: multipart/mixed; boundary=" + changeset + "\r\n" + "\r\n"
        tempPayload = tempPayload + "--" + changeset + "\r\n"
        tempPayload = tempPayload + "Content-Type: application/http " + "\r\n" + "Content-Transfer-Encoding:binary" + "\r\n" + "\r\n"
        
        tempPayload = tempPayload + "PUT ContractExecutionPlan(sourceSystemId='" + sourceSystemId.toString() + "',contractExecutionPlanNumber='" + it.contractExecutionPlanNumber.toString() + "',orderType='" + it.orderType.toString() + "') HTTP/1.1" + '\r\n' + 'Content-Type: application/json' + '\r\n' + '\r\n'

        
        def jsonOP = JsonOutput.toJson(it)
        
        tempPayload = tempPayload + jsonOP.toString() + "\r\n"
        tempPayload = tempPayload + "--" + changeset + "--" + "\r\n" + "\r\n"
        
        // Add the above payload in complete payload
        completePayload=completePayload.concat(tempPayload)
    
    }
    
    // Close the full payload
    completePayload = completePayload + "--batch_" + batchId + "--" + "\r\n"
    
    // Prepare Message Body
    message.setBody(completePayload)
    
    // Prepare Boundary Header Parameter to be added in message header
    String boundaryParam = "multipart/mixed; boundary=" + batchCode;
    
    // Prepare Message Header
    message.setHeader('Content-Type', boundaryParam)

    // save the BTP Payload as a message property 
    message.setProperty("BTP_Payload", "CEP_Payload: " + completePayload);
    
    return message
    
}

def handleDoubleAmount(fieldValue, precision20Required=false) {
    if (fieldValue == '' || fieldValue == null) {
        fieldValue = null
    }
    else
    {
        fieldValue = Double.parseDouble(fieldValue.toString())
        fieldValue = precision20Required ? String.format('%.20f', fieldValue) : String.format('%.2f', fieldValue)
        fieldValue.toString()
    }
}


      
def handleDoubleQuantity(fieldValue, precision20Required=false) {
    if (fieldValue == ''|| fieldValue == null) {
        fieldValue = null
    }
    else
    {
        fieldValue = Double.parseDouble(fieldValue.toString())
        fieldValue = precision20Required ? String.format('%.20f', fieldValue) : String.format('%.3f', fieldValue)
        fieldValue.toString()
    }
}