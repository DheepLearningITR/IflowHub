import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper 
import groovy.json.JsonOutput
import java.util.regex.*
def Message processData(Message message) {
    //Body 
       //Body 
        def body = message.getBody(String.class);
        def map = message.getHeaders();
        def pattern = ~'2..';
        def jsonSlurper = new JsonSlurper();
        def jsonObject = jsonSlurper.parseText(body);
        def lst = [];
        def httpResponseCode = map.get("CamelHttpResponseCode");
        def responseObj = jsonObject.batchPartResponse.batchChangeSetResponse.batchChangeSetPartResponse;
        
       // Filtering the batch response where statusCode is not of series 200 so that we could propogate the statusCode to the header
       
        if( responseObj.getClass() == java.util.ArrayList ) {
            // if there are multiple batchPartResponse
            def err = responseObj.findAll { obj -> !pattern.matcher(obj.statusCode).matches() };
            err.each { lst.add(JsonOutput.toJson(it)) }
            if ( lst.length ) {
                message.setHeader("CamelHttpResponseCode", lst[0].statusCode);
            }
            return message;
        } else if ( !pattern.matcher(responseObj.statusCode).matches() ) {
            
            //There is a single batchPartResponse
            message.setHeader("CamelHttpResponseCode", responseObj.statusCode);
            return message;
        }
       return message;
}