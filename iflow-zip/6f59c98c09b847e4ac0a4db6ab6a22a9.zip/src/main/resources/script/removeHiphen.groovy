def String removeHiphen(String uuid){
    uuid = uuid.replaceAll("-","");
	return uuid; 
}