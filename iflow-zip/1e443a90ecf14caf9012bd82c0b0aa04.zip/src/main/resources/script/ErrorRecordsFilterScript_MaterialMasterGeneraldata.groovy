import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {

	def body = message.getBody(String.class);
	def output;
	message.setProperty("isError", "true");
     
	//Setting the timestamp
	def now = new Date();
	message.setProperty("timestamp", now.format("yyyyMMddHHmmss", TimeZone.getTimeZone('UTC')));
	
	//parsing error message
	output = getErrorResponse(body); 
	if(!body.contains('error')) {
		message.setProperty("isError", "false");
	}
	message.setBody(output);
    
	return message;
}

def String getErrorResponse(String response) {

    def jsonSlurper = new JsonSlurper()
	def sb = new StringBuilder("{\"row\":[");
	def errMsg, errObj, data, records;
    int seqNumber = 1;

	response.split("HTTP/1.1").each { unit ->
	if(!"$unit".contains("201 Created") && !"$unit".startsWith("--changeset")) {
				errMsg = "$unit".substring("$unit".indexOf("{\"error\""), "$unit".indexOf("--changeset")).trim()
                errObj = jsonSlurper.parseText(errMsg)
				data = jsonSlurper.parseText(errObj.error.details.message[0])
				
				sb.append("{\"SNo\": \""+ seqNumber +"\",");
				sb.append("\"Status\": \"Error\",");
				sb.append("\"message\": \""+ errObj.error.message +"\",");
				sb.append("\"Material Code\": \""+ data.materialCode +"\",");
				sb.append("\"Material Description\": \""+ data.materialDescription +"\",");
				sb.append("\"Material Type\": \""+ data.materialType +"\",");
				sb.append("\"Material Group\": \""+ data.materialGroup +"\",");
				sb.append("\"Division\": \""+ data.division +"\",");
				sb.append("\"xPlant Material Status\": \""+ data.xPlantMaterialStatus +"\",");
				sb.append("\"Valid From\": \""+ data.validFrom +"\",");
				sb.append("\"Gross Weight\": \""+ data.grossWeight +"\",");
				sb.append("\"Net Weight\": \""+ data.netWeight +"\",");
				sb.append("\"Volume\": \""+ data.volume +"\",");
				sb.append("\"Size Dimensions\": \""+ data.sizeDimensions +"\",");
				sb.append("\"EAN_UPC\": \""+ data.EAN_UPC +"\",");
				sb.append("\"EAN Categary\": \""+ data.EANCategary +"\",");
				sb.append("\"Product Composition Indicator\": \""+ data.productCompositionIndicator +"\",");
				sb.append("\"Packaging Material Group\": \""+ data.packagingMaterialGroup +"\",");
				sb.append("\"Base Unit Of Measure\": \""+ data.baseUnitOfMeasure_code +"\",");
				sb.append("\"Weight Unit\": \""+ data.weightUnit_code +"\",");
				sb.append("\"Volume Unit\": \""+ data.volumeUnit_code +"\",");
				sb.append("\"materialSerialManaged_ID\": \""+ data.materialSerialManaged_ID +"\"");
				sb.append("},");
				seqNumber=seqNumber+1; 				
		}        
	}
	
	records = sb.toString();
	records = records.substring(0, records.length()-1)+"]}";
	return records;
}