import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def productId = message.getProperty("s4hana_product_id");
    List<String> missingProductsId = message.getProperty("missing_products_id") as List<String>;

    if(!missingProductsId.contains(productId)) {
        missingProductsId.add(productId);
    }
    message.setProperty("missing_products_id", missingProductsId);

    return message;
}