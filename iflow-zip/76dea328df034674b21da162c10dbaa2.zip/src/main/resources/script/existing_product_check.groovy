import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def bigcommerceProductList = message.getProperty("bigcommerce_product_list") as String
    def s4hanaProductId = message.getProperty("s4hana_product_id") as String
    def existingProduct = 'false'

    def slurper = new JsonSlurper()
    def parsedJson = slurper.parseText(bigcommerceProductList)
    
    for (product in parsedJson.data) {
        if (product.sku == s4hanaProductId) {
            message.setProperty("bc_variant_id", product.base_variant_id.toString())
            message.setProperty("bc_product_id",  product.id.toString())
            message.setProperty("bc_inventory_level", product.inventory_level.toString())
            existingProduct = true
            break
        }
    }

    message.setProperty("existing_product", existingProduct.toString())
    return message
}
