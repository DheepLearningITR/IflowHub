import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    List<String> listOfStrings = new ArrayList<String>();
    message.setProperty("missing_products_id", listOfStrings)
    return message;
}