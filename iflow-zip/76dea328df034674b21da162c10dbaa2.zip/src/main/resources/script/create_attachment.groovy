import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message)
{
    def messageLog = messageLogFactory.getMessageLog(message);
    def missingProductsId = message.getProperty("missing_products_id") as List<String>

    if(messageLog != null && missingProductsId.size() > 0)
    {
        def missingProductsIdString = missingProductsId.join("\n")
        messageLog.addAttachmentAsString("Missing SAP S/4HANA Cloud Products in BigCommerce:", missingProductsIdString, "text/plain");
    }

    return message;
}