import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    String existingJson = message.getProperty("bigcommerce_product_list") as String
    def slurper = new JsonSlurper()
    List existingData = []

    if (existingJson?.trim()) {
        try {
            def parsed = slurper.parseText(existingJson)
            existingData = (parsed.data instanceof List) ? parsed.data : []
        } catch (Exception e) {
            existingData = []
        }
    }

    String responseBody = message.getBody(String) as String
    def page = slurper.parseText(responseBody)
    List incoming = (page.data instanceof List) ? page.data : []

    def newData = existingData + incoming
  
    def accumulator = [data: newData]
    String pretty = new JsonBuilder(accumulator).toPrettyString()
    message.setProperty("bigcommerce_product_list", pretty)

    return message
}