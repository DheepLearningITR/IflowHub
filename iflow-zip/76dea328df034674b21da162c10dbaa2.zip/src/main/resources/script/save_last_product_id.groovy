import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def slurper = new JsonSlurper()
    def json = slurper.parse(body)

    message.setProperty("last_page_response", JsonOutput.toJson(json))

    def pag = json.meta?.pagination
    if (pag) {
        int currentPage = pag.current_page as int
        int totalPages = pag.total_pages as int

        if (currentPage < totalPages) {
            message.setProperty("products_next_page", (currentPage + 1).toString())
        } else {
            message.setProperty("last_product_reached", "true")
        }
    } else {
        message.setProperty("last_product_reached", "true")
    }

    def items = (json.data instanceof List) ? json.data : []
    if (!items.isEmpty()) {
        message.setProperty("last_product_id", items[-1].id.toString())
    }

    return message
}
