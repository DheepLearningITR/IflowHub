import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message)
 {
     
	def body = message.getBody(String.class);
	
	if (body == '{"issueUpdates":[]}'){
	    message.setBody("<ROOT>SKIP</ROOT>");
	} else {
	    message.setBody("<ROOT>"+body+"</ROOT>");
	}
    return message;

}