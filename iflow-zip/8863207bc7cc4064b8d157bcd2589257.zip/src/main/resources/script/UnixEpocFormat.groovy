import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone

def String EpochFormatDateTime(String arg1) {
    // Define the date format to handle milliseconds and timezone offset
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    
    // Parse the input date considering its own timezone
    Date date = df.parse(arg1)
    
    // Get epoch time in milliseconds
    long epochMillis = date.getTime()
    
    // Convert to epoch seconds
    long epochSeconds = epochMillis / 1000
    
    // Return the epoch time as a string
    return String.valueOf(epochSeconds)
}
