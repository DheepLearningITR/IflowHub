import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.gateway.ip.core.customdev.util.AttachmentWrapper
import java.util.Map
import javax.activation.DataHandler
import org.apache.camel.impl.DefaultAttachment
import javax.mail.util.ByteArrayDataSource
import groovy.xml.*
import org.apache.commons.io.IOUtils

def Message writeAttachmentList(Message message) {

    //Map<String, DataHandler> attachments = message.getAttachments() - Read AttWrappers instead of Att
    Map<String, DataHandler> attachments = message.getAttachmentWrapperObjects()
    
    if (!attachments.isEmpty()) {

        def writer = new StringWriter()
        def listxml = new MarkupBuilder(writer)
		String liststring = ""
       
        listxml.AttachmentList(){
            for ( object in attachments ) {
                
                //read DataHandler from Wrapper
                DataHandler dh = object.value.getDataHandler()
                
				//attName = object.value.getName()
				//attType = object.value.getContentType()
				//attByteContent = object.value.getContent().bytes
				//attCid = object.key
				
				//Read attachment information from wrapper instead of object
				attName = dh.getName()
				attType = dh.getContentType()
				//attByteContent = dh.getContent().bytes
				attByteContent = IOUtils.toByteArray(dh.getInputStream())
				attCid = object.value.getHeader("Content-ID").replaceAll('^\\<|\\>$','')
				
				liststring += "cid:" + attCid + ";" + attName + ";" + attType + ";" + attByteContent.length + "|"
                Attachment(){
                    AttachmentName(attName)
                    AttachmentType(attType)
                    AttachmentID(attCid)
                    AttachmentContent(attByteContent.encodeBase64().toString())
                }
	    	}
        }
        message.setProperty("AttachmentList",writer.toString())
		message.setProperty("cXMLAttachments",liststring)
		message.setHeader("hasAttachments", "YES")
    }

	//clear attachments from message
	return clearAttachments(message)
}

def Message readAttachmentList(Message message) {

    def xml = new XmlSlurper().parse(message.getBody(Reader))

    AttachmentList = xml.'**'.find{it.name() == 'AttachmentList'}
    if (AttachmentList) {

       AttachmentList.'*'.findAll{it.name() == 'Attachment'}.each{

            def attachmentDataSource = new ByteArrayDataSource(it.AttachmentContent.text().bytes, it.AttachmentType.text())
            attachmentDataSource.setName(it.AttachmentName.text())
            def attachment = new DefaultAttachment(attachmentDataSource)
			attachment.setHeader('Content-Transfer-Encoding', 'base64')
            attachment.setHeader('Content-Disposition', 'attachment; filename=\"' + java.net.URLEncoder.encode(it.AttachmentName.text(), "UTF-8") + '\"')
            attachment.setHeader('Content-ID', it.AttachmentID.text())
            message.addAttachmentObject('attachment', attachment)

        }
    }
    return message
}

def Message clearAttachments(Message message) {

	Map<String, DataHandler> attachments = message.getAttachments();
	Map<String, AttachmentWrapper> attachmentWrappers = message.getAttachmentWrapperObjects();

	attachmentWrappers.clear();
	attachments.clear();

	message.setAttachments(attachments);
	message.setAttachmentWrapperObjects(attachmentWrappers);
	
	return message
}

def Message writeAttachmentListMTOM(Message message) {

    Map<String, DataHandler> attachments = message.getAttachments()
    if (!attachments.isEmpty()) {

        def cxml = new XmlSlurper().parse(message.getBody(Reader))

        def writer = new StringWriter()
        def listxml = new MarkupBuilder(writer)
       
        listxml.AttachmentList(){
            for ( object in attachments ) {
				cid = object.value.getName()
				mtom = cxml.'**'.find{it.Include.@href == cid}
                Attachment(){
                    AttachmentName(mtom.@FileName)
                    AttachmentType(mtom.@MimeType)
                    AttachmentID(cid)
                    AttachmentContent(object.value.getContent().bytes.encodeBase64().toString())
                }
	    	}
        }
        message.setProperty("AttachmentList",writer.toString())
    }

   return message
}

def Message replaceContent(Message message) {

    def Payload = new XmlSlurper().parse(message.getBody(Reader))
    String List = message.getProperty('AttachmentList')
    if (List) { 
        def AttachmentList = new XmlSlurper().parseText(message.getProperty('AttachmentList'))
        AttachmentList.Attachment.each{ Attachment -> 
            Payload.'**'.find{it.FileName == Attachment.AttachmentName}.'Content' = Attachment.AttachmentContent.text()
        }
    }
    message.setBody(XmlUtil.serialize(Payload))
    return message
}
