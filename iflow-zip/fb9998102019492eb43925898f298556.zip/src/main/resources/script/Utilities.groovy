import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def Message removeCIGEndpoint(Message message) {
    
	def xml = new XmlParser(false,false).parse(message.getBody(Reader));

    cig = xml.'**'.Credential.find{it.@domain == 'EndPointID' && it.Identity.text() == 'CIG'}
    if (cig) cig.replaceNode{};

	message.setBody(XmlUtil.serialize(xml))
    return message;
}

def Message removeEmptyHeaders(Message message) {

    headers = message.getHeaders()
    headers.values().remove('')

    return message
}

def Message throwBodyAsException(Message message) {
    
    String body = message.getBody(String)
    
    throw new Exception(body);
}
