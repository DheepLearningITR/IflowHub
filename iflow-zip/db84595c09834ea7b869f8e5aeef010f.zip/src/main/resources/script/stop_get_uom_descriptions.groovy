import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.time.TimeCategory; 
import groovy.time.TimeDuration;
import java.util.Date;



def Message SetStopTime(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    def headers = message.getHeaders();

//get time stamps    
    Date stop = new Date();
    def start_time = headers.get("start_get_uom_descriptions");
    
//parse start time    
    def parsed = Date.parse("E MMM dd H:m:s z yyyy", start_time)

//calculate runtime    
    TimeDuration minus = TimeCategory.minus( stop,parsed );

//format runtime    
    def runtime = new Date(minus.toMilliseconds()).format("HH:mm:ss.SSS")

//set runtime log
    String result = headers.get("header.runtime") + "\nS4;Get UoM Descriptions Start;" + start_time.toString() +";" + stop.toString() + ";"+ runtime.toString();
    message.setHeader("header.runtime", result);

    return message;
}
