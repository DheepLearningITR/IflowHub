/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    def headers = message.getHeaders();
	    
	    def headerWriteBatches = new StringReader(headers.get('IBPWriteBatches'));
        def xmlBatches = new XmlSlurper().parse(headerWriteBatches);
        def bodyAsString = message.getBody(java.lang.String);
        def bodyReader = new StringReader(bodyAsString );
        def xmlResponses = new XmlSlurper().parse(bodyReader);
	    
/*	    def numberOfBatches = xmlBatches?.Batch.size();
	    def numberOfSuccessfullBatches = xmlResponses?.Batch.findAll{it.@WorstProcessingStatus == 'PROCESSED'}.size();
	    def numberOfContentErrorBatches = xmlResponses?.Batch.findAll{it.@WorstProcessingStatus == 'PROCESSED_WITH_ERRORS'}.size();
	    message.setProperty('IBPWorstProcessingStatus', numberOfBatches == numberOfSuccessfullBatches ? 'PROCESSED': numberOfBatches == numberOfSuccessfullBatches + numberOfContentErrorBatches ? 'PROCESSED_WITH_ERRORS': 'TechnicalError');
	    xmlResponses?.Batch.each { messageLog.addCustomHeaderProperty("IBP Write Batch Times", 'id:' + it.@Id + ', created:' + it.@CreatedAt + ', scheduled:' + it.@ScheduledAt + ', started:' + it.@ProcessingStartedAt + ', ended:' + it.@ProcessingEndedAt) }
        xmlResponses?.Batch.each { messageLog.addCustomHeaderProperty("IBP Write Batch Details", 'id:' + it.@Id + ', key:' + it.@Key + ', destination:' + it.@Destination + (it.@Name!=''? ', name:' : '') + it.@Name + (it.@CreatedBy!=''? ', createdBy:' : '') + it.@CreatedBy  ) }
	    xmlResponses?.Batch.each { messageLog.addCustomHeaderProperty("IBP Write Batch Status", 'id:' + it.@Id + ', worstProcessingStatus:' + it.@WorstProcessingStatus + ', scheduleStatus:' + it.@ScheduleStatus ) };
*/
	    xmlResponses?.Batch?.Packages?.Package.each { messageLog.addCustomHeaderProperty("IBP Write Batch Package", 'batch:' + it.parent().parent().@Id + ', package:' + it.@Id + ', count:' + it.@Count + ', status:' + it.@Status + (it.@ErrorCount!='' ? ', errorCount:' : '') + it.@ErrorCount) };
	    xmlResponses?.Batch?.Packages?.Package.findAll {it.@FirstError!=''}.each{ addLogCustomHeaderWithSplit(messageLog,"1st Validation Error " + it.parent().parent().@Id.text() + ',' + it.@Id.text(), it.@FirstError.text()) };
	    xmlResponses?.Batch?.Packages?.Package.findAll {it.@FirstErrorLong!=''}.each { addLogCustomHeaderWithSplit(messageLog,"1st Long Validation Error " + it.parent().parent().@Id.text() + ',' + it.@Id.text(), it.@FirstErrorLong.text()) };


	    xmlResponses?.Batch?.ScheduleException.each { addLogCustomHeaderWithSplit(messageLog,"IBP Schedule Exeption " + it.parent().@Id.text(), it.text()) };
	    xmlResponses?.Batch?.ScheduleException.findAll {it.@FailureEndpoint!=''}.each { addLogCustomHeaderWithSplit(messageLog,"IBP Schedule Failure Endpoint " + it.parent().@Id.text(), it.@FailureEndpoint.text()) };
	    xmlResponses?.Batch?.ScheduleException.findAll {it.@FailureRouteId!=''}.each { addLogCustomHeaderWithSplit(messageLog,"IBP Schedule Failure Route ID " + it.parent().@Id.text(), it.@FailureRouteId.text()) };
	    xmlResponses?.Batch?.ScheduleResponse.each {
	        it.Messages?.Message.eachWithIndex { it2, index -> addLogCustomHeaderWithSplit(messageLog,"IBP Schedule " + it.@Id.text() + ' ' + it2.@Type.text() + ' ' + (index +1).toString(), it2.text()) }
	    }

	    xmlResponses?.Batch?.GetStatusException.each { addLogCustomHeaderWithSplit(messageLog,"IBP Get Status Exception " + it.parent().@Id.text(), it.text()) };
	    xmlResponses?.Batch?.GetStatusException.findAll {it.@FailureEndpoint!=''}.each { addLogCustomHeaderWithSplit(messageLog,"IBP Get Status Failure Endpoint " + it.parent().@Id.text(), it.@FailureEndpoint.text()) };
	    xmlResponses?.Batch?.GetStatusException.findAll {it.@FailureRouteId!=''}.each { addLogCustomHeaderWithSplit(messageLog,"IBP Get Status Failure Route ID " + it.parent().@Id.text(), it.@FailureRouteId.text()) };
	    xmlResponses?.Batch.each {
	        it.Messages?.Message.eachWithIndex { it2, index -> addLogCustomHeaderWithSplit(messageLog,"IBP Process " + it.@Id.text() + ' ' + it2.@Type.text() + ' ' + (index +1).toString(), it2.text()) }
	    }
	    
	    messageLog.addAttachmentAsString('Processing Results', bodyAsString, 'text/xml')	
	}
	return message;
}

def void addLogCustomHeaderWithSplit(MessageLog messageLog, String headerName, String content) {
    def messageLength = content.length();
    if (messageLength<=198) messageLog.addCustomHeaderProperty(headerName, content);
    else {
        int i = 0;
        for (int j = 0; j < messageLength;j += 198) {
            def k = j + 198;
            i++;
            messageLog.addCustomHeaderProperty(headerName + '.' + i.toString(), content.substring(j,k<=messageLength?k:messageLength));
        }
    }
}
