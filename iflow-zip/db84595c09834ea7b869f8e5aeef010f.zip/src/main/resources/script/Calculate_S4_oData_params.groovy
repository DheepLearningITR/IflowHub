/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.lang.String;
import com.sap.it.api.mapping.*;


def Message processData(Message message) {
    def headers = message.getHeaders();
    def props = message.getProperties();

    def plants = (headers.get("PlantFilter")?:'').tokenize(',');
    def products = (headers.get("ProductFilter")?:'').tokenize(',');
    
    def productPlantNodeShortcut = props.get('S4ProductPlantNodeShortcut') ?: '';
    def supplyPlanningNodeShortcut = props.get('S4ProductPlantSupplyPlanningNodeShortcut') ?: '';
    def productShortcutString = props.get('S4ProductNodeShortcut') ?: '';

    def productPlantFurtherFilters = ('(' + (headers.get('FurtherFiltersforPlants')?:'') + ')').replaceFirst('^[(][)]$','');
    def productFurtherFilters = ('(' + (headers.get('FurtherFiltersforProducts')?:'') + ')').replaceFirst('^[(][)]$','');

        
    String eqString = '';
    String betweenString = '';
    String plantIdFilter = '';
    String productIdFilter = '';
    String locationIdFilter = '';
    String eqStringShortcut = '';
    String betweenStringShortcut = '';
    String plantFilterShortcut = '';
    def severalSingletons = false;
    def severalIntervals = false;
    def pattern = '(?<=(?:^|-))(([^-\"]*?)|(\"(?:[^\"]+|\"\")*\"))(?=(?:-|$))';
    
    def plantFilters=[];
    for (plant in plants) {
        def singlePlants = plant.findAll(pattern);
        plantFilters += (singlePlants.size() <= 1) ? "sp/Plant eq '${singlePlants[0].replaceAll('^\"|\"$','')}'":"sp/Plant ge '${singlePlants[0].replaceAll('^\"|\"$','')}' and sp/Plant le '${singlePlants[1].replaceAll('^\"|\"$','')}'";
    }
    
    def productFilters=[];
    for (product in products) {
        def singleProducts = product.findAll(pattern);
        productFilters += (singleProducts.size() <= 1) ? "Product eq '${singleProducts[0].replaceAll('^\"|\"$','')}'":"Product ge '${singleProducts[0].replaceAll('^\"|\"$','')}' and Product le '${singleProducts[1].replaceAll('^\"|\"$','')}'";
    }
    
    
    
    def plantMergedFilters = '';
    if (plantFilters.size() > 0) plantMergedFilters = '(' + plantFilters.join(' or ') + ')';
    
    def productMergedFilters = '';
    if (productFilters.size() > 0) productMergedFilters= '(' + productFilters.join(' or ') + ')';
    

    
    


    def strategyGroups = (headers.get("PlanningStrategyGroups")?:'').tokenize(',');
    addBrackets = (strategyGroups.size >= 2);
    eqString = strategyGroups.findAll{it!=''}.join("' or sp/PlanningStrategyGroup eq '");
    eqString = eqString != '' ? "sp/PlanningStrategyGroup eq '${eqString}'": '';
    if (addBrackets) eqString = "(${eqString})";
    def plantFilter = [productPlantFurtherFilters,plantMergedFilters,eqString].findAll{it!=''}.join(' and ');

    
    

        message.setHeader("S4PlantFilter", plantFilter.replaceAll('sp/',''));
        message.setHeader("S4ProductPlantFilter", plantFilter);
      
      

        message.setHeader("S4ProductIdFilter", productMergedFilters);
        
        def productFilter = [productFurtherFilters,productMergedFilters].findAll{it!=''}.join(' and ');
        
        message.setHeader("LocalProductIdFilterAndFurtherFilter", productFilter);
        
        message.setHeader("S4ProductFilter", productFilter);
        
        def productCountFilter = [productFilter,plantFilter].findAll{it!=''}.join(' and ');
        productCountFilter = productCountFilter.replaceAll(/(^|[^a-zA-Z0-9\/])(sp\/)/, '$1pl/_ProductPlantSupplyPlanning/').replaceAll("(^|[^a-zA-Z0-9])(pr\\/)",'$1')
        productCountFilter = "_ProductPlant/any(pl:${productCountFilter})"
        message.setHeader("S4ProductCountFilter", productCountFilter);
        
        def productPlantCountFilter = [productFilter,plantFilter].findAll{it!=''}.join(' and ').replaceAll("(^|[^a-zA-Z0-9])(sp\\/Plant)([^a-zA-Z0-9])",'$1Plant$3').replaceAll("(^|[^a-zA-Z0-9])(pr\\/)",'$1_Product/').replaceAll("(^|[^a-zA-Z0-9])(pl\\/)",'$1_ProductPlant/').replaceAll("(^|[^a-zA-Z0-9])(sp\\/)",'$1');

        message.setHeader("S4ProductPlantCountFilter", productPlantCountFilter);
       
        
    

    return message;
}
