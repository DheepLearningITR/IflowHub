import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	
	def messageLog = messageLogFactory.getMessageLog(message);
	def headers = message.getHeaders();
	def batchesWithValidationErrors = headers.get('IBPBatchesWithValidationErrors');
	throw new Exception("Validation errors occurred during processing of data written to IBP Batch" + (batchesWithValidationErrors.contains(',')?'es':'') + " " + batchesWithValidationErrors);  	
	
	return message;
}
