import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.lang.String;
import com.sap.it.api.mapping.*;


def internalValidateFieldExtensions(Message message, String fieldList, String fieldExtensions) {
    if (!fieldExtensions.isEmpty()) {
        if (!(fieldExtensions.startsWith('<') && fieldExtensions.endsWith('>'))) {
            throw new Exception("Start the Field Extensions parameter with '<' and end it with '>'.")
        }

        def pattern = /<(\w+)\s/
        def matches = (fieldExtensions =~ pattern)
        def tagNames = matches.collect { it[1] }
        
        boolean allTagsInFieldList = tagNames.every { tagName -> fieldList.split(',').contains(tagName) }

        if (!allTagsInFieldList) {
            def missingTags = tagNames.findAll { tagName -> !fieldList.split(',').contains(tagName) }
            throw new Exception("Fields are missing from the Fields to Update in SAP IBP parameter which are included in the Field Extensions parameter. Missing fields: $missingTags")
        }
        
        //only checks the syntax
        def fieldExtensionsXML = '<Root>'+fieldExtensions+'</Root>'
        def xmlVal = new XmlSlurper().parse(new StringReader(fieldExtensionsXML))
    }
}

def validateFieldExtensions(Message message) {
    def headers = message.getHeaders();
    def field_list_uom = headers.get('UoMConversionFactorAttributesinSAPIBP');
    def field_extensions_uom = headers.get('FieldExtensionsforUoMConversionFactors');

    def field_list_uomconv = headers.get('UnitofMeasureAttributesinSAPIBP');
    def field_extensions_uomconv = headers.get('FieldExtensionsforUnitofMeasures');

    def field_list_product = headers.get('ProductAttributesinSAPIBP');
    def field_extensions_product = headers.get('FieldExtensionsforProducts');

    internalValidateFieldExtensions(message, field_list_uom, field_extensions_uom)
    internalValidateFieldExtensions(message, field_list_uomconv, field_extensions_uomconv)
    internalValidateFieldExtensions(message, field_list_product, field_extensions_product)

    return message;
}



def validatePPandPPK(Message message) {
    def headers = message.getHeaders();
    def parallelProcesses  = headers.get('ParallelProcesses');
    def productplantsperpackage = headers.get('ProductPlantsPerPackage');
        

    
    if (parallelProcesses  < 1) {
        throw new Exception("Parallel Processes can not be less then 1")
    }
    

    
    if (productplantsperpackage < 1) {
        throw new Exception("Product Plants Per Package can not be less then 1")
    }


    return message;
}





def validateInput(Message message) {
    validatePPandPPK(message);
    validateFieldExtensions(message);
    return message;
}
