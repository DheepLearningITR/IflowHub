import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.time.TimeCategory; 
import groovy.time.TimeDuration;
import groovy.time.TimeCategory;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.DateFormat;


def Message SetStopTime(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    def headers = message.getHeaders();

//get time stamps    
    Date stop = new Date();
    def start_time = headers.get("start_create_ibp_write_batches");

//parse start time    
    def parsed = Date.parse("E MMM dd H:m:s z yyyy", start_time)

//calculate runtime    
    TimeDuration minus = TimeCategory.minus( stop,parsed );

//format runtime    
    def runtime = new Date(minus.toMilliseconds()).format("HH:mm:ss.SSS")

//set runtime log
    String result = headers.get("header.runtime") + "\nIBP;Create IBP Write Batches;" + start_time.toString() +";" + stop.toString() + ";"+ runtime.toString();
    message.setHeader("header.runtime", result);

    return message;
}