/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import com.sap.it.api.mapping.*;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	def headers = message.getHeaders();
	
	messageLog.addCustomHeaderProperty('Destination', headers.get("DestinationforSAPIBP"));
	messageLog.addCustomHeaderProperty('Batch Name', headers.get("BatchName"));
	messageLog.addCustomHeaderProperty('Planning Area', headers.get("PlanningArea"));
	messageLog.addCustomHeaderProperty('Planning Area Version', headers.get("PlanningAreaVersion"));

	
	
   def attachment = "Datastore ID for Product Plant Filter: " + headers.get("DatastoreIDforProductPlantFilter")+
    "\nDestination: " + headers.get("DestinationforSAPIBP")+
   "\nBatch Name: " + headers.get("BatchName")+
   "\nPlanning Area: " + headers.get("PlanningArea")+
   "\nPlanning Area Versions: " + headers.get("PlanningAreaVersion")+
   "\nField Extensions for Products: " + headers.get("FieldExtensionsforProducts")+
   "\nField Extensions for Unit of Measures: " + headers.get("FieldExtensionsforUnitofMeasures")+
   "\nField Extensions for UoM ConversionFactors: " + headers.get("FieldExtensionsforUoMConversionFactors")+
   "\nFurther Filters for Plants: " + headers.get("FurtherFiltersforPlants")+
   "\nFurther Filters for Products: " + headers.get("FurtherFiltersforProducts")+
   "\nLanguage For Descriptions: " + headers.get("LanguageForDescriptions")+
   "\nMaster Data Types: " + headers.get("MasterDataTypes")+
   "\nParallel Processes: " + headers.get("ParallelProcesses")+
   "\nProduct Plants Per Package: " + headers.get("ProductPlantsPerPackage")+
   "\nProcess Unchanged Data: " + headers.get("ProcessUnchangedData")+
   "\nProduct Attributes in SAP IBP: " + headers.get("ProductAttributesinSAPIBP")+
   "\nProduct Fields: " + headers.get("ProductFields")+
   "\nProduct Filter: " + headers.get("ProductFilter")+
   "\nExpand for Products: " + headers.get("ExpandforProducts")+
   "\nPlant Filter: " + headers.get("PlantFilter")+
   "\nUnified Base Unit: " + headers.get("UnifiedBaseUnit")+
   "\nUnified Base Unit Description: " + headers.get("UnifiedBaseUnitDescription")+
   "\nUnit of Measure Attributes in SAP IBP: " + headers.get("UnitofMeasureAttributesinSAPIBP")+
   "\nUnit of Measure Fields: " + headers.get("UnitofMeasureFields")+
   "\nUoM Conversion Factor Attributes in SAP IBP: " + headers.get("UoMConversionFactorAttributesinSAPIBP")+
   "\nDetailed Trace Log: " + headers.get("DetailedTraceLog")+
   "\nHost for SAP S4/HANA Cloud Public Edition: " + headers.get("HostforSAPS4HANACloud")+
   "\nMaster Data Prefix: " + headers.get("MasterDataPrefix");
   messageLog.addAttachmentAsString("Parameters" , attachment.toString(), "text/xml");
   return message;
}
