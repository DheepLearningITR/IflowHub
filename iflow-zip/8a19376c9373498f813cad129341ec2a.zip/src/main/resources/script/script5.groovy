import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

 def Message processData(Message message) {

    def (pMap) = [];
    def (mode_ext,last_run_date,queryFilter,payrollPeriod,todaysDate) = [];
   // def (queryFilter, str, param,parameter) = [];
    
     //Camel Message --> Properties

  // String date = "1900-01-01T00:00:00Z";
   def messageLog = messageLogFactory.getMessageLog(message); 
   pMap = message.getProperties();
    
   mode_ext = pMap.get("executionMode").toString();
   // mode_ext = "Auto"
   payrollPeriod = pMap.get("payrollPeriod").toString();
   // payrollPeriod = "01-2019"
   last_run_date = pMap.get("L_RUN_DATE_SAGE").toString();
  // last_run_date = "2019-05-20T00:00:00Z"
  todaysDate = pMap.get("Today").toString();
  //todaysDate = "2019-05-23"
    String[] data = payrollPeriod.split("-");
    
   // messageLog.addAttachmentAsString("Mode:", mode_ext, "text/xml");
    //messageLog.addAttachmentAsString("Last:", S_RUN_DATE_MIM, "text/xml");
    Calendar c = Calendar.getInstance();   
    def year1 = data[1]
    int year=(Integer.parseInt(year1))
    def month1 = data[0]
    int month=(Integer.parseInt(month1))-1
    int day = 1;
    c.set(year, month, day);
    int numOfDaysInMonth = c.getActualMaximum(Calendar.DAY_OF_MONTH);
   // System.out.println("First Day of month: " + c.getTime().format("yyyy-MM-dd"));
    def startDateTime= c.getTime().format("yyyy-MM-dd")+ "T00:00:00Z"
    //println "startDateTime"+startDateTime;
    c.add(Calendar.DAY_OF_MONTH, numOfDaysInMonth-1);
   // System.out.println("Last Day of month: " + c.getTime().format("yyyy-MM-dd"));
    def endDate= c.getTime().format("yyyy-MM-dd");
     def endDateTime= c.getTime().format("yyyy-MM-dd")+ "T23:59:59Z"
  //   println "endDateTime"+endDateTime   
   
   
       if (mode_ext.equalsIgnoreCase("PayrollPeriod"))
       {
            queryFilter = "WHERE last_modified_on > to_datetime('" + startDateTime + "') AND "+"last_modified_on <= to_datetime('" + endDateTime + "')"+" AND effective_end_date >= to_date('"+endDate+ "')";
       }
       else if (mode_ext.equalsIgnoreCase("manual"))
       {
            queryFilter = "WHERE last_modified_on >= to_datetime('" + last_run_date + "')"+" AND effective_end_date >= to_date('"+todaysDate+ "')" ;
       }
       else if (mode_ext.equalsIgnoreCase("auto"))
            queryFilter = "WHERE last_modified_on >= to_datetime('" + last_run_date + "')"+" AND effective_end_date >= to_date('"+todaysDate+ "')" ;
       else
          queryFilter = "XXXX"
    // println 
               messageLog.addAttachmentAsString("queryFilter:", queryFilter, "text/xml");
    message.setProperty("QueryFilter",queryFilter);
  //  message.setProperty("mode_ext", mode_ext);
    return message;
}


