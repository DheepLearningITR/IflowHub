import com.sap.gateway.ip.core.customdev.util.Message;

    import java.util.HashMap;

   

    def Message processData(Message message) {


        def map = message.getProperties();      

        def value = map.get("events");

     
        //Clear body

        def body = "";

        message.setBody(body);


        String[] str;

        str = value.split(';');

        for( String values : str )


         body = body + values + '\n'

     
        message.setBody( body );


        return message;

        }