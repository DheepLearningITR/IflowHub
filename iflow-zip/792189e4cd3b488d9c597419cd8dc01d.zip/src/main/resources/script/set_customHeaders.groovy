import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def testRun = message.getHeaders().get("testRun");
		if(testRun != null && testRun != 'false' && testRun != ''){
			messageLog.addCustomHeaderProperty("cbr_testRun", testRun);		
        }
		def skillId = message.getProperties().get("skillId");
		if(skillId!=null){
			messageLog.addCustomHeaderProperty("cbr_skillId", skillId);		
        }
        def compCode = message.getProperties().get("compExtCode");
		if(compCode != null){
			messageLog.addCustomHeaderProperty("sfsf_competencyExtCode", compCode);		
        }
        def operation = message.getProperties().get("operation");
        if(operation != null){
			messageLog.addCustomHeaderProperty("sfsf_operation", operation);		
        }
	}
	return message;
}
