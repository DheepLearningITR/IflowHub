/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.HashMap;
import java.util.UUID; 
import java.util.Iterator; 
import java.util.List; 
import java.lang.Thread;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;
import groovy.xml.XmlUtil;


import java.util.Base64; 
import org.json.JSONObject; 
import org.json.JSONArray;
import org.json.JSONException;
import javax.ws.rs.core.MediaType;



def Message check_in(Message message) {
      try {
          
		message.setProperty("IBPStep", "Check IN");
		
		message.setHeader("x-csrf-token", "fetch");
    
        def payloadBody =  message.getBody(java.lang.String) as String; 
        
        JSONObject extractJSON =new JSONObject(payloadBody);  
        
        message.setProperty("sac_payload", extractJSON.get("sacPayload"));
        
        message.setProperty("planning_area", extractJSON.get("planningArea"));
        
        message.setProperty("fields_string", extractJSON.get("fieldsString"));
        
        message.setProperty("host_name", extractJSON.get("hostName"));
        
        if(!extractJSON.isNull("commit")){
            message.setProperty("commit", extractJSON.get("commit").toBoolean());
        } else {
            message.setProperty("commit", "true".toBoolean());
        }
        
        if(!extractJSON.isNull("transactionId")){
        
            message.setProperty("ext_transaction_id", extractJSON.get("transactionId"));
            
        } 
        
        message.setProperty("credentials_name", extractJSON.get("credentialsName"));
		
		message.setProperty("stepStatus", "success");
    
        
    } catch (JSONException e) { 
        
        message.setProperty("stepStatus", "error");
        message.setProperty("errorMessage", e.toString());
		message.setBody(e);
	}
    return message;
}

def Message prepare_write_odata_payload(Message message) {
    
    message.setProperty("IBPStep", "Write IBP");
    
    try {
    
        def payload_Body = message.getProperty('sac_payload') as String; 
        
        def csrf_token = message.getProperty('new_csrf_token') as String; 
        
        message.setHeader("x-csrf-token", csrf_token);
        message.setHeader("Content-Type", "application/json");
        message.setHeader("Accept", "application/json");
            
        // SAC Array that needs to be written to IBP 
        JSONArray payload_JSON =new JSONArray(payload_Body);   
            
        def planning_area = message.getProperty("planning_area") as String;
        def nav_planning_area = "Nav" + planning_area;
        def commit = message.getProperty('commit');
        /*
        if(message.getProperty('commit')){
            commit = message.getProperty('commit');
        } else {
           commit = true; 
        }
        */
            
        def mp = ['Transactionid' : message.getProperty("ibpTransactionID"), 'DoCommit': (commit), 'AggregationLevelFieldsString': message.getProperty('fields_string'), (nav_planning_area) : payload_JSON];   
        // mp[nav_planning_area] = payload_JSON
            
        def ibp_Payload = new JSONObject(mp).toString();
    	    
    	message.setBody(ibp_Payload);
    
        
    } catch (JSONException e) { 
		message.setBody(e);
	}
    
    return message;
    
}                                         


def Message processData(Message message) {
       //Body 
       def body = message.getBody();
       message.setBody(body + "Body is modified");
       //Headers 
       def map = message.getHeaders();
       def value = map.get("oldHeader");
       message.setHeader("oldHeader", value + "modified");
       message.setHeader("newHeader", "newHeader");
       //Properties 
       map = message.getProperties();
       value = map.get("oldProperty");
       message.setProperty("oldProperty", value + "modified");
       message.setProperty("newProperty", "newProperty");
       return message;
}


def Message getTransactionID(Message message) {
    
    message.setProperty("IBPStep", "GET Transaction ID");
    message.setProperty("new_csrf_token", message.getHeader("x-csrf-token", java.lang.String));
    // message.setHeader("x-csrf-token", message.getHeader("x-csrf-token", java.lang.String));
    
    // CLEAR and SET HTTP HEaders
	message.setHeader("CamelHttpQuery", "");
	message.setHeader("x-csrf-token", "");
	def body = message.getBody(java.lang.String) as String; 
    JSONObject extractJSON =new JSONObject(body);
	//If no external transaction ID is present
	if(!message.getProperty('ext_transaction_id')){
        def ibpTransactionID = "";
        // byte[] responseBody = body.getBytes();;
    	JSONObject entryJSONObject = null;
        try {
            // If there was no error while getting the transaction id
    		entryJSONObject = extractJSON.getJSONObject("entry");
    		if(entryJSONObject.length() > 0){
    		    JSONObject contentJSONObject = entryJSONObject.getJSONObject("content");
    			JSONObject propertiesJSONObject = contentJSONObject.getJSONObject("properties");
    			ibpTransactionID = (String)propertiesJSONObject.get("Value");
    			message.setProperty("stepStatus", "success");
    			message.setProperty("ibpTransactionID", ibpTransactionID);  
    		}  
    	    message.setBody(extractJSON);	
    	} catch (JSONException e) { 
    		message.setBody(e);
    	}
        try {
            // Error getting transaction id
            if(entryJSONObject.length() < 3){
            	JSONObject errorJSONObject = extractJSON.getJSONObject("error");
        		if(errorJSONObject.length() > 0){  
        		    message.setProperty("stepStatus", "error");
        			message.setProperty("errorMessage", errorJSONObject.getJSONObject("message").toString());
        		}  
        	    message.setBody(extractJSON);
            }
    	} catch (JSONException e) { 
    		message.setBody(e);
    	} 
	} else {
	    try {
	        // If it lands here, it means, it has an external transaction id, but still got an error connecting to IBP
            	JSONObject errorJSONObject = extractJSON.getJSONObject("error");
        		if(errorJSONObject.length() > 0){ 
        		    message.setProperty("stepStatus", "error");
        			message.setProperty("errorMessage", errorJSONObject.getJSONObject("message").toString()); 
        	        message.setBody(errorJSONObject);
        		}  
            
    	} catch (JSONException e) { 
    	    // No error message was found
    		// message.setBody(e);
    	} 
    	
		message.setProperty("stepStatus", "success");
		message.setProperty("ibpTransactionID", message.getProperty('ext_transaction_id'));  
	}
    return message;
} 



def Message process_post_trans(Message message) {
    
    message.setProperty("IBPStep", "Completed POST TRANS");
    message.setProperty("new_csrf_token", message.getHeader("x-csrf-token", java.lang.String)); 
    
    // CLEAR and SET HTTP HEaders
	message.setHeader("CamelHttpQuery", "");
	message.setHeader("x-csrf-token", "");
	
	def planning_area = message.getProperty("planning_area") as String;
    def nav_planning_area = "Nav" + planning_area;
    
    def body = message.getBody(java.lang.String) as String;  
    // byte[] responseBody = body.getBytes();;
    JSONObject extractJSON =new JSONObject(body);
    JSONObject entryJSONObject = null;
    
    try {
	    entryJSONObject = extractJSON.getJSONObject("d");
	    JSONObject contentJSONObject = entryJSONObject.getJSONObject((nav_planning_area)); 
		String ibpTransactionID = (String)entryJSONObject.get("Transactionid");
		message.setProperty("stepStatus", "success");
		message.setProperty("ibpTransactionID", ibpTransactionID);   
	} catch (JSONException e) { 
	    JSONObject errorJSONObject = extractJSON.getJSONObject("error");
		if(errorJSONObject){ 
    		message.setProperty("stepStatus", "error");
    		message.setProperty("errorMessage", errorJSONObject.getJSONObject("message").toString());  
    	}
	    message.setProperty("stepStatus", "error");
		message.setProperty("IBPStep", "Completed POST TRANS with error " + e.toString());
	}
	message.setBody(extractJSON);
    return message;
} 


def Message check_processing(Message message) {
    
    def body = message.getBody(java.lang.String) as String; 
    //String ibpTransactionID = "";
    
    JSONObject extractJSON =new JSONObject(body);
    JSONObject entryJSONObject = null;
    
    try {
		entryJSONObject = extractJSON.getJSONObject("d");
		if(entryJSONObject){
		    JSONArray resultsJSONArray = entryJSONObject.getJSONArray(("results"));  
		    
		    String processingMessageType = resultsJSONArray[0].get("Value") as String;
		    
			message.setProperty("processingStatus",  mapProcessingMessageTypeToString(message, processingMessageType));
			message.setProperty("processingMessage", processingMessageType);
			message.setProperty("stepStatus", "success"); 
		} else {
		    JSONObject errorJSONObject = extractJSON.getJSONObject("error");
    		if(errorJSONObject){ 
        		message.setProperty("stepStatus",   "error");
        		message.setProperty("errorMessage", errorJSONObject.getJSONObject("message").toString()); 
        		message.setBody(errorJSONObject);
        	}  
		} 
	    
	} catch (JSONException e) { 
	    message.setProperty("stepStatus", "error");
		message.setProperty("IBPStep",    "Completed getExportResults with error " + e.toString());
	}
	
    return message;
} 
 
 def String mapProcessingMessageTypeToString(Message message, String processingMessageType) {
    if(!message.getProperty('commit')){
        return 'PROCESSED';
    }  
     
    switch (processingMessageType) {
        case 'PROCESSED_WITH_ERRORS': return 'PROCESSED';
        case 'PROCESSING':            return 'loop';
        case 'PROCESSED':             return 'PROCESSED'; 
        case 'INITIAL':               return 'loop'; 
        default: return processingMessageType;
    }
}




def Message analyse_export_message(Message message) {
    // String processingStatus = message.getProperty('processingStatus');
    String processingMessage = message.getProperty('processingMessage');
    
    message.setProperty("IBPStep", "Analysing getExportResults ");
    
    if(processingMessage.equalsIgnoreCase('PROCESSED')){
        	message.setProperty("stepStatus",  "success");
    } else {
        	message.setProperty("stepStatus",  "error");
        	message.setProperty("errorMessage", (processingMessage)); 
    }
    return message;
} 



def Message post_success(Message message) { 
    
    
     try { 
        
		def mp = [
		    "IBP Host" :  message.getProperty('host_name'), 
		    "IBP credentials" :  message.getProperty('credentialsName'), 
		    "stepStatus" : "success", 
		    "Status" : "Success", 
		    "Message" : "Processed transaction " + message.getProperty('ibpTransactionID') + " Successfull. Check the logs at IBP"
		    ];
    
        def ibpCommitStatus = new JSONObject(mp).toString();
	    
		message.setBody(ibpCommitStatus);
		
	} catch (JSONException e) { 
		message.setBody(e);
	}
    return message; 
     
}