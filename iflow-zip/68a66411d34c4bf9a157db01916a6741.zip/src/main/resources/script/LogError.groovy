/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message; 
import java.util.HashMap; 


import java.util.Base64; 
import org.json.JSONObject; 
import org.json.JSONArray;
import org.json.JSONException;
import javax.ws.rs.core.MediaType;

 

def Message catch_camels(Message message){  
    
    def map  = message.getProperties();
    def ex   = map.get("CamelExceptionCaught");
    def exceptionText;
    
    if (ex != null)
    {
        exceptionText    = ex.getMessage();
        def messageLog   = messageLogFactory.getMessageLog(message);
        messageLog.addAttachmentAsString("Exception", exceptionText,"application/text");
     
        // copy the http error response body as a property 
        message.setProperty("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
        
        try { 
        
    		def mp = [
    		    "IBP Host" :  message.getProperty('host_name'), 
    		    "IBP credentials" :  message.getProperty('credentialsName'), 
    		    "Status" : "error", 
    		    "stepStatus" : "error", 
    		    "ibpStep" :  message.getProperty('IBPStep'), 
    		    "Message" :  exceptionText
    		    ];
        
            def ibpCommitStatus = new JSONObject(mp).toString();
            
            message.setProperty("http.response", ibpCommitStatus);
    	    
    		message.setBody(ibpCommitStatus);
    		
    	} catch (JSONException e) { 
    		message.setBody(e);
    	}   
    }
    return message; 
}

def Message log_checkin_error(Message message) {
    
     try { 
        
		def mp = [
		    "IBP Host" :  message.getProperty('host_name'), 
		    "IBP credentials" :  message.getProperty('credentialsName'), 
		    "Status" : "error", 
		    "stepStatus" : "error", 
		    "ibpStep" :  message.getProperty('IBPStep'), 
		    "Message" : "Payload error while calling Cloud Integration. Check the request made from SAC" 
		    ];
    
        def ibpCommitStatus = new JSONObject(mp).toString();
	    
		message.setBody(ibpCommitStatus);
		
	} catch (JSONException e) { 
		message.setBody(e);
	}
    return message; 
} 

def Message log_posting_error(Message message) {
    
     try { 
        
		def mp = [
		    "IBP Host" :  message.getProperty('host_name'), 
		    "IBP credentials" :  message.getProperty('credentialsName'), 
		    "Status" : "error", 
		    "stepStatus" : "error", 
		    "ibpStep" :  message.getProperty('IBPStep'), 
		    "Message" : "POST data using transaction " + message.getProperty('ibpTransactionID') + " stopped With errors. Check the logs at IBP" 
		    ];
    
        def ibpCommitStatus = new JSONObject(mp).toString();
	    
		message.setBody(ibpCommitStatus);
		
	} catch (JSONException e) { 
		message.setBody(e);
	}
    return message; 
}
 


def Message log_post_processing_error(Message message) {
    
     try { 
        
		def mp = [
		    "IBP Host" :  message.getProperty('host_name'), 
		    "IBP credentials" :  message.getProperty('credentialsName'), 
		    "Status" : "error", 
		    "stepStatus" : "error", 
		    "ibpStep" :  message.getProperty('IBPStep'), 
		    "Message" : "Processing transaction " + message.getProperty('ibpTransactionID') + " stopped With errors. Check the logs at IBP" 
		    ];
    
        def ibpCommitStatus = new JSONObject(mp).toString();
	    
		message.setBody(ibpCommitStatus);
		
	} catch (JSONException e) { 
		message.setBody(e);
	}
    return message; 
}




def Message process_with_errors(Message message) {
    
     try { 
        
		def mp = [
		    "IBP Host" :  message.getProperty('host_name'), 
		    "IBP credentials" :  message.getProperty('credentialsName'), 
		    "Status" : "error", 
		    "stepStatus" : "error", 
		    "ibpStep" :  message.getProperty('IBPStep'), 
		    "Message" : "Processed transaction " + message.getProperty('ibpTransactionID') + " With errors. Check the logs at IBP" 
		    ];
    
        def ibpCommitStatus = new JSONObject(mp).toString();
	    
		message.setBody(ibpCommitStatus);
		
	} catch (JSONException e) { 
		message.setBody(e);
	}
    return message; 
}

def Message transaction_error(Message message) { 
    

    try { 
        
		def mp = [
		    "IBP Host" :  message.getProperty('host_name'), 
		    "IBP credentials" :  message.getProperty('credentialsName'), 
		    "Status" : "Error", 
		    "ibpStep" :  message.getProperty('IBPStep'), 
		    "IBP credentials" :  message.getProperty('credentialsName'), 
		    "stepStatus" : "error", 
		    "Message" : message.getProperty("errorMessage")
		]; 
    
        def ibpCommitStatus = new JSONObject(mp).toString();
	    
		message.setBody(ibpCommitStatus);
		
	} catch (JSONException e) { 
		message.setBody(e);
	}
    return message;
}