import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import java.util.HashMap;

def Message processData(Message message) {

def body = message.getBody(java.lang.String) as String;
def jsonSlurper = new JsonSlurper();
def object = jsonSlurper.parseText(body);
def cmssiteVal = message.getProperty("CMSSITE");
def fieldsMap = object.siteConsentDetails;
def fieldsEntrySet = fieldsMap.entrySet();
def newFieldsSet = [];
for(def field:fieldsEntrySet){
 if(field.value.get("customData") && field.value.get("legalStatements")){
         def customData = field.value.customData;
         for(def customDataField: customData){
             if (customDataField.key.equals("cmssite") && customDataField.value.equals(cmssiteVal)){
                def tempCopy = JsonOutput.toJson(field.value);
                def replicaOfJson = jsonSlurper.parseText(tempCopy);
                replicaOfJson.put("id",field.key);
                def siteVal = customDataField.value;
                replicaOfJson.put("site", siteVal.toString());
                 if(field.value.get("legalStatements") != null){
                     def legalStatement = field.value.legalStatements;
                     def legalSet=[];
                     def legalStEntrySet = legalStatement.entrySet();
                     
                     
                     for(def legalIterator : legalStEntrySet){
        
                        legalIterator.value.put("language",legalIterator.key)
                        legalSet.add(legalIterator.value)
        
                    }
                 replicaOfJson.legalStatements = legalSet
                     
                 }
                 newFieldsSet.add(replicaOfJson);
                 
             }
             
         }
        
    }
}
object.siteConsentDetails=newFieldsSet;
message.setBody(new JsonBuilder(object).toPrettyString());
       return message;

}   



                
            
