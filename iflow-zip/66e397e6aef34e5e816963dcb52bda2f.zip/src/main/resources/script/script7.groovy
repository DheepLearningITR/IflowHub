import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    
    def jsonslurper = new JsonSlurper();
    def object = jsonslurper.parseText(body);
    def baseSite = object.BaseSites.BaseSite;
    def cmsSite= baseSite.uid;
    def gigyaConfigs = baseSite.gigyaConfig.GigyaConfig;
    def gigyaApiKey = gigyaConfigs.get("gigyaApiKey")
    def gigyaDataCenter = gigyaConfigs.get("gigyaDataCenter")
    message.setProperty("GIGYADATACENTER",gigyaDataCenter);
    message.setProperty("GIGYAAPIKEY", gigyaApiKey);
    message.setProperty("CMSSITE",cmsSite)
    return message;
}