import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import com.sap.gateway.ip.core.customdev.util.Message;



/*def body="""
{"GigyaConfigs":{"GigyaConfig":{"gigyaSiteSecret":"/5Zu5mjMGF5XQd6CdWHUJKdQPifSr5R+UHtnCvDmNbM=","gigyaDataCenter":"us1.gigya.com","integrationKey":"gigyaConfigForElectronicsSite","code":"gigyaConfigForElectronicsSite","gigyaApiKey":"3_WecBJGZIsW84mtwuJz_JouQovBTOqIMPAgY-8c0xa71hKcJqSGA14GHojftxLggV"}}}
"""
def jsonSlurper = new JsonSlurper();
def object = jsonSlurper.parseText(body);
def configMap = object.GigyaConfigs.GigyaConfig;
def dataCenter =configMap.get("gigyaDataCenter");
def apiKey= configMap.get("gigyaApiKey")

def gigyaURL="https://accounts."+dataCenter+"/accounts.getSchema";

def query = "include=preferencesSchema&scope=site&filter=explicitOnly&ApiKey="+apiKey;
print(gigyaURL+"?"+query);*/
def Message processData(Message message) {
def body=message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
def object = jsonSlurper.parseText(body);
def configMap = object.GigyaConfigs.GigyaConfig;
def dataCenter =configMap.get("gigyaDataCenter");
def apiKey= configMap.get("gigyaApiKey")

def gigyaURL="https://accounts."+dataCenter+"/accounts.getSchema";

def query = "include=preferencesSchema&scope=site&filter=explicitOnly&ApiKey="+apiKey;



    return message;
}