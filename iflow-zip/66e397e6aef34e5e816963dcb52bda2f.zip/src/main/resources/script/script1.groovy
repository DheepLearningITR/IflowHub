/*import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import java.util.HashMap;

def Message processData(Message message) {

def body = message.getBody(java.lang.String) as String;

def jsonSlurper = new JsonSlurper();
def object = jsonSlurper.parseText(body);
def fieldsMap = object.preferencesSchema.fields;
def messageLog1 = messageLogFactory.getMessageLog(message);
if(messageLog1 != null) {
        messageLog1.addAttachmentAsString("Log - XML - TEST112" , "\n Properties \n ----------   \n" + "property" +
                                                           "\n headers \n ----------   \n" + "header" +
                                                           "\n Test Value \n ----------  \n\n" + fieldsMap.getClass(),
                                                           "text/xml");
    }
def fieldsEntrySet = fieldsMap.entrySet();
def newFieldsSet = [];
def pmap = message.getProperties();
def headers = message.getHeaders() as Map<String, Object>;
    def properties = message.getProperties() as Map<String, Object>;
for(def field:fieldsEntrySet){
    if(field.value.get("customData") && field.value.get("currentDocVersion")){
         def customData = field.value.customData;
         for(def customizedData: customData.key){
             if (customizedData.equals("cmssite")){
                 field.value.put("id",field.key);
                 if(field.value.get("legalStatements") != null){
                     def legalStatement = field.value.legalStatements;
                     def legalSet=[];
                     def messageLog2 = messageLogFactory.getMessageLog(message);
                     if(messageLog2 != null) {
        messageLog2.addAttachmentAsString("Log - XML - LegalStatement" , "\n Properties \n ----------   \n" + "property" +
                                                           "\n headers \n ----------   \n" + "header" +
                                                           "\n Test Value \n ----------  \n\n" + legalStatement.getClass()+" !!!!!"+legalStatement,
                                                           "text/xml");
    }
                     def legalStEntrySet = legalStatement.entrySet();
                     
                     
                     for(def legalIterator : legalStEntrySet){
        
                        legalIterator.value.put("language",legalIterator.key)
                        legalSet.add(legalIterator.value)
        
                    }
                 field.value.legalStatements = legalSet
                     
                 }
                 newFieldsSet.add(field.value);
                 
             }
             
         }
        
    }
}
object.preferencesSchema.fields=newFieldsSet;
message.setBody(new JsonBuilder(object).toPrettyString());
 def propertiesAsString ="\n";
    properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };
    
    def headersAsString ="\n";
    headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };
    
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null) {
        messageLog.addAttachmentAsString("Log - XML" , "\n Properties \n ----------   \n" + propertiesAsString +
                                                           "\n headers \n ----------   \n" + headersAsString +
                                                           "\n Body \n ----------  \n\n" + body,
                                                           "text/xml");
    }
       return message;

}   */