import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();

       //Headers 
       def map = message.getHeaders();
       def value = map.get("CamelHttpQuery");

       String[] str;
       String[] val;
       String companyCode;
       String customerNo;
       
       str = value.split('&');
       
       for(String s in str) { 
         if(s.matches("CustomerNo(.*)"))
         {
            val = s.split('=');    
            customerNo = val[1];
         }
         
         if(s.matches("CompanyCode(.*)"))
         {
            val = s.split('=');    
            companyCode = val[1];
         }
         
       } 
       
       if (customerNo.isNumber()){
           len=customerNo.length()
           int len2
           int entitylen = 10;
           String addstr
           if (len<= entitylen)
           {
              len2=entitylen-len
              addstr="0"*len2
              customerNo=addstr+customerNo
           }
       }
       
  
       //Properties 
       map = message.getProperties();
       message.setProperty("companyCode", companyCode);
       message.setProperty("customerNo", customerNo);
       return message;
}