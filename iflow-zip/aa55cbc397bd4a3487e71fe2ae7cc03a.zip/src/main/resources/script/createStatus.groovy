import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;

def String createStatus(String type, MappingContext context) {

    if(type.length()==0 || type == null){
        return "SUCCESS"
    }
    return "FAILURE"
    
}