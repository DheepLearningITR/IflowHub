import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;

def String createMessage(String message, MappingContext context) {

    if(message.length()==0 || message == null){
        return "Data fetched successfully"
    }
    return message
    
}