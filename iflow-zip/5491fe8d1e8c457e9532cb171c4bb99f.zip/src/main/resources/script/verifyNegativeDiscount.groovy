import com.sap.it.api.mapping.*;

def String verifyNegativeDiscount(String value, MappingContext context){
    if (context.getProperty("negativeDiscountEnabled").equals("true")) {
        BigDecimal bigDecimalValue = new BigDecimal(value);
        return bigDecimalValue.negate().toString();
    }
    return value;
}