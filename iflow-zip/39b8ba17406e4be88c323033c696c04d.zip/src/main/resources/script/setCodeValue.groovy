import com.sap.it.api.mapping.*;

def String getCode(String code, MappingContext context) {
    
      def value1 = context.getProperty("code");
      return value1;
       
       
}

