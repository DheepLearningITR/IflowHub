/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

	def body = message.getBody(java.lang.String.class);
	def encoded = java.net.URLEncoder.encode(body);

    message.setBody("__rdxml="+encoded);
	return message;
}

