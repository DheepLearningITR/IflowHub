import com.sap.it.api.mapping.*;

def String updateIssueText(String inputText){
    inputText = inputText.toUpperCase();
    inputText =inputText.replace("CREATE TICKET","");
    if(inputText.length() > 50)
    inputText = inputText.substring(0,50);
	return inputText;
}

def String updateIssueDescription(String inputText){
      inputText = inputText.toUpperCase();
    inputText =inputText.replace("CREATE TICKET","");
	return inputText;
}

def String getProperty(String propertyName,MappingContext context){
    
	return Integer.parseInt(context.getProperty(propertyName));
}