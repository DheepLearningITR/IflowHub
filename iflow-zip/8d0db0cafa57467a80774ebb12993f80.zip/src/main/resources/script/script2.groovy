
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String);
       def slurped = new JsonSlurper().parseText(body);
       def builder = new JsonBuilder(slurped);
        def Sprint = slurped.fields.customfield_10020;
        builder.content.fields.customfield_10020 =  Integer.parseInt(Sprint);
       message.setBody(builder.toPrettyString());
       return message;
}