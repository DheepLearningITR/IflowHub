import com.sap.gateway.ip.core.customdev.util.Message; 
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message enrichJsonOutput(Message message) {
    def body = message.getBody(java.io.Reader)
    Map parsedJson = new JsonSlurper().parse(body)
    parsedJson.messageRequests.each {
        request -> request.body.priceElements.each {
            priceElement -> processPriceElement(priceElement)
        }
        request.body.items.each {
            item -> item.priceElements?.each {
                itemPriceElement -> convertBooleanFields(itemPriceElement, [
                    'isRateDenominatorUpdateEnabled',
                    'isRateNumeratorUpdateEnabled',
                    'isGroupedIndicator',
                    'isManuallyChanged',
                    'isDeleteEnabled',
                    'isEffective',
                    'isEditAuthorizationSufficient',
                    'isViewAuthorizationSufficient'
                ])
            }
            if (item.businessTerms?.cashDiscountTerms != null) {
                item.businessTerms.cashDiscountTerms = Boolean.parseBoolean(item.businessTerms.cashDiscountTerms)
            }
        }
    }
    def openAPISchemaStream = this.getClass().getResourceAsStream("/src/main/resources/json/salesQuoteS4ReplicationIn.json")
    def iDOCReplicationHelper = message.getProperty('iDOCReplicationHelper')
    try {
        def schema = new JsonSlurper().parse(openAPISchemaStream)
            .components.schemas.SalesQuoteInboundReplicationcreaterequest.properties.messageRequests.items.properties.body;
        parsedJson.messageRequests.each {
            request -> iDOCReplicationHelper.setMissingAttributesToNull(request.body, schema)
            message.setProperty("requestBody", request.body);
        }
        def modifiedJson = JsonOutput.toJson(parsedJson)
        message.setBody(modifiedJson)
    } finally {
        if (openAPISchemaStream != null) {
            openAPISchemaStream.close()
        }
    }
    return message
}

void processPriceElement(Object priceElement) {
    convertBooleanFields(priceElement, [
        'isManuallyChanged',
        'isDeleteEnabled',
        'isEffective',
        'isGroupedIndicator',
        'isRateDenominatorUpdateEnabled',
        'isRateNumeratorUpdateEnabled'
    ])
}

void convertBooleanFields(Object obj, List < String > fields) {
    fields.each {
        field -> if (obj."$field" != null) {
            obj."$field" = Boolean.parseBoolean(obj."$field")
        }
    }
}