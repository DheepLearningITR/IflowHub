import com.sap.gateway.ip.core.customdev.util.Message; 
import groovy.json.JsonSlurper
import groovy.json.JsonOutput


def Message enrichJsonPayload(Message message) {
    //Body 
    def body = message.getBody(java.io.Reader)
    Map parsedJson = new JsonSlurper().parse(body)
    parsedJson.messageRequests.each {
        request -> def requestBody = request.body
        requestBody.parties.each {
            party -> if (party.isMain) {
                party.isMain = Boolean.parseBoolean(party.isMain)
            }
        }
        requestBody.priceElements.each {
            element -> processPriceElement(element)
        }
        requestBody.items.each {
            item -> item.lineNumber = Integer.parseInt(item.lineNumber)
            try {
                item.parentItemLineNumber = Integer.parseInt(item.parentItemLineNumber)
            } catch (NumberFormatException e) {
                item.parentItemLineNumber = null
            }
            item.priceElements.each {
                element -> processPriceElement(element)
            }
        }
    }
    def openAPISchemaStream = this.getClass().getResourceAsStream("/src/main/resources/json/salesOrderS4ReplicationIn.json")
    def iDOCReplicationHelper = message.getProperty('iDOCReplicationHelper')
    try {
        def schema = new JsonSlurper().parse(openAPISchemaStream)
            .components.schemas.SalesOrderInboundReplicationcreaterequest.properties.messageRequests.items.properties.body;
        parsedJson.messageRequests.each {
            request -> iDOCReplicationHelper.setMissingAttributesToNull(request.body, schema)
            message.setProperty("requestBody", request.body);
        }
        def respbody = JsonOutput.toJson(parsedJson)
        message.setBody(respbody)
    } finally {
        if (openAPISchemaStream != null) {
            openAPISchemaStream.close()
        }
    }
    return message;
}

def Object processPriceElement(Object priceElement) {
    priceElement.isManuallyChanged = convertToBoolean(priceElement.isManuallyChanged)
    priceElement.isDeleteEnabled = convertToBoolean(priceElement.isDeleteEnabled)
    priceElement.isEffective = !convertToBoolean(priceElement.isEffective)
    priceElement.isGroupedIndicator = convertToBoolean(priceElement.isGroupedIndicator)
    priceElement.isRateDenominatorUpdateEnabled = convertToBoolean(priceElement.isRateDenominatorUpdateEnabled)
    priceElement.isRateNumeratorUpdateEnabled = convertToBoolean(priceElement.isRateNumeratorUpdateEnabled)
    priceElement.isViewAuthorizationSufficient = convertToBoolean(priceElement.isViewAuthorizationSufficient)
    priceElement.isEditAuthorizationSufficient = convertToBoolean(priceElement.isEditAuthorizationSufficient)
}

def Boolean convertToBoolean(String value) {
    return value == 'X'
}

def Message setMonitoringIdentifiers(Message message) {
    message.setHeader("SAP_ApplicationID", message.getHeaders().get("SapMessageIdEx").toLowerCase())
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        def idocNo = message.getHeaders().get("SapIDocTransferId");
        if (idocNo != null) {
            messageLog.addCustomHeaderProperty("IDoc Number", idocNo)
        }
    }
    return message
}