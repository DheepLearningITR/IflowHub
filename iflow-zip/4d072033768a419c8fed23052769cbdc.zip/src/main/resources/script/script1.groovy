import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.xml.MarkupBuilder
import java.text.SimpleDateFormat;  
import java.util.Date;

def Message processData(Message message) {

    def map = message.getHeaders();

    def OpenAPIJobs = new JsonBuilder()

    def runMode = map.get("runMode");
    def startDate = map.get("StartDate");
    def endDate = map.get("EndDate");
    def templateType = map.get("templateType");
    def deltaFrom = map.get("DeltaFrom");
    def templateName = map.get("templateName");

    def (jobStartDate, jobEndDate) = []

    def now = new Date()
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    def now_String = formatter.format(now).toString()
    
    if(deltaFrom.equalsIgnoreCase("") || deltaFrom == null)
        deltaFrom = startDate
    
    def convertString2Date = { originalDateString, datePattern ->

        def output = (originalDateString.equalsIgnoreCase("")) ? "" : (new Date().parse(datePattern, originalDateString))

        return output
    }

    if (runMode.equalsIgnoreCase("adhoc")) {
        jobStartDate = startDate
        jobEndDate = endDate
    } else {
        jobStartDate = deltaFrom
        jobEndDate = now_String
        message.setHeader("DeltaFrom",now_String)
    }


    if (templateType.equalsIgnoreCase("Updated")) {
        OpenAPIJobs {
            viewTemplateName(templateName)
            filters {
                updatedDateFrom(convertString2Date(jobStartDate, "yyyy-MM-dd'T'HH:mm:ss'Z'").format("yyyy-MM-dd'T'HH:mm:ss'Z'", TimeZone.getTimeZone('UTC')))
                updatedDateTo(convertString2Date(jobEndDate, "yyyy-MM-dd'T'HH:mm:ss'Z'").format("yyyy-MM-dd'T'HH:mm:ss'Z'", TimeZone.getTimeZone('UTC')))
            }
        }
    } else {
        OpenAPIJobs {
            viewTemplateName(templateName)
            filters {
                createdDateFrom(convertString2Date(jobStartDate, "yyyy-MM-dd'T'HH:mm:ss'Z'").format("yyyy-MM-dd'T'HH:mm:ss'Z'", TimeZone.getTimeZone('UTC')))
                createdDateTo(convertString2Date(jobEndDate, "yyyy-MM-dd'T'HH:mm:ss'Z'").format("yyyy-MM-dd'T'HH:mm:ss'Z'", TimeZone.getTimeZone('UTC')))
            }
        }

    }


    def prettyJson = JsonOutput.prettyPrint(OpenAPIJobs.toString())
    message.setBody(prettyJson.toString().trim())

    return message;
}