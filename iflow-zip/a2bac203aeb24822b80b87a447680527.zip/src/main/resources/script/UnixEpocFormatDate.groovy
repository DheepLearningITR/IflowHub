import com.sap.it.api.mapping.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone

def String EpochFormat(String arg1) {
    // Define the date format without time
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd")
    df.setTimeZone(TimeZone.getTimeZone("UTC"))  // Ensure the parser interprets the date in UTC
    
    // Parse the date string
    Date date = df.parse(arg1)
    
    // Get the epoch time in milliseconds
    long epochMillis = date.getTime()
    
    // Convert milliseconds to seconds (Unix epoch time)
    long epochSeconds = epochMillis / 1000
    
    // Return the epoch time as a string
    return String.valueOf(epochSeconds)
}