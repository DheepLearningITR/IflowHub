import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.op.agent.mpl.*;
import groovy.transform.Field;
import groovy.json.JsonOutput;

@Field String ORIGINAL_PAYLOAD_LOG = '1. Inbound Request';
@Field String EXIT_OUTPUT_JSON_LOG = '1.1 Post-Exit Request';
@Field String SB_ERROR_RESPONSE_JSON = '2. SB Error Response';
@Field String IFLOW_JSON_ERROR_RESPONSE_LOG = '3. iFlow Error Response';
@Field String IFLOW_JSON_RESPONSE_LOG = '3. iFlow Response';


def Boolean isDebug(Message message) {
     final MplConfiguration config = message.getProperty("SAP_MessageProcessingLogConfiguration");
     return config.getOverallLogLevel() == MplLogLevel.DEBUG;
}

def Message logOriginalRequest(Message message) { 
     processOriginalData(ORIGINAL_PAYLOAD_LOG, message);
}

def Message logSBErrorResponseJson(Message message) {
     processData(SB_ERROR_RESPONSE_JSON, message);
}

def Message logiFlowJsonErrorResponse(Message message) { 
     processData(IFLOW_JSON_ERROR_RESPONSE_LOG, message);
}

def Message logiFlowJsonResponse(Message message) { 
     processData(IFLOW_JSON_RESPONSE_LOG, message);
}

def Message logPostExitOutput(Message message) { 
     processData(EXIT_OUTPUT_JSON_LOG, message);
}



def Message processOriginalData(String title, Message message){
  if (isDebug(message)) {
       def body = message.getBody(java.lang.String);
       def headers = message.getHeaders();
       def properties = message.getProperties();

       def propertiesAsString ="\n";
       properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };

       def headersAsString ="\n";
       headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };

       def messageLog = messageLogFactory.getMessageLog(message);

       if(messageLog != null) {
            if (body != null) {
                 messageLog.addAttachmentAsString(title , "\n Properties \n ----------   \n" + propertiesAsString +
                                                               "\n Headers \n ----------   \n" + headersAsString +
                                                               "\n Body \n ----------  \n\n" + body, "text/plain");
            } else {
                 messageLog.addAttachmentAsString(title , "\n Properties \n ----------   \n" + propertiesAsString +
                                                               "\n Headers \n ----------   \n" + headersAsString +
                                                               "\n Body \n ----------  \n\n" + "", "text/plain");
            }
       }
  }
  return message;
}

def Message processData(String title, Message message) {
     if (isDebug(message)) {
          def body = message.getBody(java.lang.String);
          def headers = message.getHeaders();
          def properties = message.getProperties();

          def propertiesAsString ="\n";
          properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };

          def headersAsString ="\n";
          headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };

          def messageLog = messageLogFactory.getMessageLog(message);

          if(messageLog != null) {
               if (body != null) {
                    messageLog.addAttachmentAsString(title , "\n Properties \n ----------   \n" + propertiesAsString +
                                                                  "\n Headers \n ----------   \n" + headersAsString +
                                                                 "\n Body \n ----------  \n\n" + JsonOutput.prettyPrint(body), "text/plain");
               } else {
                    messageLog.addAttachmentAsString(title , "\n Properties \n ----------   \n" + propertiesAsString +
                                                                  "\n Headers \n ----------   \n" + headersAsString +
                                                                  "\n Body \n ----------  \n\n" + "", "text/plain");
               }
          }
     }
     return message;
}
