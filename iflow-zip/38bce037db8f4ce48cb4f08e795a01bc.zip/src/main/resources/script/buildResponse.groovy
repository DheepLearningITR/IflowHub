import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;
import groovy.json.JsonOutput;
import groovy.json.JsonSlurper;

@Field String IFLOW_ERROR_CODE = '500';
@Field String IFLOW_ERROR_TYPE = 'IFLOW_ERROR';
@Field String IFLOW_ERROR_MSG = 'A technical error occurred in the iFlow.';
@Field String IFLOW_INVALID_HOST_CODE = '404';
@Field String IFLOW_INVALID_HOST_MSG = 'The SAP Subscription Billing host configured in the iFlow could not be reached.';
@Field String IFLOW_INVALID_CREDENTIAL_NAME_CODE = '404';
@Field String IFLOW_INVALID_CREDENTIAL_NAME_MSG = 'The credential name used to access SAP Subscription Billing could not be found in the security material of the CPI tenant.';
@Field String IFLOW_UNKNOWN_ERROR_CODE = '500';
@Field String IFLOW_UNKNOWN_ERROR_MSG = 'An unknown error occurred while calling SAP Subscription Billing.';
@Field String IFLOW_ERROR_DETAILS = 'To find additional details, please use the SAP Cloud Integration message ID: ';

class ResponseMsg {
    String status
	String message
	String type
	List details
}

def Message buildErrorResponse(Message message) {

	def ResponseMsg respMsg;	
    def detailMsgs = [:]
	List<String> error_details = [];

	try{
        def map = message.getProperties();
        def ex = map.get("CamelExceptionCaught");
        
        if (ex != null) {

            def error_type = ex.getClass().getCanonicalName();
    
            if (error_type != null) {
                
                detailMsgs.message = IFLOW_ERROR_DETAILS + message.getProperty("SAP_MessageProcessingLogID");
                error_details.add(detailMsgs);

                switch ( error_type ) {
    
                    // Forward the errors coming from SB to the caller
                    case "org.apache.camel.component.ahc.AhcOperationFailedException":
                        message.setBody(ex.getResponseBody());
                        message.setProperty("http.ResponseBody",ex.getResponseBody());
                        message.setProperty("http.StatusCode", ex.getStatusCode());
                        message.setProperty("http.StatusText", ex.getStatusText());
                        break;
    
                    // Invalid SB host of the Receiver configuration
                    case "java.net.UnknownHostException":
                        respMsg = buildResponseMessage(IFLOW_INVALID_HOST_CODE, IFLOW_INVALID_HOST_MSG, IFLOW_ERROR_TYPE, error_details);
                        message.setHeader("CamelHttpResponseCode", IFLOW_INVALID_HOST_CODE);
                        break;
                        
                    // Invalid credential name in the Receiver configuration
                    case "com.google.common.util.concurrent.UncheckedExecutionException":
                        if (ex.toString().contains('NoArtifactDecriptorFoundForArtifactName')) {
                            respMsg = buildResponseMessage(IFLOW_INVALID_CREDENTIAL_NAME_CODE, IFLOW_INVALID_CREDENTIAL_NAME_MSG, IFLOW_ERROR_TYPE, error_details);
                            message.setHeader("CamelHttpResponseCode", IFLOW_INVALID_CREDENTIAL_NAME_CODE);
                            break;
                        }
                        
                    // Unknown errors when calling SB
                    default:
         	 	        respMsg = buildResponseMessage(IFLOW_UNKNOWN_ERROR_CODE, IFLOW_UNKNOWN_ERROR_MSG, IFLOW_ERROR_TYPE, error_details);
                        message.setHeader("CamelHttpResponseCode", IFLOW_UNKNOWN_ERROR_CODE);
                        break;
                }
            }
        } 
 	} catch (Exception e) { 
	   	respMsg = buildResponseMessage(IFLOW_ERROR_CODE, IFLOW_ERROR_MSG, IFLOW_ERROR_TYPE, error_details);
	   	message.setHeader("CamelHttpResponseCode", IFLOW_ERROR_CODE);
	}

 	if (respMsg != null) {
    	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(respMsg)));
 	}

    return message;
}

def ResponseMsg buildResponseMessage(String rsp_status, String rsp_message, String rsp_type, List rsp_details) {
    
    return new ResponseMsg(status:rsp_status, message:rsp_message, type:rsp_type, details:rsp_details);

}