import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.json.JsonOutput;

def Message parseHeaders(Message message) {

	def map = message.getHeaders();

    def sfsfAttributeType = map.get("sfsfAttributeType");
	message.setProperty("sfsfAttributeType", sfsfAttributeType);
	
    def sfsfAttributeFound = map.get("sfsfAttributeFound");
	message.setProperty("sfsfAttributeFound", sfsfAttributeFound);
	
    def testRun = map.get("testRun");
	message.setProperty("testRun", testRun);	
	
	//divide filesize to 2 as both en_US and de_DE languages are included in the same file!! 
	def SFTP_Target_FileSize = message.getProperties().get("SFTP_Target_FileSize").toInteger();
	SFTP_Target_FileSize = SFTP_Target_FileSize / 2;
	message.setProperty("SFTP_Target_FileSize", SFTP_Target_FileSize);
	
	//used to clear hashmap global variables
	def emptyHmap = new HashMap<String, String>();
	emptyHmap.put('null','');
	message.setProperty("emptyHmap", emptyHmap);	
	
	return message;
}

def Message gather_filenames(Message message) {
    def body = message.getBody(String);
    def root = new XmlSlurper().parseText(body);
    
    List<String> files = [
        "filenameUPDTexts"
    ];

    files.each { file ->
        Set<String> filenames = new HashSet<>();
        def elements = root."$file";
        elements.each(){
            def fname = it.text().trim();
            if(fname && fname != '[]'){
                filenames.add(fname)
            }
        }
        if(!filenames.isEmpty()){
            message.setHeader(file, JsonOutput.toJson(filenames));
        }
    }
    
    
    // Check if root is empty or has no children
    if (root.children().size() > 0) {    
    
        // Collect all sumCreate values and calculate total sum
        def sumTextUpdates = root.'**'.findAll { it.name() == 'sumTextUpdates' }*.text()*.toInteger().sum();
        message.setHeader("sumTextUpdates", sumTextUpdates);
        
        // Collect all sumDuplicateAttributeTexts values and calculate total sum
        def sumDuplicateAttributeTexts = root.'**'.findAll { it.name() == 'sumDuplicateAttributeTexts' }*.text()*.toInteger().sum();
        message.setHeader("sumDuplicateAttributeTexts", sumDuplicateAttributeTexts);
        
        Set<String> duplicateAttributeTexts = extractSetFromXml(root, 'duplicateAttributeTexts')
        message.setHeader("duplicateAttributeTexts", JsonOutput.toJson(duplicateAttributeTexts).toString());               
        
    }
    
    return message;
}

// Reusable method to extract and clean up sets from XML nodes
Set<String> extractSetFromXml(def xml, String tagName) {
    
    Set<String> resultSet = new HashSet<>();
    xml.'**'.findAll { it.name() == tagName }.each { node ->
        def content = node.text().trim();
        if (content != '[]'){ 
            
            if(content.startsWith("[") && content.endsWith("]")) {
                content = content[1..-2]; // remove square brackets
                
                content.split(',').each { item ->
                    def trimmed = item.trim();
                    if (trimmed) {
                        trimmed = trimmed.replace('%2C', ','); //decode commas
                        resultSet.add(trimmed);
                    }
                }
            }
        }
    }
    return resultSet;
}

def String escapeText(txt){
    //escape special including '&'. This is a TEMPORARY fix until SAP Fixes Note 3459488!!  
    //txt = StringEscapeUtils.escapeHtml4(txt);        
    def stxt = txt.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    return stxt;
}

def String format_desc(description){
    String descr = description;
    descr = descr.replaceAll(/\/n/, "\n");  //replace with actual new line
    descr = descr.replaceAll ('"','\\\\\\"'); //escape double quotes
    descr = descr.take(4000);  //4000 char limit    
    return descr;
}

def Message process_textUpdates(Message message) {
	
	def map = message.getProperties();
	def attributeType = map.get("sfsfAttributeType"); 
	HashMap<String, String> hmapTexts = map.get("hmap_sfsfAttributeTexts"); 
    List<String> duplicateAttributeTexts = [];
    def sumDuplicateAttributeTexts = 0;	
	
	def body = message.getBody(java.lang.String);
    HashMap<String, String> hmapAttrib = map.get("hmap_sfsfAttributes"); 

	//change status 
	def sumTextUpdates = 0;
	def Root = new XmlParser().parseText(body);
	
    Root.file.each{
        it.attribute.each{r->
            def sfsfAttribExtCode = r.id[0].text(); //with cbr_ prefix
            if(!hmapAttrib.containsKey(sfsfAttribExtCode)){
                //Talent Skill NOT FOUND in SFSF Attribute, nothing to update!
                r.replaceNode{}; //remove
            }else{
                //Talent Skill FOUND in SFSF
                if(hmapTexts!=null){
                    //check for duplicates en_US Texts 
                    //JIRA INT-326 Same Name with different Names is allowed
                    def name = attributeType+'-en_US-'+r.translation_en_US[0].title.text().trim().toLowerCase();
                    def duplicateId = hmapTexts.get(name);
                    if(duplicateId!=null && sfsfAttribExtCode!=duplicateId){
                        //duplicate Text found, remove Translation Node
                        r.translation_en_US.replaceNode();
                        duplicateAttributeTexts.add(sfsfAttribExtCode+':'+name.replace(',', '%2C')+'|'+duplicateId);
                        sumDuplicateAttributeTexts++;
                    }
                    
                    //check for duplicate de_DE Texts!  
                    //JIRA INT-363 Same name Translations allowed as long as they're different types
                    name = attributeType+'-de_DE-'+r.translation_de_DE[0].title.text().trim().toLowerCase();
                    duplicateId = hmapTexts.get(name);
                    if(duplicateId!=null && sfsfAttribExtCode!=duplicateId){
                        //duplicate Text found, remove Translation Node
                        r.translation_de_DE.replaceNode();  
                        duplicateAttributeTexts.add(sfsfAttribExtCode+':'+name.replace(',', '%2C')+'|'+duplicateId);
                        sumDuplicateAttributeTexts++;
                    }
                    
                    if( r.findAll { it.name().startsWith('translation_') }.size() == 0){
                        //remove entire skill Node
                        r.replaceNode{}; 
                    }else{
                        sumTextUpdates++;
                        
                        r.findAll { it.name().startsWith('translation_') }.each { t ->
                            // Truncate the description text
                            if(t.description[0]){
                                t.description[0].value = format_desc(t.description[0].text());
                            }
                        }    
                    }
                }    
            }
        }
    }
    
    message.setProperty("hmap_sfsfAttributes",null);  //clear processed data
    message.setBody(XmlUtil.serialize(Root));
    message.setProperty("sumTextUpdates",sumTextUpdates.toString());
    message.setProperty("sumDuplicateAttributeTexts",sumDuplicateAttributeTexts.toString());
    message.setProperty("duplicateAttributeTexts",duplicateAttributeTexts.toString()); 
    
	return message;
}


