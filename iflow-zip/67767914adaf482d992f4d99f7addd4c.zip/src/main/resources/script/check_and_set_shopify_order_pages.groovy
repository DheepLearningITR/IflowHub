import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser

def Message processData(Message message) {
    def body = message.getBody(String)
    def parser = new XmlParser().parseText(body)

    def hasNextPageElement = parser.data.orders.pageInfo.hasNextPage
    def hasNextPage = hasNextPageElement?.text() == 'true'

    if (hasNextPage) {
        def endCursor = parser.data.orders.pageInfo.endCursor.text()
        message.setProperty("lastNode", endCursor)
        message.setProperty("hasNextPage", true)
    } else {
        message.setProperty("hasNextPage", false)
    }
   
    return message
}