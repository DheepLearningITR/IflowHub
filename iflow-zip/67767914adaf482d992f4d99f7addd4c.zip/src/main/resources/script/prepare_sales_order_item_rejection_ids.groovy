import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def xml = new XmlSlurper().parse(body)

    def salesOrderItem = xml.A_SalesOrderItemType.SalesOrderItem.text()

    if (salesOrderItem) {
        message.setProperty("s4SalesOrderItemID", salesOrderItem)
    }

    return message;
}