import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def currentExecutionTime = message.getProperty("current_execution_last_processed_shopify_order_updated_at_timestamp")
    def requestDate = message.getProperty("lastShopifyOrderRequestTimestamp")

    if (currentExecutionTime == null || currentExecutionTime.toString().trim().isEmpty()) {
        message.setProperty("current_execution_last_processed_shopify_order_updated_at_timestamp", requestDate)
    } else {
        message.setProperty("current_execution_last_processed_shopify_order_updated_at_timestamp", currentExecutionTime.toString())
    }

    return message
}