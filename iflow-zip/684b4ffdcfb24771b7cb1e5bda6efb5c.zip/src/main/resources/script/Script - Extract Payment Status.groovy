import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*

def Message processData(Message message) {
    def json = new JsonSlurper().parseText(message.getBody(String));
    message.setProperty('wf_paymentstatus', json.A_OperationalAcctgDocItemCube.A_OperationalAcctgDocItemCubeType.IsCleared);
    
    
    def item = json.A_OperationalAcctgDocItemCube.A_OperationalAcctgDocItemCubeType.AccountingDocumentItem
    def stringLen = 3;
    def strLen = item.toString().size()
    def expectedLen = stringLen.toInteger() - strLen.toInteger()
    for(i = 0; i<=expectedLen-1;i++)
    {
    	item = "0" + item;
    }
    
    def bKey = json.A_OperationalAcctgDocItemCube.A_OperationalAcctgDocItemCubeType.CompanyCode + '_' + json.A_OperationalAcctgDocItemCube.A_OperationalAcctgDocItemCubeType.AccountingDocument + '_' + json.A_OperationalAcctgDocItemCube.A_OperationalAcctgDocItemCubeType.FiscalYear + '_' + item + '_' + json.A_OperationalAcctgDocItemCube.A_OperationalAcctgDocItemCubeType.DunningLevel;
    
    message.setProperty('wf_businessKey', bKey);
    return message;
}