import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

//Routers
def clearRoute(message) {
    message.setProperty("checkErrorOccured", "");
    message.setProperty("Irrelevant", "")
    message.setProperty("RouterType", "")
}
def setRouteIrrelevant(Message message) {
    clearRoute(message)
    message.setProperty("Irrelevant", "X")
}

// process message
def Message processData(Message message) { 
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)
    def eventType = jsonResult.eventType?.toLowerCase()
    def contactID
    def equipmentID

    message.setHeader("EventType", eventType)

    // decide on iFlow route
    switch (eventType) {
        
        case "contact.created":
            contactID = jsonResult.data?.contact.id as String ?: ''
            if (contactID != null || contactID != ''){
                message.setProperty("RouterType", "contact")
                
            } else {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            }
            break;

        case "contact.updated":
            contactID = jsonResult.data?.contact.externalID as String ?: ''
            if (contactID != null || contactID != ''){
                message.setProperty("RouterType", "contact")
                
            } else {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            }
            break;
            
        case "equipment.created":
            equipmentID = jsonResult.data?.equipment.id as String ?: ''
            objectCategory = jsonResult.data?.equipment.objectCategory as String ?: ''
            if(equipmentID != null || equipmentID != '') {
                message.setProperty("RouterType", "equipment")
                
            } else {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            }
            break;

        case "equipment.updated":
            equipmentID = jsonResult.data?.equipment.externalID as String ?: ''
            objectCategory = jsonResult.data?.equipment.objectCategory as String ?: ''
            if (equipmentID != null || equipmentID != ''){
                message.setProperty("RouterType", "equipment")
                
            } else {
                // route: Irrelevant, ignore, no error
                setRouteIrrelevant(message)
            }
            break;

        default:
            // route: Irrelevant, ignore, no error
            setRouteIrrelevant(message)
            break
    }

    return message
}
