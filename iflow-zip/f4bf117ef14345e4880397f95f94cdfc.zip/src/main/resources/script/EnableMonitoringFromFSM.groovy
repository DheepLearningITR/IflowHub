import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
// Version 1
// get ids from incoming message from FSM API for setting SAP Application ID and custom log headers
def Message processData(Message message) { 
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)
    
    // fetch X-Request-ID as SAP_ApplicationID
    def sapApplicationID = message.getHeaders().get("x-request-id")
    if (sapApplicationID != null && sapApplicationID != '') {
        message.setHeader("SAP_ApplicationID", sapApplicationID) 
    }
    // add contact(id) to message headers and custom log headers
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null) {
        def contactID
        // get contactID
        try {
            contactID = jsonResult['data']['contact']['externalId'] as String
        } catch(Exception ex0) { /* not found */ }
        if (contactID == null) {
            try {
                contactID = jsonResult['data']['contact']['id'] as String
            } catch(Exception ex1) { /* not found */ }
        }
        if(contactID != null && contactID != '') {
            message.setHeader("contactID", contactID)
            messageLog.addCustomHeaderProperty("Contact ID", contactID)    
        }
        def equipmentID
        // get equipmentID
        try {
            equipmentID = jsonResult['data']['equipment']['externalId'] as String
        } catch(Exception ex0) { /* not found */ }
        if (equipmentID == null) {
            try {
                equipmentID = jsonResult['data']['equipment']['id'] as String
            } catch(Exception ex1) { /* not found */ }
        }
        if(equipmentID != null && equipmentID != '') {
            message.setHeader("equipmentID", equipmentID)
            messageLog.addCustomHeaderProperty("Equipment ID", equipmentID)    
        }
    }
    return message
}
