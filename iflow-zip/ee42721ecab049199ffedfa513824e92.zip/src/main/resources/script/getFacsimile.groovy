import com.sap.it.api.mapping.*;


def String getFascimileNumber(String header, MappingContext context) {

 String FaxNumber = context.getProperty("FaxNumber");
 
 return FaxNumber != "" ? FaxNumber : "";

}