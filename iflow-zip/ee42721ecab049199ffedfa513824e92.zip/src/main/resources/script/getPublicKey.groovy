import com.sap.it.api.mapping.*;

def String getPublicKey(String header, MappingContext context){
    
    String internalID = context.getProperty("InternalID");
    String publicKey = internalID + "|" + internalID + "|KNA1|null";
    
    return publicKey;
}
