import java.util.HashMap;
import java.util.ArrayList;
import groovy.json.*;
import groovy.xml.*;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def jsonSlurper = new JsonSlurper();
    def body = message.getBody(String.class);
    
    if (!body) {
        return message;
    }

    def jsonData = jsonSlurper.parseText(body);
    message.setProperty("interos_job_uuid", null);

    data = jsonData.get("data");
    if (data) {
        if (data instanceof ArrayList) {
            data = data[0]
        }

        job = data.get("job");

        if (job.uuid) {
            message.setProperty("interos_job_uuid", job.uuid);
        }

        if (job.status) {
            message.setProperty("interos_job_status", job.status);
        }
    }

    return message;
}
