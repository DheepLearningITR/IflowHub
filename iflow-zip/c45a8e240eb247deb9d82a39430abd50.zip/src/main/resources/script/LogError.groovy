import java.util.HashMap;
import groovy.json.*;
import groovy.xml.*;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);

    // get a map of headers
    def headMap = message.getHeaders();

    // get a map of properties
    def propMap = message.getProperties();

    // log headers
    for (def headkey : headMap.keySet()) {
        if (!headkey.startsWith("SECURE_")) {
            def headval = headMap.get(headkey) as String;
            messageLog.addAttachmentAsString(headkey, headval, "text/plain");
        }
    }

    // log properties
    for (def propkey : propMap.keySet()) {
        if (!propkey.startsWith("SECURE_")) {
            def propval = propMap.get(propkey) as String;
            messageLog.addAttachmentAsString(propkey, propval, "text/plain");
        }
    }

    // get an exception java class instance
    def ex = propMap.get("CamelExceptionCaught");

    if (ex != null) {
        // save the error response as a message attachment 
        messageLog.addAttachmentAsString("Exception", ex.getResponseBody(), "text/plain");

        // copy the http error response to the message body
        message.setBody(ex.getResponseBody());

        // copy the value of http error code (i.e. 500) to a property
        message.setProperty("http.StatusCode", 500);

        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
            // copy the http error response to an exchange property
            message.setProperty("http.ResponseBody",ex.getResponseBody());

            // copy the value of http error code (i.e. 500) to a property
            message.setProperty("http.StatusCode",ex.getStatusCode());

            // copy the value of http error text (i.e. "Internal Server Error") to a property
            message.setProperty("http.StatusText",ex.getStatusText());
        }

        throw new Exception(ex);
    }

    return message;
}
