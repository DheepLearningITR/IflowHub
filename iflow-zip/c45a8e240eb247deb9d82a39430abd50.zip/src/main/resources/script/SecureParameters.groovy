import java.util.HashMap;
import groovy.json.*;
import groovy.xml.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.securestore.exception.SecureStoreException;

def Message processData(Message message) {
    // get the security store
    def secureStorageService = ITApiFactory.getService(SecureStoreService, null);

    // get a map of properties
    def propMap = message.getProperties();

    try {
        def aribaAuthBasic = propMap.getOrDefault("SECURE_ARIBA_AUTH_BASIC", null);
        if (aribaAuthBasic != null && aribaAuthBasic.startsWith("{") && aribaAuthBasic.endsWith("}")) {
            aribaAuthBasic = aribaAuthBasic.replace("{", "");
            aribaAuthBasic = aribaAuthBasic.replace("}", "");
            def secureParameter = secureStorageService.getUserCredential(aribaAuthBasic);
            if (secureParameter != null) {
                def secureValue = secureParameter.getPassword().toString();
                message.setProperty("SECURE_ARIBA_AUTH_BASIC", secureValue);
            }
        }
    } catch(Exception e) {
        throw new SecureStoreException("Secure Parameter 'SECURE_ARIBA_AUTH_BASIC' not available", e);
    }

    try {
        def aribaAuthApiKey = propMap.getOrDefault("SECURE_ARIBA_AUTH_API_KEY", null);
        if (aribaAuthApiKey != null && aribaAuthApiKey.startsWith("{") && aribaAuthApiKey.endsWith("}")) {
            aribaAuthApiKey = aribaAuthApiKey.replace("{", "");
            aribaAuthApiKey = aribaAuthApiKey.replace("}", "");
            def secureParameter = secureStorageService.getUserCredential(aribaAuthApiKey);
            if (secureParameter != null) {
                def secureValue = secureParameter.getPassword().toString();
                message.setProperty("SECURE_ARIBA_AUTH_API_KEY", secureValue);
            }
        }
    } catch(Exception e) {
        throw new SecureStoreException("Secure Parameter 'SECURE_ARIBA_AUTH_API_KEY' not available", e);
    }

    try {
        def interosCustomerID = propMap.getOrDefault("SECURE_INTEROS_CUSTOMER_ID", null);
        if (interosCustomerID != null && interosCustomerID.startsWith("{") && interosCustomerID.endsWith("}")) {
            interosCustomerID = interosCustomerID.replace("{", "");
            interosCustomerID = interosCustomerID.replace("}", "");
            def secureParameter = secureStorageService.getUserCredential(interosCustomerID);
            if (secureParameter != null) {
                def secureValue = secureParameter.getPassword().toString();
                message.setProperty("SECURE_INTEROS_CUSTOMER_ID", secureValue);
            }
        }
    } catch(Exception e) {
        throw new SecureStoreException("Secure Parameter 'INTEROS_CUSTOMER_ID' not available", e);
    }

    try {
        def interosAuthApiKey = propMap.getOrDefault("SECURE_INTEROS_AUTH_API_KEY", null);
        if (interosAuthApiKey != null && interosAuthApiKey.startsWith("{") && interosAuthApiKey.endsWith("}")) {
            interosAuthApiKey = interosAuthApiKey.replace("{", "");
            interosAuthApiKey = interosAuthApiKey.replace("}", "");
            def secureParameter = secureStorageService.getUserCredential(interosAuthApiKey);
            if (secureParameter != null) {
                def secureValue = secureParameter.getPassword().toString();
                message.setProperty("SECURE_INTEROS_AUTH_API_KEY", secureValue);
            }
        }
    } catch(Exception e) {
        throw new SecureStoreException("Secure Parameter 'INTEROS_AUTH_API_KEY' not available", e);
    }

    return message;
}
