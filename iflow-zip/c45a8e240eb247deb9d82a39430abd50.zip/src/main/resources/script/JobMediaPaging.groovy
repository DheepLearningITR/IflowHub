import java.util.HashMap;
import groovy.json.*;
import groovy.xml.*;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(String.class);

    def jsonSlurper = new JsonSlurper();
    def jsonData = jsonSlurper.parseText(body);
    def loopCounter = message.getProperty("loop_counter").toInteger()

    message.setProperty("loop_counter", "-1")
    message.setProperty("interos_job_uuid", "")
    message.setProperty("interos_media_uuid", "")

    def data = jsonData.get("data");
    if (data) {
        def media_list = data.get("job_media");
        if (media_list && media_list.size() > loopCounter) {
            def job_media = media_list[loopCounter]
            message.setProperty("interos_job_uuid", job_media.job_uuid);
            message.setProperty("interos_media_uuid", job_media.uuid);

            loopCounter = loopCounter + 1
            message.setProperty("loop_counter", loopCounter.toString())
        }
    }

    return message;
}
