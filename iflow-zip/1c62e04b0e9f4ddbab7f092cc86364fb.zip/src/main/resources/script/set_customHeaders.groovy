import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def testRun = message.getProperties().get("testRun");
		if(testRun != null){
			messageLog.addCustomHeaderProperty("cbr_testRun", testRun);		
        }	    
        def sfsfEntityType = message.getProperties().get("sfsfEntityType");
		if(sfsfEntityType != null){
			messageLog.addCustomHeaderProperty("sfsf_entityType", sfsfEntityType);		
        }        
        def wsmId = message.getProperties().get("wsmId");
		if(wsmId != null){
			messageLog.addCustomHeaderProperty("sfsf_wsmId", wsmId);		
        }
        def roleExtCode = message.getProperties().get("roleExtCode");
		if(roleExtCode != null){
			messageLog.addCustomHeaderProperty("sfsf_roleExtCode", roleExtCode);		
        }
        def externalCode = message.getProperties().get("externalCode");
		if(externalCode != null && externalCode != ''){
			messageLog.addCustomHeaderProperty("sfsf_roleAttrExtCode", externalCode);		
        }        
	}
	return message;
}

