import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;

def Message processData(Message message) {
	def unique_id = message.getProperty('ENDPOINT_ID');
    def PD_NAMESPACE = "DME_Generic_Processing_$unique_id";
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 
    if (service == null){
      throw new IllegalStateException("Partner Directory Service not found");
    }
    def headers = message.getHeaders();
    if (headers != null) {
        def rfc_target_url = headers.get("ErpDestination");
        if (rfc_target_url == null || "".equals(rfc_target_url)) {
            throw new IllegalStateException("ErpDestination not found");
        }
    }
	
	def body = message.getBody(String.class);
	if (body != null) {
		message.setBody(body.substring(body.indexOf("<BAPI_MATERIAL_AVAILABILITY>")))
	}
	
	return message;
}
