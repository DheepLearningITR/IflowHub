import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
def Message processData(Message message) {
      
      String Credential = message.getProperty("OpenText_Credentials")
      
      def service =  ITApiFactory.getApi(SecureStoreService.class, null)
      def credential_Secret = service.getUserCredential(Credential)
      
      String username_Secret = new String(credential_Secret.getUsername())
      String password_Secret = new String(credential_Secret.getPassword())
      
      message.setProperty("UserName_OT",username_Secret)
      message.setProperty("Password_OT",password_Secret)
      
      return message;
      
}