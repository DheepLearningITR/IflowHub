import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) 
{

    def body = message.getBody(java.lang.String) as String;

    def query = new XmlSlurper().parseText(body);

    def map = message.getProperties()

    def ContactID = map.get("ContactID")

    
     if(query.Log.MaximumLogItemSeverityCode == 3)
     {
          query.Log.Item.each { it -> 
            if(it.SeverityCode == 3)
            {
                message.setProperty("ErrorType","CRMError");
                message.setProperty('http.ResponseBody', body)
            }};
     }

     else 
     {
      
        def sap_ext_id = query.ContactPerson.BusinessPartner.ID
        message.setBody('''{"id":"'''+ContactID+'''","externalId":"'''+sap_ext_id+'''"}''')
    
     }
    return message;

}