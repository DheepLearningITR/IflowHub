import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def map = message.getProperties();
    def pointer = map.get("Attachment_Size");
    def id = map.get("attachment_id");
    
    Map<String,String> hmap = map.get("Content_Map");
    hmap.put(id, body);
    
    message.setProperty('Content_Map', hmap);
    message.setProperty('Attachment_Size', pointer - 1);
    return message;
}
