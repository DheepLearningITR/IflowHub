import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def map = message.getProperties();
    def attList = map.get("Attachment_List");
    def pointer = map.get("Attachment_Size");
    
    message.setProperty("attachment_id", attList[pointer - 1]);
    return message;
}
