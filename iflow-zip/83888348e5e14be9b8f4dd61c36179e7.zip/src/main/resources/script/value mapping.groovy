import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;


def Message processData(Message msg) {
    def helperValMap = ITApiFactory.getApi(ValueMappingApi.class, null)
    def properties = msg.getProperties();

    def input = properties.get('Bussys');
    def url = helperValMap.getMappedValue('SAP', 'Bussys', input , 'GK', 'ws_binding_url');
    def credentials = helperValMap.getMappedValue('SAP', 'Bussys', input , 'GK', 'ws_credentials_id');
    def cloudconnectionid = helperValMap.getMappedValue('SAP', 'Bussys', input , 'GK' , 'ws_cloud_connector_id');
    msg.setProperty( 'binding_url', url );
    msg.setProperty( 'credentials_id', credentials);
    msg.setProperty( 'cloud_connector_id', cloudconnectionid);
	return msg;
	
}