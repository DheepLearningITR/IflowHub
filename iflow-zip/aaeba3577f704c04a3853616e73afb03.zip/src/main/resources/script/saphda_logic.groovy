import com.sap.it.api.mapping.*;
import org.json.JSONObject;
import org.json.JSONException;
import groovy.json.JsonBuilder
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

def Message handleRequestBody(Message message) {
    //Body
    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body)
    //Headers
    //def headers = message.getHeaders();
    //def value = headers.get("oldHeader");
    //message.setHeader("oldHeader", value + " modified");
    //message.setHeader("newHeader", "newHeader");
    //Properties
    //def properties = message.getProperties();
    //value = properties.get("oldProperty");
    //message.setProperty("oldProperty", value + " modified");


    def saphda_calmonth_from = URLEncoder.encode(input.calmonthFrom,StandardCharsets.UTF_8.name())
    message.setProperty("saphda_calmonth_from", saphda_calmonth_from);
    message.setProperty("saphda_current_calmonth", saphda_calmonth_from);

    def saphda_calmonth_to = URLEncoder.encode(input.calmonthTo,StandardCharsets.UTF_8.name())
    message.setProperty("saphda_calmonth_to", saphda_calmonth_to);

    def saphda_chunck2 = input.saphda_chunck
    if ( saphda_chunck2 instanceof Integer ) {
        saphda_chunck = saphda_chunck2
    } else {
		saphda_chunck = Integer.parseInt(saphda_chunck2)
    }       
    message.setProperty("saphda_chunck", saphda_chunck);
   
    def saphda_maxlines2 = input.saphda_maxlines
    if ( input.saphda_maxlines != null ) {
    if ( saphda_maxlines2 instanceof Integer ) {
        saphda_maxlines = saphda_maxlines2
    } else {
		saphda_maxlines = Integer.parseInt(saphda_maxlines2)
    }       
    message.setProperty("saphda_maxlines", saphda_maxlines);
    } else {
    message.setProperty("saphda_maxlines", 999999);
    }
    
    def saphda_transactionID = UUID.randomUUID().toString().replace("-", "");
    message.setProperty("saphda_transactionID", saphda_transactionID);
    
    return message;
}

def Message topskip(Message message) {
    def propMap = message.getProperties()
    def CamelLoopIndex = propMap.get("CamelLoopIndex")
    def saphda_chunck = propMap.get("saphda_chunck")

    def calc = saphda_chunck.toInteger() * CamelLoopIndex.toInteger()
    message.setProperty("saphda_skip",calc.toString())
    return message;

}

def String convertDate(String arg1){

    Date date = Date.parse( 'MM/yyyy', arg1 )
    String converted_datetime = date.format( 'yyyy-MM-dd\'T\'HH:mm:ss' )

    return converted_datetime;
}


def Message transform(Message message) {

    Reader body = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(body)
    def saphda_actuals_array = input.get("d").get("results")
    def propMap = message.getProperties()
    def saphda_current_calmonth = propMap.get("saphda_current_calmonth")
    def saphda_calmonth_from = propMap.get("saphda_calmonth_from")
    def saphda_calmonth_to = propMap.get("saphda_calmonth_to")
    def commit_val = propMap.get('saphda_commit')
    def chunksize = propMap.get('saphda_chunck')
    def skip = propMap.get('saphda_skip')
    def maxLines = propMap.get("saphda_maxlines")
    def saphda_ipb_credential = propMap.get("saphda_ipb_credential")
    def saphda_ibp_url = propMap.get("saphda_ibp_url")
    def saphda_ibp_planningarea = propMap.get("saphda_ibp_planningarea")
    def saphda_transactionID = propMap.get('saphda_transactionID')


    commit_val = false
    def count = input.get("d").get("__count").toInteger()
    if ( count <= ( skip.toInteger() + chunksize.toInteger() ) || maxLines.toInteger() <= ( skip.toInteger() + chunksize.toInteger() ) ) {
        message.setProperty("saphda_commit",'true')
        commit_val = true
    }

    def builder = new JsonBuilder();
    builder {
        "hostName" saphda_ibp_url
        "credentialsName" saphda_ipb_credential
        "planningArea" saphda_ibp_planningarea
        "commit" commit_val.toString()
        "oData" "true"
        'transactionId' saphda_transactionID
        'fieldsString' 'PERIODID3_TSTAMP,PRDID,CURRID,CUSTID,SALESSPEND'
        sacPayload saphda_actuals_array.collect {
            [
                    PERIODID3_TSTAMP: convertDate(it.FiscalYearPeriod),
                    PRDID           : it.SoldMaterial,
                    CURRID          : it.CompanyCodeCurrency,
                    CUSTID          : it.Customer,
                    SALESSPEND      : it.AmountInCompanyCodeCurrency
            ]
        }
    }

    def prettyBody = builder.toPrettyString()

    message.setBody(prettyBody);

    return message;
}


def Message catch_camels(Message message){

    def map  = message.getProperties();
    def ex   = map.get("CamelExceptionCaught");
    def exceptionText;

    if (ex != null)
    {
        exceptionText    = ex.getMessage();
        def messageLog   = messageLogFactory.getMessageLog(message);
        messageLog.addAttachmentAsString("Exception", exceptionText,"application/text");

        // copy the http error response body as a property
        message.setProperty("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());

        try {

            def mp = [
                    "IBP Host" :  message.getProperty('saphda_ibp_url'),
                    "IBP credentials" :  message.getProperty('saphda_ipb_credential'),
                    "Status" : "error",
                    "stepStatus" : "error",
                    "current/nextmonth" :  message.getProperty('saphda_current_calmonth'),
                    "Message" :  exceptionText
            ];

            def ibpCommitStatus = new JSONObject(mp).toString();

            message.setProperty("http.response", ibpCommitStatus);

            message.setBody(ibpCommitStatus);

        } catch (JSONException e) {
            message.setBody(e);
        }
    }
    return message;
}

