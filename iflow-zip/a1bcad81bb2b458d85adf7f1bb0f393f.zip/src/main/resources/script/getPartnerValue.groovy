import com.sap.it.api.mapping.*;

def String getBillToPartner(String partnerFunctionField, String value, MappingContext context)
{
	def parterFunction= context.getProperty("BillToPartnerFunction");

    if(partnerFunctionField != null && 
	partnerFunctionField.trim().length() > 0 && 
	value != null && 
	value.trim().length() > 0 &&
	partnerFunctionField == parterFunction){
		
		return value;
		   
    }
 	
	return "";
}

def String getOtherToPartner(String partnerFunctionField, String value, MappingContext context)
{
	def parterFunction = context.getProperty("OtherToPartnerFunction");
	
    if(partnerFunctionField != null && 
	partnerFunctionField.trim().length() > 0 && 
	value != null && 
	value.trim().length() > 0 &&
	partnerFunctionField == parterFunction){
		
		return value;
		   
    }
 	
	return "";
}

def String getShipToPartner(String partnerFunctionField, String value, MappingContext context)
{
	def parterFunction= context.getProperty("ShipToPartnerFunction");

    if(partnerFunctionField != null && 
	partnerFunctionField.trim().length() > 0 && 
	value != null && 
	value.trim().length() > 0 &&
	partnerFunctionField == parterFunction){
		
		return value;
		   
    }
 	
	return "";
}

def String getAssigneePartner(String partnerFunctionField, String value, MappingContext context)
{
	def parterFunction= context.getProperty("AssigneePartnerFunction");

    if(partnerFunctionField != null && 
	partnerFunctionField.trim().length() > 0 && 
	value != null && 
	value.trim().length() > 0 &&
	partnerFunctionField == parterFunction){
		
		return value;
		   
    }
 	
	return "";
}
