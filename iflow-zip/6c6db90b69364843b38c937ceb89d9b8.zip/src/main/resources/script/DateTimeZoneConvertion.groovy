import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Date;
import java.util.TimeZone;

def Message processData(Message message) 
{   
    def prop_timezone = message.getProperty("Timezone");
    def queryDateString = message.getProperty("QueryDate");
    
    def date = Date.parse("yyyy-MM-dd'T'HH:mm:ss'Z'",queryDateString)
    def dtFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'"
    def dt = date.format(dtFormat, TimeZone.getTimeZone(prop_timezone))
    
    
    message.setProperty("QueryDate", dt); 

return message
}
