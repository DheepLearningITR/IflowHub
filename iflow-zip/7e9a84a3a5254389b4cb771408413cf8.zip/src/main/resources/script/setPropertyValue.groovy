import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {
      def body = new JsonSlurper().parseText(message.getBody(String));
      message.setProperty("OrderId", body.OrderID)
      message.setProperty("RequirementDate", body.RequirementDate)
      message.setProperty("StartDate", body.StartDate)
      message.setProperty("FinishDate", body.FinishDate)
      message.setProperty("NewDate", body.NewDate)
      return message;
}