        import com.sap.gateway.ip.core.customdev.util.Message;

        def Message processData(Message message) {
                        
                        // get a map of iflow properties
                        def map = message.getProperties()
                        def refernceID = map.get("SF_Empl_Email")
                        def logException = map.get("ExceptionLogging")
                        def enableMailNotification = map.get("EnableMailNotification")
                        def SAP_MessageProcessingLogID =  map.get("SAP_MessageProcessingLogID")
                        def attachID = ""
                        def errordetails = ""

                        // get an exception java class instance
                        def ex = map.get("CamelExceptionCaught")
                        if (ex!=null) 
                        {
                        // save the error response as a message attachment 
                        def messageLog = messageLogFactory.getMessageLog(message);
                        if (refernceID == null || refernceID == "" )
                        {
                            errordetails = "The User replication failed because of the following error:  " + ex.toString()
                            attachID  = "Error Details for User"
                        }
                        else 
                        {
                            errordetails = "The User replication of  '" + refernceID + "' failed because of the following error:  " + ex.toString()
                            attachID  = "Error Details for User '" + refernceID + "'"	
                        }
                        
                        if (logException != null && logException.equalsIgnoreCase("TRUE")) 
                        {
                            messageLog.addAttachmentAsString(attachID, errordetails, "text/plain");
                        }
                        
                        }

                        return message;
        }