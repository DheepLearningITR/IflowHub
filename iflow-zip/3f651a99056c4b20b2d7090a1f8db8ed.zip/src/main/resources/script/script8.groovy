import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import java.util.ArrayList;

def Message processData(Message message) {
   
    def messageLog = messageLogFactory.getMessageLog(message);
    def body = message.getBody(java.lang.String) as String
    def jsonParser = new JsonSlurper()
    def jsonObject = jsonParser.parseText(body)

    def arr = []
    def json
    def results = {}
   
    for(int i = 0; i < jsonObject.FOCostCenter.FOCostCenter.size(); i++ ){
        json = {}
        json = JsonOutput.toJson(
        codigo : jsonObject.FOCostCenter.FOCostCenter[i].externalCode,
        nome : jsonObject.FOCostCenter.FOCostCenter[i].name_localized
        
        )
       
         arr.push(json)
         
       
    }
   
    message.setBody(JsonOutput.prettyPrint(arr.toString()))  
    message.setProperty("size_payload_hana", jsonObject.size())
    message.setProperty("array_tratado",  JsonOutput.prettyPrint(arr.toString()))
    // messageLog.addAttachmentAsString("Request_Payload", JsonOutput.prettyPrint(arr.toString()), "text/json");
   
       return message;
}