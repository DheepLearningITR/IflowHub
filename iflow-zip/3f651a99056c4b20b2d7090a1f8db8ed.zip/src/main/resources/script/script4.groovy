import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
    def body = message.getBody(java.lang.String) as String
    def jsonParser = new JsonSlurper()
    def jsonObject = jsonParser.parseText(body)
    
    jsonObject.remove('company')
    jsonObject.remove('message')
    
    def json_unique = new JsonBuilder(jsonObject).toPrettyString()
    
    messageLog.addAttachmentAsString("Json_Unique", JsonOutput.prettyPrint(json_unique), "text/json");
    
    
    
       return message;
}