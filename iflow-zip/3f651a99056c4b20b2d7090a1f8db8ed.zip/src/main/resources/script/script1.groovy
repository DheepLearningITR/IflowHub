import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import java.util.ArrayList;

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String
    def jsonParser = new JsonSlurper()
    def jsonObject = jsonParser.parseText(body)

    def arr = []
    def json
    
    jsonObject.forEach{e ->
    json = {}
        json = JsonOutput.toJson(
        matricula : e.matricula,
        dataAdmissao : (e.dataAdmissao == null) ? null : Date.parse("yyyyMMdd", e.dataAdmissao).format("ddMMyyyy"),
        departamento : e.departamento,
        hierarquia_1n : e.hierarquia_1n,
        cargo : (e.cargo == null) ? '' : e.cargo,
        regimeTrabalho : (e.regimeTrabalho == '1') ? 'CLT' : (e.regimeTrabalho == '2') ? 'estatutario' : 'estagiario',
        centroCusto : (e.centroCusto == null) ? '' : e.centroCusto,
        nome : (e.nome == null) ? '' : e.nome,
        dataNascimento : Date.parse("yyyyMMdd", e.dataNascimento).format("ddMMyyyy"),
        sexo : (e.sexo == '1') ? 'M' : 'F',
        cpf : (e.cpf == null) ? '' : e.cpf,
        rg : (e.rg == null) ? '' : e.rg,
        ctps : (e.ctps == null ) ? '' : e.ctps+"/"+e.ctps_serie,
        pis : (e.pis == null) ? '' : e.pis,
        cod_escala_padrao : (e.cod_escala_padrao == null) ? '' : e.cod_escala_padrao,
        carga_horaria : (e.carga_horaria == null) ? '' : e.carga_horaria,
        registra_ponto : (e.registra_ponto == '1') ? 'SIM' : 'NAO',
        email : (e.email == null) ? '' : e.email,
        login_saml : (e.login_saml == null) ? '' : e.login_saml,
        municipio : (e.municipio == null) ? '' : e.municipio,
        estado : (e.estado == null) ? '' : e.estado,
        matricula_chefia : (e.matricula_chefia == null) ? '' : e.matricula_chefia,
        nome_chefia : (e.nome_chefia == null) ? '' : e.nome_chefia,
        dataDemissao : (e.STAT2 == '0') ? Date.parse("yyyyMMdd", e.dataAdmissao).format("ddMMyyyy") : '',
        gerente_head : (e.gerente_head == null) ? '' : e.gerente_head,
        cod_sindicato : (e.cod_sindicato == null) ? '' : e.cod_sindicato,
        empresa : (e.empresa == null) ? '' : e.empresa,
        diretoria : (e.diretoria == null) ? '' : e.diretoria,
        area_rh : (e.area_rh == null) ? '' : e.area_rh,
        filial : (e.cod_estab == null) ? '' : e.cod_estab,
        cnpj : (e.cnpj == null) ? '' : e.cnpj,
        )
        arr.push(json)
    }
    
    message.setBody(JsonOutput.prettyPrint(arr.toString()))  
    message.setProperty("size_payload_hana", jsonObject.size())
    message.setProperty("array_tratado",  JsonOutput.prettyPrint(arr.toString()))
    
   
       return message;
}