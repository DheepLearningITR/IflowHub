import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import java.util.ArrayList;

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String
    def jsonParser = new JsonSlurper()
    def jsonObject = jsonParser.parseText(body)

    def map = message.getProperties()
    int i = map.get("i").toInteger()
    
    int count
    
    def array_1000 = []
    def json = {}    
    
        for(count = map.get("i").toInteger(); count < jsonObject.size() - i; count++){
           
        if (jsonObject[count].dataAdmissao == null){
            json = JsonOutput.toJson(
            matricula : jsonObject[count].matricula,
            departamento : jsonObject[count].departamento,
            hierarquia_1n : jsonObject[count].hierarquia_1n,
            cargo : jsonObject[count].cargo,
            regimeTrabalho : jsonObject[count].regimeTrabalho,
            nome : jsonObject[count].nome,
            dataNascimento : jsonObject[count].dataNascimento,
            sexo : jsonObject[count].sexo,
            cpf : jsonObject[count].cpf,
            rg : jsonObject[count].rg,
            ctps : jsonObject[count].ctps,
            pis : jsonObject[count].pis,
            cod_escala_padrao : jsonObject[count].cod_escala_padrao,
            carga_horaria : jsonObject[count].carga_horaria,
            registra_ponto : jsonObject[count].registra_ponto,
            estado : jsonObject[count].estado,
            login_saml : jsonObject[count].login_saml,
            municipio : jsonObject[count].municipio,
            matricula_chefia : jsonObject[count].matricula_chefia,
            nome_chefia : jsonObject[count].nome_chefia,
            dataDemissao : jsonObject[count].dataDemissao,
            centroCusto : jsonObject[count].centroCusto,
            email : jsonObject[count].email,
            cod_sindicato : jsonObject[count].cod_sindicato,
            empresa : jsonObject[count].empresa,
            diretoria : jsonObject[count].diretoria,
            area_rh : jsonObject[count].area_rh,
            filial : jsonObject[count].filial,
            cnpj : jsonObject[count].cnpj,
            
            )
        } else {
            json = JsonOutput.toJson(
            matricula : jsonObject[count].matricula,
            dataAdmissao : jsonObject[count].dataAdmissao,
            departamento : jsonObject[count].departamento,
            hierarquia_1n : jsonObject[count].hierarquia_1n,
            cargo : jsonObject[count].cargo,
            regimeTrabalho : jsonObject[count].regimeTrabalho,
            nome : jsonObject[count].nome,
            dataNascimento : jsonObject[count].dataNascimento,
            sexo : jsonObject[count].sexo,
            cpf : jsonObject[count].cpf,
            rg : jsonObject[count].rg,
            ctps : jsonObject[count].ctps,
            pis : jsonObject[count].pis,
            cod_escala_padrao : jsonObject[count].cod_escala_padrao,
            carga_horaria : jsonObject[count].carga_horaria,
            registra_ponto : jsonObject[count].registra_ponto,
            estado : jsonObject[count].estado,
            login_saml : jsonObject[count].login_saml,
            municipio : jsonObject[count].municipio,
            matricula_chefia : jsonObject[count].matricula_chefia,
            nome_chefia : jsonObject[count].nome_chefia,
            dataDemissao : jsonObject[count].dataDemissao,
            centroCusto : jsonObject[count].centroCusto,
            email : jsonObject[count].email,
            cod_sindicato : jsonObject[count].cod_sindicato,
            empresa : jsonObject[count].empresa,
            diretoria : jsonObject[count].diretoria,
            area_rh : jsonObject[count].area_rh,
            filial : jsonObject[count].filial,
            cnpj : jsonObject[count].cnpj,

            )   
        }

    array_1000.push(json)
        }
    
    message.setBody(JsonOutput.prettyPrint(array_1000.toString()))
    
    i += 5000
    message.setProperty("i", i)
    
    return message;
}