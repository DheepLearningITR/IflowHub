import com.sap.it.api.mapping.*;

def String getRandomUUID(){
    return UUID.randomUUID().toString()
}
