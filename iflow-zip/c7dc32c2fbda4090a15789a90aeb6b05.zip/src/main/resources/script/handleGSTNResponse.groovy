/**
 * This script is used to handle the response received from GSP/GSTN system
 * 
 * Date		  |	Information
 * ------------------------------------------------------------------------ 
 * 13-08-2017 | Initial Version
 */


import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

import java.security.NoSuchAlgorithmException

import javax.crypto.Cipher
import javax.crypto.NoSuchPaddingException
import javax.crypto.ShortBufferException
import javax.crypto.spec.SecretKeySpec
import javax.xml.bind.DatatypeConverter

import javax.crypto.Mac;

import java.util.zip.ZipEntry;
import org.apache.commons.compress.compressors.gzip.*;
import org.apache.commons.io.IOUtils;
import org.apache.commons.compress.archivers.tar.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;

def Message processData(Message message) {

	//Body

	def map = message.getProperties();
	def headers = message.getHeaders();


	// Form the header and body of the payload based on the api group(api_action) and action
	switch (map.get("api_action")) {
		case "AUTH":
			def body = message.getBody(String.class);
			def jsonSlurper = new JsonSlurper();
			def object = jsonSlurper.parseText(body);
			def jsonString = new JsonBuilder();
			// for OTPREQUEST
			if(!object.status_cd.equals("0")) {
				if (map.get("action").equals("OTPREQUEST") || map.get("action").equals("EVCOTP")) {
				   message.setHeader("GSP_RESP_PAYLOAD_SIZE", body.length());
				}
	
				// for AUTHTOKEN
				if (map.get("action").equals("AUTHTOKEN")) {
					if(!object.status_cd.equals("0")){
						String appkey = map.get("appkey");
						String sek = object.sek;
			
						jsonString	status_cd: object.status_cd,
						auth_token: object.auth_token,
						expiry: object.expiry,
						sek:  symmDecryption(appkey.decodeBase64(), object.sek)
						message.setBody(jsonString.toString());
					}
				}
	
				// for REFRESHTOKEN
				if (map.get("action").equals("REFRESHTOKEN")) {
		
					String appkey = map.get("appkey");
					String sek = object.sek;
		
					jsonString	status_cd: object.status_cd,
					auth_token: object.auth_token,
					expiry: object.expiry,
					sek:  symmDecryption(appkey.decodeBase64(), object.sek)
					message.setBody(jsonString.toString());
				}
			}
			break;

		case "RET":
			//special handling for DOWNLOAD
			if(map.get("action").equals("DOWNLOAD")){
				//unGZIP the returned file
	
				def inputStream = message.getBody(InputStream.class);
				def jsonString = new JsonBuilder();
				GzipCompressorInputStream gzipStream = new GzipCompressorInputStream(inputStream);
				TarArchiveInputStream tarStream = new TarArchiveInputStream(gzipStream);
				BufferedReader bufReader = null;
				TarArchiveEntry tarEntry = null;
				StringBuffer sbuffer = new StringBuffer();
	
				while((tarEntry = tarStream.getNextTarEntry()) != null)
				{
					if(tarEntry.isDirectory())
					{
						// Interested only in files, Directories to be skipped
						 while ((tarEntry = tarStream.getNextTarEntry()) != null) {
					       if (!tarEntry.isDirectory()) {
					           bufReader = new BufferedReader(new InputStreamReader(tarStream));
				            	while(bufReader.ready())
					            	{
							            sbuffer.append(bufReader.readLine());
						            }
					        }
					     }
					}
					else
					{
						InputStreamReader instreamReader = new InputStreamReader(tarStream);
						bufReader = new BufferedReader(instreamReader);
						while(bufReader.ready())
						{
							sbuffer.append(bufReader.readLine());
						}
					}
				}
				String enckey = map.get("enckey");
				String data = new String(symmDecryption(enckey.decodeBase64(), sbuffer.toString()).decodeBase64());
				jsonString	status_cd: "1",
				data: data
				message.setBody(jsonString.toString());
	
			}
			else {
				def body = message.getBody(String.class);
				def jsonSlurper = new JsonSlurper();
				def object = jsonSlurper.parseText(body);
				def jsonString = new JsonBuilder();
		
				if(!object.status_cd.equals("0")){
					String enckey = map.get("enckey");
					String decrek = symmDecryption(enckey.decodeBase64(), object.rek);
					String data = new String(symmDecryption(decrek.decodeBase64(), object.data).decodeBase64());
					String hmac_data = generateHmac(decrek.decodeBase64(), data);
					String hmac = object.hmac;
		
		
					if(hmac.equals(hmac_data)){
						jsonString	status_cd: object.status_cd,
						data: data
					}
					else {
						jsonString	ststus_cd: "0",
						hmac_verify: "Failed"
					}
					message.setBody(jsonString.toString());
				}
			}
			break;
		case "COMM":
		 	def body = message.getBody(String.class);
			def jsonSlurper = new JsonSlurper();
			def object = jsonSlurper.parseText(body);
		  if(!object.status_cd.equals("0")){
		  
			def jsonString = new JsonBuilder();
			jsonString	status_cd: object.status_cd,
			data: object.data;
			message.setBody(jsonString.toString());
			}
			break;
		case "LEDR":
			def body = message.getBody(String.class);
			def jsonSlurper = new JsonSlurper();
			def object = jsonSlurper.parseText(body);
			def jsonString = new JsonBuilder();
	
			if(!object.status_cd.equals("0")){
				String enckey = map.get("enckey");
				String decrek = symmDecryption(enckey.decodeBase64(), object.rek);
				String data = new String(symmDecryption(decrek.decodeBase64(), object.data).decodeBase64());
				String hmac_data = generateHmac(decrek.decodeBase64(), data);
				String hmac = object.hmac;
	
	
				if(hmac.equals(hmac_data)){
					jsonString	status_cd: object.status_cd,
					data: data
				}
				else {
					jsonString	ststus_cd: "0",
					hmac_verify: "Failed"
				}
				message.setBody(jsonString.toString());
			}
			break;
		case "SIMP":
			def body = message.getBody(String.class);
			def jsonSlurper = new JsonSlurper();
			def object = jsonSlurper.parseText(body);
			def jsonString = new JsonBuilder();
	
			if(!object.status_cd.equals("0")) {
				String enckey = map.get("enckey");
				String decrek = symmDecryption(enckey.decodeBase64(), object.rek);
				String data = new String(symmDecryption(decrek.decodeBase64(), object.data).decodeBase64());
				String hmac_data = generateHmac(decrek.decodeBase64(), data);
				String hmac = object.hmac;
	
	
				if(hmac.equals(hmac_data)){
					jsonString	status_cd: object.status_cd,
					data: data
				}
				else {
					jsonString	ststus_cd: "0",
					hmac_verify: "Failed"
				}
				message.setBody(jsonString.toString());
			}
			break;
		default:
			break;
	}


	// calculate the time difference
	
	def lasttimestamp = message.getHeaders().get("GSP_LAST_TIMESTAMP");
	if (lasttimestamp!=null) {
		def currentDate = new Date();
		long diff = currentDate.getTime() - lasttimestamp.getTime();
		def diff_str = new java.text.SimpleDateFormat("HH:mm:ss.SSS").format(diff);
		message.setHeader("GSP_RESPONSE_TIME", diff_str);
		message.setHeader("GSP_RESP_TIMESTAMP", currentDate);
		headers.remove("GSP_LAST_TIMESTAMP");
	}

	return message;
}


def synchronized String symmDecryption(byte[] key, String data){

	//constants
	String AES_TRANSFORMATION = "AES/ECB/PKCS5Padding";
	String AES_ALGORITHM = "AES";
	ENC_BITS = 256;
	
	try {
		decryptCipher = Cipher.getInstance(AES_TRANSFORMATION);
	} catch (NoSuchAlgorithmException | NoSuchPaddingException e1) {
		return null;
	}
	SecretKeySpec secreteKey = new SecretKeySpec(key, AES_ALGORITHM);
	decryptCipher.init(Cipher.DECRYPT_MODE, secreteKey);
	
	InputStream instream = new ByteArrayInputStream(DatatypeConverter.parseBase64Binary(data));
	OutputStream outStream = new ByteArrayOutputStream();
	
	final int cipherBlockSize = decryptCipher.getBlockSize();
	final int outBlockSize = decryptCipher.getOutputSize(cipherBlockSize);
	
	final byte[] inData = new byte[cipherBlockSize];
	byte[] outData = new byte[outBlockSize];
	
	int inReadSize = 0;
	
	try
	{
		while((inReadSize % cipherBlockSize == 0))
		{
			inReadSize = instream.read(inData);
			if(inReadSize == cipherBlockSize)
			{
				try {
					final int encryptedLength = decryptCipher.update(inData, 0, inReadSize,outData);
					outStream.write(outData, 0, encryptedLength);
				} catch (ShortBufferException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return null;
				}
	
			}
		}
	
		if(inReadSize > 0)
		{
			outData = decryptCipher.doFinal(inData,0,inReadSize);
		}
		else
		{
			outData = decryptCipher.doFinal();
		}
	
		outStream.write(outData);
		byte[] decryptedData = ((ByteArrayOutputStream)outStream).toByteArray();
		return decryptedData.encodeBase64().toString();
	}
	finally
	{
		try
		{
			instream.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
		try
		{
			outStream.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
	}
}

def String generateHmac(byte[] key, String data){
	try{
		Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
		SecretKeySpec secret_key = new SecretKeySpec(key, "AES");
		sha256_HMAC.init(secret_key);
	
		String hash = sha256_HMAC.doFinal(data.getBytes()).encodeBase64().toString();
		return hash;
	}catch(Exception e){
		return "";
	}
}