/**
 * This script is used to build the JSON request details 
 * 
 * Date		  |	Information
 * ------------------------------------------------------------------------ 
 * 13-08-2017 | Initial Version
 * 20-09-2017 | REFRESH TOKEN CHANGES
 */


import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;

import java.lang.invoke.SwitchPoint;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.security.spec.X509EncodedKeySpec;
import java.security.InvalidKeyException;
import java.security.InvalidAlgorithmParameterException;


import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.BadPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.ShortBufferException;
import javax.crypto.spec.IvParameterSpec;

import javax.xml.bind.DatatypeConverter;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;
import com.sap.it.api.keystore.exception.KeystoreException;



import javax.crypto.Mac;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;

import java.io.BufferedReader;
import java.io.InputStreamReader;

def Message processData(Message message) {

	// get the properties
	def props = message.getProperties();
	// get the headers
	def headers = message.getHeaders();

	StringBuilder sb = new StringBuilder();
	StringBuilder sb1 = new StringBuilder();
	StringBuilder sb2 = new StringBuilder();
	def jsonString = new JsonBuilder();
	def version = "";
	def gspHttpUrl = "";
	def url = "";

	//Form the Payload for GSTN Request based on the API_ACTION(e.g. AUTH, RET etc.) and ACTION(e.g. OTPREQUEST, AUTHTOKEN, RETSAVE etc.)
	switch (props.get("api_action")) {
		case "AUTH":
		//set the required headers for the Authentication request
			message.setHeader("Content-Type","application/json");
			message.setHeader("username", props.get("username"));
			message.setHeader("ip-usr", props.get("ip-usr"));
			message.setHeader("state-cd",props.get("state-cd"));
			message.setHeader("txn",props.get("txn"));
			message.setHeader("GspHttpUrl",props.get("gstn_auth"));

		//set the Payload for the authentication requests
		//for OTPREQUEST
			if (props.get("action").equals("OTPREQUEST")) {
				//1. Generate a new Application Key(APPKEY)
				byte[] rawAppkey =  generateAppKey();

				//set the appkey in the header so that it can be send back in the response to the DCS application
				//the same appkey must be send in the subsequent request for AUTHTOKEN
				message.setHeader("appkey", rawAppkey.encodeBase64().toString());

				//2.Form the JSON Payload
				jsonString	action	: props.get("action"),
				username: props.get("username"),
				app_key	: encryptAppKey(rawAppkey) // Encrypt the application key using the GSTN public key
				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				//set the payload size
				message.setHeader("GSP_REQ_PAYLOAD_SIZE", req_payload.length());
				message.setHeader("GSP_REQ_PAYLOAD", req_payload.getBytes().encodeBase64().toString());
			}

		//for AUTHTOKEN
			if (props.get("action").equals("AUTHTOKEN")) {
				//1. Get the application key passed to the header of the iFlow
				String appkey = props.get("appkey");

				//2. Form the JSON Payload
				jsonString	action	: props.get("action"),
				username: props.get("username"),
				app_key	: encryptAppKey(appkey.decodeBase64()), // Encrypt the application key using the GSTN public key
				otp		: symmEncryption(appkey.decodeBase64(), props.get("otp")) // Encrypt the OTP(One Time Password) using the Application Key
				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				//set the payload size
				message.setHeader("GSP_REQ_PAYLOAD_SIZE", req_payload.length());
				message.setHeader("GSP_REQ_PAYLOAD", req_payload.getBytes().encodeBase64().toString());
			}

		//for REFRESHTOKEN
			if (props.get("action").equals("REFRESHTOKEN")) {
				// to do - set the pappkeyayload properly here
				byte[] rawAppkey =  generateAppKey();
				String appkey = props.get("enckey");
				
				//message.setHeader("appkey", appkey);
				String appdata = new String(rawAppkey);
				message.setHeader("auth-token", props.get("auth-token"));
				
				message.setHeader("appkey", rawAppkey.encodeBase64().toString());
				props.put("appkey", appdata.getBytes().encodeBase64().toString());
				
				//2. Form the JSON Payload
				jsonString	action: props.get("action"),
				username: props.get("username"),
				app_key	: symmEncryption(appkey.decodeBase64(),appdata), //encryptAppKey(appkey.decodeBase64()), // Encrypt the application key using the GSTN public key
				auth_token: props.get("auth-token") // Encrypt the OTP(One Time Password) using the Application Key
				
				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				//set the payload size
				message.setHeader("GSP_REQ_PAYLOAD_SIZE", req_payload.length());
				message.setHeader("GSP_REQ_PAYLOAD", req_payload.getBytes().encodeBase64().toString());
			}
			//for LOGOUT
			if (props.get("action").equals("LOGOUT")) {
				String appkey = props.get("appkey");
				jsonString	action: props.get("action"),
				username: props.get("username"),
				app_key	: encryptAppKey(appkey.decodeBase64()),
				auth_token: props.get("auth-token") // Encrypt the OTP(One Time Password) using the Application Key
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				message.setHeader("GSP_REQ_PAYLOAD_SIZE", req_payload.length());
				message.setHeader("GSP_REQ_PAYLOAD", req_payload.getBytes().encodeBase64().toString());
			}
			
			//Initiate OTP for EVC
			if (props.get("action").equals("EVCOTP")) {
				message.setHeader("auth-token", props.get("auth-token"));
				message.setHeader("gstin",props.get("gstin"));
				
				message.setHeader("GspHttpQuery", sb2.append("gstin=").append(props.get("gstin")).append("&pan=").append(props.get("pan")).append("&form_type=").append(props.get("return_type")).append("&action=EVCOTP"));
				
				String authUrl = props.get("gstn_auth");
				authUrl = authUrl.replace(props.get("auth_ver"), props.get("evc_ver"));
				message.setHeader("GspHttpUrl",authUrl);
				
			}
			break;

		case "RET":
			//Set the required headers for the GST Returns request
			version = getApiVersion(props);
		
			message.setHeader("username", props.get("username"));
			message.setHeader("ip-usr", props.get("ip-usr"));
			message.setHeader("state-cd",props.get("state-cd"));
			message.setHeader("txn",props.get("txn"));
			message.setHeader("auth-token", props.get("auth-token"));
			message.setHeader("gstin",props.get("gstin"));
			message.setHeader("ret_period", props.get("ret_period"));
			message.setHeader("Content-Type","application/json");
			
			// Additional headers for ITC04 (following same pattern as new returnns) and GSTR1
			if(props.get("return_type").toLowerCase().trim().equals("gstr1") || props.get("return_type").toLowerCase().trim().equals("itc04")
			   || props.get("action").equals("RETFILE")) {
			   
			   if(props.get("return_type").toLowerCase().trim().equals("itc04"))
			   {
			      	message.setHeader("api_version",props.get("itc04_api_ver"));
			   }
			   else
			   {
			   	 message.setHeader("api_version",version.substring(1, version.length()));
			   }
				message.setHeader("userrole",props.get("return_type"));
				message.setHeader("rtn_typ",props.get("return_type"));
			}

			if (props.get("action").equals("SAVE") || props.get("action").equals("RETSAVE") || props.get("action").equals("RETSUBMIT") || props.get("action").equals("GEN2B")) {

				def body = message.getBody(String.class);
				def jsonSlurper = new JsonSlurper();
				def object = jsonSlurper.parseText(body);

				String in_data = object.data;
				String enckey = props.get("enckey");

				jsonString	action: props.get("action"),
				data: symmEncryption(enckey.decodeBase64(), in_data),
				hmac: generateHmac(enckey.decodeBase64(), in_data)

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				
				//set the payload size
				message.setHeader("GSP_REQ_PAYLOAD_SIZE", req_payload.length());
				url = sb.append(props.get("gstn_ret")).append("/").append(props.get("return_type").toLowerCase().trim()).toString();
				gspHttpUrl =  url.replace("version", version);
				message.setHeader("GspHttpUrl", gspHttpUrl);				
			}
			else if (props.get("action").equals("RETFILE")) {

				def body = message.getBody(String.class);
				def jsonSlurper = new JsonSlurper();
				def object = jsonSlurper.parseText(body);
				
				String sid = new String(symmDecryption(getKey(props.get("gstin")),object.sid).decodeBase64());

				String in_data = object.data;
				String enckey = props.get("enckey");
				
				if(object.st.equals("EVC")){
					//String sidVal = object.sid+"|"+props.get("otp");
					//object.sid is PAN"|"OTP
					jsonString	action: props.get("action"),
					data: symmEncryption(enckey.decodeBase64(), in_data),
					sign:  generateHmac(sid.getBytes(), in_data),
					st: object.st,
					sid: sid
				}else{
					jsonString	action: props.get("action"),
					data: symmEncryption(enckey.decodeBase64(), in_data),
					sign: object.sign,
					st: object.st,
					sid: sid
				}
				
				
				
				//hmac: generateHmac(enckey.decodeBase64(), in_data)

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				//set the payload size
				message.setHeader("GSP_REQ_PAYLOAD_SIZE", req_payload.length());
				
				url = sb.append(props.get("gstn_ret")).append("/").append(props.get("return_type").toLowerCase().trim()).toString();
				gspHttpUrl =  url.replace("version", version);
				message.setHeader("GspHttpUrl", gspHttpUrl);
			}
			
			else if(props.get("action").equals("RETNEWPTF")){
			    
			    message.setHeader("api_version",version.substring(1, version.length()));
				message.setHeader("userrole",props.get("return_type"));
				message.setHeader("rtn_typ",props.get("return_type"));
			
				def body = message.getBody(String.class);
				def jsonSlurper = new JsonSlurper();
				def object = jsonSlurper.parseText(body);

				String in_data = object.data;
				String enckey = props.get("enckey");

				def jsonBuilder = new groovy.json.JsonBuilder();
					jsonBuilder(
						"username": props.get("username"),
						"ip-usr": props.get("ip-usr"),
						"state-cd": props.get("state-cd"),
						"txn": props.get("txn"),
						"auth-token": props.get("auth-token"),
						"gstin": props.get("gstin"),
						"ret_period": props.get("ret_period"),
						"clientid": headers.get("clientid"),
						"api_version":version.substring(1, version.length()),
						"userrole": props.get("return_type"),
						"rtn_typ": props.get("return_type")
						);
					
				

				jsonString	action: props.get("action"),
				data: symmEncryption(enckey.decodeBase64(), in_data),
			    hmac: generateHmac(enckey.decodeBase64(), in_data),
			   	hdr: new JsonSlurper().parseText(jsonBuilder.toString());

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				//set the payload size
				message.setHeader("GSP_REQ_PAYLOAD_SIZE", req_payload.length());
				
				url = sb.append(props.get("gstn_gstrptf")).toString();
				gspHttpUrl =  url.replace("version", version);
				message.setHeader("GspHttpUrl", gspHttpUrl);
			}
			
			else if (props.get("action").equals("RETSTATUS")) {
			    //For Return Status
				url = sb.append(props.get("gstn_ret")).toString();
				gspHttpUrl =  url.replace("version", version);
				message.setHeader("GspHttpUrl", gspHttpUrl);
				message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin")).append("&ret_period=").append(props.get("ret_period")).append("&action=").append(props.get("action")));
				//message.setHeader("GspHttpQuery", sb2.append("ref_id=ITC_e02e38703c864cc894aa6eb613eea22c").append("&gstin=").append(props.get("gstin")).append("&ret_period=").append(props.get("ret_period")).append("&action=").append(props.get("action")));
			}else if (props.get("action").equals("B2BA") || props.get("action").equals("B2B") || props.get("action").equals("CDNA") || props.get("action").equals("CDN") || props.get("action").equals("CDNR") || props.get("action").equals("CDNRA") || props.get("action").equals("CDNUR") || props.get("action").equals("CDNURA")|| props.get("action").equals("B2CL") || props.get("action").equals("B2CLA")|| props.get("action").equals("EXP")|| props.get("action").equals("EXPA")
			|| props.get("action").equals("B2CS") || props.get("action").equals("B2CSA") || props.get("action").equals("AT") ||props.get("action").equals("ATA") || props.get("action").equals("RETSUM") || props.get("action").equals("NIL")
			|| props.get("action").equals("TXP") || props.get("action").equals("TXPA") || props.get("action").equals("IMPG") || props.get("action").equals("IMPGA") || props.get("action").equals("IMPS") || props.get("action").equals("IMPSA") 
			|| props.get("action").equals("HSNSUM") || props.get("action").equals("NIL") || props.get("action").equals("B2BUR") || props.get("action").equals("MISMATCH")|| props.get("action").equals("SUBMITREFCLM")
			|| props.get("action").equals("REFCLM")|| props.get("action").equals("LATEFEE") || props.get("action").equals("GENERATE") || props.get("action").equals("RETDET")
			|| props.get("action").equals("GET") || props.get("action").equals("CALRCDS") || props.get("action").equals("RECORDS")
			|| props.get("action").equals("GET2B") || props.get("action").equals("EINV") || props.get("action").equals("AUTOLIAB")
			|| props.get("action").equals("GETCNT") || props.get("action").equals("GETINV") || props.get("action").equals("REQSTS") || props.get("action").equals("GENSTS2B")) 
			{
				//For All GET Calls
				if(props.get("action") == "EINV"){
					url = sb.append(props.get("gstn_ret")).append("/").append("einvoice").toString();
				} else {
					url = sb.append(props.get("gstn_ret")).append("/").append(props.get("return_type").toLowerCase().trim()).toString();
				}
				gspHttpUrl =  url.replace("version", version);
				message.setHeader("GspHttpUrl", gspHttpUrl);
				sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin")).append("&action=").append(props.get("action"));
				if(props.get("action").equals("GET2B")) {
					sb2.append("&rtnprd=").append(props.get("ret_period"));
				} else {
				    //IMS changes
				    if (!props.get("return_type").equals("IMS") && !props.get("return_type").equals("ims") && !props.get("action").equals("GENSTS2B")) {
					sb2.append("&ret_period=").append(props.get("ret_period"));
				    }
				}
				message.setHeader("GspHttpQuery", sb2);
			}else if (props.get("action").equals("FILEDET")) {
			    //IMS changes
			    if (props.get("return_type").equals("IMS") || props.get("return_type").equals("ims")) {
			     url = sb.append(props.get("gstn_ret")).append("/").append(props.get("return_type").toLowerCase().trim()).toString();
			     gspHttpUrl =  url.replace("version", version);
			     message.setHeader("GspHttpUrl", gspHttpUrl);
			     message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin")).append("&action=").append(props.get("action")));
			    }
			    
			    else {
				url = sb.append(props.get("gstn_ret")).toString();
				gspHttpUrl =  url.replace("version", version);
				message.setHeader("GspHttpUrl", gspHttpUrl);
				message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin")).append("&ret_period=").append(props.get("ret_period")).append("&action=").append(props.get("action")));
			    }
			}else if(props.get("action").equals("DOWNLOAD") ){
			    if(props.get("dwdurl") != null && props.get("dwdurl").startsWith("https://")){
			       message.setHeader("isFileDownloader","Y");
			        gspHttpUrl = sb1.append(props.get("dwdurl")).toString();
			        //IMS Changes
			        if(gspHttpUrl.contains("uatfiles")) {
			           gspHttpUrl = gspHttpUrl.replace("uatfiles", "sbfiles");
			        }
			        message.setHeader("GspHttpUrl", gspHttpUrl)
			    }
			    
			    else {
				message.setHeader("GspHttpUrl", sb1.append(props.get("gspurl")).append(props.get("dwdurl")));
			    }
			}else if(props.get("action").equals("RETTRACK") ){				
				url = sb.append(props.get("gstn_ret")).toString();
				gspHttpUrl =  url.replace("version", version);
				message.setHeader("GspHttpUrl", gspHttpUrl);
				if(props.get("type") == null) {
					message.setHeader("GspHttpQuery", sb2.append("gstin=").append(props.get("gstin")).append("&action=").append(props.get("action"))
						.append("&ret_period=").append(props.get("ret_period")));
				} else {
					message.setHeader("GspHttpQuery", sb2.append("gstin=").append(props.get("gstin")).append("&action=").append(props.get("action"))
						.append("&ret_period=").append(props.get("ret_period")).append("&type=").append(props.get("type")));
				}
			}
			else if (props.get("action").equals("SAVEPREF")) {
				
				def body = message.getBody(String.class);
				def jsonSlurper = new JsonSlurper();
				def object = jsonSlurper.parseText(body);

				String in_data = object.data;
				String enckey = props.get("enckey");
				jsonString	action: props.get("action"),
				data: symmEncryption(enckey.decodeBase64(), in_data),
				hmac: generateHmac(enckey.decodeBase64(), in_data);

				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				
				message.setHeader("api_version",version.substring(1, version.length()));
				message.setHeader("userrole","NA");
				message.setHeader("rtn_typ","NA");
				message.setHeader("GSP_REQ_PAYLOAD_SIZE", req_payload.length());
				url = sb.append(props.get("gstn_ret")).toString();
				gspHttpUrl =  url.replace("version", version);
				message.setHeader("GspHttpUrl", gspHttpUrl);
			}
			else if (props.get("action").equals("GETPREF")) {
				url = sb.append(props.get("gstn_ret")).toString();
				gspHttpUrl =  url.replace("version", version);
				message.setHeader("GspHttpUrl", gspHttpUrl);
				message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin")).append("&action=").append(props.get("action")));
			}
			
			
			//gstr3b sections
			//Get system calculated interest
			else if(props.get("action").equals("RETINT")){
			
				url = sb.append(props.get("gstr3b_ret")).toString();
				message.setHeader("GspHttpUrl", url);
				message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("gstin=").append(props.get("gstin")).append("&ret_period=").append(props.get("ret_period")).append("&action=").append(props.get("action")));
			
			}
			
			//Re-compute interest
			else if(props.get("action").equals("CMPINT")){
			
				def body = message.getBody(String.class);
				def jsonSlurper = new JsonSlurper();
				def object = jsonSlurper.parseText(body);

				String in_data = object.data;
				String enckey = props.get("enckey");
				jsonString	action: props.get("action"),
				data: symmEncryption(enckey.decodeBase64(), in_data),
				hmac: generateHmac(enckey.decodeBase64(), in_data);

				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				
				url = sb.append(props.get("gstr3b_ret")).toString();
				message.setHeader("GspHttpUrl", url);
				
			}
			
			//Offset Liability GSTR3B data
			else if(props.get("action").equals("RETOFFSET")){
			
				def body = message.getBody(String.class);
				def jsonSlurper = new JsonSlurper();
				def object = jsonSlurper.parseText(body);

				String in_data = object.data;
				String enckey = props.get("enckey");
				jsonString	action: props.get("action"),
				data: symmEncryption(enckey.decodeBase64(), in_data),
				hmac: generateHmac(enckey.decodeBase64(), in_data);

				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				
				url = sb.append(props.get("gstr3b_ret")).toString();
				message.setHeader("GspHttpUrl", url);
			
			}
			
			//Validate GSTR3B against AutoCalculated data
			else if(props.get("action").equals("VALID")){
			
				def body = message.getBody(String.class);
				def jsonSlurper = new JsonSlurper();
				def object = jsonSlurper.parseText(body);

				String in_data = object.data;
				String enckey = props.get("enckey");
				jsonString	action: props.get("action"),
				data: symmEncryption(enckey.decodeBase64(), in_data),
				hmac: generateHmac(enckey.decodeBase64(), in_data);

				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				
				url = sb.append(props.get("gstr3b_ret")).toString();
				message.setHeader("GspHttpUrl", url);
			}
						
			
			else{
				url = sb.append(props.get("gstn_ret")).append("/").append(props.get("return_type").toLowerCase().trim()).toString();
				gspHttpUrl =  url.replace("version", version);
				message.setHeader("GspHttpUrl", gspHttpUrl);
				message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin")).append("&ret_period=").append(props.get("ret_period")).append("&action=").append(props.get("action")));

			}
			break;
		case "COMM":
			message.setHeader("Content-Type","application/json");
			message.setHeader("ip-usr", props.get("ip-usr"));
			message.setHeader("txn",props.get("txn"));
			
			//Search Tax Payer
			if (props.get("action").equals("TP")) {
				message.setHeader("GspHttpUrl",props.get("gstn_comm"));
				message.setHeader("GspHttpQuery", sb2.append("gstin=").append(props.get("gstin")).append("&action=").append(props.get("action")));
			} else if(props.get("action").equals("RETTRACK")) {
				message.setHeader("GspHttpUrl",props.get("gstn_comm_track_returns"));
				message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin")).append("&action=").append(props.get("action"))
						.append("&fy=").append(props.get("fy")).append());
			}
			break;
			
		case "LEDR":
			version = getApiVersion(props);
			message.setHeader("username", props.get("username"));
			message.setHeader("ip-usr", props.get("ip-usr"));
			message.setHeader("state-cd",props.get("state-cd"));
			message.setHeader("txn",props.get("txn"));
			message.setHeader("auth-token", props.get("auth-token"));
			message.setHeader("gstin",props.get("gstin"));
			message.setHeader("ret_period", props.get("ret_period"));
			message.setHeader("Content-Type","application/json");
			
			url = sb.append(props.get("gstn_ledr")).toString();
			gspHttpUrl =  url.replace("version", version);
			message.setHeader("GspHttpUrl", gspHttpUrl);
			
			if (props.get("action").equals("BAL") || props.get("action").equals("TAX")) {
				message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin"))
					.append("&ret_period=").append(props.get("ret_period")).append("&action=").append(props.get("action")));
			} else if(props.get("action").equals("CASH") || props.get("action").equals("ITC")) {
				message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin"))
					.append("&fr_dt=").append(props.get("fr_dt")).append("&to_dt=").append(props.get("to_dt")).append("&action=").append(props.get("action")));
			}else{
				message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin"))
					.append("&ret_period=").append(props.get("ret_period")).append("&action=").append(props.get("action")));
			} 
			break;
		case "SIMP":
			version = getApiVersion(props);
			
			message.setHeader("username", props.get("username"));
			message.setHeader("ip-usr", props.get("ip-usr"));
			message.setHeader("state-cd",props.get("state-cd"));
			message.setHeader("txn",props.get("txn"));
			message.setHeader("auth-token", props.get("auth-token"));
			message.setHeader("gstin",props.get("gstin"));
			message.setHeader("ret_period", props.get("ret_period"));
			message.setHeader("Content-Type","application/json");
			
			if (props.get("return_type").toLowerCase().trim().equals("anx1")) {
				if (props.get("action").equals("SAVEANX1") || props.get("action").equals("GENSUM")) {
				//For All POST Calls
					def body = message.getBody(String.class);
					def jsonSlurper = new JsonSlurper();
					def object = jsonSlurper.parseText(body);
					def jsonBuilder = new groovy.json.JsonBuilder();
					jsonBuilder(
						"username": props.get("username"),
						"ip-usr": props.get("ip-usr"),
						"state-cd": props.get("state-cd"),
						"txn": props.get("txn"),
						"auth-token": props.get("auth-token"),
						"gstin": props.get("gstin"),
						"ret_period": props.get("ret_period"),
						"clientid": headers.get("clientid"),
						"api_version":version.substring(1, version.length()),
						"userrole": props.get("return_type"),
						"rtn_typ": props.get("return_type")
						);
					
					String in_data = object.data;
					String enckey = props.get("enckey");
	
					jsonString	action: props.get("action"),
					data: symmEncryption(enckey.decodeBase64(), in_data),
					hmac: generateHmac(enckey.decodeBase64(), in_data),
					hdr: new JsonSlurper().parseText(jsonBuilder.toString());
	
					//set the message body
					def req_payload = jsonString.toString();
					message.setBody(req_payload);
					
					// Additional for new returns
					message.setHeader("api_version",version.substring(1, version.length()));
					message.setHeader("userrole",props.get("return_type"));
					message.setHeader("rtn_typ",props.get("return_type"));
					
					//set the payload size
					message.setHeader("GSP_REQ_PAYLOAD_SIZE", req_payload.length());
					url = sb.append(props.get("gstn_ret")).append("/").append(props.get("return_type").toLowerCase().trim()).toString();
					gspHttpUrl =  url.replace("version", version);
					message.setHeader("GspHttpUrl", gspHttpUrl);
				} 
				else if (props.get("action").equals("GETRETSTATUS")) {
					//For Return Status
					url = sb.append(props.get("gstn_ret")).append("/").append(props.get("action").toLowerCase().trim()).toString();
					gspHttpUrl =  url.replace("version", version);
					message.setHeader("GspHttpUrl", gspHttpUrl);
					message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin")).append("&rtnprd=").append(props.get("ret_period")).append("&action=").append(props.get("action")));
					//message.setHeader("GspHttpQuery", sb2.append("ref_id=ITC_e02e38703c864cc894aa6eb613eea22c").append("&gstin=").append(props.get("gstin")).append("&ret_period=").append(props.get("ret_period")).append("&action=").append(props.get("action")));
				}
				else if (props.get("action").equals("B2B") || props.get("action").equals("B2C") || props.get("action").equals("DE") 
				|| props.get("action").equals("ECOM") || props.get("action").equals("EXPWOP") || props.get("action").equals("EXPWP") 
				|| props.get("action").equals("IMPG") || props.get("action").equals("IMPGSEZ")|| props.get("action").equals("IMPS") 
				|| props.get("action").equals("MIS")|| props.get("action").equals("REV")|| props.get("action").equals("SEZWOP")
				|| props.get("action").equals("SEZWP") || props.get("action").equals("GETSUM")) 
				{
				//For All GET Calls
					url = sb.append(props.get("gstn_ret")).append("/").append(props.get("return_type").toLowerCase().trim()).toString();
					gspHttpUrl =  url.replace("version", version);
					message.setHeader("GspHttpUrl", gspHttpUrl);
					message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin")).append("&rtnprd=").append(props.get("ret_period")).append("&action=").append(props.get("action")));
				}  
			} 
			else if(props.get("return_type").toLowerCase().trim().equals("anx2")) {
				if (props.get("action").equals("SAVEANX2") || props.get("action").equals("GENSUM")) {
				//For All POST Calls
					def body = message.getBody(String.class);
					def jsonSlurper = new JsonSlurper();
					def object = jsonSlurper.parseText(body);
					def jsonBuilder = new groovy.json.JsonBuilder();
					jsonBuilder(
						"username": props.get("username"),
						"ip-usr": props.get("ip-usr"),
						"state-cd": props.get("state-cd"),
						"txn": props.get("txn"),
						"auth-token": props.get("auth-token"),
						"gstin": props.get("gstin"),
						"ret_period": props.get("ret_period"),
						"clientid": headers.get("clientid"),
						"api_version":version.substring(1, version.length()),
						"userrole": props.get("return_type"),
						"rtn_typ": props.get("return_type")
						);
	
					String in_data = object.data;
					String enckey = props.get("enckey");
	
					jsonString	action: props.get("action"),
					data: symmEncryption(enckey.decodeBase64(), in_data),
					hmac: generateHmac(enckey.decodeBase64(), in_data),
					hdr: new JsonSlurper().parseText(jsonBuilder.toString());
	
					//set the message body
					def req_payload = jsonString.toString();
					message.setBody(req_payload);
					
					// Additional for new returns
					message.setHeader("api_version",version.substring(1, version.length()));
					message.setHeader("userrole",props.get("return_type"));
					message.setHeader("rtn_typ",props.get("return_type"));
					
					//set the payload size
					message.setHeader("GSP_REQ_PAYLOAD_SIZE", req_payload.length());
					url = sb.append(props.get("gstn_ret")).append("/").append(props.get("return_type").toLowerCase().trim()).toString();
					gspHttpUrl =  url.replace("version", version);
					message.setHeader("GspHttpUrl", gspHttpUrl);
				} 
				else if (props.get("action").equals("GETRETSTATUS")) {
					//For Return Status
					url = sb.append(props.get("gstn_ret")).append("/").append(props.get("action").toLowerCase().trim()).toString();
					gspHttpUrl =  url.replace("version", version);
					message.setHeader("GspHttpUrl", gspHttpUrl);
					message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin")).append("&rtnprd=").append(props.get("ret_period")).append("&action=").append(props.get("action")));
					//message.setHeader("GspHttpQuery", sb2.append("ref_id=ITC_e02e38703c864cc894aa6eb613eea22c").append("&gstin=").append(props.get("gstin")).append("&ret_period=").append(props.get("ret_period")).append("&action=").append(props.get("action")));
				}
				else if (props.get("action").equals("B2B") || props.get("action").equals("DE") 
				|| props.get("action").equals("ISDC") || props.get("action").equals("ITCSUM") || props.get("action").equals("SEZWOP")
				|| props.get("action").equals("SEZWP") || props.get("action").equals("GETSUM")) 
				{
				//For All GET Calls
					url = sb.append(props.get("gstn_ret")).append("/").append(props.get("return_type").toLowerCase().trim()).toString();
					gspHttpUrl =  url.replace("version", version);
					message.setHeader("GspHttpUrl", gspHttpUrl);
					message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin")).append("&rtnprd=").append(props.get("ret_period")).append("&action=").append(props.get("action")));
				}
			}
			else if(props.get("return_type").toLowerCase().trim().equals("profile")) {
				if (props.get("action").equals("SAVPROFILE")) {
					def body = message.getBody(String.class);
					def jsonSlurper = new JsonSlurper();
					def object = jsonSlurper.parseText(body);
					def jsonBuilder = new groovy.json.JsonBuilder();
					jsonBuilder(
						"username": props.get("username"),
						"ip-usr": props.get("ip-usr"),
						"state-cd": props.get("state-cd"),
						"txn": props.get("txn"),
						"auth-token": props.get("auth-token"),
						"gstin": props.get("gstin"),
						"ret_period": props.get("ret_period"),
						"clientid": headers.get("clientid"),
						"api_version":version.substring(1, version.length()),
						"userrole": "NA",
						"rtn_typ": "NA"
						);
	
					String in_data = object.data;
					String enckey = props.get("enckey");
	
					jsonString	action: props.get("action"),
					data: symmEncryption(enckey.decodeBase64(), in_data),
					hmac: generateHmac(enckey.decodeBase64(), in_data),
					hdr: new JsonSlurper().parseText(jsonBuilder.toString());
	
					//set the message body
					def req_payload = jsonString.toString();
					message.setBody(req_payload);
					
					// Additional for new returns
					message.setHeader("api_version",version.substring(1, version.length()));
					message.setHeader("userrole","NA");
					message.setHeader("rtn_typ","NA");
					//set the payload size
					message.setHeader("GSP_REQ_PAYLOAD_SIZE", req_payload.length());
					url = sb.append(props.get("gstn_ret")).append("/").append(props.get("return_type").toLowerCase().trim()).toString();
					gspHttpUrl =  url.replace("version", version);
					message.setHeader("GspHttpUrl", gspHttpUrl);
				}
				else if (props.get("action").equals("GETPROFILE")) 
				{
					//def fy = props.get("ret_period").substring(2);
					//For All GET Calls
					url = sb.append(props.get("gstn_ret")).append("/").append(props.get("return_type").toLowerCase().trim()).toString();
					gspHttpUrl =  url.replace("version", version);
					message.setHeader("GspHttpUrl", gspHttpUrl);
					message.setHeader("GspHttpQuery", sb2.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("&gstin=").append(props.get("gstin")).append("&action=").append(props.get("action")));
				}
			}
			break;
		default:
			break;
	}


	// set the current timestamp as the REQUEST timestamp
	def currentDate = new Date();
	message.setHeader("GSP_LAST_TIMESTAMP", currentDate);
	message.setHeader("GSP_REQ_TIMESTAMP", currentDate);
	return message;
}


def String generateHmac(byte[] key, String data){
	try{
		Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
		SecretKeySpec secret_key = new SecretKeySpec(key, "AES");
		sha256_HMAC.init(secret_key);

		String hash = sha256_HMAC.doFinal(data.getBytes()).encodeBase64().toString();
		return hash;
	}catch(Exception e){
		return "";
	}
}

def String encryptAppKey(byte[] rawAppKey){
	/* ASYMMETRIC ENCRYPTION */
	// get the GSTN public key from the JAVA keystore
	def service = ITApiFactory.getApi(KeystoreService.class, null);
	PublicKey pk;
	byte[] keydata;

	if(service != null)
	{
		// here it reads the certificate with alias gstncert.
		// the GSTN public key must be deployed in the cloud integration tenants keystore with alias name as gstncert
		X509Certificate certificate = service.getCertificate("gstncert");
		if(certificate != null)
		{
			pk = certificate.getPublicKey();
			String encoded  = pk.getEncoded().encodeBase64().toString();
			keydata = encoded.decodeBase64();
		}
	}

	// encrypt the raw appkey using the GSTN public key from keystore
	Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	PublicKey pubKey = KeyFactory.getInstance("RSA")
			.generatePublic(new X509EncodedKeySpec(keydata));
	cipher.init(Cipher.ENCRYPT_MODE, pubKey);
	byte[] encryptedByte= cipher.doFinal(rawAppKey);
	return encryptedByte.encodeBase64().toString();
}

def byte[] generateAppKey(){
	//constants
	String AES_TRANSFORMATION = "AES/ECB/PKCS5Padding";
	String AES_ALGORITHM = "AES";
	ENC_BITS = 256;
	KeyGenerator keyGenerator = null;

	try {
		keyGenerator = KeyGenerator.getInstance(AES_ALGORITHM);
		keyGenerator.init(ENC_BITS);
	}
	catch (NoSuchAlgorithmException e) {
		e.printStackTrace();
	}

	SecretKey appkey = keyGenerator.generateKey();
	return appkey.getEncoded();
}

def String getApiVersion(def props){
		def returnType = props.get("return_type");
		def action = props.get("action");
		def apiAction = props.get("api_action");
		
		//IMS changes
		if(action == "FILEDET" && (returnType == "IMS" || returnType == "ims")) {
		    return props.get("ims_ver");
		}
		
		else if(action == "RETSTATUS" || action == "FILEDET"){
			return props.get("default_ver");
		}else if(action == "RETTRACK"){
				return props.get("comm_ret_ver");
		}else if(action == "EINV"){
				return props.get("gstreinvoice_ver");
		}else if(action == "BAL"){
		 		return props.get("bal_ver");   
		}else if(action == "TAX"){
		 		return props.get("tax_ver");   
		}else if(apiAction == "LEDR"){
				return props.get("gstr_ledr_ver");
		}else if(action == "RETNEWPTF"){
		 		return props.get("gstrptf_ver");   
		}
		else{
			switch(returnType){
				case "gstr1":
				case "gstr1a":
				case "GSTR1":
				case "GSTR1A":
		      		return props.get("gstr1_ver");
				case "gstr2":
				case "gstr2a":
				case "GSTR2":
				case "GSTR2A":
		      		return props.get("gstr2_ver");
				case "gstr3":
				case "gstr3a":
				case "gstr3b":
				case "GSTR3":
				case "GSTR3A":
				case "GSTR3B":
		      		return props.get("gstr3_ver");
		      	case "gstr4":
				case "gstr4a":
				case "GSTR4":
				case "GSTR4A":
					return props.get("gstr4_ver");
				case "gstr5":
				case "gstr5a":
				case "GSTR5":
				case "GSTR5A":
					return props.get("gstr5_ver");
		      	case "gstr6":
				case "gstr6a":
				case "GSTR6":
				case "GSTR6A":
					return props.get("gstr6_ver");
				case "gstr7":
				case "gstr7a":
				case "GSTR7":
				case "GSTR7A":
					return props.get("gstr7_ver");
				case "gstr8":
				case "gstr8a":
				case "GSTR8":
				case "GSTR8A":
					return props.get("gstr8_ver");
				case "gstr9":
				case "gstr9a":
				case "GSTR9":
				case "GSTR9A":
					return props.get("gstr9_ver");
				case "itc04":
				case "ITC04":
				    return props.get("itc04_ver");
				case "anx1":
				case "ANX1":
		      		return props.get("gstranx1_ver");
		      	case "anx2":
				case "ANX2":
		      		return props.get("gstranx2_ver");
		      	case "profile":
				case "PROFILE":
		      		return props.get("gstrprofile_ver");
				case "GSTR2B":
				case "gstr2b":
					return props.get("gstr2b_ver");
				//IMS changes	
				case "IMS":
				case "ims":
					return props.get("ims_ver");
				default:
		    		 return props.get("default_ver");
			}
		
		}
		
}

def String symmEncryption(byte[] key, String data){
	//constants
	String AES_TRANSFORMATION = "AES/ECB/PKCS5Padding";
	String AES_ALGORITHM = "AES";
	ENC_BITS = 256;

	Cipher encryptCipher = Cipher.getInstance(AES_TRANSFORMATION);
	SecretKeySpec secreteKey = new SecretKeySpec(key, AES_ALGORITHM);
	encryptCipher.init(Cipher.ENCRYPT_MODE, secreteKey);

	InputStream instream = new ByteArrayInputStream(data.getBytes());
	OutputStream outStream = new ByteArrayOutputStream();

	final int cipherBlockSize = encryptCipher.getBlockSize();
	final int outBlockSize = encryptCipher.getOutputSize(cipherBlockSize);

	final byte[] inData = new byte[cipherBlockSize];
	byte[] outData = new byte[outBlockSize];

	int inReadSize = 0;


	try
	{
		while((inReadSize % cipherBlockSize == 0))
		{
			inReadSize = instream.read(inData);
			if(inReadSize == cipherBlockSize)
			{
				try {
					final int encryptedLength = encryptCipher.update(inData, 0, inReadSize,outData);
					outStream.write(outData, 0, encryptedLength);
				} catch (ShortBufferException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return null;
				}

			}
		}

		if(inReadSize > 0)
		{
			outData = encryptCipher.doFinal(inData,0,inReadSize);
		}
		else
		{
			outData = encryptCipher.doFinal();
		}

		outStream.write(outData);
		byte[] encryptedData = ((ByteArrayOutputStream)outStream).toByteArray();

		return encryptedData.encodeBase64().toString();
	}
	finally
	{
		try
		{
			instream.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
		try
		{
			outStream.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
	}
	
}

def byte[] getKey(String myKey)
{
	MessageDigest sha = null;
	byte[] key = null;
	try {
		key = myKey.getBytes("UTF-8");
		sha = MessageDigest.getInstance("SHA-256");
		key = sha.digest(key);
		key = Arrays.copyOf(key, 16);
	}
	catch (NoSuchAlgorithmException e) {
		e.printStackTrace();
	}
	catch (UnsupportedEncodingException e) {
		e.printStackTrace();
	}
	
	return key;
}

def synchronized String symmDecryption(byte[] key, String encrypted){
	
		try {
    		IvParameterSpec iv = new IvParameterSpec(key);
    		SecretKeySpec skeySpec = new SecretKeySpec(key, "AES");

    		Cipher cipher;
			
				cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			
    		cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
    		byte[] decryptedData = cipher.doFinal(encrypted.decodeBase64());

    		return decryptedData.encodeBase64().toString();
    	} catch (NoSuchAlgorithmException  e) {
			e.printStackTrace();
		}catch(NoSuchPaddingException e){
			e.printStackTrace();
		}catch(InvalidKeyException  e){
			e.printStackTrace();
		}catch(InvalidAlgorithmParameterException  e){
			e.printStackTrace();
		}catch(IllegalBlockSizeException  e){
			
		}catch(BadPaddingException e){
			e.printStackTrace();
		}

    	return null;
	}
