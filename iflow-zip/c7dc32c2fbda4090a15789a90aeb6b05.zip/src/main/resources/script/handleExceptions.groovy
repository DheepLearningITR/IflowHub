/**
 * This script is used to handle the exceptions raised at any of the steps 
 * 
 * Change Details
 * 
 * Date		  |	Information
 * ------------------------------------------------------------------------ 
 * 13-08-2017 | Initial Version
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder

def Message processData(Message message) {
	def map = message.getHeaders();
	def map1 = message.getProperties();
	def ex = map1.get("CamelExceptionCaught");
	def jsonString = new JsonBuilder();
	def errorString = new JsonBuilder();

	map.put("Content-Type",   "application/json");
	map.put("CamelHttpResponseCode",   200);

	if (ex!=null) {

		if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
			if(ex.getStatusCode() == 410 || ex.getStatusCode() == 403){
				map.put("CamelHttpResponseCode",ex.getStatusCode());
				errorString error_cd:"SCI_ERR",
				message : ex.toString()
				jsonString	status_cd	: "0",
				error	:errorString.getContent()
				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			}
			else {
				message.setBody(ex.getResponseBody());			    
			}

		}else if(ex.getClass().getCanonicalName().equals("javax.net.ssl.SSLHandshakeException")){ 
			errorString error_cd:"SSL_ERR",
			message : "GSP SSL Certificate not added in keystore or Maintained wrong URLS in the IFLOW configuration"
			jsonString	status_cd	: "0",
			error	:errorString.getContent()
			//set the message body
			def req_payload = jsonString.toString();
			message.setBody(req_payload);
		
		}else if(ex.getClass().getCanonicalName().equals("java.net.UnknownHostException")){
			errorString error_cd:"SCI_ERR",
			message : "Maintained wrong URLS in the IFLOW configuration, Please correct the GSP URL's"
			jsonString	status_cd	: "0",
			error	:errorString.getContent()
			//set the message body
			def req_payload = jsonString.toString();
			message.setBody(req_payload);
		
		}else{
			if(ex.toString().contains("B.clone()")){
				errorString error_cd:"SCI_ERR",
				message : "Please add GSTN public key in the keystore with alias name gstncert"
				jsonString	status_cd	: "0",
				error	:errorString.getContent()
				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
				
			}else{
				errorString error_cd:"SCI_ERR",
				message : "Internal error occured at SCI"
				jsonString	status_cd	: "0",
				error	:errorString.getContent()
				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			}
		}
	}else{
		def aMultilineString = """{
				\"status_cd\":\"0\",
				\"error\"	:{
				\"error_cd\"	:\"SCI_ERR\",
				\"message\":\"GSP Integration failed.\"
				}
				}""";
		message.setBody(aMultilineString);
	}

	return message;
}