
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

       def root = new XmlParser().parseText(message.getBody(String.class));
       def HeaderBusinessSystemId = root.MessageHeader.RecipientParty.InternalID.text()
       def fsm_sc_id = root.ServiceRequestReplicationConfirmation[0].ServiceRequestReplicationConfirmation.ServiceRequestConfirmation.
                            find({node -> (node.BusinessSystemID.text().equals(HeaderBusinessSystemId) && node.BTDReference.UUID) })?.BTDReference?.UUID?.text()
       
       if(root.MessageHeader.ReferenceID.text() == "FALSE"){
           //it means no new Tikcet or Ticket line item is created in this replication in C4C
           message.setProperty("SendEmptyBody", true)
       }
       
       def root_output = new NodeBuilder().Service_Call_Confirmation{
            id(fsm_sc_id?.replace("-", "")?.toUpperCase())          //Converting UUID to FSM no-hyphen UUID format
            externalId(root.ServiceRequestReplicationConfirmation[0].ServiceRequestReplicationConfirmation.ID.text())
       }
       
       def activityConfirmation, fsm_act_id
       for(item in root.ServiceRequestReplicationConfirmation[0].ServiceRequestReplicationConfirmation.ItemConfirmation){
           
           if(item.FSMRelevance.text().equals('1')){
               fsm_act_id = item.BTDReference.find({node -> (node.BusinessSystemID.text().equals(HeaderBusinessSystemId) && node.BTDReference.UUID) })?.BTDReference?.UUID?.text()
               if(fsm_act_id != null && fsm_act_id != ""){
                   activityConfirmation = new NodeBuilder().activities{
                       id(fsm_act_id?.replace("-", "")?.toUpperCase())     //Converting UUID to FSM no-hyphen UUID format
                       externalId(item.UUID.text())
                   }
                   root_output.append(activityConfirmation)
               }
           }
           
       }
        
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(root_output)
        message.setBody(stringWriter.toString())
        return message;
}