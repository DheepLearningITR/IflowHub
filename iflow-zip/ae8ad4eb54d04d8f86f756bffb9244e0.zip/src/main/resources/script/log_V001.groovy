import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

// you can use _010, _020 etc methods to reuse same script from multiple places in the iflow
def Message log_010(Message message) {
	
	def body = message.getBody(java.lang.String)
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        messageLog.addAttachmentAsString('LOG_010', body, 'text/plain')
    }
    return message
	
}

def Message log_020(Message message) {
    
    def body = message.getBody(java.lang.String)
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        messageLog.addAttachmentAsString('LOG_020', body, 'text/plain')
    }
    return message
	
}

