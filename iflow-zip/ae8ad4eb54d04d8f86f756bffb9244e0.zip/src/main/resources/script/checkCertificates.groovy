/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat

def Message processData(Message message) {
    //Body 
       def body = message.getBody();

	   String newline = System.getProperty("line.separator")
	   // def int limit = message.getHeader("expireLimit")
	   def headerMap = message.getHeaders();
       def int limit = Integer.parseInt(headerMap.get("expireLimit"))
       def String isExpired = "false"
       
       
	   def StringBuilder strBld = new StringBuilder();
	   strBld.append("Dear CPI Operator," + newline + newline + "the following certificates will expire soon:" + newline)
	   
	   
	   def content = new XmlSlurper().parseText(body)
	   content.KeystoreEntry.each { KeystoreEntry ->
			def aliasStr = KeystoreEntry.Alias
			def validNotAfter = KeystoreEntry.ValidNotAfter
			String pattern = "yyyy-MM-dd";
			Date CertExpirydate = new SimpleDateFormat(pattern).parse(validNotAfter.text());
			Date dateNow = new Date(System.currentTimeMillis())
			long dateDiff = CertExpirydate.getTime() - dateNow.getTime();
			int daysToExpire = dateDiff / ( 1000 * 60 * 60 * 24);
			if (daysToExpire < limit) {
			    isExpired = "true"
				strBld.append("   - DaysLeft: " + daysToExpire  + "   Alias: " + aliasStr + newline)
				
			}
		}
		

        message.setHeader("isExpired", isExpired)
        message.setBody(strBld)
       return message;
}