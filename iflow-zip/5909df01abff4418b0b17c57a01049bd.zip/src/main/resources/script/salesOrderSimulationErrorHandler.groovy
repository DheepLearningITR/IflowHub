import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {

  def body = message.getBody(java.io.Reader)
  def jsonObject = new JsonSlurper().parse(body)

  def output = [
                value: [
                        info: [
                                details: [
                                        [
                                                message: jsonObject.error.message.value,
                                                messageCode: jsonObject.error.code,
                                                severity: 'E' // Mapping "error" to "E"
                                        ]
                                ]
                        ]
                ]
        ]
  
  // Convert output to JSON string
  def outputJson = JsonOutput.toJson(output)
  message.setBody(outputJson)

  return message
}