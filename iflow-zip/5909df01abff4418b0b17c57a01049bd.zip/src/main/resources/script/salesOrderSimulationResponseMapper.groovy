import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.math.RoundingMode
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

def Message processData(Message message) {

    def body = message.getBody(java.io.Reader)
    
    // Input JSON string
    def input = new JsonSlurper().parse(body)
    
    def currency = input.d.TransactionCurrency
    def pricingProcedureName = input.d.SDPricingProcedure
    def creditWorthinessStatus = input.d.to_Credit?.TotalCreditCheckStatus ?: ''
    
    def priceElements = input.d.to_PricingElement.results.collect { element ->
           parsePriceElements(element) 
        }
    def totalGrossAmount = BigDecimal.ZERO
    def totalNetAmount = BigDecimal.ZERO
    def totalTaxAmount = BigDecimal.ZERO

    def items = input.d.to_Item.results.collect { item ->
    def itemPriceElements = item.to_PricingElement.results.collect { element ->
           parsePriceElements(element) 
        }

        def scheduleLines = item.to_ScheduleLine.results.collect { scheduleLine ->
        def dateSource = scheduleLine.RequestedDeliveryDate ?: scheduleLine.ConfirmedDeliveryDate
                [
                        displayId: scheduleLine.ScheduleLine,
                        confirmedQuantity: [
                                content: scheduleLine.ConfdOrderQtyByMatlAvailCheck.toDouble(),
                                uomCode: scheduleLine.OrderQuantityUnit
                        ],
                        originalQuantity: [
                                content: scheduleLine.CorrectedQtyInOrderQtyUnit.toDouble(),
                                uomCode: scheduleLine.OrderQuantityUnit
                        ],
                        quantity: [
                                content: scheduleLine.ScheduleLineOrderQuantity.toDouble(),
                                uomCode: scheduleLine.OrderQuantityUnit
                        ],
                        period: [
                                startDateTime: dateSource ? Instant.ofEpochMilli(dateSource.replaceAll(/\D/, '').toLong())
                                        .atZone(ZoneId.of('UTC'))
                                        .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")) : null
                        ]
                ]
            }

            def netAmount = new BigDecimal(item.NetAmount)
            def taxAmount = new BigDecimal(item.TaxAmount)
            def grossAmount = netAmount.add(taxAmount).setScale(2, RoundingMode.HALF_UP)

            totalNetAmount = totalNetAmount.add(netAmount)
            totalTaxAmount = totalTaxAmount.add(taxAmount)
            totalGrossAmount = totalGrossAmount.add(grossAmount)

            def itemCurrency = item.TransactionCurrency
            return [
                    displayId: item.SalesOrderItem, // Include other fields from the item as needed
                    parentItemDisplayId: item.HigherLevelItem,
                    productDisplayId: item.Material,
                    priceElements: itemPriceElements,
                    scheduleLines: scheduleLines,
                    totalValues: [
                            grossAmount: [
                                    content: grossAmount,
                                    currencyCode: itemCurrency
                            ],
                            netAmount: [
                                    content: netAmount,
                                    currencyCode: itemCurrency
                            ],
                            taxAmount: [
                                    content: taxAmount,
                                    currencyCode: itemCurrency
                            ]
                    ]
            ]
        }

  def output = [
    value: [
      currency: currency,
      pricingProcedureName: pricingProcedureName,
      creditWorthinessStatus: creditWorthinessStatus,
      items: items,
      priceElements: priceElements,
      totalValues: [
                                grossAmount: [
                                        content: totalGrossAmount.setScale(2, RoundingMode.HALF_UP),
                                        currencyCode: currency
                                ],
                                netAmount: [
                                        content: totalNetAmount.setScale(2, RoundingMode.HALF_UP),
                                        currencyCode: currency
                                ],
                                taxAmount: [
                                        content: totalTaxAmount.setScale(2, RoundingMode.HALF_UP),
                                        currencyCode: currency
                                ]
                        ]
    ]
  ]
  
  // Convert output to JSON string
  def outputJson = JsonOutput.toJson(output)

  message.setBody(outputJson)

  return message;
}

private LinkedHashMap<String, Serializable> parsePriceElements(element) {
        return [
                calculatedAmount    : [
                        content     : element.ConditionAmount.toDouble(),
                        currencyCode: element.ConditionCurrency ?: ''
                ],
                calculationBasisCode: element.ConditionCalculationType,
                categoryCode        : element.ConditionClass,
                conditionType       : element.ConditionType,
                counter             : element.PricingProcedureCounter.toInteger(),
                inactiveReasonCode  : element.ConditionInactiveReason ?: '',
                isGroupedIndicator  : element.IsGroupCondition ? true : false,
                isManuallyChanged   : element.ConditionIsManuallyChanged as Boolean,
                originCode          : element.ConditionOrigin,
                rateAmount          : [
                        content     : element.ConditionRateValue.toDouble(),
                        currencyCode: element.ConditionCurrency ?: ''
                ],
                rateBaseQuantity    : [
                        content: element.ConditionQuantity.toDouble(),
                        uomCode: element.ConditionQuantityISOUnit ?: ''
                ],
                stepNumber          : element.PricingProcedureStep.toInteger()
        ]
    }