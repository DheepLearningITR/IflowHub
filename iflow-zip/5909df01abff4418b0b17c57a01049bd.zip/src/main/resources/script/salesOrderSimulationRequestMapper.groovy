import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {

 def body = message.getBody(java.io.Reader)

  // Input JSON string
  def input = new JsonSlurper().parse(body)
  
  //Define Identifiers To Search In Message Processing Logs
  message.setHeader('SAP_ApplicationID', input.id)


  // Prepare output JSON structure
  def output = [
    SalesOrderType: input.documentType,
    SalesOrganization: input.receiverSalesOrganizationDisplayId,
    DistributionChannel: input.distributionChannel,
    OrganizationDivision: input.division,
    SoldToParty: input.receiverAccountDisplayId,
    SalesOrderDate: "${input.documentDate}T00:00:00",
    PurchaseOrderByCustomer: input.customerReferenceId,
    PricingDate: "${input.priceDate}T00:00:00",
    RequestedDeliveryDate: input.requestedDateTime.replace("Z", ""),
    to_Item: input.items.collect {
      item -> [
        SalesOrderItem: item.displayId,
        HigherLevelItem: "0",
        SalesOrderItemCategory: item.itemType,
        Material: item.receiverProductDisplayId,
        RequestedQuantity: item.requestedQuantity.content.toString(),
        to_PricingElement: item.priceElements.collect {
          priceElement ->
            def pricingElement = [
              ConditionType: priceElement.conditionType,
              ConditionRateValue: priceElement.netPrice
            ]
          // Only add ConditionCurrency if netPriceCurrency exists
          if (priceElement.netPriceCurrency) {
            pricingElement.ConditionCurrency = priceElement.netPriceCurrency
          }
          pricingElement
        },
        // Add the empty array "to_ScheduleLine"
        to_ScheduleLine: []
      ]
    },
    to_Pricing: [: ],
    to_PricingElement: input.priceElements.collect {
      priceElement ->
        def pricingElement = [
          ConditionType: priceElement.conditionType,
          ConditionRateValue: priceElement.netPrice
        ]
      // Only add ConditionCurrency if netPriceCurrency exists
      if (priceElement.netPriceCurrency) {
        pricingElement.ConditionCurrency = priceElement.netPriceCurrency
      }
      pricingElement
    },
    to_Partner: input.partners.findAll {
      it.role in ["AG", "WE", "RE", "RG"]
    }.collect {
      partner -> [
        PartnerFunction: partner.role,
        Customer: partner.receiverDisplayId
      ]
    },
    // Add the empty node "to_Credit"
    to_Credit: [: ]
  ]

  // Convert output to JSON string
  def outputJson = JsonOutput.toJson(output)
  
  message.setBody(outputJson)

  return message
}