import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

	//Properties  
	def pmap = message.getHeaders();
    def messageLog = messageLogFactory.getMessageLog(message);

   
    String BusinessPartner = pmap.get("BusinessPartner");
    String BusinessPartnerRole = pmap.get("BusinessPartnerRole");

    //String Operator = pmap.get("Operator");
	
	String Operator = "";
	String query = "";

	
// add filter parameter for PERSON_ID_EXTERNAL
	if(BusinessPartner != null && BusinessPartner != "") {	
		query = query + " BusinessPartner eq ('" + BusinessPartner +"')";
		message.setProperty("FILTER_PARAMETERS", query);
		Operator = 'TRUE'
	}
	
// add filter parameter for BusinessPartnerRole
	if(BusinessPartnerRole != null && BusinessPartnerRole != "") 
	{ 
	    if(Operator == 'TRUE')
	    {
	        query = query + " and BusinessPartnerRole eq ('" + BusinessPartnerRole +"')";
  	} 
	    else 
    	{
	        query = query + " BusinessPartnerRole eq ('" + BusinessPartnerRole +"')";
	         Operator = 'TRUE'
	}
    }


		//Set FILTER_PARAMETERS
	message.setProperty("FILTER_PARAMETERS", query);
	if(messageLog != null){
		messageLog.setStringProperty("FILTER_PARAMETERS: ", query);
	}
	
	return message;
}

