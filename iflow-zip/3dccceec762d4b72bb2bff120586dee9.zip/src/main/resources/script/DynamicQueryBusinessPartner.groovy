import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

	//Properties  
	def pmap = message.getHeaders();
    def messageLog = messageLogFactory.getMessageLog(message);

   
    String personIdExternal = pmap.get("person_id_external");
    String zip_code = pmap.get("zip_code");
    String country = pmap.get("country");
    String city = pmap.get("city");
    String CompanyName = pmap.get("CompanyName");

	String Operator = "";
	String query = "";

	
// add filter parameter for PERSON_ID_EXTERNAL
	if(personIdExternal != null && personIdExternal != "") {	
		query = query + " Partner eq ('" + personIdExternal +"')";
		message.setProperty("FILTER_PARAMETERS", query);
		Operator = 'TRUE'
	}
	
// add filter parameter for zip_code
	if(zip_code != null && zip_code != "") 
	{ 
	    if(Operator == 'TRUE')
	    {
	        query = query + " and PostalCode eq ('" + zip_code +"')";
    	} 
	    else 
    	{
	         query = query + " PostalCode    eq ('" + zip_code +"')";
	         Operator = 'TRUE'
    	}
    }


// add filter parameter for country
	if(country != null && country != "") 
	{ 
	    if(Operator == 'TRUE')
	    {
	        query = query + " and Country eq ('" + country +"')";
    	} 
	    else 
    	{
	         query = query + " Country eq ('" + country +"')";
	         Operator = 'TRUE'
    	}
    }    
    

//add filter parameter for city
	if(city != null && city != "") 
	{ 
	    if(Operator == 'TRUE')
	    {
	        query = query + " and startswith(City, '" + city +"')";
    	} 
	    else 
    	{
	         query = query + " startswith(City, '" + city +"')";
	         Operator = 'TRUE'
    	}
    } 
    
// add filter parameter for CompanyName
	if(CompanyName != null && CompanyName != "") 
	{ 
	    if(Operator == 'TRUE')
	    {
	        query = query + " and startswith(CompanyName, '" + CompanyName +"')";
    	} 
	    else 
    	{
	         query = query + " startswith(CompanyName, '" + CompanyName +"')";
	         Operator = 'TRUE'
    	}
    }
    
	
//Set FILTER_PARAMETERS
	message.setProperty("FILTER_PARAMETERS", query);
	if(messageLog != null){
		messageLog.setStringProperty("FILTER_PARAMETERS: ", query);
	}
	
	return message;
}

