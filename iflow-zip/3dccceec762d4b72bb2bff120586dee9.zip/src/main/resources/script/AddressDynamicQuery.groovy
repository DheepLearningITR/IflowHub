import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

	//Properties  
	def pmap = message.getHeaders();
    def messageLog = messageLogFactory.getMessageLog(message);


    String zip_code = pmap.get("zip_code");
    String city = pmap.get("city");
    String CompanyName = pmap.get("CompanyName");

	String Operator = "";
	String query = "";

	
// add filter parameter for zip_code
	if(zip_code != null && zip_code != "") 
	{ 
	    if(Operator == 'TRUE')
	    {
	        query = query + " and PostalCode eq ('" + zip_code +"')";
    	} 
	    else 
    	{
	         query = query + " PostalCode eq ('" + zip_code +"')";
	         Operator = 'TRUE'
    	}
}


// add filter parameter for city
	if(city != null && city != "") 
	{ 
	    if(Operator == 'TRUE')
	    {
	        query = query + " and startswith(CityName, '" + city +"')";
//	        query = query + " and CityName eq ('" + city +"')";
    	} 
	    else 
    	{
	         query = query + " startswith(CityName, '" + city +"')";
	         Operator = 'TRUE'
    	}
    }    
    
// add filter parameter for CompanyName
	if(CompanyName != null && CompanyName != "") 
	{ 
	    if(Operator == 'TRUE')
	    {
	        query = query + " and startswith(FullName, '" + CompanyName +"')";
    	} 
	    else 
    	{
	         query = query + " startswith(FullName, '" + CompanyName +"')";
	         Operator = 'TRUE'
    	}
    }
	
		//Set FILTER_PARAMETERS
	message.setProperty("FILTER_PARAMETERS", query);
	if(messageLog != null){
		messageLog.setStringProperty("FILTER_PARAMETERS: ", query);
	}
	
	return message;
}

