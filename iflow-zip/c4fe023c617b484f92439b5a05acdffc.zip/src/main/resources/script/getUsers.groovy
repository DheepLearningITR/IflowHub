import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    //Body 
    try
    {
    def body = message.getBody(java.lang.String)
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body.toString())
    def membersList = object.Resources.members.value
    String memberIdsInString = membersList
    if(memberIdsInString.length()<=2)
    {
        message.setProperty("emailValue", "")
        message.setProperty("hasMoreIds","false")
    }
    else
    {
        String memberIdsList = memberIdsInString.replace("[","")
        memberIdsList = memberIdsList.replace("]","")
        String[] memberIds
        memberIds = memberIdsList.split(',')
        message.setProperty("userIdList",memberIds)
        message.setProperty("original_size",memberIds.size())
        message.setProperty("numberOfCallsToBeMade",memberIds.size())
        message.setProperty("hasMoreIds","true")
    }
    }
    catch(Exception e)
     {
         message.setProperty("emailValue", "")
     }    
    return message;
}