import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    //Body 
    try{
         def body = message.getBody(java.lang.String);
        def map = message.getProperties()
        int numberOfCalls = map.get("numberOfCallsToBeMade")
        int original_size = map.get("original_size")
        def jsonSlurper = new JsonSlurper()
        def object = jsonSlurper.parseText(body.toString())
        String currentEmailAddress = object.emails.value
        currentEmailAddress = currentEmailAddress.replace("[","")
        currentEmailAddress = currentEmailAddress.replace("]","")
        if(original_size - numberOfCalls == 0 )
        {
            String firstEmailAddress = currentEmailAddress
            firstEmailAddress =firstEmailAddress.trim()
            message.setProperty("userEmailAddressList",firstEmailAddress)
        }
        else
        {
            String previousEmailList = map.get("userEmailAddressList")
            String updatedEmailList = previousEmailList + ","+currentEmailAddress
            updatedEmailList = updatedEmailList.trim()
            message.setProperty("userEmailAddressList",updatedEmailList)
        }
        numberOfCalls = numberOfCalls - 1
        if(numberOfCalls == 0)
        {
            message.setProperty("hasMoreIds","false")
        }
        message.setProperty("numberOfCallsToBeMade",numberOfCalls)
    }
    catch(Exception e)
     {
         message.setProperty("emailValue", "")
     }
    return message;
}