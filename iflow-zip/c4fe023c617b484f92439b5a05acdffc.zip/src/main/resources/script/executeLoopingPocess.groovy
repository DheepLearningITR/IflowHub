import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    try{
        def map = message.getProperties();
        int numberOfCalls = map.get("numberOfCallsToBeMade")
        int original_size = map.get("original_size")
        def userIdList = map.get("userIdList")
        def currentUserToBeFetched = userIdList[original_size - numberOfCalls]
        currentUserToBeFetched =currentUserToBeFetched.trim()
        message.setProperty("currentUserToBeFetched",currentUserToBeFetched)
    }
    catch(Exception e)
     {
         message.setProperty("emailValue", "")
     }     
    return message
}