import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message) {   

    def body = message.getBody(java.lang.String) as String;
    def root = new XmlParser().parseText(body);
    //def mesgproperties=message.getProperties();

    def trandatacnt=root.total.text().toInteger();
    println trandatacnt

 if (trandatacnt > 0)
 {
    def i=0;
    def orderseqlist="";
    def finalmessage='"';
    def allmessage=[];
    root.'**'.findAll { it.name() == 'salesTransactionSeq'}.each { a ->allmessage << a.text()};
    int len = allmessage.size();
//println len
   while(i<len)
    {
//errors=errors+","+'"'+allmessage[i=0,i=1,i=2]+'"';
    orderseqlist=orderseqlist+","+allmessage[i=i]
      i++;
    }
//println errors
    orderseqlist=orderseqlist.substring(1);
    finalmessage=orderseqlist
    //println orderseqlist
    println finalmessage
    message.setProperty("exittransactionLoop", false);
    message.setProperty("p_transeqlist", orderseqlist);

   }
else
{
  message.setProperty("exittransactionLoop", true); 
}
    
    message.setBody(XmlUtil.serialize(root));
    return message;
}
