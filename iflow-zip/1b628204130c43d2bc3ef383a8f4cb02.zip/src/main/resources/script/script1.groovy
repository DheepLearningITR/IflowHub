import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
def Message processData(Message message) {   

    def body = message.getBody(java.lang.String) as String;
    def root = new XmlParser().parseText(body);
    def properties = message.getProperties();

     def comm_ordersData = root.salesOrders;
     def count=comm_ordersData.size()
     println count
     //def i=0;
     int v_count = properties.get("p_count").toInteger();
     println v_count
  
    if (v_count < count)
    {
       def comm_orderdata2=root.salesOrders[v_count];
       def orderseq=comm_orderdata2.salesOrderSeq.text();
       def orderid=comm_orderdata2.orderId.text();
       println orderseq

        message.setProperty("p_orderseq", orderseq);
        message.setProperty("p_orderid", orderid);
        v_count++;
        message.setProperty("p_count", v_count);
        message.setProperty("exitorderLoop", false);
    }
    else
    {
       message.setProperty("exitorderLoop", true); 
    }
           
    message.setBody(XmlUtil.serialize(root));
    return message;
}