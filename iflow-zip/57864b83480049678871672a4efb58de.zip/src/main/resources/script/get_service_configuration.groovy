package main.resources.script
import com.sap.gateway.ip.core.customdev.util.Message;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

import groovy.json.JsonSlurper;

def Message processData(Message message) {


	//Initialize
	def jsonSlurper = new JsonSlurper();

	try {
		def service = ITApiFactory.getApi(SecureStoreService.class, null);

		//---------------------------------------------------------------------------------------------------------
		//Service Account Id
		credential = service.getUserCredential("GoogleAnalytics_ServiceAccountId");
		if (credential == null){
			throw new IllegalStateException("No credential found for alias 'GoogleAnalytics_ServiceAccountId'");
		}
		message.setProperty("service_account_id",credential.getPassword().toString());

		//---------------------------------------------------------------------------------------------------------
		//Service Account Email
		credential = service.getUserCredential("GoogleAnalytics_ServiceAccountEmail");
		if (credential == null){
			throw new IllegalStateException("No credential found for alias 'GoogleAnalytics_ServiceAccountEmail'");
		}
		message.setProperty("service_account_email",credential.getPassword().toString());

	} catch (Exception ex) {
		throw new IllegalStateException("No credential found for alias 'GoogleAnalytics'");
	}

	accountId = message.getHeader("accountId", java.lang.String.class);
	if (accountId == null) {
		throw new IllegalStateException("AccountId not provided in headers");
	}
	message.setProperty("accountId", accountId);

	webPropertyId = message.getHeader("webPropertyId", java.lang.String.class);
	if (webPropertyId == null) {
		throw new IllegalStateException("WebProperty not provided in headers");
	}
	message.setProperty("webPropertyId", webPropertyId);


	return message;
}
