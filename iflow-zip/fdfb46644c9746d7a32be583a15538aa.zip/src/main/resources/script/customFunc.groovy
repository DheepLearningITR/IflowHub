import com.sap.it.api.mapping.*;

def String setPoBox(String poBox){
	if(poBox == "X"){
	    return "true" 
	}
	else{
	    return "false"
	}
}

def String setBankUri(String country, String id){
	 return "Bank(BankCountry='${country}',BankInternalID='${id}')"
}

def String setAddressUri(String country, String id, MappingContext context){
    Boolean flag = context.getProperty('Reference').get('AddressExist')
    if(flag){
        return "BankAddress(BankCountry='${country}',BankInternalID='${id}',AddressRepresentationCode='')"
    }
    else{
        return "Bank(BankCountry='${country}',BankInternalID='${id}')/_BankAddress"
    }
}

def String setMethod(String value, MappingContext context){
    Boolean flag = context.getProperty('Reference').get('AddressExist')
    if(flag){
        return "PUT"
    }
    else{
        return "POST"
    }
}

def String getBankCategory(String propertyName, MappingContext context){
    String bankCategory = context.getProperty(propertyName)
    if(bankCategory == null || bankCategory == ''){
        throw new Exception('Bank category is not defined')
    }
    return bankCategory
}