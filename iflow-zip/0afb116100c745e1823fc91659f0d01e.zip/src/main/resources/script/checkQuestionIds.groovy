import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.time.Instant;
import org.apache.camel.converter.stream.ByteArrayInputStreamCache;
import groovy.json.JsonSlurperClassic;

def Message processData(Message message) {
    
    //Feedback definition payload 
    def body = message.getBody(String.class);
    def parsedObj = new JsonSlurper().parseText(body);
    
    //Survey payload
    def surveyPayload = message.getProperty("surveyPayload");
    def parsedPayload = new JsonSlurper().parseText(surveyPayload);
    
    def map = message.getHeaders();
    
    if(map.get('CamelHttpResponseCode') == 200 && parsedPayload.questions[0].id == parsedObj.value[0].questions[0].id){
        message.setProperty("questionIdMatch", true);
    }
    return message;
    
}