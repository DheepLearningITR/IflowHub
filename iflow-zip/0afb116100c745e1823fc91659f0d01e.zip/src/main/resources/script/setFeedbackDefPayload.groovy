import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {
    
     def body = message.getBody(String.class);

    def parsedObj = new JsonSlurper().parseText(body);
   
    def finalBody = new JsonSlurper().parseText('{}');
    def name = new JsonSlurper().parseText('{}');
    def questions = [];
    def grades = [];

    finalBody<<["externalObjectId":parsedObj.result.SurveyID];
    
    name<<["content": parsedObj.result.SurveyName];
    name<<["languageCode": parsedObj.result.SurveyOptions.SurveyLanguage];

    finalBody<<["name":name];
    
    //scoring category
    def defaultScoringCategory = parsedObj.result.Scoring.DefaultScoringCategory;
    
    for(res in parsedObj.result.Questions){
        if(res.getValue().Selector == "NPS"){
            def questionData = new JsonSlurper().parseText('{}');
            def questionContent = new JsonSlurper().parseText('{}');
        
            questionData<<["id": res.getValue().QuestionID];
       
        
            questionContent<<["content": res.getValue().QuestionText];
            questionContent<<["languageCode": parsedObj.result.SurveyOptions.SurveyLanguage];   //question language array empty
        
            questionData<<["question": questionContent];
        
            questionData<<["questionType": "CSAT"];
            
            if(!res.getValue().GradingData.isEmpty()){
                //Scoring
                for(gradingData in res.getValue().GradingData){
                    if(gradingData.containsKey('Grades')){
                        grades.add((gradingData.Grades[defaultScoringCategory]).toInteger());
                    }
                }
                
                questionData<<["minScore": grades.min()];
                questionData<<["maxScore": grades.max()];
            }else{
                throw new Exception("Scoring not maintained for the question : " + res.getValue().QuestionID);
            }
        
            questions << questionData;
            break;
        }
    }
    finalBody<<["questions":questions];

    JsonBuilder builder = new JsonBuilder(finalBody);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
    message.setProperty("surveyPayload", jsonBody);
    
    return message;
}