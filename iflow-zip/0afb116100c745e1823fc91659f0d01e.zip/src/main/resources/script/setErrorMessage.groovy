import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    
    def surveyId = message.getProperty("SurveyID");
    
    message.setBody("Unable to fetch feedback definition data for external object Id : " + surveyId);
    
    return message;
}