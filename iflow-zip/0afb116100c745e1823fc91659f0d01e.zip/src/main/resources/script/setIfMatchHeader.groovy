import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {
    
    def body = message.getBody(String.class);
    def parsedObj = new JsonSlurper().parseText(body);
    
    def definitionId = parsedObj.value[0].id;
    def updatedOn = parsedObj.value[0].adminData.updatedOn;

    
    message.setProperty("FeedbackDefinitionId", definitionId);
    
    message.setHeader('If-Match', updatedOn);
    
    message.setBody(message.getProperty("surveyPayload"));
    
    return message;
}