/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.IOException;
import java.util.Map;
import groovy.util.XmlSlurper;
import groovy.xml.*

def Message processData(Message message) {
    
	def ErrorCode = '0000';
    def ErrorDesc = '';
    def exType;
	def cause;
	try{	
	
	def map = message.getProperties();
	def ex = map.get("CamelExceptionCaught");
	if (ex!=null){
		if (ex instanceof org.apache.cxf.interceptor.Fault) {
		    cause = ex.getCause();
		    exType = cause.getClass().getCanonicalName();
		    if (exType == "org.apache.cxf.transport.http.HTTPException"){
		        def stat_code = cause.getResponseCode();
		        def stat_res = cause.getMessage();
		        stat_res = stat_res.replaceAll('([<][!]DOCTYPE\\s*[a-zA-Z\\s0-9\\W]*[>])?\\s*[<]html\\s*[a-zA-Z\\s0-9\\W]*[>]\\s*[a-zA-Z\\s0-9\\W]+[<][\\/]html[>]\\s*\\n*', '');
		        message.setProperty("Code",stat_code);
		         message.setProperty("ParamDetail",stat_res);
		    }
		    else{
			String xml = ex.getDetail() as String;
			ErrorDesc = ex.getMessage() as String;
			def detail = new XmlSlurper().parseText(xml);
		    def Code = detail.ProcessingFault.Code.text();
		    def ParamDetail = detail.ProcessingFault.Message.text();
		    message.setProperty("Code",Code)
		    message.setProperty("ParamDetail",ParamDetail);
		    }
		}		
	}
	} catch (Exception ex01) {
	    message.setProperty("Code",ErrorCode);
	    message.setProperty("ParamDetail",ErrorDesc);
	}
    return message;

}