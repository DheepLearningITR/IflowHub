/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import com.sap.it.api.mapping.*;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	def headers = message.getHeaders();
	
	messageLog.addCustomHeaderProperty('Destination for SAP IBP', headers.get("DestinationforSAPIBP"));
	messageLog.addCustomHeaderProperty('Planning Area', headers.get("PlanningArea"));
	messageLog.addCustomHeaderProperty('Planning Area Version', headers.get("PlanningAreaVersion"));

	
	
   def attachment = "Batch Size In Rows: " + headers.get("BatchSizeInRows")+
                     "\nDetailed Trace Log: " + headers.get("DetailedTraceLog")+
                     "\nFilter ID: " + headers.get("FilterID")+
                     "\nFilter User ID: " + headers.get("FilterUserID") +
                     "\nKey Figure Name: " + headers.get("KeyFigureName") +
                     "\nPackage Size In Rows: " + headers.get("PackageSizeInRows") +
                     "\nParallel Processes: " + headers.get("ParallelProcesses") +
                     "\nPeriod Type: " + headers.get("PeriodType") +
                     "\nPeriod Type - Time Profile Level: " + headers.get("PeriodTypeTimeProfileLevel") +
                     "\nPlant Source Field: " + headers.get("PlantSourceField") +
                     "\nProduct Source Field: " + headers.get("ProductSourceField")+
                     "\nFurther Filters: " + headers.get("FurtherFilters")+
                     "\nHost for SAP S4/HANA Cloud: " + headers.get("HostforSAPS4HANACloud")+
                     "\nRead Limit: " + headers.get("ReadLimit")+
                     "\nUnified Base Unit: " + headers.get("UnifiedBaseUnit");
                     
	

        messageLog.addAttachmentAsString("Parameters" , attachment.toString(), "text/xml");
	return message;
}
