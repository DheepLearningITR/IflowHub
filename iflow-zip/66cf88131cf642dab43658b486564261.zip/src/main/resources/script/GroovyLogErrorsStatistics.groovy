/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.math.*;
import com.sap.it.api.msglog.*;
import groovy.time.*;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	
    def headers = message.getHeaders();
	def props = message.getProperties();
	

	    
	    def body = message.getBody(java.lang.String) as String;
	    def dateIFlowStart = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",props.get('TimeiFlowStart'));
	    def dateIFlowEnd = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",props.get('TimeIBPCloseEnd'));
	    def iFlowRuntime = TimeCategory.minus(dateIFlowEnd, dateIFlowStart);
	    def timeiFlow = iFlowRuntime.toMilliseconds() * 0.001;
	    def durationIBPInit = TimeCategory.minus(Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",props.get('TimeIBPInitEnd')), Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",props.get('TimeIBPInitStart')));
	    def timeIBPInit = durationIBPInit.toMilliseconds() * 0.001;
	    def durationIBPClose = TimeCategory.minus(Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",props.get('TimeIBPCloseEnd')), Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",props.get('TimeIBPCloseStart')));
	    def timeIBPClose =  durationIBPClose.toMilliseconds() * 0.001;
        def timeS4Posts= props.get('StatsSumTimeS4Posts').toDouble()?:0.0;
        def countS4UpdatedPIRs = Double.valueOf(props.get('StatsCountS4UpdatedPIRs')).intValue()?:0; 
        def countS4UpdatedPIRItems = Double.valueOf(props.get('StatsCountS4UpdatedPIRItems')).intValue()?:0; 
        def countS4FailedPIRs = Double.valueOf(props.get('StatsCountS4FailedPIRs')).intValue()?:0; 
        def countS4FailedPIRItems = Double.valueOf(props.get('StatsCountS4FailedPIRItems')).intValue()?:0; 
        def timeIBPFetch = props.get('StatsSumTimeIBPFetch').toDouble()?:0.0;
        def timeMapIBPToS4 = props.get('StatsSumTimeMapIBPToS4').toDouble()?:0.0;
        def timeS4ParallelPosts = (props.get('StatsSumTimeS4PostsOnly')?:0).toDouble();
        def timeS4ParallelPostsInclSplit = (props.get('StatsSumTimeS4PostsEndToEnd')?:0).toDouble();
		def perflogs = "Performance Logs\n";
		
	    perflogs = perflogs + "\nStats Runtime IBP Read Init " + timeIBPInit.toString();
	    perflogs = perflogs + "\nStats Runtime IBP Read Close " + timeIBPClose.toString();
	    perflogs = perflogs + "\nStats Runtime iFlow " + timeiFlow.toString();
        
	    perflogs = perflogs + "\nStats Runtime IBP Read Fetch " + props.get('StatsSumTimeIBPFetch');
	    perflogs = perflogs + "\nStats Runtime Map IBP to S4 " + props.get('StatsSumTimeMapIBPToS4');
	    perflogs = perflogs + "\nStats Runtime S4 Post PIRs " + props.get('StatsSumTimeS4PostsOnly');
	    perflogs = perflogs + "\nStats Runtime S4 Post PIRs incl. Split " + props.get('StatsSumTimeS4PostsInclSplitGather');
	    perflogs = perflogs + "\nStats Runtime S4 PIRs " + timeS4Posts.round(3).toString();

	    perflogs = perflogs + "\nStats Count IBP Fetch " + props.get('StatsCountIBPFetch').toString();
	    perflogs = perflogs + "\nStats Count S4 Batches " + props.get('StatsCountS4Batches').toString();
	    perflogs = perflogs + "\nStats Count S4 Failed PIRs " + countS4FailedPIRs.toString();
	    perflogs = perflogs + "\nStats Count S4 Failed PIR Items " + countS4FailedPIRItems.toString();
	    perflogs = perflogs + "\nStats Count S4 Updated PIRs " + countS4UpdatedPIRs.toString();
	    perflogs = perflogs + "\nStats Count S4 Updated PIR Items " + countS4UpdatedPIRItems.toString();
	    perflogs = perflogs + "\nStats Count S4 Total PIRs " + (countS4UpdatedPIRs + countS4FailedPIRs).toString();
	    perflogs = perflogs + "\nStats Count S4 Total PIR Items " + (countS4UpdatedPIRItems + countS4FailedPIRItems).toString();
	    
	    
	    if (timeS4Posts > 0) {
	        perflogs = perflogs + "\nThroughput All PIRs per s " + ( (countS4UpdatedPIRs + countS4FailedPIRs ) / timeS4Posts).round(3).toString();
	        perflogs = perflogs + "\nThroughput All PIR Items per s " + ( (countS4UpdatedPIRItems + countS4FailedPIRItems ) / timeS4Posts).round(3).toString();
	    }
	    
	    if (timeS4ParallelPosts > 0) {
	        perflogs = perflogs + "\nThroughput Parallel PIRs per s " + ( (countS4UpdatedPIRs + countS4FailedPIRs ) / timeS4ParallelPosts).round(3).toString();
	        perflogs = perflogs + "\nThroughput Parallel PIR Items per s " + ( (countS4UpdatedPIRItems + countS4FailedPIRItems ) / timeS4ParallelPosts).round(3).toString();
	    }
	    if (timeiFlow > 0) perflogs = perflogs + "\nThroughput End To End Items per s " + ( (countS4UpdatedPIRItems + countS4FailedPIRItems ).toDouble() / timeiFlow).round(3).toString();
	    if (timeIBPFetch > 0) perflogs = perflogs + "\nThroughput IBP Fetch Items per s " + ( (countS4UpdatedPIRItems + countS4FailedPIRItems ).toDouble() / timeIBPFetch).round(3).toString();
	    if (timeIBPInit > 0) perflogs = perflogs + "\nThroughput IBP Init Items per s " + ( (countS4UpdatedPIRItems + countS4FailedPIRItems ).toDouble() / timeIBPInit).round(3).toString();
	    if (timeIBPInit > 0 || timeIBPFetch > 0 || timeIBPClose > 0) perflogs = perflogs + "\nThroughput IBP All Steps per s" + ( (countS4UpdatedPIRItems + countS4FailedPIRItems ).toDouble() / (timeIBPInit + timeIBPFetch + timeIBPClose)).round(3).toString(); 
	    
	   if (timeS4ParallelPosts > 0) perflogs = perflogs + "\nS4 Effective Parallelization Factor " + (timeS4Posts / timeS4ParallelPosts).round(2).toString();
	    
        //messageLog.addAttachmentAsString('Performance Logs', perflogs, 'text/xml');

	message.setHeader("FetchedKeyfigures", props.get('StatsCountIBPFetch').toString());
    message.setHeader("SavedPIRs", countS4UpdatedPIRs);
	message.setHeader("SavedPIRItems", countS4UpdatedPIRItems);
	message.setHeader("FailedPIRs", countS4FailedPIRs);
	message.setHeader("FailedPIRItems", countS4FailedPIRItems);

	
	messageLog.addCustomHeaderProperty('Fetched Keyfigures', props.get('StatsCountIBPFetch').toString() );
    messageLog.addCustomHeaderProperty('Saved PIRs', countS4UpdatedPIRs.toString() );
    messageLog.addCustomHeaderProperty('Saved PIR Items', countS4UpdatedPIRItems.toString() );
    messageLog.addCustomHeaderProperty('Failed PIRs', countS4FailedPIRs.toString() );
    messageLog.addCustomHeaderProperty('Failed PIR Items', countS4FailedPIRItems.toString() );
    
    

	return message;
}

def void addLogCustomHeaderWithSplit(MessageLog messageLog, String headerName, String content) {
    def messageLength = content.length();
    if (messageLength<=198) messageLog.addCustomHeaderProperty(headerName, content);
    else {
        int i = 0;
        for (int j = 0; j < messageLength;j += 198) {
            def k = j + 198;
            i++;
            messageLog.addCustomHeaderProperty(headerName + '.' + i.toString(), content.substring(j,k<=messageLength?k:messageLength));
        }
    }
}
