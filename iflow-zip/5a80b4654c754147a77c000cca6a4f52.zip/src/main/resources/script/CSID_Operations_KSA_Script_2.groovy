import com.sap.gateway.ip.core.customdev.util.Message;
import java.nio.charset.StandardCharsets;
import groovy.json.JsonSlurper;

def Message prepareCSRRequest(Message message) {
       def properties = message.getProperties();
       def headers = message.getHeaders();
       
       String urlHost = properties.get("sciHost");
       String urlPostfix = "/SigningRequest/" + '$' + "value" + "?withExtensions=true";
       String urlPrefix  = "/api/v1/KeystoreEntries";
       
       String solutionUnitId = headers.get("SolutionUnitId");
       String csidSequenceNo = headers.get("CSIDSequenceNo");
       //Convert to hexadecimal value with upper case for alias
       String alias = solutionUnitId + "_" + csidSequenceNo;
       String hexAlias = alias.getBytes(StandardCharsets.UTF_8).encodeHex().toString().toUpperCase();
       
       //Prepare the URL to get CSR
       String csrRequestURL = urlHost + urlPrefix + "('" + hexAlias + "')" + urlPostfix;
       message.setHeader("CSRRequestURL", csrRequestURL);

       return message;
}

def Message prepareCSRFRequest(Message message) {
    String path = "/api/v1/"
    def properties = message.getProperties();
    def sciHost = properties.get("sciHost");
    message.setHeader("CSRFRequestURL" , sciHost + path);
    return message;
}

def Message prepareKeypairRequest(Message message) {
    String path = "/api/v1/KeyPairGenerationRequests"
    properties = message.getProperties();
    String sciHost = properties.get("sciHost");
    message.setHeader("KeyPairRequestURL" , sciHost + path);
    return message;
}

def Message prepareUserCredentialsURL(Message message) {
    String path = "/api/v1/UserCredentials";
    properties = message.getProperties();
    String sciHost = properties.get("sciHost");
    message.setHeader("UserCredentialsURL" , sciHost + path);
    return message;
}

def prepareKeypairUpdationURL(Message message) {
    def properties = message.getProperties();
    def headers = message.getHeaders();
    
    def urlHost = properties.get("sciHost");
    String urlPostfix = "/" + '$' + "value" + "?fingerprintVerified=true&returnKeystoreEntries=false";
    String urlPrefix  = "/api/v1/CertificateChainResources";
    
    String solutionUnitId = headers.get("SolutionUnitId");
    String csidSequenceNo = headers.get("CSIDSequenceNo");
    //Convert to hexadecimal value with upper case for alias
    String alias = solutionUnitId + "_" + csidSequenceNo;
    String hexAlias = alias.getBytes(StandardCharsets.UTF_8).encodeHex().toString().toUpperCase();
    
    //Prepare the URL to update Keypair
    String keypairUpdationURL = urlHost + urlPrefix + "('" + hexAlias + "')" + urlPostfix;
    message.setHeader("KeypairUpdationURL", keypairUpdationURL);
    return message;
}

def prepareKeypairDeletionURL(Message message) {
    def properties = message.getProperties();
    def headers = message.getHeaders();
    
    def urlHost = properties.get("sciHost");
    String urlPrefix  = "/api/v1/KeystoreEntries";
    
    String solutionUnitId = headers.get("SolutionUnitId");
    String csidSequenceNo = headers.get("CSIDSequenceNo");
    //Convert to hexadecimal value with upper case for alias
    String alias = solutionUnitId + "_" + csidSequenceNo;
    String hexAlias = alias.getBytes(StandardCharsets.UTF_8).encodeHex().toString().toUpperCase();
    
    //Prepare the URL to delete Keypair
    String keypairDeletionURL = urlHost + urlPrefix + "('" + hexAlias + "')";
    message.setHeader("KeypairDeletionURL", keypairDeletionURL);
    return message;
}

def prepareUserCredentialsDeletionURL(Message message) {
    def properties = message.getProperties();
    def headers = message.getHeaders();
    
    def urlHost = properties.get("sciHost");
    String urlPrefix  = "/api/v1/UserCredentials";
    
    String solutionUnitId = headers.get("SolutionUnitId");
    String csidSequenceNo = headers.get("CSIDSequenceNo");
    
    String alias_c = solutionUnitId + "_" + csidSequenceNo + "_c";
    String alias_p = solutionUnitId + "_" + csidSequenceNo + "_p";
    
    //Prepare the URL to delete UserCredentials
    String userCredentialsDeletionURL_c = urlHost + urlPrefix + "('" + alias_c + "')";
    String userCredentialsDeletionURL_p = urlHost + urlPrefix + "('" + alias_p + "')";
    message.setHeader("UserCredentialsDeletionURL_Comp", userCredentialsDeletionURL_c);
    message.setHeader("UserCredentialsDeletionURL_Prod", userCredentialsDeletionURL_p);
    return message;
}

def Message extractErrorMessage(Message message) {
    def properties = message.getProperties();
    
	//Handle HTTP Exceptions
    def ex = properties.get("CamelExceptionCaught");
    if (ex != null) {
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException") && isValidJson(ex.getResponseBody())) {
            message.setBody(ex.getResponseBody());
        }
        else if (ex.getClass().getCanonicalName().equals("java.util.concurrent.TimeoutException")) {
            message.setBody('{"code":"408","value":"Request Timeout"}');
        }
    }
    
    def body = message.getBody(String.class);
    if(body == '' || !isValidJson(body)) {
        def headers = message.getHeaders();
        message.setBody('{"code":"' + headers.get("CamelHttpResponseCode") + '","value":"' + headers.get("CamelHttpResponseText") + '"}');
    }
    return message;
}

def Message updateErrorDataIfEmpty(Message message) {
    def headers = message.getHeaders();
    def errorMsg;
    
    if( headers.get("ErrorCode") == null || headers.get("ErrorCode") == "" ) {
        message.setHeader("ErrorCode", "SCI Error");
    }
    if( headers.get("ErrorText") == null || headers.get("ErrorText") == "" ) {
        if( headers.get("CamelHttpResponseCode") != null && headers.get("CamelHttpResponseCode") != "" ) {
            errorMsg = "HTTP Status " + headers.get("CamelHttpResponseCode") + " - " + headers.get("CamelHttpResponseText");
        }
        else {
            errorMsg = "Check SCI logs for more details";
            message.setProperty("CamelExceptionCaught", new Exception(errorMsg));
        }
        message.setHeader("ErrorText", errorMsg);
    }
    
    return message;
}

def boolean isValidJson(String str) {
    try {
        new JsonSlurper().parseText(str);
        return true;
    }
    catch (Exception e) { return false; }
    return false;
}