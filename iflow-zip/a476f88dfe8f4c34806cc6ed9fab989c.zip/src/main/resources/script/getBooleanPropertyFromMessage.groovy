import com.sap.it.api.mapping.*;

def Boolean getPropertyToBoolean(String property_name, MappingContext context) {
    
    def propValue= context.getProperty(property_name);
    Boolean propertyAsBoolean = propValue.toBoolean();

    return propertyAsBoolean;

}