import com.sap.gateway.ip.core.customdev.util.Message
import groovy.transform.Field;
import groovy.json.*
import src.main.resources.script.ProductLoggingUtils

@Field String PRODUCT_ERROR_LOG = '-1 Product Error Log'
@Field String FORMAT_TEXT	= 'text/plain'
@Field String FORMAT_XML	= 'application/xml'
@Field String FORMAT_JSON	= 'application/json'


// - Log Product Errors if there's any replication errors (redis lock, validation error etc.)
def Message outputProductErrorLog(Message message) {
	def productError = message.getProperty("productError");
	if (productError.size > 0) {
	    def log = new JsonSlurper().parseText('{}');
        log.put("Products with errors", productError);
        this.getLoggingUtils().outputToLog(message, PRODUCT_ERROR_LOG, JsonOutput.prettyPrint(JsonOutput.toJson(log)));    
	}
    return message;
}

// 1. Log Incoming SB Response
def Message logIncomingSBResponse(Message message) {
    def pageNumber = message.getProperty("pageNumber");
    this.getLoggingUtils().outputToLog(message, "1." +pageNumber +" Response from SB", this.getLoggingUtils().prettyPrintJson(message));
	return message;
}

// 2. Log SB XML Payload
def Message logSBGeneratedXmlPayload(Message message) {
    def pageNumber = message.getProperty("pageNumber");
    
    if (pageNumber != '-1'){
        this.getLoggingUtils().outputDebugLog(message, "2." + pageNumber +" SB XML Payload", this.getLoggingUtils().prettyPrintXML(message), FORMAT_XML );
    }
	return message;
}

// 2a. Pre Exit Before
def Message logPreExitBefore(Message message) {
    def pageNumber = message.getProperty("pageNumber");
	this.getLoggingUtils().outputDebugLog(message, "2a." + pageNumber + " Pre Exit Before", this.getLoggingUtils().prettyPrintXML(message), FORMAT_XML );
	return message;
}

// 2b. Pre Exit After
def Message logPreExitAfter(Message message) {
    def pageNumber = message.getProperty("pageNumber");
	this.getLoggingUtils().outputDebugLog(message, "2b." + pageNumber + " Pre Exit After", this.getLoggingUtils().prettyPrintXML(message), FORMAT_XML );
	return message;
}

// 3. Log Mapping Result
def Message logMappingResult(Message message) {
    def pageNumber = message.getProperty("pageNumber");
	this.getLoggingUtils().outputDebugLog(message, "3." + pageNumber + " Mapping Result", this.getLoggingUtils().prettyPrintXML(message), FORMAT_XML );
	return message;
}

// 4. Log XML to JSON Result
def Message logXmlToJsonResult(Message message) {
    def pageNumber = message.getProperty("pageNumber");
	this.getLoggingUtils().outputDebugLog(message, "4." + pageNumber + " XML to JSON Result", this.getLoggingUtils().prettyPrintJson(message));
	return message;
}

// 5. Log Upsert Payload
def Message logUpsertPayload(Message message) {
    def pageNumber = message.getProperty("pageNumber");
	this.getLoggingUtils().outputDebugLog(message, "5." + pageNumber + " Upsert Payload", this.getLoggingUtils().prettyPrintJson(message));
	return message;
}

// 5a. Post Exit Before
def Message logPostExitBefore(Message message) {
    def pageNumber = message.getProperty("pageNumber");
	this.getLoggingUtils().outputDebugLog(message, "5a." + pageNumber + " Post Exit Before", this.getLoggingUtils().prettyPrintXML(message), FORMAT_XML );
	return message;
}

// 5b. Post Exit After
def Message logPostExitAfter(Message message) {
    def pageNumber = message.getProperty("pageNumber");
	this.getLoggingUtils().outputDebugLog(message, "5b." + pageNumber + " Post Exit After", this.getLoggingUtils().prettyPrintXML(message), FORMAT_XML );
	return message;
}

// 6. Log Product Transfer Output
def Message outputProductTransferLog(Message message) {
    def pageNumber = message.getProperty("pageNumber");
	this.getLoggingUtils().outputToLog(message, "6." + pageNumber + " Product Transfer Log", this.getLoggingUtils().prettyPrintJson(message));
	return message;
}

// 7. Log patch payload
def Message outputPatchPayloadLog(Message message) {
    def patchCounter = message.getProperty("patchCounter");
	this.getLoggingUtils().outputToLog(message, "7." + patchCounter +  " Patch Payload Log", this.getLoggingUtils().prettyPrintJson(message));
	return message;
}

def ProductLoggingUtils getLoggingUtils() {
	return new ProductLoggingUtils(messageLogFactory)
}

// Merge names and descriptions lists that come from SB into one list
def Message generateDescriptions(Message message) {
    def body = message.getBody(java.lang.String) as String; //response from Subscription Billing
    def jsonBody = new JsonSlurper().parseText(body); // LazyMap

    def languageCode = message.getProperty("defaultLanguageCode")
    if (languageCode == null || languageCode.trim().length() == 0) {
        languageCode = "en";
    }
    
    // get List of Products
    def productsList = jsonBody.products.product;
      
    // Loop over the list
    productsList.eachWithIndex { currentProduct, index ->
        def namesList = currentProduct.names;
        def descriptionList = currentProduct.descriptions;
        def information = new ArrayList();
        if (namesList.isEmpty() && descriptionList.isEmpty()) {
            // read from header
            def prInfo = new JsonSlurper().parseText("{}");
            prInfo.put("languageCode", languageCode);
            prInfo.put("name", currentProduct.name);
            prInfo.put("description", currentProduct.description);
            information.add(prInfo);
        } else {
            namesList.each { currentIt ->

                def foundObj = descriptionList.find { it.lang == "${currentIt.lang}" };
                if (foundObj == null) {
                    description = " ";
                } else {
                    description = foundObj.content;
                }

                def prInfo = new JsonSlurper().parseText("{}");
                prInfo.put("languageCode", currentIt.lang);
                if (currentIt.content == null) {
                    return;
                }
                prInfo.put("name", currentIt.content);
                prInfo.put("description", description);
                information.add(prInfo);
            }
        }
        jsonBody.products.product[index].put("generatedDescriptions", information);
    }
    
    def newBody = JsonOutput.toJson(jsonBody);
    message.setBody(newBody);
    return message;
}

// Merge markets and marketAttributesList lists that come from SB into one list
def Message generateMarketAttributes(Message message) {
    def body = message.getBody(java.lang.String) as String; //response from Subscription Billing
    def jsonBody = new JsonSlurper().parseText(body); // LazyMap

    // get List of Products
    def productsList = jsonBody.products.product;
    def productsToNotReplicate = new ArrayList();
    def log = new JsonSlurper().parseText('{}');
      
    // Loop over the products list
    productsList.eachWithIndex { currentProduct, index ->
        def marketsList = currentProduct.markets;
        def marketAttributesList = currentProduct.mixins.subscriptionProduct.marketAttributesList;
        def consolidatedMarkets = new ArrayList();
        if (marketsList.isEmpty() || marketAttributesList.isEmpty()) {
            // product should not be replicated as there's no rate plan or market assigned to it
            productsToNotReplicate.add(currentProduct);
            log.put("Product '" + currentProduct.name + "'", "Product could not be replicated because it is missing market and/or rate plan.");

        } else {
            marketsList.each { currentIt ->

                def foundObj = marketAttributesList.find { it.marketId == "${currentIt.marketId}" };
                if (foundObj != null) {
                    ratePlanId = foundObj.ratePlanId;

                    def prMarketAttribute = new JsonSlurper().parseText("{}");
                    prMarketAttribute.put("marketId", currentIt.marketId);
                    prMarketAttribute.put("ratePlanId", ratePlanId);
                    prMarketAttribute.put("active", currentIt.active);
                    consolidatedMarkets.add(prMarketAttribute);
                }
                else {
                    log.put("Product '" + currentProduct.name + "'", "Market '" + currentIt.marketId + "' could not be replicated because it is not assigned to a rate plan.");
                }
                
            }
            jsonBody.products.product[index].put("generatedMarketsAttributes", consolidatedMarkets);
        }
    }
    def pageNumber = message.getProperty("pageNumber");
    
    if (!log.isEmpty()){
        this.getLoggingUtils().outputDebugLog(message, "0." + pageNumber +" Invalid products", JsonOutput.prettyPrint(JsonOutput.toJson(log)), FORMAT_JSON );
    }
    
    
    jsonBody.products.product.removeAll(productsToNotReplicate)

    def newBody = JsonOutput.toJson(jsonBody);
    message.setBody(newBody);
    return message;
}

// Process Response
def Message processResponse(Message message) {
	def body = message.getBody(java.lang.String) as String; //response from product service
	
	def productError = message.getProperty("productError");
	if (productError instanceof String) {
	    productError = new ArrayList();
	    message.setProperty("productError", productError);
	}
	
	def errors = [];
	def successes = [];
	def log = new JsonSlurper().parseText('{}');
	def responses = new JsonSlurper().parseText(body);

    def headers = message.getHeaders();
    def httpStatus = headers.get("CamelHttpResponseCode");
    log.put("HttpStatusCode: ", httpStatus);
    
    if (httpStatus >= 400){
        def error = new JsonSlurper().parseText('{}');
        error.put("message":"Something went wrong!");
        errors.push(error);
    }

    def batchResponseProducts = responses.batchResponseProducts;

	if (batchResponseProducts instanceof Collection) { // request error message
		batchResponseProducts.each { response ->
			if (response.status == "Error") {
				def error = new JsonSlurper().parseText('{}');
				// get displayId
                error.put("displayId", response.displayId);
                error.put("code", response.error.code);
                error.put("message", response.error.message);
				productError.add(error);
			}
			else {
				def success = new JsonSlurper().parseText('{}');
				success.put("id", response.id);
				success.put("displayId", response.displayId);
				success.put("name", response.name);
				success.put("status", response.status);
				successes.add(success);
			}
		}
	}
	else {
		errors.push(responses);
	}

	if (errors.size > 0) {
		message.setProperty("hasErrors", true);
	}
    log.put("Product Replication Response : ",responses);
	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(log)));
	message.setProperty("productError", productError);

	return message;
}

// Exceptions

def Message externalSystemIdNotFoundException(Message message) { 
	throw new ProductTransferException("Please add externalSystemId in Configure Option");
}

def Message pageSizeExceededException(Message message) { 
	throw new ProductTransferException("Please provide a page size that is equal or less than page size default value!");
}

def Message raiseProductTransferException(Message message) { 
	throw new ProductTransferException("One or more error(s) occurred during transfer. Please look at the Logs for more details.");
}

public class ProductTransferException extends Exception { 
	public ProductTransferException(String message) { 
		super(message);
	}
}
