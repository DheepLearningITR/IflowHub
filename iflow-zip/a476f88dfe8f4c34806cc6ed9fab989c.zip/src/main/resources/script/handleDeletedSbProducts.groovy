import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*;

def Message addProductsToSBProductsList(Message message) {
    def body = message.getBody(java.lang.String) as String; //response from Subscription Billing
    def jsonBody = new JsonSlurper().parseText(body); // LazyMap

    // get list of SB products
    def productsList = jsonBody.products.product;
    
    // add to be replicated products to sbProducts list
    def sbProducts = message.getProperty("sbProducts");
	if (sbProducts instanceof String) {
	    sbProducts = new ArrayList();
	    message.setProperty("sbProducts", sbProducts);
	}
		
	def mapProductCodeToExternalId = message.getProperty("mapProductCodeToExternalId");
	
    if(mapProductCodeToExternalId == "false") {
	   for (int i = 0; i < productsList.size(); i++) {
    	   def product = productsList.get(i);
	       sbProducts.add(product.id)
	   }
	} else {
	   for (int i = 0; i < productsList.size(); i++) {
    	  def product = productsList.get(i);
	       sbProducts.add(product.code)
	   }
	}
	message.setProperty("sbProducts", sbProducts);
	
	return message;
	
}

def Message addProductsToOmfProductsList(Message message) {
    def body = message.getBody(java.lang.String) as String; //response from OMF to get products
    def jsonBody = new JsonSlurper().parseText(body); // LazyMap

    // get list of OMF products
    def productsList = jsonBody;
    
    // add OMF products to omfProducts list
    def omfProducts = message.getProperty("omfProducts");
	if (omfProducts instanceof String) {
	    omfProducts = new ArrayList();
	    message.setProperty("omfProducts", omfProducts);
	}
	
	for (int i = 0; i < productsList.size(); i++) {
	    def product = productsList.get(i);
	    if (product.externalSystemReferences.size() == 1) {
	        def omfIds = new JsonSlurper().parseText("{}");
            omfIds.put("id", product.id);
	        omfIds.put("externalId", product.externalSystemReferences[0].externalId);
	        omfProducts.add(omfIds);
	    }
	}
	
	message.setProperty("omfProducts", omfProducts);
	
	return message;
}

def Message prepareProductPatchPayload(Message message) {
    
    def productsToBeDeletedIds = new ArrayList();
    
    def omfProducts = message.getProperty("omfProducts");
    def sbProducts = message.getProperty("sbProducts");
	def patchPayload = message.getProperty("omfPatchPayload");
	
	for (int i = 0; i < omfProducts.size(); i++) {
	    def omfProduct = omfProducts.get(i);
	    if (!sbProducts.contains(omfProduct.externalId)) {
	        productsToBeDeletedIds.add(omfProduct.id);
	    }
	}
	
	// build batch payload
	if (patchPayload instanceof String) {
		patchPayload = new ArrayList();
		message.setProperty("omfPatchPayload", patchPayload);
	}
	

	for (int i = 0; i < productsToBeDeletedIds.size(); i++) {
	    def batchProductObj = new JsonSlurper().parseText("{}");
	    batchProductObj.put("id", productsToBeDeletedIds.get(i));
	    batchProductObj.put("markedForDeletion", true);
	    
	    
	    patchPayload.add(batchProductObj);
	}

	if (patchPayload.size() > 0) {
		message.setProperty("omfPatchPayload", patchPayload);
		message.setProperty("deleteSbProducts", "true");
	}
	
    return message;
}

def Message paginatePatchPayload(Message message) {
    
	def omfPatchPayload = message.getProperty("omfPatchPayload");
	def omfPatchPayloadTemp = message.getProperty("omfPatchPayloadTemp");
	def patchPayloadLimit = message.getProperty("patchPayloadLimit") as Integer;
	def patchCounter = message.getProperty("patchCounter") as Integer;

	if (omfPatchPayloadTemp instanceof String) {
		omfPatchPayloadTemp = new ArrayList();
		message.setProperty("omfPatchPayloadTemp", omfPatchPayloadTemp);
	}
	
	if (omfPatchPayload.size() == 0 && omfPatchPayloadTemp.size() == 0) {
	    message.setProperty("deleteSbProducts","false");
	    return message;
	}
	

	if (omfPatchPayload.size() > patchPayloadLimit) {
		omfPatchPayloadTemp =  new ArrayList<>(omfPatchPayload.subList(patchPayloadLimit, omfPatchPayload.size()));
		message.setProperty("omfPatchPayloadTemp", omfPatchPayloadTemp);
		omfPatchPayload =  new ArrayList<>(omfPatchPayload.subList(0, patchPayloadLimit));
	}
	else if (omfPatchPayload.size() == 0 && omfPatchPayloadTemp.size() > 0) {
		if (omfPatchPayloadTemp.size() <= patchPayloadLimit) {
			omfPatchPayload = omfPatchPayloadTemp;
			omfPatchPayloadTemp = new ArrayList();
			message.setProperty("omfPatchPayloadTemp", omfPatchPayloadTemp);
		}
		else {
			omfPatchPayload =  new ArrayList<>(omfPatchPayloadTemp.subList(0, patchPayloadLimit));
			omfPatchPayloadTemp =  new ArrayList<>(omfPatchPayloadTemp.subList(patchPayloadLimit, omfPatchPayloadTemp.size()));			
			message.setProperty("omfPatchPayloadTemp", omfPatchPayloadTemp);
		}
		
	}

	if (omfPatchPayload.size() > 0) {
		message.setProperty("deleteSbProducts", "true");
	    def newBody = JsonOutput.toJson(omfPatchPayload);
        message.setBody(newBody);
		// reset omfPatchPayload
		omfPatchPayload = new ArrayList();
		message.setProperty("omfPatchPayload", omfPatchPayload);
		patchCounter++;
		message.setProperty("patchCounter", patchCounter);

	}
	else { // both patchPayload lists are empty
		message.setProperty("deleteSbProducts", "false");
	}

	return message;
}