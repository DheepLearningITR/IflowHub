import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*;

// Increase pageNumber for SB call
def Message increasePageNumber(Message message){
    def pageNumber = message.getProperty("pageNumber");

    def body = message.getBody(java.lang.String) as String; //response from Subscription Billing
    def jsonBody = new JsonSlurper().parseText(body); // LazyMap
    
    // get List of Products
    def productsList = jsonBody; //ArrayList
    if (productsList.isEmpty() ){
        message.setProperty("pageNumber", '-1');
    }
    else {
        Integer pageNumberAsInteger = pageNumber as Integer;
        pageNumberAsInteger++;
        message.setProperty("pageNumber", pageNumberAsInteger.toString());
    }
    
    return message;
}

// Increase pageNumber for OMF call
def Message increaseOmfPageNumber(Message message){
    def pageNumber = message.getProperty("omfPageNumber");
    
    if (pageNumber == null || pageNumber == "")
        message.setProperty("omfPageNumber", '0');

    def body = message.getBody(java.lang.String) as String; //response from OMF
    def jsonBody = new JsonSlurper().parseText(body); // LazyMap
    
    // get List of Products
    def productsList = jsonBody; //ArrayList
    if (productsList.isEmpty() ){
        message.setProperty("omfPageNumber", '-1');
    }
    else {
        Integer pageNumberAsInteger = pageNumber as Integer;
        pageNumberAsInteger++;
        message.setProperty("omfPageNumber", pageNumberAsInteger.toString());
    }
    
    return message;
}

// Reset pageNumber for SB
def Message resetSBPageNumber(Message message){
   
    def pageNumber = 0;
    message.setProperty("pageNumber", pageNumber.toString());
    
    return message;
}