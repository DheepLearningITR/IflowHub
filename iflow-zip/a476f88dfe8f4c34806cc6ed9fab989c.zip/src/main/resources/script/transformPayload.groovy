import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message removeProductRootNode(Message message) {

	def body = message.getBody(java.lang.String) as String;

	if(body != null && !body.trim().isEmpty()){
		def bodyJson = new JsonSlurper().parseText(body);
		if (!bodyJson.product) {
		    throw new SubscriptionProductFormatException("Message format is not as defined in subscription-product-schema.xsd. Root node 'product' is missing!")
		}
		def products = bodyJson.product;
		if (products.size == null) { // if there's only 1 product, put it in an array
			def product = products;
			products = [];
			products.push(product);
		}
		message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(products)));
	}

	return message;
}

// Exception

public class SubscriptionProductFormatException extends Exception {
	public SubscriptionProductFormatException(String message) {
		super(message);
	}
}
