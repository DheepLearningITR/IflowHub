import com.sap.it.api.mapping.*;

def String getMappingForExternalId(String mapCodeToExternalId, String id, String code){
    
    if(mapCodeToExternalId.equalsIgnoreCase('true')){
        return code
    }
    else{
	    return id
    }
}