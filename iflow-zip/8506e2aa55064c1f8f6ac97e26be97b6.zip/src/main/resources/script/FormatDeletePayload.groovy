import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*

def Message processData(Message message) {
    def json = new JsonSlurper().parseText(message.getBody(String));
    def body;
    if (json != null) {
        def totalObjectCount = json.totalObjectCount;
        message.setProperty('lastPage',json.lastPage);
        message.setProperty('totalObjectCount',totalObjectCount);
        if (totalObjectCount > 0) {
            def dataArray = json.data;
            for (def i=0; i < dataArray.size(); i++) {
                def id = dataArray[i].unifiedPerson.id;
                if (id != null) {
                    if (i == 0) {
                        body = body + '{"id":"'+ id +'","inactive":"true"}';
                    }else{
                        body = body + ',{"id":"'+ id +'","inactive":"true"}'; 
                    }
                }
            }
            if (body != null) {
                body = '['+ body +']';
                body = body.replace("null","");
                message.setBody(body);
            }
        }
    }
    return message;
}