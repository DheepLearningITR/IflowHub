import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.asdk.datastore.*
import com.sap.it.api.asdk.runtime.*

def Message processData(Message message) {
    def valueMappingApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def allfsmCompanyList;
    
    def getAllCompanies = {
        def messageLog = messageLogFactory.getMessageLog(message)
        def DSservice = new Factory(DataStoreService.class).getService()
        // get the FSM Company List from data store
        def dsEntry = DSservice.get("FSMCompanyList", 'FSMCompanyList')?DSservice.get("FSMCompanyList", 'FSMCompanyList'):'NA'
		if (dsEntry != 'NA'){
			def result = new String(dsEntry.getDataAsArray())
			allfsmCompanyList = new XmlParser().parseText(result)
		}else{
		   allfsmCompanyList = new XmlParser().parseText("<FSMMultiCompany><FSMCompany>NA|NA</FSMCompany></FSMMultiCompany>")
		}
    }
	getAllCompanies();
	
    def FSMCompanyData = XmlUtil.serialize(allfsmCompanyList)
    message.setBody(FSMCompanyData)
    return message
}