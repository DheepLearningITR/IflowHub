import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message){
    def body = message.getBody(java.lang.String);
    def query = new XmlSlurper().parseText(body);
    def FSMAccountCompany = query.text();
    
    if (FSMAccountCompany != null || FSMAccountCompany != ''){
        message.setHeader("X-Account-ID",FSMAccountCompany.split("\\|")[0]);
        message.setHeader("X-Company-ID",FSMAccountCompany.split("\\|")[1]);

        message.setProperty("X-Account-ID",FSMAccountCompany.split("\\|")[0]);
        message.setProperty("X-Company-ID",FSMAccountCompany.split("\\|")[1]);
                
        def retentionPeriod = message.getProperty('RetentionPeriod');
        retentionPeriod = retentionPeriod.toInteger();
        def daysToBeDeducted = retentionPeriod * -1;
        
        def CompareDate = Calendar.getInstance();
        CompareDate.add(Calendar.DATE, daysToBeDeducted); 
        (_E, Y, M, _WY, _WM, D) = CompareDate; 
        QueryParameter = "createDateTime >=\"$Y-${M+1}-$D" + "T00:00:00Z\" AND orgLevelIds is null AND inactive =\"false\"";
        message.setProperty("QueryParameter", QueryParameter);
    }
    
  def xml_data = XmlUtil.serialize(query);
  message.setBody(xml_data);
  
  return message;
}
