import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def query = new XmlSlurper().parseText(body);
    List<String> list = new ArrayList<String>();
    def insertOrChangeExists = false;
    query.IDOC.each{
        if(it.E1010821150212.E1010821150213.OBJECT_TASK.text() == "D")
        {
            list.add(it.E1010821150212.E1010821150213.E1010821150214.E1010821150215.PARTNER_NO.text());
            it.replaceNode {};
        }else{
            insertOrChangeExists = true
        }
    }
    message.setProperty("Insert_or_Change_Exists",insertOrChangeExists.toString());
    message.setProperty("Deleted_relationships", list);
    message.setProperty("Delete_relationship_Count", list.size());
    def valid_data = XmlUtil.serialize(query);
    message.setBody(valid_data);
    return message;
}