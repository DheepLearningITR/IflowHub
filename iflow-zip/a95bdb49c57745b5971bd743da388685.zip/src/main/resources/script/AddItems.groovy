import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String);
    def jsonSlurper = new JsonSlurper();
    def quote = jsonSlurper.parseText(body);

    //Property
    def map = message.getProperties();
    def quoteItems = jsonSlurper.parseText(map.get("QuoteItems"));
    
    quote['Items'] = [:];
    quote['Items']['Item'] = quoteItems;
    
    body = JsonOutput.toJson(quote);
    message.setBody(body);

    return message;
}