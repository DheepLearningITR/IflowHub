import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;
import groovy.json.JsonOutput;
import java.time.Instant;

@Field String ERROR_SHORTTEXT = 'ERROR';
@Field String INFO_SHORTTEXT = 'INFO';
@Field String GENERIC_ERROR_MESSAGE = 'A technical error occurred. Use the SAP Cloud Integration message ID to find additional error details.';
@Field String CPI_MSGID_TEXT = 'SAP Cloud Integration message ID: ';

@Field String COMMUNICATION_ERROR_TYPE = 'COMMUNICATION_ERROR';
@Field String MESSAGE_PROCESSING_ERROR_TYPE = 'MESSAGE_PROCESSING_ERROR';

@Field String STATUS_SUCCESS = 'SUCCESS';
@Field String STATUS_FAILURE = 'FAILURE';

class ResponseMsg {
	String type
	String message
}

class Acknowledgement {
	String status
	Error error
}

class Error {
	String code
	String type
	String messageId
	String date
}

def Message normalResponse(Message message) {
	buildResponse(message, false);
}

def Message exceptionResponse(Message message) {
	buildResponse(message, true);
}
	
def Message buildResponse(Message message, boolean isException) {	
	def properties = message.getProperties();
	
	def headers = message.getHeaders();
	headers.put("Content-Type",   "application/json");	
	
	def response = [:];		
	List<ResponseMsg> respMsgs = [];

	response["isSuccess"] = !isException;
	
	if (isException) {		
	    String messageString = "";
		def exceptionCause;

		exceptionCause = properties.get("CamelExceptionCaught").getCause();
		
		messageString = (exceptionCause) ? (exceptionCause.getMessage()): "";
		messageString = (messageString.trim()) ? messageString.replaceAll("\\P{Print}", "") : "";

		if (!exceptionCause) {
			messageString = properties.get("CamelExceptionCaught").message.replaceAll("\\P{Print}", "");
		}
	
		if (!messageString.trim()) {
			messageString = GENERIC_ERROR_MESSAGE;
		}
						
		respMsgs.add(new ResponseMsg(type:ERROR_SHORTTEXT,message:messageString));						
	} 

	//Add CPI MsgID to messages	
	respMsgs.add(new ResponseMsg(type:INFO_SHORTTEXT,message:CPI_MSGID_TEXT + properties.get("SAP_MessageProcessingLogID")));  
	response["messages"] = respMsgs;
	
	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(response)));	
	
	return message;
}

def Message buildSuccessAcknowledgement(Message message) {
	def acknowledgement = new Acknowledgement(status:STATUS_SUCCESS, error:null);
	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(acknowledgement)));
	return message;
}

def Message buildAcknowledgementForTransformationError(Message message) {
	return buildFailedAcknowledgementMessage(message, MESSAGE_PROCESSING_ERROR_TYPE);
}

def Message buildAcknowledgementForSendingError(Message message) {
	return buildFailedAcknowledgementMessage(message, COMMUNICATION_ERROR_TYPE);
}

def Message buildFailedAcknowledgementMessage(Message message, String errorType) {
	def headers = message.getHeaders() as Map<String, Object>
	def properties = message.getProperties() as Map<String, Object>

	def messageID = headers.get("SAP_MessageProcessingLogID")
	def exceptionProperty = properties.get("CamelExceptionCaught");

	def statusCode = exceptionProperty.hasProperty('statusCode') ? exceptionProperty.getStatusCode() : ""
	def error = new Error(code:statusCode,type:errorType,messageId:messageID,date:Instant.now().toString())
	def acknowledgement = new Acknowledgement(status:STATUS_FAILURE, error:error);

	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(acknowledgement)));
	return message;
}


