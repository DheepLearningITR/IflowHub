import com.sap.it.api.mapping.*;
import java.util.UUID;


def String getRandomUUID(){
		return UUID.randomUUID().toString()
}