import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat

def Message processData(Message message) {

    def discoundEndDate = message.getProperty("discount_end_date")
    SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")
    SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX")

    Date date = inputFormat.parse(discoundEndDate)

    String outputDateString = outputFormat.format(date).replace("Z", "+00:00")

    message.setProperty("discount_end_date", outputDateString)

    return message
}