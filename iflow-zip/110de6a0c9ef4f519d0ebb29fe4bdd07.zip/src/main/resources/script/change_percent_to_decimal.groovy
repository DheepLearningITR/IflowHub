import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def percentageValue = message.getProperty("sap_condition_rate_value")?.toString();

    if (percentageValue != null) {
        try {
            BigDecimal positiveConditionRateValue = Math.abs(new BigDecimal(percentageValue));

            float positiveFloatValue = positiveConditionRateValue.floatValue();
            message.setProperty("positive_condition_value", positiveFloatValue);

        } catch (NumberFormatException e) {
            // Handle the case where the input is not a valid number
            throw new IllegalArgumentException("The provided percentage value is invalid: " + percentageValue, e);
        }
    }

    return message;
}