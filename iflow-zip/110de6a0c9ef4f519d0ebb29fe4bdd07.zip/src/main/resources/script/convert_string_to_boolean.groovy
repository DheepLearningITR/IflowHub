import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def canStackDiscounts = message.getProperty("can_stack_discounts")
    message.setProperty("can_stack_discounts", canStackDiscounts.toBoolean())
    
    return message
}