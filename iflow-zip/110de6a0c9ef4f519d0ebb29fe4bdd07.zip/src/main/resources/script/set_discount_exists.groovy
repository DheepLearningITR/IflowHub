import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def discountList = message.getProperty("discount_list")
    def currentProductId = message.getProperty("request_product_id")

    def slurper = new JsonSlurper()
    def json = slurper.parseText(discountList)

    def discountForProductId = json.discounts.find { discount -> 
        discount.productId?.toString() == currentProductId?.toString()
    }

    if (discountForProductId != null) {
    message.setProperty("discount_exists", "true")
    message.setProperty("discount_id", discountForProductId.id)
    } else {
    message.setProperty("discount_exists", "false")
    }

    return message
}