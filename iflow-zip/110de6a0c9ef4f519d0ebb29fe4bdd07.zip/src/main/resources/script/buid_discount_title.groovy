import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    String conditionRateValue = message.getProperty("sap_condition_rate_value")?.toString();
    String discountType = message.getProperty("sap_discount_type")?.toString();
	String productSKU = message.getProperty("sap_material_code")?.toString();

    String positiveConditionRateValue = Math.abs(new BigDecimal(conditionRateValue)).toString();

    String title = "${positiveConditionRateValue} ${discountType} Off Automatic Discount on Product ${productSKU}";

    message.setProperty("title", title);

    return message;
}