import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def body = message.getBody(String)
    def slurper = new JsonSlurper()
    def json = slurper.parseText(body)

    def metaInfo = json.meta.pagination.links
    def nextPage = metaInfo.next

    if (nextPage) {
        message.setProperty("next_discounts_page_query", nextPage)
    } else {
        message.setProperty("has_more_discounts", false)
    }

    return message
}