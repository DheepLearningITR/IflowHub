import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
	Integer intRetryTimes = 0;
	headersMap = message.getHeaders();
	String strRetryTimes = headersMap.get("SAPJMSRetries");
	if (strRetryTimes?.isInteger()) {
	    intRetryTimes = strRetryTimes.toInteger();
	}
	propertiesMap = message.getProperties();
	strEnablePayloadLog = propertiesMap.get("ENABLE_PAYLOAD_LOGGING");
	iDocNumber = propertiesMap.get("IDOC_NUMBER");
/*
    String applicationObjectType = "";
    String applicationObjectId = "";
    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body);
    if (json.applicationObjects instanceof ArrayList) {
        applicationObjectType = json.applicationObjects[0].applicationObjectType;
        applicationObjectId = json.applicationObjects[0].applicationObjectId;
    } else {
        applicationObjectType = json.applicationObjects.applicationObjectType;
        applicationObjectId = json.applicationObjects.applicationObjectId;
    }
    message.setHeader("SAP_MessageType", applicationObjectType);
	message.setHeader("SAP_ApplicationID", applicationObjectId);
	*/
	if (strEnablePayloadLog.toUpperCase().equals("TRUE") && !(intRetryTimes > 0.5)) {
		def body = propertiesMap.get("MESSAGE_SENT_TO_GTT");
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
	        messageLog.setStringProperty("IDOC Number", iDocNumber);
			messageLog.addAttachmentAsString("Message sent to GTT with IDOC Number " + iDocNumber, body, "text/plain");
		}
	}
	return message;
}