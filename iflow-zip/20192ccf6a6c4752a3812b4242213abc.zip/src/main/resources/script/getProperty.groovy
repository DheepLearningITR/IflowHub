import com.sap.it.api.mapping.MappingContext;

def String getPropertyValue(String propertyName, MappingContext context){
	String propertyValue = context.getProperty(propertyName);
	return propertyValue;
}