import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import javax.xml.crypto.AlgorithmMethod;
import org.apache.camel.component.xmlsecurity.api.XmlSignatureHelper;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.cert.CertificateException;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;

import com.sap.it.api.keystore.KeystoreService;
import java.security.KeyPair;
import java.security.Signature;
import java.math.BigInteger;

def Message addTransforms(Message message) {
    List<AlgorithmMethod> transforms = new ArrayList<AlgorithmMethod>(4);
    AlgorithmMethod m1 = XmlSignatureHelper.getXPathTransform("not(ancestor-or-self::ext:UBLExtensions)",
            Collections.singletonMap("ext", "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2"));
    transforms.add(m1);
    
    AlgorithmMethod m2 = XmlSignatureHelper.getXPathTransform("not(ancestor-or-self::cac:Signature)",
            Collections.singletonMap("cac", "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"));
    transforms.add(m2);
    
    Map<String, String> prefixToNamespace = new HashMap<String, String>(2);
    prefixToNamespace.put("cbc", "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2");
    prefixToNamespace.put("cac", "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2");
    AlgorithmMethod m3 = XmlSignatureHelper.getXPathTransform("not(ancestor-or-self::cac:AdditionalDocumentReference[cbc:ID='QR'])",
                                                                prefixToNamespace);
    transforms.add(m3);
    
    transforms.add(XmlSignatureHelper.getCanonicalizationMethod("http://www.w3.org/2006/12/xml-c14n11"));
    
    def properties = message.getProperties();
    message.setProperty("CamelXmlSignatureTransformMethods", transforms);
    return message;
}

def Message trimBodyAndStore(Message message) {
    def body = message.getBody(String.class);
    body = body.replaceAll("\\s","");
    message.setBody(body);
    message.setProperty("SignedXMLEncoded", body);
    return message;
}

def Message generateQrCodeAndSigningAttributes(Message message) {
    def properties = message.getProperties();
    def headers = message.getHeaders();
    
    //Extracting Info from Properties
    String sellerName = properties.get("sellerName");
    String sellerVAT = properties.get("sellerVAT");
    String timestamp = properties.get("issueDate") + "T" + properties.get("issueTime");
    String invoiceTotal = properties.get("invoiceTotal");
    String vatTotal = properties.get("vatTotal");
    String hash = properties.get("hash");
    String signature = properties.get("signature");
    
    //Extracting Info from Headers
    String csid = headers.get("CSID");
    String process = headers.get("Process");
    
    String pubkey, ecdsaSign, x509IssuerName;
    
    if(process == "compliance"){
        csid = headers.get("CCSID");
    }
    
    csid = csid.replaceAll("\\s","");
    csid = new String(csid.decodeBase64());
    
    //Extracting Public Key from Certificate
    //ECDSA signature of the cryptographic stamp’s issued by ZATCA’s technical CA
    try {
		CertificateFactory f = CertificateFactory.getInstance("X.509");
		X509Certificate x509cert = (X509Certificate)f.generateCertificate(new ByteArrayInputStream(csid.decodeBase64()));
        
        x509IssuerName = x509cert.getIssuerDN().getName();
        pubkey = x509cert.getPublicKey().getEncoded().encodeBase64().toString();
        ecdsaSign = x509cert.getSignature().encodeBase64().toString();
	} catch (CertificateException e) {
        message.setHeader("ErrorCode", "SCI Error");
        message.setHeader("ErrorText", e.getMessage());
        throw new Exception(e.getMessage());
	}
    
    //Generating TLV for QR Code
    try {
        def arr = [sellerName,sellerVAT,timestamp,invoiceTotal,vatTotal,hash,signature,pubkey,ecdsaSign];
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        for(int i=0; i<9; i++)
        {   
           //To store hex 0x81 (for one byte length) or hex 0x82 (for two bytes length) temp is defined
           //To specify in how many bytes length of the value will be stored as per the TLV format
            int length;
            def temp;
            
            byte[] tag, len, val;
            tag = i+1;
            if (i != 7 && i != 8){
                val = arr[i].getBytes(StandardCharsets.UTF_8);
                def hex = val.encodeHex().toString();
                length = hex.length()/2;
                len = length > 255 ? BigInteger.valueOf(length).toByteArray() : length;
            }
            else{
                val = arr[i].decodeBase64();
                len = val.length;
            }
            
        	ByteArrayOutputStream tempOut = new ByteArrayOutputStream();
        	tempOut.write( tag );
        	
        	//write hex 0x81 or 0x82 to specify the number of bytes length of the value is stored
        	if ( length > 127 && length <= 255 ) {
        	    temp = 0x81;
        	    tempOut.write( temp );
        	} 
        	else if ( length > 255) {
                temp = 0x82;
        	    tempOut.write( temp );
            } 
            
        	tempOut.write( len );
        	tempOut.write( val );
    	    byte[] tlv = tempOut.toByteArray( );
    	    
    	    out.write(tlv);
        }
        byte[] qr = out.toByteArray();
        //Setting the QR code as property for further use
        message.setProperty("QRCode",qr.encodeBase64().toString());
    } catch (Exception e) {
        message.setHeader("ErrorCode", "SCI Error");
        message.setHeader("ErrorText", e.getMessage());
        throw new Exception(e.getMessage());
    }
    
    message.setProperty("x509IssuerName", x509IssuerName);
    return message;
}

def Message prepareURLforReporting(Message message) {
    def properties = message.getProperties();
    def headers = message.getHeaders();
    
    def op_mode = properties.get("Mode");
    def testURL = properties.get("Test_URL");
    def prodURL = properties.get("Prod_URL");
    def process = headers.get("Process");
    def solutionUnitId = headers.get("SolutionUnitId");
    def csidSeqNo = headers.get("CSIDSequenceNo");
    String path, alias;
    
    if(op_mode == "TEST"){
        receiver_endpoint = testURL;
    }
    else if(op_mode == "PROD"){
        receiver_endpoint = prodURL;
    }
    else{
        def errorMsg = "Communication Mode: " + op_mode + " is incorrect; Only 'TEST' or 'PROD' are allowed";
        message.setHeader("ErrorCode", "SCI Error");
        message.setHeader("ErrorText", errorMsg);
        throw new Exception(errorMsg);
    }
    
    if(process == "compliance"){
        path = "/compliance/invoices";
        def ccsid = headers.get("CCSID");
        ccsid = ccsid.replaceAll("\\s","");
        alias = solutionUnitId + "_" + csidSeqNo + "_c";
        message = addAuthHeader(message, alias, ccsid);
    }
    else{
        path = "/invoices/reporting/single";
        message.setHeader("Clearance-Status", "1");
        
        def csid = headers.get("CSID");
        csid = csid.replaceAll("\\s","");
        alias = solutionUnitId + "_" + csidSeqNo + "_p";
        message = addAuthHeader(message, alias, csid);
    }

    message.setHeader("urlReporting" , receiver_endpoint + path);
    return message;
}

def Message updatePIH(Message message) {
    def properties = message.getProperties();
    def hash = properties.get("hash");
    
    String pih_updated = convertHash(hash);
    
    message.setHeader("PIH", pih_updated);
    return message;
}

def Message convertHashValues(Message message) {
    def headers = message.getHeaders();
    String certHash_unconverted = headers.get("certHash_unconverted");
    String signedPropertiesHash_unconverted = headers.get("signedPropertiesHash_unconverted");
    
    String certHash = convertHash(certHash_unconverted);
    String signedPropertiesHash = convertHash(signedPropertiesHash_unconverted);
    
    message.setProperty("certHash", certHash);
    message.setProperty("signedPropertiesHash", signedPropertiesHash);
    return message;
}

def String convertHash(String str) {
    String hash_hex = str.decodeBase64().encodeHex().toString();
    return hash_hex.getBytes(StandardCharsets.UTF_8).encodeBase64().toString();
}

def Message getSignedProperties(Message message) {
    def properties = message.getProperties();
    def headers = message.getHeaders();
    
    String certHash = convertHash(headers.get("certHash_unconverted"));
    String signingTime = properties.get("signingTime");
    String x509IssuerName = properties.get("x509IssuerName");
    String x509SerialNumber = properties.get("x509SerialNumber");
    
    String signedProperties = String.format('<xades:SignedProperties xmlns:xades="http://uri.etsi.org/01903/v1.3.2#" Id="xadesSignedProperties"><xades:SignedSignatureProperties><xades:SigningTime>%s</xades:SigningTime><xades:SigningCertificate><xades:Cert><xades:CertDigest><ds:DigestMethod xmlns:ds="http://www.w3.org/2000/09/xmldsig#" Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/><ds:DigestValue xmlns:ds="http://www.w3.org/2000/09/xmldsig#">%s</ds:DigestValue></xades:CertDigest><xades:IssuerSerial><ds:X509IssuerName xmlns:ds="http://www.w3.org/2000/09/xmldsig#">%s</ds:X509IssuerName><ds:X509SerialNumber xmlns:ds="http://www.w3.org/2000/09/xmldsig#">%s</ds:X509SerialNumber></xades:IssuerSerial></xades:Cert></xades:SigningCertificate></xades:SignedSignatureProperties></xades:SignedProperties>', signingTime, certHash, x509IssuerName, x509SerialNumber);
    
    message.setBody(signedProperties);
    return message;
}

def Message addAuthHeader(Message message, String alias, String userId) {
    SecureStoreService sss = ITApiFactory.getService(SecureStoreService.class, null);
    if (sss != null)
    {   
        //Getting User Credentials from Secure Store Service
        def userCred = sss.getUserCredential(alias);
        if (userCred != null)
        {
            //Setting Basic Authorization Header
            message.setHeader("Authorization", "Basic " + (userId + ":" + userCred.getPassword()).getBytes(StandardCharsets.UTF_8).encodeBase64().toString());
        }
        else
        { 
            def errorMsg = "Error while getting User Credentials from Security Material; Check if User Credential '" + alias + "' is present in Security Material";
            message.setHeader("ErrorCode", "SCI Error");
            message.setHeader("ErrorText", errorMsg);
            throw new Exception(errorMsg);
        }
    }
    else{
        def errorMsg = "Error while creating object for Class SecureStoreService";
        message.setHeader("ErrorCode", "SCI Error");
        message.setHeader("ErrorText", errorMsg);
        throw new Exception(errorMsg);
    }
    
    return message;
}

def Message storeErrorDataAsHeader(Message message) {
    def headers = message.getHeaders();
    def properties = message.getProperties();
    
    //Timeout Error
    def ex = properties.get("CamelExceptionCaught");
    if (ex != null) {
        if (ex.getClass().getCanonicalName().equals("java.util.concurrent.TimeoutException")) {
            message.setHeader("ErrorCode", "408");
            message.setHeader("ErrorText", "Request Timeout");
        }
    }
    
    def errorMsg;
    if(headers.get("CamelHttpResponseCode") == 401 || properties.get("exceptionMessage") == null) {
        errorMsg = "HTTP Status " + headers.get("CamelHttpResponseCode") + " - " + headers.get("CamelHttpResponseText");
    }
    else {
        errorMsg = properties.get("exceptionMessage");   
    }
    
    if( headers.get("ErrorCode") == null ) {
        message.setHeader("ErrorCode", "SCI Error");
    }
    if( headers.get("ErrorText") == null ) {
        message.setHeader("ErrorText", errorMsg);
    }
    
    return message;
}