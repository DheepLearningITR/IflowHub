/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;
def Message processData(Message message) {
       //Properties 
       map = message.getProperties();
       def commentsList = map.get("secCommentsList") as ArrayList;
       def commentIds = map.get("secCommentIds") as ArrayList;
       def isCommentExist="";
       if(commentIds!=null && commentIds.size()>0){
           isCommentExist="false";
           def secCommentId=commentIds.get(0);
           message.setProperty("secCommentId",secCommentId);
           commentIds.remove(0);
           if(commentsList!=null && commentsList.size()>0){
              isCommentExist=(commentsList.contains(secCommentId.toString()))?"true":"false";
           }
       }
       message.setProperty("isCommentExist",isCommentExist);
       return message;
}