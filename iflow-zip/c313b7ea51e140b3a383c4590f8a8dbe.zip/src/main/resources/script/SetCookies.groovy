/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
   // message.setHeader("x-csrf-token","ADgiEPCdFc-C0zujA2JRXA==");
    def map = message.getHeaders();
    message.setHeader("Content-Type","application/json");
    message.setHeader("Accept","application/json");
    def cookies=map.get("set-cookie");
    cookies=cookies.join(" ");
    cookies=cookies.replaceAll("path=/","");
    cookies=cookies.replaceAll("secure","");
    cookies=cookies.replaceAll("HttpOnly","");
    cookies=cookies.replaceAll(" ;", ""); 
    message.setHeader("Cookie",cookies);
    def body = message.getBody(java.lang.String) as String;
    message.setProperty("csrf_token",map.get("x-csrf-token"));
    message.setProperty("cookies",cookies);
    message.setProperty("httpMethod","PATCH");
    return message;
}