import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import groovy.json.*
import java.nio.charset.StandardCharsets;
import groovy.xml.XmlUtil;
def Message processData(Message message) {
                
// get a map of iflow properties
// unescape the JSON body    
//    def ebody = message.getBody(String);
//    def body=StringEscapeUtils.unescapeJava(ebody)
//    def map = message.getProperties();
//    def jsonSlurper = new JsonSlurper()
//    def rpn = jsonSlurper.parseText(body as String);
      map = message.getProperties();
        def eRn = map.get("EmployerRegistrationNumber");
//      def eRn = message.getProperties();
    message.setProperty("eRn", eRn);
//    message.setProperty("http.ResponseBody",ex.getMessage());
// get an exception java class instance
    def ex = map.get("CamelExceptionCaught");
    if (ex!=null) {
                                
    // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {

            // save the http error response as a message attachment 
            def messageLog = messageLogFactory.getMessageLog(message);
            messageLog.addAttachmentAsString("http.ResponseBody", ex.getResponseBody(), "text/plain");

            // copy the http error response to an iflow's property
            message.setProperty("http.ResponseBody",ex.getResponseBody());

            // copy the http error response to the message body
            message.setBody(ex.getResponseBody());

            // copy the value of http error code (i.e. 500) to a property
            message.setProperty("http.StatusCode",ex.getStatusCode());

            // copy the value of http error text (i.e. "Internal Server Error") to a property
            message.setProperty("http.StatusText",ex.getStatusText());
                                                
            }
        else     
         {
                map.put("http.StatusCode",900);
                message.setProperty("http.ResponseBody",ex.getMessage());

        }
        def String errorText = ex.getResponseBody();
        if (errorText.contains('certificate'))
        {
            def eRN  = ex.getResponseBody.substring.after(':');

        }
}

                return message;
}