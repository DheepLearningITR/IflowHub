/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;
import java.lang.*;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def responseBody = jsonSlurper.parseText(body);
    def success = responseBody.data.success;
    
    //key is refItemNo, value is entitlementNo list
    Map<String,List<String>> refItemNoMap = new HashMap<>();
    for (def successItem : success) {
        def entitlementNo = successItem.EntitlementNo;
        //construct by SB's lineNumber + "_" + itemValidFrom
        def refItemNo = successItem.RefItemNo;
        if(refItemNoMap.containsKey(refItemNo))
        {
            List<String> existedEntitlementNoList = refItemNoMap.get(refItemNo);
            existedEntitlementNoList.add(entitlementNo);
            refItemNoMap.put(refItemNo, existedEntitlementNoList);
        }
        else
        {
            List<String> entitlementNoList = new ArrayList<>();
            entitlementNoList.add(entitlementNo);
            refItemNoMap.put(refItemNo, entitlementNoList);
        }
    }
    
    //add refItemNoMap key into a list
    List<String> refItemNoMapKeyList = new ArrayList<>();
    for (final def key in refItemNoMap.keySet()) {
        refItemNoMapKeyList.add(key);
    }
    
    //refItemNoMapKeyList sorted by validFrom desc
    for(int i = 1; i < refItemNoMapKeyList.size(); i++){
        int j = i;
        // [10_20231021,10_20231020,10_20231012]
        def tmp = refItemNoMapKeyList[i];
        def formerElement = refItemNoMapKeyList[j -1].split ("_");
        def currentElement = refItemNoMapKeyList[j].split("_");

        def currentElementDate = Date.parse("yyyyMMdd", currentElement[1]);
        def formerElementDate = Date.parse("yyyyMMdd", formerElement[1]);
        while(j > 0 && formerElementDate.before(currentElementDate)){
            def temp = refItemNoMapKeyList[j - 1];
            refItemNoMapKeyList[j - 1] = refItemNoMapKeyList[j];
            refItemNoMapKeyList[j] = temp;
            j--;

            formerElement = refItemNoMapKeyList[j - 1 ].split ("_");
            currentElement = refItemNoMapKeyList[j].split("_");
            currentElementDate = Date.parse("yyyyMMdd", currentElement[1]);
            formerElementDate = Date.parse("yyyyMMdd", formerElement[1]);
        }
        refItemNoMapKeyList[j] = tmp;
    }
    
    //Properties
    message.setProperty("refItemNoMapSize", refItemNoMap.size());
    message.setProperty("refItemNoMap", refItemNoMap);
    message.setProperty("refItemNoMapKeyList", refItemNoMapKeyList);
    return message;
}