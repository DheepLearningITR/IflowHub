/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */


/*
1.example
    refItemNoMapSize	2
    refItemNoMap	{10_20231012=[10738, 10737], 10_20231020=[10741, 10740, 10739]}
    refItemNoMapKeyList	[10_20231012, 10_20231020]
*/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    //to call externalobjectreferences API payload.
    def newPayload = [:];
    
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def properties = message.getProperties();
    def subscriptionBilling = jsonSlurper.parseText(body);
    def refItemNoMapSize = properties.get("refItemNoMapSize");
    //Use refItemNoMapSize to control loop
    refItemNoMapSize = refItemNoMapSize - 1;
    def refItemNoMap = properties.get("refItemNoMap");
    def refItemNoMapKeyList = properties.get("refItemNoMapKeyList");
    //refItemNoMapKey was combined with SB's itemId + '_' + effectiveDate
    def refItemNoMapKey = refItemNoMapKeyList.get(refItemNoMapSize);
    def entitlementNoList = refItemNoMap.get(refItemNoMapKey);
    
    def timeZone = subscriptionBilling.market.timeZone;
    def snapshots = subscriptionBilling.snapshots;
    def externalObjectReferences = [];
    for (def snapshot : snapshots) {
        def items = snapshot.items;
        for (def item : items) {
            def itemValidFrom = getDateFromTimezone(snapshot.effectiveDate, timeZone);
            def itemNumber = item.itemId + "_" + itemValidFrom;

            if (itemNumber == refItemNoMapKey) {
                for (final def entitlementNo in entitlementNoList) {
                    def externalObjectReference = [:];
                    externalObjectReference["externalId"] = entitlementNo;
                    externalObjectReference["externalIdTypeCode"] = "sap.ems.entitlement.id";
                    externalObjectReference["externalSystemId"] = "sapems";
                    externalObjectReferences.add(externalObjectReference);
                }
                newPayload["effectiveDate"] = snapshot.effectiveDate;
                //to call externalobjectreferences API url
                message.setProperty("sb_itemid", item.itemId);
                break;
            }
        }
    }

    newPayload["metaData"] = subscriptionBilling.metaData;
    newPayload["externalObjectReferences"] = externalObjectReferences;
    //use additionalInfo to avoid SB's loop event.
    newPayload["additionalInfo"] = "EMS_ENTITLEMENTID_UPDATE";
    message.setBody(JsonOutput.toJson(newPayload));
    
    message.setProperty("refItemNoMapSize", refItemNoMapSize);
    
    return message;
}

def String getDateFromTimezone(String inputDate, String timeZone) {
    def inputDateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    def outputDateFormat = "yyyyMMdd";
    def outputTZ = TimeZone.getTimeZone(timeZone);

    def date = Date.parse(inputDateFormat, inputDate);
    def convertedDate = date.format(outputDateFormat, outputTZ);
    return convertedDate;
}