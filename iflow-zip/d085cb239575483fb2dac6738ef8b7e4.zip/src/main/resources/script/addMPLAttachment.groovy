import com.sap.gateway.ip.core.customdev.util.Message;

/*def Message addMPLAttachment(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        def body = message.getBody(java.lang.String) as String
        messageLog.addAttachmentAsString("Error Message", body, "text/plain");
    }
    return message;
}*/


def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def map = message.getProperties();
    if(messageLog != null){
        def body = message.getBody(java.lang.String) as String
        messageLog.addAttachmentAsString("Error Message", body, "text/plain");
    }
    //Get exception object
    def ex = map.get("CamelExceptionCaught")
    if (ex!=null) {
        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
            messageLog.addAttachmentAsString("Error Message Response Body", ex.getResponseBody(), "text/plain");
        }
    }
    return message;
}