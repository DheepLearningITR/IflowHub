import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);

    //Body
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def subscription = jsonSlurper.parseText(body);

    def map = message.getProperties();
    def sourceSystem = map.get("SourceSystem");
    def eventType = map.get("event_type");
	def businessEvent = valueMapApi.getMappedValue('SAP Subscription Billing', 'Event Type', eventType, 'SAP Entitlement Management', 'Business Event');

    def entitlement = [:];
    def entitlementBody = [:];
    if (subscription) {
        entitlement['EMS_TimeZone'] = subscription.market.timeZone;
        entitlement['SourceSystem'] = sourceSystem;
        entitlement['CustomerID'] = subscription.customer.id;
        entitlement['DocumentNumber'] = subscription.documentNumber;
        entitlement['DocumentType'] = 'Subscription';
        entitlement['Item'] = [];
        entitlement['Status'] = subscription.status.replaceAll(' ', '_').toUpperCase();
        if (entitlement['Status'] == 'CANCELED') {
            entitlement['Status'] = 'CANCELLED';
        }

        message.setProperty("SubscriptionStatus",entitlement['Status']);

        def snapshots = subscription.snapshots;
        for (def i=0; i<snapshots.size(); i++) 
        {
            def items = snapshots[i].items;
            for (def j=0; j<items.size(); j++) 
            {
                def entitlementItem = [:];
                def item = items[j];
                //update entitlement logic
                def externalObjectReferencesList = item.externalObjectReferences;
                if(externalObjectReferencesList)
                {
                    def emsSaleDocEnt = [];
                    for(def externalObjectReferences : externalObjectReferencesList)
                    {
                        if("EMS".equals(externalObjectReferences['externalIdTypeCode']))
                        {
                            def entitlementNo = [:];
                            entitlementNo['EntNo'] = externalObjectReferences['externalId'];
                            emsSaleDocEnt.add(entitlementNo);
                        }
                    }
                    entitlementItem['EMS_SaleDoc_Ent'] = emsSaleDocEnt;
                }

                entitlementItem['OfferingID'] = item.product.code;
                entitlementItem['UoM'] = 'EA';
                entitlementItem['ItemValidFrom'] = getDateFromTimezone(snapshots[i].effectiveDate, subscription.market.timeZone);
                entitlementItem['ItemNumber'] = item.itemId + "_" + entitlementItem['ItemValidFrom'];
                
                setEntitlementItemValidTo(subscription, entitlementItem, snapshots, i);
                
                if(businessEvent?.trim()) {
                    entitlementItem['BusinessEvent'] = businessEvent;
                } else {
                    entitlementItem['BusinessEvent'] = 'PUR';
                }
                if(item.parentItemId?.trim()) {
                    entitlementItem['ParentItemNumber'] = items.find{ it.itemId == item.parentItemId }.itemId + "_" + entitlementItem['ItemValidFrom'];;
                }
                def subscriptionParameters = item.subscriptionParameters;
                def entitlementAttribute = '';
                for (def k=0; k<subscriptionParameters.size(); k++) {
                    entitlementAttribute = valueMapApi.getMappedValue('SAP Subscription Billing', 'Subscription Parameter', subscriptionParameters[k].code, 'SAP Entitlement Management', 'Interface Field');
                    if (entitlementAttribute != '' && entitlementAttribute != null) {
                        if (!entitlementItem[entitlementAttribute]) {
                            entitlementItem[entitlementAttribute] = subscriptionParameters[k].value;
                        }
                    } else {
                        if (!entitlementItem[subscriptionParameters[k].code]) {
                            entitlementItem[subscriptionParameters[k].code] = subscriptionParameters[k].value;
                        }
                    }
                }
                if (!entitlementItem['Quantity']) {
                    entitlementItem['Quantity'] = '1';
                }
                entitlement['Item'].push(entitlementItem);
            }
        }

        entitlementBody['Inbound_Interface_Entitlement_Generation'] = [:];
        entitlementBody['Inbound_Interface_Entitlement_Generation']['Inbound_Interface_Entitlement_Generation'] = entitlement;
        body = JsonOutput.toJson(entitlementBody);
    } else {
        body = "NotFound";
    }
    message.setBody(body);

    return message;
}

def String getDateFromTimezone(String inputDate, String timeZone) {
    def inputDateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    def outputDateFormat = "yyyyMMdd";
    def outputTZ = TimeZone.getTimeZone(timeZone);

    def date = Date.parse(inputDateFormat, inputDate);
    def convertedDate = date.format(outputDateFormat, outputTZ);
    return convertedDate;
}

def String getLastOneDayFromTimezone(String inputDate, String timeZone) {
    def inputDateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    def outputDateFormat = "yyyyMMdd";
    def outputTZ = TimeZone.getTimeZone(timeZone);
    def date = Date.parse(inputDateFormat, inputDate);

    Calendar calendar = Calendar.getInstance();
    calendar.setTimeZone(outputTZ);
    calendar.setTime(date);
    calendar.add(Calendar.DATE, -1);
    def convertedDate = calendar.format(outputDateFormat);
    
    return convertedDate;
}

def void setEntitlementItemValidTo(def subscription, def entitlementItem, def snapshots, def i) {
    def nextSnapshotIndex = i + 1;
    if (nextSnapshotIndex <= snapshots.size() - 1) {
        entitlementItem['ItemValidTo'] = getLastOneDayFromTimezone(snapshots[nextSnapshotIndex].effectiveDate, subscription.market.timeZone);
    }
    if (nextSnapshotIndex > snapshots.size() - 1) {
        if (subscription.validUntil) {
            entitlementItem['ItemValidTo'] = getDateFromTimezone(subscription.validUntil, subscription.market.timeZone);
        } else {
            entitlementItem['ItemValidTo'] = '99991231';
        }
    }
}
