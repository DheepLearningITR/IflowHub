// =============================================================================================
// This script filters sets the IDocType as well as the CIMTYP if available
// 
// History:
// 2024-10-29 SAP [MÖ] - Initial creation of script
// =============================================================================================

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    Map<String, Object> props = message.getProperties();
    String sapRelease = props.get("SAP_RFC_SAPRelease") as String;
    String APPREL = props.get("SAP_RFC_APPRelease") as String;
    String recMessageType = props.get("SAP_EDI_REC_Message_Type") as String;
    def array = recMessageType.split('\\.').length;
    def cimType ="";
    def idocType ="";
    if (array == 2){
         idocType = recMessageType.split('\\.')[1];
    }
    else {
         idocType = recMessageType.split('\\.')[1];
         cimType = recMessageType.split('\\.')[2];
    }

    message.setProperty("SAP_RFC_IDOCTYP",idocType);
    message.setProperty("SAP_RFC_CIMTYP",cimType);
    
    String SAP_RFC_DataStoreKey = idocType;
    SAP_RFC_DataStoreKey = cimType == "" ? SAP_RFC_DataStoreKey : SAP_RFC_DataStoreKey + "_" + cimType;
    SAP_RFC_DataStoreKey = sapRelease == "" ? SAP_RFC_DataStoreKey : SAP_RFC_DataStoreKey + "_" + sapRelease;
    SAP_RFC_DataStoreKey = APPREL == "" ? SAP_RFC_DataStoreKey : SAP_RFC_DataStoreKey + "_" + APPREL;
    
    message.setProperty("SAP_RFC_DataStoreKey", SAP_RFC_DataStoreKey );
  
    return message;
}