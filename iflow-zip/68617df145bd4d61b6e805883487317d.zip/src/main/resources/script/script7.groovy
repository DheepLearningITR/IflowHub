import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def currentIndex = message.getProperty('CURRENT_INDEX');

    def messageLog = messageLogFactory.getMessageLog(message)
    def enablePayloadLogging = message.getProperty("ENABLE_PAYLOAD_LOGGING");
	if (messageLog != null && "true".equalsIgnoreCase(enablePayloadLogging)) {
		messageLog.addAttachmentAsString('Workflow context #' + currentIndex, body, "application/json")
	}
    
    def jsonSlurper = new JsonSlurper()
    def workflowContext = jsonSlurper.parseText(body)
    
    // Reset properties in case they were set in the previous loop and they are not available in the context of the current workflow
    message.setProperty('DRM_QUERY', '');
    
    if (workflowContext && workflowContext.employment) {
        def ecWorkflowCompletedAt = workflowContext.ecWorkflowCompletedAt
        def personIdExternal = workflowContext.employment.personIdExternal
        def replicationTargetSystem = workflowContext.configuration.replicationTargetSystem
        def replicationContentType = workflowContext.replicationContentType
        
        if (ecWorkflowCompletedAt && personIdExternal) {
            def drmQuery = "personNav/personIdExternal eq '$personIdExternal' and replicationProcessingTime ge '$ecWorkflowCompletedAt'".toString()
            if (replicationTargetSystem != null) {
                drmQuery += " and replicationTargetSystem eq '$replicationTargetSystem'".toString();
            }
            if (replicationContentType == null) {
                replicationContentType = 'EMPLOYEE_MASTER_DATA'
            }
            drmQuery += " and replicationContentType eq '$replicationContentType'".toString();
            message.setProperty('DRM_QUERY', drmQuery);
            
            if (messageLog != null && "true".equalsIgnoreCase(enablePayloadLogging)) {
		        messageLog.addAttachmentAsString('DRM filter query #' + currentIndex, drmQuery, "text/plain")
	        }
        }
    }
    return message;
}