import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);

    def messageLog = messageLogFactory.getMessageLog(message)
    def enablePayloadLogging = message.getProperty("ENABLE_PAYLOAD_LOGGING")
	if (messageLog != null && "true".equalsIgnoreCase(enablePayloadLogging)) {
		messageLog.addAttachmentAsString('Process Automation API response', body, "application/json")
	}
    
    def jsonSlurper = new JsonSlurper()
    def workflows = jsonSlurper.parseText(body)
    
    if (!workflows.isEmpty()) {
        def workflowInstanceIds = [];
        for (workflow in workflows) {
            workflowInstanceIds << workflow.id
        }
        message.setProperty('WORKFLOW_INSTANCE_IDS', JsonOutput.toJson(workflowInstanceIds))
        message.setProperty('EXECUTE_LOOP', 'true')
        message.setProperty('CURRENT_INDEX', 0)
        
        if (messageLog != null && "true".equalsIgnoreCase(enablePayloadLogging)) {
            messageLog.addAttachmentAsString('IDs of suspended workflows', message.getProperty('WORKFLOW_INSTANCE_IDS'), "application/json")
        }
    } else {
        message.setProperty('EXECUTE_LOOP', 'false')
    }
    return message;
}