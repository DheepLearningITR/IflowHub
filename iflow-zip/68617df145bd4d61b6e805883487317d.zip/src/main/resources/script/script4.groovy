import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def drmResponse = new XmlSlurper().parseText(body)
    
    def messageLog = messageLogFactory.getMessageLog(message)
    def enablePayloadLogging = message.getProperty("ENABLE_PAYLOAD_LOGGING");
	if (messageLog != null && "true".equalsIgnoreCase(enablePayloadLogging)) {
	    def currentIndex = message.getProperty('CURRENT_INDEX')
		messageLog.addAttachmentAsString('DRM response #' + currentIndex, body, "application/xml")
	}
    
    // Reset flag in case previous loop entry set this to true
    message.setProperty('REPLICATION_SUCCESSFUL', 'false')
    
	def dataReplicationElementList = drmResponse.EmployeeDataReplicationElement;
	if (!dataReplicationElementList.isEmpty()) {
	    def dataReplicationElement = dataReplicationElementList[0]
        def replicationUpdateStatus = dataReplicationElement.replicationUpdateStatus.text()
	    if (replicationUpdateStatus == 'SUCCESSFUL') {
            message.setProperty('REPLICATION_SUCCESSFUL', 'true')
	    }
	}
    return message;
}