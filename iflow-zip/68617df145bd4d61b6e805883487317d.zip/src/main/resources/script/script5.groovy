import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def currentIndex = message.getProperty('CURRENT_INDEX')
    def workflowInstanceIdsProp = message.getProperty('WORKFLOW_INSTANCE_IDS')
    
    def jsonSlurper = new JsonSlurper()
    def workflowInstanceIds = jsonSlurper.parseText(workflowInstanceIdsProp);
    
    if (currentIndex < workflowInstanceIds.size()) {
        def workflowInstanceId = workflowInstanceIds.get(currentIndex)
        message.setProperty('workflowInstanceId', workflowInstanceId);
        
        currentIndex++
        if (currentIndex == workflowInstanceIds.size()) {
            message.setProperty('EXECUTE_LOOP', 'false')
        }
        message.setProperty('CURRENT_INDEX', currentIndex)
    }
    return message;
}