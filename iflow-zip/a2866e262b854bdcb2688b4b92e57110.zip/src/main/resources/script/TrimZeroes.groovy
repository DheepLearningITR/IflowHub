import com.sap.it.api.mapping.*;



def String customFunc(String str){
    
    def orderId = str.replaceFirst("^0+(?!$)", "")
    
	return str
}