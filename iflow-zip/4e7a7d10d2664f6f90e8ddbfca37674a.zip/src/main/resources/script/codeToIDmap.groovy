import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;


import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {

def body = message.getBody(String.class);
def parsedObj = new JsonSlurper().parseText(body);
def codeToIdJson = [:];
def itr=0;
parsedObj.data.each{
codeToIdJson[parsedObj.data[itr]["itm"]["code"]] = parsedObj.data[itr]["itm"]["id"];
    itr = itr + 1;
};
codeToIdJson = codeToIdJson.toString();
message.setProperty("codeToIdMap",codeToIdJson);
return message;
}