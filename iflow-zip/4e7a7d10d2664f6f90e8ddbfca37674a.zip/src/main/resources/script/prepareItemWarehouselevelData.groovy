/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;


def Message processData(Message message) {
       def body = message.getBody(String.class);
       def parsedObj = new XmlSlurper().parseText(body);
       def map = message.getProperties();
       def codeToIdMapString = map.get("codeToIdMap");
       def warehouse = map.get("wareHouseId");
       def warehouselevelbody = "";
       def root = "";
       def json = new JsonBuilder();
       def itemFound = false;
       def itr = 1;
       String itr_string = "";
       String externalIdString;
       String itemString;
       String warehouseString;
       String inStockString;
       def codeToIdMap = 
    // Take the String value between
    // the [ and ] brackets.
    codeToIdMapString[1..-2]
        // Split on , to get a List.
        .split(', ')
        // Each list item is transformed
        // to a Map entry with key/value.
        .collectEntries { entry -> 
            def pair = entry.split(':')
            [(pair.first()): pair.last()]
        }
       parsedObj.data.each{
        externalIdString = ""; warehouseString = ""; itemString = ""; inStockString = ""; 
        it.externalId = warehouse+"#"+it.item;
        externalIdString = it.externalId.toString();
        it.item = codeToIdMap[it.item.toString()];
        itemString = it.item.toString();
        it.warehouse = warehouse;
        warehouseString = warehouse.toString();
        inStockString = it.inStock.toString();
        def messageLog = messageLogFactory.getMessageLog(message);

        if(itemString != "null"){
            itemFound = true;
           root = json "externalId": externalIdString,"inStock":inStockString,"item":itemString,"warehouse":warehouseString,"ordered":"0.0","committed":"0.0";
           if(warehouselevelbody == ""){
              warehouselevelbody = json.toString(); 
           }else{
               warehouselevelbody = warehouselevelbody+","+json.toString();
           }
        }
        };
        if(!itemFound){
            throw new Exception("No Item found");
        }
        warehouselevelbody = "["+warehouselevelbody+"]";
        message.setBody(warehouselevelbody);
        
        //Initialize structure for parallel calls
        
        message.getProperties().put("1","");
        message.getProperties().put("2","");
        message.getProperties().put("3","");
        message.getProperties().put("4","");
        message.getProperties().put("5","");
          
        
        //Split into 5 groups of 20 and store it in message properties.
        final List<Map> json_split = new JsonSlurper().parseText(warehouselevelbody) as List<Map>;
        json_split.collate(20).each { part ->
        itr_string = itr.toString();
        message.getProperties().put(itr_string,JsonOutput.toJson(part));
        itr = itr + 1;
}
        
        
        
       return message;
}