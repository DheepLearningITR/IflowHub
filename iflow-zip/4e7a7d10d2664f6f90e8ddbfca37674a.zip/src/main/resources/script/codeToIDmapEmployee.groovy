import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;


import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {

def body = message.getBody(String.class);
def parsedObj = new JsonSlurper().parseText(body);
def root = "";
def json = new JsonBuilder();
def codeToIdMapEmp = "";
def itr=0;
def empCode = "";
def empId = "";
parsedObj.data.each{
empCode = parsedObj.data[itr]["up"]["code"].toString();
empId   = parsedObj.data[itr]["up"]["id"].toString();
codeToIdMapEmp = '{"'+ empCode +'":"'+empId+'"}'
itr = itr + 1;
};
if(empCode == ""){
    throw new Exception("Owner not found");  
}
message.setProperty("codeToIdMapEmp",codeToIdMapEmp);
return message;
}