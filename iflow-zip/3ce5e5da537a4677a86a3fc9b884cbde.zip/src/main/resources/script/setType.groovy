import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.pd.PartnerDirectoryService
import groovy.xml.*;

Message setAssignmentType(Message message) {
    def body = message.getBody(String.class);
    def bodyXml = new XmlSlurper().parseText(body);
    def assignmentType = bodyXml.'**'.findAll { node -> node.name() == 'AssignmentType' }*.text();

    if (assignmentType.size() > 0) {
        assignmentType = assignmentType[0].toString();
    } else {
        assignmentType = "";
    }

    message.setProperty('AssignmentType', assignmentType);
    return message;
}



