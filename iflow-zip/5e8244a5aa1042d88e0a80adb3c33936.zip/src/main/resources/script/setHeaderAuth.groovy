import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    
    //Variables in cache
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("token");
    HashMap<String, String> t1CacheData = map.get("t1_token");
    HashMap<String, String> t2CacheData = map.get("t2_token");
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // Set variables
    def t1_auth_value = "Bearer " + t1CacheData.get("t1_token");
    def t2_auth_value = "Bearer " + t2CacheData.get("t2_token");
    
    //Properties
    def properties = message.getProperties();
    
    // To avoid rate limit
    def sleepTime =  properties.get("sleepTime")
    
    if (sleepTime == "YES") {
        Thread.sleep(60000);
    }
    
    // Set variables
    def headerParam = "application/json";
    def auth_value = "Bearer " + cacheData.get("token");
    message.setHeader("accept",headerParam);
    message.setHeader("content-type",headerParam);
    def no_auth_code = "false"
    
    def gat_enabled = properties.get("is_GAT_enabled")
    if (gat_enabled == 'true') {
        def country = properties.get("Country")
        def tenant1 = properties.get("tenantCountryList1")
        def tenant2 = properties.get("tenantCountryList2")
        // def tenant1Xcode = properties.get("tenant1XCode")
        // def tenant2Xcode = properties.get("tenant2XCode")
        // def gatXCode = properties.get("gatXCode")
        
        // def messageLog = messageLogFactory.getMessageLog(message);
        // messageLog.addAttachmentAsString("Check Payload for tenant", tenant1Xcode, "text/plain");
        
        def tenantList1 = tenant1.split(',')
        def tenantList2 = tenant2.split(',')
        
        if (country in tenantList1) {
            message.setHeader("Authorization",t1_auth_value);
        }
        else if (country in tenantList2) {
            message.setHeader("Authorization",t2_auth_value);
        }
        else {
            no_auth_code = "true"
        }
        
    }
    
    
    else {
        message.setHeader("Authorization",auth_value);
    }
    
    
    //Bio field
    SFSFDepartment = properties.get("SFSFDepartment");
    SFSFDivision = properties.get("SFSFDivision");
    SFSFBusinessUnit = properties.get("SFSFBusinessUnit");
    setBioField = properties.get("setBioField");
    defaultLanguage = properties.get("defaultLanguage");
    
    empStatus = properties.get("EmployeeStatus");
    
    if (empStatus in ['A','F','P','U']) {
        message.setProperty("loginStatus", "false")
    }
    else {
        message.setProperty("loginStatus", "true")
    }

    def DegreedBioField = 'Department = ' + SFSFDepartment + ' , Division = ' + SFSFDivision + ' , Business Unit = ' + SFSFBusinessUnit
    
    if (setBioField == 'true') {
        message.setProperty("DegreedBioField", DegreedBioField)
    }
    else {
        message.setProperty("DegreedBioField", "")
    }
    
    //messageLog.addAttachmentAsString("Check language", defaultLanguage, "text/plain");
    
    if (defaultLanguage != null && !defaultLanguage.isEmpty()){
        
        defaultLanguage = defaultLanguage.replace("_", "-")
        
        if (defaultLanguage == 'zh-CN'|| defaultLanguage == 'zh-TW') {
            message.setProperty("language", defaultLanguage.toLowerCase())
        } else {
            message.setProperty("language", defaultLanguage.substring(0, Math.min(2, defaultLanguage.length())));
        }
        
    }
    else {
        message.setProperty("language", "en");
    }
    
    message.setProperty("no_auth_code", no_auth_code)
    return message;
}