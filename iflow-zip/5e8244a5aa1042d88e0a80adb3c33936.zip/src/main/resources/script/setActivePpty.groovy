import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String);
    def parser = new XmlParser();
    def doc = parser.parseText(body);
    def externalId = doc.PerPerson.PerPerson.personIdExternal.text();
    message.setProperty("ExternalId", externalId);
    return message;
}