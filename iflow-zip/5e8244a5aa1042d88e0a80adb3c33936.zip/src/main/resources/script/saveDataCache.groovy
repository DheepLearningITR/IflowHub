import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String);
    def parser = new XmlParser();
    def doc = parser.parseText(body);
    def externalId = doc.data.attributes['employee-id'].text();
    message.setProperty("externalId", externalId);
    
    return message;
}