import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {

    def properties = message.getProperties();
    degreedUserId = properties.get("DegreedId");
    degreedDepartmentCustomAttr = properties.get("SFSFDepartment");
    degreedDivisionCustomAttr = properties.get("SFSFDivision");
    degreedBusinessUnitCustomAttr = properties.get("SFSFBusinessUnit");
    
    payload = [
            "data": [
                "type": "user-custom-attributes",
                "attributes": [
                    "user-id": degreedUserId,
                    "custom-attributes": [
                        "Department": degreedDepartmentCustomAttr,
                        "Division": degreedDivisionCustomAttr,
                        "Business Unit": degreedBusinessUnitCustomAttr
                    ]
                    
                    ]
        ]
    ]

    def json = new groovy.json.JsonBuilder(payload);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString());
    message.setBody(bodyPayload);
    return message;
}
