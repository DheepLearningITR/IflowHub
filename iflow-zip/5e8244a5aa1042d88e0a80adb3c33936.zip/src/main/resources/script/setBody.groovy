import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String);
    def parser = new XmlParser();
    def root = parser.parseText(body);
    def permissionRole = root.data.attributes['permission-role'].text()
    if ( permissionRole == '664298') {
        root.data.attributes['permission-role'].value = 'LearningProfessional';
    } else {
        root.data.attributes['permission-role'].value = 'Admin';
    }

    def xml = XmlUtil.serialize(root);
    message.setBody(xml);
    return message;
}