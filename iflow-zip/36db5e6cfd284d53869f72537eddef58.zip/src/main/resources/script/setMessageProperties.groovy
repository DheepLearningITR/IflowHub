import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Body 
    def inputString = message.getProperty("InputJSONPayload");
    def jsonSlurper = new JsonSlurper()
    def dataObject = jsonSlurper.parseText(inputString);

    def targetDocumentCategoryCode = dataObject.complaintHeader.targetDocumentCategoryCode;   
    message.setProperty("targetDocumentCategoryCode", targetDocumentCategoryCode);
    
    def referenceSONum = dataObject.complaintHeader.referenceSalesOrder;   
    message.setProperty("referenceSalesOrderNo", referenceSONum);

    message.setBody(inputString);
    return message;
}