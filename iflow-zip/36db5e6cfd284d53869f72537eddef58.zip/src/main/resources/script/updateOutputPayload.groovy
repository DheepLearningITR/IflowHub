import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    
    def payload = message.getBody(java.lang.String);
    
    def inputJson= payload.replace("\"\"","null");
    
    def jsonSlurper = new JsonSlurper()
	
	def modifiedInputJson  = jsonSlurper.parseText(inputJson);
	
    def headerFieldsToInt = ['daysBetweenReferenceDocAndComplaintCreation'];
    headerFieldsToInt.each { f -> modifiedInputJson.complaintHeader[f] = 
    modifiedInputJson.complaintHeader[f] != null ? modifiedInputJson.complaintHeader[f].toInteger(): null; }  

    def itemFieldsToInt = ['quantity','price'];
    itemFieldsToInt.each { f -> modifiedInputJson.complaintItems.each { item -> item[f] =
            item[f] != null ? item[f].toFloat(): null;
        }
    } 
    
    message.setBody(JsonOutput.toJson(modifiedInputJson)); 
	
    return message;
}


