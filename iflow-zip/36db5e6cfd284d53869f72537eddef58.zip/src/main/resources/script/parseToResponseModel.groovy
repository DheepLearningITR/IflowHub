import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
     
     // Read Response Body
     def body_json= message.getBody(java.lang.String) as String;
     def jsonSlurper = new JsonSlurper();
	 def resultList = [];
     try{
         def result = jsonSlurper.parseText(body_json);		 
		 resultList.push(result);
		 def resultListJson = JsonOutput.toJson(resultList);
         message.setProperty("result",resultListJson);
         message.setProperty("errorMessage", "");
         message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
     }
     catch(Exception e)
     {
		 def map  = message.getProperties();
         def ex   = map.get("CamelExceptionCaught");
		 if (ex != null)
		 {
            def exceptionText    = ex.getMessage();
            message.setProperty("result", resultList);
            message.setProperty("errorMessage", exceptionText);
            message.setProperty("statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
		 } else {
			message.setProperty("result", resultList);
            message.setProperty("errorMessage", "Exception Occurred");
		 }
     }
     return message;
}