import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
 	def body = message.getBody(java.lang.String);
    def headerDestination = message.getHeaders();
	def destinationValue = headerDestination.get("destination");
    
    message.setProperty("InputJSONPayload",body);
    message.setProperty("destination",destinationValue);
    
    return message;
}