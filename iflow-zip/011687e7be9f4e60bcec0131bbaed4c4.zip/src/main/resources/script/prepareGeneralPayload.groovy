import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {
    def map = message.getProperties();
    String ScoringCategories = map.get('externalSurveyScoringCategory') as String;  
    String originPayload = map.get('originPayload') as String;
    def originData = new JsonSlurper().parseText(originPayload);
    String surveyID = map.get('surveyObjectID') as String;
    def root = "";
    def json = new JsonBuilder();
    def ScoreCatPayload = "";
    def body = message.getBody(String.class);
    // Exisitng Scoring Categories
    def parsedBody2 = new JsonSlurper().parseText(body);
    
    if(ScoringCategories != null){
        // Scoring Categories red from Qualtrics Metadata
        def ScoringCatList = '['+ScoringCategories+']';
        def parsedBody1 = new JsonSlurper().parseText( ScoringCatList )
    
        parsedBody1.each{
            def element = it;
            def foundEntry = parsedBody2.d.results.find{ x -> x.ID == it.ID}; 
            if(foundEntry != null){
                root = json "action":"update","ObjectID":foundEntry.ObjectID,"payload":element;
            }else{
                //ID Does not exist create it 
                root = json "action":"create", "payload":element;
            }
            if (ScoreCatPayload == '') {
                    ScoreCatPayload = json.toString();
            } else {
                    ScoreCatPayload = ScoreCatPayload + "," + json.toString();
            }
        }
        def ScoreCatBody = new JsonSlurper().parseText('{"ScoringCategories":['+ScoreCatPayload+']}');
        def finalBody = new JsonSlurper().parseText('{}');
        finalBody<<["Payload":ScoreCatBody]
        finalBody<<["OriginalPayload":originData]
        JsonBuilder builderA = new JsonBuilder(finalBody);
        String jsonBodyA = JsonOutput.prettyPrint(builderA.toString());
        message.setBody(jsonBodyA);
    }else{
         // No scoring categoies maintained in Qualtrics
            throw new Exception("No Scoring Categories found");
    }
	return message;
}