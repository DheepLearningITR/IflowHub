import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;


def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def parsedObj = new JsonSlurper().parseText(body);
	
	//Creating Origin Payload Exchange Property for Extension
	JsonBuilder builder = new JsonBuilder(parsedObj);
	message.setProperty("originPayload",builder.toString());
	
	parsedObj.each {
	 message.getProperties().put(it.getKey(),it.getValue());
	}
	return message;
}