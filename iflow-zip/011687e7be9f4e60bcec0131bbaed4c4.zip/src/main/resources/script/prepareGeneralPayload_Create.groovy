import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {
    def map = message.getProperties();
    String ScoringCategories = map.get('externalSurveyScoringCategory') as String;  
    String originPayload = map.get('originPayload') as String;
    def originData = new JsonSlurper().parseText(originPayload);
    
    def body = message.getBody(String.class);
    def surveyRoot = new JsonSlurper().parseText(body);
    String SurveyObjectID;
    if(surveyRoot.d.results.ObjectID != null){
        SurveyObjectID = surveyRoot.d.results.ObjectID
        message.setProperty("surveyObjectID",SurveyObjectID);
    }
    
    def root = "";
    def json = new JsonBuilder();
    def ScoreCatPayload = "";
    
    if(ScoringCategories != null){
        
        // Scoring Categories red from Qualtrics Metadata
        def ScoringCatList = '['+ScoringCategories+']';
        def parsedBody = new JsonSlurper().parseText( ScoringCatList )
    
        parsedBody.each{
            it.ParentObjectID = SurveyObjectID
            root = json "action":"create", "payload":it
            
            if (ScoreCatPayload == '') {
                    ScoreCatPayload = json.toString();
            } else {
                    ScoreCatPayload = ScoreCatPayload + "," + json.toString();
            }
        }
        
        def ScoreCatBody = new JsonSlurper().parseText('{"ScoringCategories":['+ScoreCatPayload+']}');
        def finalBody = new JsonSlurper().parseText('{}');
        finalBody<<["Payload":ScoreCatBody]
        finalBody<<["OriginalPayload":originData]
        
        JsonBuilder builderA = new JsonBuilder(finalBody);
        String jsonBodyA = JsonOutput.prettyPrint(builderA.toString());
        message.setBody(jsonBodyA);
        
    }else{
         // No scoring categoies maintained in Qualtrics
            throw new Exception("No Scoring Category found");
    }
	return message;
}