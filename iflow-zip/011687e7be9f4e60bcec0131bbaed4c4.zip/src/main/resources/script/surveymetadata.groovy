/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import java.util.HashMap;


def Message processData(Message message) {

    def body = message.getBody(String.class);
    def messageLog = messageLogFactory.getMessageLog(message);
    body = body.replaceAll("/", "//");
    def parsedObj = new JsonSlurper().parseText(body);
    def trashqs;
    def i = 0;
    def max_score = 0;
    def id = '';
    def root = "";
    def root2 = "";
    def json = new JsonBuilder();
    def json2 = new JsonBuilder();
    def map = message.getProperties();
    def surveyID = map.get("SurveyID");
    surveyID = surveyID.toString();
    def scoringCategory = "";
    boolean defaultScoringCategoryIndicator = false;
    def list = [0];

    //set survey name, default scoring category
    root = json "ID": surveyID, "Name": parsedObj.result.SurveyName,"LastActivatedDatetime":parsedObj.result.LastActivated;
    message.setProperty("LastActivatedDatetimeQualtrics",parsedObj.result.LastActivated.toString());
    message.setProperty("externalSurveyRoot", json.toString());
    message.setProperty("DefaultScoringCategoryFound", "false");

    if (parsedObj.result.Scoring?.DefaultScoringCategory) {
        
    message.setProperty("SurveyName", parsedObj.result.SurveyName);
    message.setProperty("DefaultScoringCategory", parsedObj.result.Scoring.DefaultScoringCategory);

        message.setProperty("DefaultScoringCategoryFound", "true");
        //delete unused question
        parsedObj.result.Blocks.each {
            if (it.getValue().Type == 'Trash') {
                trashqs = it.getValue().BlockElements;
            };
            trashqs.each {
                parsedObj.result.Questions.remove(trashqs.QuestionID[i].toString());
                i = i + 1;

            }
        }

        //Aggregate max score
        if (parsedObj.result.Scoring.ScoringCategories.isEmpty()) {
            throw new Exception("No Scoring Category found");
        } else {
            parsedObj.result.Scoring.ScoringCategories.each {
                id = it.ID.toString();
                id = id.toString();
                name = it.Name.toString();
                max_score = 0;
                if (it.ID == parsedObj.result.Scoring.DefaultScoringCategory) {
                    defaultScoringCategoryIndicator = true;
                }else{
                    defaultScoringCategoryIndicator = false;
                }
                parsedObj.result.Questions.each {
                    mat_q = false;
                    choiceId = 0;
                    answerID = 0;
                     it.getValue().GradingData.each{
                        if(it?.Grades[id]){
                            list.add(it?.Grades[id].toDouble());
                        }
                    };
                        max_score = max_score + list.sort().last().toDouble();
                    list.clear();
                    list =[0]
                }
                max_score_str = max_score.toString();
                message.setProperty("surveyMaxScore", max_score_str);
                root2 = json2 "ID": id,"Name":name, "MaximumScore":max_score_str, "DefaultIndicator": defaultScoringCategoryIndicator;
                if (scoringCategory == '') {
                    scoringCategory = json2.toString();
                } else {
                    scoringCategory = scoringCategory + "," + json2.toString();
                }
            }
            //scoringCategory = "["+scoringCategory+"]";
            message.setProperty("externalSurveyScoringCategory", scoringCategory);

        }
    }
    return message;
}