import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {
    def map = message.getProperties();
    String surveyID = map.get('surveyObjectID') as String;
    
    def body = message.getBody(String.class);
    def parsedObj = new JsonSlurper().parseText(body);
    
    String surveyName = map.get('SurveyName') as String;
    String LastActivatedDatetimeQualtrics = map.get('LastActivatedDatetimeQualtrics') as String;
    
    String batchHeader = "--batch_12345\r\nContent-Type:multipart/mixed; boundary=changeset_12345-001\r\n\r\n\r\n";
    String surveyBodyHeader = "PATCH ExternalSurveyCollection(ObjectID='"+surveyID+"') HTTP/1.1\r\nContent-Type:application/json\r\nAccept:applicationjson\r\n\r\n";
    String surveyBody = "{\r\n"+'"Name"'+":"+'"'+surveyName+'"'+",\r\n"+'"LastActivatedDatetime"'+":"+'"'+LastActivatedDatetimeQualtrics+'"'+"\r\n}\r\n\r\n\r\n";
    String batchBody = "--changeset_12345-001\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\n\r\n";
    String batchFooter = "--changeset_12345-001--" + "\r\n\r\n\r\n" + "--batch_12345--\r\n";

    String finalBody =  batchHeader + batchBody + surveyBodyHeader + surveyBody;
    
    parsedObj.ScoringCategories.each{
        if(it.action == "update"){
            finalBody = finalBody + batchBody + "PATCH ExternalSurveyScoringCategoryCollection(ObjectID='"+ it.ObjectID +"') HTTP/1.1\r\nContent-Type:application/json\r\nAccept:applicationjson\r\n\r\n"
            JsonBuilder builderA = new JsonBuilder(it.payload);
            String jsonBodyA = JsonOutput.prettyPrint(builderA.toString());
            finalBody = finalBody + jsonBodyA + "\n\r\n\r\n" ;
        }else{
            //ID Does not exist create it 
            finalBody = finalBody + batchBody + "POST ExternalSurveyScoringCategoryCollection HTTP/1.1\r\nContent-Type:application/json\r\nAccept:application/json\r\n\r\n"
            it.payload.ParentObjectID = surveyID
            JsonBuilder builderA = new JsonBuilder(it.payload);
            String jsonBodyA = JsonOutput.prettyPrint(builderA.toString());
            finalBody = finalBody + jsonBodyA + "\n\r\n\r\n" ;
            }
        }
    
    finalBody = finalBody + batchFooter;
    message.setBody(finalBody);
	
	return message;
}