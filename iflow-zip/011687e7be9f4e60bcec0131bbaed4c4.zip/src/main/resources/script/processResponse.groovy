/* Hello World in Groovy */
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def root = "";
    def json = new JsonBuilder();
    def root2 = "";
    def json2 = new JsonBuilder();
    String Sc_ID_UUID = "";
    def root3 = "";
    def recpUUID = "";
    def refObjUUID = "";
    def map = message.getProperties();
    def c4cSurveyID = map.get("surveyObjectUUID");
    def surveyMaxScore = map.get('surveyMaxScore');
    def body = message.getBody(String.class);;
    def parsedObj = new XmlSlurper().parseText(body);
    
    def finalObj = new JsonSlurper().parseText('{}');
    
    def recepientUUID = "";
    def ObjectType = "";
    def ObjectUUID = "";

    
    //check if survey c4c survey ID is present

    parsedObj.results.each {
        id = it.ID.toString();
        id = id.toString();
        uuid = it.UUID.toString();
        uuid = uuid.toString();
        max_score = it.MaximumScore.toString();
        root = json "ID": id, "CAT_UUID": uuid, "MAX_SCORE": max_score;
        if (Sc_ID_UUID == '') {
            Sc_ID_UUID = json.toString();
        } else {
            Sc_ID_UUID = Sc_ID_UUID + "," + json.toString();
        }
    };
    
      def responseBody = map.get("responseBody");
      def parsedObj2 = new JsonSlurper().parseText(responseBody);
      
    
    if(parsedObj2.result.values.C4CObject){
        //Decode embedded responde data
        def encodedEmbedData = parsedObj2.result.values.C4CObject;
        Byte[] decodedEmbedData = encodedEmbedData.decodeBase64();
    
        def Decoded = new String(decodedEmbedData);
    
    
        def values = Decoded.split('&');
    
        values.each{
            C4CData = it.split('=');
            if(C4CData.size() == 2){
                if(C4CData[0] == 'OBJECT_UUID'){
                    ObjectUUID =  C4CData[1].substring(0, 8) + "-" + C4CData[1].substring(8, 12) + "-" + C4CData[1].substring(12, 16) + "-" + C4CData[1].substring(16, 20) + "-" + C4CData[1].substring(20, 32);
                }else if(C4CData[0] == 'RECIPIENT_UUID'){
                    recepientUUID = C4CData[1].substring(0, 8) + "-" + C4CData[1].substring(8, 12) + "-" + C4CData[1].substring(12, 16) + "-" + C4CData[1].substring(16, 20) + "-" + C4CData[1].substring(20, 32);
                }else{
                    ObjectType = C4CData[1];
                }
            }
        }
    }
    
    Sc_ID_UUID = "[" + Sc_ID_UUID + "]";
    def parsedobj3 = new JsonSlurper().parseText(Sc_ID_UUID);
    def itr = 0;
    def score = '';
    def total_score = '';
    parsedobj3.each {
        total_score = parsedObj2.result.values[parsedobj3[itr]["ID"]];
        if(total_score != null){
            total_score = total_score.toString();
            cat_uuid = parsedobj3[itr]["CAT_UUID"].toString();
            maxScore = parsedobj3[itr]["MAX_SCORE"].toString();
            root2 = json2 "TotalScore": total_score, "CategoryUUID": cat_uuid, "ResponseTimeSurveyMaxScore": maxScore;
            if (score == '') {
                score = json2.toString();
            } else {
                score = score + "," + json2.toString();
            }
        }    
        itr = itr + 1;
    };
    score = score.toString();
    json3 = new JsonBuilder();
    def root4 = "";
    score = "[" + score + "]";
    def parsedObj5 = new JsonSlurper().parseText(score);

    def responseID = map.get("ResponseID");
    def pat = "yyyy-MM-dd'T'hh:mm:ss.SSS'Z'";
    def recordedDate = Date.parse(pat, parsedObj2.result.values["recordedDate"]);
    
    // create final json
    
        finalObj <<[ID:responseID];
        if(recepientUUID != ""){
            finalObj <<[RecipientUUID:recepientUUID];
        }
        if(ObjectType != ""){
            finalObj <<[ReferenceMetaObjectName:ObjectType];
        }
        if(ObjectUUID != ""){
            finalObj <<[ReferenceObjectUUID:ObjectUUID];
        }
        finalObj <<[ExternalSurveyScore:parsedObj5];
        
        JsonBuilder builder = new JsonBuilder(finalObj);
        String finalResponse = JsonOutput.prettyPrint(builder.toString());
    
        message.setProperty("ticketSurveyResponse", finalResponse);
        message.setBody(finalResponse);


    return message;
}