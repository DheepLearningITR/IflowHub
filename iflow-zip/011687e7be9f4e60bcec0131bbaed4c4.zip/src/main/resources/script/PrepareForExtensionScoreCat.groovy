import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;


def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	message.setProperty("BatchPayload",body);
	def root = "";
	def json = new JsonBuilder();
	def map = message.getProperties();
	String originBody = map.get('originPayload') as String;
	def originPayload = new JsonSlurper().parseText(originBody);
	
    root = json "Payload":body,"OriginPayload":originPayload;
    
//     def finalObj = new JsonSlurper().parseText('{}');
// 	JsonBuilder builder = new JsonBuilder(finalObj);
	message.setProperty("BatchPayload2",root);
    // String jsonBody = JsonOutput.prettyPrint(builder.toString());
    message.setBody(root);
    
	return message;
}