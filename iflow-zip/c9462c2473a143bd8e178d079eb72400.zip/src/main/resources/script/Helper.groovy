import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import java.time.Instant
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.exception.SecureStoreException
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {

  // get a map of properties
  def map = message.getProperties();

  // get an exception java class instance
  def ex = map.get("CamelExceptionCaught");
  if (ex != null) {
      // copy the http error response to the message body
      message.setBody(ex.getResponseBody());
  }

  return message;
}

def Message readExceptionMessage(Message message){
    def body = message.getBody(java.io.Reader)
     
        def map = message.getProperties();
        def exception = map.get("CamelExceptionCaught")
        if (exception!=null)
        {
            def errorMessage = exception.getCause().getCause().getMessage();
            message.setBody(errorMessage)
        }
    
    return message
}

def Message readQuoteOwnerInfo(Message message){
    // Parse the JSON
    def json = message.getBody(java.io.Reader)
    def jsonObject = new JsonSlurper().parse(json)
    
    //messageHeader
    message.setHeader("SAP_ApplicationID", jsonObject.displayId)
    
    // Access the value of ownerId and userName
    def ownerId = jsonObject.ownerId
    def username = jsonObject.userName
    
    message.setProperty("ownerId",ownerId)
    message.setProperty("userName", username);
    
    return message

}

def Message readUserName(Message message){
    // Parse the JSON
    def json = message.getBody(java.io.Reader)
    def jsonObject = new JsonSlurper().parse(json)
    
    // Check the count value
    if (jsonObject.count != 1) {
        throw new IllegalArgumentException("User for owner not found")
    }

    // Extract the userName
    def cnsQuoteOwner = jsonObject.value[0]?.userName
  
    // set the CPQ Quote Owner based on value mapping
    if (cnsQuoteOwner) {
        def valueMapApi = ITApiFactory.getService(ValueMappingApi.class, null)
        def cpqQuoteOwner = valueMapApi.getMappedValue('CNS', 'OpportunityOwnerUserName', cnsQuoteOwner, 'CPQ', 'QuoteOwnerUserName')
        if (cpqQuoteOwner){
            message.setProperty("userName",cpqQuoteOwner)
            message.setProperty("valueMappingFound","true")
        }
        else{
            message.setProperty("userName",cnsQuoteOwner)
            message.setProperty("valueMappingFound","false")
        }
        
    } else {
        throw new IllegalArgumentException("userName for owner not found")
    }
    
    return message

}

def Message setBearerToken(Message message) {

  def sharedKey = ""

  // Define your shared key (HMAC secret)
  def apikey_alias = message.getProperty("P_SharedSecretAlias")
  def secureStorageService = ITApiFactory.getService(SecureStoreService.class, null)

  try {
    def secureParameter = secureStorageService.getUserCredential(apikey_alias)
    sharedKey = secureParameter.getPassword().toString()
    message.setProperty("sharedKey", sharedKey)
  } catch (Exception e) {
    throw new SecureStoreException("Secure Parameter not available")
  }

  String username = message.getProperty("userName");
  // Get the current time for `iat` and calculate expiration time for `exp`
  Instant now = Instant.now();
  Date issuedAt = Date.from(now);
  Date expiresAt = Date.from(now.plusSeconds(120)); // 2 minutes from now

  // Create the JWT algorithm (HS256)
  Algorithm algorithm = Algorithm.HMAC256(sharedKey);
  // Build the JWT token using payload and algorithm
  String token = JWT.create()
    .withClaim("username", username)
    .withClaim("iat", issuedAt.getTime() / 1000) // Seconds since epoch
    .withClaim("exp", expiresAt.getTime() / 1000) // Seconds since epoch
    .sign(algorithm)

  String bearerToken = "Bearer " + token
  message.setHeader("Authorization", bearerToken)
  message.setHeader("Content-Type", "application/json")
  return message
  
}
