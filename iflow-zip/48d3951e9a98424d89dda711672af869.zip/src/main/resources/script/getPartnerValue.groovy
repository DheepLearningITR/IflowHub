import com.sap.it.api.mapping.*;

def String getBillToPartner(String partnerFunctionField, String value, MappingContext context)
{
	def parterFunction= context.getProperty("BillToPartnerFunction") ? context.getProperty("BillToPartnerFunction") : 'BP';

    if(partnerFunctionField != null && 
	partnerFunctionField.trim().length() > 0 && 
	value != null && 
	value.trim().length() > 0 &&
	partnerFunctionField == parterFunction){
		
		return value;
		   
    }
 	
	return "";
}

def String getOtherToPartner(String partnerFunctionField, String value, MappingContext context)
{
	def parterFunction = context.getProperty("OtherToPartnerFunction") ? context.getProperty("OtherToPartnerFunction") : 'SH';
	
    if(partnerFunctionField != null && 
	partnerFunctionField.trim().length() > 0 && 
	value != null && 
	value.trim().length() > 0 &&
	partnerFunctionField == parterFunction){
		
		return value;
		   
    }
 	
	return "";
}

def String getShipToPartner(String partnerFunctionField, String value, MappingContext context)
{
	def parterFunction= context.getProperty("ShipToPartnerFunction") ? context.getProperty("ShipToPartnerFunction") : 'SP';

    if(partnerFunctionField != null && 
	partnerFunctionField.trim().length() > 0 && 
	value != null && 
	value.trim().length() > 0 &&
	partnerFunctionField == parterFunction){
		
		return value;
		   
    }
 	
	return "";
}

def String getAssigneePartner(String partnerFunctionField, String value, MappingContext context)
{
	def parterFunction= context.getProperty("AssigneePartnerFunction") ? context.getProperty("AssigneePartnerFunction") : 'SE';

    if(partnerFunctionField != null && 
	partnerFunctionField.trim().length() > 0 && 
	value != null && 
	value.trim().length() > 0 &&
	partnerFunctionField == parterFunction){
		
		return value;
		   
    }
 	
	return "";
}
