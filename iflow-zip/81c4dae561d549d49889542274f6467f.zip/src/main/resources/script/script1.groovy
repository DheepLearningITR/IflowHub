import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
 
    
    def body = message.getBody(java.lang.String) as String;
    body = body.replaceAll("<ns1:Envelope xmlns:ns1=", "");
    body = body.replaceAll("\"http://schemas.xmlsoap.org/soap/envelope/\">", "");
    //body = body.removeSurrounding("\"");
    body = body.replaceAll("<ns1:Body>", "");
	body = body.replaceAll("</ns1:Body>", "");
	body = body.replaceAll("</ns1:Envelope>", "");
	message.setBody(body);
	return message;
}