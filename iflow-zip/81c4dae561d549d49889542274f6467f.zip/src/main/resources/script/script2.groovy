import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
 
    
    def body = message.getBody(java.lang.String) as String;
    body = body.replaceAll("<\\?xml version=","<\\?xml version='1.0' encoding='UTF-8'\\?>");
    body = body.replaceAll("\"1.0\" encoding=\"UTF-8\" standalone=\"no\"\\?>","<SOAP:Envelope xmlns:SOAP='http://schemas.xmlsoap.org/soap/envelope/'><SOAP:Header/><SOAP:Body>");
    body = body.replace("rfc", "ns0");
    body = body.replace("\"urn:sap-com:document:sap:ns0:functions\"", "'urn:sap-com:document:sap:rfc:functions'");
    body = body.replace(".Response>", ".Response></SOAP:Body></SOAP:Envelope>");
	message.setBody(body);
	return message;
}