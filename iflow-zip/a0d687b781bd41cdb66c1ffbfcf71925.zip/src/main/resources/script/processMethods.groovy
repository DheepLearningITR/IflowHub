
import com.sap.gateway.ip.core.customdev.util.Message;

import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

def Message validateInput(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    
    //headers
    def headers = message.getHeaders();
    def toDateTime = headers.get("toDateTime");
    def fromDateTime = headers.get("fromDateTime");
    
    //Properties
    def properties = message.getProperties();
    def initialRunDateTime = properties.get("initialRunDateTime")
    def scheduledRerun = properties.get("scheduledRerun") ?: "false"

    //filter variables
    def varFromDateTime = "updatedDateFrom"
    def varToDateTime = "updatedDateTo"
    def filter = '{'
    
    //dateTime variables
    def dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'"
    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(dateFormat)
    LocalDateTime ldtObj
    
    //others
    def errorFlag = false
    def proceed = true
    def initializeLastRunDateTime = false
    def rerunScheduled = false
    def adhoc = false
    def runMode = ""
    
    //Check if initialize mode
    if(initialRunDateTime != ""){
        runMode = "Set Initialize LastRunDateTime"
        initializeLastRunDateTime = true
        try{
            ldtObj = LocalDateTime.parse(initialRunDateTime, dateFormatter)
            initialRunDateTime = dateFormatter.format(ldtObj)
            
            message.setHeader("initialRunDateTime", initialRunDateTime)
            messageLog.addCustomHeaderProperty("Initial Last Run DateTime", initialRunDateTime.toString());
        }
        catch(Exception e){
            message.setProperty("errorMsg", "Error during date conversion. Required format: yyyy-MM-dd'T'HH:mm:ss'Z")
            messageLog.addCustomHeaderProperty("errorMsg","Error during date conversion. Required format: yyyy-MM-dd'T'HH:mm:ss'Z");
            errorFlag = true
            proceed = false
        }
    }
    
    //Check if rerunScheduled
    if(scheduledRerun != "" && scheduledRerun.toLowerCase() == "true"){
        rerunScheduled = true
        runMode = "Rerun Scheduled Interface"
    }
    
    //Adhoc - convert dates
    try{
        if(toDateTime != "" && fromDateTime != ""){
            adhoc = true
            runMode = "Ad Hoc"
            
            ldtObj = LocalDateTime.parse(toDateTime, dateFormatter)
            toDateTime = dateFormatter.format(ldtObj)
            ldtObj = LocalDateTime.parse(fromDateTime, dateFormatter)
            fromDateTime = dateFormatter.format(ldtObj)
            
            filter = filter + '"' + varFromDateTime + '":"' + fromDateTime + '","' + varToDateTime + '":"' + toDateTime + '"'
            
            messageLog.addCustomHeaderProperty("From DateTime", fromDateTime);
            messageLog.addCustomHeaderProperty("To DateTime", toDateTime);
            message.setHeader("fromDateTime", fromDateTime)
            message.setHeader("toDateTime", toDateTime)
        }
    }
    catch(Exception e){
        message.setProperty("errorMsg", "Error during date conversion. Required format: yyyy-MM-dd'T'HH:mm:ss'Z'")
        messageLog.addCustomHeaderProperty("errorMsg","Error during date conversion. Required format: yyyy-MM-dd'T'HH:mm:ss'Z'");
        errorFlag = true
        proceed = false
    }
    
    //check if at least minimum mandatory information is provided
    if(errorFlag == false && initializeLastRunDateTime == false && rerunScheduled == false && adhoc == false){
        message.setProperty("errorMsg","Please populate minimum fields required: [fromDate and toDate] or set mode [Initialize RunDateTime or Adhoc run as Schedule]")
        messageLog.addCustomHeaderProperty("errorMsg","Please populate minimum fields required: [fromDate and toDate] or set mode [Initialize RunDateTime or Adhoc run as Schedule]");
        proceed = false
    }
    
    //check if multiple modes selected
    String[] modeList = [initializeLastRunDateTime,rerunScheduled,adhoc]
    String[] mode = modeList.minus("false")
    if(mode.size() > 1){
        //more than 1 flag is true
        message.setProperty("errorMsg","Please select 1 mode only [Initialize RunDateTime or Adhoc run as Schedule or Adhoc run]")
        messageLog.addCustomHeaderProperty("errorMsg","Please select 1 mode only [Initialize RunDateTime or Adhoc run as Schedule or Adhoc run]");
        proceed = false
    }
    
    //set filter
    filter = filter + '}'
    message.setHeader("filter",filter)
    //set run mode
    message.setHeader("runMode",runMode)
    messageLog.addCustomHeaderProperty("Run mode", runMode);
    
    message.setHeader("initializeLastRunDateTime",initializeLastRunDateTime)
    message.setHeader("rerunScheduled",rerunScheduled)
    //set action
    message.setProperty("proceed",proceed)
    
    return message;
}