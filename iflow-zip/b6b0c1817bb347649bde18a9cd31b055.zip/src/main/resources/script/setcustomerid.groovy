import com.sap.it.api.mapping.*;



def String customFunc1(String p1,String p2,MappingContext context) {
         
         String value2 = context.getProperty(p1) as String;
         return value2;
}