import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.pd.PartnerDirectoryService
import groovy.transform.Field
import groovy.util.slurpersupport.GPathResult
import org.codehaus.groovy.runtime.InvokerHelper
import org.slf4j.Logger
import org.slf4j.LoggerFactory

@Field String LOG_ID = 'PLANT_VALUE_MAPPING';
@Field static final String HEADER_VM_MODE = "VM_MODE";
@Field static final String VM_MODE_REQUEST = "REQUEST";
@Field static final String PROPERTY_ENDPOINT_ID = "ENDPOINT_ID";
@Field static final String PD_PARAMETER_ENABLE_PLANT_CONVERSION = "ENABLE_PLANT_CONVERSION";
@Field static final String PARTNER_ID_PREFIX = "DME_Generic_Processing_";
@Field static final String VM_AGENCY_EWM = "EWM";                                //Agency of EWM
@Field static final String VM_IDENTIFIER_EWM_PLANT = "PLANT";                    //Identifier of EWM
@Field static final String VM_AGENCY_DMC = "DMC";                                //Agency of DMC
@Field static final String VM_IDENTIFIER_DMC_PLANTS = "PLANT";                   //Identifier of DMC
@Field static final String[] EWM_PAYLOAD_FIELDS = ['Plant'];                     //Names of EWM fields which require value mapping
@Field static final String[] SOAP_LOGICAL_SYS_FIELDS = ['ERPLogicalSystem'];
@Field Logger log = LoggerFactory.getLogger("com.sap.cpi.metviewer." + LOG_ID);

// Inbound source system EWM, target system DMC

Message processData(Message message) {

    String endpointId = message.getProperty(PROPERTY_ENDPOINT_ID);
    String partnerId = PARTNER_ID_PREFIX + endpointId;

    PartnerDirectoryService pd = ITApiFactory.getService(PartnerDirectoryService.class, null);
    if (pd == null) {
        throw new IllegalStateException("Partner Directory Service not found");
    }
    boolean enablePlantConversion = toBoolean(pd.getParameter(PD_PARAMETER_ENABLE_PLANT_CONVERSION, partnerId, String.class));
    if (enablePlantConversion) {
        executePlantConversion(message);
    }

    return message;
}

private void executePlantConversion(Message message) {

    String vmSourceAgency;
    String vmSourceIdentifier;
    String vmTargetAgency;
    String vmTargetIdentifier;
    String[] fields;
    String prefix;

    ValueMappingApi vm = ITApiFactory.getService(ValueMappingApi.class, null);
    Reader payload = message.getBody(Reader);
    GPathResult root = new XmlSlurper().parse(payload);

    String mode = message.getHeaders().get(HEADER_VM_MODE);

    if (mode == VM_MODE_REQUEST) {
        vmSourceAgency = VM_AGENCY_EWM;
        vmSourceIdentifier = VM_IDENTIFIER_EWM_PLANT;
        vmTargetAgency = VM_AGENCY_DMC;
        vmTargetIdentifier = VM_IDENTIFIER_DMC_PLANTS;
        fields = EWM_PAYLOAD_FIELDS;

        SOAP_LOGICAL_SYS_FIELDS.each { String tag ->
            List<GPathResult> searchResult = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase(tag) && it.children().size() == 0 && it.text() != null && it.text() != ""; }
            if (!searchResult.isEmpty()) {
                prefix = searchResult[0];
            }
        }
    } else {
        vmSourceAgency = VM_AGENCY_DMC;
        vmSourceIdentifier = VM_IDENTIFIER_DMC_PLANTS;
        vmTargetAgency = VM_AGENCY_EWM;
        vmTargetIdentifier = VM_IDENTIFIER_EWM_PLANT;
        fields = EWM_PAYLOAD_FIELDS;
    }

    fields.each { String tag ->
        List<GPathResult> searchResult = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase(tag) && it.children().size() == 0; }
        if (!searchResult.isEmpty()) {
            searchResult.each { GPathResult it ->
                String plantSourceValue = it.text();

                String plantTargetValue = vm.getMappedValue(vmSourceAgency, vmSourceIdentifier, prefix + ":" + plantSourceValue, vmTargetAgency, vmTargetIdentifier);
                if (plantTargetValue) {
                    try {
                        plantTargetValue = plantTargetValue.split(":")[1];
                    } catch (ArrayIndexOutOfBoundsException ex) {
                        // log.error("Can't split the plant value ", plantTargetValue);
                    }
                } else {
                    plantTargetValue = vm.getMappedValue(vmSourceAgency, vmSourceIdentifier, plantSourceValue, vmTargetAgency, vmTargetIdentifier);
                }

                if (plantTargetValue) {
                    it.replaceBody(plantTargetValue);
                }
            }
        }
    }

    message.setBody(serialize(root));
}

private static boolean toBoolean(String value) {

    if (value != null) {
        if ("TRUE".equalsIgnoreCase(value)) {
            return true;
        }
    }
    return false;
}

private static String serialize(Object node) {
    try {
        Object builder = Class.forName("groovy.xml.StreamingMarkupBuilder").getDeclaredConstructor().newInstance();
        InvokerHelper.setProperty(builder, "encoding", "UTF-8");
        Writable w = (Writable) InvokerHelper.invokeMethod(builder, "bindNode", node);
        return w.toString();
    } catch (Exception e) {
        return "Couldn't convert node to string because: " + e.getMessage();
    }
}