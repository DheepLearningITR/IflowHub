import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message; 



/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/
// Get IDOC Control Record information
def String getSenderPort(String P1, MappingContext context){
	return context.getProperty("p_SNDPOR");
}

def String getSenderPartnerNumber(String P1, MappingContext context){
	return context.getProperty("p_SNDPRN");
}

def String getRecipientPort(String P1, MappingContext context){
	return context.getProperty("p_RCVPOR");
}

def String getRecipientPartnerNumber(String P1, MappingContext context){
	return context.getProperty("p_RCVPRN");
}

def String getERPBusinessSystemID(String P1, MappingContext context){
	return context.getProperty("ERPBusinessSystemID");
}

def String getDivision(String P1, MappingContext context){
	return context.getProperty("p_Division");
}

def String getDistributionChannel(String P1, MappingContext context){
    if (P1.length()>0)
        return P1;
    else
	    return context.getProperty("p_DistributionChannel");
}

def String getOrderStatusId(String P1, MappingContext context){
	return context.getProperty("OrderStatusId");
}

def void getCustomFieldValue(String[] var1,String[] var2, String[] var3, Output output, MappingContext context){
    /*
    <CustomField>
      <Content><![CDATA[AN CPQ Quote 180929 16:11]]></Content>
      <Id>6</Id>
      <Name><![CDATA[PO Number]]></Name>
    </CustomField>
    var2 is PO Number <Name>
    var3 is AN CPQ Quote 180929 16:11 <Content>
    */
    for (int i=0;i<var1.length;i++)
	{ 
		if (var1[i].equals(var2[0]))
		{ 
				output.addValue(var3[i]);
			
	    }
    }
}
def void checkHeaderDiscount(String[] var1, Output output, MappingContext context){
    for (int i=0;i<var1.length;i++){
	double d = 0.0;
	try{
		d = Double.parseDouble(var1[i]);
	    
	}
	catch (Exception ex){
		d = 0.0;
	}
	if (d > 0.0)
		output.addValue(var1[i]); 
}
}

def void getPartnerReceipientId(String[] var1,String[] var2, String[] var3, Output output, MappingContext context){
    

    for (int i=0;i<var1.length;i++)
	{ 
		if (var1[i].equals(var2[0]))
		{ 
				output.addValue(var3[i]);
			
	    }
    }
}

def String formatUUID(String uuid, MappingContext context){
 String out = "";
 if (uuid != null && !uuid.equals(""))
{
	out = (uuid.substring(0,8)+"-"+uuid.substring(8, 12)+"-"+uuid.substring(12,16)+"-"+uuid.substring(16,20)+"-"+uuid.substring(20));
 }
return out;
}

def String getMessageID(String var1, MappingContext context){
    String MsgID = context.getProperty(SAP_MessageProcessingLogID);
    
    return MsgID;
}


def String generateMessageID(String arg1, MappingContext context){	
	String messageID = java.util.UUID.randomUUID().toString()
	context.setHeader("SapMessageId", messageID.toUpperCase().replaceAll("-",""))
	context.setHeader("SapMessageIdEx", messageID)	
	return messageID.toUpperCase().replaceAll("-","") 
} 
 
def void createItemNumber(String[] itemno,String[] parentItemno, Output erp_item_no, Output erp_parent_item_no, MappingContext context){

        List<String> erp_item_num = new ArrayList<>();
        int initalItemNo = 0;
		int subItemIncrement = 1;
		int maxsubItemCount = 0;
		int subItemCount = 0;
	
	 	for (int i = 0; i < itemno.length; i++) {
	 	    try {
		    	int ItemNumID =  Integer.parseInt(itemno[i]);
		    	if ( subItemCount > maxsubItemCount  ) {
		    	        maxsubItemCount = subItemCount; // reset 
		    	}
		    	    subItemCount = 0; // reset
	 	    }	
	 	    catch (NumberFormatException ex) {
	 	        subItemCount++;   
	 	    }
		}
	
		int C4CItemMultiple = 10; // for backward compatibility with old logic  
		if ( maxsubItemCount > 9 ) {
		    // This logic dynamically determines the C4C item numbering logic 
		    //e.g. if max sub item in CPQ quote is 9 then C4C item numbering will be parent item [10]-->11,12.. so on;[20],21.....;[30].....
		    //     if max sub item in CPQ quote is greater then 9 and less than 100 then C4C item numbering will be parent item
		    //     [100]-->101,102.. so on;[200],201.....;[300].....
		    //     similarly for higher level items id's  
		    double a = Math.ceil((Math.log10(maxsubItemCount)) + 0.001) ;
            C4CItemMultiple = (int)Math.pow(10,a);
		}
		
		
		// Generate ITM_NUMBER
		for (int i = 0; i < itemno.length; i++) {
			try {
				initalItemNo = Integer.parseInt(itemno[i]) * C4CItemMultiple;
				erp_item_no.addValue(String.valueOf(initalItemNo));
				erp_item_num.add(String.valueOf(initalItemNo));
				subItemIncrement = 1;

			} catch (NumberFormatException ex) {
			    String ChildItemNumber = String.valueOf(initalItemNo + subItemIncrement);
				erp_item_no.addValue(ChildItemNumber);
				erp_item_num.add(ChildItemNumber);
				subItemIncrement++;
			}
		}
		
		// Generate HG_LV_ITEM
		for (int i = 0; i < parentItemno.length; i++) {
			if (parentItemno[i].length() == 0)
				erp_parent_item_no.addValue("");
			else
				for (int j = 0; j < itemno.length; j++) {
					if (parentItemno[i].equals(itemno[j])) {
						erp_parent_item_no.addValue(erp_item_num.get(j));
						break;
					}
				}
		}
}



