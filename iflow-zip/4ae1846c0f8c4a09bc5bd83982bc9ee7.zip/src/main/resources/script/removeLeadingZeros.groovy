import com.sap.it.api.mapping.*;
import com.sap.aii.mapping.lookup.*;
import com.sap.aii.mappingtool.tf7.rt.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String removeLeadingZeros(String input){
    // This function will remove all leading zeros if the input string is non-alphaneumeric 
    String str = input;
    char str1;
    boolean b1 = false;
    int len = str.length();
    for(int i=0;i<len;i++){
      str1 = str.charAt(i);
      b1 = Character.isLetter(str1);
      if (b1 == true)
        break;
      else
        continue; 
     }
    if (b1 == true)
      return (input); //return if it is alphanumeric
    else
      return input.replaceAll("^0+",""); //return if it is non-alphanumeric
}