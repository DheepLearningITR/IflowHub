/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;

import java.util.HashMap;
import java.io.*;
import java.nio.*;
import java.util.*;

import groovy.util.*;
import groovy.xml.*;
import groovy.json.*;

import org.apache.camel.CamelContext;
import org.apache.commons.io.IOUtils;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType
import org.apache.http.conn.params.ConnRoutePNames;


def Message processTokenResponse(Message message) {
    
    def body = message.getBody(String.class);    
    def jsonSlurper = new JsonSlurper()
    def responsePayload = jsonSlurper.parseText(body)
    def token = responsePayload.access_token;
    def tokenWithType = "Bearer " + token;
    message.setProperty("Authorization", tokenWithType);
     return message;
}

def Message callDARService(Message message) {
    def sURL = message.getProperty("DAR_Base_URL") + "/data-manager/api/v3/datasetSchemas";
    
    def payload = message.getBody(String.class);

    	//build URL
    HttpPost request = new HttpPost(sURL);
    
        def StringEntity entity = new StringEntity(payload,ContentType.APPLICATION_JSON)
    request.setEntity(entity);

    //set token    
    String DOCXOAuthToken = message.getProperties().get('Authorization');
    request.setHeader("Authorization", DOCXOAuthToken);
    request.setHeader("Content-Type", "application/json");

    
    //execute request
    HttpClient client = new DefaultHttpClient();
    HttpResponse response = client.execute(request);
    // Get the response
    BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
    StringBuffer sb = new StringBuffer();
    String line = "";
    while ((line = rd.readLine()) != null) {
            sb.append(line);
    }

    message.setBody(sb.toString());
    return message;
}
