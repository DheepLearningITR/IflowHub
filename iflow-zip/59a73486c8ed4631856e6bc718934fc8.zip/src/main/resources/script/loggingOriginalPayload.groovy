import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	map = message.getProperties();
	property_ENABLE_PAYLOAD_LOGGING = map.get("ENABLE_PAYLOAD_LOGGING");
	idocNumber = map.get("IDOC_NUMBER");
	if (property_ENABLE_PAYLOAD_LOGGING.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String) as String;
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString("IDOC:" + idocNumber, body, "text/plain");
		}
	}
	return message;
}