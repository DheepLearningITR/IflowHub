import com.sap.it.api.mapping.*;
def String Matcode_Validation(String input){
//if (input.matches(".*\\d.*")){
// def zeros = "000000000000000000";
// input = zeros+input;
// input = input.substring(input.size()-18,input.size());
// return input;
// }
// else{
// return input;
// }

    if(input.isNumber()){
        // input.padLeft(18,'0');
      input = ("000000000000000000" + input).substring(input.length())
 }
    return input;
}