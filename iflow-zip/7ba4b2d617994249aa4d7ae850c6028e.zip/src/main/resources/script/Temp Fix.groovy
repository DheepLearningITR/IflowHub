import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.String;
import groovy.xml.*;
import groovy.util.*;

def Message processData(Message message) {

	def map = message.getProperties();

	String content = message.getBody(java.lang.String) as String;
	def rootNode = new XmlSlurper().parseText(content);
	
    def invoiceCode = rootNode.Invoice.response.invoiceCode;
    if (invoiceCode.isEmpty()) {
    	def invoiceCodeObj = new XmlSlurper().parseText("<invoiceCode>0</invoiceCode>");
    	rootNode.Invoice.response.appendNode(invoiceCodeObj);
    }
	
	def newRootNode = XmlUtil.serialize(rootNode);
	message.setBody(newRootNode);
	return message;
}