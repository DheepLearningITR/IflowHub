import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.String;
import groovy.xml.*;
import groovy.util.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.ITApi;

def Message processData(Message message) {
    
    def map = message.getProperties();
    String serialNo = map.get("complexSerialNo");
	
	def invoiceInfo = dynamicValueMap("SerialNo","name","InvoiceCode:InvoiceNo","name",serialNo);
	if (invoiceInfo != null) {
	    message.setProperty("fdeiFlag", "X");
	    if (invoiceInfo.contains(":")) {
    	    def parts = invoiceInfo.split(":");
    	    def invoiceCode = parts[0];
    	    def invoiceNo = parts[1];
    		message.setProperty("invoiceNo",invoiceNo);
    		message.setProperty("invoiceCode",invoiceCode);	        
	    } else {
	        message.setProperty("eInvoice","X");
    		message.setProperty("invoiceNo",invoiceInfo);	 
	    }
	}
	return message;
}

def String dynamicValueMap(String sAgency, String sSchema, String tAgency, String tSchema, String key){
	def service = ITApiFactory.getApi(ValueMappingApi.class, null);
	if( service != null) {
		return service.getMappedValue(sAgency, sSchema, key, tAgency, tSchema);
	}
	throw new Exception("Service is null");
	return null;
}