import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonException

def Message processData(Message message) {
    String content
    try {
        new JsonSlurper().parseText(message.getBody(String))
        content = 'JSON'
    } catch (JsonException) {
        content = 'XML'
    }
    message.setProperty('XmlOrJson', content)
    return message
}