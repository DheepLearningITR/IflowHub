import com.sap.it.api.ITApiFactory; 
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    
    def map = message.getProperties();
    
    def taxNo = map.get("taxNo");

    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    def serviceURL = valueMapApi.getMappedValue("SAP S/4HANA", "taxNo", 
        taxNo, "Partner", "serviceURL");

    message.setProperty("serviceURL", serviceURL);
    
    def serviceCredentialName = valueMapApi.getMappedValue("SAP S/4HANA", "taxNo", 
        taxNo, "Partner", "serviceCredentialName");

    message.setProperty("serviceCredentialName", serviceCredentialName);
    
    String body = message.getBody(java.lang.String) as String;
    messageLog.addAttachmentAsString("bodyBefore", body, "text/json");
    
    updatedMessageString = addCustomizedParamToPayload(body, valueMapApi, taxNo);
    
    messageLog.addAttachmentAsString("bodyAfter", updatedMessageString, "text/json");
    message.setBody(updatedMessageString);
    return message;
}

String addCustomizedParamToPayload(body, valueMapApi, taxNo) {
    def paramNameList = valueMapApi.getMappedValue("SAP S/4HANA", "taxNo", 
        taxNo, "Partner", "paramNameList");
    
    //no customized parameter found.
    if (paramNameList == null) {
        return body;
    }
    
    def jsonSlurper=new JsonSlurper();
    def jsonObject=jsonSlurper.parseText(body);
    
    def businessInfo = jsonObject.BusinessInfo;
    
    def resultArr = paramNameList.split(",").collect { it.trim() };
    resultArr.each { paramName -> 
        def paramValue = valueMapApi.getMappedValue("Partner", "paramName", 
            paramName, "Partner", "paramValue");
        
        businessInfo[paramName] = paramValue;
    }
    
    JsonOutput.toJson(jsonObject);
   
}