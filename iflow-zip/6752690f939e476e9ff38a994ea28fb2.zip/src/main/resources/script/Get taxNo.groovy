import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Body 
    def messageLog = messageLogFactory.getMessageLog(message); 
    String body = message.getBody(java.lang.String) as String;
    def jsonSlurper=new JsonSlurper();
    def jsonObject=jsonSlurper.parseText(body);
    def taxNo=jsonObject.BusinessInfo.TaxNumber;
    message.setProperty("taxNo", taxNo);
    return message;
}
