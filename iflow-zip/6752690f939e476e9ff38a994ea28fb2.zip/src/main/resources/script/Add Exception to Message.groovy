import com.sap.gateway.ip.core.customdev.util.Message;
import static groovy.json.JsonOutput.toJson

def Message processData(Message message) {
    //Body 
    def map = message.getProperties();
    def exceptionMessage = map.get("exceptionMessage");
    
    def data = ["Code": "999", "Message":exceptionMessage];
    def jsonString = toJson(data).toString();
    
    message.setBody(jsonString);
    return message;
}
