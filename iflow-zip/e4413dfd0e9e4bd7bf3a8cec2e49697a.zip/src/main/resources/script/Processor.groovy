import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.security.MessageDigest;
import java.security.Security;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

import groovy.transform.Field;
import java.lang.Exception;
import java.text.Normalizer;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import java.net.URI;

import org.apache.commons.codec.binary.Base64;
import java.util.*;
 
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import java.lang.Object;
import java.util.zip.CRC32;
import java.util.zip.Checksum;
import java.security.DigestInputStream;
import java.util.zip.CheckedInputStream;
import java.nio.charset.StandardCharsets;


//static final String SECRET_KEY_ENCODING = "UTF-8";
//static final String MESSAGE_PROPERTY_NAME = "replacementkey_alias";                                                                                 


def Message processGetToken( Message message ) throws Exception {

	setCredentialsAsProperties(message);
	setRequestSignatureAsProperties(message);
	
	return message;
}


def setCredentialsAsProperties( Message message ) throws Exception {

    def map = message.getProperties();
    def credentials_alias = map.get("credentials_alias");
	
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
	def credential = null;
	try {
		credential = service.getUserCredential( credentials_alias );
	} catch (all) {
		throw new Exception("No credentials found for alias " + credentials_alias );
	}

//Get credential from keystore
    String userName = credential.getUsername();
   // String password = new String(credential.getPassword());
    
//Hash SHA-512 the pass capital letters    
    def MessageDigest digest = MessageDigest.getInstance("SHA-512");
    byte[] salt = (new String(credential.getPassword())).getBytes("UTF-8");
    digest.update(salt);

    def passwordHash = digest.digest().encodeHex().toString();
    def passwordHashup = passwordHash.toUpperCase();
   
    message.setProperty("login", userName);
    message.setProperty("passwordHash", passwordHashup);
	
 	return message;
}


def setRequestSignatureAsProperties( Message message ) throws Exception {
// Concatenate requestId value - UTC timestamp tag value using a YYYYMMDDhhmmss mask (remove separators)
// and String literal of the technical user�s signature key
    def map = message.getProperties();
    def invoiceNo = map.get("invoiceNo");
	def timestamp = map.get("timestampZ").replaceAll(/[^0-9]/, "").substring(0, 14);
	def requestId = map.get("requestId_token");  
    def signaturekey_alias = map.get( "signaturekey_alias" );
	
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
	def signature = null;
	try {
		signature = service.getUserCredential( signaturekey_alias );
	} catch (all) {
		throw new Exception("No signaturekey credentials found for alias " + signaturekey_alias );
	}

//Get credential from keystore
    String userName = signature.getUsername();
   // String password = new String(signature.getPassword());   
          
    def requestSignature = new String(requestId + timestamp + (new String(signature.getPassword())) );
    
 //Hash SHA-512 the pass capital letters    
    def MessageDigest digest = MessageDigest.getInstance("SHA3-512");
    byte[] salt = requestSignature.getBytes("UTF-8");
    digest.update(salt);
    def requestSignatureHass = digest.digest().encodeHex().toString();
    def requestSignatureHashup = requestSignatureHass.toUpperCase();
   
    message.setProperty("requestSignature", requestSignatureHashup ); 
    message.setProperty("requestSignatureNoHASH", requestSignature ); 
	message.setProperty("signaturekey_alias", signaturekey_alias );
	message.setProperty("requestId_token", requestId );
	message.setProperty("timestamp", timestamp );
  
 	return message;
}


def Message processInvoiceReg( Message message ) throws Exception {

	postprocessTokenMessage(message );
 //   encodeBody(message);
	setNewRequestSignature(message);
//	crc32Encode(message);
//	getNewRequestSignature(message);
	
	return message;
}


def Message postprocessTokenMessage( Message message ) {

   def body = message.getBody( java.lang.String ) as String;
   //def nsMatcher = ( body =~ /(?<=\<encodedExchangeToken\>)(\s*.*\s*)(?=\<\/encodedExchangeToken\>)/ );

   def exchangeTag = body.substring(
                body.indexOf('<encodedExchangeToken>') + '<encodedExchangeToken>'.length(),
                body.indexOf('</encodedExchangeToken>')
   );

   //def exchangeTag = '';
   //exchangeTag = nsMatcher[0][0].toString();

//AES encode
   def dencodedToken = encrypt_aes(exchangeTag, message);
   message.setProperty("dencodedToken", dencodedToken.take(48));     
   message.setProperty("encodedEToken", exchangeTag.toString() );  
         
    return message;   
}



def encrypt_aes( String toBeEncrypt, Message message) throws Exception {
    def replacement_key = new String('replacementkey_alias');
    def map = message.getProperties();
    def replacementkey_alias = map.get( replacement_key );                                                                                   
    
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
	def replacementkey = null;
	try {
		replacementkey = service.getUserCredential( replacementkey_alias );
	} catch (all) {
		throw new Exception("No replacement key credentials found for alias " + replacementkey_alias );
	}

//Get credential from keystore
    String userName = replacementkey.getUsername();
    //String password = new String(replacementkey.getPassword());
    
  	//String SECRET_KEY = password;//"weJiSEvR5yAC5ftB";

//// 
    def secretKeySpec = new SecretKeySpec((new String(replacementkey.getPassword())).getBytes(StandardCharsets.UTF_8), "AES");        
    def cipher = Cipher.getInstance("AES/ECB/NOPADDING");//PKCS5PADDING

    cipher.init(Cipher.DECRYPT_MODE, secretKeySpec); //, ivParameterSpec
    byte[] decryptedBytes = cipher.doFinal(Base64.decodeBase64(toBeEncrypt));
    
    return new String(decryptedBytes);
}

def encodeBody(Message message) {

         def invoiceData = message.getProperty( "invoiceBody" );
         def encodedInvoiceData = invoiceData.getBytes("UTF-8").encodeBase64().toString();
 		 message.setProperty("encodedInvoiceData", encodedInvoiceData);
         
  
    return message;
}

def setNewRequestSignature(Message message) throws Exception {	
    def map = message.getProperties();	
    def requestId = map.get( "requestId_manage" );	
	def timestamp = map.get("timestamp");    	
    def signaturekey_alias = map.get( "signaturekey_alias" );	
		
    def service = ITApiFactory.getApi(SecureStoreService.class, null);	
	def signature = null;	
	try {	
		signature = service.getUserCredential( signaturekey_alias );	
	} catch (all) {	
		throw new Exception("No signaturekey credentials found for alias " + signaturekey_alias );	
	}	
//Get credential from keystore	
    String userName = signature.getUsername();
//Hash SHA-512 the pass capital letters    	
    def MessageDigest digest = MessageDigest.getInstance("SHA3-512");	
//Concatenate the new request signature with CRC32    
 def newRequestSignatureHass = digest.digest((new String(requestId + timestamp + (new String(signature.getPassword())))).getBytes("UTF-8")).encodeHex().toString();	
    def newRequestSignatureHashup = newRequestSignatureHass.toUpperCase();	
   	
    message.setProperty("newRequestSignature", newRequestSignatureHashup );    	
    message.setProperty("newRequestSignatureNoHASH", (new String(requestId + timestamp + (new String(signature.getPassword())))));                                             	
  	
    return message;                                       	
 }
