import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;


def Message processDigestArray(Message message) throws Exception {
    
    def currentPage = message.getProperty('currentPage');
    
    def parsedXml = new XmlSlurper().parseText(message.getBody(java.lang.String) as String);
    
    def invoiceDigestXmlString = ''; 
    if (!currentPage == 1) {
         invoiceDigestXmlString = message.getProperty('invoiceDigestXmlString');
    } else {
        invoiceDigestXmlString = '<invoiceDigests>';
        def availablePage = parsedXml.'**'.find{ it.name() == 'availablePage' };
        message.setProperty('availablePage', availablePage.text());
    }
    
    
    parsedXml.'**'.findAll{ it.name() == 'invoiceDigest' }.each{
        invoiceDigestXmlString = invoiceDigestXmlString + 
                                 '<invoiceDigest>' + 
                                 '<invoiceNumber>' + it.invoiceNumber.text() + '</invoiceNumber>' +
                                 '<supplierTaxNumber>' + it.supplierTaxNumber.text() + '</supplierTaxNumber>' +
                                 '</invoiceDigest>';
    }
    
    message.setProperty('invoiceDigestXmlString', invoiceDigestXmlString);

    if (currentPage.toString() == message.getProperty('availablePage') || currentPage.toString() > message.getProperty('availablePage' )) {
        message.setProperty('goDigestLoop', 'false');  
        message.setProperty('WebOperation', 'queryInvoiceData');    
        invoiceDigestXmlString = invoiceDigestXmlString + '</invoiceDigests>';
        message.setBody(XmlUtil.serialize(invoiceDigestXmlString));
    } else {
        message.setProperty('currentPage', currentPage.toInteger() + 1);
    }
    
    return message;
}
