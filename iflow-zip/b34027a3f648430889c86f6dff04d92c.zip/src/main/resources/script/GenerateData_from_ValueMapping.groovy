import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

import org.apache.camel.impl.DefaultAttachment
import javax.mail.util.ByteArrayDataSource

def Message processData(Message message) {
	
    def crossref_lookup = new XmlParser().parse(this.getClass().getResourceAsStream('/mapping/CrossReference_Lookup.xslt'))
	def customheader_lookup = new XmlParser().parse(this.getClass().getResourceAsStream('/mapping/CustomHeader_Lookup.xslt'))
	def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
	
	def properties = message.getProperties()
	source_agency = properties.get('anid')
	target_agency = properties.get('doctype')
	target_identifier = properties.get('sysid')
	
	crossrefs = null
	customheader = null
	uom = null
	lookuptable = null
	
	//Read possible CrossRef parameters for current doctype from lookup table
	crossref_params = crossref_lookup.'**'.Item.find{ it.DocumentType.text() == target_agency }
	//If CrossRefs are possible for this doctype try mapping with VM
	if ( crossref_params ) {
	    crossref_params = crossref_params.children()*.name()
	    crossrefs = crossref_params.collectEntries{ [it, valueMapApi.getMappedValue(source_agency, 'CrossRef', it, target_agency, target_identifier)] }
	}
	crossrefs = transform_crossref(crossrefs)
	
	//Try mapping with VM based on template
    uom = ['AribaValue','CustomerValue'].collectEntries{ [it, valueMapApi.getMappedValue(source_agency, 'UOM', it, 'Customer', target_identifier)] }
    uom = transform_uom(uom)
    
	//Try mapping with VM based on template
    lookuptable = ['DocumentType','Name','ProductType','ItemName','ItemValue'].collectEntries{ [it, valueMapApi.getMappedValue(source_agency, 'LookupTable', it, target_agency, target_identifier)] }
    lookuptable = transform_lookuptable(lookuptable)
	
	//Create baseline headers
	def header_base = HeaderBase()
	//Read all possible CustomParameters from lookup table
    customheader_params = customheader_lookup.'**'.Item.find{it}.children()*.name()
	//Try mapping with VM, if values are found keep all that are found
	customheader = customheader_params.collectEntries{ [it, valueMapApi.getMappedValue(source_agency, 'CustomParameter', it, target_agency, target_identifier)] }
    if ( customheader.find{ it.value } ) {
		customheader = header_base + customheader.findAll{ it.value != null }
	}
	else {
		customheader = header_base
	}
    
	//Create CustomData message as XML
    def writer = new StringWriter()
	def xml = new MarkupBuilder(writer)
	
    xml.CustomData() {
        Parameters() {
            for ( header in customheader ) {
                Parameter(key: header.key, header.value)
			}
        }     
        Contents() {
            Content(key: 'CROSSREFERENCE_' + target_identifier, crossrefs.bytes.encodeBase64().toString())
            Content(key: 'UOM_UOM_' + target_identifier, uom.bytes.encodeBase64().toString())
            Content(key: 'LOOKUPTABLE_' + target_identifier, lookuptable.bytes.encodeBase64().toString())          
        }
    }

	//Write CustomData message to Attachment to be processed as MIME message
    def output = writer.toString()
    def dataSource = new ByteArrayDataSource(output.bytes, 'text/xml')
    def attachment = new DefaultAttachment(dataSource)
    message.addAttachmentObject('CustomData', attachment)

    return message
}

//Handler functions for different message contents
String transform_crossref( Map input ) {

    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)

    xml.ParameterCrossReference(){
        ListOfItems(){
			if (input) {
            Item{
                for (ref in input) {
                    if (ref.value) {
						"${ref.key}"("${ref.value}")
					}
                }
            }
			}
        }
    }
    return writer.toString()
}

String transform_uom( Map input ) {

    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)

    xml.UOM(){
        ListOfItems(){
			if (input){
            Item{
                for (ref in input) {
                    if (ref.value) {
						"${ref.key}"("${ref.value}")
					}
                }
            }
			}
        }
    }
    return writer.toString()
}

String transform_lookuptable( Map input ) {

    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)

    xml.LOOKUPTABLE(){
		if (input){
        Parameter(){
            DocumentType(input['DocumentType'])
            Name(input['Name'])
            ProductType(input['ProductType'])
            ListOfItems(){
                Item{
                    Name(input['ItemName'])
                    Value(input['ItemValue'])
                }
            }
        }
		}
    }
    return writer.toString()
}

Map HeaderBase() {

	def headers = [:]

	headers.anERPSystemID = target_identifier
	headers.anBuyerANID = source_agency
	headers.anPayloadID = UUID.randomUUID().toString() + "@" + new Date().getTime()
	headers.anCrossRefFlag = 'YES';
	headers.anUOMFlag = 'YES';
	headers.anLookUpFlag = 'YES';

	return headers
	
}
