import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*
import org.apache.camel.impl.DefaultAttachment
import javax.mail.util.ByteArrayDataSource

def Message processData(Message message) {
    
    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)
    def anid = message.getProperty('anid')
    def sysid = message.getProperty('sysid')
    def cid = UUID.randomUUID().toString()
 
    def writer = new StringWriter()
    def cc = new MarkupBuilder(writer)
	
    cc.cXML(payloadID:xml.@payloadID.toString() - xml.@timestamp.toString()
            , timestamp:xml.@timestamp, version:'1.2.056', "xml:lang":'en-US') {
        Header{
            From{
                Credential(domain:'NetworkID'){
                    Identity(anid)
                }
            }
            To{
                Credential(domain:'VendorID'){
                    Identity(xml.Header.From.Credential.find{it.@domain == 'VendorID'}.Identity)
                } 
            }
            Sender{
                Credential(domain:"NetworkID") {
                    Identity(xml.Header.Sender.Credential.find{it.@domain == 'NetworkID'}.Identity)
                }
                UserAgent('Ariba SN Buyer Adapter')
            }
        }
        Request{
            CopyRequest{
                cXMLAttachment{
                    Attachment{
                        URL('cid:' + cid)
                    }
                }
            }
        }
    }
    
    def dtd = '<?xml version="1.0" encoding="utf-8"?><!DOCTYPE cXML SYSTEM "http://xml.cxml.org/schemas/cXML/1.2.056/InvoiceDetail.dtd">'
    
    def dataSource = new ByteArrayDataSource((dtd + body).bytes, "text/xml")
    def attachment = new DefaultAttachment(dataSource)
    attachment.setHeader('Content-Transfer-Encoding', 'base64')
    attachment.setHeader('Content-Disposition', 'attachment; filename=' + 'MMInvoice.xml')
    attachment.setHeader('Content-ID', '<' + cid + '>')
    message.addAttachmentObject('attachment', attachment)
    
    message.setBody(XmlUtil.serialize(writer.toString()))
    message.setProperty('attachmentflag','true')
    return message
}