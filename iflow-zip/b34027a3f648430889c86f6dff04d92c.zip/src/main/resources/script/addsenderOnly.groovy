import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential
import com.sap.it.api.securestore.exception.SecureStoreException

def Message processData(Message message) {

	def xml = new XmlParser(false,false).parse(message.getBody(Reader))
    credential_name = message.getProperty('SharedSecret_Credential')   

    //Get Security Material
    def service = ITApiFactory.getApi(SecureStoreService.class, null)
    def cred = service.getUserCredential(credential_name);
    if (cred == null){
        throw new IllegalStateException('No credential found for alias')
    }
 
    sender = xml.'**'.Sender.Credential
    if (sender) sender.replaceNode{
        Credential(domain:'NetworkID') {
            Identity(cred.getUsername())
           // SharedSecret(cred.getPassword())
        }
    };

	message.setBody(XmlUtil.serialize(xml).replaceFirst("<\\?xml version=\"1.0\".*\\?>", ""))
    return message;
}
