import com.sap.it.api.mapping.*;

def String getProp(String P, MappingContext context){
	    String value = context.getProperty(P);
        return value;
}