import com.sap.it.api.mapping.*;

//Add MappingContext parameter to read or set headers and properties
def String readProp(String P1,MappingContext context) {
         String value1 = context.getProperty(P1);
         value1 = value1.substring(0,4);
         return value1;
}

