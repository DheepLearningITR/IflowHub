import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    
    
    if(object.A_CreditMemoRequest==null || object.A_CreditMemoRequest.isEmpty() )
    {
        message.setHeader("NoUpdates",true)
    }
    else{
	message.setHeader("NoUpdates",false)

	// Batch Payload
    String completePayload = "";
  
    // Generate Random Id to be used in Batch Code
    String batchId = UUID.randomUUID().toString();
  
    // Prepare Batch Code
    String batchCode = "--batch_id-" + batchId;    

	//Checking if there is only one Record
    if (!isCollectionOrArray(object.A_CreditMemoRequest.A_CreditMemoRequestType)) {
        
		//Converting Record to an array
        
		object.A_CreditMemoRequest.A_CreditMemoRequestType = [object.A_CreditMemoRequest.A_CreditMemoRequestType].toArray();
    
	}
	
	// Set DRF bulk message id and sender system id as properties
	message.setProperty("messageID", object.messageID);
	message.setProperty("senderID", object.senderID);
	
	String contentId = "";
	
	// Prepare changeset data by looping the list of records
	object.A_CreditMemoRequest.A_CreditMemoRequestType.each { record ->
	
    	// Generate changeset Id to be used in changeset Code
	    String changesetID = UUID.randomUUID().toString();
	    
	    
	    contentId = "BP_" + record.CreditMemoRequest;
	
	    // Prepare changeset Code for address and businesspartner payloads
	    String changeset = "--changeset_" + changesetID; 
	    
	    completePayload=completePayload.concat(batchCode + "\n")
	    completePayload=completePayload.concat("Content-Type: multipart/mixed; boundary=changeset_"+changesetID+ "\n" + "\n")
	    
	    String tempPayload = changeset + "\n"
		tempPayload = tempPayload + "Content-Type:application/http " + "\n" + "Content-Transfer-Encoding:binary" + "\n" + "Content-ID:" + contentId + "\n" + "\n"
		
		
		
	
// 	      def jsonInput="{"+
//     "\"items\": "+
//       "  {"+
//           " \"identifier\": \""+record.CreditMemoRequest+"\""+
//         "}"+
//   " ,"+
//     "\"status_code\": \"CMPL\""+
// "}\"";

def jsonInput="{\"status_code\":\"CMPL\"}";
def id=findIdByIdentifier( message.getProperty("input"),record.CreditMemoRequest);


	    
		tempPayload = tempPayload + "PATCH ComplaintActions("+id+") HTTP/1.1" + "\n"
		tempPayload = tempPayload + "Accept:application/json;odata.metadata=minimal;IEEE754Compatible=true" + "\n" 
		tempPayload = tempPayload + "Accept-Language:en-US" + "\n" 
		tempPayload = tempPayload + "Content-Type:application/json;charset=UTF-8;IEEE754Compatible=true" + "\n" + "\n" 
		tempPayload = tempPayload + jsonInput + "\n" + "\n"
		
	   
		
		completePayload = completePayload.concat(tempPayload)
		// Close the changeset
	    completePayload = completePayload + "--changeset_" + changesetID + "--" + "\n" + "\n"
		
	}
	
	// Close the full payload
	completePayload = completePayload + "--batch_id-" + batchId + "--"
	
	// Prepare Message Body
	message.setBody(completePayload)
	
	// Prepare Boundary Header Parameter to be added in message header
	String boundaryParam = "multipart/mixed; boundary=batch_id-" + batchId;
	
	// Prepare Message Header
	message.setHeader('Content-Type', boundaryParam);
	message.setHeader('Prefer', "odata.continue-on-error");
    }
	
    return message
}



//Returns true if object is an array

boolean isCollectionOrArray(object) {
    
	[Collection, Object[]].any {
        
		it.isAssignableFrom(object.getClass())
    
	}
}



// Function to find ID by systemName and identifier
def findIdBySystemAndIdentifier(Map<String, List<Map>> groupedBySystem, String systemName, String targetIdentifier) {
    def systemItems = groupedBySystem[systemName]
    if (systemItems) {
        def foundItem = systemItems.find { item ->
            item.items.identifier == targetIdentifier
        }
        return foundItem?.id // Return the ID if found, or null if not found
    }
    return null // Return null if systemName not found
}
	
	
	
	// Function to find ID by identifier
def findIdByIdentifier(Map<String, List<Map>> groupedBySystem, String targetIdentifier) {
    def resultId = null
    groupedBySystem.each { systemName, items ->
        items.each { item ->
            if (item.items.identifier == targetIdentifier) {
                resultId = item.ID
                return  // Exit loop once the identifier is found
            }
        }
        if (resultId != null) {
            return  // Exit outer loop if result found
        }
    }
    return resultId
}



	
	
	
	