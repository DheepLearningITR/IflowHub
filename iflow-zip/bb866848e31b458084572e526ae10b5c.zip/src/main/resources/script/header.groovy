import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String);
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body.toString());
   message.setHeader("destination", object.mobile);
	message.setHeader("newHeader", "newHeader");
    return message;
}