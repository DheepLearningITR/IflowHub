import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
import groovy.xml.*
import java.io.StringWriter
def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String);
    
     def jsonSlurper = new JsonSlurper()
       def object = jsonSlurper.parseText(body.toString());

    
// Fetch the count
def count = object.'@count';

// Output the results
message.setProperty("count",count);
def oldSkipValue=message.getProperty("skip")
def recordsFetchNumber=message.getProperty("recordsPerFetch");
message.setProperty("skip",oldSkipValue+recordsFetchNumber);

    
    def listOfdocument=object.value;


// Group identifiers by system
def groupedBySystem = listOfdocument.groupBy { it.targetType.destinationSystem }

message.setProperty("input",groupedBySystem);
 
  def s_xml=new StringWriter()
def builder = new groovy.xml.MarkupBuilder(s_xml)





builder.complaintActions{
        groupedBySystem.each(){ systemName, entries ->
         builder.target{
           builder.Destination(systemName);
              entries.each { item ->
               // id(item.id)
                identifier(item.items.identifier)
                }
        
           }
        }
         
    }

   message.setBody(s_xml.toString());

   
    
    return message;
}