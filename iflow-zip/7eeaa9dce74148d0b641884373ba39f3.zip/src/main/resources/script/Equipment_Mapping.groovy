import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser

def Message processData(Message message) {
    def output_node = new NodeBuilder().Equipments{}
    def tempNode
    def registeredProductNode
    def eq_inactive = true
    def response = new XmlParser().parseText(message.getBody(String.class))
    def language_code = message.getProperty("languageCode")
    def fallback_language_code = message.getProperty("fallbackLanguageCode")
    def desc = ""
    if(language_code.isEmpty()){
        language_code = "EN"
    }
    def desc_node
    def text=""
    def fsmParentId = ""
    def func_loc_enabled = message.getProperty("func_loc_enabled")
    
    response.RegisteredProductReplicationRequest.each{
        registeredProductNode = it.RegisteredProduct
        if(registeredProductNode.LifeCycleStatusCode.text().equals("2")){
            eq_inactive = false
        }
        
        desc_node = it.'**'.findAll { it.name() == 'Description' && it.@languageCode == language_code }
        desc = desc_node.isEmpty()? "" : desc_node[0].text() 
        if(desc.isEmpty()){
           desc_node= it.'**'.findAll { it.name() == 'Description' && it.@languageCode == fallback_language_code }
           desc = desc_node.isEmpty()? "" : desc_node[0].text() 
        }
        
        if(registeredProductNode.TextCollection){
            registeredProductNode.TextCollection.Text.each{
                if(it.TypeCode.text().equals("10024")){
                    text = it.ContentText.text()
                }
            }
        }
        def typeCode = registeredProductNode.HierachyRelationship.UpperInstallationPointTypeCode.text()
        
        
        if(registeredProductNode.@actionCode[0].equals("04")){
            tempNode = new NodeBuilder().data{
                businessPartner{
                    externalId(registeredProductNode.CustodianParty.PartyID.text())
                }
                externalId(registeredProductNode.InstallationPointID.text())
                inactive(eq_inactive)
                item{
                    externalId(registeredProductNode.ReferenceProductID.text())
                }
                name(desc)
                remarks(text)
                serialNumber(registeredProductNode.SerialID.text())
                nameTranslations{}
            }
            if(registeredProductNode.CustodianParty.ContactParty.PartyID.text()){
                def contactNode = new NodeBuilder().contact{
                    externalId(registeredProductNode.CustodianParty.ContactParty.PartyID.text() + "~ID-JOIN~" + registeredProductNode.CustodianParty.PartyID.text())
                }
                tempNode.append(contactNode)
            }
            if(typeCode.equals("2")){
                fsmParentId = registeredProductNode.HierachyRelationship.UpperInstallationPointID.text()
                def parentNode = new NodeBuilder().parentId{
                    externalId(fsmParentId)
                }
                tempNode.append(parentNode)
            }
            if(typeCode.equals("6") && func_loc_enabled){
                fsmParentId = registeredProductNode.HierachyRelationship.UpperInstallationPointID.text()
                def parentNode = new NodeBuilder().parentId{
                    externalId(fsmParentId)
                }
                tempNode.append(parentNode)
            }
            desc_node = it.'**'.findAll { it.name() == 'Description'}
            desc_node.each{
                def languageCode = it.Description.@languageCode[0]
                def description = it.Description.text()
                if(languageCode){
                    languageCode = languageCode.toLowerCase()
                    def tempNode2 = new NodeBuilder()."${languageCode}"(description)
                    tempNode.nameTranslations[0].append(tempNode2)
                }
            }
            output_node.append(tempNode)
        }
    }
    
     message.setBody(groovy.xml.XmlUtil.serialize(output_node))
     return message
}