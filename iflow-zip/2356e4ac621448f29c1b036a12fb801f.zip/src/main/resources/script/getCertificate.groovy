/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.commons.codec.binary.Base64;
import java.security.cert.X509Certificate;
import java.security.cert.Certificate;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

def Message processData(Message message) {
 def map = message.getProperties();
     def header = message.getHeaders();
     
     def submit= header.get("Submit");
     def cancel= header.get("Cancel");
     def getStatus = header.get("Status")
     def submitv2= header.get("SubmitV2");
     def cancelv2= header.get("CancelV2");
     int j=0;
     char[] cert = new char[20];
 
          
     //Deciding the name of the root node and response path based on the action
     if(submit|submitv2)
     {
     	message.setProperty("root","scfd:emitirRetencion/scfd:PoRequestRetencion");
     	message.setProperty("response","/emitirRetencionResponse/emitirRetencionResult/ResponseAdmonRetencion");
     }
	 else if(cancel|cancelv2)
	 {
	 	message.setProperty("root","scfd:cancelarRetencion/scfd:PoRequestRetencion");
	 	message.setProperty("response","/cancelarRetencionResponse/cancelarRetencionResult/ResponseAdmonRetencion");
	 }
	 else if(Status)
	 {
	 	message.setPropery("root","scfd:consultarRetencion/scfd:PoRequestRetencion");
	 	message.setProperty("response","/consultarRetencionResponse/ResponseAdmonRetencion/");
	 }
	 
	// Access the PAC credentials
	// def credservice = ITApiFactory.getApi(SecureStoreService.class, null);
	// def credentials = header.get("pac_credentials");
	// def credential = credservice.getUserCredential(credentials);
    // String userName = credential.getUsername();
    // String password = new String(credential.getPassword());
	// message.setHeader('PACUser', userName);
	// message.setHeader('PACPWD', password);
	 	 	 
	 if(submit || submitv2)
	 {
	 def certname = header.get("certname");
	 //Access the keystore and get the certificate based on the alias
	 def service = ITApiFactory.getApi(KeystoreService.class, null);
//     if (credential == null){
//      throw new IllegalStateException("No credential found for alias" + credentials);
//    }
    
     Certificate certs = service.getCertificate(certname);
	 X509Certificate x509certificate = (X509Certificate)certs;
     
	 def serial =  certs.getSerialNumber();
	 
	 String cert_serial =  x509certificate.getSerialNumber().toString(16);
	 
	 char[] serialno = cert_serial.toCharArray();
	 
	 for(int i=1;i<cert_serial.length();i=i+2)
	    cert[j++] = serialno[i];
	    
	 String certificateno= String.valueOf(cert); 
	 message.setHeader('certificateno',certificateno);
	 message.setHeader('serial',serial);
	 
	 //prepare Base64 encoded format of the certificate
	 String certificate =  Base64.encodeBase64String(certs.getEncoded());
	
	 message.setHeader("certificate", certificate);
	
	 }
    if(submit || cancel || getStatus)
	 {
	 message.setProperty("eDocNamespace", "\"http://www.sap.com/eDocument/Mexico/WTC/v1.0\"");
	 message.setProperty("version", "\"1.0\"");
	 }else if(submitv2 || cancelv2 || getStatusv2)
	 {
	 message.setProperty("eDocNamespace", "\"http://www.sap.com/eDocument/Mexico/WTC/v2.0\"");
	 message.setProperty("version", "\"2.0\"");
	 }
	 
	return message;
}