import com.sap.it.api.mapping.*;

def String customFunc(String propertyName, MappingContext context){
String deviceType = context.getProperty(propertyName);
switch(deviceType)
{
    case "Computer":
        deviceType = "DESKTOP";
        break;
    case "Mobile":
        deviceType = "MOBILE";
        break;
    case "Tablet":
        deviceType = "TABLET";
        break;
    case "Game console":
        deviceType = "CONSOLE";
        break;
    case "Wearable computer":
        deviceType = "WEARABLE";
        break;
    case "Digital media receiver":
        deviceType = "RECEIVER";
        break;
    case "Unknown":
        deviceType = "UNKNOWN";
        break;
    default:
        deviceType = "";
        break;
}
	return deviceType; 
}