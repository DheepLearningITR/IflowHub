import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
		def procDirect = message.getProperties().get("processDirect");
		if(procDirect!=null){
			messageLog.addCustomHeaderProperty("cbr_targetProcess", procDirect);		
        }
	}
	return message;
}
