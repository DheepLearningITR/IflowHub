import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    //Headers
    def headers = message.getHeaders();
    def retries = headers.get("SAPJMSRetries");
    if(retries!=null){
        message.setHeader("isRetry", 'true');
    }
    return message;
}