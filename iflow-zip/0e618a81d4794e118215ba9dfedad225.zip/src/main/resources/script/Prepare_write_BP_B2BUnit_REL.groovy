import com.sap.gateway.ip.core.customdev.util.Message;
import java.lang.String;
import javax.xml.xpath.XPathFactory;
import javax.xml.parsers.DocumentBuilderFactory;

// set B2BUnit + BP_REL datastore name, entry ID to write the two payload, set WRITE_ACTION to "True"
def Message processData(Message message) {
    	
	def messageLog = messageLogFactory.getMessageLog(message);
	def body = message.getBody(java.lang.String) as String;
    message.setProperty("BP_REL_PAYLOAD", body);


	String BP_Payload = message.getProperty("BP_PAYLOAD");
	
	String B2BUnit_REL_ID = processXml(body, "//RelationshipBusinessPartnerInternalID");
	
	message.setHeader("DATASTORE_NAME", "BP_B2BUnit_REL");
	message.setHeader("ENTRY_ID", B2BUnit_REL_ID);
	message.setHeader("ACTION", "WRITE");
	
	if (BP_Payload != null && BP_Payload != "")
	{
	    String Language = processXml(BP_Payload, "//Language");
	    message.setBody("<B2BUnitRel>" + body + "<Language>" + Language + "</Language>" + "</B2BUnitRel>");

	} 
	else 
	{
	    message.setBody("<B2BUnitRel>" + body + "</B2BUnitRel>");
	    
	}
    
    
   return message;
}    

def processXml( String xml, String xpathQuery ) {
    
   def xpath = XPathFactory.newInstance().newXPath()
   def builder     = DocumentBuilderFactory.newInstance().newDocumentBuilder()
   def inputStream = new ByteArrayInputStream( xml.bytes )
   def records     = builder.parse(inputStream).documentElement
  
   xpath.evaluate( xpathQuery, records )
}