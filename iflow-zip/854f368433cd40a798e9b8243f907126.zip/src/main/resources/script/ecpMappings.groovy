import com.sap.it.api.mapping.*;
import static java.util.Calendar.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String formatDate(String date) {
    def formattedDate = date
    
    if (date != null && date != "") {
		if (!date.contains("-")) {
			//yyyy-MM-dd
			def dp = new Date().parse("yyyyMMdd", date)
            formattedDate = dp.format("yyyy-MM-dd")
		}
    }    
	return formattedDate 
}
def String formatTime(String time) {
    def formattedTime = time
    
    if (time != null && time != "") {
		if (!time.contains(":")) {
			//HH:mm:ss
			def dp = new Date().parse("HHmmss", time)
            formattedTime = dp.format("HH:mm:ss")
		}
    }    
	return formattedTime 
}
def String mapOperacao(String p,MappingContext context) {
    def tpOp = context.getProperty(p);
    
    if (tpOp == null || tpOp == "") {
        tpOp = "I"
    } 
    //I - inclusão
    //M - modificação
    //E - exclusão
    
    return tpOp
}