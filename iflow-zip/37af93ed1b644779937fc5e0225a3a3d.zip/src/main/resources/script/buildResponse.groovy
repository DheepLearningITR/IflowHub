import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;
import groovy.json.JsonOutput;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

@Field String ERROR_SHORTTEXT = 'ERROR';
@Field String INFO_SHORTTEXT = 'INFO';

@Field String UNKNOWN_ERROR = 'An unknown error occurred.';
@Field String CPI_MSGID_TEXT = 'SAP Cloud Integration message ID: ';

@Field String OAS_TYPE_FULFILLMENTINITIATED = 'SAP_FULFILLMENT_INITIATED';
@Field String OAS_TYPE_FULFILLMENTREJECTED = 'SAP_FULFILLMENTREJECTED';

class ResponseMsg {
	String type
	String message
}

class OrderItemInit {
	String fulfillmentRequestItemId
	Quantity quantity
	FulfillmentSystemReference fulfillmentSystemReference
}

class OrderItemReject {
	String fulfillmentRequestItemId	
	Quantity quantity
	String reasonCode
}

class FulfillmentSystemReference {
	String documentItemNumber	
}

class Quantity {
	BigDecimal value
	String unit
}

// method to create the message for order activity type SAP_FULFILLMENT_INITIATED
def Message buildFulfillmentInitiatedMessage(Message message) {
	def headers = message.getHeaders();
	headers.put("Content-Type", "application/json");

	def properties = message.getProperties();
	def response = [:];

	String useSAPUnitCode = properties.get("useSAPUnitCode");
	response["fulfillmentRequestId"] = properties.get("externalDocumentId");
	response["businessObjectId"] = UUID.randomUUID().toString();
	response["type"] = OAS_TYPE_FULFILLMENTINITIATED;
	response["occurredAt"] = formatDate(properties.get("documentLastChangedDateTime"));
	response["source"] = properties.get("fulfillmentSystemId");
	
	def fulfillmentSystemReference = [:];
	fulfillmentSystemReference["systemId"] = properties.get("fulfillmentSystemId");
	fulfillmentSystemReference["documentNumber"] = properties.get("salesOrderId");
	response["fulfillmentSystemReference"] = fulfillmentSystemReference;

	List<OrderItemInit> items = [];
	def orderItemList = properties.get("orderItemList");
	int length = orderItemList.getLength();
	for (i = 0; i < length; i++) {
		def newItem = convertItemFulfillmentInitiated((Element)orderItemList.item(i), useSAPUnitCode);
		if (newItem != null) {
			items.add(newItem);
		}
	}
	if (items.size() > 0) {
		response["items"] = items;
	} else {
		response["items"] = "[]";
	}

	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(response)));		
	return message;	
}

def OrderItemInit convertItemFulfillmentInitiated(def orderItem, String useSAPUnitCode){
	String fulfillmentRequestItemId = orderItem.getElementsByTagName("ExternalItemID").item(0).getTextContent();
	String documentItemNumber = orderItem.getElementsByTagName("SalesOrderItemID").item(0).getTextContent();
	def quantityNode = orderItem.getElementsByTagName("RequestedQuantity").item(0);
	String quantityString = quantityNode.getTextContent();
	BigDecimal quantityValue = new BigDecimal(quantityString);
	String quantityUnit = "";
	if (useSAPUnitCode.equals("true")) {
		quantityUnit = quantityNode.getAttributes().getNamedItem("SAPunitCode").getNodeValue();
	} else {
		quantityUnit = quantityNode.getAttributes().getNamedItem("unitCode").getNodeValue();
	}
	return new OrderItemInit(fulfillmentRequestItemId:fulfillmentRequestItemId, quantity:new Quantity(value:quantityValue, unit:quantityUnit), fulfillmentSystemReference:new FulfillmentSystemReference(documentItemNumber:documentItemNumber));
}

// method to create the message for order activity type SAP_FULFILLMENTREJECTED
def Message buildFulfillmentRejectedMessage(Message message) {
	def headers = message.getHeaders();
	headers.put("Content-Type",   "application/json");

	def properties = message.getProperties();
	def response = [:];

	String useSAPUnitCode = properties.get("useSAPUnitCode");
	response["fulfillmentRequestId"] = properties.get("externalDocumentId");
	response["businessObjectId"] = UUID.randomUUID().toString();
	response["type"] = OAS_TYPE_FULFILLMENTREJECTED;
	response["occurredAt"] = formatDate(properties.get("documentLastChangedDateTime"));
	response["source"] = properties.get("fulfillmentSystemId");	

	List<OrderItemReject> items = [];
	def orderItemList = properties.get("orderItemList");
	int length = orderItemList.getLength();
	for (i = 0; i < length; i++) {
		def newItem = convertItemFulfillmentRejected((Element)orderItemList.item(i), useSAPUnitCode);
		if (newItem != null) {
			items.add(newItem);
		}
	}
	if (items.size() > 0) {
		response["items"] = items;
		message.setProperty("rejectedItemsExist", true);
	} else {
		response["items"] = "[]";
	}

	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(response)));		
	return message;	
}

def OrderItemReject convertItemFulfillmentRejected(def orderItem, String useSAPUnitCode){
	String fulfillmentRequestItemId = orderItem.getElementsByTagName("ExternalItemID").item(0).getTextContent();	
	Element statusElement = (Element)orderItem.getElementsByTagName("Status").item(0);	
	Boolean rejected = getRejectionStatusBool(statusElement.getElementsByTagName("SDDocumentRejectionStatus").item(0).getTextContent());
	// only return item if status is "rejected" = true
	if (!rejected) {
		 return null;
	}
	String rejectionReason = getValueMappingRejectionReason(orderItem.getElementsByTagName("SalesDocumentRjcnReason").item(0).getTextContent());
	def quantityNode = orderItem.getElementsByTagName("RequestedQuantity").item(0);
	String quantityString = quantityNode.getTextContent();
	BigDecimal quantityValue = new BigDecimal(quantityString);
	String quantityUnit = "";
	if (useSAPUnitCode.equals("true")) {
		quantityUnit = quantityNode.getAttributes().getNamedItem("SAPunitCode").getNodeValue();
	} else {
		quantityUnit = quantityNode.getAttributes().getNamedItem("unitCode").getNodeValue();
	}
	return new OrderItemReject(fulfillmentRequestItemId:fulfillmentRequestItemId, quantity:new Quantity(value:quantityValue, unit:quantityUnit), reasonCode:rejectionReason);   	
}

def String formatDate(String dateString) {	
	Date date = Date.parse("yyyy-MM-dd'T'HH:mm:ss'Z'", dateString);
	return date.format("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
}

def Message exceptionDetails(Message message) {
	def properties = message.getProperties();
	String errorMessage = "";
	def exceptionProperty;
	def response = [:];
	List<ResponseMsg> respMsgs = [];

	try {
		exceptionProperty = properties.get("CamelExceptionCaught");
		// an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
		if (exceptionProperty.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
			errorMessage = exceptionProperty.getResponseBody();
		}
		if (!errorMessage.trim()) {
			errorMessage = exceptionProperty.message;
		}
	} catch (Exception ex) {
	}

	errorMessage = (errorMessage.trim()) ? errorMessage.replaceAll("\\P{Print}", "") : UNKNOWN_ERROR;
	respMsgs.add(new ResponseMsg(type:ERROR_SHORTTEXT,message:errorMessage));
	//Add CPI MsgID to messages
	respMsgs.add(new ResponseMsg(type:INFO_SHORTTEXT,message:CPI_MSGID_TEXT + properties.get("SAP_MessageProcessingLogID")));
	response["messages"] = respMsgs;

	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(response)));
	return message;
}

def Boolean getRejectionStatusBool(String statusCode) {
	Boolean statusBool = null;
	if (statusCode.equals('C')) {
		statusBool = true;
	}
	if (statusCode.equals('A')) {
		statusBool = false;
	}
	return statusBool;
}

def String getValueMappingRejectionReason(String rejectionReasonCode) {
	// retrieve value mapping api instance
	def valueMapApi = ITApiFactory.getService(ValueMappingApi.class, null);
	// returns mapped value if mapping is found
	// returns null if value is not found in value mapping OR value mapping artifact is not deployed
	String rejectionReasonText = valueMapApi.getMappedValue('S/4HANA', 'RejectionReason', rejectionReasonCode, 'OrderManagement', 'RejectionReason');
	// default to original rejection reason code if mapped value is not found
	return rejectionReasonText?rejectionReasonText:rejectionReasonCode;
}

