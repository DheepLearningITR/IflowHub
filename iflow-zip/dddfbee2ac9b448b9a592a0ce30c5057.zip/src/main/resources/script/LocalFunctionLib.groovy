import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.StringBuffer;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def String formatUUID(String uuid){	
	return (uuid.substring(0,8)+"-"+uuid.substring(8, 12)+"-"+uuid.substring(12,16)+"-"+uuid.substring(16,20)+"-"+uuid.substring(20));
}


def String generateGuid(String arg1){
	return UUID.randomUUID().toString()
}

def String getBusinessSystemDisplayId(String arg1, MappingContext context){
    return context.getProperty(arg1)
}



def Message processXmlInput(Message message) {

  def body = message.getBody(java.io.Reader)
  def xml = new XmlParser().parse(body)

  //find tags with null value
  def results = xml.
  '**'.findAll {
    !it.value()
  }

  results.each {
    def newNode = new Node(null, it.name(), 'xsi.nil')
    // replace node    
    it.replaceNode(newNode)
  }
  // write to body
  StringWriter stringWriter = new StringWriter()
  XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
  nodePrinter.setPreserveWhitespace(true)
  nodePrinter.print xml

  message.setBody(stringWriter.toString())
  return message;

}

def Message enrichJsonOutput(Message message) {
  //Body 
  def body = message.getBody(java.io.Reader);

  JsonSlurper slurper = new JsonSlurper()
  Map parsedJson = slurper.parse(body)

  parsedJson.messageRequests.each {

    if (it.body.isBlocked) {
      it.body.isBlocked = Boolean.parseBoolean(it.body.isBlocked)
    }

    if (it.body.isDeleted) {
      it.body.isDeleted = Boolean.parseBoolean(it.body.isDeleted)
    }

  }

  def respbody = JsonOutput.toJson(parsedJson)
  // handle xml nil 
  def body2 = respbody.replace('"xsi.nil"', 'null')
  message.setBody(body2)

  return message;
}

 def String deleteLeadingZeroes(String str){
        StringBuffer sb = new StringBuffer(str);
        while (sb.length()>1 && sb.charAt(0) == '0')
            sb.deleteCharAt(0);
        return sb.toString();  // return in String
}





