import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

Map transformToJson(Message message) {

    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    return json

}

def void updateMessageBody(Message message, Map messageBody) {

    def messageBodyJson = JsonOutput.toJson(messageBody);
    def prettyMessageBody = JsonOutput.prettyPrint(messageBodyJson);

    message.setBody(prettyMessageBody)

}


Message isDeletedToBoolean(Message message) {

    def messageJson = transformToJson(message)
    def shipmentMaterials = messageJson.data.shipmentMaterials
    
    if(shipmentMaterials != null) {
        for (shipmentMaterial in shipmentMaterials) {
    
            def isDeleted = shipmentMaterial.isDeleted
            
            if(isDeleted != null) {
                if (isDeleted instanceof String) {
                    shipmentMaterial.isDeleted = isDeleted.toBoolean()
                }   
            }
        }
    }

    updateMessageBody(message, messageJson)

    return message

}