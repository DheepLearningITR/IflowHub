import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    def jsonParser = new JsonSlurper();
    jsonObject = jsonParser.parseText(body);
    jsonObject=jsonObject["EQUIPMENT"];
    newBody="[]";
    print jsonObject;
    newjsonObject = jsonParser.parseText(newBody);
    newjsonObject.add(jsonObject);
    message.setBody(JsonOutput.toJson(newjsonObject));
    message.setProperty("RequestPayload",JsonOutput.toJson(newjsonObject));
    return message;
}