import java.util.*;

import com.sap.it.api.mapping.*;

//This method returns value of a header, expects one input header_name i.e. name of the header to be retrieved
def String get_header(String header_name,MappingContext context) {

    def header = context.getHeader(header_name);

    return header;

}

public String getProperty(String property_name, MappingContext context) {

    def propValue = context.getProperty(property_name);

    return propValue.toString();

}

public String isNumeric(String strValue, MappingContext context) {

    return strValue.isNumeric();

}

public String getNumerberWithLeadingZeroes(String strValue, MappingContext context) {
    def Integer iLength;
    def String strValue2;

    if (strValue.isNumber()){
        iLength = strValue.length();        
        // 30 times 0
        strValue2 = '000000000000000000000000000000' + strValue;
        strValue = strValue2.substring( iLength, iLength +30);
    }
    
    return strValue;

}