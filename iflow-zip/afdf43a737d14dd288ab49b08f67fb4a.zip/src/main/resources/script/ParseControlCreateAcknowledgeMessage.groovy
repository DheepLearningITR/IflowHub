import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.transform.CompileStatic
import groovy.transform.Field

@Field public static final String ACKNOWLEDGE_MESSAGE_STATUS_SUCCESS = 'SUCCESS'
@Field public static final String ADDRESS_FORMAT = '%s/cp.portal/site#Control-display?ControlGUID=%s&sap-app-origin-hint=&/ControlDisplay/%s'

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def acknowledgeMessageJson = new JsonSlurper().parse(body)
    def data = acknowledgeMessageJson.data
    def messageStatus = data.messageStatus

    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addCustomHeaderProperty("messageStatus", messageStatus)
    messageLog.addCustomHeaderProperty("xsapcorrelationid", acknowledgeMessageJson.xsapcorrelationid)
    messageLog.addCustomHeaderProperty("messageId", acknowledgeMessageJson.id)

    message.setProperty('messageStatus', messageStatus)
    if (messageStatus.equals(ACKNOWLEDGE_MESSAGE_STATUS_SUCCESS)) {
        messageLog.addCustomHeaderProperty("signavioControlId", data.externalId)
        messageLog.addCustomHeaderProperty("ramControlId", data.controlId)

        def ramHost = message.getProperty('ramHost')
        RamControlInfo controlInfo = new RamControlInfo(data.controlId, data.displayId, data.externalId, String.format(ADDRESS_FORMAT, ramHost, data.controlId, data.controlId))
        message.setProperty('signavioControlId', data.externalId)
        message.setProperty('ramControl', controlInfo)
    } else {
        messageLog.addAttachmentAsString("Failure Message Body", JsonOutput.prettyPrint(JsonOutput.toJson(acknowledgeMessageJson)), "text/plain")
    }

    return message
}

@CompileStatic
class RamControlInfo {
    String controlId
    String displayId
    String externalId
    String url

    RamControlInfo(String controlId, String displayId, String externalId, String url) {
        this.controlId = controlId
        this.displayId = displayId
        this.externalId = externalId
        this.url = url
    }
}

