import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.transform.Field

@Field public static final String FAILURE_ACKNOWLEDGE_EMAIL_BODY_FORMAT = 'Integration Flow Name: %s\nMessage Processing Log ID: %s\nMessage Processing Log Correlation ID: %s\nTimestamp: %s\nException Message: %s\n'

// Version 1.0
// save attachment to log and build error email body
Message processData(Message message) {
    Map<String, Object> map = message.getProperties()
    Map<String, Object> headers = message.getHeaders()
    
    def addToLogFlag = map.getOrDefault("ErrorLogAttachments", "No") == "Yes"
    String headersText = ''
    def body = message.getBody(java.io.Reader)
    def jsonModel = new JsonSlurper().parse(body)

    if (addToLogFlag) {
        // add headers
        headers.each { k, v -> headersText += "${k}: ${v}" + "\n" }
        // headers.each { k, v ->
        //     headersText += k + ': ' + v + '\n'
        // }
        // save headers as an attachment
        def messageLog = messageLogFactory.getMessageLog(message)

        messageLog.addAttachmentAsString("Headers", headersText, "text/plain")
    }
    def emailBody = String.format(FAILURE_ACKNOWLEDGE_EMAIL_BODY_FORMAT, map.get("iFlowName"), map.get('SAP_MessageProcessingLogID'), headers.get('SAP_MplCorrelationId'), map.get('CamelCreatedTimestamp'), JsonOutput.toJson(jsonModel))
    message.setBody(emailBody)
    return message
}