import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.transform.Field

@Field public static final String SIGNAVIO_CONTROL_UPDATE_BODY_FORMAT = 'title=%s&category=%s&description=%s&force=true&attachments=%s&metaDataValues=%s&formats=%s'
@Field public static final String URL_ENCODE_CHARSET = "UTF-8"

def Message processData(Message message) {
    def signavioUpdateControl = message.getProperty('signavioControl')
    encodeUrlInSignavioControl(signavioUpdateControl)

    def attachments = JsonOutput.toJson(signavioUpdateControl.attachments)
    def metaDataValues = JsonOutput.toJson(signavioUpdateControl.metaDataValues)
    def formats = JsonOutput.toJson(signavioUpdateControl.formats)
    def signavioUpdateBody = String.format(SIGNAVIO_CONTROL_UPDATE_BODY_FORMAT, signavioUpdateControl.title, signavioUpdateControl.category, signavioUpdateControl.description, attachments, metaDataValues, formats)
    message.setBody(signavioUpdateBody)

    return message
}

static void encodeUrlInSignavioControl(signavioUpdateControl) {
    for (def attachment : signavioUpdateControl.attachments) {
        encodeUrl(attachment)
    }

    for (def metaData : signavioUpdateControl.metaDataValues) {
        encodeUrl(metaData.value)
        if (metaData.value instanceof List) {
            for (def metaDataValueItem : metaData.value) {
                encodeUrl(metaDataValueItem)
            }
        }
    }
}

static void encodeUrl(def object) {
    if (object instanceof Map) {
        if (object.url != null) {
            object.url = URLEncoder.encode(object.url, URL_ENCODE_CHARSET)
        }
    }
}