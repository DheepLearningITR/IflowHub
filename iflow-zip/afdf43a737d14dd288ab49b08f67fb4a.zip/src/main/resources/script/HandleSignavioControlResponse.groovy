import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.CompileStatic
import groovy.transform.Field

@Field public static final String CONTROL_URL_LABEL = 'RAM Control'
@Field public static final String META_CONTROLDISPLAYID = 'meta-ramcontrolid'
@Field public static final String META_CONTROLID = 'meta-ramcontroltechnicalid'

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def jsonBody = new JsonSlurper().parse(body)
    def ramControl = message.getProperty("ramControl")
    def signavioControl = new SignavioControl(jsonBody.title, jsonBody.description, jsonBody.category.split("/")[2], jsonBody.attachments, jsonBody.metaDataValues, jsonBody.formats)

    def needToUpdateSignavioControl = false

    if (signavioControl.metaDataValues[META_CONTROLDISPLAYID] != ramControl.displayId || signavioControl.metaDataValues[META_CONTROLID] != ramControl.controlId) {
        needToUpdateSignavioControl = true
        signavioControl.metaDataValues[META_CONTROLDISPLAYID] = ramControl.displayId
        signavioControl.metaDataValues[META_CONTROLID] = ramControl.controlId
    }

    if(signavioControl.attachments == null) {
        signavioControl.attachments = []
    }

    def controlUrlExistInAttachment = false
    for (def attachment : signavioControl.attachments) {
        if (attachment instanceof Map) {
            if (attachment.label == CONTROL_URL_LABEL) {
                controlUrlExistInAttachment = true
                break
            }
        }
    }

    if (!controlUrlExistInAttachment) {
        needToUpdateSignavioControl = true
        def grcControlUrl = [label: CONTROL_URL_LABEL, url: ramControl.url]
        signavioControl.attachments.add(grcControlUrl)
    } else {
        for (def attachment : signavioControl.attachments) {
            if (attachment instanceof Map) {
                if (attachment.label == CONTROL_URL_LABEL && attachment.url != ramControl.url) {
                    needToUpdateSignavioControl = true
                    attachment.url = ramControl.url
                    break
                }
            }
        }
    }

    message.setProperty("needToUpdateSignavioControl", needToUpdateSignavioControl)
    message.setProperty("signavioControl", signavioControl)
    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addCustomHeaderProperty("needToUpdateSignavioControl", needToUpdateSignavioControl.toString())
    return message
}

@CompileStatic
class SignavioControl {
    String title
    String description
    String category
    List attachments
    Map<String, String> metaDataValues
    Map<String, String> formats


    SignavioControl(String title, String description, String category, List attachments, Map<String, String> metaDataValues, Map<String, String> formats) {
        this.title = title
        this.description = description
        this.category = category
        this.attachments = attachments
        this.metaDataValues = metaDataValues
        this.formats = formats
    }
}
