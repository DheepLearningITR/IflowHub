/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonBuilder;
def Message processData(Message message) {
//get the message Body  as string object
        def body = message.getBody(String.class);
        def jsonSlurper = new JsonSlurper();
         //convert the body to a json object
         def jsonObject = jsonSlurper.parseText(body.toString());
         //get the poll from  json object
        def root = jsonObject.root;
        if(root != null)
        {
            
            def polls= jsonObject.root.polls;
            def jsonOP;
            
            if(polls == [""])
            {
                jsonOP = [];
            }
            
            //  else
            //  {
            //      def pollArray = [];
            //     pollArray.add(polls);
            //     jsonOP = JsonOutput.toJson(pollArray);
                
            //  }
            else
                jsonOP = JsonOutput.toJson(polls);
            message.setBody(jsonOP);
        }
        return message;
}