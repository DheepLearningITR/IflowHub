
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonBuilder;
def Message processData(Message message) {
//get the message Body  as string object
        def body = message.getBody(String.class);
        def jsonSlurper = new JsonSlurper();
         //convert the body to a json object
         def jsonObject = jsonSlurper.parseText(body.toString());
         //get the poll from  json object
        def root = jsonObject.root;
        if(root != null)
        {
            
            def resourcesviewed= jsonObject.root.resourcesviewed;
            def jsonOP;
            
            if(resourcesviewed == [""])
            {
                jsonOP = [];
            }
            
           
            else
                jsonOP = JsonOutput.toJson(resourcesviewed);
            message.setBody(jsonOP);
        }
        return message;
}