import com.sap.gateway.ip.core.customdev.util.Message;

import java.util.HashMap; 

import com.sap.it.api.ITApiFactory;

import com.sap.it.api.securestore.SecureStoreService;
import groovy.json.*;
import com.sap.it.api.securestore.UserCredential;

def Message processData(Message message)

{
    def properties = message.getProperties();
	def service = ITApiFactory.getApi(SecureStoreService.class, null);
	def token_id = properties.get("token");
	def secret_id = properties.get("secret");
	def apiToken = service.getUserCredential(token_id);
	def apiSecret = service.getUserCredential(secret_id);
	def messageLog = messageLogFactory.getMessageLog(message);
	def headers = message.getHeaders();
	// Retrieve all the incoming headers to construct the HTTPS url to ON24
	def clientid = headers.get("provideraccountid").toString();
	def eventid = headers.get("externaleventid").toString();

	if (apiToken == null) {
		throw new IllegalStateException("No credential found for alias "+ token_id);
	}
	if (apiSecret == null) {
		throw new IllegalStateException("No credential found for alias "+ secret_id);
	}
	// Set the headers for further calls
    message.setHeader("accessTokenKey",new String(apiToken.getPassword()));
	message.setHeader("accessTokenSecret",new String(apiSecret.getPassword()));
	message.setHeader("clientId",clientid);
	message.setHeader("eventId",eventid);
	message.setProperty("on24ResourceUrl", "https://apiqa.on24.com/v2/client/"+clientid+"/event/"+eventid+"/resource");
	return message;

}