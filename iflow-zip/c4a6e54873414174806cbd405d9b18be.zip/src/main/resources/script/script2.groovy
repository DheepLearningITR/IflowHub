import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import java.time.LocalDate
import groovy.time.TimeCategory
import java.util.Date
import java.text.SimpleDateFormat

def Message processData(Message message) {
 	JsonSlurper jsonSlurper = new JsonSlurper()
    Reader body = message.getBody(java.io.Reader)
    def eventType
    def stMap
    def input 
    def catenaXId
    try {
        catenaXId = message.getHeaders().get("catenaXId")
        stMap = new JsonSlurper().parse(body)
        def inputMap = stMap.ctxObjects.find{it.ctxId == catenaXId}
        if(inputMap.ProductSerialNumber && !(inputMap.ReceivedSerializedProduct)) {
            eventType = "ProduceSerialNumberEvent"
            input = inputMap.ProductSerialNumber
        }else if(inputMap.ProductBatch &&  !(inputMap.ReceivedProductBatch )) {
            eventType = "ProduceEvent"
            input = inputMap.ProductBatch
        }
    }catch(def e){
        	message.setHeader("Content-Type", "application/json" + "; charset=utf-8" )
 	        message.setBody(" item ("+catenaXId+") does not exist  ")
	        return message
    }

	def resultMap = [:]
    if (input ){
        def localIdentifiersArray = []
        def localIdentifiersMap = [:]
        def manufacturingInformationMap = [:]
        def partTypeInformationMap = [:]

        if(eventType == "ProduceSerialNumberEvent"){
            localIdentifiersMap.key = "partInstanceID"
            localIdentifiersMap.value = input.serialId
            localIdentifiersArray << localIdentifiersMap
        }else{
            localIdentifiersMap.key = "batchId"
            localIdentifiersMap.value = input.batchId
            localIdentifiersArray << localIdentifiersMap
        }
        
        resultMap.localIdentifiers = localIdentifiersArray
        manufacturingInformationMap.date = getFormatedDate(input.creationDate)
        manufacturingInformationMap.country = input.location
        resultMap.manufacturingInformation = manufacturingInformationMap
        resultMap.catenaXId = "urn:uuid:"+stMap.ctxObjects[0].ctxId
        if(eventType == "ProduceSerialNumberEvent"){
            partTypeInformationMap.manufacturerPartId = input.productId
            partTypeInformationMap.customerPartId = input.productId
            partTypeInformationMap.classification = "product"
            partTypeInformationMap.nameAtManufacturer = input.productName
            partTypeInformationMap.nameAtCustomer = input.productName
            resultMap.partTypeInformation = partTypeInformationMap
        } else {
            partTypeInformationMap.manufacturerPartId = input.productId
            partTypeInformationMap.classification = "product"
            partTypeInformationMap.nameAtManufacturer = input.productName
            resultMap.partTypeInformation = partTypeInformationMap
        }
    }else{
        message.setHeader("Content-Type", "application/json" + "; charset=utf-8" )
 	    message.setBody(" item ("+catenaXId+") does not exist  ")
        return message
    }
	
    
    def mtJson = new JsonBuilder(resultMap)
	message.setHeader("Content-Type", "application/json" + "; charset=utf-8" )
	message.setBody(mtJson.toPrettyString())
	return message
}

def getFormatedDate(def inDate) {
    if(inDate == null ) return ""
    Date date1 = new SimpleDateFormat("yyyyMMdd").parse(inDate)
    def delta = Math.abs(new Random().nextInt() % 9000000) +1000000
    date1 = new Date(date1.getTime()+delta)
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    return sdf.format(date1.getTime())
}