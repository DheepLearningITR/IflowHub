import com.sap.gateway.ip.core.customdev.util.Message;

def Message storeRootMessageID(Message message) {
    def headers = message.getHeaders() as Map<String, Object>
    def messageID = headers.get("SAP_MessageProcessingLogID")
    message.setHeader("OSTA_RootMessageID", messageID)
    return message;
}

def Message markWithAggregationId(Message message) {
    def headers = message.getHeaders() as Map<String, Object>
    def messageLog = messageLogFactory.getMessageLog(message);

    messageLog.addCustomHeaderProperty("AggregationID", headers.get("OSTA_aggregationID"));
    return message;
}

def Message markWithRootIdAndAggregationId(Message message) {
    def headers = message.getHeaders() as Map<String, Object>
    def messageLog = messageLogFactory.getMessageLog(message);

    messageLog.addCustomHeaderProperty("RootMessageID", headers.get("OSTA_RootMessageID"));
    messageLog.addCustomHeaderProperty("AggregationID", headers.get("OSTA_aggregationID"));
    return message;
}