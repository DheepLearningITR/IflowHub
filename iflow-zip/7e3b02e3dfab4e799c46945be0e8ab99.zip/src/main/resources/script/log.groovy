import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.transform.Field;
import groovy.json.JsonOutput;
import groovy.xml.XmlUtil;

// Downstream
@Field String ORIGINAL_JSON_PAYLOAD = 'Inbound POS Transactions JSON';
@Field String TRANSLATED_XML_PAYLOAD = 'Inbound POS Transactions XML';
@Field String SPLITTED_JSON_PAYLOAD = 'Splitted Inbound POS Transactions XML';
@Field String MAPPED_S4_PAYLOAD = 'Outbound POS Transactions XML';
@Field String IFLOW_JSON_EXCEPTION_RESPONSE = 'iFlow Error Response JSON';

//Upstream
@Field String S4_MESSAGE_XML = '1 - Inbound Message XML';
@Field String IFLOW_MESSAGE_XML = '2 - Outbound Message XML';
@Field String IFLOW_MESSAGE_JSON = '3 - Outbound Message JSON';
@Field String RESPONSE_JSON = '4 - OSTA Response JSON';

//Common
@Field String UNKNOWN_ERROR = 'An unknown error occurred.';

def Message logOriginalJsonPayload(Message message) {
    return log(ORIGINAL_JSON_PAYLOAD, false, message);
}

def Message logXmlPayload(Message message) {
    return log(TRANSLATED_XML_PAYLOAD, true, message);
}

def Message logMappedS4Payload(Message message) {
    return log(MAPPED_S4_PAYLOAD, true, message);
}

def Message logModJsonPayload(Message message) {
    return log(SPLITTED_JSON_PAYLOAD, true, message);
}

def Message logS4MessageXML(Message message) {
    return log(S4_MESSAGE_XML, true, message);
}

def Message logiFlowMessageJson(Message message) {
    return log(IFLOW_MESSAGE_JSON, false, message);
}

def Message logiFlowMessageXML(Message message) {
    return log(IFLOW_MESSAGE_XML, true, message);
}

def Message logResponseJson(Message message) {
    return log(RESPONSE_JSON, false, message);
}

def Message logUnknownError(Message message) {
    return log(UNKNOWN_ERROR, false, message);
}

def Message log(String title, boolean isXML, Message message) {

    def body = message.getBody(java.lang.String) as String;
    def headers = message.getHeaders() as Map<String, Object>;
    def properties = message.getProperties() as Map<String, Object>;

    def propertiesAsString ="\n";
    properties.each{ iterator -> propertiesAsString = propertiesAsString + "${iterator}" + "\n" };

    def headersAsString ="\n";
    headers.each{ iterator -> headersAsString = headersAsString + "${iterator}" + "\n" };

    def messageLog = messageLogFactory.getMessageLog(message);
    def prettyPrintedBodyString = "\n";

    if((messageLog != null) && (body != "")) {
        if (isXML) {
            prettyPrintbodyString = XmlUtil.serialize(body);
        }
        else {
            prettyPrintbodyString = JsonOutput.prettyPrint(body);
        }
    }

    messageLog.addAttachmentAsString(title , "\n Properties \n ----------   \n" + propertiesAsString +
            "\n Headers \n ----------   \n" + headersAsString +
            "\n Body \n ----------  \n\n" + prettyPrintbodyString, "text/plain");

    return message;
}

def Message logMessageSentToS4(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("Data has been sent to S4" , "OK", "text/plain");
    return message;
}

def Message logExceptionDetails(Message message) {
    def properties = message.getProperties();

    String errorMessage = "";
    def exceptionProperty = properties.get("CamelExceptionCaught");

    // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
    if (exceptionProperty.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
        errorMessage = exceptionProperty.getResponseBody();
    }

    if (!errorMessage.trim()) {
        errorMessage = exceptionProperty.message;
    }

    def headers = message.getHeaders() as Map<String, Object>;

    def propertiesAsString ="\n";
    properties.each{ iterator -> propertiesAsString = propertiesAsString + "${iterator}" + "\n" };
    def headersAsString ="\n";
    headers.each{ iterator -> headersAsString = headersAsString + "${iterator}" + "\n" };

    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString(IFLOW_JSON_EXCEPTION_RESPONSE ,
            "\n Properties \n ----------   \n" + propertiesAsString +
            "\n Headers \n ----------   \n" + headersAsString +
            "\n Exception \n ----------  \n\n" + errorMessage, "text/plain");

    return message;
}

def Message logRetryConfiguration(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def properties = message.getProperties() as Map<String, Object>;
    def acknAttempts = properties.get('retryAcknowledgementAttempts');

    messageLog.addAttachmentAsString("Sending terminated", "Retry Configuration:\n"
            + "--------------------\n"
            + "Retry acknowledgement attempts: " + acknAttempts, "text/plain");

    return message;
}

def Message logAcknowledgement(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def headers = message.getHeaders() as Map<String, Object>;
    def aggregationID = headers.get("OSTA_aggregationID");

    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("Sending Acknowledgement back to OSTA" , "Message\n" +
            "----------\n" +
            "AggregationID: " + aggregationID +
            "\nBody:\n" + body, "text/plain");
    return message;
}