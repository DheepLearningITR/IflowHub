import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def map = message.getProperties();
    def successProductList = map.get("SuccessProductList");
    def failedProductList = map.get("FailedProductList");
    
    if(messageLog != null){
        if(!successProductList.isEmpty()){
            messageLog.addAttachmentAsString("Success offering IDs", successProductList.toString(), "text/xml");
        }
        if(!failedProductList.isEmpty()){
                messageLog.addAttachmentAsString("All failed offering IDs", failedProductList.toString(), "text/xml");

            }
    }
    return message;
}
