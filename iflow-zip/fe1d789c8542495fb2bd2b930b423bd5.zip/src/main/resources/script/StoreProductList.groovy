import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper


def Message processData(Message message)
{
    def jsonSlurper = new JsonSlurper();
    def body = message.getBody(String.class);
    def originalPayload = jsonSlurper.parseText(body);

    def properties = message.getProperties();
    def successProductList = properties.get("SuccessProductList");
    def failedProductList = properties.get("FailedProductList");

    if(null == successProductList || "" == successProductList || successProductList.size() == 0)
    {
        successProductList = [];
    }
    
    if(null == failedProductList || "" == failedProductList || failedProductList.size() == 0)
    {
        failedProductList = [];
    }

    //store successful & failed product list into property
    def successList = originalPayload.data.Response.Success;
    def failedList = originalPayload.data.Response.Failure;
    for (def success : successList) {
        successProductList.add(success.OfferingID);
    }
    for (def failure : failedList) {
        failedProductList.add(failure.OfferingID);
    }
    
    
    message.setProperty("SuccessProductList", successProductList);
    message.setProperty("FailedProductList", failedProductList);
    return message;
}