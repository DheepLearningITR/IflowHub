import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message)
{
	def jsonSlurper = new JsonSlurper();
    def body = message.getBody(String.class);
    def product = jsonSlurper.parseText(body);
    def value = product.value;
    if(null == value || value.size() == 0)
    {
        throw new Exception("No data found");
    }
    return message;
}