import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;


def Message setMessageProperties(Message message) {
    //Get message and parse to json
    def json = message.getBody(java.io.Reader)
    def data = new JsonSlurper().parse(json)
    
    //messageHeader
    message.setHeader("SAP_ApplicationID", data.messageHeader.id)
    
    
    message.setProperty("P_SenderParty", data.messageHeader.senderCommunicationSystemDisplayId)
    message.setProperty("P_ReceiverParty", data.messageHeader.receiverCommunicationSystemDisplayId)

   
    message.setProperty("P_OpportunityId", data.messageRequests[0].body.id)
    message.setProperty("P_OpportunityDisplayId", data.messageRequests[0].body.displayId)
    
    message.setProperty("P_messageHeaderId", java.util.UUID.randomUUID())
    message.setProperty("P_messageRequestHeaderId", java.util.UUID.randomUUID())
    
    // for idempotence
    
    message.setHeader("RequestID", data.messageHeader.id)
    message.setHeader("RepeatabilityCreation", data.messageHeader.senderCommunicationSystemDisplayId)
    return message
}

def Message readExceptionMessage(Message message){
    def body = message.getBody(java.io.Reader)
    def data = new XmlSlurper().parse(body)
    String errorMessage = data.message
    message.setBody(errorMessage)
    return message
}