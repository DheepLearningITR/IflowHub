import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

Map package_parameter_checks = [
  'Notify_Service_Order_Update_from_SAP_Field_Service_Management_to_SAP_S4HANA_Cloud': [
    'Header Extension Enabled': [
      'description': 'More - Header Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Service Order Note Language': [
      'description': 'More - Service Order Note Language',
      'size': 2,
      'mandatory': true
    ],
    'ExtensionEnabled': [
      'description': 'More - ExtensionEnabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Address': [
      'description': 'Receiver: Service_Order_Item_Update - Address',
      'type': 'url',
      'mandatory': true,
      'default' : 'https://<MYS4HANA-api.s4hana.ondemand.com>:443/sap/opu/odata/sap/API_SERVICE_ORDER_SRV'
    ],
    'Timeout': [
      'description': 'Receiver: Service_Order_Item_Update - Timeout (in min)',
      'type': 'number',
      'mandatory': true
    ],
    'CredentialName': [
      'description': 'Receiver: Service_Order_Item_Update - Credential Name',
      'mandatoryif': [ 'Authentication', 'Basic' ],
      'default' : '<SAP S/4HANA Cloud Credential Name>'
    ],
    'LocationID': [
      'description': 'Receiver: Service_Order_Item_Update - Location ID',
      'mandatoryif': [ 'ProxyType', 'On-Premise']
    ],
    'item_update_extension_customer_iflow': [
      'description': 'Receiver: Extension_ProcessDirect - Address',
      'mandatoryif': [ 'ExtensionEnabled', 'true'],
      'default' : 'item_update_cloud_extension_customer_iflow'
    ],
    'Service Order Header Note Type': [
      'description': 'More - Service Order Header Note Type',
      'size': 4,
      'mandatory': true
    ],
    'Private_Key': [
      'description': 'Receiver: Service_Order_Item_Update - Private Key Alias',
      'mandatoryif': [ 'Authentication', 'Client Certificate']
    ],
    'ProcessDirectAddress': [
      'description': 'Sender: SAP_FSM - Address',
      'mandatory': true
    ],
    'Service Order Header Problem Description Type': [
      'description': 'More - Service Order Header Problem Description Type',
      'size': 4,
      'mandatory': true
    ],
    'Header Extension Address': [
      'description': 'Receiver: Header_Extension_ProcessDirect - Address',
      'mandatoryif': [ 'Header Extension Enabled', 'true'],
      'default' : 'header_update_cloud_extension_customer_iflow'
    ],
    'Authentication': [
        'description': 'Receiver: Service_Order_Item_Update - Authentication'
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'User Status for Completed Activity': [
      'description': 'More - User Status for Completed Activity',
      'size': 5
    ],
    'ProxyType': [
      'description': 'Receiver: Service_Order_Item_Update - Proxy Type'
    ],
    'Service Order Item Note Type': [
      'description': 'More - Service Order Item Note Type',
      'size': 4,
      'mandatory': true
    ],
    'Rejection Reason Code': [
      'description': 'More - Rejection Reason Code',
      'size': 2
    ]
  ],
  'Replicate_Attachments_from_SAP_Field_Service_Management_to_SAP_S4HANA_Cloud': [
    'S4HANA Proxy Type': [
      'description': 'Receiver: S4HanaCloud - Proxy Type'
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Attachment - FSM Host',
      'type': 'hostname',
      'mandatory': true,
      'default': 'https://<cluster.coresuite.com>'
    ],
    'S4HANA Host': [
      'description': 'Receiver: S4HanaCloud - S4HANA Host',
      'type': 'hostname',
      'mandatory': true,
      'default': 'https://<MYS4HANA-api.s4hana.ondemand.com>:443'
    ],
    'User Role': [
      'description': 'Sender: FSM - User Role',
      'mandatory': true
    ],
    'S4HANA Credentials': [
      'description': 'Receiver: S4HanaCloud - Credential Name',
      'mandatoryif': ['S4HANA Authentication', 'Basic'],
      'default': '<SAP S/4HANA Cloud Credential Name>'
    ],
    'FSM Company ID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Company Name',
      'default': '<FSM_Company_ID>'
    ],
    'FSM Account Name': [
      'description': 'More - FSM Account Name',
      'group': 'Name',
      'alternative' : 'FSM Account ID',
      'default': '<FSM Account Name>'
    ],
    'Endpoint': [
      'description': 'Sender: FSM - Address',
      'mandatory': true
    ],
    'Private Key Alias': [
      'description': 'Receiver: S4HanaCloud - Private Key Alias',
      'mandatoryif' : ['S4HANA Authentication', 'Client Certificate']
    ],
    'FSM Company Name': [
      'description': 'More - FSM Company Name',
      'group': 'Name',
      'alternative' : 'FSM Company ID',
      'default': '<FSM Company Name>'
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'S4HANA Authentication': [
        'description': 'Receiver: S4HanaCloud - Authentication'
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'S4HANA Location ID': [
      'description': 'Receiver: S4HanaCloud - Location ID',
      'mandatoryif' : ['S4HANA Proxy Type', 'On-Premise']
    ],
    'FSM Account ID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Account Name',
      'default' : '<FSM_Account_ID>'
    ],
    'FSM Credentials': [
      'description': 'Receiver: FSM_Attachment - Credential Name',
      'mandatory': true,
      'default': '<FSM Credentials>'
    ]
  ],
  'Replicate_Confirmed_Service_from_SAP_Field_Service_Management_to_SAP_S4HANA_Cloud': [
    'Post Exit Address': [
      'description': 'Receiver: Customer_iFlow_Address - Address',
      'mandatoryif': [ 'Post Exit Enable', 'true'],
      'default' : '<customer_iflow_address>'
    ],
    'Authentication_For_ServiceOrder': [
        'description': 'Receiver: ReadServiceOrder - Authentication'
    ],
    'Address': [
      'description': 'Sender: FSM - Address',
      'mandatory': true
    ],
    'Address_For_ServiceOrder': [
      'description': 'Receiver: ReadServiceOrder - Address',
      'type': 'url',
      'mandatory': true,
      'default' : 'https://<MYS4HANA-api.s4hana.ondemand.com>:443/sap/opu/odata/sap/API_SERVICE_ORDER_SRV'
    ],
    'Timeout': [
      'description': 'Receiver: ReadServiceOrder - Timeout (in min)',
      'type': 'number',
      'mandatory': true
    ],
    'Authentication_For_ServiceConfirmation': [
        'description': 'Receiver: Create_Service_Confirmation - Authentication'
    ],
    'Item Note Type': [
      'description': 'More - Item Note Type',
      'size': 4,
      'mandatory': true
    ],
    'Private_Key_Alias': [
      'description': 'Receiver: ReadServiceOrder - Private Key Alias',
      'mandatoryif': [ 'Authentication_For_ServiceOrder', 'Client Certificate']
    ],
    'Location_ID': [
      'description': 'Receiver: ReadServiceOrder - Location ID',
      'mandatoryif': [ 'Proxy_Type_For_Visiting_S4', 'On-Premise']
    ],
    'Private_Key_Alias_For_ServiceConfirmation': [
      'description': 'Receiver: Create_Service_Confirmation - Private Key Alias',
      'mandatoryif': [ 'Authentication_For_ServiceConfirmation', 'Client Certificate']
    ],
    'Item Note Language': [
      'description': 'More - Item Note Language',
      'size': 2,
      'mandatory': true
    ],
    'Address_For_ServiceConfirmation': [
      'description': 'Receiver: Create_Service_Confirmation - Address',
      'type': 'url',
      'mandatory': true,
      'default' : 'https://<MYS4HANA-api.s4hana.ondemand.com>:443/sap/opu/odata/sap/API_SERVICE_CONFIRMATION_SRV'
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',        
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'Proxy_Type_For_Visiting_S4': [
      'description': 'Receiver: Create_Service_Confirmation - Proxy Type',
    ],
    'Credential_For_ServiceConfirmation': [
      'description': 'Receiver: Create_Service_Confirmation - Credential Name',
      'mandatoryif': [ 'Authentication_For_ServiceConfirmation', 'Basic' ],
      'default' : '<SAP S/4HANA Cloud Credential Name>'
    ],
    'Credential_For_ServiceOrder': [
      'description': 'Receiver: ReadServiceOrder - Credential Name',
      'mandatoryif': [ 'Authentication_For_ServiceOrder', 'Basic' ],
      'default' : '<SAP S/4HANA Cloud Credential Name>'
    ],
    'Post Exit Enable': [
      'description': 'More - Post Exit Enable',
      'type': 'boolean',
      'mandatory': true
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Confirm_Time_and_Material - FSM Host',
      'type': 'hostname',
      'default': 'https://customer-cluster.coresuite.com'
    ],
    'FSM Credentials': [
      'description': 'Receiver: FSM_Confirm_Time_and_Material - Credential Name',
      'default': '<FSM Credentials>',
      'mandatoryif': ['FSM Host']
    ],
    'FSM Timeout': [
      'description': 'Receiver: FSM_Confirm_Time_and_Material - Timeout (in ms)',
      'type': 'number',
      'mandatoryif': ['FSM Host']
    ],
    'FSM Account ID': [
      'description': 'More - FSM Account ID',
      'type': 'number',
      'default': '<FSM_Account_ID>',
      'mandatoryif': ['FSM Host']
    ],
    'FSM Company ID': [
      'description': 'More - FSM Company ID',
      'type': 'number',
      'default': '<FSM_Company_ID>',
      'mandatoryif': ['FSM Host']
    ]    
  ],
  'Replicate_Service_Call_from_SAP_Field_Service_Management_to_SAP_S4HANA_Cloud': [
    'Service Order Note Language': [
      'description': 'More - Service Order Note Language',
      'size': 2,
      'mandatory': true
    ],
    'address': [
      'description': 'Sender - Address',
      'mandatory': true
    ],
    'Timeout': [
      'description': 'Receiver: FSM_Create_or_Update_ServiceCall_withActivities - Timeout (in millisecond)',
      'type': 'number',
      'mandatory': true
    ],
    'Credential Name': [
      'description': 'Receiver: S4HANA_Cloud_CreateServiceOrder - Credential Name',
      'mandatoryif': [ 'Authentication', 'Basic' ],
      'default' : '<SAP S/4HANA Cloud Credential Name>'
    ],
    'S4HANA Host': [
      'description': 'Receiver: S4HANA_Cloud_CreateServiceOrder - S4HANA Host and port',
      'type': 'hostname',
      'mandatory': true,
      'default' : 'https://<MYS4HANA-api.s4hana.ondemand.com>:443'
    ],
    'FSM Host': [
      'description': 'Receiver: SAP_FSM_Update - FSM Host',
      'type': 'hostname',
      'mandatory': true,
      'default' : 'https://<cluster.coresuite.com>'
    ],
    'Service Order Header Note Type': [
      'description': 'More - Service Order Header Note Type',
      'size': 4,
      'mandatory': true
    ],
    'Proxy Type': [
      'description': 'Receiver: S4HANA_Cloud_CreateServiceOrder - Proxy Type'
    ],
    'FSM User': [
      'description': 'More - FSM User',
      'default' : '<FSM User>'
    ],
    'FSM Company ID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Company Name',
      'default': '<FSM_Company_ID>'
    ],
    'FSM Account Name': [
      'description': 'More - FSM Account Name',
      'group': 'Name',
      'alternative' : 'FSM Account ID',
      'default': '<FSM_Account_Name>'
    ],
    'Location ID': [
      'description': 'Receiver: S4HANA_Cloud_CreateServiceOrder - Location ID',
      'mandatoryif': [ 'Proxy Type', 'On-Premise']
    ],
    'Service Order Header Problem Description Type': [
      'description': 'More - Service Order Header Problem Description Type',
      'size': 4,
      'mandatory': true
    ],
    'FSM Company Name': [
      'description': 'More - FSM Company Name',
      'group': 'Name',
      'alternative' : 'FSM Company ID',
      'default': '<FSM_Company_Name>'
    ],
    'Authentication': [
        'description': 'Receiver: S4HANA_Cloud_CreateServiceOrder - Authentication'
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'FSM Account ID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Account Name',
      'default' : '<FSM_Account_ID>'
    ],
    'Post Mapping Extension Address': [
      'description': 'Receiver: Customer_Post_Mapping_Extension - Address',
      'mandatoryif': [ 'Post Mapping Extension Enabled', 'true']
    ],
    'FSM Credentials': [
      'description': 'Receiver: SAP_FSM_Update - Credential Name',
      'mandatory': true,
      'default' : '<FSM Credentials>'
    ],
    'Post Mapping Extension Enabled': [
      'description': 'More - Post Mapping Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ]
  ],
  'Replicate_Service_Order_from_SAP_S4HANA_Cloud_to_SAP_Field_Service_Management': [
    'Post_Mapping_Extension_Enable': [
      'description': 'More - Post_Mapping_Extension_Enable',
      'type': 'boolean',
      'mandatory': true
    ],
    'EnableMultiCompanyReplication': [
      'description': 'More - EnableMultiCompanyReplication',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable pre-exit MultiCompany': [
      'description': 'More - Enable pre-exit MultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
    'Address': [
      'description': 'Sender - Address',
      'mandatory': true
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Read_ServiceCall - FSM Host',
      'type': 'emailhostname',
      'mandatory': true,
      'default' : '<FSM_host>'
    ], 
    'Service Order Header Note Type': [
      'description': 'More - Service Order Header Note Type',
      'size': 4,
      'mandatory': true
    ],
    'autoCreateActivity': [
      'description': 'More - autoCreateActivity',
      'type': 'boolean',
      'mandatory': true
    ],
    'Location_ID': [
      'description': 'Receiver: S4HANA_Query - Location ID',
      'mandatoryif': [ 'Proxy_Type', 'On-Premise']
    ],
    'Private_Key': [
      'description': 'Receiver: S4HANA_Query - Private Key Alias',
      'mandatoryif': [ 'Authentication_Method_S4', 'Client Certificate']
    ],
    'Service Order Item Note Language': [
      'description': 'More - Service Order Item Note Language',
      'size': 2,
      'mandatory': true
    ],
    'Service Order Item Note Type': [
      'description': 'More - Service Order Item Note Type',
      'size': 4,
      'mandatory': true
    ],
    'Service Order Header Note Language': [
      'description': 'More - Service Order Header Note Language',
      'size': 2,
      'mandatory': true
    ],
    'Authentication_Method_S4': [
      'description': 'Receiver: S4HANA_Query - Authentication'
    ],
    'AccountID': [
      'description': 'More - AccountID',
      'group': 'ID',
      'alternative' : 'account',
      'default' : '<FSM_Account_ID>'
    ],
    'CompanyID': [
      'description': 'More - CompanyID',
      'group': 'ID',
      'alternative' : 'company',
      'default': '<FSM_Company_ID>'
    ],
    'account': [
      'description': 'More - account',
      'group': 'Name',
      'alternative' : 'AccountID',
      'default': '<FSM_Account>'
    ],
    'company': [
      'description': 'More - company',
      'group': 'Name',
      'alternative' : 'CompanyID',
      'default': '<FSM_Company>'
    ],
    'CredentialName_OData': [
      'description': 'Receiver: S4HANA_Query - Credential Name',
      'mandatoryif': [ 'Authentication_Method_S4', 'Basic'],
      'default' : '<SAP S/4HANA Cloud Credential Name>'
    ],
    'Credential Name': [
      'description': 'Receiver: FSM_Read_ServiceCall - Credential Name',
      'mandatory': true,
      'default' : '<FSM Credential Name>'     
    ],
    'Post_Mapping_Extension_Address': [
      'description': 'Receiver: Customer_Post_Mapping_Extension_iFlow - Address',
      'mandatoryif': [ 'Post_Mapping_Extension_Enable', 'true']
    ],
    'Proxy_Type': [
      'description': 'Receiver: S4HANA_Query - Proxy Type',
    ],
    'S4HANA Host Port': [
      'description': 'Receiver: S4HANA_Query - Address',
      'type': 'hostname',
      'mandatory': true,
      'default' : 'https://<MYS4HANA-api.s4hana.ondemand.com>:443'
    ],
    'User_Role': [
      'description': 'Sender - User Role',
      'mandatory': true
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'Transaction Types Used in Replication': [
      'description': 'More - Transaction Types Used in Replication',
      'separator': '\\|',
      'mandatory': true
    ],
    'user': [
      'description': 'More - user',
      'default' : '<FSM_User>'
    ],
    'HTTP_Timeout': [
      'description': 'Receiver: FSM_Read_ServiceCall - Timeout (in ms)',
      'type': 'number',
      'mandatory': true   
    ],
    'Service Order Header Problem Description': [
      'description': 'More - Service Order Header Problem Description',
      'size': 4,
      'mandatory': true
    ]
  ],
  'Route_Payload_from_SAP_Field_Service_Management_to_SAP_S4HANA_Cloud': [
    'Address_ServiceOrder': [
      'description': 'Receiver: Update_Service_Order - Address',
      'mandatory': true
    ],
    'ProcessDirectSODuplicateAct': [
      'description': 'Receiver: Update_Service_Order_Create_Item - Address',
      'mandatory': true
    ],
    'Address Create Service Order': [
      'description': 'Receiver: Create_Service_Order - Address',
      'mandatory': true
    ],
    'Address_ServiceConfirmation': [
      'description': 'Receiver: Create_Service_Confirmation - Address',
      'mandatory': true
    ],
    's4_query_location_id': [
      'description': 'Receiver: Read_Service_Order_Item - Location ID',
      'mandatoryif': [ 's4_query_proxy', 'On-Premise']
    ],
    's4_query_address': [
      'description': 'Receiver: Read_Service_Order_Item - Address',
      'type': 'url',
      'mandatory': true, 
      'default' : 'https://<MYS4HANA-api.s4hana.ondemand.com>:443/sap/opu/odata/sap/API_SERVICE_ORDER_SRV'
    ],
    'Address': [
      'description': 'Sender - Address',
      'mandatory': true
    ],
    'User Role': [
      'description': 'Sender - User Role',
      'mandatory': true
    ],
    's4_query_authentication': [
      'description': 'Receiver: Read_Service_Order_Item - Authentication',
    ],
    's4_query_credential_name': [
      'description': 'Receiver: Read_Service_Order_Item - Credential Name',
      'mandatoryif': [ 's4_query_authentication', 'Basic'],
      'default' : '<SAP S/4HANA Cloud Credential Name>'
    ],
    'Service Call Status Used in Replication': [
      'description': 'More - Service Call Status Used in Replication',
      'separator': '\\|',
      'mandatory': true
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    's4_query_proxy': [
      'description': 'Receiver: Read_Service_Order_Item - Proxy Type'
    ],
    's4_query_private_key': [
      'description': 'Receiver: Read_Service_Order_Item - Private Key Alias',
      'mandatoryif': [ 's4_query_authentication', 'Client Certificate']
    ],
    'Handle Unplanned Items in Backend': [
      'description': 'More - Handle Unplanned Items in Backend',
      'type': 'boolean'
    ]
  ],
  'Send_Error_Email_for_Integration_SAP_S4HANA_Cloud_with_SAP_Field_Service_Management': [
    'Email Server Address': [
      'description': 'Receiver: Email_Receiver - Address',
      'mandatory': true,
      'type': 'emailhostname',
      'default' : '<SMTP_host:port>'
    ],
    'Secret Key Length': [
      'description': 'Receiver: Email_Receiver - Secret Key Length',
      'mandatoryif': [ 'Email Content Encryption Algorithm', 'AEY/CBC/PKCS5Padding']
    ],
    'Email Authentication Method': [
        'description': 'Receiver: Email_Receiver - Authentication'
    ],
    'Email Content Encryption Algorithm': [
      'description': 'Receiver: Email_Receiver - Content Encryption Algorithm',
      'mandatoryif': [ 'Email Signature and Encryption Type', 'S/MIME Encryption', 'S/MIME Signature and Encryption']
    ],
    'Email Credentials for OAuth2': [
      'description': 'Receiver: Email_Receiver - Credential Name',
      'mandatoryif' : [ 'Email Authentication Method', 'OAuth2 Authorization Code']
    ],
    'Email Signature Private Key Alias': [
      'description': 'Receiver: Email_Receiver - Private Key Alias',
      'default' : '<Email Signature Private Key Alias>',
      'mandatoryif': [ 'Email Signature and Encryption Type', 'S/MIME Signature', 'S/MIME Signature and Encryption']
    ],
    'Email Subject': [
      'description': 'Receiver: Email_Receiver - Subject',
      'default' : '<Email Subject>',
      'mandatory': true
    ],
    'Email Sender': [
      'description': 'Receiver: Email_Receiver - From',
      'mandatory': true,
      'default' : '<email_from@email.com>'
    ],
    'Email Protection': [
      'description': 'Receiver: Email_Receiver - Protection',
    ],
    'Email Credentials for User Password': [
      'description': 'Receiver: Email_Receiver - Credential Name',
      'mandatoryif': [ 'Email Authentication Method', 'Encrypted User/Password', 'Plain User/Password'],
      'default' : '<Email Credentials>'
    ],
    'Email Receiver': [
      'description': 'Receiver: Email_Receiver - To',
      'mandatory': true,
      'default' : '<email_to@email.com>'
    ],
    'Email Signature and Encryption Type': [
      'description': 'Receiver: Email_Receiver - Signature and Encryption Type',
    ],
    'Email Connection Location ID': [
      'description': 'Receiver: Email_Receiver - Location ID',
      'mandatoryif': [ 'Email Proxy Type', 'On-Premise']
    ],
    'Email Receiver Bcc': [
      'description': 'Receiver: Email_Receiver - Bcc'
    ],
    'Email Timeout': [
      'description': 'Receiver: Email_Receiver - Timeout (in ms)',
      'type': 'number',
      'mandatory': true
    ],
    'Email Receiver Public Key': [
      'description': 'Receiver: Email_Receiver - Public Key',
      'default' : '<Email Receiver Public Key>',
      'mandatoryif': [ 'Email Signature and Encryption Type', 'S/MIME Encryption', 'S/MIME Signature and Encryption']
    ],
    'Email Send Clear Text Signed Message': [
      'description': 'Receiver: Email_Receiver - Send Clear Text Signed Message'
    ],
    'Email Proxy Type': [
      'description': 'Receiver: Email_Receiver - Proxy Type'
    ],
    'Email Receiver Cc': [
      'description': 'Receiver: Email_Receiver - Cc'
    ]

  ],
  'Update_Service_Order_for_Duplicate_Activity_from_SAP_Field_Service_Management_to_SAP_S4HANA_Cloud': [
    'Service Order Note Language': [
      'description': 'More - Service Order Note Language',
      'size': 2,
      'mandatory': true
    ],
    'address': [
      'description': 'Sender - Address',
      'mandatory': true
    ],
    'PrivateKeyAlias': [
      'description': 'Receiver: S4HANA_Cloud_Read - Private Key Alias',
      'mandatoryif': [ 'AuthenticationMethod', 'Client Certificate']
    ],
    'CredentialName': [
      'description': 'Receiver: S4HANA_Cloud_Read - Credential Name',
      'mandatoryif': [ 'AuthenticationMethod', 'Basic' ],
      'default' : '<SAP S/4HANA Cloud Credential Name>'
    ],
    'LocationID': [
      'description': 'Receiver: S4HANA_Cloud_Read - Location ID',
      'mandatoryif': [ 'ProxyType', 'On-Premise']
    ],
    'Creation Post Mapping Extension Enabled': [
      'description': 'More - Creation Post Mapping Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Credential Name': [
      'description': 'Receiver: SAP_FSM_Update - Credential Name',
      'mandatory': true,
      'default' : '<FSM_Credential>'
    ],
    'Product Id for Service Item': [
      'description': 'More - Product Id for Service Item',
      'mandatory': true
    ],
    'AuthenticationMethod': [
        'description': 'Receiver: S4HANA_Cloud_Read - Authentication'
    ],
    'Creation Post Mapping Extension Address': [
      'description': 'Receiver: Creation_Post_Mapping_Extension_iFlow - Address',
      'mandatoryif': [ 'Creation Post Mapping Extension Enabled', 'true']
    ],
    'FSM Company ID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'company'
    ],
    'ODataServiceAddress': [
      'description': 'Receiver: S4HANA_Cloud_Read - Address',
      'type': 'url',
      'mandatory': true,
      'default' : 'https://<MYS4HANA-api.s4hana.ondemand.com>:443/sap/opu/odata/sap/API_SERVICE_ORDER_SRV'
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Atachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'company': [
      'description': 'More - company',
      'group': 'Name',
      'alternative' : 'FSM Company ID',
      'default': '<FSM_Company>'
    ],
    'FSM Account ID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'account'
    ],
    'Post Mapping Extension Address': [
      'description': 'Receiver: Duplication_Post_Mapping_Extension_iFlow - Address',
      'mandatoryif': [ 'Post Mapping Extension Enabled', 'true']
    ],
    'ProxyType': [
      'description': 'Receiver: S4HANA_Cloud_Read - Proxy Type'
    ],
    'FSM Host': [
      'description': 'Receiver: SAP_FSM_Update - FSM Host',
      'type': 'emailhostname',
      'mandatory': true,
      'default' : '<FSM Host>'
    ],
    'Post Mapping Extension Enabled': [
      'description': 'More - Post Mapping Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'user': [
      'description': 'More - user',
      'default' : '<FSM_User>'
    ],
    'account': [
      'description': 'More - account',
      'group': 'Name',
      'alternative' : 'FSM Account ID',
      'default': '<FSM_Account>'
    ],
    'Service Order Item Note Type': [
      'description': 'More - Service Order Item Note Type',
      'size': 4,
      'mandatory': true
    ]
  ],
  'Replicate_Business_Partner_Address_from_SAP_S4HANA_Cloud_to_SAP_Field_Service_Management': [
    'Account':[
         'description': 'More - FSM Account Name',
         'group': 'Name',         
		 'alternative' : 'AccountID',
		 'default': '<FSM Account Name>'
    ],
    'AccountID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'Account',
		 'default': '<FSM Account ID>'
    ],
    'Company':[          
         'description': 'More - FSM Company Name',
         'group': 'Name',         
		 'alternative' : 'CompanyID',
		 'default': '<FSM Company Name>'
    ],
    'CompanyID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'Company',
		 'default': '<FSM Company ID>'
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Update_Address - FSM Host',
      'type': 'emailhostname',
      'mandatory': true,
      'default' : '<FSM_host>'
    ], 
    'Address':[
          'description': 'Sender - Address',
          'mandatory': true
    ],

    'EnableMultiCompanyReplication':[
          'description': 'More - EnableMultiCompanyReplication',
		 'type': 'boolean',
		 'mandatory': true
    ],
    'Credential Name':[
         'description': 'Receiver: FSM_Create_Business_Partner_Address - Credential Name',
         'mandatory': true,
         'default': '<FSM_Token>'
    ],
    'dto':[
         'description': 'Receiver: FSM_Create_Business_Partner_Address - DTO version',
         'mandatory': true
    ],
    'Enable post-exit': [
      'description': 'More - Post Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable pre-exit': [
      'description': 'More - Pre Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'ErrorEmailNotification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'ErrorLogAttachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Exception integration flow endpoint':[
      'description': 'More - exception handling iflow endpoint',
      'mandatoryif': [ 'ErrorEmailNotification', 'true' ]
    ],
    'Post-exit integration flow endpoint': [
      'description': 'Receiver: Post-exit process - Address',
      'mandatoryif': [ 'Enable post-exit', 'true' ]
    ],
    'Pre-exit integration flow endpoint': [
      'description': 'Receiver: Pre-exit processn - Address',
      'mandatoryif': [ 'Enable pre-exit', 'true']
    ]
],
'Replicate_Business_Partner_Contact_from_SAP_S4HANA_Cloud_to_SAP_Field_Service_Management': [
    'Account':[
         'description': 'More - FSM Account Name',
         'group': 'Name',         
		 'alternative' : 'AccountID',
		 'default': '<FSM_Account>'
    ],
    'AccountID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'Account',
		 'default': '<FSM Account ID>'
    ],
    'Company':[          
         'description': 'More - FSM Company Name',
         'group': 'Name',         
		 'alternative' : 'CompanyID',
		 'default': '<FSM_Company>'
    ],
    'CompanyID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'Company',
		 'default': '<FSM Company ID>'
    ],
    'EnableMultiCompanyReplication':[
         'description': 'More - EnableMultiCompanyReplication',
		 'type': 'boolean',
		 'mandatory': true
    ],
    'DS-ExpirationPeriod':[
         'description': 'More - DataStore - Expiration Period value',
         'type': 'number',
         'default': '30'
    ],
    'DS-RetentionThreshold':[
         'description': 'More - DataStore - Retention Threshold value',
         'type': 'number',
         'default': '28'
    ],
    'Address':[
          'description': 'Sender - Address',
          'mandatory': true
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Update_Contact - FSM Host',
      'type': 'emailhostname',
      'mandatory': true,
      'default' : '<FSM_host>'
    ], 
    'Credential Name':[
         'description': 'Receiver: FSM_Create_Business_Partner_Contact - Credential Name',
         'mandatory': true,
         'default': '<FSM_Token>'
    ],
    'Enable post-exit': [
      'description': 'More - Post Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable pre-exit': [
      'description': 'More - Pre Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'ErrorEmailNotification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'ErrorLogAttachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Exception integration flow':[
      'description': 'More - exception handling iflow endpoint',
      'mandatoryif': [ 'ErrorEmailNotification', 'true' ]
    ],
    'Post-exit integration flow endpoint': [
      'description': 'Receiver: Post-exit process - Address',
      'mandatoryif': [ 'Enable post-exit', 'true' ]
    ],
    'Pre-exit integration flow endpoint': [
      'description': 'Receiver: Pre-exit processn - Address',
      'mandatoryif': [ 'Enable pre-exit', 'true']
    ]
],
'Replicate_Business_Partner_Relationships_from_SAP_S4HANA_Cloud_to_SAP_Field_Service_Management': [
    'Account':[
         'description': 'More - FSM Account Name',
         'group': 'Name',         
		 'alternative' : 'AccountID',
		 'default': '<FSM_Account>'
    ],
    'AccountID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'Account',
		 'default': '<FSM Account ID>'
    ],
    'Company':[          
         'description': 'More - FSM Company Name',
         'group': 'Name',         
		 'alternative' : 'CompanyID',
		 'default': '<FSM_Company>'
    ],
    'CompanyID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'Company',
		 'default': '<FSM Company ID>'
    ],
    'Address':[
          'description': 'Sender: S4SOAP - Address',
          'mandatory': true
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Business_Partner_Relationship - FSM Host',
      'type': 'emailhostname',
      'mandatory': true,
      'default' : '<FSM_host>'
    ], 
    'Authorization':[
            'description': 'Sender: S4SOAP - Authentication'
    ],
    'Credential Name':[
         'description': 'Receiver: FSM_Create_Business_Partner_Relationship - Credential Name',
         'mandatory': true,
         'default' : '<FSM_Token>'
    ],
    'EnableMultiCompanyReplication':[
         'description': 'More - EnableMultiCompanyReplication',
		 'type': 'boolean',
		 'mandatory': true
    ],
    'Enable pre-exit MultiCompany':[
         'description': 'More - Enable pre-exit MultiCompany',
		 'type': 'boolean',
		 'mandatory': true
    ],
    'Enable post-exit': [
      'description': 'More - Post Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable pre-exit': [
      'description': 'More - Pre Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'ErrorEmailNotification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'ErrorLogAttachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Exception iflow endpoint':[
      'description': 'More - exception handling iflow endpoint',
      'mandatoryif': [ 'ErrorEmailNotification', 'true' ]
    ],
    'Issuer_DN': [
      'description': 'Sender: S4SOAP - Issuer DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Issuer_Distinguished_Name>'
    ],
    'Post-exit integration flow endpoint': [
      'description': 'Receiver: Post-exit process - Address',
      'mandatoryif': [ 'Enable post-exit', 'true' ]
    ],
    'Pre-exit integration flow endpoint': [
      'description': 'Receiver: Pre-exit processn - Address',
      'mandatoryif': [ 'Enable pre-exit', 'true']
    ],
    'Subject_DN': [
      'description': 'Sender: S4SOAP - Subject DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Subject_Distinguished_Name>'
    ]
],
'Replicate_Business_Partners_from_SAP_S4HANA_Cloud_to_SAP_Field_Service_Management': [
    'Account':[
         'description': 'More - FSM Account Name',
         'group': 'Name',         
		 'alternative' : 'AccountID',
		 'default': '<FSM_Account>'
    ],
    'AccountID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'Account',
		 'default': '<FSM Account ID>'
    ],
    'Company':[          
         'description': 'More - FSM Company Name',
         'group': 'Name',         
		 'alternative' : 'CompanyID',
		 'default': '<FSM_Company>'
    ],
    'CompanyID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'Company',
		 'default': '<FSM Company ID>'
    ],
    'Address':[
        'description': 'Sender - S4SOAP- Address',
        'mandatory': true
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Business_Partner - FSM Host',
      'type': 'emailhostname',
      'mandatory': true,
      'default' : '<FSM_host>'
    ], 
    'Address_S4HANA_Cloud_Business_Partner_Address_Replication':[
        'description': 'More - Address Replicate business partner Address',
        'mandatory': true
    ],
    'Address_S4HANA_Cloud_Business_Partner_Contact_Replication':[
        'description': 'More - Address Replicate business partner contact',
         'mandatory': true
    ],
    'Address_To_Forward_Exception_Payload':[
        'description': 'More - Address Replicate business partner employee',
        'mandatoryif': [ 'ErrorEmailNotification', 'true' ]
    ],
    'Authorization':[
          'description': 'Sender: S4SOAP - Authorization'
    ],
    'Credential Name':[
        'description': 'Receiver: FSM_Create_Business_Partner - Credential Name',
        'mandatory': true,
        'default' : '<FSM_Token>'
    ],
    'EnableMultiCompanyReplication': [
      'description': 'More - EnableMultiCompanyReplication',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable Pre-Exit MultiCompany': [
      'description': 'More - Enable Pre-Exit MultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable_Post-Exit': [
      'description': 'More - Post Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable_Pre-Exit': [
      'description': 'More - Pre Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'ErrorEmailNotification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'ErrorLogAttachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Issuer_DN': [
      'description': 'Sender: S4SOAP - Issuer DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Issuer_Distinguished_Name>'
    ],
    'Post_Exit_Integration_Flow': [
      'description': 'Receiver: Post-exit process - Address',
      'mandatoryif': [ 'Enable_Post-Exit', 'true' ]
    ],
    'Pre_Exit_Integration_Flow': [
      'description': 'Receiver: Pre-exit process - Address',
      'mandatoryif': [ 'Enable_Pre-Exit', 'true']
    ],
    'Subject_DN': [
      'description': 'Sender: S4SOAP - Subject DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Subject_Distinguished_Name>'
    ],
    'User_Role': [
      'description': 'Sender - User Role',
      'mandatoryif': [ 'Authorization', 'RoleBased']
    ]
],
'Replicate_Equipment_from_SAP_Asset_Central_to_SAP_Field_Service_Management': [
    'Account':[
         'description': 'More - FSM Account Name',
         'mandatory': true,
         'default': '<FSM_Account>'
    ],
    'Address':[
          'description': 'Sender: HTTPS - Address',
          'mandatory': true
    ],
    'Address_Create_update_Equipment':[
          'description': 'Receiver - FSM - url',
          'mandatory': true,
          'default': 'https://<cluster>.coresuite.com/api/data/v4/Equipment/externalId/bulk'
    ],
    'Address_To_Fetch_Component_Information':[
          'description': 'Receiver - AIN_System - url',
          'mandatory': true,
          'default': 'https://<Service_Key_Endpoint>.sap.hana.ondemand.com/ain/services/api/v1/equipment(${property.EquipmentID})/components'
    ],
    'Address_To_Forward_Exception_Payload':[
      'description': 'More - exception handling iflow endpoint',
      'mandatoryif': [ 'ErrorEmailNotification', 'true' ]
    ],
    'AIN_Address':[
            'description': 'Receiver: AIN - Address',
            'mandatory': true,
            'default': 'https://<Service_Key_Endpoint>.sap.hana.ondemand.com/oauth/token'
    ],
    'AIN_Client_Id':[
            'description': 'Receiver: AIN - Client Id',
            'mandatory': true,
            'default': '<AIN_Client_ID>'
    ],
    'AIN_Client_Secret':[
            'description': 'Receiver: AIN - Client Secret',
            'mandatory': true,
            'default': '<AIN_Client_Secret>'
    ],
    'AIN_Tenant_Address':[
            'description': 'Receiver: AIN - Tenant Address',
            'mandatory': true,
            'default': 'https://<Service_Key_Endpoint>.sap.hana.ondemand.com/ain/services/api/v1/equipment(${property.EquipmentID})/header'
    ],
    'Authentication':[
            'description': 'Receiver: FSM - Authentication'
    ],
    'Authorization':[
            'description': 'Sender: HTTPS - Authorization'
    ],
    'Body_Size':[
          'description': 'Sender: HTTPS - Body Size (in MB)',
          'mandatory': true
    ],
    'BpRole':[
          'description': 'More - Business Partner Role',
          'mandatory': true
    ],
    'Company':[
          'description': 'More - FSM Company Name',
          'mandatory': true,
          'default': '<FSM_Company>'
    ],
    'Credential Name':[
         'description': 'Receiver: FSM - Credential Name',
         'mandatory': true,
         'default' : '<FSM_Credential_Name>'
    ],
    'Enable_Post_Exit_Component': [
      'description': 'More - Post Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable_Post_Exit_Equipment': [
      'description': 'More - Post Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable_Pre_Exit_Component': [
      'description': 'More - Pre Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable_Pre_Exit_Equipment': [
      'description': 'More - Pre Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'EquipmentDTO_Version': [
      'description': 'More - FSM - Equipment DTO',
      'mandatory': true
    ],
    'ErrorEmailNotification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'ErrorLogAttachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Grant_Type':[
        'description': 'Receiver: AIN Grant Type',
        'mandatory': true
    ],
    'Issuer_DN': [
      'description': 'Sender: HTTPS - Issuer DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Issuer_Distinguished_Name>'
    ],
    'Post_Exit_Component_Address': [
      'description': 'Receiver: Post-exit component process - Address',
      'mandatoryif': [ 'Enable_Post_Exit_Component', 'true' ]
    ],
    'Post_Exit_Equipment_Address': [
      'description': 'Receiver: Post-exit equipment process - Address',
      'mandatoryif': [ 'Enable_Post_Exit_Equipment', 'true' ]
    ],
    'Pre_Exit_Equipment_Address': [
      'description': 'Receiver: Pre-exit equipment process - Address',
      'mandatoryif': [ 'Enable_Pre_Exit_Equipment', 'true']
    ],
    'Pre-Exit_Component_Address': [
      'description': 'Receiver: Pre-exit componentprocess - Address',
      'mandatoryif': [ 'Enable_Pre_Exit_Component', 'true']
    ],
    'Response_Type': [
      'description': 'Receiver: AIN Response Type',
      'mandatory': true
    ],
    'Subject_DN': [
      'description': 'Sender: HTTPS - Subject DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Subject_Distinguished_Name>'
    ],
    'Time_Out': [
      'description': 'Receiver: AIN_Tenant - Timeout (in ms)',
      'type': 'number',
      'mandatory': true
    ],
    'User': [
      'description': 'More - FSM User',
      'mandatory': true,
      'default' : '<FSM_User>'
    ],
    'User_Role': [
      'description': 'Sender - User Role',
      'mandatoryif': [ 'Authorization', 'RoleBased']
    ]
],
'Replicate_Item_PriceList': [
    'Account':[
         'description': 'More - FSM Account Name',
         'group': 'Name',         
		 'alternative' : 'AccountID',
		 'default': '<FSM Account>'
    ],
    'AccountID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'Account',
		 'default': '<FSM Account ID>'
    ],
    'Company':[          
         'description': 'More - FSM Company Name',
         'group': 'Name',         
		 'alternative' : 'CompanyID',
		 'default': '<FSM Company>'
    ],
    'CompanyID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'Company',
		 'default': '<FSM Company ID>'
    ],
    'Address':[
          'description': 'Sender -S4SOAP- Address',
          'mandatory': true
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_PriceList - FSM Host',
      'type': 'emailhostname',
      'mandatory': true,
      'default' : '<FSM_host>'
    ], 
    'Authorization':[
            'description': 'Sender: S4SOAP - Authentication'
    ],
    'Credential Name':[
         'description': 'Receiver: FSM_Create_PriceList - Credential Name',
         'mandatory': true,
         'default' : '<FSM_Token>'
    ],
    'Enable Post-exit Material': [
      'description': 'More - Post Extension Enabled for material',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable Post-exit Price List': [
      'description': 'More - Post Extension Enabled for pricelist',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable Pre-exit Material': [
      'description': 'More - Pre Extension Enabled for material',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable Pre-exit Price List': [
      'description': 'More - Pre Extension Enabled for pricelist creation',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable Pre-exit Price List Deletion': [
      'description': 'More - Pre Extension Enabled for pricelist deletion',
      'type': 'boolean',
      'mandatory': true
        ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable pre-exit MultiCompany': [
      'description': 'More - Enable pre-exit MultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
	'EnableMultiCompanyReplication': [
      'description': 'More - EnableMultiCompanyReplication',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Exception integration flow endpoint':[
      'description': 'More - exception handling iflow endpoint',
      'mandatoryif': [ 'Error Email Notification', 'true']
    ],
    'HTTP_Timeout': [
      'description': 'Receiver: FSM_Create_PriceList - Timeout (in ms)',
      'type': 'number',
      'mandatory': true
    ],
    'Issuer_DN': [
      'description': 'Sender: S4SOAP - Issuer DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Issuer_Distinguished_Name>'
    ],
    'ItemPriceListAssignmentDTO':[
      'description':'Receiver: HTTP_Request_to_LinkItem_To_Pricelist - dto version',
      'mandatory': true
    ],
    'Post-exit integration flow endpoint for Material': [
      'description': 'Receiver: Post-exit process - Address for material',
      'mandatoryif': [ 'Enable Post-exit Material', 'true' ]
    ],
    'Post-exit integration flow endpoint for PriceList': [
      'description': 'Receiver: Post-exit process - Address for pricelist',
      'mandatoryif': [ 'Enable Post-exit Price List', 'true' ]
    ],
    'Pre-exit integration flow endpoint for Material': [
      'description': 'Receiver: Pre-exit process - Address for material',
      'mandatoryif': [ 'Enable Pre-exit Material', 'true']
    ],
    'Pre-exit integration flow endpoint for PriceList': [
      'description': 'Receiver: Pre-exit process - Address for PriceList',
      'mandatoryif': [ 'Enable Pre-exit Price List', 'true']
    ],
    'PriceListDTO':[
      'description':'Receiver: FSM_Create_PriceList - dto version',
      'mandatory': true
    ],
    'Subject_DN': [
      'description': 'Sender: S4SOAP - Subject DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Subject_Distinguished_Name>'
    ],
    'User_Role': [
      'description': 'Sender - User Role',
      'mandatoryif': [ 'Authorization', 'RoleBased']
    ]
],
'Replicate_Product_Stock_from_SAP_S4HANA_Cloud_to_SAP_Field_Service_Management': [
    'Address':[
          'description': 'Sender - S4SOAP - Address',
          'mandatory': true
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Update_Warehouse - FSM Host',
      'type': 'emailhostname',
      'mandatory': true,
      'default' : '<FSM_host>'
    ], 
    'Address_To_Forward_Exception_Payload':[
      'description': 'More - exception handling iflow endpoint',
      'mandatoryif': [ 'ErrorEmailNotification', 'true']
    ],
    'Authorization':[
            'description': 'Sender: S4SOAP - Authentication'
    ],
    'Credential Name':[
         'description': 'Receiver: FSM_Create_Update_Warehouse - Credential Name',
         'mandatory': true,
         'default' : '<FSM Token>'
    ],
    'Enable_Post_Exit1': [
      'description': 'More - Post Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'EnableMultiCompanyReplication': [
      'description': 'More - EnableMultiCompanyReplication',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable pre-exit MultiCompany': [
      'description': 'More - Enable pre-exit MultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable_Post_Exit2': [
      'description': 'More - Post Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable_Pre-Exit': [
      'description': 'More - Pre Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'ErrorEmailNotification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'ErrorLogAttachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'FSM Account':[
         'description': 'More - FSM Account Name',
         'group': 'Name',         
		 'alternative' : 'AccountID',
		 'default': '<FSM_Account>'
    ],
    'AccountID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'FSM Account',
		 'default': '<FSM Account ID>'
    ],
    'FSM Company':[          
         'description': 'More - FSM Company Name',
         'group': 'Name',         
		 'alternative' : 'CompanyID',
		 'default': '<FSM_Company>'
    ],
    'CompanyID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'FSM Company',
		 'default': '<FSM Company ID>'
    ],
    'Issuer_DN': [
      'description': 'Sender: S4SOAP - Issuer DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Issuer_Distinguished_Name>'
    ],
    'Post_Exit_Integration_Flow_1': [
      'description': 'Receiver: Post-exit process - Address',
      'mandatoryif': [ 'Enable_Post_Exit1', 'true' ]
    ],
    'Post_Exit_Integration_Flow_2': [
      'description': 'Receiver: Post-exit process - Address',
      'mandatoryif': [ 'Enable_Post_Exit2', 'true' ]
    ],
    'Pre_Exit_Integration_Flow': [
      'description': 'Receiver: Pre-exit processn - Address',
      'mandatoryif': [ 'Enable_Pre-Exit', 'true']
    ],
    'Subject_DN': [
      'description': 'Sender: S4SOAP - Subject DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Subject_Distinguished_Name>'
    ],
    'User Role': [
      'description': 'Sender - User Role',
      'mandatoryif': [ 'Authorization', 'RoleBased']
    ],
    'Warehouse_Delimiter':[
      'description': 'More - Warehouse delimiter',
      'mandatory': true
    ],
    'Warehouse_Delimiter_Name':[
      'description': 'More - Warehouse delimiter name',
      'mandatory': true
    ]
],
'Replicate_Products_from_SAP_S4HANA_Cloud_to_SAP_Field_Service_Management': [
    'account':[
         'description': 'More - FSM Account Name',
         'group': 'Name',         
		 'alternative' : 'AccountID',
		 'default': '<FSM_Account>'
    ],
    'AccountID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'account',
		 'default': '<FSM Account ID>'
    ],
    'company':[          
         'description': 'More - FSM Company Name',
         'group': 'Name',         
		 'alternative' : 'CompanyID',
		 'default': '<FSM_Company>'
    ],
    'CompanyID':[
         'description': 'More - FSM Account ID',
		 'group': 'ID',
		 'type': 'number',			 
		 'alternative' : 'company',
		 'default': '<FSM Company ID>'
    ],
    'Address':[
          'description': 'Sender: S4SOAP - Address',
          'mandatory': true
    ],
    'FSM_host': [
      'description': 'Receiver: FSM_Create_Product - FSM Host',
      'type': 'emailhostname',
      'mandatory': true,
      'default' : '<FSM_host>'
    ], 
    'AddressForException':[
        'description': 'More - exception handling iflow endpoint',
      'mandatoryif': [ 'ErrorEmailNotification', 'true']
    ],
    'Authorization':[
            'description': 'Sender: S4SOAP - Authentication'
    ],
    'Credential Name':[
         'description': 'Receiver: FSM_Create_Business_Partner_Relationship - Credential Name',
         'mandatory': true,
         'default' : '<FSM_Credential_Name>'
    ],
    'ErrorEmailNotification': [
        'description': 'More - Error Email Notification',
        'type': 'boolean',
        'mandatory': true
    ],
    'EnableMultiCompanyReplication': [
        'description': 'More - EnableMultiCompanyReplication',
        'type': 'boolean',
        'mandatory': true
    ],
    'Enable_Pre-Exit_MultiCompany': [
        'description': 'More - Enable_Pre-Exit_MultiCompany',
        'type': 'boolean',
        'mandatory': true
    ],	
    'ErrorLogAttachments': [
        'description': 'More - Error Log Attachments',
        'type': 'boolean',
        'mandatory': true
    ],
    'Issuer_DN': [
        'description': 'Sender: S4SOAP - Issuer DN',
        'mandatoryif': [ 'Authorization', 'Client Certificate'],
        'default' : '<Issuer_Distinguished_Name>'
    ],
    'Post_Exit': [
        'description': 'Receiver: Post-exit process - Address',
        'mandatoryif': [ 'Post-Exit', 'Yes' ]
    ],
    'Post-Exit': [
        'description': 'More - Post Extension Enabled',
        'mandatory': true
    ],
    'Pre_Exit': [
        'description': 'Receiver: Pre-exit process - Address',
        'mandatoryif': [ 'Pre-Exit', 'Yes']
    ],
    'Pre-Exit': [
      'description': 'More - Pre Extension Enabled',
      'mandatory': true
    ],
    'ProductDescriptionLanguage':[
        'description': 'More - Product decription default language',
        'mandatory': true
    ],
    'S4HANA_Payload_Attachment_Size':[
          'description': 'Sender: S4SOAP - Payload Attachment Size(in MB)',
          'mandatory': true
    ],
    'S4HANA_Payload_Body_Size':[
          'description': 'Sender: S4SOAP - Payload body Size(in MB)',
          'mandatory': true
    ],
    'Subject_DN': [
        'description': 'Sender: S4SOAP - Subject DN',
        'mandatoryif': [ 'Authorization', 'Client Certificate'],
        'default' : '<Subject_Distinguished_Name>'
    ],
    'User_Role': [
        'description': 'Sender - User Role',
        'mandatoryif': [ 'Authorization', 'RoleBased']
    ]
]
]

/*
Map package_parameter_checks = [ 
  'IntegrationFlowID': [		// integration flow id 
    'Parameter Name': [ 		// externalized parameter name  
        'description': 'UI name',  	// parameter name on the configuration UI if different 
                                    // from Parameter Name  
        'type': 'string',           // supported types are string, number, boolean, url,  
                                    // hostname (with protocol and port), email,  
                                    // emailhostname (with protocol and port) 
        'size': 12,              	// max. size of string (optional) 
        'exact': 12,                	// exact size of string (optional) 
        'values': ['S001', 'S002'], 	// only these values allowed 
        'separator': '\\|',         	// list of separate values, each value is type/size 					
                                        // checked individually 
        'default': '<SMTP Server>', 	// default value to be interpreted as empty 
        'mandatory': true,          	// single mandatory parameter (optional) 
        'mandatoryif': ['another parameter' ,'v1','v2'], // is mandatory if another						
                                        // parameter is set or (optional) has values v1 or v2 
        'alternative': 'parameter', 	// not mandatory if alternative parameter set instead 
        'group': 'group name'       	// mandatory if another parameter of this group is set 
    ], 
    // … repeat for all parameters of IntegrationFlowID 
  ], 
  // … repeat for all integration flows 
] 
*/

    message.setProperty('PackageParameterChecks', package_parameter_checks)
    return message
}