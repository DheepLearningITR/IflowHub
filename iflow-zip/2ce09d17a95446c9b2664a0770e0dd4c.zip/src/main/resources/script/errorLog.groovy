import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Callable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

def Message logError_CreateBPBatch1Failed(Message message) {
    Logger log = LoggerFactory.getLogger(this.getClass());
    try {
        processData("CreateBP Batch1 failed", message);
    } catch (Exception ex) {
        log.error("processData error", ex);
    }
}

def Message processData_error_main(Message message) {
    Logger log = LoggerFactory.getLogger(this.getClass());

    try {
        processData("IFLOW_log_error_main", message);
    } catch (Exception ex) {
        log.error("processData error", ex);
    }
}

def Message processData_error_getToken(Message message) {
    Logger log = LoggerFactory.getLogger(this.getClass());

    try {
        processData("IFLOW_log_error_getToken", message);
    } catch (Exception ex) {
        log.error("processData error", ex);
    }
}

def Message processData_error_updateBP(Message message) {
    Logger log = LoggerFactory.getLogger(this.getClass());

    try {
        processData("IFLOW_log_error_updateBP", message);
    } catch (Exception ex) {
        log.error("processData error", ex);
    }
}

def Message processData_error_createBP(Message message) {
    Logger log = LoggerFactory.getLogger(this.getClass());

    try {
        processData("IFLOW_log_error_createBP", message);
    } catch (Exception ex) {
        log.error("processData error", ex);
    }
}

def Message processData(String prefix, Message message) {
    Logger log = LoggerFactory.getLogger(this.getClass());
    try {
        processBody(prefix, message);
    } catch (Exception ex00) {
        log.error("processData error", ex00)
        StringWriter sw = new StringWriter();
        ex00.printStackTrace(new PrintWriter(sw));
        log.error(sw.toString());
    }
    return message;
}


def void processBody(String prefix, Message message) {
    Logger log = LoggerFactory.getLogger(this.getClass());
    ExecutorService pool = Executors.newSingleThreadExecutor();
    def task = {c -> pool.submit( c as Callable)}
    def byte[] body_bytes = null;
    try {
        if (message==null) {
            body_bytes = new byte[0];
        } else if (message.getBody() == null) {
           body_bytes = new byte[0];
        } else {
            body_bytes = message.getBody(byte[].class);
        }

       def messageLog = messageLogFactory.getMessageLog(message);
       messageLog.addAttachmentAsString(prefix+"_payload", new String(body_bytes), "text/plain");
    } catch (Exception ex01) {
        log.error("cannot save body",ex01);
        StringWriter sw = new StringWriter();
        ex01.printStackTrace(new PrintWriter(sw));
        log.info(sw.toString());
    }
}

def Message processData_error_getSupportedRoles(Message message) {
    Logger log = LoggerFactory.getLogger(this.getClass());

    try {
        processData("IFLOW_log_error_filterBPRoles", message);
    } catch (Exception ex) {
        log.error("processData error", ex);
    }
}

def Message processData_error_getUserGroup(Message message) {
    Logger log = LoggerFactory.getLogger(this.getClass());

    try {
        processData("IFLOW_log_error_getUserGroup", message);
    } catch (Exception ex) {
        log.error("processData error", ex);
    }
}
