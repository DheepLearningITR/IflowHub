import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message logConfirmation(Message message) {
    map = message.getProperties();
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        def S4ID = map.get("externalId");
        messageLog.addAttachmentAsString("Confirmation_" + S4ID + "_" + map.get("businessPartnerId"), body, "text/xml");
    }
    return message;
}

def Message logS4BPID(Message message) {
    map = message.getProperties();
    def S4BPID = map.get("externalId");
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        messageLog.addAttachmentAsString("S4_BPID_" + S4BPID, "", "text/xml");
    }
    return message;
}

def Message logCreateECBP(Message message) {
    map = message.getProperties();
    def ECBPID = map.get("businessPartnerId");
    def messageLog = messageLogFactory.getMessageLog(message);

    if (messageLog != null) {
        messageLog.addAttachmentAsString("Create_ECBP_" + ECBPID, "", "text/json");
    }
    return message;
}

def Message logUpdateECBP(Message message) {
    map = message.getProperties();
    def ECBPID = map.get("businessPartnerId");
    def messageLog = messageLogFactory.getMessageLog(message);

    if (messageLog != null) {
        messageLog.addAttachmentAsString("Update_ECBP_" + ECBPID, "", "text/json");
    }
    return message;
}

def Message logSupportedRoleList(Message message) {
	map = message.getProperties();
    def messageLog = messageLogFactory.getMessageLog(message);
	def supportedRoleList = map.get("supportedRoleList");
    if (messageLog != null) {
        messageLog.addAttachmentAsString("EC_Supported_Role_List", supportedRoleList.toString(), "text/json");
    }
    return message;
}