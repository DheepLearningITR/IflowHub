importClass(com.sap.gateway.ip.core.customdev.util.Message);
// construct body for first batch request: POST BP and Addresses
var CONST_NAME = {
    BP: "BusinessPartner",
    ADDRESS: "Address",
    BPROLE: "BPRole",
    BPADDRESS: "BPAddress",
    POSTALADDRESS: "PostalAddress",
    EMAIL: "Email",
    PHONE: "Phone"
};
var OPERATION = {
    POST: "POST",
    PUT: "PUT",
    DELETE: "DELETE"
}

var constBoundary = "changeset_8843-b8e1-6b24";  

function getHeaderBoundary() {
    return "--batch_mybatch" + "\n" + "Content-Type: multipart/mixed; boundary=" + constBoundary + "\n\n";
}

function getFooterBoundary() {
    return "--" + constBoundary + "--" + "\n" + "--batch_mybatch--";
}

function getHeaderForEachCall(operation, name, ETag) {
    var str = "--" + constBoundary + "\n" + "Content-Type: application/http" + "\n" +
        "Content-Transfer-Encoding: binary" + "\n\n" + operation + " " + name + " HTTP/1.1" + "\n" +
        "Accept-Language: en" + "\n" + "Accept: application/json" + "\n" + "MaxDataServiceVersion: 2.0" + "\n" +
        "DataServiceVersion: 2.0" + "\n" + "Content-Type: application/json" + "\n";
    if (ETag) {
        str += "If-Match: " + ETag + "\n";

    }
    return str + "\n";
}

function handleRetentionStatusCode_Create(message) {
    var map = message.getProperties();
    var BPData = JSON.parse(map.get("newBP"));
    var BPInfo = BPData.BPInfo;
    if (BPInfo.retentionStatusCode === "true") {
        BPInfo.retentionStatusCode = "01";
    } else {
        delete BPInfo.retentionStatusCode;
    }
    message.setProperty("newBP", JSON.stringify(BPData));
    return message;
}

function handleRetentionStatusCode_Update(message) {
    var map = message.getProperties();
    var newBP = JSON.parse(map.get("newBP"));
    var oldBP = JSON.parse(map.get("oldBP"));
    var BPInfo = newBP.BPInfo;
    if (oldBP.retentionStatusCode === "02") {
        BPInfo.retentionStatusCode = "02";
    } else {
        if (BPInfo.retentionStatusCode === "true") {
            BPInfo.retentionStatusCode = "01";
        } else {
            delete BPInfo.retentionStatusCode;
        }
    }
    message.setProperty("newBP", JSON.stringify(newBP));
    return message;
}
// construct the body of the first batch request including BP and
// multi-Addresses
function constructFirstBatchBody_Create(message) {
    var map = message.getProperties();
    var BPData = JSON.parse(map.get("newBP"));
    var addresses = BPData.addresses;
    var BPInfo = BPData.BPInfo;
    var userGroup = map.get("userGroup");
    if(userGroup){
        BPInfo.businessPartnerSearchGroup = String(userGroup);
    }
    var body = getHeaderBoundary();

    body += getHeaderForEachCall(OPERATION.POST, CONST_NAME.BP);
    // add bp info

    body += JSON.stringify(BPInfo) + "\n\n";
    body += constructAddress_Post(addresses);
    body += getFooterBoundary();
    message.setBody(body);
    return message;
}

// Construct Address for Post operation
function constructAddress_Post(addresses) {
    if (!addresses)
        return "";

    // add address info
    var obj;
    var str = "";
    var headerStr = getHeaderForEachCall(OPERATION.POST, CONST_NAME.ADDRESS);
    if (Array.isArray(addresses)) {
        addresses.forEach(function(v, i) {
            obj = {
                "externalGuid": v.externalGuid
            }
            str += headerStr + JSON.stringify(obj) + "\n\n";
        });
    } else {
        obj = {
            "externalGuid": addresses.externalGuid
        }
        str = headerStr + JSON.stringify(obj) + "\n\n";
    }
    return str;

}
// construct the body of the second batch request including BPAddress,
// PostalAddress/Email/Phone
function constructSecondBatchBody_Create(message) {
    var map = message.getProperties();
    var addressIDs = map.get("addressIds");
    var BPID = map.get("businessPartnerId").intValue();
    var BPData = JSON.parse(map.get("newBP"));

    var addresses = BPData.addresses;
    var roles = BPData.roles;
    // if roles and addresses both empty, no need to do second batch request
    if (!addresses && !roles) {
        message.setProperty("emptyRoleAndAddress", "true");
        return message;
    }

    var body = getHeaderBoundary();
    body += constructBPRole_POST(BPID, roles);
    body += constructAddresses(BPID, addressIDs, addresses);
    body += getFooterBoundary();
    message.setBody(body);
    return message;
}
// construct BPRole into body
function constructBPRole_POST(BPID, roles) {
    if (!roles)
        return "";
    var headerStr = getHeaderForEachCall(OPERATION.POST, CONST_NAME.BPROLE);
    if (!Array.isArray(roles)) {
        roles.businessPartnerId = BPID;
        return headerStr + JSON.stringify(roles) + "\n\n";
    }
    var str = "";
    roles.forEach(function(v) {
        v.businessPartnerId = BPID;
        str += headerStr + JSON.stringify(v) + "\n\n";
    });
    return str;
}
// construct Address related info (including BPAddress, PostalAddress, Email,
// phone) into body
function constructAddresses(BPID, addressIDs, addresses) {
    if (!addresses)
        return "";

    if (!Array.isArray(addresses)) {
        return constructOneAddress(BPID, addressIDs.get(0).intValue(), addresses);
    }

    var addressId;
    var str = "";
    addresses.forEach(function(v, i) {
        addressId = addressIDs.get(i).intValue();
        str += constructOneAddress(BPID, addressId, v);
    });
    return str;
}

function constructOneAddress(BPID, addressId, address) {
    // Add BPAddress
    var str = getHeaderForEachCall(OPERATION.POST, CONST_NAME.BPADDRESS);
    var BPAddress = address.BPAddress;
    BPAddress.businessPartnerId = BPID;
    BPAddress.addressId = addressId;
    str += JSON.stringify(BPAddress) + "\n\n";

    // handle addressRepresentationCode field in postalAddress
    address.postalAddress = handlePostalAddress(address.postalAddress);

    // Add PostalAddress array
    str += constructAddressChild(addressId, address.postalAddress, CONST_NAME.POSTALADDRESS);
    // Add Email
    str += constructAddressChild(addressId, address.emails, CONST_NAME.EMAIL);
    // Add Phone
    str += constructAddressChild(addressId, address.phones, CONST_NAME.PHONE);
    return str;
}

/*Without Filter non-initial addressRepresentationCode
function handlePostalAddress(postalAddress) {
    if (!postalAddress)
        return;
    if (Array.isArray(postalAddress)) {
        postalAddress.forEach(function(v) {
            if (!v.addressRepresentationCode) {
                v.addressRepresentationCode = "";
            }
        });
    } else {
        if (!postalAddress.addressRepresentationCode) {
            postalAddress.addressRepresentationCode = "";
        }
    }
}
*/
//Filter non-initial addressRepresentationCode
function handlePostalAddress(postalAddress) {
	if (!postalAddress)
		return;
	if (Array.isArray(postalAddress)) {
		for (var i = 0; i < postalAddress.length; i++) {
			if (!postalAddress[i].addressRepresentationCode) {
				postalAddress[i].addressRepresentationCode = "";
				return postalAddress[i];
			}
		}
	} else {
		if (!postalAddress.addressRepresentationCode) {
			postalAddress.addressRepresentationCode = "";
			return postalAddress;
		} 
	}
	return null;
}
// construct request body for PostalAddress/Email/Phone under address
function constructAddressChild(addressId, objectArr, objectName) {
    if (!objectArr)
        return "";
    var str = "";
    var headerStr = getHeaderForEachCall(OPERATION.POST, objectName);
    if (Array.isArray(objectArr)) {
        objectArr.forEach(function(v, i) {
            v.addressId = addressId;
            str += headerStr + JSON.stringify(v) + "\n\n";

        });
    } else {
        objectArr.addressId = addressId;
        str = headerStr + JSON.stringify(objectArr) + "\n\n";
    }
    return str;
}

//construct the body of the second batch request for BP Update process
//Including BPAddress, PostalAddress/Email/Phone
function constructSecondBatchBody_Update(message) {
    var map = message.getProperties();
    var addressIDs = map.get("addressIds");
    var BPID = map.get("businessPartnerId").intValue();

    var addresses = JSON.parse(map.get("newAddressArr"));

    var body = getHeaderBoundary();
    body += constructAddresses(BPID, addressIDs, addresses);
    body += getFooterBoundary();
    message.setBody(body);
    return message;
}
// Construct first batch body for BP update process
function constructFirstBatchBody_Update(message) {
    var map = message.getProperties();
    var newBP = JSON.parse(map.get("newBP"));
    var oldBP = JSON.parse(map.get("oldBP"));
    var userGroup = map.get("userGroup");
    if(userGroup){
        newBP.BPInfo.businessPartnerSearchGroup = String(userGroup);
    }
    var newAddressArr = newBP.addresses;
    var oldAddressArr = oldBP.Addresses.results;

    var newBPRoleArr = newBP.roles;
    var oldBPRoleArr = oldBP.Roles.results;

    var body = getHeaderBoundary();

    // add bp info
    body += constructBPInfo_Update(newBP.BPInfo, oldBP);
    // Add BP role
    body += constructBPRole_Update(oldBP.id, newBPRoleArr, oldBPRoleArr);

    // Add Address Info
    body += constructAddress_Update(newAddressArr, oldAddressArr, message);

    // Add footer boundary
    body += getFooterBoundary();

    message.setBody(body);
    return message;
}

function constructBPInfo_Update(newBP, oldBP) {
    var filedNeedRemove = ["__metadata", "Roles", "Addresses", "BPLegalHold", "AgentData"];
    var filedNeedKeep = ["isAgent", "userName", "userId", "coLocationGroup", "administrativeData_createdBy",
        "administrativeData_createdAt", "administrativeData_changedBy", "administrativeData_changedAt"
    ];

    return constructOneObj_Put(newBP, oldBP, filedNeedRemove, filedNeedKeep);
}

// Construct BPRole in batch for BP update process
function constructBPRole_Update(BPID, newBPRoleArr, oldBPRoleArr) {
    newBPRoleArr = convertObjectToArray(newBPRoleArr);
    var obj = checkOperation(newBPRoleArr, oldBPRoleArr,
        function(newRole, oldRole) {
            if (newRole.role === oldRole.role)
                return true;
            return false;
        });

    //Construct PUT BPRole array
    var newPutArr = obj.sourcePutArr;
    var oldPutArr = obj.targetPutArr
    var filedNeedRemove = ["__metadata"];
    var filedNeedKeep = ["coLocationGroup"];
    var str = "";
    if (newPutArr && oldPutArr && newPutArr.length !== 0 && newPutArr.length === oldPutArr.length) {
        oldPutArr.forEach(function(v, i) {
            str += constructOneObj_Put(newPutArr[i], v, filedNeedRemove, filedNeedKeep);
        });

    }
    // Construct POST BPRole array
    str += constructBPRole_POST(BPID, obj.postArr);

    // Construct DELETE BPRole array
    str += constructObj_Delete(obj.deleteArr);
    return str;
}

// check address and find out which operation(POST/PUT/DELETE) should be
// processed
function constructAddress_Update(newAddressArr, oldAddressArr, message) {
    newAddressArr = convertObjectToArray(newAddressArr);
    var obj = checkOperation(newAddressArr, oldAddressArr,
        function(newAddress, oldAddress) {
            if (newAddress.externalGuid === oldAddress.Address.externalGuid)
                return true;
            return false;
        });
    // TODO: Construct PUT address array
    var str = constructAddress_Put(obj.sourcePutArr, obj.targetPutArr);

    // Construct DELETE address array
    //Address array get from EC has child node "Address", need to convert to Address level
    if (obj.deleteArr.length !== 0) {
        var delArr = [];
        obj.deleteArr.forEach(function(v, i) {
            delArr.push(v.Address);
        });
        str += constructObj_Delete(delArr);
    }

    //Set PostAddress array to property to construct batch2 later
    message.setProperty("newAddressArr", JSON.stringify(obj.postArr));
    // Construct POST address array
    str += constructAddress_Post(obj.postArr);
    return str;
}

// Construct address for PUT operation
function constructAddress_Put(newPutAddArr, oldPutAddArr) {
    if (!newPutAddArr || !oldPutAddArr || newPutAddArr.length === 0 || oldPutAddArr.length === 0)
        return "";
    if (newPutAddArr.length !== oldPutAddArr.length)
        return "";

    var str = "";
    var endPoint = "";
    var oldAddress, newAddress, BPAddress;
    oldPutAddArr.forEach(function(v, i) {
        oldAddress = v.Address;
        newAddress = newPutAddArr[i];

        // BPAddress
        str += constructOneObj_Put(newAddress.BPAddress, v, ["__metadata", "Address"], ["coLocationGroup"]);
        // PostalAddress
        // Add addressRepresentationCode="" if this field is missing
        newAddress.postalAddress = handlePostalAddress(newAddress.postalAddress);
        str += constructAddressChild_Update(CONST_NAME.POSTALADDRESS, oldAddress.id, newAddress.postalAddress, oldAddress.PostalAddresses.results,
            function(newPostalAddress, oldPostalAddress) {
                if (newPostalAddress.addressRepresentationCode === oldPostalAddress.addressRepresentationCode)
                    return true;
                return false;

            }, ["__metadata"], ["coLocationGroup"]);

        // Phone
        str += constructAddressChild_Update(CONST_NAME.PHONE, oldAddress.id, newAddress.phones, oldAddress.Phones.results,
            function(newPhone, oldPhone) {
                if (newPhone.countryCode === oldPhone.countryCode && newPhone.number === oldPhone.number)
                    return true;
                return false;

            }, ["__metadata"], ["coLocationGroup"]);

        // Email
        str += constructAddressChild_Update(CONST_NAME.EMAIL, oldAddress.id, newAddress.emails, oldAddress.Emails.results,
            function(newEmail, oldEmail) {
                if (newEmail.URI === oldEmail.URI)
                    return true;
                return false;
            }, ["__metadata"], ["coLocationGroup"]);
    });
    return str;
}

// construct request body for PostalAddress/Email/Phone for Address Put process
function constructAddressChild_Update(objectName, addressId, newArr, oldArr, checkIsEqualFunc, filedNeedRemove, filedNeedKeep) {
    newArr = convertObjectToArray(newArr);
    var obj = checkOperation(newArr, oldArr, checkIsEqualFunc);

    var newPutArr = obj.sourcePutArr;
    var oldPutArr = obj.targetPutArr;
    var str = "";
    //Construct PUT array
    if (newPutArr && oldPutArr && newPutArr.length !== 0 && newPutArr.length === oldPutArr.length) {
        oldPutArr.forEach(function(v, i) {
            str += constructOneObj_Put(newPutArr[i], v, filedNeedRemove, filedNeedKeep);
        });

    }
    // Construct DELETE array
    str += constructObj_Delete(obj.deleteArr);

    // Construct POST array
    str += constructAddressChild(addressId, obj.postArr, objectName);
    return str;
}

function constructObj_Delete(delArr) {
    if (!delArr || delArr.length === 0)
        return "";
    var str = "";
    var endPoint = "";
    var index = -1;
    delArr.forEach(function(v, i) {
        if (v.__metadata) {
            index = v.__metadata.uri.lastIndexOf("/");
            if (index != -1) {
                endPoint = v.__metadata.uri.substring(index + 1);
                etag = v.__metadata.etag;
                str += getHeaderForEachCall(OPERATION.DELETE, endPoint, etag);
            }
        }
    });
    return str;
}

function convertObjectToArray(obj) {
    if (obj && !Array.isArray(obj)) {
        return [obj];
    }
    return obj;
}


// Compare two array, and put corresponding obj into post/put/delete array
// Record targetPutArr incase need to compare child node
// sourceArr is S4 outbound data, targetArr is EC data
function checkOperation(sourceArr, targetArr, checkIsEqualFunc) {
    var obj = {
        sourcePutArr: [],
        targetPutArr: [],
        postArr: [],
        deleteArr: [],
    }

    if (!sourceArr || sourceArr.length === 0) {
        // All objects in targetArr need DELETE
        obj.deleteArr = targetArr;
        return obj;
    }

    if (!targetArr || targetArr.length === 0) {
        // All objects in sourceArr need POST
        obj.postArr = sourceArr;
        return obj;
    }

    for (var i = 0; i < sourceArr.length; i++) {
        for (var j = 0; j < targetArr.length; j++) {
            if (checkIsEqualFunc(sourceArr[i], targetArr[j])) {
                break;
            }
        }
        // Exist in newArray, but not find in old array, need POST
        if (j === targetArr.length) {
            obj.postArr.push(sourceArr[i]);
        } else { // Exist in both new array and old array, need PUT
            obj.sourcePutArr.push(sourceArr[i]);
            obj.targetPutArr.push(targetArr[j]);
            // remove the put one in targetArr, after loop end, the objects left
            // in targetArr need DELETE
            targetArr.splice(j, 1);
        }
    }
    // still left some obj need DELETE
    if (targetArr.length !== 0) {
        obj.deleteArr = targetArr;
    }
    return obj;
}

// Construct one obj for PUT operation
function constructOneObj_Put(newObj, oldObj, filedNeedRemove, filedNeedKeep) {
    if (!newObj || !oldObj || !oldObj.__metadata)
        return "";

    var etag = oldObj.__metadata.etag;
    var index = oldObj.__metadata.uri.lastIndexOf("/");
    if (index === -1)
        return "";
    var endPoint = oldObj.__metadata.uri.substring(index + 1);
    var obj = getComparedObj(newObj, oldObj, filedNeedRemove, filedNeedKeep);
    return getHeaderForEachCall(OPERATION.PUT, endPoint, etag) + JSON.stringify(obj) + "\n\n";
}

// Compare two obj, and delete fields in old obj, keep the needed field in old
// obj
function getComparedObj(newObj, oldObj, filedNeedRemove, filedNeedKeep) {
    if (filedNeedRemove && Array.isArray(filedNeedRemove)) {
        filedNeedRemove.forEach(function(value) {
            delete oldObj[value];
        });
    }

    var obj = {};
    if (filedNeedKeep && Array.isArray(filedNeedKeep)) {
        filedNeedKeep.forEach(function(value) {
            obj[value] = oldObj[value];
            delete oldObj[value];
        });
    }

    for (var key in oldObj) {
        if (key in newObj) {
            obj[key] = newObj[key];
        } else {
            obj[key] = null;
        }
    }
    return obj;
}

function filterBPRoles(message) {   
    var map = message.getProperties();
    var BPData = JSON.parse(map.get("newBP"));
    var BPRoles = BPData.roles;
    BPRoles = convertObjectToArray(BPRoles); // if the request body only has one role, the <code>BPData.roles</code> is an object 	
    
    var aSupportedRoles = JSON.parse(map.get("supportedRoleList"));
    var aNonSupportedRoles = null;
    // filter roles based on supported role list
    if (BPRoles && BPRoles.length > 0) {
    	aNonSupportedRoles = removeNonSupportedRoles(BPRoles, aSupportedRoles);
    }
    // log un-supported roles
    logUnSupportedRoles(message, aNonSupportedRoles);
    
	BPData.roles = BPRoles;
    setEmptyBPRolesFlag(message, BPRoles);
    
    message.setProperty("newBP", JSON.stringify(BPData));
    return message;
}

function logUnSupportedRoles(message, aNonSupportedRoles) {
	var messageLog = messageLogFactory.getMessageLog(message);
	var map = message.getProperties();
    var S4ID = map.get("externalId");
    if (aNonSupportedRoles === null) {
    	messageLog.addAttachmentAsString("No_BPRoles_S4BPID_" + S4ID, "No BPRoles are found", "text/plain"); 	
    } else if(aNonSupportedRoles.length > 0) {
    	messageLog.addAttachmentAsString("UnSupported_Roles_S4BPID_" + S4ID, JSON.stringify(aNonSupportedRoles), "text/json"); 	
    }
}

// remove unsupported roles from BP
function removeNonSupportedRoles(aBPRoles, aSupportedRoles) {
	var aNonSupportedRoles = [];
    for(var i = aBPRoles.length - 1; i >= 0; i--){
        var value = aBPRoles[i];
        var role = aSupportedRoles.filter(function(item) {
        	return item === value.role;
        });
        if (role.length === 0) {  // this role does not be supported
        	aBPRoles.splice(i, 1);
        	aNonSupportedRoles.push(value.role);
        }
    }
    return aNonSupportedRoles;
}

function setEmptyBPRolesFlag(message, aBPRoles) {	
	if ((!aBPRoles) || (aBPRoles && aBPRoles.length === 0)) {
		message.setProperty("isEmptyBPRoles", JSON.stringify(true));
	} else {
		message.setProperty("isEmptyBPRoles", JSON.stringify(false));
	}		
}