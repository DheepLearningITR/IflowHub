import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Get the JSON string from the header
    def headers = message.getHeaders()
    def jsonString = headers.get("FormattedHTTPQuery")
    
    // Parse the JSON string
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(jsonString)

    // Initialize the writer for XML
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.setDoubleQuotes(true)

    // Define a mapping from JSON field names to XML field names (for "orderBy" conversions)
    def fieldMapping = [
        
        
        'correspondenceType'        : 'CORRESPONDENCE_TYPE',
        'createdOn'                 : 'CREATED_ON',
        'issueDate'                 : 'ISSUE_DATE',
        'issueTime'                 : 'ISSUE_TIME',
        'technicalCorrespondenceStatusText' : 'CORRESPONDENCE_TECH_STAT_TEXT',
        'indicatorFlag'             : 'IB_CORRESP_INDICATOR',
        'dateReceived'              : 'IB_CORRESP_DATE_RECEIVED',
        'appFormKey'                : 'APP_FORM_KEY',
        'correspondenceRecipient'   : 'CORRESPONDENCE_RECIPIENT',
        'correspondenceKey'         : 'CORRESPONDENCE_KEY',
        'contractAccountId'         : 'CONTRACT_ACCOUNT'


  //      'documentNumber'        : 'DOCUMENT_NUMBER',
  //     'writeOffDocumentNumber': 'WRITE_OFF_DOCUMENT_NUMBER',
    //    'companyCode'           : 'COMPANY_CODE',
  //      'writeOffAmount'        : 'WRITE_OFF_AMOUNT',
  //      'writeOffReasonCode'    : 'WRITE_OFF_REASON_CODE',
  //      'writeOffReasonText'    : 'WRITE_OFF_REASON_TEXT',
  //      'writeOffDate'          : 'WRITE_OFF_DATE',
 //       'reversedFlag'          : 'REVERSED_FLAG',
 //       'contractAccountId'     : 'CONTRACT_ACCOUNT'
    ]

    // Build the XML structure with namespace
    xml.'n0:IsuC4cV2CorrespHistGet'('xmlns:n0': 'urn:sap-com:document:sap:soap:functions:mc-style') {
        // Separate handling for dueDateFrom and dueDateTo
        if (jsonObject.dueDateFrom || jsonObject.dueDateTo) {
            ItDueDate {
                'item' {
                    Sign('I')
                    Option('BT')
                    DateFrom(jsonObject.dueDateFrom?.get(0)?.value ?: '')
                    DateTo(jsonObject.dueDateTo?.get(0)?.value ?: '')
                }
            }
        }

        jsonObject.each { key, value ->
            switch (key) {
                case 'top':
                    IvTop(value)
                    break
                case 'skip':
                    IvSkip(value)
                    break
                    
                case 'orderBy':
                    // Convert the value if a mapping exists; otherwise, use the original value
                    def mappedValue = fieldMapping.get(value, value)
                    IvSortField(mappedValue)
                    break
                case 'orderByType':
                    IvSortType(value)
                    break
                    
                    
                case 'businessPartnerId':
                    ItBusinessPartner {
                        value.each { BP ->
                            'item' {
                                Sign('I')
                                Option(BP.operator)
                                Low(BP.value.trim())
                            }
                        }
                    }
                    break
                case 'contractAccountId':
                    ItContractAccount {
                        value.each { ca ->
                            'item' {
                                Sign('I')
                                Option(ca.operator)
                                Low(ca.value.trim())
                            }
                        }
                    }
                    break
                case 'correspondenceStatus':
                    ItCorrespondenceStatus {
                        value.each { cs ->
                            'item' {
                                Sign('I')
                                Option(cs.operator)
                                Low(cs.value.trim())
                            }
                        }
                    }
                    break
                case 'technicalCorrespondenceStatusCode':
                    ItCorrespondenceTechStatus {
                        value.each { tcs ->
                            'item' {
                                Sign('I')
                                Option(tcs.operator)
                                Low(tcs.value.trim())
                            }
                        }
                    }
                    break
                case 'correspondenceType':
                    ItCorrespondenceType {
                        value.each { ct ->
                            'item' {
                                Sign('I')
                                Option(ct.operator)
                                Low(ct.value.trim())
                            }
                        }
                    }
                    break
                default:
                    // Handle any additional dynamic fields here if necessary
                    break
            }
        }

        // Always include ItAdditionalFilter with constant values
        ItAdditionalFilter {
            'item' {
                Fieldname('QueryFilter')
                FieldValue(headers.get("QueryFilter"))
                Sign('I')
                Option('')
                Low("")
                High("")
            }
        }
    }

    // Set the XML output as the message body
    message.setBody(writer.toString())

    return message
}
