/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
   
    def map = message.getProperties();
    def method = map.get("method");
    def taxNo = map.get("taxNo");
    def header = map.get("head");
    // def invoiceMap = map.get("map");
    def control = map.get("control");
    def syncMode = map.get("syncMode");
    def sourceSystem = map.get("sourceSystem")
    
    message.setProperty("logKey","general");
    
    if(sourceSystem == null || sourceSystem == ""){
        sourceSystem = "Unknown System";
    }
    
    if(method == 'I'){
        method = "open"
        message.setProperty("method","open");
    }else if(method == 'C'){
        method = "cancel"
        message.setProperty("method","cancel");
    }
    
    message.setProperty("sourceSystem",sourceSystem);
    message.setHeader("sourceSystem",sourceSystem);

    if(control.length == 0){
    	message.setProperty("successCode","200008");
        message.setProperty("errorMessage","XML格式错误");
        message.setProperty("detailMessage","XML格式错误, 找不到<Control>节点");
        message.setProperty("generalError","1");
        return message;
    }
    
    if((header == null || header.length == 0) && method == 'open'){
    	message.setProperty("successCode","200010");
        message.setProperty("errorMessage","XML格式错误");
        message.setProperty("detailMessage","XML格式错误, 找不到<GTDocument>节点下的<GTHeader>节点");
        message.setProperty("generalError","1");
        return message;
    }
    
    if(method != 'open' && method != 'cancel'){
    	message.setProperty("successCode","200001");
        message.setProperty("errorMessage","不支持的操作类型");
        message.setProperty("detailMessage","操作为空或不支持的操作类型，目前支持的类型为I和C");
        message.setProperty("generalError","1");
        return message;
    }
    if(taxNo == ''){
        message.setProperty("successCode","200002");
        message.setProperty("errorMessage","税号不能为空");
        message.setProperty("detailMessage","发票请求中，税号不能为空，请确保taxnumber不为空");
        message.setProperty("generalError","1");
        return message;
    }
    if(syncMode != 'sync' && syncMode != 'async'){
        message.setProperty("syncMode","async");
        return message;
    }
    
    
    return message;
}