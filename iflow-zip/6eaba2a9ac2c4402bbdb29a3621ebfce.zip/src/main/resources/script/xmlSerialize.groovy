import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.Exception;
import java.lang.String;
import java.math.BigDecimal;
import groovy.xml.XmlUtil;
import groovy.util.*;
import groovy.util.XmlParser;

def Message processData(Message message) {
    String content = message.getBody(java.lang.String) as String;
	def rootNode = new XmlParser().parseText(content)
//     def bodyObj = new XmlSlurper().parseText(body);
//   String responseBody = XmlUtil.serialize(bodyObj);
//     def sw = new StringWriter();
//     def nodePrinter = new XmlNodePrinter(new PrintWriter(sw));
//     nodePrinter.setPreserveWhitespace(true);
//     nodePrinter.print(bodyObj);
//     def newXml = sw.toString();
    String responseBody = XmlUtil.serialize(rootNode);
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("responseBody",responseBody, "text/plain");
    message.setBody(responseBody);
    return message;
}