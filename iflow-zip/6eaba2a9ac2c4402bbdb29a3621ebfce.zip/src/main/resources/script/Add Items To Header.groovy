/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
 which includes helper methods useful for the content developer:
 The methods available are:
 public java.lang.Object getBody()
 public void setBody(java.lang.Object exchangeBody)
 public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
 public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
 public void setHeader(java.lang.String name, java.lang.Object value)
 public java.util.Map<java.lang.String,java.lang.Object> getProperties()
 public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 public void setProperty(java.lang.String name, java.lang.Object value)
 public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
 public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
 public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.*;
import groovy.xml.*;
import org.w3c.dom.*;

def Message processData(Message message) {
	//Body
	String body = message.getBody(java.lang.String) as String;
	def rootObj = new XmlSlurper().parseText("<GoldenTax></GoldenTax>");
	def bodyObj = new XmlSlurper().parseText("<Control></Control>");
	def mappingObj = new XmlSlurper().parseText("<Mapping></Mapping>");
	
	def errorSource = "CPI";
	def map = message.getProperties();
	def invoiceObj = new XmlSlurper().parseText("<GTDocument></GTDocument>");

	def headObj = new XmlSlurper().parseText(body);
	
	//def items = map.get("items");
	def mapItem = map.get("map");
	def controllItem = map.get("control");
	
	def method = map.get("method");

    //get direct childnodes for control
    if(method == 'open'){
        for (int i = 0; i < controllItem.getLength(); i++) {
		    def item = controllItem.item(i);
		    def itemInfo = item.getChildNodes();
		    for (int y = 0; y < itemInfo.getLength(); y++) {
			    def info = itemInfo.item(y);
			    if(info.getNodeName() != 'GTDocument'){
				    if(info.getFirstChild() != null )
			            bodyObj.appendNode(info);
			    }   
		    } 
	    }
    	String responseControl = XmlUtil.serialize(bodyObj);
    	responseControl = responseControl.replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&quot;', '"').replaceAll('&apos;', "'").replaceAll('&amp;', '&').replaceAll("<\\?xml(.+?)\\?>", "");
    	bodyObj = new XmlSlurper().parseText(responseControl);	    
	    invoiceObj.appendNode(headObj);
	    bodyObj.appendNode(invoiceObj);
    }
    
    //get direct childnodes for control
    if(method == 'cancel'){
        for (int i = 0; i < controllItem.getLength(); i++) {
		    def item = controllItem.item(i);
		    def itemInfo = item.getChildNodes();
		    for (int y = 0; y < itemInfo.getLength(); y++) {
			    def info = itemInfo.item(y);
			    if(info.getNodeName() != 'Mapping'){
				    if(info.getFirstChild() != null )
			            bodyObj.appendNode(info);
			    }   
		    } 
	    }
	    mappingObj.appendNode(headObj);
	    bodyObj.appendNode(mappingObj);
    }


	rootObj.appendNode(bodyObj);
	String responseBody = XmlUtil.serialize(rootObj);
	//responseBody = responseBody.replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&quot;', '"').replaceAll('&apos;', "'").replaceAll('&amp;', '&').replaceAll("<\\?xml(.+?)\\?>", "");
	message.setBody(responseBody);
	
	return message;
}
