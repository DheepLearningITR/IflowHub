import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import java.util.HashMap;
def Message processData(Message message) {
    def properties = message.getProperties();
    
    def body = message.getBody(java.lang.String) as String;
    def ExternalProperty = properties.get("ReplicateBusinessPartnerStatus");
    def nodeList = [];
    def idSet = [];
    def bpid = '';
    def jsonObject = new JsonSlurper().parseText(body);
    def jsonRelation = jsonObject.root.Relationships.Relation;
    if(ExternalProperty.equals('requested')){
        if(jsonRelation instanceof java.util.ArrayList){
            for ( def rel : jsonRelation){
                def BPID = rel.get("BPID");
            //println(BPID)
                if(!idSet.contains(BPID)){
                idSet.add(BPID)
                nodeList.add(rel)
            
                }   
        
            }
        jsonObject.root.Relationships.Relation = nodeList;
        }
    }

message.setBody(new JsonBuilder(jsonObject).toPrettyString())
   
return message;
}