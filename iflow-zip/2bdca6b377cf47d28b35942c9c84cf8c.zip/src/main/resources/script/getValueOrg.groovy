import com.sap.it.api.mapping.*;

def String getValue(String property, String Id, MappingContext context){
    
	def contactPersonId = context.getProperty(Id+"contact");
	def status = context.getProperty("ReplicateBusinessPartnerStatus");
	if(status.equals("requested")){
	    if(context.getProperty(contactPersonId+property).equals('') || context.getProperty(contactPersonId+property) == null)
	    return '';
	    else 
	    return context.getProperty(contactPersonId+property)
	}
	return '';
}