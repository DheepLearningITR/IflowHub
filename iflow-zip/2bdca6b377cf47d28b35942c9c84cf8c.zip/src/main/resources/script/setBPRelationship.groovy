import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    if(message.getBody() != ''){
    message.setProperty("BusinessPartnerRelationship", body)
    }
    return message;
}