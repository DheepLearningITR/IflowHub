import com.sap.it.api.mapping.*;

def String getDepartment(String blankString, MappingContext context){
    def department = context.getProperty("department")
	return department 
}