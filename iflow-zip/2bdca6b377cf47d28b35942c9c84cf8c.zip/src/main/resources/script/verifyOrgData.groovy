import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder
import groovy.util.XmlParser;
def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties() as Map<String, Object>;
    def xmlBody = properties.get("BusinessPartnerOrganizationPayload");
    def RoleCode = properties.get("RoleCode");
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    if(!object.OrgData.isEmpty()){
    def organization = object.OrgData.organization;
    def fieldSet = [];
     def messageLog = messageLogFactory.getMessageLog(message);
    
     def xmlObject = new XmlParser().parseText(xmlBody);
      def bpObject = xmlObject.BusinessPartnerSUITEReplicateRequestMessage;
      if( organization instanceof groovy.json.internal.LazyMap){
          for(def bp : bpObject){
           if(bp.BusinessPartner.Role.RoleCode.text().contains(RoleCode)){
               def orgID = organization.get("organization.BPID")
               if(bp.BusinessPartner.InternalID.text().equals(orgID))
               {
                     
                   fieldSet.add(organization)
               }
           }
       }
          
      }else{
          for( def org : organization){
               for(def bp : bpObject){
           if(bp.BusinessPartner.Role.RoleCode.text().contains(RoleCode)){
               def orgID = org.get("organization.BPID")
               if(bp.BusinessPartner.InternalID.text().equals(orgID))
               {
                   fieldSet.add(org)
               }
           }
       }
          }
      }
     object.OrgData.organization = fieldSet
     body = new JsonBuilder(object).toPrettyString();
     def jsonCount = object.OrgData.organization;
     
     if(jsonCount.size() > 0){
        message.setProperty("OrganizationCounter", jsonCount.size());   
        
     }else{
          message.setProperty("OrganizationCounter", jsonCount.size()); 
     }
    message.setProperty("BusinessPartnerOrganisation", body);
   message.setBody(body);
    }else{
        message.setProperty("OrganizationCounterouterloop",'0');
    }
      
   
    return message;
}