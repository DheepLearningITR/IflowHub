import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
def body = message.getBody(java.lang.String) as String;
def properties = message.getProperties() as Map<String, Object>;
def organizationPayload= properties.get("BusinessPartnerOrganisation");
def relationshipPayload = properties.get("BusinessPartnerRelationship");
 def jsonSlurper = new JsonSlurper();
 def contactPersonData = jsonSlurper.parseText(body);
 def organizationData = jsonSlurper.parseText(organizationPayload);
def relationshipData = jsonSlurper.parseText(relationshipPayload);
def relationship = relationshipData.root.Relationships.Relation;
def contactPerson = contactPersonData.Payload.customers;

def orgData = organizationData.OrgData.organization;
def newContactPersonData = [];
def newRelationshipData = [];
def uidArray = [];

for(def data : orgData){
    if(relationship instanceof groovy.json.internal.LazyMap){
         newRelationshipData.add(relationship);
           if(contactPerson instanceof groovy.json.internal.LazyMap){
              if(contactPerson.get("customer").get("UID").equals(relationship.get("UID") )){
                            if(!uidArray.contains(relationship.get("UID"))){
                                newContactPersonData.add(contactPerson);
                                uidArray.add(relationship.get("UID"));
                            }
                        }
               
           }else{
            for( def contact : contactPerson){
                //println(contact.getClass())
                if(contact instanceof groovy.json.internal.LazyMap){
                    if(!contact.isEmpty()){
                        if(contact.get("customer").get("UID").equals(relationship.get("UID") )){
                             if(!uidArray.contains(relationship.get("UID"))){
                                newContactPersonData.add(contact);
                                uidArray.add(relationship.get("UID"));
                            }
                        }
                    }
                }else if(contact instanceof java.lang.String){
                    
                }
                else{
                    println(contact.getClass())
                     if(!contact){
                         //println(contact.getClass())
                        if(contact.getValue().get("UID").equals(rel.get("UID"))){
                             if(!uidArray.contains(relationship.get("UID"))){
                                newContactPersonData.add(contact);
                                uidArray.add(relationship.get("UID"));
                            }
                        }
                    }
                }
            }
        }
        
       
   }else{
    
    for(def rel : relationship){
        if ( rel.get("BPID").equals(data.get("organization.BPID"))){
            newRelationshipData.add(rel);
            for( def contact : contactPerson){
                if(contact instanceof groovy.json.internal.LazyMap){
                    if(!contact.isEmpty()){
                        if(contact.get("customer").get("UID").equals(rel.get("UID") )){
                             if(!uidArray.contains(rel.get("UID"))){
                                newContactPersonData.add(contact);
                                uidArray.add(rel.get("UID"));
                            }
                        }
                    }
                }else if(contact instanceof java.lang.String){
                    
                }else{
                     if(!contact){
                        if(contact.getValue().get("UID").equals(rel.get("UID"))){
                             if(!uidArray.contains(rel.get("UID"))){
                                newContactPersonData.add(contact);
                                uidArray.add(rel.get("UID"));
                            }
                        }
                    }
                }
            }
        }
        
    }
   }
}
relationshipData.root.Relationships.Relation = newRelationshipData;
contactPersonData.Payload.customers = newContactPersonData ; 
relationshipPayload = new JsonBuilder(relationshipData).toPrettyString();
//= newContactPersonData;
body = new JsonBuilder(contactPersonData).toPrettyString();

message.setProperty("BusinessPartnerRelationship",relationshipPayload);
message.setProperty("BusinessPartnerContactData",body)
message.setBody(body);

  return message;
}