import com.sap.it.api.mapping.*;


def String getRoleValue(String RoleID, MappingContext context){
    String delegatedAdmin = context.getProperty("DelegatedAdminRole");
    String admin = context.getProperty("AdminRole")
    String customer = context.getProperty("CustomerRole")
    String delimiter = ","
    String role = "";
    if(RoleID.equals("0001")){
         role = admin.concat(delimiter).concat(delegatedAdmin);
    }else if(RoleID.equals("0002")){
        role = admin.concat(delimiter).concat(delegatedAdmin).concat(delimiter).concat(customer);
    }else if(RoleID.equals("0011")){
        role = customer;
    }else{
        return role;
    }
	return role;
}