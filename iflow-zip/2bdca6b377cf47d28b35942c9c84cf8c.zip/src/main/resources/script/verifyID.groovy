import com.sap.it.api.mapping.*;
import java.util.HashMap;
import groovy.json.JsonSlurper;


def String verifyID(String contactPersonID, MappingContext context){
    def body = context.getProperty("ContactPersonData");
    def object = new JsonSlurper().parseText(body);
    def relationship = context.getProperty("BusinessPartnerRelationship")
    def relObject = new JsonSlurper().parseText(relationship);
    def relation = relObject.root.Relationships.Relation;
    def contacts = object.Relationships.ContactPersonData;
       if(contacts instanceof java.util.ArrayList){
        for(def contact : contacts){
            def ID = contact.ContactPersonID;
            def OrganizationID = contact.OrganizationID;
            if(relation instanceof java.util.ArrayList){
                for( def rel : relation){
                    if(ID.equals(rel.UID) && OrganizationID.equals(rel.BPID) && ID.equals(contactPersonID)){
                        return contactPersonID;
                    }
               
                }
            }else{
               // if(ID.equals(relation.get("UID")) && OrganizationID.equals(relation.get("BPID")) && ID.equals(Id)){
                if(ID.equals(relation.get("UID")) && OrganizationID.equals(relation.get("BPID")) && ID.equals(contactPersonID)){
                    return contactPersonID;
                    
                }
            }
      }
    }else{
        def OrganizationID = contacts.OrganizationID;
        def ID = contacts.ContactPersonID;
        if(relation instanceof java.util.ArrayList){
            
        
            for( def rel : relation){
               // if(ID.equals(rel.UID) && OrganizationID.equals(rel.BPID) && ID.equals(Id)){
                if(ID.equals(relation.get("UID")) && OrganizationID.equals(relation.get("BPID")) && ID.equals(contactPersonID)){
                    return contactPersonID;
                }
               
            }
        }else{
           // if(ID.equals(relation.get("UID")) && OrganizationID.equals(relation.get("BPID")) && ID.equals(Id)){
            if(ID.equals(relation.get("UID")) && OrganizationID.equals(relation.get("BPID")) && ID.equals(contactPersonID)){
                   return contactPersonID;
                    
            }
        }
    }
	return 'false'
}