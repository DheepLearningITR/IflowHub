import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    if(body.isEmpty()){
    message.setProperty("BPCustomerStatus" , '0')}
    else{
     message.setProperty("BPCustomerStatus" , '1')
    }
    
return message;
}
