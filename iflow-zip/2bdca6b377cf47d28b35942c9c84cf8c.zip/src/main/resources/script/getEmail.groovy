import com.sap.it.api.mapping.*;

def String getEmail(String arg1, MappingContext context){
	return context.getProperty('EmailID') 
}