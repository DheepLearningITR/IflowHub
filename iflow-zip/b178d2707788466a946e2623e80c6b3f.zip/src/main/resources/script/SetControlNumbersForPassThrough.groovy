import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.nrc.NumberRangeConfigurationService;

def Message processData(Message message) {
	def NRCS = ITApiFactory.getApi(NumberRangeConfigurationService.class, null);

	def headers													=   message.getHeaders();
	def sndDocumentStandard             =   headers.get("SAP_EDI_Document_Standard");
	def sndMessageVersion               =   headers.get("SAP_EDI_Message_Version");
	def sndMessageRelease               =   headers.get("SAP_EDI_Message_Release");
	def sndMessageType                  =   headers.get("SAP_EDI_Message_Type");
	def sndInterchangeControlNumber     =   headers.get("SAP_EDI_Interchange_Control_Number");
	def sndGroupControlNumber           =   headers.get("SAP_EDI_GS_Control_Number");
	// change to SAP_EDI_Message_Control_Number
	def sndMessageNumber                =   headers.get("SAP_EDI_Message_Control_Number");

 	def properties                      =   message.getProperties();
 	def recInterchangeControlNumberType =   properties.get("SAP_EDI_REC_Interchange_Control_Number_Type");
 	def recGroupControlNumberType       =   properties.get("SAP_EDI_REC_Group_Control_Number_Type");
 	def recMessageNumberType            =   properties.get("SAP_EDI_REC_Message_Number_Type");
 	
 	def recInterchangeControlNumber = "";
 	def recGroupControlNumber       = "";
    def recMessageNumber            = "";
 		
 	if (recInterchangeControlNumberType == null){
        recInterchangeControlNumberType = "ICN_DEFAULT";
    }
    try {
 	    recInterchangeControlNumber = NRCS.getNextValuefromNumberRange(recInterchangeControlNumberType, null);
 	   	recGroupControlNumber       = recInterchangeControlNumber;
 	   	recMessageNumber            = recInterchangeControlNumber;
 	  
 	    if (recGroupControlNumberType != null){
 		    recGroupControlNumber = NRCS.getNextValuefromNumberRange(recGroupControlNumberType, null);
 	    }
 		
 	    if (recMessageNumberType != null){
 		    recMessageNumber = NRCS.getNextValuefromNumberRange(recMessageNumberType, null);
 	    }
    } catch(Exception e){
        throw new IllegalStateException("Error reading number range " + recInterchangeControlNumberType);
    }

    message.setProperty("SAP_EDI_REC_Interchange_Control_Number", recInterchangeControlNumber);
    message.setProperty("SAP_EDI_REC_Group_Control_Number", recGroupControlNumber);
    message.setProperty("SAP_EDI_REC_Message_Number", recMessageNumber);
    message.setProperty("SAP_EDI_SND_Document_Standard", sndDocumentStandard);
    message.setProperty("SAP_EDI_SND_Standard_Version", sndMessageVersion);
    message.setProperty("SAP_EDI_SND_Standard_Release", sndMessageRelease);
    message.setProperty("SAP_EDI_REC_Standard_Message_Type", sndMessageType);
    message.setProperty("SAP_EDI_SND_Interchange_Control_Number", sndInterchangeControlNumber);
    message.setProperty("SAP_EDI_SND_Group_Control_Number", sndGroupControlNumber);
    message.setProperty("SAP_EDI_SND_Message_Number", sndMessageNumber);
    
    def targetSenderId = headers.get("SAP_TPM_REC_Sender_ID")
    if (targetSenderId != null) {
        message.setProperty("SAP_EDI_REC_Sender_ID", targetSenderId)
    }
    def targetReceiverId = headers.get("SAP_TPM_REC_Receiver_ID")
    if (targetReceiverId != null) {
        message.setProperty("SAP_EDI_REC_Receiver_ID", targetReceiverId)
    }
 
    return message; 
}