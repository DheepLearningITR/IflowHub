import com.sap.gateway.ip.core.customdev.util.Message
import org.w3c.dom.Document
import javax.xml.xpath.XPath
import javax.xml.xpath.XPathConstants
import javax.xml.xpath.XPathFactory
import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.Source
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import javax.xml.transform.Transformer
import javax.xml.transform.TransformerFactory
import javax.xml.transform.OutputKeys
import java.lang.Exception
import java.text.NumberFormat
import org.w3c.dom.Node
import org.w3c.dom.NodeList
import org.w3c.dom.Element
import org.xml.sax.InputSource
import org.w3c.dom.CDATASection;
import groovy.util.XmlSlurper
import groovy.xml.XmlUtil


def Message retrieveContent(Message message) {
	def xpath = XPathFactory.newInstance().newXPath()
	def properties = message.getProperties()
	def headers = message.getHeaders()
	Document document = message.getBody(Document.class)
	if (document == null){
		throw new IllegalStateException("Unable to get Body as XML Document")
	}
	Document content = parseXml(properties.get("ORIGINAL_CONTENT"))
	message.setBody(printSingleLineXml(content, byte[].class))
	return message
}

def Message retrieveZahtevka(Message message) {
	def xpath = XPathFactory.newInstance().newXPath()
	def properties = message.getProperties()
	Document content = parseXml(properties.get("ZAHTEVKA"))
	message.setBody(printSingleLineXml(content, byte[].class))
	return message
}

def Message retrieveAttachments(Message message) {
	def xpath = XPathFactory.newInstance().newXPath()
	def properties = message.getProperties()
	Document content = parseXml(properties.get("ATTACHMENTS"))
	message.setBody(printSingleLineXml(content, byte[].class))
	return message
}

def Message addSignedAttachments(Message message) {
	def xpath = XPathFactory.newInstance().newXPath()
	def properties = message.getProperties()
	def modTransformer = {
		it.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes")
	}
	Document attachments = message.getBody(Document.class)
	Document priloga = parseXml(properties.get("PROCESSED_PRILOGA"))
	CDATASection cData = priloga.createCDATASection(printSingleLineXml(attachments, String.class, modTransformer))
	Element prilogaElement = (Element)xpath.evaluate("/*[local-name()='Priloga']", priloga, XPathConstants.NODE)
	Node prilogaData = prilogaElement.getFirstChild()
	prilogaElement.removeChild(prilogaData)
	prilogaElement.appendChild(cData)
	message.setBody(printSingleLineXml(priloga, byte[].class))
	return message
}

def Message combineXml(Message message) {
	def xpath = XPathFactory.newInstance().newXPath()
	def properties = message.getProperties()
	def headers = message.getHeaders()
	def modTransformer = {
		it.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes")
	}
	Document signedPrilogy = message.getBody(Document.class)
	Document fullDocument = parseXml(properties.get("ORIGINAL_CONTENT"))
	Document signedZahtevka = parseXml(properties.get("ZAHTEVKA_SIGNED"))
	CDATASection cdataSection = fullDocument.createCDATASection(printSingleLineXml(signedZahtevka, String.class, modTransformer))
	
	Element originalEvemDoc = (Element)xpath.evaluate("/*[local-name()='OddajVlogoReq']/*[local-name()='EvemNDMDocument']", fullDocument, XPathConstants.NODE)
	Element originalZahtevka = (Element)xpath.evaluate("/*[local-name()='OddajVlogoReq']/*[local-name()='EvemNDMDocument']/*[local-name()='Zahtevek']/*[local-name()='xmlZahtevka']", fullDocument, XPathConstants.NODE)
	Node originalCdata = originalZahtevka.getFirstChild()
	originalZahtevka.removeChild(originalCdata)
	originalZahtevka.appendChild(cdataSection)
	
	NodeList prilogy = (NodeList)xpath.evaluate("/*[local-name()='OddajVlogoReq']/*[local-name()='EvemNDMDocument']/*[local-name()='Priloga']", fullDocument, XPathConstants.NODESET)
	for (int i = 0; i < prilogy.getLength(); ++i) {
		originalEvemDoc.removeChild(prilogy.item(i))
	}
	NodeList newEvemDoc = (NodeList)xpath.evaluate("/*[local-name()='OddajVlogoReq']/*[local-name()='EvemNDMDocument']/*[local-name()='Priloga']", signedPrilogy, XPathConstants.NODESET)
	for (int i = 0; i < newEvemDoc.getLength(); ++i) {
		Node importedPriloga = fullDocument.importNode(newEvemDoc.item(i), true)
		originalEvemDoc.appendChild(importedPriloga)
	}
	Document finalBody = parseXml(properties.get("ORIGINAL_BODY"))
	Element finalVloga = (Element)xpath.evaluate("/*[local-name()='submitVloga']", finalBody, XPathConstants.NODE)
	finalVloga.setTextContent(printSingleLineXml(fullDocument, String.class, modTransformer))
	message.setBody(printSingleLineXml(finalBody, byte[].class))
	return message
}

def Message rewrapEnvelope(Message message) {
	def properties = message.getProperties()
	def xpath = XPathFactory.newInstance().newXPath()
	def modTransformer = {
		it.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes")
	}
	Document originalEnvelope = parseXml(properties.get("ORIGINAL_BODY"))
	Document strippedRequest = message.getBody(Document.class)
	Element request = (Element)xpath.evaluate("/*[local-name()='statusiVlog']/*[local-name()='vlog']", strippedRequest, XPathConstants.NODE)
	String text = ""
	if (request != null) {
		text = request.getTextContent()
	}
	Element originalVlog = (Element)xpath.evaluate("/*[local-name()='statusiVlog']", originalEnvelope, XPathConstants.NODE)
	originalVlog.removeChild(originalVlog.getFirstChild())
	originalVlog.setTextContent(text)
	//originalVlog.setTextContent(printSingleLineXml(strippedRequest, String.class, modTransformer))
	message.setBody(printSingleLineXml(originalEnvelope, byte[].class))
	return message
}

def Message checkVersionRequirement(Message message) {
	def properties = message.getProperties()
	NumberFormat format = NumberFormat.getInstance(Locale.US)
	def number = format.parse(properties.get("VERSION_REQUIREMENT"))
	def version_requirement = number.doubleValue()
	if (version_requirement == 0){
		throw new IllegalStateException("Implement latest SAP Notes as described in SAP Note 3211436.")
	} else if (version_requirement > 1.0){
		throw new IllegalStateException("SCPI content for communication with SPOT needs to be updated to newer version.")
	}
	return message;
}

def printSingleLineXml(Document document, Class returnType = String.class, Closure modTransformer = null){
	Transformer transformer = TransformerFactory.newInstance().newTransformer()
	transformer.setOutputProperty(OutputKeys.INDENT, "no")
	if(modTransformer!=null){
		modTransformer.call(transformer)
	}
	switch(returnType) {
		case byte[].class:
			ByteArrayOutputStream bos = new ByteArrayOutputStream()
			transformer.transform(new DOMSource(document), new StreamResult(bos))
			return bos.toByteArray()
			break
		case String.class:
		default:
			StringWriter writer = new StringWriter()
			transformer.transform(new DOMSource(document), new StreamResult(writer))
			return writer.getBuffer().toString()
			break
	}
}

def parseXml(def source){
	def builder = DocumentBuilderFactory.newInstance().newDocumentBuilder()
	Document document
	switch(source.class) {
		case byte[].class:
			document = builder.parse(new ByteArrayInputStream(source))
			break
		case String.class:
		default:
			document = builder.parse(new InputSource(new StringReader(source)))
			break
	}
	//removeWhitspace(document)
	return document
}

def removeWhitspace(Document document){
	def xpath = XPathFactory.newInstance().newXPath()
	NodeList emptyTextNodes = (NodeList)xpath.evaluate("//text()[normalize-space(.) = '']", document, XPathConstants.NODESET)
	for (int i = 0; i < emptyTextNodes.getLength(); i++) {
		Node emptyTextNode = emptyTextNodes.item(i)
		emptyTextNode.getParentNode().removeChild(emptyTextNode)
	}
	document.normalize()
}
