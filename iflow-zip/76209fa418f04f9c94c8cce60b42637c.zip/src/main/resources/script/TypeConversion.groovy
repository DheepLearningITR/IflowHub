/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
     //Body
    def body = message.getBody(java.lang.String);

    def jsonSlurper = new JsonSlurper();
    def cfg = jsonSlurper.parseText(body);

    if(cfg.DeliveryRequest.MessageHeader.ReconciliationIndicator!=null){
        cfg.DeliveryRequest.MessageHeader.ReconciliationIndicator=Boolean.parseBoolean(cfg.DeliveryRequest.MessageHeader.ReconciliationIndicator);
    }

    if(cfg.DeliveryRequest.Delivery.HeaderGrossWeight!=null){
        cfg.DeliveryRequest.Delivery.HeaderGrossWeight.value=Double.parseDouble(cfg.DeliveryRequest.Delivery.HeaderGrossWeight.value);
    }
    if(cfg.DeliveryRequest.Delivery.HeaderNetWeight!=null){
        cfg.DeliveryRequest.Delivery.HeaderNetWeight.value=Double.parseDouble(cfg.DeliveryRequest.Delivery.HeaderNetWeight.value);
    }
    if(cfg.DeliveryRequest.Delivery.HeaderVolume!=null){
        cfg.DeliveryRequest.Delivery.HeaderVolume.value=Double.parseDouble(cfg.DeliveryRequest.Delivery.HeaderVolume.value);
    }

    if( cfg.DeliveryRequest.Delivery.PickingDateTime!=null && cfg.DeliveryRequest.Delivery.PickingDateTime.daylightSavingTimeIndicator!=null){
        cfg.DeliveryRequest.Delivery.PickingDateTime.daylightSavingTimeIndicator=Boolean.parseBoolean( cfg.DeliveryRequest.Delivery.PickingDateTime.daylightSavingTimeIndicator);
    }

    if( cfg.DeliveryRequest.Delivery.LoadingDateTime!=null && cfg.DeliveryRequest.Delivery.LoadingDateTime.daylightSavingTimeIndicator!=null){
        cfg.DeliveryRequest.Delivery.LoadingDateTime.daylightSavingTimeIndicator=Boolean.parseBoolean( cfg.DeliveryRequest.Delivery.LoadingDateTime.daylightSavingTimeIndicator);
    }

    if( cfg.DeliveryRequest.Delivery.GoodsIssueDateTime!=null && cfg.DeliveryRequest.Delivery.GoodsIssueDateTime.daylightSavingTimeIndicator!=null){
        cfg.DeliveryRequest.Delivery.GoodsIssueDateTime.daylightSavingTimeIndicator=Boolean.parseBoolean( cfg.DeliveryRequest.Delivery.GoodsIssueDateTime.daylightSavingTimeIndicator);
    }

    if( cfg.DeliveryRequest.Delivery.ProofOfDeliveryDateTime!=null && cfg.DeliveryRequest.Delivery.ProofOfDeliveryDateTime.daylightSavingTimeIndicator!=null){
        cfg.DeliveryRequest.Delivery.ProofOfDeliveryDateTime.daylightSavingTimeIndicator=Boolean.parseBoolean( cfg.DeliveryRequest.Delivery.ProofOfDeliveryDateTime.daylightSavingTimeIndicator);
    }

    if( cfg.DeliveryRequest.Delivery.ActualGoodsMovementDateTime!=null && cfg.DeliveryRequest.Delivery.ActualGoodsMovementDateTime.daylightSavingTimeIndicator!=null){
        cfg.DeliveryRequest.Delivery.ActualGoodsMovementDateTime.daylightSavingTimeIndicator=Boolean.parseBoolean( cfg.DeliveryRequest.Delivery.ActualGoodsMovementDateTime.daylightSavingTimeIndicator);
    }

    if( cfg.DeliveryRequest.Delivery.DeliveryDateTime!=null && cfg.DeliveryRequest.Delivery.DeliveryDateTime.daylightSavingTimeIndicator!=null){
        cfg.DeliveryRequest.Delivery.DeliveryDateTime.daylightSavingTimeIndicator=Boolean.parseBoolean( cfg.DeliveryRequest.Delivery.DeliveryDateTime.daylightSavingTimeIndicator);
    }

    if(cfg.DeliveryRequest.Delivery.JustInTimeHeader!=null && cfg.DeliveryRequest.Delivery.JustInTimeHeader.JITComponentIsReordered!=null)
    {
        cfg.DeliveryRequest.Delivery.JustInTimeHeader.JITComponentIsReordered=Boolean.parseBoolean(cfg.DeliveryRequest.Delivery.JustInTimeHeader.JITComponentIsReordered);
    }

    if( cfg.DeliveryRequest.Delivery.IsCopyWeightVolumeRequested!=null){
        cfg.DeliveryRequest.Delivery.IsCopyWeightVolumeRequested=Boolean.parseBoolean( cfg.DeliveryRequest.Delivery.IsCopyWeightVolumeRequested);
    }

    if( cfg.DeliveryRequest.Delivery.IsExportDelivery!=null){
        cfg.DeliveryRequest.Delivery.IsExportDelivery=Boolean.parseBoolean( cfg.DeliveryRequest.Delivery.IsExportDelivery);
    }


    cfg.DeliveryRequest.Delivery.DeliveryItem.each{

                if(it.UnlimitedOverdeliveryIsAllowed!=null)
                {
                    it.UnlimitedOverdeliveryIsAllowed=Boolean.parseBoolean(it.UnlimitedOverdeliveryIsAllowed);
                }
                if(it.ActualDeliveryQuantity!=null)
                {
                    it.ActualDeliveryQuantity.value=Double.parseDouble(it.ActualDeliveryQuantity.value);
                }
                if(it.ActualDeliveredQtyInBaseUnit!=null)
                {
                    it.ActualDeliveredQtyInBaseUnit.value=Double.parseDouble(it.ActualDeliveredQtyInBaseUnit.value);
                }
                if(it.OriginalDeliveryQuantity!=null)
                {
                    it.OriginalDeliveryQuantity.value=Double.parseDouble(it.OriginalDeliveryQuantity.value);
                }
                if(it.ItemNetWeight!=null)
                {
                    it.ItemNetWeight.value=Double.parseDouble(it.ItemNetWeight.value);
                }
                if(it.ItemGrossWeight!=null)
                {
                    it.ItemGrossWeight.value=Double.parseDouble(it.ItemGrossWeight.value);
                }
                if(it.ItemVolume!=null)
                {
                    it.ItemVolume.value=Double.parseDouble(it.ItemVolume.value);
                }

                if(it.DangerousGoodInformation!=null)
                {
                    if(it.DangerousGoodInformation.ExtendedInformation!=null)
                    {
                         if(it.DangerousGoodInformation.ExtendedInformation.Regulation!=null)
                        {
                            it.DangerousGoodInformation.ExtendedInformation.Regulation.each{
                                    if(it.ModeOfTransport!=null){
                                       it.ModeOfTransport.each{

                                        if(it.IMDGEmSchedFireIsUnderlined!=null)
                                        {
                                            it.IMDGEmSchedFireIsUnderlined=String.valueOf(it.IMDGEmSchedFireIsUnderlined).toBoolean();;
                                        }
                                        if(it.IMDGEmSchedSpillIsUnderlined!=null)
                                        {
                                            it.IMDGEmSchedSpillIsUnderlined=Boolean.parseBoolean(it.IMDGEmSchedSpillIsUnderlined);
                                        }
                                        if(it.ProdIsEnvironmentalHazardous!=null)
                                        {
                                            it.ProdIsEnvironmentalHazardous=Boolean.parseBoolean(it.ProdIsEnvironmentalHazardous);
                                        }
                                        if(it.ProductIsMarinePollutant!=null)
                                        {
                                            it.ProductIsMarinePollutant=Boolean.parseBoolean(it.ProductIsMarinePollutant);
                                        }
                                        if(it.OnlyReportableQtyIsToBePrinted!=null)
                                        {
                                            it.OnlyReportableQtyIsToBePrinted=Boolean.parseBoolean(it.OnlyReportableQtyIsToBePrinted);
                                        }
                                        if(it.DangerousGoodsQtyPointsValue!=null)
                                        {
                                            it.DangerousGoodsQtyPointsValue=Integer.parseInt(it.DangerousGoodsQtyPointsValue);
                                        }

                                     }

                                }
                            }
                        }
                        if(it.DngrsGdsEnclrNmbrOfInnerPckgs!=null)
                        {
                            it.DngrsGdsEnclrNmbrOfInnerPckgs=Integer.parseInt(it.DngrsGdsEnclrNmbrOfInnerPckgs);
                        }
                        if(it.DngrsGdsEnclrInnerPackageQty!=null)
                        {
                            it.DngrsGdsEnclrInnerPackageQty=Double.parseDouble(it.DngrsGdsEnclrInnerPackageQty)
                        }
                        if(it.OpenCupFlashPointTemperature!=null)
                        {
                            it.OpenCupFlashPointTemperature=Double.parseDouble(it.OpenCupFlashPointTemperature);
                        }
                        if(it.ClosedCupFlashPointTemperature!=null)
                        {
                            it.ClosedCupFlashPointTemperature=Double.parseDouble(it.ClosedCupFlashPointTemperature);
                        }
                        if(it.ChmlDensityAt20DegCelsiusQty!=null)
                        {
                            it.ChmlDensityAt20DegCelsiusQty=Double.parseDouble(it.ChmlDensityAt20DegCelsiusQty);
                        }
                        if(it.ChmlDensityAt15DegCelsiusQty!=null)
                        {
                            it.ChmlDensityAt15DegCelsiusQty=Double.parseDouble(it.ChmlDensityAt15DegCelsiusQty);
                        }
                        if(it.ChmlDensityAt50DegCelsiusQty!=null)
                        {
                            it.ChmlDensityAt50DegCelsiusQty=Double.parseDouble(it.ChmlDensityAt50DegCelsiusQty);
                        }
                        if(it.ChemicalBulkDensityQuantity!=null)
                        {
                            it.ChemicalBulkDensityQuantity=Double.parseDouble(it.ChemicalBulkDensityQuantity);
                        }
                        if(it.ControlTemperature!=null)
                        {
                            it.ControlTemperature=Double.parseDouble(it.ControlTemperature);
                        }
                        if(it.EmergencyTemperature!=null)
                        {
                            it.EmergencyTemperature=Double.parseDouble(it.EmergencyTemperature);
                        }
                        if(it.ChmlTempSenstvyLowrLmtTemp!=null)
                        {
                            it.ChmlTempSenstvyLowrLmtTemp=Double.parseDouble(it.ChmlTempSenstvyLowrLmtTemp);
                        }
                        if(it.ChmlTempSenstvyUprLmtTemp!=null)
                        {
                            it.ChmlTempSenstvyUprLmtTemp=Double.parseDouble(it.ChmlTempSenstvyUprLmtTemp);
                        }
                        if(it.FillingTemperature!=null)
                        {
                            it.FillingTemperature=Double.parseDouble(it.FillingTemperature);
                        }
                        if(it.KinematicViscosityQuantity!=null)
                        {
                            it.KinematicViscosityQuantity=Double.parseDouble(it.KinematicViscosityQuantity);
                        }
                    }
                    if(it.DangerousGoodInformation.BasicInformation!=null)
                    {
                         if(it.DangerousGoodInformation.BasicInformation.Regulation!=null)
                         {
                            it.DangerousGoodInformation.BasicInformation.Regulation.each
                            {
                                if(it.ModeOfTransport!=null)
                                {
                                    it.ModeOfTransport.each
                                    {
                                        if(it.ItemIsDangerousGood!=null)
                                        {
                                            it.ItemIsDangerousGood=Boolean.parseBoolean(it.ItemIsDangerousGood);
                                        }
                                        if(it.TransportIsAllowed!=null)
                                        {
                                            it.TransportIsAllowed=Boolean.parseBoolean(it.TransportIsAllowed);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
        }


       //if(cfg.DeliveryRequest.Delivery.HandlingUnit !=null){
        cfg.DeliveryRequest.Delivery.HandlingUnit.each{
                if( it.JITData!=null)
                {
                    if(it.JITData.JITCallSlotData!=null)
                    {
                        it.JITData.JITCallSlotData.each{
                            if(it.ReorderIndicator!=null)
                            {
                                it.ReorderIndicator=Boolean.parseBoolean(it.ReorderIndicator)
                            }
                        }
                    }
                }
                if(it.HeightMeasure!=null)
                {
                    it.HeightMeasure=Double.parseDouble(it.HeightMeasure);
                }
                if(it.LengthMeasure!=null)
                {
                    it.LengthMeasure=Double.parseDouble(it.LengthMeasure);
                }
                if(it.WidthMeasure!=null)
                {
                    it.WidthMeasure=Double.parseDouble(it.WidthMeasure);
                }
                if(it.GrossVolumeMeasure!=null)
                {
                    it.GrossVolumeMeasure=Double.parseDouble(it.GrossVolumeMeasure);
                }
                if(it.NetVolumeMeasure!=null)
                {
                    it.NetVolumeMeasure=Double.parseDouble(it.NetVolumeMeasure);
                }
                if(it.GrossWeightMeasure!=null)
                {
                    it.GrossWeightMeasure=Double.parseDouble(it.GrossWeightMeasure);
                }
                if(it.NetWeightMeasure!=null)
                {
                    it.NetWeightMeasure=Double.parseDouble(it.NetWeightMeasure);
                }

            }
       // }


    def builder = new groovy.json.JsonBuilder(cfg);
    //println(builder.toPrettyString());

    message.setBody(builder.toPrettyString());

    return message;
}
