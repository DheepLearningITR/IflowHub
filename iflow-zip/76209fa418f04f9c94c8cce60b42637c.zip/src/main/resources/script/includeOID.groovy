import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.slurpersupport.GPathResult;

def Message processData(Message message) {

    //Body
    def body = message.getBody(java.lang.String);
    GPathResult rootGPath = new XmlSlurper().parseText(body);
    Node rootNode = new XmlParser().parseText(body);

    String systemId = "";
    String deliveryDocument = "";
    //String primaryEmail = "";

    deliveryDocument = rootGPath.Delivery.DeliveryDocument;
    systemId = rootGPath.MessageHeader.SenderBusinessSystemID;
    /*primaryEmail = rootGPath.SalesOrder.Partner.find {it.PartnerFunction == "AG"}
            .Address.Communication.EmailAddress.text(); */
    
    if(!deliveryDocument.isEmpty() && !systemId.isEmpty()){
        String oid = "<DeliveryOID>SystemId:DeliveryDocument</DeliveryOID>";
        oid = oid.replace("SystemId", systemId);
        oid = oid.replace("DeliveryDocument", deliveryDocument);

        Node oidNode = new XmlParser().parseText(oid);
        for(int i=0; i<rootNode.children().size(); i++){
            if(rootNode.children().get(i).name().equals("Delivery")){
               rootNode.children().get(i).append(oidNode);
            }
        }
    }

    /*if(!primaryEmail.isEmpty()){
        String email = "<PrimaryEmail>email</PrimaryEmail>";
        email = email.replace("email", primaryEmail);

        Node emailNode = new XmlParser().parseText(email);
        for(int i=0; i<rootNode.children().size(); i++){
            if(rootNode.children().get(i).name().equals("SalesOrder")){
                rootNode.children().get(i).append(emailNode);
            }
        }
    }*/

    StringWriter stringWriter = new StringWriter();
    XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter));
    nodePrinter.setPreserveWhitespace(true);
    nodePrinter.print(rootNode);
    
    String result = stringWriter.toString();
    result = result.replace("n0:",""); //remove namspace prefix
    message.setBody(result);

    return message;
}
