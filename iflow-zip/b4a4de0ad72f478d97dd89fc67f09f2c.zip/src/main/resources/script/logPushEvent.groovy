import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.util.regex.Pattern;

def Message processData(Message message) {
	
	def pmap = message.getProperties();
	String enableLogging = pmap.get("ENABLE_PAYLOAD_LOGGING");
	String proxyType = pmap.get("SAP_ERP_proxyType_108");
	String ERPEndpointURL = pmap.get("SAP_ERP_PUSH_URL_IN");
	String regularExpression = pmap.get("REGULAR_EXPRESSION");
	
	Document bodyDoc = message.getBody(org.w3c.dom.Document);
	XPathFactory factory = XPathFactory.newInstance();
    xPath = factory.newXPath();
    NodeList ids = (NodeList) xPath.evaluate("//ROOT/userId", bodyDoc, XPathConstants.NODESET);
	
	if(enableLogging != null && enableLogging.toUpperCase().equals("TRUE")){
	    def messageLog = messageLogFactory.getMessageLog(message);
	    if(messageLog != null){
	        def body = message.getBody(java.lang.String) as String;
		    messageLog.addAttachmentAsString("EC Push Event", body, "text/xml");
	    }   
	}
	
	//error handling
	if(proxyType != null && proxyType.equals("default")){
        if(ERPEndpointURL != null && !ERPEndpointURL.startsWith("https")){
            throw new Exception("Configuration Error: Please enter https at the beginning of the ERP Connection Address.   ");
        }
    }
    
    //validate user IDs with regex, only if regex is provided
    if(regularExpression != null && !regularExpression.equals("")){
        for(int i = 0; i < ids.getLength(); i++){
            Node currentNode = ids.item(i);
            
            //evaluate regular expression
            if(!Pattern.matches(regularExpression, currentNode.getTextContent())){
                throw new Exception("The user ID " + currentNode.getTextContent() + " from the push event does not match the entered regular expression in the external parameter REGULAR_EXPRESSION.  ");
            }
        }
    }
	 
	return message;
}