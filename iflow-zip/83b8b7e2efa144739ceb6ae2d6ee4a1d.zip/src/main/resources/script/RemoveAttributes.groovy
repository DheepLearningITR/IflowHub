import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.*;
import groovy.xml.MarkupBuilder;
import groovy.xml.*


def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String) as String;
    // Parse the XML
    def xml = new XmlSlurper().parseText(body)

    // Remove the xsi:type attribute from OldValue and NewValue elements
    xml.'**'.findAll { it.name() in ['OldValue', 'NewValue'] }.each { it.attributes().remove('xsi:type') }

    // Convert the modified XML back to string
    def output = XmlUtil.serialize(xml)

    message.setBody(output)
    
    def messageLog = messageLogFactory.getMessageLog(message);
	
	
	if(messageLog != null)
	
	{
        String str = ""; 
        def Ids = message.getHeaders().get("Ids");
        
        xml.'**'.findAll { it.name() == 'records' }.each
        {
            str=it.Id.text();
            if(Ids == null)
            {
                 Ids = str+"\n";
            }
            else
            {
                 Ids = Ids+str+"\n";    
            }
            
			messageLog.addCustomHeaderProperty("Id", str);	
        }
	}

    return message;
}