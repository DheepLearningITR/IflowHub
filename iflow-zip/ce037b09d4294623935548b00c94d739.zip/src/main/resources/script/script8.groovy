import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {	
	def body = message.getBody(java.lang.String) as String;
	def headers = message.getHeaders() as Map<String, Object>;
	def properties = message.getProperties() as Map<String, Object>;
	
	def propertiesAsString ="\n";
	properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };
	
	def enableLog = properties.get("enableLog") as String;
	def statusCode = headers.get("CamelHttpResponseCode") as Integer;
	
	def headersAsString ="\n";
	headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };
	

	    message.setHeader("CamelHttpResponseCode",200);
	

	def messageLog = messageLogFactory.getMessageLog(message);
    if(enableLog == "true" && messageLog != null){
		messageLog.addAttachmentAsString("Log Message", "\n Body \n ----------  \n\n" + body,
		                                                    "text/xml");
	}
	
	return message;
}

