import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.olingo.odata2.api.uri.UriInfo;
import com.sap.gateway.ip.core.customdev.logging.*;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
	def headers = message.getHeaders() as Map<String, Object>;
	def properties = message.getProperties() as Map<String, Object>;

	def odataURI = new StringBuilder();
	def urlDelimiter = "&";
	
	def body = message.getBody(java.lang.String) as String;
	
	def root = new XmlSlurper().parseText(body);
    def productId = root.productId.text();
    def uom = root.uom.text();
    def map = message.getProperties();
    
    productId = URLEncoder.encode(productId);
    
    properties.put("productId",productId);
    
    if(uom.equals("")){
         odataURI.append("\$select=").append("Product");
         odataURI.append(urlDelimiter);
         odataURI.append("\$filter=").append("Product eq '"+productId+"'");
         message.setHeader("referencedPath","A_Product");
    }else{
        properties.put("unitOfMeasure",uom);
    	odataURI.append("\$filter=").append("Product eq '"+productId+"' and AlternativeUnit eq '"+uom+"'");
     	message.setHeader("currentUnitOfMeasure",uom);
        message.setHeader("referencedPath","A_ProductUnitsOfMeasure");
           
    }
     	
 	
 	message.setHeader("currentProductId",productId);
 	message.setHeader("odataURI",odataURI.toString());

	return message;
}