import com.sap.it.api.mapping.*;

def String customFunc(String arg1, String arg2){
	if(arg1 != null){
		return arg1;
	}
	else{
		return arg2;
	}
}