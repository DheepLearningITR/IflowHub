import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
   
    //Headers
    def headers = message.getHeaders()
    def deltaTimeStamp = headers.get("DeltaTimeStamp")
    def currentDateTime = headers.get("CurrentDateTime")
    def getDeletedUsers = headers.get("GetDeletedUsers")
    def countryCode = headers.get("CountryCode")
    
    def validitydateFilter = "(UserValidityEndDate eq datetime'0001-01-01T00:00:00' or UserValidityEndDate ge datetime'" + currentDateTime + "')"
    def validitydateFilterForDeletedusers = "UserValidityEndDate le datetime'" + currentDateTime + "'"
    
    if (getDeletedUsers && deltaTimeStamp){
        def deletedUsersQuery = '$filter=' + validitydateFilterForDeletedusers + " and EntityLastChangedOn ge datetimeoffset'" + deltaTimeStamp +"'"
        message.setProperty("p_query",deletedUsersQuery)
    }
    
    else if (deltaTimeStamp){
        def deltaQuery = '$filter=(' +  validitydateFilter + " and EntityLastChangedOn ge datetimeoffset'" + deltaTimeStamp +"')"
        message.setProperty("p_query",deltaQuery)
        
    }
    else if(countryCode){
        def countryCodeFilter = '$filter=' + 'CountryCode eq %27' +  countryCode + '%27 and '+  validitydateFilter
        message.setProperty("p_query",countryCodeFilter)
        
    }
    else
    {
        def query = '$filter=' + validitydateFilter
        message.setProperty("p_query",query)
    }
       
    return message
}