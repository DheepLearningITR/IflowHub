import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

Message processData(Message message) {

    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)
    def stripHtml = { html ->
        html?.replaceAll(/<[^>]+>/, '')?.replaceAll('&nbsp;', ' ')?.replaceAll(/&#(\d+);/) { m ->
            Character.toChars(m[1].toInteger()).toString()
        }?.trim()
    }



    def result = json.value.collect { item ->
        [
            ID         : item.id,
            URL        : item.url,
            Title      : item.fields["System.Title"],
            Description: stripHtml(item.fields["System.Description"]), 
            Status     : item.fields["System.State"]
        ]
    }

    message.setBody(JsonOutput.toJson(result))
    return message
}
