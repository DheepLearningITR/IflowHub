import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {
    // Get JSON body as string
    def body = message.getBody(String)
    
    // Parse the JSON
    def json = new JsonSlurper().parseText(body)

    // Extract IDs from workItems
    def idList = json.workItems*.id

    // Create comma-separated string
    def issuesListString = idList.join(',')

    // Set the property
    message.setProperty("IssuesList", issuesListString)

    return message
}
