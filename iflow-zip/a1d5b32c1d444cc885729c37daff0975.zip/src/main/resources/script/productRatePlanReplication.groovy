import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import java.util.HashMap;
import org.json.simple.*;
import groovy.json.*;
import javax.xml.bind.DatatypeConverter;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

def Message removeSnapshots(Message message) {
  def body = message.getBody(java.lang.String) as String;
  def jsonParser = new JsonSlurper();
  def jsonObject = jsonParser.parseText(body);

  // check and remove element 'snapshots'
  String snapShots = jsonObject.snapshots;
  if (snapShots == "[]") {
    jsonObject.remove('snapshots');
  }
  message.setBody(JsonOutput.toJson(jsonObject));
  return message;
}

def Message getSnapshots(Message message) {
  def body = message.getBody(java.lang.String) as String;
  def jsonParser = new JsonSlurper();
  def jsonObject = jsonParser.parseText(body);
  def snapShots = jsonObject.get("ns1:PATCH_patch_rate-plan_snapshots_InputMessage").get("ratePlanSnapshots");
  message.setBody(JsonOutput.toJson(snapShots));
  return message;
}

def Message formatOutput(Message message) {

  //Get Body 
  def body = message.getBody(String.class);

  //Define JSONSlurper
  def jsonSlurper = new JsonSlurper();

  //Handle empty payload and add dummy

  if ((body == null) || (body.isEmpty())) {
    empty = JsonOutput.toJson([dummy: 'true']);
    body = empty;
  }

  def list = jsonSlurper.parseText(body);

  //Define JSONObject and add a root node
  JSONObject myobj = new JSONObject();
  myobj.put("Root", list);

  //Format the JSON output
  def jsonOP = JsonOutput.toJson(myobj);

  //Set the modified JSON to body and return
  message.setBody(jsonOP);

  return message;
}

def Message setAccessTokenBody(Message message) {

  def map = message.getProperties();
  def CPQCredentials = map.get("CPQCredentials");

  def service = ITApiFactory.getApi(SecureStoreService.class, null);
  def credential = service.getUserCredential(CPQCredentials);

  if (credential == null) {
    String error = "No credential found for alias" + CPQCredentials;
    throw new IllegalStateException(error);
  }

  String user = credential.getUsername();
  int index = user.indexOf("#");
  String domain = user.substring(index + 1);
  String username = user.substring(0, index);
  String psword = new String(credential.getPassword());

  def body = message.getBody();
  body = "grant_type=password";
  body = body + "&username=" + username;
  body = body + "&password=" + psword;
  body = body + "&domain=" + domain;
  message.setBody(body);

  return message;

}