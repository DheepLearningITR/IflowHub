/*
 * This Script will build a query filter to get WO available in EC. Using this filter , it will query all WO corresponding to each CW which is
 * Active in EC and also include future dated WO.
 * And also it will store the current payload in property "reqArrived" this will be used after API call(request call).
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.List;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def map = message.getProperties();
	def len = map.get("length");
	def AllWorkOrderIds = map.get("AllWorkOrderId");
    String[] WOids = AllWorkOrderIds.split(" ");
    String str = "effectiveStatus eq 'A' and (";
    String separator = "";
    int i=Integer.parseInt(len.get(0));
    for(; i<WOids.length; i++){
        
        if(str.size() > 3900){
            break;
        }
        str += separator + "workOrderId eq '" + WOids[i] +"'";
        separator = " or ";
        
    }
    str += ")";
	if(i == WOids.length){
	    len.set(0,"-1");
	}
	else{
	    len.set(0,String.valueOf(i));
	}
	message.setProperty("QueryFilter",str);
	
	
	
	return message;
}

