import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext




def String generateUuid(String arg1){
	return UUID.randomUUID().toString()
}

def String generateMessageHeaderUUID(String value, MappingContext context){
    def messageId = UUID.randomUUID().toString()
    context.setProperty ("p_msg_header_id", messageId)
	return messageId
}


def String getUsageCode(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty(propertyName);
    return propertyValue;
}


def String removeLeadingZeros(String arg1){
	return arg1.replaceFirst('^0+(?!$)', "")
}
 
 
def void removeDuplicates(String[] input, Output output, MappingContext context) {
    def unique = input.unique();
    unique.each { v -> output.addValue(v) }
}    
    

