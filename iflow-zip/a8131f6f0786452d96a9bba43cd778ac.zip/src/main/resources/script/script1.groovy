import com.sap.gateway.ip.core.customdev.util.Message;
import java.io.Reader;
import groovy.xml.*;
 import groovy.util.*;

def Message processData(Message message) {
   //Body 
     def body = message.getBody(Reader);
     def String childNode = '''<MarketingAreaId>''' + " " + '''</MarketingAreaId>''';
     def xmlchild = new XmlSlurper( false, true ).parseText(childNode);
     def actMsg = new XmlSlurper( false, true ).parseText(body);
     // def actMsg = new XmlParser().parse(body);
     
     
     actMsg.appendNode( xmlchild );
     actMsg = XmlUtil.serialize(actMsg);
     
     message.setBody(body); 
     return message;
}