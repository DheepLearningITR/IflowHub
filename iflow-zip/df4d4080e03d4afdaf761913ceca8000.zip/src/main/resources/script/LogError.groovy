/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.HashMap;
import java.util.UUID; 
import java.util.Iterator; 
import java.util.List; 
import java.lang.Thread;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;
import groovy.xml.XmlUtil;


import java.util.Base64; 
import org.json.JSONObject; 
import org.json.JSONArray;
import org.json.JSONException;
import javax.ws.rs.core.MediaType;



def Message catchCamels(Message message){  
    
    def map  = message.getProperties();
    def ex   = map.get("CamelExceptionCaught");
    def exceptionText;
    def headerMap = message.getHeaders();
    
    if (ex != null)
    {
        exceptionText    = ex.getMessage();
        def messageLog   = messageLogFactory.getMessageLog(message);
        messageLog.addAttachmentAsString("Exception", exceptionText,"application/text");
     
        // copy the http error response body as a property 
        message.setProperty("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString()); 
        
        try { 
        
    		def mp = [
    		    "IBP Host" :  headerMap.get('IBPDestination'), 
    		    "IBP credentials" :  headerMap.get('IBPCredentials'), 
    		    "Status" : "error", 
    		    "stepStatus" : "error", 
    		    "ibpStep" :  message.getProperty('IBPStep'), 
    		    "Message" :  exceptionText
    		    ];
        
            def ibpCommitStatus = new JSONObject(mp).toString();
            
            message.setProperty("http.response", ibpCommitStatus);
    	    
    		message.setBody(ibpCommitStatus);
    		
    	} catch (JSONException e) { 
    		message.setBody(e);
    	}   
    }
    return message; 
} 


def String getCounter(String counterName,Message message) {
    Integer counterValue = message.getProperty(counterName) as Integer ?:0;
    counterValue = counterValue + 1;
    message.setProperty(counterName,counterValue);
    return counterValue;
}
 

def Message logMessage(java.lang.String fileName, Message message) {
	def body = message.getBody(java.lang.String);
	def messageLog = messageLogFactory.getMessageLog(message);
	def counter = getCounter(fileName + 'Counter',message).padLeft(3,' ');
	def logCounter = getCounter('OverallLogCounter',message).padLeft(4,' ');
	if(messageLog != null){
		messageLog.addAttachmentAsString(logCounter + " " + fileName + counter, body, "text/plain");
	};
	
	return message;
} 

def Message logException(Message message) {
    def exceptionText = message.getProperty("CamelExceptionCaught");
    message.setBody(exceptionText)
    message = logMessage("Exception - ", message);
	return message;
}

def Message logIBPMessage(Message message) {
    message = logMessage("IBP Log - ", message);
	return message;
}