/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
 
 import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.HashMap;
import java.util.UUID; 
import java.util.Iterator; 
import java.util.List; 
import java.lang.Thread;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;
import groovy.xml.XmlUtil; 

import java.util.Base64; 
import org.json.JSONObject; 
import org.json.JSONArray;
import org.json.JSONException;
import javax.ws.rs.core.MediaType;

import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
 

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher
import java.util.regex.Pattern



import java.util.Base64
import java.util.Base64.Decoder

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.KeyFactory;
import java.security.PrivateKey;
 


def Message processData(Message message) {
    //Headers
    def headers = message.getHeaders();
     
    message.setHeader("ExceptionSubProcess", "Error - needed deep tracing");
    
    return message;
}

def String genUUID(){ 
 
   return UUID.randomUUID().toString().replace("-", "").toUpperCase(); 

}

def String getTimeStamp(){
   //"yyyy-MM-dd'T'HH:mm:ss.SSSZ"
   return new Date().format("yyyy-MM-dd'T'HH:mm:ss",TimeZone.getTimeZone('GMT+2'))
}

def Message handleRequestToRead(Message message) {
    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body); 
    def queryString="" as String;
     
    // IBP Instance of the Supplier
    // in the format e.g. https://myXXXXXX-api.scmibp1.ondemand.com/sap/opu/odata/IBP/PLANNING_DATA_API_SRV/<<NAME of PLAN AREA>>
    if (input.IBPDestination == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPDestination", input.IBPDestination);
    }
    
    // Credentials used for the IBP instance
    if (input.IBPCredentials == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPCredentials", input.IBPCredentials);
    }
    
    // Planning area used in the IBP instance
    if (input.IBPPlanningArea == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPPlanningArea", input.IBPPlanningArea);
    }
    
    // Name of the Key figure that needs to be sent to Business Networks
    if (input.IBPKeyFigureName == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("IBPKeyFigureName", input.IBPKeyFigureName);
    }
    
    //Ariba Destination instance
    if (input.AribaTransactionURL == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("AribaTransactionURL", input.AribaTransactionURL);
    } 
    
    // Ariba ANID - as a supplier
    if (input.AribaSupplierANID == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("AribaSupplierANID", input.AribaSupplierANID);
    }
    
    // Ariba Shared secret - between the parties
    if (input.AribaSharedSecret == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("AribaSharedSecret", input.AribaSharedSecret);
    }
    
    // Ariba ANID - for the Buyer
    if (input.AribaBuyerANID == null) {
        message.setHeader("inputsAvailable", false);
        return message;
    } else {
        message.setHeader("AribaBuyerANID", input.AribaBuyerANID);
    }
    
   
    
    // for OData - Query select 
    if (input.IBPQuerySelectString != null) {
         queryString = '$inlinecount=allpages&$select=' + input.IBPQuerySelectString;
    } else {
        message.setHeader("inputsAvailable", false);
        return message;
    }
    
    // for OData - Query filter 
    if (input.IBPQueryFilterString != null) {
         queryString += '&$filter=' + input.IBPQueryFilterString;
    }else {
        message.setHeader("inputsAvailable", false);
        return message;
    } 
    
    // for OData - Optional Order by
    if (input.IBPQueryOrderBy != null) {
         queryString += '&$orderby=' + input.IBPQueryOrderBy;
    }
    
    if (queryString.length() > 1) {
          message.setHeader("IBPODataURLQuery", queryString);
    }else {
        message.setHeader("inputsAvailable", false);
        return message;
    }
    
    message.setProperty("IBPQueryUUID", genUUID())
    message.setProperty("CurrentTS", getTimeStamp())
    message.setProperty("iFlowId", "Ariba_Integration_IBP_Read");
    
    // IBP WS-RFC support in future
    message.setHeader("IBPQueryTimeAggregationLevel", input.IBPQueryTimeAggregationLevel);
    message.setHeader("IBPQueryKey1", input.IBPQueryKey1);
    message.setHeader("IBPQueryOffset1", input.IBPQueryOffset1);
    message.setHeader("IBPPackageSizeInRows", input.IBPPackageSizeInRows);
    
    
    message.setHeader("inputsAvailable", true);
    return message;
} 


def String convertMilliToDate(String millInput){

    Pattern pattern = Pattern.compile("\\d+")
    Matcher matcher = pattern.matcher(millInput)

    String simpleDate =  ""
    if (matcher.find()) {
        def millInputInLong = Long.valueOf(matcher.group())
        Date result_date = new Date( millInputInLong );
        DateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        simpleDate = simple.format(result_date);
    }

    return simpleDate;
}

def String getCounter(String counterName,Message message) {
    Integer counterValue = message.getProperty(counterName) as Integer ?:0;
    counterValue = counterValue + 1;
    message.setProperty(counterName,counterValue);
    return counterValue;
}
 

def Message logMessage(java.lang.String fileName, Message message) {
	def body = message.getBody(java.lang.String);
	def messageLog = messageLogFactory.getMessageLog(message);
	def counter = getCounter(fileName + 'Counter',message).padLeft(3,' ');
	def logCounter = getCounter('OverallLogCounter',message).padLeft(4,' ');
	if(messageLog != null){
		messageLog.addAttachmentAsString(logCounter + " " + fileName + counter, body, "text/plain");
	};
	
	return message;
} 

def Message logException(Message message) {
    def exceptionText = message.getProperty("CamelExceptionCaught");
    message.setBody(exceptionText)
    message = logMessage("Exception - ", message);
	return message;
}

def Message logIBPMessage(Message message) {
    message = logMessage("IBP Log - ", message);
	return message;
}