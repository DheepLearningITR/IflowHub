import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/



def void getDescription(String[] langu, String[] desc, Output output, MappingContext context){
    
 for( Integer i=0; i<langu.length; i++ )
    {
        if (langu[i].equals("EN"))
        {
            String value1 = desc[i];
            output.addValue(value1);
        }
    }  

}

def void getDefault(String[] input, Output output, MappingContext context){
    
    String value;
    
 for( Integer i=0; i<input.length; i++ )
    {
        value = input[i];
        
        if (input[i].equals("true"))
        {

            break;
        }
    }  
    
    output.addValue(value);

}


def String removeZeros(String input){

    BigDecimal bd;
    try
        {
	        bd = new BigDecimal(input);
	        return bd.toString();
        }
    catch(Exception e)
        {   
            return input;
        }           
}        
        

def void suppressMultipleContextValues (String[] input, Output output, MappingContext context){
		def values = [];
		if (input != null && input.length > 0) {
			for (int i = 0; i < input.length; i++) {
				if (!values.contains(input[i])) {
					values.add(input[i]);
					output.addValue(input[i]);
				} else {
					output.addSuppress();
				}
			}
		}
	}
        
        
        