import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def root = new XmlSlurper().parse(body)

    def persistedBigCommerceOrderBody = message.getProperty("bigCommerce_order_body")
    message.setBody(persistedBigCommerceOrderBody)
    message.setProperty("productsTaxRate", JsonOutput.toJson({}))

    def productIdToSkuMap = new JsonSlurper().parseText(message.getProperty("productIdToSkuMap"))

    def result = []
    root.tax.findAll { tax ->
        tax.line_item_type.text() == 'product'
    }.each { tax ->
        def productId = tax.order_product_id.text()
        def percentageRate = tax.rate.text()
        def sku = productIdToSkuMap.find { entry -> entry.id == productId }?.sku
        result << ["productId": productId, "percentageRate": percentageRate, "sku": sku]
    }

    def jsonOutput = JsonOutput.toJson(result)

    message.setProperty("productsTaxRate", jsonOutput)

    return message
}