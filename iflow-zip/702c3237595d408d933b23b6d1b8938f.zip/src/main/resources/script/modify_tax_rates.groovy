import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.util.XmlSlurper
import groovy.xml.XmlUtil

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def xml = new XmlSlurper().parse(body)
    def productsTaxRateString = message.getProperty("productsTaxRate")
    def productsTaxRate = new JsonSlurper().parseText(productsTaxRateString)
    def defaultTaxConditionCode = message.getProperty("default_tax_condition_type")

    productsTaxRate.each { element ->
        def sku = element.sku
        def percentageRate = element.percentageRate

        if (percentageRate != "0.0000"){
            def salesOrderTypeForProduct = xml.A_SalesOrderType.to_Item.A_SalesOrderItemType.find { node -> node.Material.text() == sku }
            def priceElementTypeForTax = salesOrderTypeForProduct?.to_PricingElement?.A_SalesOrderItemPrElementType?.find { node -> node.ConditionType.text() == defaultTaxConditionCode }
            priceElementTypeForTax?.ConditionRateValue = percentageRate
        }
    }

    def xmlMessage = XmlUtil.serialize(xml)
    message.setBody(xmlMessage)
    return message;
}
