import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def one_time_business_partner = message.getProperty("one_time_business_partner")
    message.setProperty("sold_to_party", one_time_business_partner)

    return message;
}
