import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){

		def bigCommerceOrderId = message.getProperty("bigCommerceOrderId") as String;	
		if(bigCommerceOrderId!=null && !bigCommerceOrderId.isEmpty()){
			messageLog.addCustomHeaderProperty("Updated Order with ID ", bigCommerceOrderId);		
        }
	}
	return message;
}