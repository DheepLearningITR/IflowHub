import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    // Workaround for the case when the response is empty
    def stringBody = message.getBody(String)
    
    if (!stringBody) {
        message.setProperty("hasNextPage", false)
        message.setProperty("isEmptyResponse", true)
        return message
    }

    def bigCommerceOrderQueryPage = message.getProperty("get_orders_page")
    def streamedBody = message.getBody(java.io.Reader)
    def xmlSlurper = new XmlSlurper()
    def xml = xmlSlurper.parse(streamedBody)

    if (!xml.order) {
        message.setProperty("hasNextPage", false)
        message.setProperty("isEmptyResponse", true)
    } else {
        def nextPageNumber = bigCommerceOrderQueryPage.toInteger() + 1
        message.setProperty("get_orders_page", nextPageNumber)
    }

    return message
}