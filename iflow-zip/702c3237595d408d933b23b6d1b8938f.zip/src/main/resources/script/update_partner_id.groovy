import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)
    def partnerID = xml.id.text()
    
    message.setProperty("sold_to_party", partnerID)

    return message
}