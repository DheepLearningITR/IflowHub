import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def slurper = new JsonSlurper()
    def json = slurper.parse(body)

    def persistedBigCommerceOrderBody = message.getProperty("bigCommerce_order_body")
    message.setBody(persistedBigCommerceOrderBody)
    
    json.data.each { transactionNode ->
        def status = transactionNode.status
        def event = transactionNode.event
        
        if (status == 'ok' && event == 'purchase') {
            def transactionId = transactionNode.id
            def gateway = transactionNode.gateway
            def createdAt = transactionNode.date_created
            def gatewayTransactionId = transactionNode.gateway_transaction_id
            
            def transactionText = """Transaction ID: ${transactionId}
Gateway: ${gateway}
Created At: ${createdAt}
Gateway Transaction ID: ${gatewayTransactionId}"""
           
            message.setProperty("s4hana_payment_transaction_details", transactionText)
            return message
        }
    }

    return message
}