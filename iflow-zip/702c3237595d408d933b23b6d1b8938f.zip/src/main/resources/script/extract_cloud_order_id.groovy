import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def slurper = new JsonSlurper()
    def json = slurper.parse(body)

    def persistedBigCommerceOrderBody = message.getProperty("bigCommerce_order_body")
    message.setBody(persistedBigCommerceOrderBody)
    message.setProperty("s_4hana_cloud_order_id", "")

    json.data.each { metafieldsNode ->
        def metafieldsKey = metafieldsNode.key

        if (metafieldsKey == "s_4hana_cloud_order_id") {
            def businessPartnerId = metafieldsNode.value
            message.setProperty("s_4hana_cloud_order_id", businessPartnerId)

            return message
        }
    }

    return message
}