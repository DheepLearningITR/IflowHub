import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)

    def result = []

    xml.order.consignments.shipping.shipping.line_items.line_items.each { lineItem ->
        def id = lineItem.id.text()
        def sku = lineItem.sku.text()
        result << [id: id, sku: sku]
    }
    def jsonOutput = JsonOutput.toJson(result)
    message.setProperty("productIdToSkuMap", jsonOutput)

    return message;
}