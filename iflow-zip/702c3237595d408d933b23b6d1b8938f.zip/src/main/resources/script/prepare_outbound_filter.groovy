import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def propertyOne = message.getProperty("sales_order_s4hana_id") as String
    def propertyTwo = message.getProperty("custom_s4hana_outbound_filter") as String
 
    def mergedValue = "SalesOrder eq " + propertyOne + " and " + propertyTwo
    
    message.setProperty("s4hana_outbound_filter", mergedValue)

    return message
}