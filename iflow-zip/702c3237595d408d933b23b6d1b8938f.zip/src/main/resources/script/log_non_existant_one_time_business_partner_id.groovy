import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def one_time_business_partner = message.getProperty("one_time_business_partner")
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        messageLog.addAttachmentAsString('Non_Existing_One_Time_SAP_S4HANA_Cloud_Business_Partner', one_time_business_partner, 'text/plain')
    }
    return message
}
