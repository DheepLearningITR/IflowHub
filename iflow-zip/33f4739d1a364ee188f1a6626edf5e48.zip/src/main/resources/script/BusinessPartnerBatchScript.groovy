import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	
	// Batch Payload
    String completePayload = "";
  
    // Generate Random Id to be used in Batch Code
    String batchId = UUID.randomUUID().toString();
  
    // Prepare Batch Code
    String batchCode = "--batch_id-" + batchId; 

	//Checking if there is only one Record
    if (!isCollectionOrArray(object.row)) {
        
		//Converting Record to an array
		object.row = [object.row].toArray();
    
	}
	
	// Set DRF bulk message id and sender system id as properties
	message.setProperty("messageID", object.messageID);
    //	message.setProperty("senderBusinessSystemID", object.senderBusinessSystemID);
	
	// Prepare changeset data by looping the list of records
	object.row.each { record ->
	
    	// Generate changeset Id to be used in changeset Code
        String changesetID = UUID.randomUUID().toString();
    	    
        // Prepare changeset Code for businesspartner payloads
        String changeset = "--changeset_" + changesetID;
        
        completePayload=completePayload.concat(batchCode + "\n")
        completePayload=completePayload.concat("Content-Type: multipart/mixed; boundary=changeset_"+changesetID+ "\n" + "\n")
	    
	    String tempPayload = changeset + "\n"
	    String contentId = "BP_" + record.businessPartnerNumber;
		
		tempPayload = tempPayload + "Content-Type:application/http " + "\n" + "Content-Transfer-Encoding:binary" + "\n" + "Content-ID:" + contentId + "\n" + "\n"
		tempPayload = tempPayload + "POST BusinessPartners HTTP/1.1" + "\n"
		tempPayload = tempPayload + "Accept:application/json;odata.metadata=minimal;IEEE754Compatible=true" + "\n" 
		tempPayload = tempPayload + "Accept-Language:en-US" + "\n" 
		tempPayload = tempPayload + "Content-Type:application/json;charset=UTF-8;IEEE754Compatible=true" + "\n" + "\n" 

	    if(record.isBlocked != null){
		    record.isBlocked = record.isBlocked.toLowerCase().toBoolean();
		}
		if(record.isReleased != null){
		    record.isReleased = record.isReleased.toLowerCase().toBoolean();
		}
		if(record.isMarkedForDeletion != null){
		    record.isMarkedForDeletion = record.isMarkedForDeletion.toLowerCase().toBoolean();
		}
		
        if(record.texts != null){
		   if(!isCollectionOrArray(record.texts)){
		        record.texts = [record.texts].toArray();
		    }
		}
		
		if(record.bpRoles != null){
		   if(!isCollectionOrArray(record.bpRoles)){
		        record.bpRoles = [record.bpRoles].toArray();
		    }
		}
		
		if(record.addressData != null){
		   if(!isCollectionOrArray(record.addressData)){
		        record.addressData = [record.addressData].toArray();
		    }
		    record.addressData.each { data ->
		        if (data.emailAddresses != null){
		            if(!isCollectionOrArray(data.emailAddresses)){
		                data.emailAddresses = [data.emailAddresses].toArray();
		            }
		            data.emailAddresses.each { email ->
		                if(email.usageDeniedIndicator != null){
		                    email.usageDeniedIndicator = email.usageDeniedIndicator.toLowerCase().toBoolean();
		                }
		            }
		        }
		        if (data.phoneNumbers != null){
		            if(!isCollectionOrArray(data.phoneNumbers)){
		                data.phoneNumbers = [data.phoneNumbers].toArray();
		            }
		            data.phoneNumbers.each { phone ->
		                if(phone.usageDeniedIndicator != null){
		                    phone.usageDeniedIndicator = phone.usageDeniedIndicator.toLowerCase().toBoolean();
		                }
		                if(phone.mobilePhoneNumberIndicator != null){
		                    phone.mobilePhoneNumberIndicator = phone.mobilePhoneNumberIndicator.toLowerCase().toBoolean();
		                }		                
		            }		            
		        }
		        if (data.usages != null){
		            if(!isCollectionOrArray(data.usages)){
		                data.usages = [data.usages].toArray();
		            }
		        }
		    }
		}
		
		if(record.customerInformation != null){
		    if(record.customerInformation.isMarkedForDeletion != null){
		        record.customerInformation.isMarkedForDeletion = record.customerInformation.isMarkedForDeletion.toLowerCase().toBoolean();
		    }
		    if(record.customerInformation.accountingInformation != null){
		        if(!isCollectionOrArray(record.customerInformation.accountingInformation)){
		            record.customerInformation.accountingInformation = [record.customerInformation.accountingInformation].toArray();
		        }
		        record.customerInformation.accountingInformation.each { account ->
		            if(account.isMarkedForDeletion != null){
		                account.isMarkedForDeletion = account.isMarkedForDeletion.toLowerCase().toBoolean();
		            }
		        }
		    }
		    if(record.customerInformation.customerSalesArrangements != null){
		        if(!isCollectionOrArray(record.customerInformation.customerSalesArrangements)){
		            record.customerInformation.customerSalesArrangements = [record.customerInformation.customerSalesArrangements].toArray();
		        }
		        record.customerInformation.customerSalesArrangements.each { item ->
		            if(item.isMarkedForDeletion != null){
		                item.isMarkedForDeletion = item.isMarkedForDeletion.toLowerCase().toBoolean();
		            }
		            if(item.customerSalesArrangementFunctions != null){
		                if(!isCollectionOrArray(item.customerSalesArrangementFunctions)){
		                    item.customerSalesArrangementFunctions = [item.customerSalesArrangementFunctions].toArray();
		                }
		            }
		            item.customerSalesArrangementFunctions.each { itemFunction ->
		                if(itemFunction.isDefault != null){
		                    itemFunction.isDefault = itemFunction.isDefault.toLowerCase().toBoolean();
		                }
		            }
		        }
		    }		    
		}

		if(record.supplierInformation != null){
		    if(record.supplierInformation.isMarkedForDeletion != null){
		        record.supplierInformation.isMarkedForDeletion = record.supplierInformation.isMarkedForDeletion.toLowerCase().toBoolean();
		    }
		    if(record.supplierInformation.purchasingAccounting != null){
		        if(!isCollectionOrArray(record.supplierInformation.purchasingAccounting)){
		            record.supplierInformation.purchasingAccounting = [record.supplierInformation.purchasingAccounting].toArray();
		        }
		        record.supplierInformation.purchasingAccounting.each { account ->
		            if(account.isMarkedForDeletion != null){
		                account.isMarkedForDeletion = account.isMarkedForDeletion.toLowerCase().toBoolean();
		            }
		        }
		    }
		    if(record.supplierInformation.purchasingArrangements != null){
		        if(!isCollectionOrArray(record.supplierInformation.purchasingArrangements)){
		            record.supplierInformation.purchasingArrangements = [record.supplierInformation.purchasingArrangements].toArray();
		        }
		        record.supplierInformation.purchasingArrangements.each { arrangement ->
		            if(arrangement.isMarkedForDeletion != null){
		                arrangement.isMarkedForDeletion = arrangement.isMarkedForDeletion.toLowerCase().toBoolean();
		            }
		        }
		    }
		}
		
		//convert the closure variable to Json output
		def sRecord = JsonOutput.toJson(record)
	    
		tempPayload = tempPayload + sRecord + "\n"
		
		completePayload = completePayload.concat(tempPayload)
		
		// Close the full payload
	    completePayload = completePayload + "--changeset_" + changesetID + "--" + "\n"
	}
	
	// Close the full payload
	completePayload = completePayload + "--batch_id-" + batchId + "--"
	
	// Prepare Message Body
	message.setBody(completePayload)
	
	// Prepare Boundary Header Parameter to be added in message header
	String boundaryParam = "multipart/mixed; boundary=batch_id-" + batchId;
	
	// Prepare Message Header
	message.setHeader('Content-Type', boundaryParam);
	message.setHeader('Prefer', "odata.continue-on-error");
	
    return message
}


//Returns true if object is an array
boolean isCollectionOrArray(object) {
    
	[Collection, Object[]].any {
        
		it.isAssignableFrom(object.getClass())
    
	}

}