import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {

	def body = message.getBody(String.class);
	def output;
	message.setProperty("isError", "true");
     
	//Setting the timestamp
	def now = new Date();
	message.setProperty("timestamp", now.format("yyyyMMddHHmmss", TimeZone.getTimeZone('UTC')));
	
	//parsing error message
	output = getErrorResponse(body,message); 
	if(!body.contains('error')) {
		message.setProperty("isError", "false");
	}
	 message.setBody(output);
	
    
	return message;
}

def String getErrorResponse(String response,Message message) {

    def jsonSlurper = new JsonSlurper();
	def errMsg, errObj, records;
	int iSuccess = 0,iTotal = 0, iFailure =0;
    def errorJson = jsonSlurper.parseText("{}");
    errorJson["Errors"] = [];
    // def successresp = new Node(null, 'root');

	response.split("HTTP/1.1").each { unit ->
        if("$unit".contains("201 Created") || "$unit".contains("200 OK"))
    	{
    	     iSuccess = iSuccess + 1;
    	     /*def s = "$unit".indexOf("Content-ID: BP_");
    	     def e = "$unit".lastIndexOf("");
    	     if(s != -1 && e != -1)
    	    {
    		  def bp =  "$unit".substring(s+15,e).trim();
    		  new Node(successresp,'BP_Number',bp);
    		 }*/
    	}
    	if(!"$unit".contains("201 Created") && !"$unit".startsWith("--changeset")) {
    		if(!"$unit".contains("200 OK") && !"$unit".startsWith("--changeset")) {
    		    def startIndex = "$unit".indexOf("{\"error\"");
    		    def endIndex = "$unit".indexOf("--changeset");
    		    if(endIndex == -1){
    		   	    endIndex = "$unit".indexOf("--batch");
    		    }
    		    if(startIndex != -1 && endIndex != -1)
    		    {
    				errMsg = "$unit".substring(startIndex,endIndex).trim();
                    errObj = jsonSlurper.parseText(errMsg.toString().replaceAll("@",""));
                    errorJson.Errors.push(errObj);
                    iFailure = iFailure + 1;
    		    }    
    		}
    	}
	}

//iSuccess = iSuccess / 2;
/*if(iSuccess > 0){
  message.setHeader("successresp",groovy.xml.XmlUtil.serialize(successresp));
}*/
message.setProperty("iSuccess",iSuccess);
message.setProperty("iFailure",iFailure);
iTotal = iSuccess + iFailure ;
message.setProperty("iTotal",iTotal);
records = JsonOutput.toJson(errorJson);
return records;
}