import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import java.io.StringReader
def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def properties = message.getProperties()
    def errorDetailedInfo = properties.get('ERROR_DETAILED_INFO')
    def rejectedLocs = properties.get('REJECTED_LOCATION_IDs')
    def noOfRejectedLocs = properties.get('NO_OF_REJECTED_LOCATIONS')
    def splittedLocs = rejectedLocs.split(',')
    def prefix = properties.get("PREFIX")
    def mdtName = properties.get("MDT")
    def separator = properties.get("SEPARATOR")
    def sPrefix = prefix.toString()
    def sMDTName = mdtName.toString()
    def sSeparator = separator.toString()

    def formattedIDs = splittedLocs.collect { input ->
    formatIDs(input, sPrefix, sMDTName, sSeparator)
    }

    def sNumberOfLocations = "Number of locations rejected for processing: " + noOfRejectedLocs
    def sListofLocationsIds = "\n\nLocation IDs rejected for processing:\n"+formattedIDs.join("\n")
    def sDetailedInfo = "\n\nDetailed Information:\n"+errorDetailedInfo
    def logResult = sNumberOfLocations + sListofLocationsIds + sDetailedInfo

    if(messageLog != null && noOfRejectedLocs > 0) {
    	messageLog.addAttachmentAsString("Location(s) Rejected for Processing", logResult, "text/plain")
     }
	return message
}


def formatIDs(input, sPrefix, sMDTName, sSeparator) {
    
    def withoutPrefix = ""
    def withoutMDTName = ""
    def defaultSeparator = "-"
    
    if(!(sPrefix.isEmpty() || sSeparator.isEmpty())) {

     withoutPrefix = input.replaceAll(sPrefix + sSeparator, "")
     withoutMDTName = withoutPrefix.replaceAll(sMDTName + sSeparator, "")
    
    } else if (sPrefix.isEmpty() && !sSeparator.isEmpty()) {

        withoutMDTName = input.replaceAll(sMDTName + sSeparator, "")
        
    } else if (!sPrefix.isEmpty() && sSeparator.isEmpty()) {

        withoutPrefix = input.replaceAll(sPrefix + defaultSeparator, "")
        withoutMDTName = withoutPrefix.replaceAll(sMDTName + defaultSeparator, "")
        
    } else {

        withoutMDTName = input.replaceAll(sMDTName + defaultSeparator, "")

    }
    return withoutMDTName
    
}