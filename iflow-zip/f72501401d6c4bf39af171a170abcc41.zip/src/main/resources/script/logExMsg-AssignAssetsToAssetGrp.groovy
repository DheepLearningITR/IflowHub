import com.sap.gateway.ip.core.customdev.util.Message
def Message processData(Message message) {
	def body = message.getBody(java.lang.String) as String
	def headers = message.getProperties()
	def payload = headers.get("Payload")
	def logExMsg = "Assign Assets to Asset Group Subflow - Exception Info"
	def logFailedPayload = "Assign Assets to Asset Group Subflow - Failed Payload"
	def msgLogFormat = "text/plain"
	def messageLog = messageLogFactory.getMessageLog(message)
	if(messageLog != null) {
	    messageLog.addAttachmentAsString(logExMsg, body, msgLogFormat)
	    messageLog.addAttachmentAsString(logFailedPayload, payload.toString(), msgLogFormat)
    }
	return message
}