import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def successLocsXml = message.getBody(java.io.Reader)
	def successLocsParsed = new XmlParser().parse(successLocsXml)
	def numberOfSuccessLocs = successLocsParsed.LOCATION.size()
	def assetIds = successLocsParsed.LOCATION.ASSET_ID.collect { it.text() }.join(',')
	message.setProperty('NO_OF_ACCEPTED_LOCATIONS', numberOfSuccessLocs)
	message.setProperty('ACCEPTED_LOCATION_IDs', assetIds)
	binding.variables.clear() //Purging all variables used in the script
    return message
}