import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
def Message processData(Message message) {
    def failedLocsXml = message.getBody(java.io.Reader)
	def failedLocsParsed = new XmlParser().parse(failedLocsXml)
	def numberOfFailedLocs = failedLocsParsed.LOCATION.size()
	def assetIds = failedLocsParsed.LOCATION.ASSET_ID.collect { it.text() }.join(',')
	message.setProperty('NO_OF_REJECTED_LOCATIONS', numberOfFailedLocs)
	message.setProperty('REJECTED_LOCATION_IDs', assetIds)
	message.setProperty('REJECTED_LOCATIONS_INFO', XmlUtil.serialize(failedLocsParsed))
	binding.variables.clear() //Purging all variables used in the script
    return message
}
