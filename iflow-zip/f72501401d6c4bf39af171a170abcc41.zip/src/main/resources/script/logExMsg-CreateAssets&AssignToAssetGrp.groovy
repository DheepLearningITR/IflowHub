import com.sap.gateway.ip.core.customdev.util.Message
def Message processData(Message message) {
	def body = message.getBody(java.lang.String) as String
	def properties = message.getProperties()
	def payload = properties.get("PAYLOAD")
	def logMsgFormat = "text/plain"
	def logMsgExpInfo = "Create Assets and Assign to Asset Group Subflow - Exception Info"
	def logMsgFailedPayload = "Create Assets and Assign to Asset Group Subflow - Failed Payload"
	def messageLog = messageLogFactory.getMessageLog(message)
	if(messageLog != null) {
    	messageLog.addAttachmentAsString(logMsgExpInfo, body, logMsgFormat)
    	messageLog.addAttachmentAsString(logMsgFailedPayload, payload.toString(), logMsgFormat)
     }
	return message
}