import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def properties = message.getProperties()
    def acceptedLocs = properties.get('ACCEPTED_LOCATION_IDs')
    def noOfSuccessLocs = properties.get('NO_OF_ACCEPTED_LOCATIONS')
    def splittedLocs = acceptedLocs.split(',')
    def prefix = properties.get("PREFIX")
    def mdtName = properties.get("MDT")
    def separator = properties.get("SEPARATOR")
    def sPrefix = prefix.toString()
    def sMDTName = mdtName.toString()
    def sSeparator = separator.toString()

    def formattedIDs = splittedLocs.collect { input ->
    formatIDs(input, sPrefix, sMDTName, sSeparator)
    }
    def sNumberOfLocations = "Number of locations accepted by Everstream for processing: " + noOfSuccessLocs
    def sListofLocationsIds = "\n\nLocation IDs accepted for processing:\n"+formattedIDs.join("\n")
    def logResult = sNumberOfLocations + sListofLocationsIds

    if(messageLog != null && noOfSuccessLocs > 0) {
    	messageLog.addAttachmentAsString("Success - Location(s) Accepted for Processing", logResult, "text/plain")
     }
	return message
}


def formatIDs(input, sPrefix, sMDTName, sSeparator) {
    
    def withoutPrefix = ""
    def withoutMDTName = ""
    def defaultSeparator = "-"
    
    if(!(sPrefix.isEmpty() || sSeparator.isEmpty())) {

     withoutPrefix = input.replaceAll(sPrefix + sSeparator, "")
     withoutMDTName = withoutPrefix.replaceAll(sMDTName + sSeparator, "")
    
    } else if (sPrefix.isEmpty() && !sSeparator.isEmpty()) {

        withoutMDTName = input.replaceAll(sMDTName + sSeparator, "")
        
    } else if (!sPrefix.isEmpty() && sSeparator.isEmpty()) {

        withoutPrefix = input.replaceAll(sPrefix + defaultSeparator, "")
        withoutMDTName = withoutPrefix.replaceAll(sMDTName + defaultSeparator, "")
        
    } else {

        withoutMDTName = input.replaceAll(sMDTName + defaultSeparator, "")

    }
    return withoutMDTName
    
}