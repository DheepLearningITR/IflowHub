import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
def messageLog = messageLogFactory.getMessageLog(message)
def properties = message.getProperties()
def listOfFailedItems = properties.get("FAILED_ASSETS")
def prefix = properties.get("PREFIX").toString()
def mdtName = properties.get("MDT").toString()
def separator = properties.get("SEPARATOR").toString()
def commaSpace = ", "
def commaNewline = ",\n"
def locIdsWithSpaces = properties.get('ID_WITH_SPACES')?.toString().replaceAll(commaSpace, commaNewline)
def locIdsWith0Geo = properties.get('ID_WITH_0_GEO')?.toString().replaceAll(commaSpace, commaNewline)
def locIdsWithOobGeo = properties.get('ID_WITH_OOB_GEO')?.toString().replaceAll(commaSpace, commaNewline)
def invalidIbpLocationsIds = "Please Check - IBP Location(s) with Invalid Data!"
def messageLogFormat = "text/plain"
def successLogMsg = "Success - No Failures in Location(s) Processing"
def successLogMsgBody = "All IBP locations are in Sync with Everstream!"
def sFailedLocs = listOfFailedItems.split(",")

def formattedIDs = sFailedLocs.collect { input ->
    formatIDs(input, prefix, mdtName, separator)
}
def formattedIDSize = formattedIDs.findAll { it != null && it.trim() }
def numberOfLocFailedProcessing = "Number of Locations Failed to be Processed: " + formattedIDSize.size()
def failedLocs = "\n\nFailed Locations: \n\n" + formattedIDs.join("\n").replaceAll("\"", "")
def sResult = numberOfLocFailedProcessing + failedLocs
def invalidIbpPayloads = formatInvalidIBPLocationMsg(locIdsWithSpaces, locIdsWith0Geo, locIdsWithOobGeo)

if(messageLog != null && formattedIDSize.size() == 0) {
    messageLog.addAttachmentAsString(successLogMsg, successLogMsgBody, messageLogFormat)
} 

if(messageLog != null && formattedIDSize.size() > 0) {
	messageLog.addAttachmentAsString("Location(s) Failed to be Processed", sResult.toString(), messageLogFormat)
}
 
if(messageLog != null && (locIdsWithSpaces.length()>0 || locIdsWith0Geo.length()>0 || locIdsWithOobGeo.length()>0)) {
messageLog.addAttachmentAsString(invalidIbpLocationsIds, invalidIbpPayloads.toString(), messageLogFormat)
}
     
	return message
}

def formatIDs(input, sPrefix, sMDTName, sSeparator) {
    
    def withoutPrefix = ""
    def withoutMDTName = ""
    def defaultSeparator = "-"
    
    if(!(sPrefix.isEmpty() || sSeparator.isEmpty())) {

     withoutPrefix = input.replaceAll(sPrefix + sSeparator, "")
     withoutMDTName = withoutPrefix.replaceAll(sMDTName + sSeparator, "")
    
    } else if (sPrefix.isEmpty() && !sSeparator.isEmpty()) {

        withoutMDTName = input.replaceAll(sMDTName + sSeparator, "")
        
    } else if (!sPrefix.isEmpty() && sSeparator.isEmpty()) {

        withoutPrefix = input.replaceAll(sPrefix + defaultSeparator, "")
        withoutMDTName = withoutPrefix.replaceAll(sMDTName + defaultSeparator, "")
        
    } else {

        withoutMDTName = input.replaceAll(sMDTName + defaultSeparator, "")

    }
    return withoutMDTName
    
}

def formatInvalidIBPLocationMsg(locIdsWithSpaces, locIdsWith0Geo, locIdsWithOobGeo) {
    
def idsWithSpaceMsg = "Please check, following IBP IDs have spaces in them:\n"
def idsWith0GeoMsg = "\n\nPlease check, following IBP IDs have invalid geo-coordinates:\n"
def idsWithOobMsg = "\n\nPlease check, following IBP IDs have geo-coordinates that are out of range:\n"
def sInvalidMsg =  idsWithSpaceMsg+locIdsWithSpaces+idsWith0GeoMsg+locIdsWith0Geo+idsWithOobMsg+locIdsWithOobGeo
return sInvalidMsg
}
