/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def properties = message.getProperties()
    ibpLocations = properties.get("IBP_LOCATIONS_LIST")
    everstreamLocations = properties.get("EVERSTREAM_LOCATIONS_LIST")
    def prefix = properties.get('PREFIX')
    def ibpMdt = properties.get('MDT')
    def separator = properties.get('SEPARATOR')
    def deleteAssetIDsProperty = "DELETED_ASSET_IDs"
    def formattedIdPrefix = ""
    def ibpLocationsParsed = new XmlParser().parseText(ibpLocations.trim())
    def everstreamLocationsParsed = new XmlParser().parse(new StringReader(everstreamLocations.trim()))
    def ibpLocs = ibpLocationsParsed.LOCATION
    def everstreamLocs = everstreamLocationsParsed.LOCATION
    def deletedLocations = []
    def sQuotes = "\""
    
    everstreamLocs.each { everstreamLocs1 ->

        if (!everstreamLocs1.ID.text().isEmpty()) {
            def id1 = everstreamLocs1.ID.text()
            def matched = false
        
            ibpLocs.each { ibpLocs1 ->
                def id2 = ibpLocs1.ID.text()
                if (id1 == id2) {
                    matched = true
                }
            }
        
            if (!matched) {
                deletedLocations << everstreamLocs1.ID.text()
            }
        }
    }

    formattedIdPrefix = formateAssetID(prefix, separator, ibpMdt)
    if(deletedLocations.size() == 1) {
     message.setProperty(deleteAssetIDsProperty, sQuotes + formattedIdPrefix + deletedLocations.toString() + sQuotes)
    } 
    
    if (deletedLocations.size() > 0) {
     def delLocFormatted = deletedLocations.collect {sQuotes + formattedIdPrefix + "$it" + sQuotes}.join(',')
     message.setProperty(deleteAssetIDsProperty, delLocFormatted.toString())
    } 
    
    if (deletedLocations.size() == 0) {
        message.setProperty(deleteAssetIDsProperty, "")
    }
    
    message.setProperty("NO_OF_DELETED_LOCs", deletedLocations.size().toString())
    message.setBody("")

binding.variables.clear() //Purging all variables used in the script

    return message
}


def formateAssetID(prefix, separator, mdt) {
    
    def assetIDFormat = ""
    def defaultSeparator = "-"
    
    if(!(prefix.isEmpty() || separator.isEmpty())) {
        
        assetIDFormat = prefix + separator + mdt + separator
        
    } else if (prefix.isEmpty() && !separator.isEmpty()) {
        
        assetIDFormat = mdt + separator
        
    } else if (!prefix.isEmpty() && separator.isEmpty()) {
        
        assetIDFormat = prefix + defaultSeparator + mdt + defaultSeparator
        
    } else {
        
        assetIDFormat = mdt + defaultSeparator
    }
    
    return assetIDFormat.toString()
    
}
