import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
	
def messageLog = messageLogFactory.getMessageLog(message)
def properties = message.getProperties()
def listOfModifiedItems = properties.get("ASSET_ID_LIST")
def prefix = properties.get("PREFIX")
def mdtName = properties.get("MDT")
def separator = properties.get("SEPARATOR")
def commaSpace = ", "
def commaNewline = ",\n"
def locIdsWithSpaces = properties.get('ID_WITH_SPACES')?.toString().replaceAll(commaSpace, commaNewline)
def locIdsWith0Geo = properties.get('ID_WITH_0_GEO')?.toString().replaceAll(commaSpace, commaNewline)
def locIdsWithOobGeo = properties.get('ID_WITH_OOB_GEO')?.toString().replaceAll(commaSpace, commaNewline)
def invalidIbpLocationsIds = "Please Check - IBP Location(s) with Invalid Data!"
def failedAssets = properties.get('FAILED_ASSETS').toString()
def sModifiedLocs = listOfModifiedItems.split(",")
def sPrefix = prefix.toString()
def sMDTName = mdtName.toString()
def sSeparator = separator.toString()
def messageLogFormat = "text/plain"
def successMsgLog = "Success - No IBP Location(s) Added/Changed"
def successMsgLogBody = "All IBP locations are in Sync with Everstream!"

def formattedIDs = sModifiedLocs.collect { input ->
    formatIDs(input, sPrefix, sMDTName, sSeparator)
}
def formattedIDSize = formattedIDs.findAll { it != null && it.trim() }
def numOfLocChangedAdded = "Number of Locations Added/Changed: " + formattedIDSize.size()
def changedAddedLocs = "\n\nAdded/Changed Locations: \n\n" + formattedIDs.join("\n").replaceAll("\"", "")
def sResult = numOfLocChangedAdded + changedAddedLocs

def invalidIbpPayloads = formatInvalidIBPLocationMsg(locIdsWithSpaces, locIdsWith0Geo, locIdsWithOobGeo)

if(messageLog != null && formattedIDSize.size() == 0) {
    	messageLog.addAttachmentAsString(successMsgLog, successMsgLogBody, messageLogFormat)
} 

if(messageLog != null && formattedIDSize.size() > 0) {
    messageLog.addAttachmentAsString("Success - Added/Changed Location(s)", sResult.toString(), messageLogFormat)
}

if (messageLog != null && failedAssets.length() == 0) {
    if(locIdsWithSpaces.length()>0 || locIdsWith0Geo.length()>0 || locIdsWithOobGeo.length()>0) {
        messageLog.addAttachmentAsString(invalidIbpLocationsIds, invalidIbpPayloads.toString(), msgLogFormat)
    }    
}
    
	return message
}


def formatIDs(input, sPrefix, sMDTName, sSeparator) {
    
    def withoutPrefix = ""
    def withoutMDTName = ""
    def defaultSeparator = "-"
    
    if(!(sPrefix.isEmpty() || sSeparator.isEmpty())) {

     withoutPrefix = input.replaceAll(sPrefix + sSeparator, "")
     withoutMDTName = withoutPrefix.replaceAll(sMDTName + sSeparator, "")
    
    } else if (sPrefix.isEmpty() && !sSeparator.isEmpty()) {

        withoutMDTName = input.replaceAll(sMDTName + sSeparator, "")
        
    } else if (!sPrefix.isEmpty() && sSeparator.isEmpty()) {

        withoutPrefix = input.replaceAll(sPrefix + defaultSeparator, "")
        withoutMDTName = withoutPrefix.replaceAll(sMDTName + defaultSeparator, "")
        
    } else {

        withoutMDTName = input.replaceAll(sMDTName + defaultSeparator, "")

    }
    return withoutMDTName
    
}

def formatInvalidIBPLocationMsg(locIdsWithSpaces, locIdsWith0Geo, locIdsWithOobGeo) {
    
def idsWithSpaceMsg = "Please check, following IBP IDs have spaces in them:\n"
def idsWith0GeoMsg = "\n\nPlease check, following IBP IDs have invalid geo-coordinates:\n"
def idsWithOobMsg = "\n\nPlease check, following IBP IDs have geo-coordinates that are out of range:\n"
def sInvalidMsg =  idsWithSpaceMsg+locIdsWithSpaces+idsWith0GeoMsg+locIdsWith0Geo+idsWithOobMsg+locIdsWithOobGeo
return sInvalidMsg
}