import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
def messageLog = messageLogFactory.getMessageLog(message)
def successMsg = "Success - No IBP Location(s) Added/Changed"
def successMsgBody = "All IBP locations are in Sync with Everstream!"

if(messageLog != null) {
    messageLog.addAttachmentAsString(successMsg, successMsgBody, "text/plain")
}
return message
}

