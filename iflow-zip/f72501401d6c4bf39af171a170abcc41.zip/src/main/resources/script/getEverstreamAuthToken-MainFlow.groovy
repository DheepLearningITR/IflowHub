import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*
import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
   
       String apiToken;
       def secureStoreService = ITApiFactory.getApi(SecureStoreService.class, null)
       def properties = message.getProperties()
       def credentialName = properties.get("API_TOKEN_SECURITY_MATERIAL")
       

       def securityItem = secureStoreService.getUserCredential(credentialName)
       
        if (securityItem) {
            apiToken= new String(securityItem.getPassword())
        } else {
            throw new IllegalStateException("No API Token found for Secutiy Item")            
        }
        
        message.setHeader("AUTHORIZATION" , apiToken)
        
        binding.variables.clear() //Purging all variables used in the script
      
      return message;
}