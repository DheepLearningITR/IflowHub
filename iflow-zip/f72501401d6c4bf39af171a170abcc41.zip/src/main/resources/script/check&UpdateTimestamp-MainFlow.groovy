import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    def properties = message.getProperties()
    def timestampID = properties.get('timestampID')
    def lastRunObject = properties.get('lastSuccessfullRunObject')
    def timestampKey = timestampID.toString() + '_lastSuccessfulRun'

     if(lastRunObject) {
         
        def hashMap = generateHashMapFromPairs(lastRunObject)
        
        if(hashMap.get(timestampKey)) {
            hashMap.put(timestampKey, "")
            message.setProperty('timestampObject', hashMap)
        }
     }
     
    return message;
}

def generateHashMapFromPairs(lastRunObject) {
    def hashMap = [:]

    def lastRunObjectValue = lastRunObject.toString().replaceAll(/[{}\[\]]+/, "")
        def keyValuePairs = lastRunObjectValue.split(',')
        
        keyValuePairs.each { pair ->
            if (!pair.isEmpty()) { 
                def keyValue = pair.split('=')
                def key = keyValue[0].trim()
                def value = keyValue.size() > 1 ? keyValue[1].trim() : ''
                hashMap[key] = value
            }
        }
        
        return hashMap
}