import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
def Message processData(Message message) {
def httpResponseCode = message.getHeaders().get('CamelHttpResponseCode').toString()
def httpSuccessResponseCodes = [200, 201, 202, 204]
if(!httpSuccessResponseCodes.contains(httpResponseCode)) {
	def body = message.getBody(java.io.Reader)
	def jsonBody = new JsonSlurper().parse(body)
	message.setProperty("EVERSTREAM_RESPONSE_MSG", jsonBody.toString())
}
binding.variables.clear() //Purging all variables used in the script
return message
}