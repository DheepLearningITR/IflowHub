import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def properties = message.getProperties()
    def rejectedLocations = properties.get("REJECTED_LOCATIONS_INFO")
    def rejectedLocationsParsed = new XmlParser().parse(new StringReader(rejectedLocations.trim()))
    def assetId = ""
    def httpResponseCode = ""
    def errorPayload = ""
    def everstreamResponseMsg = ""
    def result = ""
    
    rejectedLocationsParsed.each { locations ->
        assetId = locations.ASSET_ID.text()
        httpResponseCode = locations.HTTP_RESPONSECODE.text()
        errorPayload = locations.PAYLOAD.text()
        everstreamResponseMsg = locations.EVERSTREAM_RESPONSE_MSG.text()
    
        result +="""
        Asset ID: $assetId
        HTTP Response Code: $httpResponseCode
        Payload: $errorPayload
        Everstream Response Message: $everstreamResponseMsg
        """
    }
    
    result = result.replaceAll('[\t ]+',' ')

    message.setProperty('ERROR_DETAILED_INFO', result.toString())
    binding.variables.clear() //Purging all variables used in the script
    return message
}
