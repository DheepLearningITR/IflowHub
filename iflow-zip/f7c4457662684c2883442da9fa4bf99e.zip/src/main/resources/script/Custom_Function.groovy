import com.sap.it.api.mapping.*;
import java.util.UUID; 
import java.util.Arrays;
import java.util.Set;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;

// Script to get number range group code of business partner
def String getInternalId(String arg1, MappingContext context){
    
    def getInternalId = context.getProperty("businessPartnerInternalId");
    
    return getInternalId;
	
}

// Script to get number range group code of business partner
def String getBPUUID(String arg1, MappingContext context){
    
    def getBPUUID = context.getProperty("businessPartnerInternalUUID");
    
    return getBPUUID;
	
}


// Script to get number range group code of business partner
def String getCustomerId(String arg1, MappingContext context){
    
    def getCustomerId = context.getProperty("customerId");
    
    return getCustomerId;
	
}


// Script to get number range group code of business partner
def String getEmail(String arg1, MappingContext context){
    
    def getEmail = context.getProperty("customerEmail");
    
    return getEmail;
	
}

// Script to get number range group code of business partner
def String getfirstName(String arg1, MappingContext context){
    
    def getfirstName = context.getProperty("fname");
    
    return getfirstName;
	
}

// Script to get number range group code of business partner
def String getlastName(String arg1, MappingContext context){
    
    def getlastName = context.getProperty("lname");
    
    return getlastName;
	
}

//Script to get Partner Function Id
def String getPartnerFunctionId(String arg1, MappingContext context){
    def partnerFunctionId = context.getProperty("partnerFunctionId");
    
    return partnerFunctionId;
}


//Script to get Sender System Id
def String getSenderSystemId(String arg1, MappingContext context){
    def senderSystemId = context.getProperty("SenderSystemId");
    
    return senderSystemId;
}

//Script to get Receiver System Id
def String getReceiverSystemId(String arg1, MappingContext context){
    def receiverSystemId = context.getProperty("ReceiverSystemId");
    
    return receiverSystemId;
}





