import com.sap.it.api.mapping.*;


def String randomUUID(String arg1){
    
    def id = UUID.randomUUID().toString();
	return id; 
}