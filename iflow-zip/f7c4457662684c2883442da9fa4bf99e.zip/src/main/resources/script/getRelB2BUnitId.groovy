import com.sap.it.api.mapping.*;
import java.util.UUID; 
import java.util.Arrays;
import java.util.Set;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;

// Script to get B2BUnit ID
def String getRelB2BUnitId(String arg1, MappingContext context){
    
    def B2BUnitId = context.getProperty("DefaultB2BUnit");
    
    return B2BUnitId;
    
}