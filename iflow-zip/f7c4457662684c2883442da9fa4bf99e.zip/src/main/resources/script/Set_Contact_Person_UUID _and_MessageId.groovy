import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.UUID; 
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.*;


//Set contact person message headers' UUID, MessageId(SOAP Header) and referenceId
def Message processData(Message message) {
    
    def messageId = UUID.randomUUID().toString();
    def referenceId = messageId.replaceAll("-", "");
    message.setProperty("ContactPerson_MessageId", messageId);
//    message.setProperty("ContactPerson_UUID", messageId);
    message.setProperty("ContactPerson_ReferenceId", referenceId);
    
    return message;
}