import com.sap.it.api.mapping.*;
import java.util.UUID; 
import java.util.Arrays;
import java.util.Set;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;

// Script to get senderBusinessSystemID
def String getB2BUnitSenderSysId(String arg1, MappingContext context){
    
    def unitSenderSysId = context.getProperty("recipientBusinessSystemID");
    
    return unitSenderSysId;
    
}