import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.UUID; 
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.*;


//Set BP relationship message headers' UUID, MessageId(SOAP Header) and referenceId
def Message processData(Message message) {
    
    def messageId = UUID.randomUUID().toString();
    def referenceId = messageId.replaceAll("-", "");
    message.setProperty("REL_MessageId", messageId);
//    message.setProperty("REL_UUID", messageId);
    message.setProperty("REL_ReferenceId", referenceId);
    
    return message;
}