import com.sap.it.api.mapping.*;
import java.util.UUID; 
import java.util.Arrays;
import java.util.Set;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;

// Script to get contact person referenceId
def String getPersonReferenceId(String arg1, MappingContext context){
    
    def personReferenceId = context.getProperty("ContactPerson_ReferenceId");
    
    return personReferenceId;
    
}