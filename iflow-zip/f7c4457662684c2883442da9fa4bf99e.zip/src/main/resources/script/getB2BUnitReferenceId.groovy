import com.sap.it.api.mapping.*;
import java.util.UUID; 
import java.util.Arrays;
import java.util.Set;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;

// Script to get B2BUnit referenceId
def String getB2BUnitReferenceId(String arg1, MappingContext context){
    
    def unitReferenceId = context.getProperty("B2BUnit_ReferenceId");
    
    return unitReferenceId;
    
}