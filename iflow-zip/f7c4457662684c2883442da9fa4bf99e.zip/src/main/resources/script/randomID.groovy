import com.sap.it.api.mapping.*;


def String randomID(String arg1){
    
    def id = UUID.randomUUID().toString();
id = id.replaceAll("-","");
id = id.toUpperCase();

	return id; 
}