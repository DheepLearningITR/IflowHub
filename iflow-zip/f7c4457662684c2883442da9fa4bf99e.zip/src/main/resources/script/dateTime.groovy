import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;

def String dateTime(String arg1){
    
def date = new Date()
def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX")
return sdf.format(date);

}
