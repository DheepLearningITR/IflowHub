import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.json.JsonOutput;


def Message parseHeaders(Message message) {

	def map = message.getHeaders();

    def sfsfUpdateTagTexts = map.get("sfsfUpdateTagTexts");
	message.setProperty("sfsfUpdateTagTexts", sfsfUpdateTagTexts);

    def sfsfTagFound = map.get("sfsfTagFound");
	message.setProperty("sfsfTagFound", sfsfTagFound);
	
    def testRun = map.get("testRun");
	message.setProperty("testRun", testRun);	
	
    def sfsfDeactivateTags = map.get("sfsfDeactivateTags");
	message.setProperty("sfsfDeactivateTags", sfsfDeactivateTags);
	
	//used to clear hashmap global variables
	def emptyHmap = new HashMap<String, String>();
	emptyHmap.put('null','');
	message.setProperty("emptyHmap", emptyHmap);
	
	return message;
}


def Message gather_filenames(Message message) {
	def body = message.getBody(java.lang.String);
	def root = new XmlSlurper().parseText(body);
    
    List<String> files = [
        "filenameINSTags",
        "filenameINSTagTexts",
        "filenameUPDTags",
        "filenameUPDTagTexts"
    ];

    files.each { file ->
        Set<String> filenames = new HashSet<>();
        def elements = root."$file";
        elements.each(){
            def fname = it.text().trim();
            if(fname && fname != '[]'){
                filenames.add(fname)
            }
        }
        if(!filenames.isEmpty()){
            message.setHeader(file, JsonOutput.toJson(filenames));
        }
    }    
    
    return message;
}

def Message process_updates(Message message) {
	
	def body = message.getBody(java.lang.String);
	def map = message.getProperties();
	HashMap<String, String> hmapCompetencies = map.get("hmap_cbrCompetencies"); 
	def sfsfDeactivateTags = map.get("sfsfDeactivateTags");
	def sfsfSkillTypeTags = map.get("sfsfSkillTypeTags") ?: '';
    
	//change status 
	def updatesFound = false;
	def sumReactivate = 0;
	def sumArchive = 0;
	def Root = new XmlParser().parseText(body);
	
    Root.data.each{r->
        //remove prefix from sfsfTagId:
        if(!r.externalId[0].text().startsWith('cbr_') || sfsfSkillTypeTags.contains(r.externalId[0].text()) ){
            //exclude Tags without cbr_ prefix, and Tags which are SkillTypes (cbr_soft/cbr_hard)
            r.replaceNode{}; //remove node, Not a Competency but likely the Common Tag, do not deactivate
        }else{
            def sfsfTagId = r.externalId[0].text().replaceFirst(/^cbr_/, '');
            //if(hmapCompetencies.containsKey(r.externalId[0].text())){
            if(hmapCompetencies.containsKey(sfsfTagId)){
                //Tag FOUND in Talent, check status
                if(r.status[0].text() == 'I'){
                    //Inactive Tag FOUND in Talent, UPDATE
                    r.status[0].value = "A";
                    r.description[0].value = format_desc(r.description[0].text());
                    sumReactivate = sumReactivate + 1; //counter
                    updatesFound = true;
                }else{
                    r.replaceNode{}; //remove node, Tag still active
                }
            }else{
                if(sfsfDeactivateTags=='false'){
                    //do NOT deactivate Tags!
                    r.replaceNode{};
                }else{
                    //Tag NOT FOUND in Talent, check status
                    if(r.status[0].text() == 'A'){
                        //ACTIVE Tag NOT FOUND in Talent, check status ARCHIVE
                        r.status[0].value = "I"
                        r.description[0].value = format_desc(r.description[0].text());
                        sumArchive = sumArchive + 1; //counter
                        updatesFound = true;
                    }else{
                        r.replaceNode{}; //remove node, Tag already inactive
                    }
                }
            }
        }
    }
    message.setProperty("hmap_cbrCompetencies","");           //clear processed data
    message.setProperty("sfsfTags_payload","");   //clear processed data
    
    message.setBody(XmlUtil.serialize(Root));
    message.setHeader("sumArchiveTags",sumArchive.toString());
    message.setHeader("sumReactivateTags",sumReactivate.toString());
    message.setProperty("updatesFound", updatesFound.toString());
    
	return message;
}

def String format_desc(description){
    String descr = description;
    descr = descr.replaceAll(/\/n/, "\n");  //replace with actual new line
    descr = descr.replaceAll ('"','\\\\\\"'); //escape double quotes
    descr = descr.take(4000);  //4000 char limit    
    return descr;
}



