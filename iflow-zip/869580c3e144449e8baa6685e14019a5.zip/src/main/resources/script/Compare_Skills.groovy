import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
       ArrayList fsm_skill_ids = []
       ArrayList c4c_skill_ids = message.getProperty("c4c_skill_ids")
       def fsm_skill_res = new JsonSlurper().parseText(message.getBody(String.class));
       
       for(n in fsm_skill_res.data){
           fsm_skill_ids.add(n.req.externalId.toString())
       }
      
       //Find out FSM addresses which are not present in C4C and then prepare for delete
       def root_output = new NodeBuilder().Delete_Bulk{}
       ArrayList diff = fsm_skill_ids.minus(c4c_skill_ids)
       for(String n : diff){
           root_output.append(new NodeBuilder().data{externalId(n)})
       }
       
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(root_output)
        message.setBody(stringWriter.toString())
       return message;
}