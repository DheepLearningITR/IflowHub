
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

       def root = new XmlParser().parseText(message.getBody(String.class));
        //Loop over all the Business Partners
        root.BusinessPartnerSUITEReplicateRequestMessage.each{
        	it.BusinessPartner.AddressInformation.each{
        //Keep the 
        		it.AddressUsage.each{
        			if(it.AddressUsageCode.text().equals("XXDEFAULT")){
        				it.AddressUsageCode[0].value = "UNKNOWN"
        				it.DefaultIndicator[0].value = true				
        			}
        			else if(it.AddressUsageCode.text().equals("SHIP_TO")){
        				it.AddressUsageCode[0].value = 'SHIPTO'
        			}
        			else if(it.AddressUsageCode.text().equals("BILL_TO")){
        				it.AddressUsageCode[0].value = 'BILLTO'
        			}
        			else{
        				it.parent().remove(it)
        			}
        		}
        		
        		it.Address.PostalAddress.each{
        			if(!it.AddressRepresentationCode.text().equals("0")){
        				it.parent().remove(it)
        			}
        		}
        	}
        }
       
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(root)
        message.setBody(stringWriter.toString())
        return message;
}