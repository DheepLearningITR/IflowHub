import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
       def body = message.getBody(String.class);
       def parsedObj = new XmlSlurper().parseText(body).declareNamespace(m: 'http://schemas.microsoft.com/ado/2007/08/dataservices/metadata', d: 'http://schemas.microsoft.com/ado/2007/08/dataservices');

	   def bpDetailsJson = new JsonSlurper().parseText(message.getProperty("bpdetails"));
	   String contactID; 
	   String accountID; 
	   
	   def root_output = new NodeBuilder().Contacts{}
	   
        parsedObj.entry.each{
            contactID = it.content.properties.SecondBusinessPartnerID;
            accountID = it.content.properties.FirstBusinessPartnerID
              
            contactDataNode = new NodeBuilder().data(){
                externalId(contactID+"~ID-JOIN~"+accountID)  //~ID-JOIN~ is the delimiter used.
                firstName(bpDetailsJson[contactID]["firstname"])
                lastName(bpDetailsJson[contactID]["lastname"])
                gender(bpDetailsJson[contactID]["gender"])
                title(bpDetailsJson[contactID]["title"])
                birthDate(bpDetailsJson[contactID]["birthDate"])
            }
            
            root_output.append(contactDataNode)
        };
         
        if(root_output.'*'.size() > 0)
		{
            StringWriter stringWriter = new StringWriter()
            XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
            nodePrinter.setPreserveWhitespace(true)
            nodePrinter.print(root_output)
            message.setBody(stringWriter.toString())
            message.setProperty("No_Relationships_Found",false);
		}
		else
		{
		   message.setProperty("No_Relationships_Found",true);
		}  
		
        message.setHeader("Content-Type","application/json");
        
        //Setting this delay based on configuration to delay the BP msg of contact to avoid its' concurrent
        //replication with BP relationship msg
        long delay = Long.parseLong(message.getProperty("p_contact_repl_delay"));
        if(delay>0){
            sleep(delay);
        }
        
       return message;
}
