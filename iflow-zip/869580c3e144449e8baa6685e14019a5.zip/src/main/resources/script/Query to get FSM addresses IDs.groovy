import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    //Get Body and parse it.
       def body = message.getBody(String.class)
       def parsedObj = new XmlSlurper().parseText(body);
       String query = "{\"query\": \"SELECT addr.externalId FROM Address addr JOIN BusinessPartner bp ON addr.object.objectId = bp.id WHERE addr.externalId IS NOT NULL AND bp.externalId IN (";
       String s = '\'';
       String e = '\',';
       String eend = '\')\"}';
       String whereIn;
       ArrayList c4c_addr_ids = []
    // Form the where clause of BP IDs for which address IDs needs to be fetched from FSM
      parsedObj.BusinessPartnerSUITEReplicateRequestMessage.each{
          it.BusinessPartner.AddressInformation.each{
          	    c4c_addr_ids.add(it.UUID.text().trim())
          }
          if (whereIn == null)
          {
              whereIn = s + it.children().InternalID + eend;
          }
          else
          {
              whereIn = s + it.children().InternalID + e + whereIn;
          }
          };
    //Set final query statement which has to be send as payload of the query API request     
       query = query + whereIn;
    // Temporarily store inbound payload as property
       message.setProperty("c4c_addr_ids",c4c_addr_ids);
       message.setProperty("InPayload",body);
    // Set the query in the message body   
       message.setBody(query);
       return message;
}
