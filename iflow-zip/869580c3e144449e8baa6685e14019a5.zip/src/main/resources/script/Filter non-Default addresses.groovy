/*
Remove the AddressInformation nodes where AddressUsageCode = XXDEFAULT
 */
import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(String.class);
       def root = new XmlParser().parseText(body);
        boolean delete
        //Loop over all the Values
        root.BusinessPartnerSUITEReplicateRequestMessage.each{
        	it.BusinessPartner.AddressInformation.each{
        		delete = true
        		it.AddressUsage.each{
        			if(it.AddressUsageCode.text().equals("XXDEFAULT")){
        				delete = false
        			}
        		}
        		if(delete == true){
        			it.parent().remove(it)
        		}
        	}
        }
       
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(root)
        message.setBody(stringWriter.toString())
        return message;
}