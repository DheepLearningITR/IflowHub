import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {

       def parsedObj = new XmlSlurper().parseText(message.getBody(String.class));
	   def filter="";
	   def bpdetails = "";
	   def fname, lname, genderCode, formOfAddressCode, mappedValue
	   
	   def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
	   
      parsedObj.BusinessPartnerSUITEReplicateRequestMessage.each{
          //Replace { '\' to '\\' } and { '"' to '\"' } to ensure correct replication
          fname = it.children().Common.Person.Name.GivenName.text().replaceAll('\\\\','\\\\\\\\').replaceAll('"', '\\\\"')
          lname = it.children().Common.Person.Name.FamilyName.text().replaceAll('\\\\','\\\\\\\\').replaceAll('"', '\\\\"')
          
          switch(it.children().Common.Person.GenderCode.text()){
              case "1":
                  genderCode = "MALE"
                  break
              case "2":  
                  genderCode = "FEMALE"
                  break
              default:
                  genderCode = "UNKNOWN"
          }
          
          formOfAddressCode = it.children().Common.Person.Name.FormOfAddressCode.text()
          mappedValue = valueMapApi.getMappedValue('C4C', 'FormOfAddressCode', formOfAddressCode, 'FSM', 'FormOfAddressCode')
          formOfAddressCode = mappedValue == null ? formOfAddressCode : mappedValue
          
          if (filter == "")
          {
              filter =  "SecondBusinessPartnerID eq"+ " '" + it.children().InternalID + "'";
              bpdetails =  '"'+ it.children().InternalID +'" : { '+'"gender":'+'"'+ genderCode +'","firstname":"'+ fname +'","lastname":"'+ lname +'","title":"'+ formOfAddressCode +'","birthDate":"'+it.children().Common.Person.BirthDate+'"}';
          }
          else
          {
              filter =   filter+" or" + " SecondBusinessPartnerID eq"+ " '" + it.children().InternalID + "'";
              bpdetails = bpdetails+',"'+ it.children().InternalID +'" : { '+'"gender":'+'"'+ genderCode +'","firstname":"'+ fname +'","lastname":"'+ lname +'","title":"'+ formOfAddressCode +'","birthDate":"'+it.children().Common.Person.BirthDate+'"}';
          }

       };  
          
       bpdetails = "{"+bpdetails+"}"
          
       message.setProperty("bpdetails",bpdetails);
       message.setProperty("filter",filter);

       return message;
}
