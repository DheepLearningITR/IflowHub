
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;
import com.sap.it.api.mapping.Output;
import com.sap.it.api.mapping.MappingContext;


def void AddContext(String[] input, Output output, MappingContext context) { 
    for(item in input[0].split(',')){
     output.addValue(item);
    }
}