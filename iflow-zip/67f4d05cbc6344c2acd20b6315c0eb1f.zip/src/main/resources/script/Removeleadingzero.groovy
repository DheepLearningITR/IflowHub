import com.sap.it.api.mapping.*;
 
def String removeLeadingZeros(String arg1) {
      return arg1.replaceAll("^0+", "")
}

