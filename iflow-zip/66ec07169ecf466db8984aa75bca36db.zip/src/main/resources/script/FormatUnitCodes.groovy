/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput
def Message processData(Message message) {
    def body = message.getBody(String) as String;
    //Temparory replacing @unitCode as "@" is not acceptable.
    body = body.replaceAll("@unitCode","unitCode");
    
    //Converting Body into jsonSlurper for easy navigation to a particular node.
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    
    //Navigating to QuantityCharacteristic node
    def sample = [];
    def result = object.ProductMDMBulkReplicateRequestMessage.ProductMDMReplicateRequestMessage;
    if(result.getClass() != sample.getClass()){
    def result1 = object.ProductMDMBulkReplicateRequestMessage.ProductMDMReplicateRequestMessage.Product.QuantityCharacteristic;
    def characteristicQuantity = [];
     //Navigating to each record in the array.
     result1.each{ item ->
        // if(item.CharacteristicQuantityTypeCode == "VOLUME" || item.CharacteristicQuantityTypeCode == "NET_WEIGHT" || item.CharacteristicQuantityTypeCode == "GROSS_WT") {
            if (item.CharacteristicQuantity.unitCode) {      
    			//Pushing Records having unit code not Null into an array.        
    			characteristicQuantity.push(item); 
		    }
        // }
    
	}
	object.ProductMDMBulkReplicateRequestMessage.ProductMDMReplicateRequestMessage.Product.QuantityCharacteristic = characteristicQuantity;
    
    }
    else{
    result.each{ product ->
        def variable = product.Product.QuantityCharacteristic;
        def characteristicQuantity = [];
        
        variable.each{ item ->
            if (item.CharacteristicQuantity.unitCode) {      
    			//Pushing Records having unit code not Null into an array.        
    			characteristicQuantity.push(item); 
		    }
        }
        product.Product.QuantityCharacteristic = characteristicQuantity;
    }
    }
    
     
	results = JsonOutput.toJson(object);
    //Replacing back to @unitCode.
    results = results.replaceAll("unitCode","@unitCode")
    message.setBody(results);
    return message;
}