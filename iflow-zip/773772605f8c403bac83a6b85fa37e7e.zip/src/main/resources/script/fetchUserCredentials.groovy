/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 */
import com.sap.gateway.ip.core.customdev.util.Message;

import java.util.HashMap;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.Key
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;

import groovy.json.JsonBuilder

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;
import com.sap.it.api.keystore.exception.KeystoreException;
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential

def Message processData(Message message) {

	//Get the client secret and do a Base64 decoding
	def map = message.getProperties();
	String gstin = map.get("gstin");
	//Get the vayana gstin credentials from the keystore
	def service = ITApiFactory.getApi(SecureStoreService.class, null);

	if(service != null)
	{
		UserCredential userCredential = service.getUserCredential(gstin);
		if(userCredential != null) {
		    message.setProperty("username",userCredential.getUsername());
			message.setProperty("password",new String((char[])userCredential.getPassword()));
		}
		else {
		    message.setProperty("CamelExceptionCaught", "com.sap.it.nm.types.NodeManagerException");
		}
	}
	return message;
}

