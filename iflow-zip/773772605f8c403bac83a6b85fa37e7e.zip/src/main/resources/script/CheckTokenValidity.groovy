import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {	
	
	def body = message.getBody(String.class);
	def dateExpiryTokenSek = body.split('\\$');
	
//Calculate the expiry date and time
	def expiry = new Date().parse('EEE MMM dd HH:mm:ss z yyyy', dateExpiryTokenSek[0]);
    expiry.setTime(expiry.getTime() + (Integer.parseInt(dateExpiryTokenSek[1]) * 60 * 1000));  	
	def currentdate = new Date();
//set indicator to start new flow to fetch new token	
	if(currentdate > expiry){
		message.setHeader("refresh", "X");
	}
	else {
		message.setProperty("authtoken", dateExpiryTokenSek[2]);
		message.setProperty("sek", dateExpiryTokenSek[3]);
	}
	return message;
}

