import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

	// get the headers
	def headers = message.getHeaders();
	// get the request body
	def body = message.getBody(String.class);
	def jsonSlurper = new JsonSlurper();
	def object = jsonSlurper.parseText(body);
	def newBody;
	
	// set default properties from headers
	message.setProperty("action", headers.get("action"));
	message.setProperty("txn", headers.get("txn"));
	message.setProperty("gstin", headers.get("gstin"));
	message.setProperty("date", headers.get("date"));
	
	// Read the Payload from ECC based on ACTION(e.g. ACCESSTOKEN, GENEWAYBILL, VEHEWB, GENCEWB, CANEWB, REJEWB, GetEwayBill,
	// GetEwayBillsofOtherParty, GetEwayBillsForTransporter, GetEwayBillsForTransporterByGstin, GetTripSheet etc.)
	switch (headers.get("action")) {
		case "GENEWAYBILL":
			message.setProperty("api_action", "EWAYBILL");
			newBody = object.submitDocumentRequest.docData;
			break;
		case "VEHEWB":
			message.setProperty("api_action", "EWAYBILL");
			newBody = object.updateDocRequest.updateRequest;
			break;		
		case "CANEWB":
			message.setProperty("api_action", "EWAYBILL");
			newBody = object.cancelDocRequest.cancelRequest;
			break;
		case "UPDATETRANSPORTER":
			message.setProperty("api_action", "EWAYBILL");
			newBody = object.updateTransDocRequest.updateTransRequest;
			break;
		case "EXTENDVALIDITY":
			message.setProperty("api_action", "EWAYBILL");
			newBody = object.extendDocRequest.extendRequest;
			break;
		case "GetEwayBill":
		    message.setProperty("ewbNo", headers.get("ewbNo"));
			message.setProperty("api_action", "DETAILS");
			break;
				
		case "REJEWB":
			message.setProperty("api_action", "EWAYBILL");
			newBody = object.rejectDocRequest.rejectRequest;
			break;
		
		case "GetEwayBillsofOtherParty":
		    message.setProperty("ewbNo", headers.get("ewbNo"));
			message.setProperty("api_action", "DETAILS");
			//newBody = object.submitDocumentRequest; //TODO
			break;	
	   case "GetErrorList":
		    message.setProperty("ewbNo", headers.get("ewbNo"));
			message.setProperty("api_action", "DETAILS");
			break;
	  case "MULTIVEHMOVINT":
	 		message.setProperty("api_action", "EWAYBILL");
			newBody = object.multiVehicleMvntDocRequest.multiVehMvntRequest;
			break;
	  case "MULTIVEHADD":
	 		message.setProperty("api_action", "EWAYBILL");
			newBody = object.multiVehAddDocRequest.multiVehAddRequest;
			break;
	  case "MULTIVEHUPD":
	 		message.setProperty("api_action", "EWAYBILL");
			newBody = object.multiVehUpdDocRequest.multiVehUpdRequest;
			break;
		default:
			newBody = headers.get("action");
			break;
	}
	message.setBody(JsonOutput.toJson(newBody));
	return message;
}

