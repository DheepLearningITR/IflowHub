import javax.crypto.Cipher

/**
 * This script is used to build the JSON request details 
 * 
 * Date		  |	Information
 * ------------------------------------------------------------------------ 
 * 12-03-2018 | Initial Version
 */

import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

import java.lang.invoke.SwitchPoint;
import java.security.KeyFactory
import java.security.NoSuchAlgorithmException
import java.security.PublicKey
import java.security.cert.X509Certificate
import java.security.spec.X509EncodedKeySpec
import java.security.NoSuchAlgorithmException

import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.SecretKeySpec
import javax.crypto.ShortBufferException
import javax.crypto.NoSuchPaddingException

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;
import com.sap.it.api.keystore.exception.KeystoreException;

import javax.crypto.Mac;

def Message processData(Message message) {

	// get the properties
	def props = message.getProperties();
	// get the headers
	def headers = message.getHeaders();

	StringBuilder sbUrl = new StringBuilder();
	StringBuilder sbQuery = new StringBuilder();
	def jsonString = new JsonBuilder();

	// Form the Payload for NIC Request based on the API_ACTION(e.g. AUTH, EWAYBILL, DETAILS etc.) 
	// and ACTION(e.g. ACCESSTOKEN, GENEWAYBILL, VEHEWB, GENCEWB, CANEWB, REJEWB, GetEwayBill, 
	// GetEwayBillsofOtherParty, GetEwayBillsForTransporter, GetEwayBillsForTransporterByGstin, GetTripSheet etc.)
	switch (props.get("api_action")) {
		case "AUTH":
		//set the required headers for the Authentication request
			message.setHeader("Content-Type","application/json");
			message.setHeader("gstin",props.get("gstin"));
			message.setHeader("GspHttpUrl",props.get("nic_auth"));

		//set the Payload for the authentication requests
		//for ACCESSTOKEN
			if (props.get("action").equals("ACCESSTOKEN")) {
				//1. Generate a new Application Key(APPKEY)
				byte[] rawAppkey =  generateAppKey();

				//set the appkey in the header so that it can be send back in the response to the ECC application
				//the same appkey must be send in the subsequent request for AUTHTOKEN
				message.setHeader("appkey", rawAppkey.encodeBase64().toString());

				//2.Form the JSON Payload
				jsonString	action	: props.get("action"),
				username: props.get("username"),
				password: encryptRawData(props.get("password").getBytes(), props.get("nicpkalias")),
				app_key	: encryptRawData(rawAppkey, props.get("nicpkalias")) // Encrypt the application key using the NIC public key
				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			}
			break;
		case "EWAYBILL":
			//Set the required headers for the NIC post request
			message.setHeader("gstin", props.get("gstin"));
			message.setHeader("authtoken", props.get("authtoken"));
			message.setHeader("Content-Type","application/json");
			message.setHeader("GspHttpUrl", props.get("nic_ewaybill"));
			def body = message.getBody(String.class);
			
			// for GENEWAYBILL
			if (props.get("action").equals("GENEWAYBILL")) {
				String in_data = body;
				String tokensek = props.get("sek");

				jsonString	action: props.get("action"),
				data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			}
			// for VEHEWB
			else if (props.get("action").equals("VEHEWB")) {
				String in_data = body;
				String tokensek = props.get("sek");

				jsonString	action: props.get("action"),
				data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			}
			// for CANEWB
			else if (props.get("action").equals("CANEWB")) {
				String in_data = body;
				String tokensek = props.get("sek");

				jsonString	action: props.get("action"),
				data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			}
			// for UPDATETRANSPORTER
			else if (props.get("action").equals("UPDATETRANSPORTER")) {
				String in_data = body;
				String tokensek = props.get("sek");

				jsonString	action: props.get("action"),
				data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			}
			// for EXTENDVALIDITY
			else if (props.get("action").equals("EXTENDVALIDITY")) {
				String in_data = body;
				String tokensek = props.get("sek");

				jsonString	action: props.get("action"),
				data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			}
			
			// for REJEWB
			else if (props.get("action").equals("REJEWB")) {
				String in_data = body;
				String tokensek = props.get("sek");

				jsonString	action: props.get("action"),
				data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			}
			// for MULTIVEHMOVINT
			else if (props.get("action").equals("MULTIVEHMOVINT")) {
				String in_data = body;
				String tokensek = props.get("sek");

				jsonString	action: props.get("action"),
				data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			}
			// for MULTIVEHADD
			else if (props.get("action").equals("MULTIVEHADD")) {
				String in_data = body;
				String tokensek = props.get("sek");

				jsonString	action: props.get("action"),
				data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			}
			//for MULTIVEHUPD
			else if (props.get("action").equals("MULTIVEHUPD")) {
				String in_data = body;
				String tokensek = props.get("sek");

				jsonString	action: props.get("action"),
				data: symmEncryption(tokensek, in_data.trim())

				//set the message body
				def req_payload = jsonString.toString();
				message.setBody(req_payload);
			}
			break;

		case "DETAILS":
		//Set the required headers for the NIC post request
			message.setHeader("gstin", props.get("gstin"));
			message.setHeader("authtoken", props.get("authtoken"));
			message.setHeader("Content-Type","application/json");
			//message.setHeader("GspHttpUrl", sbUrl.append(props.get("nic_ewaybill")).append("/").append(props.get("action").trim()));

			// for GetEwayBill
			if (props.get("action").equals("GetEwayBill")) {
		    	message.setHeader("GspHttpUrl", sbUrl.append(props.get("nic_ewaybill")).append("/").append(props.get("action").trim()));
		    	message.setHeader("GspHttpQuery", sbQuery.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("ewbNo=").append(props.get("ewbNo")));
			    message.setHeader("CamelHttpMethod", "GET");
		
			}
			
			// for GetEwayBillsofOtherParty
			else if (props.get("action").equals("GetEwayBillsofOtherParty")) {
				message.setHeader("GspHttpUrl", sbUrl.append(props.get("nic_ewaybill")).append("/").append(props.get("action").trim()));
			    message.setHeader("GspHttpQuery", sbQuery.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")).append("date=").append(props.get("date")));
			    message.setHeader("CamelHttpMethod", "GET");
			}
			
			// for GetErrorList
			else if (props.get("action").equals("GetErrorList")) {
			   message.setHeader("GspHttpUrl", sbUrl.append(props.get("nic_getewaybill")).append("/").append(props.get("action").trim()));
			   message.setHeader("GspHttpQuery", sbQuery.append(headers.get("CamelHttpQuery")==null?"":headers.get("CamelHttpQuery")));
			   message.setHeader("CamelHttpMethod", "GET");
			}
			break;
		default:
			break;
	}

	// set the current timestamp as the REQUEST timestamp
	def currentDate = new Date();
	message.setHeader("GSP_LAST_TIMESTAMP", currentDate);
	message.setHeader("GSP_REQ_TIMESTAMP", currentDate);
	return message;
}


def String generateHmac(byte[] key, String data){
	try{
		Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
		SecretKeySpec secret_key = new SecretKeySpec(key, "AES");
		sha256_HMAC.init(secret_key);

		String hash = sha256_HMAC.doFinal(data.getBytes()).encodeBase64().toString();
		return hash;
	}catch(Exception e){
		return "";
	}
}

def String encryptRawData(byte[] rawAppKey, String nicpkalias){
	/* ASYMMETRIC ENCRYPTION */
	// get the NIC public key from the JAVA keystore
	def service = ITApiFactory.getApi(KeystoreService.class, null);
	PublicKey pk;
	byte[] keydata;

	if(service != null)
	{
		// here it reads the certificate with alias niccert.
		// the NIC public key must be deployed in the cloud integration tenants keystore with alias name as niccert
		X509Certificate certificate = service.getCertificate(nicpkalias);
		if(certificate != null)
		{
			pk = certificate.getPublicKey();
			String encoded  = pk.getEncoded().encodeBase64().toString();
			keydata = encoded.decodeBase64();
		}
	}

	// encrypt the raw appkey using the NIC public key from keystore
	Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	PublicKey pubKey = KeyFactory.getInstance("RSA")
			.generatePublic(new X509EncodedKeySpec(keydata));
	cipher.init(Cipher.ENCRYPT_MODE, pubKey);
	byte[] encryptedByte= cipher.doFinal(rawAppKey);
	return encryptedByte.encodeBase64().toString();
}

def byte[] generateAppKey(){
	//constants
	String AES_TRANSFORMATION = "AES/ECB/PKCS5Padding";
	String AES_ALGORITHM = "AES";
	ENC_BITS = 256;
	KeyGenerator keyGenerator = null;

	try {
		keyGenerator = KeyGenerator.getInstance(AES_ALGORITHM);
		keyGenerator.init(ENC_BITS);
	}
	catch (NoSuchAlgorithmException e) {
		e.printStackTrace();
	}

	SecretKey appkey = keyGenerator.generateKey();
	return appkey.getEncoded();
}

def String symmEncryption(String key, String data){
	//constants
	String AES_TRANSFORMATION = "AES/ECB/PKCS5Padding";
	String AES_ALGORITHM = "AES";
	ENC_BITS = 256;
	Cipher encryptCipher;

	try {
		encryptCipher = Cipher.getInstance(AES_TRANSFORMATION);
	} catch (NoSuchAlgorithmException | NoSuchPaddingException e1) {
		return null;
	}
	SecretKeySpec secreteKey = new SecretKeySpec(key.decodeBase64(), AES_ALGORITHM);
	encryptCipher.init(Cipher.ENCRYPT_MODE, secreteKey);

	InputStream instream = new ByteArrayInputStream(data.getBytes());
	OutputStream outStream = new ByteArrayOutputStream();

	final int cipherBlockSize = encryptCipher.getBlockSize();
	final int outBlockSize = encryptCipher.getOutputSize(cipherBlockSize);

	final byte[] inData = new byte[cipherBlockSize];
	byte[] outData = new byte[outBlockSize];
	int inReadSize = 0;

	try
	{
		while((inReadSize % cipherBlockSize == 0))
		{
			inReadSize = instream.read(inData);
			if(inReadSize == cipherBlockSize)
			{
				try {
					final int encryptedLength = encryptCipher.update(inData, 0, inReadSize,outData);
					outStream.write(outData, 0, encryptedLength);
				} catch (ShortBufferException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return null;
				}

			}
		}

		if(inReadSize > 0)
		{
			outData = encryptCipher.doFinal(inData,0,inReadSize);
		}
		else
		{
			outData = encryptCipher.doFinal();
		}

		outStream.write(outData);
		byte[] encryptedData = ((ByteArrayOutputStream)outStream).toByteArray();
		return encryptedData.encodeBase64().toString();
	}
	finally
	{
		try
		{
			instream.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
		try
		{
			outStream.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
	}
}
