import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.util.XmlSlurper

def Message processData(Message message) {

	// get the headers
	//def headers = message.get();
	def props = message.getProperties();
	// get the request body
	def body = message.getBody(String.class);
	def xmlSlurper = new XmlSlurper();
	def object = body;
	def newBody;
	
	// Read the Payload from ECC based on ACTION(e.g. ACCESSTOKEN, GENEWAYBILL, VEHEWB, GENCEWB, CANEWB, REJEWB, GetEwayBill,
	// GetEwayBillsofOtherParty, GetEwayBillsForTransporter, GetEwayBillsForTransporterByGstin, GetTripSheet etc.)
	switch (message.getProperty("action")) {
		case "GetEwayBill":
		    message.setProperty("ewbNo", props.get("ewbNo"));
			message.setProperty("api_action", "DETAILS");
			message.setProperty("eWayBillDetails", body);
			break;
		case "GetEwayBillsofOtherParty":
		   // message.setProperty("date", headers.get("date"));
			message.setProperty("api_action", "DETAILS");
			message.setProperty("eWayBillsAssigned", object);
			break;	
	    case "GetErrorList":
		   // message.setProperty("date", headers.get("date"));
			message.setProperty("api_action", "DETAILS");
			message.setProperty("errorList", object);
			break;	
		default:
			newBody = message.getProperty("action");
			break;
	}
	message.setBody(JsonOutput.toJson(newBody));
	return message;
}

