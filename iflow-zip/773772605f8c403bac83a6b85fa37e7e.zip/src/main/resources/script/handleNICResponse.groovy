/**
 * This script is used to handle the response received from GSP/GSTN system
 * 
 * Date		  |	Information
 * ------------------------------------------------------------------------ 
 * 13-08-2017 | Initial Version
 */

import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import groovy.json.JsonOutput

import java.security.NoSuchAlgorithmException

import javax.crypto.Cipher
import javax.crypto.NoSuchPaddingException
import javax.crypto.ShortBufferException
import javax.crypto.spec.SecretKeySpec
import javax.xml.bind.DatatypeConverter

import javax.crypto.Mac;

import java.util.zip.ZipEntry;
import org.apache.commons.compress.compressors.gzip.*;
import org.apache.commons.io.IOUtils;
import org.apache.commons.compress.archivers.tar.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;

def Message processData(Message message) {

	//Body
	def props = message.getProperties();
	def headers = message.getHeaders();

	def body = message.getBody(String.class);
	def jsonSlurper = new JsonSlurper();
	def object = jsonSlurper.parseText(body);
	def jsonString = new JsonBuilder();
	message.setHeader("status", object.status);

	// Form the header and body of the payload based on the api group(api_action) and action
	switch (props.get("api_action")) {
		case "AUTH":
		// for SUCCESS
			if(!object.status.equals("0"))
			{
				// for ACCESSTOKEN
				if (props.get("action").equals("ACCESSTOKEN")) {

					String appkey = headers.get("appkey");
					String sek = object.sek;
					String decsek = symmDecryption(appkey, object.sek);

					jsonString	status: object.status,
					authtoken: object.authtoken,
					sek:  decsek

					// Set authtoken and sek to property for further calls
					message.setProperty("authtoken", object.authtoken);
					message.setProperty("sek", decsek);

					String delimiter = "\$";
					def date = new Date(System.currentTimeMillis()).toString();
					//adding constant of 360 mins as nic is not providing it in response
					String completeToken = date.toString().concat(delimiter).concat(props.get("nic_tokenexpiry")).concat(delimiter).concat(object.authtoken).concat(delimiter).concat(decsek);
					message.setBody(completeToken);
				}
			}
			else
			{
				def actualErr = jsonSlurper.parseText(new String(object.error.decodeBase64()));
				message.setProperty("status", object.status);
				message.setProperty("errorCodes", actualErr.errorCodes);
			}
			break;
		case "EWAYBILL":
		// for SUCCESS
			if(!object.status.equals("0"))
			{
				message.setProperty("status", object.status);
				// for GENEWAYBILL
				if (props.get("action").equals("GENEWAYBILL")) {
					String sek = props.get("sek");
					String data = new String(symmDecryption(sek, object.data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					
					message.setProperty("alert", actualData.alert == null ? "": actualData.alert);
					message.setProperty("ewbNo", actualData.ewayBillNo == null ? "": actualData.ewayBillNo);
					message.setProperty("ewbDate", actualData.ewayBillDate == null ? "": actualData.ewayBillDate);
					message.setProperty("validUpto", actualData.validUpto == null? "": actualData.validUpto);
				}
				// for VEHEWB
				if (props.get("action").equals("VEHEWB")) {
					String sek = props.get("sek");
					String data = new String(symmDecryption(sek, object.data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					
					message.setProperty("vehUpdDate", actualData.vehUpdDate == null ? "": actualData.vehUpdDate);
					message.setProperty("validUpto", actualData.validUpto == null ? "": actualData.validUpto);
				}
				// for CANEWB
				if (props.get("action").equals("CANEWB")) {
					String sek = props.get("sek");
					String data = new String(symmDecryption(sek, object.data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					
					message.setProperty("ewbNo", actualData.ewayBillNo == null ? "": actualData.ewayBillNo);
					message.setProperty("cancelDate", actualData.cancelDate == null ? "": actualData.cancelDate );
				}
				// for UPDATETRANSPORTER
				if (props.get("action").equals("UPDATETRANSPORTER")) {
					String sek = props.get("sek");
					String data = new String(symmDecryption(sek, object.data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					
					message.setProperty("ewbNo", actualData.ewayBillNo == null ? "": actualData.ewayBillNo);
					message.setProperty("transporterId", actualData.transporterId == null ? "": actualData.transporterId );
					message.setProperty("transUpdateDate", actualData.transUpdateDate == null ? "": actualData.transUpdateDate);
				}
				// for EXTENDVALIDITY
				if (props.get("action").equals("EXTENDVALIDITY")) {
					String sek = props.get("sek");
					String data = new String(symmDecryption(sek, object.data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					
					message.setProperty("ewbNo", actualData.ewayBillNo == null ? "": actualData.ewayBillNo);
					message.setProperty("updatedDate", actualData.updatedDate == null ? "": actualData.updatedDate);
					message.setProperty("validUpto", actualData.validUpto == null ? "": actualData.validUpto);
				}
				// for REJEWB 
			    if (props.get("action").equals("REJEWB")) {
					String sek = props.get("sek");
					String data = new String(symmDecryption(sek, object.data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					
					message.setProperty("ewbNo", actualData.ewayBillNo == null ? "": actualData.ewayBillNo);
					message.setProperty("ewbRejectedDate", actualData.ewbRejectedDate == null ? "": actualData.ewbRejectedDate);
				}
				// for MULTIVEHMOVINT
				if (props.get("action").equals("MULTIVEHMOVINT")) {
					String sek = props.get("sek");
					String data = new String(symmDecryption(sek, object.data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					
					message.setProperty("ewbNo", actualData.ewbNo == null ? "": actualData.ewbNo);
					message.setProperty("groupNo", actualData.groupNo == null ? "": actualData.groupNo);
					message.setProperty("createdDate", actualData.createdDate == null ? "": actualData.createdDate);
					
				}
				// for MULTIVEHADD
				if (props.get("action").equals("MULTIVEHADD")) {
					String sek = props.get("sek");
					String data = new String(symmDecryption(sek, object.data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					
					message.setProperty("ewbNo", actualData.ewbNo == null ? "": actualData.ewbNo);
					message.setProperty("groupNo", actualData.groupNo == null ? "": actualData.groupNo);
					message.setProperty("vehAddedDate", actualData.vehAddedDate == null ? "": actualData.vehAddedDate);
					
				}
				// for MULTIVEHUPD
				if (props.get("action").equals("MULTIVEHUPD")) {
					String sek = props.get("sek");
					String data = new String(symmDecryption(sek, object.data).decodeBase64());
					def actualData = jsonSlurper.parseText(data);
					
					message.setProperty("ewbNo", actualData.ewbNo == null ? "": actualData.ewbNo);
					message.setProperty("groupNo", actualData.groupNo == null ? "": actualData.groupNo);
					message.setProperty("vehUpdDate", actualData.vehUpdDate == null ? "": actualData.vehUpdDate);
					
				}
			}
			else
			{
				def actualErr = jsonSlurper.parseText(new String(object.error.decodeBase64()));
				message.setProperty("status", object.status);
				message.setProperty("errorCodes", actualErr.errorCodes);
				
				//This part is to handle Invalid Auth Token scenario
				String error = actualErr.errorCodes;
				if(error.contains("238")) {
					message.setProperty("code", "238");
				}
				
				//This part is to handle pincode to pincode distance scenario
				if(error.contains("702")) {
					if(object.info == "") {
					    message.setProperty("distance", "100");
					}
					else {
					    def errInfo = jsonSlurper.parseText(new String(object.info.decodeBase64()));
						message.setProperty("distance",errInfo.distance);
						message.setProperty("fromPincode",errInfo.fromPinCode);
						message.setProperty("toPincode",errInfo.toPinCode);
						
					}
				}
			}
			break;
		case "DETAILS":
		// for SUCCESS
		message.setProperty("status", object.status);
			if(!object.status.equals("0")){
				// for GetEwayBill
				if(props.get("action").equals("GetEwayBill")){
					String sek = props.get("sek");
					String decrek = symmDecryption(sek, object.rek);
					String data = new String(symmDecryption(decrek, object.data).decodeBase64());

					def actualData = jsonSlurper.parseText(data);
					jsonString details: actualData
					message.setBody(jsonString.toString())					
				}
				
				// for GetEwayBillsofOtherParty
				if(props.get("action").equals("GetEwayBillsofOtherParty")){
					String sek = props.get("sek");
					String decrek = symmDecryption(sek, object.rek);
					String data = new String(symmDecryption(decrek, object.data).decodeBase64());

					def actualData = jsonSlurper.parseText(data);
					jsonString RecData: actualData
					
					def finalObj = new JsonBuilder();
					def finalData = jsonSlurper.parseText(jsonString.toString());
					finalObj root: finalData
					message.setBody(finalObj.toString());
					message.setProperty("getEwayBillData", finalObj.toString());
					message.setProperty("data", data);
					message.setProperty("jsonString",jsonString.toString() );
				}
				
				// for GetErrorList
				if(props.get("action").equals("GetErrorList")){
					String sek = props.get("sek");
					String decrek = symmDecryption(sek, object.rek);
					String data = new String(symmDecryption(decrek, object.data).decodeBase64());

					def actualData = jsonSlurper.parseText(data);
					jsonString data: actualData
					
					def finalObj = new JsonBuilder();
					def finalData = jsonSlurper.parseText(jsonString.toString());
					finalObj root: finalData
					message.setBody(finalObj.toString());
					
					message.setProperty("getEwayBillData", jsonString.toString());
					message.setProperty("data", data);
					message.setProperty("actualData", finalObj);
					message.setProperty("jsonString", jsonString);
				}
			
			}
			else
			{
				def actualErr = jsonSlurper.parseText(new String(object.error.decodeBase64()));
				message.setProperty("status", object.status);
				message.setProperty("errorCodes", actualErr.errorCodes);
				
				//This part is to handle Invalid Auth Token scenario
				String error = actualErr.errorCodes;
				if(error.contains("238")) {
					message.setProperty("code", "238");
				}
			}
			break;
		default:
			break;
	}
	return message;
}

def void setResponseBody(def object, Message message, def error) {
	if (object != null) {
		message.setProperty("status", "1");
		message.setProperty("docNo", message.getProperty("docNo"));
		message.setProperty("ewbNo", object.ewayBillNo);
		message.setProperty("ewbDate", object.ewayBillDate);
		message.setProperty("vehUpdDate", object.vehUpdDate);
		message.setProperty("validUpto", object.validUpto);
		message.setProperty("cancelDate", object.cancelDate);
	}
	if (error != null) {
		message.setProperty("status", "0");
		message.setProperty("errorCodes", error.errorCodes);
	}
}

def String symmDecryption(String key, String data){
	//constants
	String AES_TRANSFORMATION = "AES/ECB/PKCS5Padding";
	String AES_ALGORITHM = "AES";
	ENC_BITS = 256;
	Cipher decryptCipher;

	try {
		decryptCipher = Cipher.getInstance(AES_TRANSFORMATION);
	} catch (NoSuchAlgorithmException | NoSuchPaddingException e1) {
		return null;
	}
	SecretKeySpec secreteKey = new SecretKeySpec(key.decodeBase64(), AES_ALGORITHM);
	decryptCipher.init(Cipher.DECRYPT_MODE, secreteKey);

	InputStream instream = new ByteArrayInputStream(DatatypeConverter.parseBase64Binary(data));
	OutputStream outStream = new ByteArrayOutputStream();

	final int cipherBlockSize = decryptCipher.getBlockSize();
	final int outBlockSize = decryptCipher.getOutputSize(cipherBlockSize);

	final byte[] inData = new byte[cipherBlockSize];
	byte[] outData = new byte[outBlockSize];
	int inReadSize = 0;

	try
	{
		while((inReadSize % cipherBlockSize == 0))
		{
			inReadSize = instream.read(inData);
			if(inReadSize == cipherBlockSize)
			{
				try {
					final int encryptedLength = decryptCipher.update(inData, 0, inReadSize,outData);
					outStream.write(outData, 0, encryptedLength);
				} catch (ShortBufferException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return null;
				}

			}
		}

		if(inReadSize > 0)
		{
			outData = decryptCipher.doFinal(inData,0,inReadSize);
		}
		else
		{
			outData = decryptCipher.doFinal();
		}

		outStream.write(outData);
		byte[] decryptedData = ((ByteArrayOutputStream)outStream).toByteArray();
		return decryptedData.encodeBase64().toString();
	}
	finally
	{
		try
		{
			instream.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
		try
		{
			outStream.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
	}
}

def String generateHmac(String key, String data){
	try{
		Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
		SecretKeySpec secret_key = new SecretKeySpec(key.decodeBase64(), "AES");
		sha256_HMAC.init(secret_key);

		String hash = sha256_HMAC.doFinal(data.getBytes()).encodeBase64().toString();
		return hash;
	}catch(Exception e){
		return "";
	}
}