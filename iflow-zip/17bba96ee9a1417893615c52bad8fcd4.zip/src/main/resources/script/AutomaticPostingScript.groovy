import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def materialType=message.getProperty("Material Types")
    def plant=message.getProperty("Plants")
	
    def movementType =message.getProperty("Movement Types")
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	
	
	//def lastSyncDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss",message.getProperty("lastSyncDate"));
	def newDocumentsList = []
	def newSerialNosList = []
	
	String matDocNumeber=object.materialDocumentNumber
	String referenceDocumentNo=object.referenceDocumentNo
	String postingDocDate=object.postingDate
	String externalDelivery=object.externalDeliveryNumber
	String billOfLading=object.billOfLading
    def itemList = object;
	def serialNumberList=object

	//println("se0"+serialNumbers.serialNos)
	
		if (!isCollectionOrArray(itemList.line)) {
			itemList = [itemList].toArray();
			
		}

		if (!isCollectionOrArray(serialNumberList.serialNos)) {
		    if(serialNumberList.serialNos!=null && serialNumberList.serialNos!=""){
			serialNumberList = [serialNumberList].toArray();
		    }
			
		}
	
	    for(Object item in itemList.line) {
       		newDocumentsList.add(item)
        }

		for(Object itemSerialNos in serialNumberList.serialNos) {
    		newSerialNosList.add(itemSerialNos)
        } 
	
	
	// Batch Payload
    String completePayload = "";
  
    // Generate Random Id to be used in Batch Code
    String batchId = UUID.randomUUID().toString();
  
    // Prepare Batch Code
    String batchCode = "--batch_id-" + batchId; 

	// Generate changeset Id to be used in changeset Code
	String changesetID = UUID.randomUUID().toString();
	
	// Prepare changeset Code
	String changeset = "--changeset_" + changesetID; 
	
	completePayload=completePayload.concat(batchCode + "\n")
	completePayload=completePayload.concat("Content-Type: multipart/mixed; boundary=changeset_"+changesetID+ "\n")
	
	//Checking if there is only one Record
    if (!isCollectionOrArray(newDocumentsList)) {
        //Converting Record to an array
        newDocumentsList = [newDocumentsList].toArray();
		//println(record)

    }

	if (!isCollectionOrArray(newSerialNosList)) {
        //Converting Record to an array
        newSerialNosList = [newSerialNosList].toArray();
		//println(record)

    }
	
	// Prepare changeset data by looping the list of records
	newDocumentsList.each { record ->
		if( checkIfExists(record.plant, plant) 
		    && checkIfExists(record.materialType,materialType)
		    && checkIfExists(record.movementType,movementType)){
		String tempPayload = changeset + "\n"
		tempPayload = tempPayload + "Content-Type:application/http " + "\n" + "Content-Transfer-Encoding:binary" + "\n" + "\n"
		tempPayload = tempPayload + "POST Documents HTTP/1.1" + "\n"
		tempPayload = tempPayload + "Accept:application/json;odata.metadata=minimal;IEEE754Compatible=true" + "\n" 
		tempPayload = tempPayload + "Accept-Language:en-US" + "\n" 
		tempPayload = tempPayload + "Content-Type:application/json;charset=UTF-8;IEEE754Compatible=true" + "\n" + "\n" 
	    
		def postingDocument = prepareDocument(record,matDocNumeber,referenceDocumentNo,newSerialNosList,postingDocDate,externalDelivery,billOfLading)
		tempPayload = tempPayload + JsonOutput.toJson(postingDocument) + "\n"	
		completePayload=completePayload.concat(tempPayload)
		}
	
	}
	
	// Close the full payload
	completePayload = completePayload + "--changeset_" + changesetID + "--" + "\n"
	
	// Prepare Message Body
	message.setBody(completePayload)
	
	// Prepare Boundary Header Parameter to be added in message header
	String boundaryParam = "multipart/mixed; boundary=changeset_" + changesetID;
	
	// Prepare Message Header
	message.setHeader('Content-Type', boundaryParam)
	message.setHeader('Prefer', "odata.continue-on-error")
	
    return message
}
def boolean checkIfExists(String value, Object configItem){
    boolean valid = false;
    if(null != configItem && "" != configItem){
         String[] items = configItem.split(',');
         for(Object item in items) {
             if(item.trim().equals(value)){
                 valid = true;
                 break;
             }
         }
    }else{
        valid=true;
    }
    return valid;
}
def Object prepareDocument( Object item,Object matDocNumeber,Object referenceDocumentNo,def newSerialNosList,Object postingDocDate,Object externalDelivery,Object billOfLading) {
        def itemNum=0;
        if(item.materialDocumentItemNumber!=null){
            itemNum=Integer.parseInt(item.materialDocumentItemNumber)
        }
	    def stockType="01"
		def record = new Document().with  {
				assert delegate.class.name == 'Document'
				postingDate = Date.parse("yyyyMMdd",postingDocDate).format('yyyy-MM-dd')
				def year=Date.parse("yyyyMMdd",postingDocDate).format('yyyy')
				returnableMaterialQuantity = (int)Double.parseDouble(item.returnableMaterialQuantity)
				returnableMaterialUOM_code = item.returnableMaterialUOM_code
				plant = item.plant
				customerCode = item.customerCode
				vendorCode = item.vendorCode
				movementType = item.movementType
				materialCode = item.materialCode
				if(item.stockType=="3"){
				    stockType="07"
				}
				if(item.stockType=="X"){
				    stockType="02"
				}
				inventoryStockTypeID_ID = stockType
				//materialDocumentNumber = item.materialDocumentNumber
				materialDocumentNumber = matDocNumeber
				materialDocumentItemNumber = itemNum
				externalDeliveryNoteNumber=referenceDocumentNo
				postingDocSerialNumbers=prepareSerialNumberList(newSerialNosList,item.materialDocumentItemNumber)
				// Adding code for Stock Type
				if(null != item.movInd && "D" ==item.movInd){
				    if(null==item.customerCode || "" ==item.customerCode){
				        if(item.movPlant != null && "" != item.movPlant ){
				            receivingPlant = item.movPlant
				        }
				    }
				}
				if(null!=externalDelivery && !externalDelivery.isEmpty()){
				    externalDeliveryNoteNumber = externalDelivery
				}/*else{
				    externalDeliveryNoteNumber=deliveryNote
				}*/
				//externalDeliveryNoteNumber = externalDelivery
				//materialDocumentYear = Integer.parseInt(year)
				materialDocumentYear = year
				if(null != billOfLading && ""!=billOfLading){
				referenceDocument = prepareBillOfLaden(billOfLading)    
				}
				storageLocation=item.stgLoc
                unloadingPoint=item.unLoadingPt
                
			return delegate
        }
		
	return record;
}

def Object prepareBillOfLaden(String record) {

	def referenceDocument = []
	if (null!=record && !record.isEmpty()) {
	    referenceDocument = prepareRefrenceDocument(record)
	   }
	return referenceDocument;
}

def Object prepareRefrenceDocument(String input){
    def record = new ReferenceDocument().with  {
				assert delegate.class.name == 'ReferenceDocument'
				billOfLading = input
			return delegate
        }
        
    return record;        
}


class ReferenceDocument{
    String billOfLading
}

def Object prepareSerialNumberList(def serialNoList,Object itemDocNo) {
	def postingDocSerialNumbers = []
	serialNoList.each{record ->
	String serialNo
	println("serialNos:"+record)
	if(itemDocNo.equals(record.orderItemNo)){
	def serialNum=Integer.parseInt(record.serialno)
	def serialNumberItem = prepareSerialNumberItem(serialNum);
	postingDocSerialNumbers.add(serialNumberItem)
	}
	}
	
	return postingDocSerialNumbers;
}

def Object prepareSerialNumberItem(Object item) {
	
		def record = new SerialNumber().with  {
				assert delegate.class.name == 'SerialNumber'
				serialNumberCode = item
			return delegate
        }
		
	return record;
}

class SerialNumber {
    String serialNumberCode
}


class Document {
    String postingDate, returnableMaterialUOM_code, plant, customerCode, vendorCode, movementType, materialCode, materialDocumentNumber, materialDocumentItemNumber, inventoryStockTypeID_ID, receivingPlant, externalDeliveryNoteNumber,materialDocumentYear,storageLocation,unloadingPoint
	int returnableMaterialQuantity
	def postingDocSerialNumbers
	def referenceDocument
}


//Returns true if object is an array
boolean isCollectionOrArray(object) {
    [Collection, Object[]].any {
        it.isAssignableFrom(object.getClass())
    }
}