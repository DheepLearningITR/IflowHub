import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def body = message.getBody(String.class);
   
    String json = JsonOutput.toJson(body)
    JsonSlurper slurper = new JsonSlurper()

     def result = slurper.parseText(json)
     //def logger = message.getProperty("EnableLog");
	 //logs = logger.toLowerCase()
     //println(logs)
	 
     def logItems=['postingDocumentNumber','materialDocumentNumber','materialCode','postingDate','plant','returnableMaterialQuantity','movementType','externalDeliveryNoteNumber','materialDocumentYear']
     def errorLogItems=['code','message']
     def logMsg="";
    
      //String[] lines = result.split("\n");
      String[] lines = result.split("\n");
       int count=0;
      lines.each {line->
        if (line.startsWith('{"@context"')) {
            //if(logs){
                
                count=count+1
                String countVal=count.toString();
                logMsg=logMsg.concat("Record No:").concat(countVal).concat("\n")
                def tempLog=fetchResponseLogs(line,logItems)
                logMsg=logMsg.concat(tempLog);
                logMsg=logMsg.concat("Result:").concat("Record Posted Sucessfully").concat("\n\n");     
                println(logMsg)
                
            //}
           
    
        }else{
            if(line.indexOf("error")>0){
                count=count+1
                String countVal=count.toString();
                logMsg=logMsg.concat("Record No:").concat(countVal).concat("\n")
                logMsg=logMsg.concat(fetchErrorResponseLogs(line,errorLogItems));
                logMsg=logMsg.concat("Result:").concat("Failure").concat("\n\n");
            }
            
        }
    
}

   
    def messageLog = messageLogFactory.getMessageLog(message);
    def propertyMap = message.getProperties()
    //Read logger from the Message Properties
    //def logger = message.getProperty("Logger");
    //logs = logger
    //if(logs=="true"||logs.equals("true")){
        if(messageLog != null && (null!=logMsg && ""!=logMsg )){
        messageLog.setStringProperty("postingDocumentLog", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("ResponsePayload_postingDocumentLog: ", logMsg , "text/plain");
    }
         //}
    return message
}

def String fetchResponseLogs(String string,def logItems){
    String logMsg="";
     logItems.each{logItem->
     int index=string.indexOf(logItem);
     
        if(index>0){
            String docString=""
            String tempString=string.substring(index);
            def checkValue=tempString.substring(tempString.indexOf(':')+1,tempString.indexOf(':')+2)
            if(!checkValue.toString().isInteger()){
                if(tempString.indexOf(':"')>0){
                    docString=tempString.substring(tempString.indexOf(':"')+2,tempString.indexOf('",'))
                }else{
                    docString="null"
                }
                
            }else{
                docString=tempString.substring(tempString.indexOf(':')+1,tempString.indexOf(','))
           
            }
            //String docString=tempString.substring(tempString.indexOf(':"')+2,tempString.indexOf('",'))
            logMsg=logMsg.concat(logItem).concat(":").concat(docString).concat("\n");
        }

     }
     return logMsg
}

def String fetchErrorResponseLogs(String string,def logItems){
    String logMsg="";
     logItems.each{logItem->
     int index=string.indexOf(logItem);
           
        if(index>0){
            String docString=""
            if(logItem.equals("message")){
                int detailsIndex=string.indexOf("details")
                if(detailsIndex>0){
                String tempString=string.substring(detailsIndex);
                tempString=tempString.substring(tempString.indexOf('[')+1,tempString.indexOf(']'))
                def jsonSlurper = new JsonSlurper();
                def object = jsonSlurper.parseText(tempString);                    
                docString=object.message
                }
            }else{
                String tempString=string.substring(index);
                def checkValue=tempString.substring(tempString.indexOf(':')+1,tempString.indexOf(':')+2)
         
                if(!checkValue.toString().isInteger()){
                    docString=tempString.substring(tempString.indexOf(':"')+2,tempString.indexOf('",'))
                }else{
                    docString=tempString.substring(tempString.indexOf(':')+1,tempString.indexOf(','))
            
                }
            }
         
         logMsg=logMsg.concat(logItem).concat(":").concat(docString).concat("\n");
        }

     }
     return logMsg
}






