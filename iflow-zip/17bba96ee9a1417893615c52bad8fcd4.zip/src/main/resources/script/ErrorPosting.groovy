import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) { 
    
    
        def exceptionMsg = message.getProperty("CamelExceptionCaught")
        def messageLog = messageLogFactory.getMessageLog(message)
        messageLog.addAttachmentAsString("Cannot fetch material information ",exceptionMsg.getMessage(),"text/plain")
        throw new IOException();
        
        
       
        
         
    
	
    return message
}
