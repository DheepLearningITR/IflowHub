import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*
import groovy.util.slurpersupport.GPathResult
import java.util.HashMap;
import java.util.HashSet;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter;
import java.io.*;


def convertTimeFormat(inputMessageBody){
    String NORMAL_DATE_FORMAT = "yyyy-MM-dd";
    String DETAIL_DATE_TIME_FORMAT = "yyyyMMddHHmmss";//.fff";

    String createdOn = inputMessageBody.root[0].'createdOn'.text()
    if(!createdOn.isNumber()){

        String formattedPostingDate = 
                LocalDateTime.parse(createdOn)
                        .format(
                                DateTimeFormatter.ofPattern(NORMAL_DATE_FORMAT)
                        )
        inputMessageBody.root[0].'postingDate'.replaceBody(formattedPostingDate)

        String formattedCreatedOn = 
                LocalDateTime.parse(createdOn)
                        .format(
                                DateTimeFormatter.ofPattern(DETAIL_DATE_TIME_FORMAT)
                        )
        inputMessageBody.root[0].'createdOn'.replaceBody(formattedCreatedOn)

        String formattedChangedOn = 
                LocalDateTime.parse(createdOn)
                        .format(
                                DateTimeFormatter.ofPattern(DETAIL_DATE_TIME_FORMAT)
                        )
        inputMessageBody.root[0].'changedOn'.replaceBody(formattedChangedOn)
    }
}

def Message createFlowInfoAndSetBody(Message inputMessage){

    def inputMessageBody = new XmlSlurper()
            .parse(inputMessage.getBody(java.io.Reader))

    def mkpBuilder = new StreamingMarkupBuilder()
    def rootBuilder = new StreamingMarkupBuilder()
    convertTimeFormat(inputMessageBody)

    addPromotionElement(inputMessageBody)
    def rootSubElement = inputMessageBody.root[0].children()

    mkpBuilder.encoding = 'utf-8'

    def currentStageFlow = XmlUtil.serialize(
            mkpBuilder.bind { bld ->
                message {
                    bo(rootSubElement)
                    trans()
                }
            }
    )

    def newBodyString = XmlUtil.serialize(
            rootBuilder.bind{
                root(rootSubElement)
            }
    )
    inputMessage.setBody(newBodyString)
    inputMessage.setProperty("flowInfo", currentStageFlow)

    def messageLog = messageLogFactory.getMessageLog(inputMessage);
    if(messageLog != null){
        messageLog.addAttachmentAsString("flowInfo:", currentStageFlow, "text/xml");
    }
    return inputMessage
}

def String prepareCallbackPayload(String flowInfo, String targetUUID, Message inputMessage){
    def messageLog = messageLogFactory.getMessageLog(inputMessage);
    String settlementid = null
    def flowInfoNode = null
    if(targetUUID != null && targetUUID.trim().length() != 0){
        settlementid = targetUUID
    }else{
        flowInfoNode = new XmlSlurper().parseText(flowInfo)
        settlementid = flowInfoNode.bo.settlementUUID.text()
    }
    def now = LocalDateTime.now()
    def exceptionCallbackPayload = new XmlSlurper().parseText("<root/>")
    def properties = inputMessage.getProperties();

    def camelExceptionCaught = properties.get("CamelExceptionCaught") as String;


    StringBuffer errorMessages = new StringBuffer();
    String stageMessage = "Failed to create settlement in SAP CRM";
    errorMessages.append(stageMessage + "\n")
    if(camelExceptionCaught != null){
        errorMessages.append(camelExceptionCaught + "\n");
    }

    if(properties.containsKey("errorlogs") ){
        def errorLogsString = properties.get("errorlogs") as String
        messageLog.addAttachmentAsString("erroLogs", errorLogsString, "text/xml")
        def errorLogs = new XmlSlurper().parseText(errorLogsString);
        errorLogs.'error'.each{
            error -> 
                StringBuffer content = new StringBuffer();
                String errorMessage = error.'errorMessage'.text()
                String billId = error.'BILL_DOC_ID'.text()
                String itemNumber = error.'ITEM_NUMBER'.text()
                
                if(itemNumber != null && itemNumber.trim().length() > 0){
                    content.append("ITEM_NUMBER: " + itemNumber + " ");
                }
                
                if(billId != null && billId.trim().length() > 0){
                    content.append("BILL_DOC_ID: " + billId + " ");
                }
                
                if(errorMessage != null && errorMessage.trim().length() > 0){
                    
                    content.append("error: " + errorMessage);
                }
                 errorMessages.append(content.toString() + "\n\n");
        }
    }

   String finalMessage = errorMessages.toString();

    exceptionCallbackPayload.appendNode{
         settlementUUID(settlementid)
            timestamp(now)
            action("SETTLE")            
            status("ERROR")
            message(finalMessage)
    }
    if(flowInfoNode != null){
        if(flowInfoNode.documentTransactions != null && flowInfoNode.documentTransactions.size() > 0){
            exceptionCallbackPayload.appendNode(flowInfoNode.documentTransactions)
        }
    }

   String payload = XmlUtil.serialize(exceptionCallbackPayload)
   return payload
}

def Message sleep(Message message) {
    def properties = message.getProperties();
    def retryCount = properties.get("retryCount") as Integer;
    //30s
    def sleepUnit = properties.get("sleepUnit") as Long;

    //using fixed sleep time 
    sleepTime = 1 * sleepUnit * 1000;
    if(retryCount>0){
       new Object().sleep(sleepTime); 
    }
    
    return message;
}

def Message prepareTpmCallExecution(Message inputMessage){
    initTranProperty(inputMessage)
    return inputMessage
}

def initTranProperty(Message inputMessage){
    def propertiesMap = inputMessage.getProperties()
    def messageBodyNode = new XmlSlurper()
            .parse(inputMessage.getBody(java.io.Reader))
    def retryCount = propertiesMap.get("retryCount") as Integer 
    
    String tran = "<tran api=\"Tpm\" callOrder=\"" + retryCount + "\">\n" +
                "    <request> \n" +
                "      <body>\n" +
                "      </body>\n" +
                "    </request>\n" +
                "    <response>\n" +
                "    </response>\n" +
                "</tran>\n"
                
    
   def tranNode = new XmlSlurper().parseText(tran)

   tranNode.request[0].body[0].appendNode(messageBodyNode)
   def currentTran = XmlUtil.serialize(tranNode)
   
   inputMessage.setProperty("currentTran", currentTran)
}

def checkRetryable(GPathResult rfcResponseNode,GPathResult flowInfoNode, Map propertiesMap, Message inputMessage){

    def block = "block"
    def retry = "shouldRetry"
    def success = "success"

    List<GPathResult> errorResultLogs = new ArrayList<>();
   
    def isNotTypeEMessage = rfcResponseNode.'ET_SETTLEMENT_MSG'.'item'.findAll{
        node -> node.'TYPE'.text().trim().length() > 0 && "E".equals((String)node.'TYPE'.text())
    }.size() == 0
 
     rfcResponseNode.'ET_SETTLEMENT_MSG'.'item'.each{
         item -> errorResultLogs.add(logErrorMessage(item))
     }
 
    Set allStatuses = new HashSet<>();
    Set documentTransactions = new HashSet<>();

    rfcResponseNode.'ET_SETTLEMENT_RETURN'.'item'.each{
        item -> 
            if(item.'ERROR'.text().length() != 0){
                 errorResultLogs.add(logError(item))
            }
        
            if(item.'ERROR'.text().trim().length() != 0 && item.'ERROR'.text().trim().toLowerCase().contains("locked by another session")){
                allStatuses.add(retry)
                //errorResultLogs.add(logError(item))
            }else if(item.'BILL_DOC_ID'.text().trim().length() == 0 && isNotTypeEMessage){
                //"no value in field BILL_DOC_ID and also no Error messages presented")
                allStatuses.add(retry)
            }else if(item.'BILL_DOC_ID'.text().trim().length() != 0 && item.'ERROR'.text().trim().length() != 0){
                //"BILL_DOC_ID presented, but Error presented in item response"
               // errorResultLogs.add(logError(item))
                allStatuses.add(retry)
                documentTransactions.add(getDocumentTransaction(inputMessage,flowInfoNode, item))
            }else if(item.'BILL_DOC_ID'.text().trim().length() == 0){
                //"BILL_DOC_ID is empty")
              //  errorResultLogs.add(logError(item))
                allStatuses.add(block)
            }else{
                  //"Success"
                allStatuses.add(success)
                documentTransactions.add(getDocumentTransaction(inputMessage,flowInfoNode, item))
            }
    }

    def retryCount = propertiesMap.get("retryCount") as Integer
    def maxRetryCount = propertiesMap.get("maxRetryCount") as Integer

    if(allStatuses.size() == 0){
        allStatuses.add(retry)
    }

    def errorLogsNode = new XmlSlurper().parseText("<errors/>")


    if((allStatuses.contains(block))){
        propertiesMap.put("isRetryable", false)
        flowInfoNode.appendNode(documentTransactions)
        errorLogsNode.appendNode(errorResultLogs)
        propertiesMap.put("processDirect", "ErrorProcess")
    }else if(allStatuses.contains(retry)){
        // retry
        retryCount = retryCount + 1
        if(retryCount == maxRetryCount){
            errorLogsNode.appendNode(errorResultLogs)
            flowInfoNode.appendNode(documentTransactions)
        }
        propertiesMap.put("processDirect", "ErrorProcess")
        propertiesMap.put("retryCount", retryCount)
    }else{
        propertiesMap.put("isRetryable", false)
        flowInfoNode.appendNode(documentTransactions)
        propertiesMap.put("processDirect", "CreditMemo")
    }

    def currentFlowInfoString = XmlUtil.serialize(flowInfoNode)
    def erroLogsString = XmlUtil.serialize(errorLogsNode)
    propertiesMap.put("flowInfo", currentFlowInfoString)
    propertiesMap.put("errorlogs", erroLogsString)

    
}

def Message handleException(Message inputMessage){
  
    def messageLog = messageLogFactory.getMessageLog(inputMessage);
    def propertiesMap = inputMessage.getProperties() 
    
   def camelExceptionCaught = propertiesMap.get("CamelExceptionCaught") as String;
   messageLog.addAttachmentAsString("camelExceptionCaught", camelExceptionCaught, "text/plain")
   
    def flowInfo = propertiesMap.get("flowInfo") as String
    def settlementUUID = propertiesMap.get("settlementUUID") as String
    inputMessage.setProperty("processDirect", "ErrorProcess")
    inputMessage.setProperty("isRetryable", false)

    def body = prepareCallbackPayload(flowInfo, settlementUUID, inputMessage)
     if(messageLog != null){
        messageLog.addAttachmentAsString("Exception Body", body, "text/xml")
    }   
    inputMessage.setBody(body)
    return inputMessage
}


 def GPathResult getDocumentTransaction(inputMessage,flowInfoNode,item){
    String DETAIL_DATE_TIME_FORMAT = "yyyyMMddHHmmss";//.fff";
   LocalDateTime time = LocalDateTime.parse(flowInfoNode.bo.'createdOn'.text(), DateTimeFormatter.ofPattern(DETAIL_DATE_TIME_FORMAT))
    String bill_doc = item.'BILL_DOC_ID'.text()
    
    def mkpBuilder = new StreamingMarkupBuilder()
    
     def documentTransactionsNode = mkpBuilder.bind { bld -> 
         documentTransactions{
            documentType("SETTLEMENT_DOCUMENT")
            fiscalYear()
            createdOn(time)
            documentNumber(bill_doc)
        }
    }

    def dtNode = new XmlSlurper().parseText(XmlUtil.serialize(documentTransactionsNode))
    return dtNode

}

def GPathResult logError(GPathResult item){
    def errorLog = new XmlSlurper().parseText("<error/>")
    String billDocId = item.BILL_DOC_ID.text()
    String error = item.'ERROR'.text()
    String itemNumber = item.'ITEM_NUMBER'.text()
    errorLog.appendNode{
        BILL_DOC_ID(billDocId)
        ITEM_NUMBER(itemNumber)
        errorMessage(error)
    }
    return errorLog
}


def GPathResult logErrorMessage(GPathResult item){
    def errorLog = new XmlSlurper().parseText("<error/>")
    String error = item.'MESSAGE'.text()
    errorLog.appendNode{
        errorMessage(error)
    }
    return errorLog
}

def addPromotionElement(inputMessage){
    inputMessage.root[0].items.each {
        item ->
            boolean hasPromotionReference = false
            item.reference.findAll{
                ref -> "Promotion".equals(ref.referenceType.text())
            }.each {
                ref ->
                    hasPromotionReference = true
                  def referenceNumber =  ref.referenceNumber.text()
                  def promotionIdNode = new XmlSlurper().parseText("<promotionId>"+referenceNumber + "</promotionId>")
                    item.appendNode(promotionIdNode)
            }
            if(!hasPromotionReference){
                def promotionIdNode = new XmlSlurper().parseText("<promotionId/>")
                item.appendNode(promotionIdNode)
            }
    }
}

def recordCurrentExecution(GPathResult flowInfoNode, GPathResult tpmResponseNode, Integer retryCount, String tpmRequest){

    //create tran node for current execution
    String tran = "<tran api=\"Tpm\" callOrder=\"" + retryCount + "\">\n" +
            "    <request> \n" +
            "      <body>\n" +
            "      </body>\n" +
            "    </request>\n" +
            "    <response>\n" +
            "    </response>\n" +
            "</tran>\n"
    def tranNode = new XmlSlurper().parseText(tran)

    //append request and response info to tran node
    def requestNode = new XmlSlurper().parseText(tpmRequest)
    tranNode.request[0].body[0].appendNode(requestNode)
    tranNode.response[0].appendNode(tpmResponseNode)

    //appendto flow Information node
    flowInfoNode.trans[0].appendNode(tranNode)
}

def Message handleResponse(Message inputMessage){

    String body = inputMessage.getBody(String)
    //get information
    def propertiesMap = inputMessage.getProperties()
    def responseNode = new XmlSlurper()
            .parseText(body)

    def retryCount = propertiesMap.get("retryCount") as Integer
    def request = propertiesMap.get("tpmRequest") as String
    def flowInfoString = propertiesMap.get("flowInfo") as String
    def flowInfoNode = new XmlSlurper().parseText(flowInfoString)


    //log execution
    recordCurrentExecution(flowInfoNode as GPathResult, responseNode as GPathResult, retryCount, request)

    def messageLog = messageLogFactory.getMessageLog(inputMessage);
    if(messageLog != null){
        messageLog.addAttachmentAsString("TPM_RESPONSE_BODY_RETRY_" + retryCount, body, "text/xml");
    }

    checkRetryable(responseNode as GPathResult, flowInfoNode as GPathResult, propertiesMap, inputMessage)
    return inputMessage
}


def prepareNextProcess(Message inputMessage){

    def propertiesMap = inputMessage.getProperties()
    def body = propertiesMap.get("flowInfo") as String
    inputMessage.setBody(body)

    def messageLog = messageLogFactory.getMessageLog(inputMessage);
    if(messageLog != null){
        messageLog.addAttachmentAsString("TPM_PROCESS_OUTPUT:", body , "text/xml");
    }
}


def Message printOutput(Message inputMessage){
     def propertiesMap = inputMessage.getProperties()
    def messageLog = messageLogFactory.getMessageLog(inputMessage);
    def body = propertiesMap.get("flowInfo") as String
    if(messageLog != null){
        //messageLog.addAttachmentAsString("tpm_process_flow_message", flowInfo, "text/xml")
        messageLog.addAttachmentAsString("TPM_PROCESS_OUTPUT:", body , "text/xml");
    }
    return inputMessage
}

def Message printRequest(Message inputMessage){
    String body = inputMessage.getBody(String)
    def messageLog = messageLogFactory.getMessageLog(inputMessage);
    if(messageLog != null){
        //messageLog.addAttachmentAsString("tpm_process_flow_message", flowInfo, "text/xml")
        messageLog.addAttachmentAsString("TPM_REQUEST_BODY:", body , "text/xml");
    }
    return inputMessage
}


