import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def properties = message.getProperties();
    
    //get Json result
    def jsonSlurper = new JsonSlurper();
    def apiResult = jsonSlurper.parse(body);
    
    // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    //get db Schema
    def db_schema = properties.get('Database_Schema_Name');
    
    def eventHasBids = '0';
    
    if (apiResult.payload && apiResult.payload.size() > 0 ) {
        eventHasBids = '1';
        sqlStatement.root {
            for (rfxEventItem in apiResult.payload) {
                
                //skip if is header items
                if (rfxEventItem.itemsWithBid && rfxEventItem.itemsWithBid.size() > 0) {
                    continue;
                }
                
                //valid item with Bid
                if (rfxEventItem.item && rfxEventItem.item.terms && rfxEventItem.item.terms.size() > 0) {
                    
                    //create a new list to avoid the duplicate terms in the API result
                    def termsList = new ArrayList<String>();
                    for (rfxEventItemTerm in rfxEventItem.item.terms) {
                        if (!termsList.contains(rfxEventItemTerm.fieldId)) {
                            termsList.add(rfxEventItemTerm.fieldId);
                            sqlStatement.UpdateStatement {
                                sqlStatement.app_sourcing_item_term_bid(action: 'UPDATE') {
                                    sqlStatement.table(db_schema + '.APP_SOURCING_ITEM_TERM_BID')
                                    sqlStatement.access {
                                        
                                        sqlStatement.BID_RANK(rfxEventItem.bidRank)
                                        sqlStatement.BID_TYPE(rfxEventItem.bidType)
                                        sqlStatement.TITLE(rfxEventItemTerm.title)
                                        sqlStatement.VALUE_TYPE_NAME(rfxEventItemTerm.valueTypeName)
                                        
                                        if ( (rfxEventItemTerm.valueTypeName == 'ShortText' || rfxEventItemTerm.valueTypeName == 'Text' 
                                                    || rfxEventItemTerm.valueTypeName == 'MultilineFreeText' || rfxEventItemTerm.valueTypeName == 'MasterDataType') 
                                                && rfxEventItemTerm.value && rfxEventItemTerm.value.simpleValue) {
                                            sqlStatement.VALUE_STRING(rfxEventItemTerm.value.simpleValue.size()>1000 ? rfxEventItemTerm.value.simpleValue.substring(0,1000) :  rfxEventItemTerm.value.simpleValue)
                                        }
                                        else if ((rfxEventItemTerm.valueTypeName == 'DecimalNumber' || rfxEventItemTerm.valueTypeName == 'Percentage') 
                                                    && rfxEventItemTerm.value) {
                                            sqlStatement.VALUE_AMOUNT(rfxEventItemTerm.value.bigDecimalValue)
                                        }
                                        else if (rfxEventItemTerm.valueTypeName == 'Money' &&  rfxEventItemTerm.value && rfxEventItemTerm.value.supplierValue) {
                                            sqlStatement.VALUE_AMOUNT(rfxEventItemTerm.value.supplierValue.amount)
                                            sqlStatement.VALUE_CURRENCY_CODE(rfxEventItemTerm.value.supplierValue.currency)
                                        }
                                        else if (rfxEventItemTerm.valueTypeName == 'Quantity' && rfxEventItemTerm.value && rfxEventItemTerm.value.quantityValue) {
                                            sqlStatement.VALUE_AMOUNT(rfxEventItemTerm.value.quantityValue.amount)
                                            sqlStatement.UM_NAME(rfxEventItemTerm.value.quantityValue.unitOfMeasureName)
                                            sqlStatement.UM_CODE(rfxEventItemTerm.value.quantityValue.unitOfMeasureCode)
                                        }
                                        else if (rfxEventItemTerm.valueTypeName == 'MoneyDifference' &&  rfxEventItemTerm.value && rfxEventItemTerm.value.moneyDifferenceValue
                                                && rfxEventItemTerm.value.moneyDifferenceValue.difference) {
                                            sqlStatement.VALUE_AMOUNT(rfxEventItemTerm.value.moneyDifferenceValue.difference.amount)
                                            sqlStatement.VALUE_CURRENCY_CODE(rfxEventItemTerm.value.moneyDifferenceValue.difference.currency)
                                        }
                                        
                                        
                                        sqlStatement.MODIFIEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                                        sqlStatement.MODIFIEDBY(properties.get('Extension_User'))
                                    }
                                    sqlStatement.key {
                                        sqlStatement.EVENT_ID(rfxEventItem.eventId)
                                        sqlStatement.ITEM_ID(rfxEventItem.itemId)
                                        sqlStatement.INVITATION_ID(rfxEventItem.invitationId)
                                        sqlStatement.BID_ALTERNATE_NAME(rfxEventItem.alternateBidName != null ? rfxEventItem.alternateBidName : ' ')
                                        
                                        sqlStatement.ITEM_TERM_ID(rfxEventItemTerm.fieldId)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        };
    }

    message.setProperty("eventHasBids", eventHasBids);
    
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //def eventId = message.getProperty('eventId')
    //messageLog.addAttachmentAsString('API Result bids - Event: '+ eventId, apiResult.toString(), 'text/plain');
    
    message.setBody(writer.toString());
  
    return message;
}