import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody();
    
    def headers = message.getHeaders();

    def properties = message.getProperties();
    
    def jsonSlurper = new JsonSlurper();
    def dbResult = jsonSlurper.parse(body);
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('Result SQL SELECT', dbResult.toString(), 'text/plain');
    
    def eventValidToUpdate = '0';
    def eventId = message.getProperty('eventId');
    
    if (dbResult && dbResult.SelectStatement_response && 
            dbResult.SelectStatement_response.row && dbResult.SelectStatement_response.row.size() > 0) {
        
        def strTimeUpdatedDB = '';
        //eventTimeUpdated
        def strTimeUpdatedApi = message.getProperty('eventTimeUpdated');
        
        if (dbResult.SelectStatement_response.row[0].BID_UPDATED) {
            strTimeUpdatedDB =  dbResult.SelectStatement_response.row[0].BID_UPDATED;
            
            def timeUpdateDB = Date.parse('yyyy-MM-dd hh:mm:SS', strTimeUpdatedDB);
            def timeUpdateApi = Date.parse('yyyy-MM-dd hh:mm:SS', strTimeUpdatedApi.replaceAll('Z', '').replaceAll('T', ' '));
            
            if (timeUpdateDB < timeUpdateApi ) {
                eventValidToUpdate = '1';
            }
        }
        else {
            //updated is null, update always
            eventValidToUpdate = '1';
        }
        
        
        //log Result
        //def messageLog = messageLogFactory.getMessageLog(message);
        //messageLog.addAttachmentAsString('resultRows-'+eventId, 'eventValid: ' +  eventValidToUpdate + '. timeDB: ' + strTimeUpdatedDB + '. timeApi: '+strTimeUpdatedApi, 'text/plain');
        
        
        //log Result
        //def messageLog = messageLogFactory.getMessageLog(message);
        //messageLog.addAttachmentAsString('resultRows-'+eventId, dbResult.toString(), 'text/plain');
    }
    /*else {
        //log Result
        def messageLog2 = messageLogFactory.getMessageLog(message);
        messageLog2.addAttachmentAsString('emptyRows-'+eventId, dbResult.toString(), 'text/plain');
    }*/
    
    message.setProperty("eventValidToUpdate", eventValidToUpdate);
    message.setProperty("eventId",  eventId);
    
    return message;
}