/*
 * =============================================================================
 * This Groovy script updates the `Coupa_offset` property by retrieving its current
 * value from the message, defaulting to 0 if not provided, and increments it by 50 
 * before setting it back as a property. The script also parses the message body 
 * (XML format) to check for the presence of a specific error message: 
 * 'No results match your search criteria.'. If the error is found, the `ObjectsPresent`
 * property is set to `false`, otherwise it is set to `true`, enabling further 
 * processing based on object availability.
 * =============================================================================
 */

import com.sap.gateway.ip.core.customdev.util.Message

def processData(Message message) {
    // Get the property value from the message and cast it to an integer
    def propertyValueString = message.getProperty("Coupa_offset")
    def propertyValue = propertyValueString ? propertyValueString.toInteger() : 0 // Convert to integer, default to 0 if null or empty
    
    // Add 50 to the Coupa_offset
    propertyValue += 50

    // Set the modified offset value back to the message
    message.setProperty("Coupa_offset", propertyValue.toString()) // Convert back to string for setting property

    // Parse the body of the message
    def body = message.getBody(java.lang.String)
    def slurper = new groovy.util.XmlSlurper().parseText(body)

    // Check if the specific error message is present in the body
    def errorPresent = slurper.depthFirst().find { it.name() == 'error' && it.text() == 'No results match your search criteria.' } != null

    // Set the CountObjects property based on the presence of the error message
    message.setProperty("ResourcesPresent", !errorPresent)

    return message
}
