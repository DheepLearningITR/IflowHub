/*
 * =============================================================================
 * This Groovy script processes the `CoupaResource` property from the message and
 * checks if it contains specific object types, such as `requisition_lines`, 
 * `purchase_order_lines`, `receiving_transaction_lines`, or `invoice_lines`. 
 * Depending on the match, the script updates the `CoupaResource` to its parent 
 * object (e.g., `requisitions`, `purchase_orders`, etc.) and sets the `CoupaResourceLine`
 * property to `true`. This allows to set the correct Coupa Resource name while querying  
 * =============================================================================
 */

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    			
        def properties = message.getProperties();
		def CoupaResource = properties.get("CoupaResource");
	//	def CoupaResourceLine = properties.get("CoupaResourceLine");
		
	
	if(CoupaResource.toString().contains("requisition_lines"))
                            {
                                message.setProperty("CoupaResource", "requisitions");
                                message.setProperty("CoupaResourceLine", "true");
                            }
	
	
	if(CoupaResource.toString().contains("purchase_order_lines"))
                            {
                                message.setProperty("CoupaResource", "purchase_orders");
                                message.setProperty("CoupaResourceLine", "true");
                            }	
                            
                            
	if(CoupaResource.toString().contains("receiving_transaction_lines"))
                            {
                                message.setProperty("CoupaResource", "receiving_transactions");
                                message.setProperty("CoupaResourceLine", "true");
                            }
    if(CoupaResource.toString().contains("invoice_lines"))
                            {
                                message.setProperty("CoupaResource", "invoices");
                                message.setProperty("CoupaResourceLine", "true");
                            }                            
    return message;
}