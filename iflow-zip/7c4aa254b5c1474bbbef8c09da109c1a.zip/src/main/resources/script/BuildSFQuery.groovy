/*
 * =============================================================================
 * Logic Details 
 * =============================================================================
 *   The Groovy script dynamically generates a `ModifiedDate` and `LoadType` based on specific properties provided in the SAP message. The main function, `processData`, retrieves properties such as `Adhoc_StartDate (3)`, `ExecuteFullLoad (1)`, `last_run (4)`, and `PreDefinedStartDate (2)` from the message.
 * 
 *   The `LoadType` is determined by checking the `ExecuteFullLoad` property:
 *   - If `ExecuteFullLoad` is true, the `LoadType` is set to "FullLoad".
 *   - Otherwise, the `LoadType` is set to "DeltaLoad".
 * 
 *   For `ModifiedDate`, the script determines the value based on the following priority:
 *   1. If `PreDefinedStartDate` is present, it is used as the `ModifiedDate`.
 *   2. If `Adhoc_StartDate` is present but `PreDefinedStartDate` is not, `Adhoc_StartDate` is used as the `ModifiedDate`.
 *   3. If neither `PreDefinedStartDate` nor `Adhoc_StartDate` is provided, the `ModifiedDate` is used as the `last_run`).
 * 
 *   The script does not generate a `WHERE` clause, but it sets the `ModifiedDate` and `LoadType` as properties on the message.
 * 
 *   These properties can then be used in further logic or queries, depending on the integration scenario.
 * 
 *   The priorities of the conditional statements are noted in parentheses next to the property names for clarity.
 * =============================================================================
 */
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def properties = message.getProperties();
    def Adhoc_StartDate = properties.get("Adhoc_StartDate");
    def ExecuteFullLoad = properties.get("ExecuteFullLoad");
    def LastRun = properties.get("last_run");
    def PreDefinedStartDate = properties.get("PreDefinedStartDate");
    def LoadType = "";
    def ModifiedDate = "";

    // Trim and validate dates to avoid issues with blank spaces or null values
    Adhoc_StartDate = (Adhoc_StartDate != null && !Adhoc_StartDate.trim().isEmpty()) ? Adhoc_StartDate.trim() : null;
    PreDefinedStartDate = (PreDefinedStartDate != null && !PreDefinedStartDate.trim().isEmpty()) ? PreDefinedStartDate.trim() : null;
    LastRun = (LastRun != null && !LastRun.trim().isEmpty()) ? LastRun.trim() : null;
    
    if (ExecuteFullLoad != null && ExecuteFullLoad.equalsIgnoreCase("TRUE")) {
        LoadType = "FullLoad";
    } else {
        LoadType = "DeltaLoad";

        // Prioritize PreDefinedStartDate over Adhoc_StartDate
        if (PreDefinedStartDate != null) {
            ModifiedDate = PreDefinedStartDate;
        } else if (Adhoc_StartDate != null) {
            ModifiedDate = Adhoc_StartDate;
        } else {
            ModifiedDate = LastRun; // Use default LastRun if no other dates are set
        }
    }

    // Set the properties in the message
    message.setProperty("ModifiedDate", ModifiedDate);
    message.setProperty("LoadType", LoadType);

    return message;
}