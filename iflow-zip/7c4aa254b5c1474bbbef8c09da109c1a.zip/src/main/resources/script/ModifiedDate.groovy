/*
 * =============================================================================
 * This Groovy script dynamically sets the `LoadType` and `ModifiedDate` properties 
 * based on input properties from the message. If `ExecuteFullLoad` is `TRUE`, the 
 * `LoadType` is set to `FullLoad`; otherwise, it defaults to `DeltaLoad`. For 
 * the `ModifiedDate`, the script prioritizes `PreDefinedStartDate`, then checks 
 * `Adhoc_StartDate`, and finally defaults to `LastRun` if neither of the other 
 * dates are provided.These properties (`ModifiedDate` and `LoadType`) are 
 * then set in the message for further processing.
 * =============================================================================
 */
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def properties = message.getProperties();
    def Adhoc_StartDate = properties.get("Adhoc_StartDate");
    def ExecuteFullLoad = properties.get("ExecuteFullLoad");
    def LastRun = properties.get("last_run");
    def PreDefinedStartDate = properties.get("PreDefinedStartDate");
    def LoadType = "";
    def ModifiedDate = "";

    // Trim and validate dates to avoid issues with blank spaces or null values
    Adhoc_StartDate = (Adhoc_StartDate != null && !Adhoc_StartDate.trim().isEmpty()) ? Adhoc_StartDate.trim() : null;
    PreDefinedStartDate = (PreDefinedStartDate != null && !PreDefinedStartDate.trim().isEmpty()) ? PreDefinedStartDate.trim() : null;
    LastRun = (LastRun != null && !LastRun.trim().isEmpty()) ? LastRun.trim() : null;
    
    if (ExecuteFullLoad != null && ExecuteFullLoad.equalsIgnoreCase("TRUE")) {
        LoadType = "FullLoad";
    } else {
        LoadType = "DeltaLoad";

        // Prioritize PreDefinedStartDate over Adhoc_StartDate
        if (PreDefinedStartDate != null) {
            ModifiedDate = PreDefinedStartDate;
        } else if (Adhoc_StartDate != null) {
            ModifiedDate = Adhoc_StartDate;
        } else {
            ModifiedDate = LastRun; // Use default LastRun if no other dates are set
        }
    }

    // Set the properties in the message
    message.setProperty("ModifiedDate", ModifiedDate);
    message.setProperty("LoadType", LoadType);

    return message;
}