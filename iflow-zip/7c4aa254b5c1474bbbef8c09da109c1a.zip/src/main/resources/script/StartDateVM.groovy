import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi


def Message processData(Message message) 
{
    //Properties
    def properties = message.getProperties();
    def CoupaResource = properties.get("CoupaResource");
    
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def value = valueMapApi.getMappedValue('Coupa', 'ResourceName', CoupaResource, 'Signavio', 'StartDate')
    message.setProperty("PreDefinedStartDate", value );

    
    return message;
}