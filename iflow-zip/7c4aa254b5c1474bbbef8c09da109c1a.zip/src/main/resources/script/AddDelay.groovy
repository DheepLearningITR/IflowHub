import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) 
{

    def properties = message.getProperties();
    def LoadType = properties.get("LoadType");
    def InitialLoad_Delay = properties.get("InitialLoad_Delay") as Integer

    if (LoadType == "FullLoad" || LoadType == "AdhocStartDate_DeltaLoad" || LoadType == "PredefinedStartDate_DeltaLoad")
    {
        Thread.sleep(InitialLoad_Delay)
    }

    return message;
}