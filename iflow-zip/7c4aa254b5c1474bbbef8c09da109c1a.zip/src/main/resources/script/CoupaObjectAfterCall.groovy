/*
 * =============================================================================
 * This Groovy script checks the `CoupaResource` and `CoupaResourceLine` properties 
 * from the message. If the `CoupaResourceLine` property is set to `true` and the 
 * `CoupaResource` matches specific values (e.g., `requisitions`, `purchase_orders`, 
 * `receiving_transactions`, or `invoices`), the script updates `CoupaResource` 
 * to refer to the corresponding line items (e.g., `requisition_lines`, 
 * `purchase_order_lines`, etc.). This transformation helps to set the Coupa Resource
 * name correctly for all line items. 
 * =============================================================================
 */

import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    
    			
        def properties = message.getProperties();
		def CoupaResource = properties.get("CoupaResource");
		def CoupaResourceLine = properties.get("CoupaResourceLine");
		
	
	if(CoupaResource.toString().contains("requisitions") && CoupaResourceLine.toString().contains("true"))
                            {
                                message.setProperty("CoupaResource", "requisition_lines");
                        
                            }
                            
   	if(CoupaResource.toString().contains("purchase_orders") && CoupaResourceLine.toString().contains("true"))
                            {
                                message.setProperty("CoupaResource", "purchase_order_lines");
                             
                            }                         
	if(CoupaResource.toString().contains("receiving_transactions") && CoupaResourceLine.toString().contains("true"))
                            {
                                message.setProperty("CoupaResource", "receiving_transaction_lines");
                             
                            } 	
    if(CoupaResource.toString().contains("invoices") && CoupaResourceLine.toString().contains("true"))
                            {
                                message.setProperty("CoupaResource", "invoice_lines");
                             
                            } 	                        
	
    return message;
}
