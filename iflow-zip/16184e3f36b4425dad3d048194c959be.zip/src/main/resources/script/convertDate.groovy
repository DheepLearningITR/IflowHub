import com.sap.it.api.mapping.*;


def String convertDateToS4Format(String arg1){
    String dateBeforeFormat = arg1.substring(0, arg1.lastIndexOf("T"));
    Date date = Date.parse('yyyy-MM-dd', dateBeforeFormat);
    String formattedDate = date.format("yyyyMMdd");
    return formattedDate;        
}