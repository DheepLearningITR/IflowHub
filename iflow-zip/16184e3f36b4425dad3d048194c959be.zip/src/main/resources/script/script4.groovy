import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import groovy.transform.Synchronized
import com.sap.it.api.asdk.datastore.*
import com.sap.it.api.asdk.runtime.*

    @Synchronized
	def Message processData(Message message) {
		//Body 
		def body = message.getBody() as String;
		map = message.getProperties();
		def orderId = map.get("orderId");


		def returnrecords = new XmlSlurper().parseText(body);
        
        returnrecords.value.each {line ->
			
			def service = new Factory(DataStoreService.class).getService()

			if (service != null) {
				def dsEntry = service.get("upscale_return", orderId + '_' +line.itemCode+'_'+line.createdAt);
				if (dsEntry == null) {
					def payload = "<?xml version='1.0' encoding='UTF-8'?><savedreturnrecords><id>" + orderId + '_' +line.itemCode+'_'+line.createdAt + "</id><status>received</status></savedreturnrecords>"

					def dBean = new DataBean()
					dBean.setDataAsArray(payload.getBytes("UTF-8"))

					//Define datatore name and entry id
					def dConfig = new DataConfig()
					dConfig.setStoreName("upscale_return")
					dConfig.setId(orderId + '_' +line.itemCode+'_'+line.createdAt)

					//Write to data store
					result = service.put(dBean, dConfig)
					
					return message;
				} else {
					def result = new String(dsEntry.getDataAsArray())
					if (result == null || result.isEmpty()) {
    					def payload = "<?xml version='1.0' encoding='UTF-8'?><savedreturnrecords><id>" + orderId + '_' +line.itemCode+'_'+line.createdAt + "</id><status>received</status></savedreturnrecords>"
    
    					def dBean = new DataBean()
    					dBean.setDataAsArray(payload.getBytes("UTF-8"))
    
    					//Define datatore name and entry id
    					def dConfig = new DataConfig()
    					dConfig.setStoreName("upscale_return")
    					dConfig.setId(orderId + '_' +line.itemCode+'_'+line.createdAt)
    
    					//Write to data store
    					result = service.put(dBean, dConfig)
    					
    					return message;
				
					} else {
						
						    line.replaceNode {};
                        
					}

				}

			}

		}

		message.setBody(XmlUtil.serialize(returnrecords));
		return message;


	}