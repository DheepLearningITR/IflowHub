import com.sap.it.api.mapping.*;



def String getProperty(String p1, MappingContext context) {
    
         return context.getProperty(p1);
        
}


