importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function checkChangesNeeded(message) {
	
	var map = message.getProperties();
    var iDocMapped = map.get("iDocMapped");
    if(!iDocMapped){
    	return message;
    }
    iDocMapped = JSON.parse(iDocMapped);
    
	var existingCustomer = JSON.parse(map.get("existingCustomerResponse"))[0];
	
	map.put("changesNeeded", changesNeeded(iDocMapped, existingCustomer));
	
	return message;
}

changesNeeded = function(json1, json2){
	var excludedObjects=["iDoc_DEBMAS", "iDoc_ADRMAS"];
	for(var i in json1){
	
		var excludedObject = false;
		for(var a in excludedObjects){
			if(excludedObjects[a] === i){
				excludedObject = true;
				break;
			}
		}
		
		if(!excludedObject && typeof(json1[i]) === "string"){
			if(json1[i] !== json2[i]){
				return true;
			}
		}
		else if (!excludedObject){
			return changesNeeded(json1[i], json2[i]);
		}
	}
	return false;
}