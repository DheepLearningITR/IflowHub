importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
	
	var map = message.getProperties();
    var iDocMapped = map.get("iDocMapped");
    if(!iDocMapped){
    	return message;
    }
    iDocMapped = JSON.parse(iDocMapped);
    
	var iDoc = JSON.parse(message.getBody().toString());
	iDocMapped.mixins.iDoc_DEBMAS.E1KNA1M = {};
    copy(iDocMapped.mixins.iDoc_DEBMAS.E1KNA1M, iDoc.DEBMAS06.IDOC.E1KNA1M);
	
	//message.setProperty("iDocMapped", iDocMapped);

	message.setBody(JSON.stringify(iDocMapped));
	return message;
}

function copy(json1, json2){
	
	var arrayType = {"E1KNVVL": true, "E1KNB1L": true, "E1KNVKL": true, "E1KNKKL": true, "E1KNA1L": true, "E1KNVPM": true, "E1KNVDM": true, "E1KNVIM": true, "E1KNVLM": true, "E1KNVVH": true, "E1KNBWM": true, "E1KNB5M": true, "E1KNB1H": true, "E1KNVKH": true, "E1KNKKH": true, "E1KNA1H": true, "E1KNVVM": true, "E1KNB1M": true, "E1KNBKM": true, "E1KNVAM": true, "E1WRF12": true, "E1WRF4M": true, "E1KNVKM": true, "E1KNEXM": true, "E1KNASM": true, "E1KNKKM": true, "E1VCKUN": true, "E1WRF1M": true, "E1WRF3M": true, "E1WRF5M": true, "E1WRF6M": true, "E1T023W": true, "E1T023X": true}; 
	var json = json1;
	for(var i in json2){
		if(i === "@SEGMENT"){
			
		}
		else if(typeof json2[i] === "string"){
			json1[i.toLowerCase()] = json2[i];
		}
		else if(typeof json2[i] === "object"){
			if (arrayType[i]){ //handle arrays
				if(json2[i].length){
					json1[i] = copy([], json2[i]); //copy array into array
				}
				else{
					json1[i] = [copy({}, json2[i])]; //copy json into array
				}
			}
			else{
				json1[i] = copy({}, json2[i]); //copy json into json
			}
		}
	}
	return json;
}