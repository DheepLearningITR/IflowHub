import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {

    if (!message.getHeader("CamelHttpResponseCode", String).startsWith("2")) {
        message.setProperty("ErrorType","S4Error")
        throw new Exception("The integration flow message won’t be processed further due to an error returned by the SAP S4HANA while updating the Object. For error details, see the batch response body in the error log attachments.");
    }
    def body = message.getBody(java.lang.String) as String;
    if(body){
        def parsedBody = new XmlSlurper().parseText(body)

        // Extract the ETag from the <entry> element
        def etag = parsedBody?.batchChangeSetResponse?.batchChangeSetPartResponse?.headers?.etag.text()
        
        // Set If-Match header
        if (etag) {
            message.setProperty("If-Match", etag)
        }
    }

   return message;
}


