import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def sourcePayload = body
    def parser = new JsonSlurper()
    def parserResult = parser.parseText(body)
    
    def eventType = message.getHeaders().get("eventType") ?: ''
    message.setProperty("eventType", eventType)
    def contact = parserResult.data.contact
    
    def isAddressPresent = false
    def isAssociatedBPpresent = false
    
    if(contact.addresses[0] && contact.addresses[0].id){
       isAddressPresent = true
    }
    if(contact.object != null){
       isAssociatedBPpresent = true
    }
    
    message.setProperty("isAddressPresent",isAddressPresent)
    message.setProperty("isAssociatedBPpresent",isAssociatedBPpresent)
    
    return message;
}