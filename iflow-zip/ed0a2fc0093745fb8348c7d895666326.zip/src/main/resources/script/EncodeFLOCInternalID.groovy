import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    
	def value = "?" + message.getProperties().get("S4ID");
	String encodedUrl = URLEncoder.encode(value, "UTF-8");

	message.setProperty("FLID", encodedUrl)

	return message;
}