import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper


def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def sourcePayload = body
    def parser = new JsonSlurper()
    def parserResult = parser.parseText(body)
    
    def eventType = parserResult?.eventType as String ?: ''
    message.setProperty("eventType", eventType)
    def equipment = parserResult.data.equipment
    
    def FSMID = equipment.id as String ?: ''
    def FSMcode = equipment.code as String ?: ''
    def S4ID = equipment.externalId as String ?: 'NA'
    message.setProperty("S4ID",S4ID)
    def ObjectCategory = equipment?.objectCategory as String ?: ''
    message.setProperty("ObjectCategory",ObjectCategory);


    if(FSMID) {
        message.setProperty("FSMID", FSMID)
        message.setProperty("FSMcode",FSMcode)
        if (S4ID && ObjectCategory == 'FLOC') {
            message.setProperty("S4FLOC_ID", S4ID)
        }else if (S4ID && ObjectCategory == 'EQ') {
            message.setProperty("S4EQ_ID", S4ID)
        }
    }   
    
    def parentId = equipment?.parentId?.externalId as String ?: ''
    message.setProperty("parentID",parentId)
    
    return message;
}