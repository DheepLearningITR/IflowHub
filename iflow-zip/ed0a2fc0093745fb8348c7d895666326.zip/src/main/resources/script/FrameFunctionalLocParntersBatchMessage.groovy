import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser
import groovy.xml.XmlUtil

def Message processData(Message message) {
    //this script is to frame the Functional Location Partner update or create batch payload
    def body = message.getBody(java.lang.String) as String;
    def XmlParser = new XmlParser()
    def S4HFunctionalMsg = XmlParser.parseText(body)
    def BPPartnerMsg = ""
	def ContactMsg = ""


    //Parse FunctionalLocation Source Message
    def map = message.getProperties()
    def functionalLocID = map.get("FLID")//S4HFunctionalMsg?.FunctionalLocationType?.FunctionalLocation?.text()
    def rawfunctionalLocID = S4HFunctionalMsg?.FunctionalLocationType?.FunctionalLocation?.text()
    equipmentSrc = XmlParser.parseText(map.get("OriginalPayload"))
    def BusinessPartner = equipmentSrc?.data?.equipment?.businessPartner?.externalId.text()
    def etag = map.get("If-Match")

	def contactID = equipmentSrc?.data?.equipment?.contact?.externalId.text()

    // Find the FunctionalLocationPartnerType node with PartnerFunction == "AG"
    def agPartner = S4HFunctionalMsg?.FunctionalLocationType?.to_Partner?.FunctionalLocationPartnerType.find { 
        it.PartnerFunction.text() == 'AG' 
    }

    // Frame AG batchpart
    if (agPartner) {
        BPPartnerMsg = "<batchChangeSetPart>" +
                   "<method>PATCH</method>" +
                   "<uri>FunctionalLocationPartner(FunctionalLocation='" + functionalLocID + "',PartnerFunction='" + agPartner.PartnerFunction.text() + "',FuncnlLocPartnerObjectNmbr='" + agPartner.FuncnlLocPartnerObjectNmbr.text() + "')</uri>" +
                   "<FunctionalLocationPartner>" +
                   "<FunctionalLocationPartnerType>" +
                   "<FunctionalLocation>" + rawfunctionalLocID + "</FunctionalLocation>" +
                   "<PartnerFunction>AG</PartnerFunction>" +
                   "<FuncnlLocPartnerObjectNmbr>"+ agPartner.FuncnlLocPartnerObjectNmbr.text() +"</FuncnlLocPartnerObjectNmbr>" +
                   "<Partner>" + BusinessPartner + "</Partner>" +
                   "</FunctionalLocationPartnerType>" +
                   "</FunctionalLocationPartner>" +
                   "</batchChangeSetPart>"
    } else {
        BPPartnerMsg = "<batchChangeSetPart>" +
                   "<method>POST</method>" +
                   "<uri>FunctionalLocationPartner</uri>" +
                   "<FunctionalLocationPartner>" +
                   "<FunctionalLocationPartnerType>" +
                   "<FunctionalLocation>" + rawfunctionalLocID + "</FunctionalLocation>" +
                   "<PartnerFunction>AG</PartnerFunction>" +
                   "<FuncnlLocPartnerObjectNmbr>1</FuncnlLocPartnerObjectNmbr>" +
                   "<Partner>" + BusinessPartner + "</Partner>" +
                   "</FunctionalLocationPartnerType>" +
                   "</FunctionalLocationPartner>" +
                   "</batchChangeSetPart>"
    }

    //Frame Contact batchpart if enabled
    def EquipmentContactPartnerFunction = map.get("EquipmentContactPartnerFunction")

    if (EquipmentContactPartnerFunction){
        def cpPartner = S4HFunctionalMsg?.FunctionalLocationType?.to_Partner?.FunctionalLocationPartnerType.find { 
            it.PartnerFunction.text() == EquipmentContactPartnerFunction 
        }

        //Frame Contact BatchPart
		if (cpPartner) {
			ContactMsg = "<batchChangeSetPart>" +
					"<method>PATCH</method>" +
					"<uri>FunctionalLocationPartner(FunctionalLocation='" + functionalLocID + "',PartnerFunction='" + cpPartner.PartnerFunction.text() + "',FuncnlLocPartnerObjectNmbr='" + cpPartner.FuncnlLocPartnerObjectNmbr.text() + "')</uri>" +
					"<FunctionalLocationPartner>" +
					"<FunctionalLocationPartnerType>" +
                   "<FunctionalLocation>" + rawfunctionalLocID + "</FunctionalLocation>" +
                   "<PartnerFunction>AG</PartnerFunction>" +
                   "<FuncnlLocPartnerObjectNmbr>"+ cpPartner.FuncnlLocPartnerObjectNmbr.text() +"</FuncnlLocPartnerObjectNmbr>" +
					"<Partner>" + contactID + "</Partner>" +
					"</FunctionalLocationPartnerType>" +
					"</FunctionalLocationPartner>" +
					"</batchChangeSetPart>"
		} else {
			ContactMsg = "<batchChangeSetPart>" +
					"<method>POST</method>" +
					"<uri>FunctionalLocationPartner</uri>" +
					"<FunctionalLocationPartner>" +
					"<FunctionalLocationPartnerType>" +
					"<FunctionalLocation>" + rawfunctionalLocID + "</FunctionalLocation>" +
					"<PartnerFunction>" + EquipmentContactPartnerFunction + "</PartnerFunction>" +
					"<FuncnlLocPartnerObjectNmbr>1</FuncnlLocPartnerObjectNmbr>" +
					"<Partner>" + contactID + "</Partner>" +
					"</FunctionalLocationPartnerType>" +
					"</FunctionalLocationPartner>" +
					"</batchChangeSetPart>"
		}
    }

    def batchbody = "<batchParts><batchChangeSet>" + BPPartnerMsg + ContactMsg + "</batchChangeSet></batchParts>"
    
    if (BPPartnerMsg || ContactMsg){
        message.setProperty("FunctionalLocationPartnersExists","Yes")
        message.setBody(XmlUtil.serialize(batchbody))
    }else{
        message.setProperty("FunctionalLocationPartnersExists","No")
    }

 
    message.setHeader("Content-Type",'multipart/mixed')
    
 return message
}
   