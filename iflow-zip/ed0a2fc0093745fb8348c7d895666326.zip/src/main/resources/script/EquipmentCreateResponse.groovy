import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {

    if (!message.getHeader("CamelHttpResponseCode", String).startsWith("2")) {
        throw new Exception("The integration flow message won’t be processed further due to an error returned by SAP S4HANA while creating the object. For error details, see the batch response body in the error log attachments.");
    }
    
    def body = message.getBody(java.lang.String);
    def responsexml = new XmlSlurper().parseText(body);
    message.setProperty("S4ID",responsexml.FunctionalLocationType.FunctionalLocation.text().replaceAll(/\?/, ""))

   return message;
}