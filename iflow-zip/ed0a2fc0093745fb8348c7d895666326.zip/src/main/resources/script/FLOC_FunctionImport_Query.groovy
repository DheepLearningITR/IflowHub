import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser
import groovy.xml.XmlUtil

def Message processData(Message message) {
    //this script is to frame the equipment installation and dismantling queries
    def map = message.getProperties()
    def XmlParser = new XmlParser()
    def S4FLMsg = map.get("p_FLOCS4Message") as String;
    def parentObjectCategory = map.get("parentObjectCategory") as String;
    def parentCode = map.get("parentCode") as String;
    def parentID = map.get("parentID") as String;
    def S4FLParseMsg = XmlParser.parseText(S4FLMsg)
    def FLOCID = S4FLParseMsg?.FunctionalLocationType?.FunctionalLocation.text()
    def FLOCIDencoded = URLEncoder.encode(FLOCID, "UTF-8")

    String dismantleQuery = ''
    String installationQuery = ''

    if (S4FLParseMsg?.FunctionalLocationType?.FunctionalLocation.text() || S4FLParseMsg?.FunctionalLocationType?.SuperiorFunctionalLocation.text()){
        dismantleQuery = """FunctionalLocation='${FLOCIDencoded}'"""
    }   
    message.setProperty("dismantleQuery",dismantleQuery)

    if (parentObjectCategory == 'FLOC'){
        installationQuery= """FunctionalLocation='${FLOCIDencoded}'&SuperiorFunctionalLocation='${parentCode}'"""
    }
    message.setProperty("installationQuery",installationQuery)

 return message
}