import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser

def Message processData(Message message) {
    //this script is to frame the equipment installation and dismantling queries
    def map = message.getProperties()
    def XmlParser = new XmlParser()
    def S4equipmentMsg = map.get("p_EquipmentS4Message") as String;
    def parentObjectCategory = map.get("parentObjectCategory") as String;
    def parentCode = map.get("parentCode") as String;
    def parentID = map.get("parentID") as String;
    def S4equipmentParseMsg = XmlParser.parseText(S4equipmentMsg)
    def equipmentID = S4equipmentParseMsg?.EquipmentType?.Equipment.text()

    String dismantleQuery = ''
    String installationQuery = ''

    if (S4equipmentParseMsg?.EquipmentType?.FunctionalLocation.text() || S4equipmentParseMsg?.EquipmentType?.SuperordinateEquipment.text()){
        dismantleQuery = """Equipment='${equipmentID}'&ValidityEndDate=datetime'9999-12-31T00:00:00'"""
        //dismantleQuery = URLEncoder.encode(dismantleQuery, "UTF-8")
    }
    message.setProperty("dismantleQuery",dismantleQuery)
    

    if (parentObjectCategory == 'EQ'){
        installationQuery= """Equipment='${equipmentID}'&ValidityEndDate=datetime'9999-12-31T00:00:00'&SuperordinateEquipment='${parentID}'"""
        //installationQuery = URLEncoder.encode(installationQuery, "UTF-8")
    }else if (parentObjectCategory == 'FLOC'){
        installationQuery= """Equipment='${equipmentID}'&ValidityEndDate=datetime'9999-12-31T00:00:00'&FunctionalLocation='${parentCode}'"""
        //installationQuery = URLEncoder.encode(installationQuery, "UTF-8")
    }
    message.setProperty("installationQuery",installationQuery)

 return message
}
   
