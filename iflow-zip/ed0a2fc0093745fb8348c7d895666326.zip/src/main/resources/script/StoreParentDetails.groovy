import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper

def Message processData(Message message) {
    //this script is to read the Parent object type
    def body = message.getBody(java.lang.String) as String
    def jsonSlurper = new JsonSlurper()
    def parentData = jsonSlurper.parseText(body)
    def parentType = parentData?.data[0]?.equipment?.objectCategory as String ?: 'EQ'
    def parentName = parentData?.data[0]?.equipment?.name as String ?: ''
    def parentCode = parentData?.data[0]?.equipment?.code as String ?: ''

    message.setProperty("parentObjectCategory",parentType)
    message.setProperty("parentName",parentName)
    message.setProperty("parentCode",parentCode)

       
    return message;
}
