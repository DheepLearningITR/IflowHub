import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    //this script is to merge the address data into equipment message
    def body = message.getBody(java.lang.String) as String
    def jsonSlurper = new JsonSlurper()
    def addressData = jsonSlurper.parseText(body)

    def map = message.getProperties()
    def equipmentSrc = map.get("OriginalEquipmentPayload")
    def equipmentData = jsonSlurper.parseText(equipmentSrc)
    
    // Extract the equipment object
    def equipment = equipmentData?.data.equipment

    // Initialize address list if not present
    if (!equipment.containsKey("addresses")) {
        equipment["addresses"] = []
    }

    // Loop through the addresses in address payload
    addressData.data.each { addressEntry ->
        def address = addressEntry.address
        // Check if the address belongs to the equipment by matching objectId
        if (address.object.objectId == equipment.id) {
            // Append the entire address object to the addresses list
            equipment.addresses << address
        }
    }

    // Convert back to JSON and print result
    def updatedEquipmentJson = JsonOutput.prettyPrint(JsonOutput.toJson(equipmentData))
    message.setBody(updatedEquipmentJson)
    message.setProperty("MergedEquipmentPayload",updatedEquipmentJson)

       
    return message;
}