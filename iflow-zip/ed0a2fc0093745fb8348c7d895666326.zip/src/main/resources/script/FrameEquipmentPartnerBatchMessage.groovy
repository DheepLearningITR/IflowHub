import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser
import groovy.xml.XmlUtil

def Message processData(Message message) {
    //this script is to frame the Equipment Partner update or create batch payload
    def body = message.getBody(java.lang.String) as String;
    def XmlParser = new XmlParser()
    def S4HEquipmentMsg = XmlParser.parseText(body)
    def equipmentID = S4HEquipmentMsg?.EquipmentType?.Equipment?.text()
    def BPPartnerMsg = ""
	def ContactMsg = ""


    //Parse Equipment Source Message
    def map = message.getProperties()
    equipmentSrc = XmlParser.parseText(map.get("OriginalPayload"))
    def BusinessPartner = equipmentSrc?.data?.equipment?.businessPartner?.externalId.text()

	def contactID = equipmentSrc?.data?.equipment?.contact?.externalId.text()

    // Find the EquipmentPartnerType node with PartnerFunction == "AG"
    def agPartner = S4HEquipmentMsg?.EquipmentType?.to_Partner?.EquipmentPartnerType.find { 
        it.PartnerFunction.text() == 'AG' 
    }

    // Frame AG batchpart
    if (BusinessPartner) {
        if (agPartner) {
            BPPartnerMsg = "<batchChangeSetPart>" +
                       "<method>PATCH</method>" +
                       "<uri>EquipmentPartner(Equipment='" + equipmentID + "',PartnerFunction='" + agPartner.PartnerFunction.text() + "',EquipmentPartnerObjectNmbr='" + agPartner.EquipmentPartnerObjectNmbr.text() + "')</uri>" +
                       "<EquipmentPartner>" +
                       "<EquipmentPartnerType>" +
                       "<Partner>" + BusinessPartner + "</Partner>" +
                       "</EquipmentPartnerType>" +
                       "</EquipmentPartner>" +
                       "</batchChangeSetPart>"
        } else {
            BPPartnerMsg = "<batchChangeSetPart>" +
                       "<method>POST</method>" +
                       "<uri>EquipmentPartner</uri>" +
                       "<EquipmentPartner>" +
                       "<EquipmentPartnerType>" +
                       "<Equipment>" + equipmentID + "</Equipment>" +
                       "<PartnerFunction>AG</PartnerFunction>" +
                       "<EquipmentPartnerObjectNmbr>0</EquipmentPartnerObjectNmbr>" +
                       "<Partner>" + BusinessPartner + "</Partner>" +
                       "</EquipmentPartnerType>" +
                       "</EquipmentPartner>" +
                       "</batchChangeSetPart>"
        }
    }

    //Frame Contact batchpart if enabled
    def EquipmentContactPartnerFunction = map.get("EquipmentContactPartnerFunction")

    if (EquipmentContactPartnerFunction && contactID){
        def cpPartner = S4HEquipmentMsg?.EquipmentType?.to_Partner?.EquipmentPartnerType.find { 
            it.PartnerFunction.text() == EquipmentContactPartnerFunction 
        }

        //Frame Contact BatchPart
		if (contactID) {
		       ContactMsg = "<batchChangeSetPart>" +
		   			"<method>PATCH</method>" +
		   			"<uri>EquipmentPartner(Equipment='" + equipmentID + "',PartnerFunction='" + cpPartner.PartnerFunction.text() + "',EquipmentPartnerObjectNmbr='" + cpPartne.EquipmentPartnerObjectNmbr.text() + "')</uri>" +
		   			"<EquipmentPartner>" +
		   			"<EquipmentPartnerType>" +
		   			"<Partner>" + contactID + "</Partner>" +
		   			"</EquipmentPartnerType>" +
		   			"</EquipmentPartner>" +
		   			"</batchChangeSetPart>"
		   } else {
		   	ContactMsg = "<batchChangeSetPart>" +
		   			"<method>POST</method>" +
		   			"<uri>EquipmentPartner</uri>" +
		   			"<EquipmentPartner>" +
		   			"<EquipmentPartnerType>" +
		   			"<Equipment>" + equipmentID + "</Equipment>" +
		   			"<PartnerFunction>" + EquipmentContactPartnerFunction + "</PartnerFunction>" +
		   			"<EquipmentPartnerObjectNmbr>0</EquipmentPartnerObjectNmbr>" +
		   			"<Partner>" + contactID + "</Partner>" +
		   			"</EquipmentPartnerType>" +
		   			"</EquipmentPartner>" +
		   			"</batchChangeSetPart>"
		   }
    }

    def batchbody = "<batchParts><batchChangeSet>" + BPPartnerMsg + ContactMsg + "</batchChangeSet></batchParts>"
    
    if (BPPartnerMsg || ContactMsg){
        message.setProperty("EquipmentPartnersExists","Yes")
        message.setBody(XmlUtil.serialize(batchbody))
    }else{
        message.setProperty("EquipmentPartnersExists","No")
    }

 
    message.setHeader("Content-Type",'multipart/mixed')
    
 return message
}
   