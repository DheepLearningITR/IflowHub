import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def parsedBody = new XmlSlurper().parseText(body)

    // Extract the ETag from the <entry> element
    def etag = parsedBody.entry.'@etag'.text()
    //def S4FLID = parsedBody.entry.content.properties.FunctionalLocation.text()
    //def encodedS4FLID = URLEncoder.encode(S4FLID, "UTF-8");
    
    //message.setProperty("S4FLID",encodedS4FLID)
    
    // Set If-Match header
    if (etag) {
        message.setProperty("If-Match", etag)
    }

    return message;
}