import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    //Body 
       def body = message.getBody();
       message.setBody(body + "Body is modified");
       //Headers 
       def header = message.getHeaders();
       //Properties 
       def properties = message.getProperties();
       

def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null)
	{
	    messageLog.addAttachmentAsString("Body Log2:", body, "text/plain");
	     messageLog.addAttachmentAsString("headers Log2:", header.toString(), "text/plain");
	      messageLog.addAttachmentAsString("properties Log2:", properties.toString(), "text/plain");
     } 
     
       return message;
}

