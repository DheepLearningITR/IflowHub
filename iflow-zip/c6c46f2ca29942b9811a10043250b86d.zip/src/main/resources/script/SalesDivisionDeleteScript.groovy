import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	
    String completePayload = "";
  
	//Checking if there is only one Record
	if (!isCollectionOrArray(object.row)) {
        
		//Converting Record to an array
		object.row = [object.row].toArray();
	}
	
	object.row.join(",")
	
	object.row.each { record ->
		String tempPayload = ""
		//convert the closure variable to Json output
		def sRecord = JsonOutput.toJson(record)
		
		//append record number to the Json

		def index = sRecord.indexOf("{\"salesDivision\":");
		sRecord = sRecord.substring(0, index+1) + sRecord.substring(index+1);

		tempPayload = tempPayload + sRecord + ","
	
		completePayload=completePayload.concat(tempPayload)
	}
		
	completePayload = "[" + completePayload;

	completePayload=completePayload.concat("]")
	
	def index1 = completePayload.indexOf(",]");
	completePayload = completePayload.substring(0, index1) + completePayload.substring(index1+1);
	
	// Prepare Message Header
	message.setHeader('Content-Type', "application/json")	
	
	// Prepare Message Body
	message.setBody(completePayload)
	
    return message
}

//Returns true if object is an array

boolean isCollectionOrArray(object) {
    
	[Collection, Object[]].any {
        
		it.isAssignableFrom(object.getClass())
    
	}

}