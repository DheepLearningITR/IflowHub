import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser

def Message processData(Message message) {
    def body = message.getBody(String.class)
    def batchResponse           = new XmlParser().parseText(body);
    def responseParts           = batchResponse.batchChangeSetResponse.batchChangeSetPartResponse;
    
    String statusCode, errorStatusCode, statusInfo, errorBody
    boolean successflag, errorflag
    
    for (def item in responseParts) {
        statusCode = item.statusCode.text();
        ServiceOrderId = item.body.ServiceOrder.text();
        ServiceOrderItem = item.body.ServiceOrderItem.text();
        if (statusCode.startsWith("2") == true)
            successflag = true
        
        if (statusCode.startsWith("4") == true || statusCode.startsWith("5") == true) {
            errorflag = true
            errorStatusCode = item.statusCode.text();
            statusInfo = item.statusInfo.text();
            errorBody += item.body.text();
        }
    }
    
            if (!successflag && errorBody){
                throw new Exception("Failed while updating the Contact Address in S4HANA. For error details, see the batch response body in the error log attachments." + "\n" + errorBody);
            }
    
    return message
}