import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def sourcePayload = body
    def parser = new JsonSlurper()
    def parserResult = parser.parseText(body)
    
    def eventType = parserResult.eventType
    message.setProperty("eventType", eventType)
    def contact = parserResult.data.contact
    
    def FSMContactId = contact.id
    def S4ContactId = contact.externalId
    if(FSMContactId) {
        message.setProperty("FSMContactId", FSMContactId)
        if (S4ContactId) {
            message.setProperty("S4ContactId", S4ContactId)
        }
    }
    
    def isAddressPresent = false
    def isAssociatedBPpresent = false
    if(contact.addresses[0] && contact.addresses[0].id){
       isAddressPresent = true
    }
    if (isAddressPresent == true){
        def contactDetails = [
            FSMOfficePhoneNumber: contact.officePhone,
            FSMMobileNumber: contact.mobilePhone,
            FSMFaxNumber: contact.fax,
            FSMEmailAddress: contact.emailAddress
        ]

        contactDetails.each { key, value ->
            if (value) { // Groovy truth: null or empty values are false
                message.setProperty(key, value)
            }
        }

    }
    
    if (contact.object != null){
       isAssociatedBPpresent = true
    }
    if (isAssociatedBPpresent == true){
        def S4RelationBPId = contact.object.objectId.externalId
        if (S4RelationBPId != null){
            message.setProperty("S4RelationBPId",S4RelationBPId)
        }
    }
    message.setProperty("isAddressPresent",isAddressPresent)
    message.setProperty("isAssociatedBPpresent",isAssociatedBPpresent)
    
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null) {
        try {
            if (FSMcontactId)
                messageLog.addCustomHeaderProperty("ContactCode", FSMContactId)
            if (S4ContactId)
                messageLog.addCustomHeaderProperty("ContactExternalID", S4contactId)                
            
        } catch(Exception exp) { /* Contact details not found */ }
    }
    
    return message;
}