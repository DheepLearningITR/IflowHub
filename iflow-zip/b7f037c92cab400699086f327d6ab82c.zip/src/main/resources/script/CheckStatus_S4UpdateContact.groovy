import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    if (message.getHeader("CamelHttpResponseCode", String) != '204') {
        throw new Exception("The integration flow message won’t be processed further due to an error returned by the SAP S4HANA while updating the relationship. For error details, see the batch response body in the error log attachments.");
    }

    def messageLog = messageLogFactory.getMessageLog(message);
    def propmap = message.getProperties();
    def S4contactId = propmap.get("S4contactId")

    if(messageLog != null && S4contactId){
        messageLog.addCustomHeaderProperty("ContactExternalID", S4contactId) 
    }

   return message;
}
