import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser

def Message processData(Message message) {
    def body = message.getBody(String.class)
    def responseXml = new XmlParser().parseText(body)
    def externalID = responseXml.A_BusinessPartnerType?.BusinessPartner?.text()
    
    def isErrorContactCreate = !(message.getHeader("CamelHttpResponseCode", String) == '201' && externalID)
    message.setProperty("S4ContactId", externalID)
    message.setProperty("isErrorContactCreate", isErrorContactCreate)
    
    return message
}