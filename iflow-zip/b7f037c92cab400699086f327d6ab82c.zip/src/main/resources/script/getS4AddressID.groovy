import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def Message processData(Message message) {
    //This script is to get the S4 AddressID for the FSM ExternalID (S4 Address UUID)

   def body = message.getBody(java.lang.String) as String;
   def parsedbody = new XmlParser().parseText(body)

   def FSMAdrExternalID = parsedbody?.externalId.text()
   message.setProperty("S4AddressId","")

    //get S4 Address Response
    def propmap = message.getProperties();
    def S4AddressMsg = propmap.get("S4AddressResponse").toString(); 
    def S4AddressXml = new XmlParser().parseText(S4AddressMsg)

    S4AddressXml?.entry.each { adr ->
        def S4AddressUUID = adr?.content?."m:properties"?."d:AddressUUID".text()
        if (FSMAdrExternalID == S4AddressUUID){
            message.setProperty("S4AddressId",adr?.content?."m:properties"?."d:AddressID".text())
        }
    }
   
   
	return message;
}