import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;


def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def query = new XmlSlurper().parseText(body);
    def map = message.getProperties();
    
    //read credentials for S4 user
    def secureStoreService = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = secureStoreService.getUserCredential(map.get('S4Credential'));

    if (credential == null) {
        throw new IllegalStateException("No credential found for alias: " + credentialAlias+ ". Please enter security parameter alias used for S4 communication");
    }

    
    def FSMuser = credential.getUsername();
    def relationshipAlreadyExists = false;
    def BPExtID = map.get('S4RelationBPId')
    def bpRelationToBeDeleted = '';
    
    if(query.A_BPRelationshipType.size()==0){ //If Contact doesn't have any contact relationships in S4
        message.setProperty("relationshipPath", "createOrDelete");
    }else{
        query.A_BPRelationshipType.each{
            if(it.BusinessPartner1.text() == BPExtID){ //Check if contact and BP relationship already exists, then no changes needed
                relationshipAlreadyExists = true;
                message.setProperty("relationshipPath", "ignore");
            }else if(it.CreatedByUser.text() == FSMuser){ //if there exists a relatonship created from FSM, which is not applicable anymore - then delete
                message.setProperty("deleteRequired", "yes");
                bpRelationToBeDeleted = it.BusinessPartner1.text()
                message.setProperty("bpRelationToBeDeleted", bpRelationToBeDeleted)
                message.setProperty("relationshipNumberToDelete",it.RelationshipNumber.text())
                message.setProperty("relationshipValidityEndDate",it.ValidityEndDate.text())
            }
        }
        if(relationshipAlreadyExists && bpRelationToBeDeleted!=''){
          message.setProperty("relationshipPath", "delete");
        }
        if(!relationshipAlreadyExists && bpRelationToBeDeleted!=''){
          message.setProperty("deleteRequired", "yes");
          message.setProperty("relationshipPath", "createOrDelete");
        }
        if(!relationshipAlreadyExists && bpRelationToBeDeleted==''){
          message.setProperty("deleteRequired", "no");
          message.setProperty("relationshipPath", "createOrDelete");
        }
        if(BPExtID == null && bpRelationToBeDeleted!=''){
          message.setProperty("relationshipPath", "delete");
        }
        if(BPExtID == null && bpRelationToBeDeleted==''){
          message.setProperty("relationshipPath", "ignore");
        }
    }
    
    return message;
}