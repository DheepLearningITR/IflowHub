import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    if (!message.getHeader("CamelHttpResponseCode", String).startsWith("2")) {
        throw new Exception("The integration flow message won’t be processed further due to an error returned by SAP S4HANA while Creating the Contact Address. For error details, see the batch response body in the error log attachments.");
    }

   return message;
}
