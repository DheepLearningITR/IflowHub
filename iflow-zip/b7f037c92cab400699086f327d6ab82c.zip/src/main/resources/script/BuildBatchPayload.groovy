import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def FSMcreateDateTime = message.getProperty("FSMcreateDateTime") 
    def FSMcreateDate = FSMcreateDateTime[0..9] + "T00:00:00.000"
    def CurrentDefaultStartDate = message.getProperty("CurrentDefaultStartDate")
    def S4ContactId =  message.getProperty("S4ContactId")
    def CurrentDefaultAddressId = message.getProperty("CurrentDefaultAddressId")
    def S4AddressId = message.getProperty("S4AddressId")
    def Today = ''
    use (groovy.time.TimeCategory) {
         Date todayDate =  new Date()
         Today = todayDate.format("yyyy-MM-dd").toString()
    }
    def bodyPart = ''
    def ValidityStartDate = ''
    if (FSMcreateDate != CurrentDefaultStartDate) {
        Date yesterdayDate =  new Date()-1
        def yesterday = yesterdayDate.format("yyyy-MM-dd").toString()
        bodyPart = "<batchChangeSetPart>" +
                   "<method>POST</method>" +
                   "<uri>A_BusinessPartnerAddress(BusinessPartner='" + S4ContactId + "',AddressID='" + CurrentDefaultAddressId + "')/to_AddressUsage</uri>" +
                   "<A_BuPaAddressUsage>" +
                   "<A_BuPaAddressUsageType>" +
                   "<ValidityStartDate>" + CurrentDefaultStartDate + "</ValidityStartDate>" +
                   "<ValidityEndDate>" + yesterday + "T23:59:59Z</ValidityEndDate>" +
                   "<AddressUsage>XXDEFAULT</AddressUsage>" +
                   "</A_BuPaAddressUsageType>" +
                   "</A_BuPaAddressUsage>" +
                   "</batchChangeSetPart>"
        ValidityStartDate = Today.toString() + "T00:00:00Z"
    }
    else {
        ValidityStartDate = CurrentDefaultStartDate[0..9] + "T00:00:00Z"
    }
    
    def body = "<?xml version='1.0' encoding='UTF-8'?>" +
               "<batchParts>" +
               "<batchChangeSet>" +
               "<batchChangeSetPart>" +
               "<method>DELETE</method>" +
               "<uri>A_BuPaAddressUsage(BusinessPartner='" + S4ContactId + "',ValidityEndDate=datetimeoffset'9999-12-31T23%3A59%3A59Z'," + 
               "AddressUsage='XXDEFAULT',AddressID='" + CurrentDefaultAddressId + "')</uri>" +
               "</batchChangeSetPart>" +
               bodyPart +
               "<batchChangeSetPart>" +
               "<method>POST</method>" +
               "<uri>A_BusinessPartnerAddress(BusinessPartner='" + S4ContactId + "',AddressID='" + S4AddressId + "')/to_AddressUsage</uri>" +
               "<A_BuPaAddressUsage>" +
               "<A_BuPaAddressUsageType>" +
               "<ValidityStartDate>" + ValidityStartDate + "</ValidityStartDate>" +
               "<ValidityEndDate>9999-12-31T23:59:59Z</ValidityEndDate>" +
               "<AddressUsage>XXDEFAULT</AddressUsage>" +
               "</A_BuPaAddressUsageType>" +
               "</A_BuPaAddressUsage>" +
               "</batchChangeSetPart>" + 
               "</batchChangeSet>" +
               "</batchParts>"
    message.setBody(body)
    
    message.setHeader("Content-Type",'multipart/mixed')
    

 return message
}
   