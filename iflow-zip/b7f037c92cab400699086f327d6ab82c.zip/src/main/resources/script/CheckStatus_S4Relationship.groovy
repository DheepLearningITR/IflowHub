import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser

def Message processData(Message message) {
    def body = message.getBody(String.class)
    def batchResponse           = new XmlParser().parseText(body);
    def responseParts           = batchResponse.batchChangeSetResponse.batchChangeSetPartResponse;
    
    String statusCode, errorStatusCode, statusInfo, errorBody;
    
    for (def item in responseParts) {
        statusCode = item.statusCode.text();
        ServiceOrderId = item.body.ServiceOrder.text();
        ServiceOrderItem = item.body.ServiceOrderItem.text();
        
        if (statusCode.startsWith("4") == true || statusCode.startsWith("5") == true) {
            errorStatusCode = item.statusCode.text();
            statusInfo = item.statusInfo.text();
            errorBody = item.body.text();
            if (errorBody){
                throw new Exception("Failed while updating the relationship in S4HANA. For error details, see the batch response body in the error log attachments." + "\n" + errorBody);
            }
        }
    }
    
    return message
}