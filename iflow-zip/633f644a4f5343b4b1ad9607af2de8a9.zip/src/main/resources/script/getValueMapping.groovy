import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;

def Message processData(Message message){
    def objCodes = message.getProperty("Object_Category_Codes");
    def codes = [];
    codes = objCodes.split("\\|");
    
    int i;
    def mssg = '[{';
    def sourceValue;
    def mappedValue;
    
    for(i =0; i<codes.size()-1; i++){
        mssg = """${mssg}"externalId": "${codes[i]}", "code": "${codes[i]}", "name": "${codes[i]}", "enumType": "EQUIPMENT_OBJECT_CATEGORY", "isDefault": "false"}, {""";
    }
    mssg = """${mssg}"externalId": "${codes[i]}", "code": "${codes[i]}", "name": "${codes[i]}", "enumType": "EQUIPMENT_OBJECT_CATEGORY", "isDefault": "false"}]""";
    
    message.setBody(new JsonBuilder(new JsonSlurper().parseText(mssg)).toPrettyString());
    message.setProperty("RequestPayload", new JsonBuilder(new JsonSlurper().parseText(mssg)).toPrettyString());
    return message;
}
