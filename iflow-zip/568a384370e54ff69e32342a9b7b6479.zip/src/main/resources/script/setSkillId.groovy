import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    def headers = message.getHeaders() as Map<String, Object>;
    
    def query = headers.get("CamelHttpQuery") as String
    if(query != null && query.contains("=")){
        String[] skillId = query.split("=")
        message.setProperty("skillId", skillId[1]);
    }
    
    return message;
}