import com.sap.it.api.mapping.*;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String customFunc(String action){
	if(action=="insert" || action=="change" || action=="delete")
	{
		return arg1="true";
	}
	else{
		return arg1="false";
	} 
}
