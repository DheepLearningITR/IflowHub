import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.xml.*

def buildBatchRequest(sRequestBody){
    if (sRequestBody == null || sRequestBody == "") {
        return null;
    } else {
        sBatchRequest = "<?xml version='1.0' encoding='UTF-8'?><batchParts><batchChangeSet>" + sRequestBody + "</batchChangeSet></batchParts>";
        return sBatchRequest;
    }
}

def buildHeaderUpdateString(map){
    def headers = "<method>PATCH</method><uri>A_ServiceOrder(ServiceOrder='" + map.get("ServiceOrder") + "')</uri>";
    String body = filterXMLTag(map.get("updateHeaderPayload") as String);
    
    return "<batchChangeSetPart>" + headers + body + "</batchChangeSetPart>";
}

def buildRemoveRemarksString (map) {
    def headers = "<method>DELETE</method><uri>A_ServiceOrderText(ServiceOrder='" + map.get("ServiceOrder") + "',Language='" +  map.get("TextLangu") + "',LongTextID='" + map.get("LongTextRemarkType") + "')</uri>";
    return "<batchChangeSetPart>" + headers + "</batchChangeSetPart>";
}

def buildAddRemarksString (map) {
    def headers = "<method>PUT</method><uri>A_ServiceOrderText(ServiceOrder='" + map.get("ServiceOrder") + "',Language='" +  map.get("TextLangu") + "',LongTextID='" + map.get("LongTextRemarkType") + "')</uri>";
    String body = filterXMLTag(map.get("updateRemarkPayload")); 
    return "<batchChangeSetPart>" + headers + body + "</batchChangeSetPart>";
}

def buildRemoveResolutionString (map) {
    def headers = "<method>DELETE</method><uri>A_ServiceOrderText(ServiceOrder='" + map.get("ServiceOrder") + "',Language='" +  map.get("TextLangu") + "',LongTextID='" + map.get("LongTextResolutionType") + "')</uri>";
    return "<batchChangeSetPart>" + headers + "</batchChangeSetPart>";
}

def buildAddResolutionString (map) {
    def headers = "<method>PUT</method><uri>A_ServiceOrderText(ServiceOrder='" + map.get("ServiceOrder") + "',Language='" +  map.get("TextLangu") + "',LongTextID='" + map.get("LongTextResolutionType") + "')</uri>";
    String body = filterXMLTag(map.get("updateResolutionPayload")); 
    return "<batchChangeSetPart>" + headers + body + "</batchChangeSetPart>";
}

def buildRemoveRefObjectString (map) {
    def Deletionpayload = map.get("currentRefObjNodes");
    def currentRefObjNodes = new XmlSlurper().parseText(Deletionpayload)
    
   def writer = new StringWriter()
   def xmlBuilder = new MarkupBuilder(writer)
    
   currentRefObjNodes.A_ServiceOrderRefObjectType.each { refObject ->
        xmlBuilder.batchChangeSetPart {
            method('DELETE')
            
                def serviceOrder = refObject.ServiceOrder.text()
                def serviceReferenceEquipment = refObject.ServiceReferenceEquipment.text()
                def serviceRefFunctionalLocation = refObject.ServiceRefFunctionalLocation.text()

                def uriString = "A_ServiceOrderRefObject(ServiceOrder='${serviceOrder}',ServiceReferenceEquipment='${serviceReferenceEquipment}',ServiceRefFunctionalLocation='${serviceRefFunctionalLocation}')"
                uri(uriString)
            }
        }

def outputstring = writer.toString()
    return outputstring;
}

def buildAddRefObjectString (map) {
    def currentRefObjNodes = new XmlSlurper().parseText(map.get("currentRefObjNodes"))
    def NewRefObjNodes = new XmlSlurper().parseText(map.get("NewRefObjNodes"))
    
    def mainObjectKeys = []
    
    currentRefObjNodes.A_ServiceOrderRefObjectType.each { node ->
       if (node.SrvcRefObjIsMainObject.text() == 'true') {
        def key = "${node.ServiceOrder.text()}|${node.ServiceReferenceEquipment.text()}|${node.ServiceRefFunctionalLocation.text()}"
        mainObjectKeys << key
       }
    }

    def isMainObjectSet = false

    
    NewRefObjNodes.SrvOrderRefObjectType.each { node ->
    def key = "${node.SrvOrder.text()}|${node.SrvRefEquipment.text()}|${node.SrvRefFunctionalLocation.text()}"
        if (mainObjectKeys.contains(key)) {
         node.SrvcRefObjIsMainObject.replaceBody('true')
         isMainObjectSet = true
       }
   }

    if (!isMainObjectSet) {
       NewRefObjNodes.SrvOrderRefObjectType[0].SrvcRefObjIsMainObject.replaceBody('true')
   }
     
    def UpsertPayload = XmlUtil.serialize(NewRefObjNodes)

    def prepareupsertxml = new XmlSlurper().parseText(UpsertPayload)
    
    def writer = new StringWriter()
    def xmlBuilder = new MarkupBuilder(writer)
    
    prepareupsertxml.SrvOrderRefObjectType.each { refObject ->
    
    xmlBuilder.batchChangeSetPart {
    method('POST')
    uri('A_ServiceOrderRefObject')
    A_ServiceOrderRefObject {
        
            A_ServiceOrderRefObjectType {
                ServiceOrder(refObject.SrvOrder.text())
                ServiceReferenceEquipment(refObject.SrvRefEquipment.text())
                ServiceRefFunctionalLocation(refObject.SrvRefFunctionalLocation.text())
                def isMainObject = refObject.SrvcRefObjIsMainObject.text() == 'true' ? 'true' : 'false'
                SrvcRefObjIsMainObject(isMainObject)
            }
        }
    }
}

    def headers = writer.toString()   
    
    return headers;
}


def buildRemoveResponsibleString (map) {
    def headers = "<method>DELETE</method><uri>A_ServiceOrderPersonResp(ServiceOrder='" + map.get("ServiceOrder") + "',PersonResponsible='" + map.get("CurrentResponsible") + "')</uri>";
    return "<batchChangeSetPart>" + headers + "</batchChangeSetPart>";
}

def buildAddResponsibleString (map) {
    def headers = "<method>POST</method><uri>A_ServiceOrderPersonResp</uri>";
    def body = '''
    <A_ServiceOrderPersonResp>
        <A_ServiceOrderPersonRespType>
            <ServiceOrder>''' + map.get("ServiceOrder") + '''</ServiceOrder>
            <PersonResponsible>''' + map.get("NewResponsible") + '''</PersonResponsible>
        </A_ServiceOrderPersonRespType>
    </A_ServiceOrderPersonResp>'''; 
    
    return "<batchChangeSetPart>" + headers + body + "</batchChangeSetPart>";
}

def filterXMLTag (body) {
    String filteredBody = body;
    filteredBody = filteredBody.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "")
    
    return filteredBody;
}

def Message processData(Message message) {
    def map = message.getProperties();
    def batchRequestBody = "";
    
    if (map.get("SendRequest_DeleteResponsible") == true) {
        batchRequestBody = batchRequestBody + buildRemoveResponsibleString(map);
    }
    
    if (map.get("SendRequest_AddResponsible") == true) {
        batchRequestBody = batchRequestBody + buildAddResponsibleString(map);
    }
    
    if (map.get("SendRequest_DeleteReferenceObject") == true) {
        batchRequestBody = batchRequestBody + buildRemoveRefObjectString(map);
    }
    
    if (map.get("SendRequest_AddReferenceObject") == true) {
        batchRequestBody = batchRequestBody + buildAddRefObjectString(map);
    }
    
    if (map.get("isHeaderRemarkUpdated") == true && map.get("isHeaderRemarkDeleted") == false) {
        batchRequestBody = batchRequestBody + buildAddRemarksString(map);
    } else if (map.get("isHeaderRemarkUpdated") == true && map.get("isHeaderRemarkDeleted") == true) {
        batchRequestBody = batchRequestBody + buildRemoveRemarksString(map);
    }
    
    if (map.get("isHeaderResolutionUpdated") == true && map.get("isHeaderResolutionDeleted") == false) {
        batchRequestBody = batchRequestBody + buildAddResolutionString(map);
    } else if (map.get("isHeaderResolutionUpdated") == true && map.get("isHeaderResolutionDeleted") == true) {
        batchRequestBody = batchRequestBody + buildRemoveResolutionString(map);
    }
    
    if (map.get("SendRequest_UpdateHeader") == true || (map.get("HeaderExtensionEnabled") ==~ /(?i)(true|x)/) == true) {
        batchRequestBody = batchRequestBody + buildHeaderUpdateString(map);
    }
    
    if (map.get("isReferenceObjectUpdated") == true) {
        batchRequestBody = batchRequestBody + buildRemoveRefObjectString(map);
        batchRequestBody = batchRequestBody + buildAddRefObjectString(map);
    }
    
    message.setBody(buildBatchRequest(batchRequestBody));
    
    return message;
}