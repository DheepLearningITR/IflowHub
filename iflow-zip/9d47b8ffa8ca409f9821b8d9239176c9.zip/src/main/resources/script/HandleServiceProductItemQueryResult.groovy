import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def xmlParser = new XmlParser()
    def result = xmlParser.parseText(body)
    def eventType = message.getProperty("eventType")

    switch (eventType){
        case 'activity.confirmed':
            def jsonParser = new JsonSlurper()
            def orderNeedUpdate = true
            def s4ItemList = result.A_ServiceOrderItemType as List
            def parentServiceOrderItem = message.getProperty("ParentServiceOrderItem").toString()

            if (!s4ItemList.is(null) || s4ItemList.size() != 0){
                def s4ProductMap = [:]
                for (def item in s4ItemList){
                    if (parentServiceOrderItem == item.ParentServiceOrderItem.text() || item.ParentServiceOrderItem.text() == '0' || item.ParentServiceOrderItem.text() == 0 )
                        s4ProductMap.put(item.Product.text(),[item.ServiceOrderItem.text(),item.Product.text(),item.ParentServiceOrderItem.text()])
                }
                if (s4ProductMap.size() != 0){
                    def resultJson = message.getProperty("resultJson") as String
                    def jsonMap = jsonParser.parseText(resultJson)
                    if(jsonMap["root"]["ServiceOrderItems"].size() != 0){
                        jsonMap["root"]["ServiceOrderItems"]["ServiceOrderItemEntity"] =
                            jsonMap["root"]["ServiceOrderItems"]["ServiceOrderItemEntity"].grep{
                                item -> ! (item["Product"] in s4ProductMap.keySet())
                            }
                    }
                    if (jsonMap["root"]["ServiceOrderItems"]["ServiceOrderItemEntity"].size() == 0)
                        orderNeedUpdate = false
                    resultJson = JsonOutput.toJson(jsonMap)
                    message.setProperty("resultJson",resultJson)
                    message.setProperty("orderNeedUpdate",orderNeedUpdate)
                    message.setBody(resultJson)
                }
            }
            break
        case 'activity.confirmedcompleted':
        case 'activity.completed':
            def serviceOrderNeedComplete, serviceProductMap = [:]
            def currentServiceOrderItem
            def resultJson, regPattern

            currentServiceOrderItem = message.getProperty("ServiceOrderItem") as String

            result.A_ServiceOrderItemType.each{
                item ->
                    if (item.ServiceOrderItem.text() == currentServiceOrderItem) return
                    serviceProductMap[item.ServiceOrderItem.text()] = item.ServiceOrderItemIsCompleted.text()
            }
            serviceProductMap.remove(currentServiceOrderItem)
            serviceOrderNeedComplete = serviceProductMap.every { key, value -> value == "X" }

            if (serviceOrderNeedComplete){
                resultJson = message.getProperty("resultJson") as String
                regPattern = /"ServiceOrderItems"/
                def replacePart = '''"ServiceOrderIsCompleted":"T",
                    "ServiceOrderItems"'''
                resultJson = resultJson.replaceFirst(regPattern,replacePart)
                message.setProperty("resultJson",resultJson)
            }
            message.setProperty("serviceOrderNeedComplete",serviceOrderNeedComplete)
            break
        default:
            break
    }


    return message
}
