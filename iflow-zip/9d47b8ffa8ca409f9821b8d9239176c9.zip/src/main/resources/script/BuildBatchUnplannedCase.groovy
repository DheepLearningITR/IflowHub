import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper

def buildBatchRequest(sRequestBody){
    if (sRequestBody == null || sRequestBody == "") {
        return null;
    } else {
        sBatchRequest = "<?xml version='1.0' encoding='UTF-8'?><batchParts><batchChangeSet>" + sRequestBody + "</batchChangeSet></batchParts>";
        return sBatchRequest;
    }
}

def buildItemCreationString(item){
    def headers = "<method>POST</method><uri>A_ServiceOrderItem</uri>";
    
    String body = '''
    <A_ServiceOrderItem>
      <A_ServiceOrderItemType>
        <ServiceOrder>''' + item.ServiceOrderOutter + '''</ServiceOrder>
        <ServiceOrderItem>000000</ServiceOrderItem>
        <Product>''' + item.Product + '''</Product>
        <Quantity>''' + item.Quantity + '''</Quantity>
        <ParentServiceOrderItem>''' + item.ParentServiceOrderItem + '''</ParentServiceOrderItem>
        <ServiceOrderItemIsReleased>X</ServiceOrderItemIsReleased>
        <SrvcContrDetnIsSpprsd>true</SrvcContrDetnIsSpprsd>
      </A_ServiceOrderItemType>
    </A_ServiceOrderItem>''';
    
    return "<batchChangeSetPart>" + headers + body + "</batchChangeSetPart>";
}

def getItemsToBeCreated(body, map){
    def items = null;
    def s4ProductMap = [:];
    def jsonParser = new JsonSlurper()
    
    def s4ItemList = body.A_ServiceOrderItemType as List;
    def parentServiceOrderItem = map.get("ParentServiceOrderItem").toString();
    def currentServiceOrderItem = map.get("ServiceOrderItem") as String;
    def jsonMap = jsonParser.parseText(map.get("resultJson"));
    
    //detact all Products already in S4 as Service Items
    for (def item in s4ItemList) {
        if (item.ParentServiceOrderItem.text() == parentServiceOrderItem || item.ParentServiceOrderItem.text() == '0' || item.ParentServiceOrderItem.text() == 0 ) {
            s4ProductMap.put(item.Product.text(), [item.ServiceOrderItem.text(), item.Product.text(), item.ParentServiceOrderItem.text()])
        }
    }
        
    if (s4ProductMap.size() != 0){
        //filter all Items that have Products already in S4 as Service Items
        if (jsonMap["root"]["ServiceOrderItems"].size() != 0){
            jsonMap["root"]["ServiceOrderItems"]["ServiceOrderItemEntity"] = jsonMap["root"]["ServiceOrderItems"]["ServiceOrderItemEntity"].grep{ item -> ! (item["Product"] in s4ProductMap.keySet()) }
        }
            
        items = jsonMap["root"]["ServiceOrderItems"]["ServiceOrderItemEntity"];
    } else {
        items = jsonMap["root"]["ServiceOrderItems"]["ServiceOrderItemEntity"];
    }
    
    return items;
}

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def xmlParser = new XmlParser();
    def batchRequestBody = "";
    def map = message.getProperties();
    def itemsToCreated = getItemsToBeCreated(xmlParser.parseText(body), map);
    
    if (itemsToCreated != null && itemsToCreated != []) {
        for (def currItem in itemsToCreated) {
            batchRequestBody = batchRequestBody + buildItemCreationString(currItem);
        }
    } else {
        message.setProperty("ItemCreationNotNeeded", "true");
    }
    
    message.setBody(buildBatchRequest(batchRequestBody));
    
    return message;
}