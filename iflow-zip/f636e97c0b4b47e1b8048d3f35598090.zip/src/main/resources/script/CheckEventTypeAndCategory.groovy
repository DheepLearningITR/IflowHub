import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.ArrayList;
def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def query = new XmlSlurper().parseText(body);
    if(query.fsm_body.eventType.text() == "attachment.created" )
        message.setProperty("IsValid","true");
    else
        message.setProperty("IsValid","false");
    return message;
}