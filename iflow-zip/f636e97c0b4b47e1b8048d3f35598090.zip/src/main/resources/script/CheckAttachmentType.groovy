import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper 
def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body);
    if(object.data.attachment.category=="ServiceCheckout"&&object.data.serviceCall!=null)
        message.setProperty("IsValid","false");
    else
        message.setProperty("IsValid","true");
    return message;
}