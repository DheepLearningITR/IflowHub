/*
Script to detect invalid response message inside batch.
Release version 1.0.0
SAP SE 2018
*/
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil
import groovy.util.XmlSlurper
import groovy.util.slurpersupport.NodeChild

def Message processData(Message message) {

		//Extract Message body	
		def body = message.getBody(String.class);
		
		//Convert String to GPath
		if(body) {
		    def batchPartResponse = new XmlSlurper().parseText(body);
		
		    //Get Amount of failed Batch Requests
		    def errorResponse = getInvalidResponseMessage(batchPartResponse);

		    //If there is a failed request throw an exception
		    if(errorResponse != null && errorResponse.size() > 0) {
    			throw new Exception("\n[" + errorResponse.size() + " failed request(s)!]" + "\n" + errorResponse + "\n");
	    	}
		}
		return message;
}
	
def getInvalidResponseMessage(NodeChild batchPartResponse) {
		def invalidResponse = [];
		
		//Check for invalid HTTP Status Code
		batchPartResponse.batchChangeSetResponse.batchChangeSetPartResponse.findAll { s->
			s.statusCode.toInteger() > 299
		}.each{ s->
			invalidResponse.push(s.body)
		}
		
		return invalidResponse
}