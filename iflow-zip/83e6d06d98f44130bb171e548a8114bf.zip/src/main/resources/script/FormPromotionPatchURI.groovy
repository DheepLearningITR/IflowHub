import com.sap.it.api.mapping.*;

//Form Offer Patch URI
def String customFunc(String arg1, String arg2){
    return "Offers(OfferIdExt='"+arg1+"',OfferIdOrigin='"+arg2+"')"; 
}