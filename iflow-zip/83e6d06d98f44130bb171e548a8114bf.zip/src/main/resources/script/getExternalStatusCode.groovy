import com.sap.it.api.mapping.*;

//Get the external status code by passing the external status.
def String getExternalStatusCodeByExternalStatus(String externalStatus){
switch(externalStatus)
{
    case "UNPUBLISHED":
        externalStatus = "00";
        break;
    case "PUBLISHED":
        externalStatus = "01";
        break;  
    case "INACTIVE":
        externalStatus = "02";
        break; 
    default:
        externalStatus = "";
        break;
}
	return externalStatus; 
}