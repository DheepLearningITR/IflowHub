import com.sap.it.api.mapping.*;

//Get the external status description by passing the external status.
def String getExternalStatusDescriptionByExternalStatus(String externalStatusDesc){
switch(externalStatusDesc)
{
    case "UNPUBLISHED":
        externalStatusDesc = "In Preparation";
        break;
    case "PUBLISHED":
        externalStatusDesc = "Externally Released";
        break;  
    case "INACTIVE":
        externalStatusDesc = "Paused";
        break; 
    default:
        externalStatusDesc = "";
        break;
}
	return externalStatusDesc; 
}