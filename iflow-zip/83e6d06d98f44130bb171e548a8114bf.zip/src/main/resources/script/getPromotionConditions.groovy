import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.XmlUtil

def Message processData(Message message) {

	//Body
	def promotionPayload = message.getBody()

	//Get Properties
	def map = message.getProperties()

	//Get the promotion condition details such as products, categories and couponUUID
	def promotionConditionsPayload = map.get("promotionConditionsPayload")

	def jsonSlurper = new JsonSlurper()
	def oPayload = jsonSlurper.parseText(promotionConditionsPayload)

	def productMap = [:]
	def categoryMap = [:]
	def couponsMap = [:]
	def prodList
	def prodCatList
	def couponNameList
	def prodCatLoopIncrementor = 0
	def prodLoopIncrementor = 0

	def promotionConditionsXmlPayload = new StringWriter()
	def builder = new groovy.xml.MarkupBuilder(promotionConditionsXmlPayload)

	oPayload?.each
	{
		if(it?.definitionId == 'y_qualifying_coupons')
		{
			if(!(couponsMap.size()))
			{
				if(it.parameters?.coupons?.type == "List(ItemType(AbstractCoupon))")
				{
					couponNameList = it.parameters?.coupons?.value.collect()
					if(couponNameList)
					{
						couponsMap.put(1, couponNameList[0])
					}
				}
			}
		}

		if(it?.definitionId == 'y_qualifying_categories')
		{
			if(it.parameters?.categories?.type == "List(ItemType(Category))")
			{
				prodCatList = it.parameters?.categories?.value.collect()
				if(prodCatList)
				{
					prodCatList.each{ item ->
						prodCatLoopIncrementor++
						categoryMap.put(prodCatLoopIncrementor, item)
					}
				}
			}
		}

		if(it?.definitionId == 'y_qualifying_products')
		{
			if(it.parameters?.products?.type == "List(ItemType(Product))")
			{
				prodList = it.parameters?.products?.value?.collect()
				if(prodList)
				{
					prodList.each{ item ->
						prodLoopIncrementor++
						productMap.put(prodLoopIncrementor, item.tokenize(':')[0])
					}
				}
			}
		}


		if(it?.definitionId == 'y_group')
		{

			it.children.each{ child ->

				if(child.definitionId == 'y_qualifying_coupons')
				{
					if(!(couponsMap.size()))
					{
						if(child.parameters?.coupons?.type == "List(ItemType(AbstractCoupon))")
						{
							couponNameList = child.parameters?.coupons?.value.collect()
							if(couponNameList)
							{
								couponsMap.put(1, couponNameList[0])
							}
						}
					}
				}

				if(child.definitionId  == 'y_qualifying_categories')
				{
					if(child.parameters?.categories?.type == "List(ItemType(Category))")
					{
						prodCatList = child.parameters?.categories?.value.collect()
						if(prodCatList)
						{
							prodCatList.each{ item ->
								prodCatLoopIncrementor++
								categoryMap.put(prodCatLoopIncrementor, item)
							}
						}
					}


				}


				if(child.definitionId  == 'y_qualifying_products')
				{
					if(child.parameters?.products?.type == "List(ItemType(Product))")
					{
						prodList = child.parameters?.products?.value?.collect()
						if(prodList)
						{
							prodList.each{ item ->
								prodLoopIncrementor++
								productMap.put(prodLoopIncrementor, item.tokenize(':')[0])
							}
						}
					}
				}

			}

		}


	}

	builder.promotionConditions
	{
		if(productMap.size() > 0)
		{
			Products()
			{
				productMap.each()
				{ key, value ->
					product()
					{
						"id" "${value}"
					}
				}
			}
		}

		if(categoryMap.size() > 0)
		{
			Categories()
			{
				def tempList;
				categoryMap.each()
				{ key, value ->
					tempList = value.tokenize(':')
					category()
					{
						"offerCategory" "${tempList[0]}"
						"heierarchyId" "${tempList[1]}"
					}
				}
			}
		}

		if(couponsMap.size() > 0)
		{
			Coupon()
			{
				couponsMap.each()
				{ key, value ->
					"coupon" "${value}"
				}
			}
		}
	}

	def rootXml  = new XmlSlurper().parseText(promotionPayload.toString())
	def childXml = new XmlSlurper().parseText(promotionConditionsXmlPayload.toString())
	rootXml.PromotionSourceRule[0].appendNode(childXml)
	message.setBody(groovy.xml.XmlUtil.serialize( rootXml ))
	return message
}