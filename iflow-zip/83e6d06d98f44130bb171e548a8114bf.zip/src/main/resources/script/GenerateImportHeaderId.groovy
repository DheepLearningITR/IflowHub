import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.mapping.*;
import java.security.SecureRandom;

def String customFunc(String arg1){

	return generateImportHeaderId();

}

protected String generateImportHeaderId()
	{
		def HEX = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'] as char[];
		
		SecureRandom GENERATOR = new SecureRandom();
		
		// 128 bits upper case hexadecimal String
		final byte[] randomBytes = new byte[16];
		GENERATOR.nextBytes(randomBytes); // synchronized
		final char[] randomChars = new char[32];
		for (int i = 0; i < 16; i++)
		{
			final byte b = randomBytes[i];
			randomChars[i * 2 + 0] = HEX[b >>> 4 & 0x0F];
			randomChars[i * 2 + 1] = HEX[b & 0x0F];
		}
		return new String(randomChars);
	}