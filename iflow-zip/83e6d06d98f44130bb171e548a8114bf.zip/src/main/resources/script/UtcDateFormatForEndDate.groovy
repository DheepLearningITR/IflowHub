import com.sap.it.api.mapping.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

//Create the end date by adding number of given months to the current date
def String createDate(int numberOfMonths) throws ParseException
{
     String format = "yyyy-MM-dd'T'HH:mm:ss.sss" ;
     SimpleDateFormat sdf = new SimpleDateFormat(format) ;
     Calendar cal = Calendar.getInstance();
     cal.add(Calendar.MONTH, numberOfMonths);
     Date dateAsObjAfterAMonth = cal.getTime() ;
     return sdf.format(dateAsObjAfterAMonth) ;
}