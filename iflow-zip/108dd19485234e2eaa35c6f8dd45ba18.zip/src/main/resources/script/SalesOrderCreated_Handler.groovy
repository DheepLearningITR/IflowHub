import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import javax.activation.DataHandler;

def Message processEvent(Message message) {
    //Body 
    def body = message.getBody(String.class);
    JsonSlurper slurper = new JsonSlurper();
    Map parsedJson = slurper.parseText(body);
    def type;
  
    switch(parsedJson.type) {
        case "sap.s4.beh.salesorder.v1.SalesOrder.Created.v1":
            type = "Sales Order Created";
            break;
        default:
            type = "NA";
    }
    
    message.setProperty("eventType", type);
    
    if(type != "NA"){
        message.setProperty("processDefinitionId", "managesalesorder");
        message.setProperty("processInstanceId", parsedJson.data.SalesOrder);
        message.setProperty("eventTimestamp", parsedJson.time);
        message.setProperty("orderId", parsedJson.data.SalesOrder);
    }
      
    return message;
    
}

def Message processSalesOrder(Message message) {
    
    def body = message.getBody(String.class);
    def salesOrder;
    String[] reasonList;
    def salesOrderApprovalReason;
    def payload = new groovy.json.JsonBuilder()
    def ApprovalRelevance = "Not Relevant";
    
    JsonSlurper slurper = new JsonSlurper();
    Map parsedJson = slurper.parseText(body);
    
    if (parsedJson.d != null) {
        salesOrder = parsedJson.d.results[0];
        salesOrder.remove('__metadata');
        salesOrder.remove('to_Item');
        salesOrder.remove('to_Partner');
        salesOrder.remove('to_PaymentPlanItemDetails');
        salesOrder.remove('to_PricingElement');
        salesOrder.remove('to_Text');
        message.setProperty("salesOrder", salesOrder);
    
        // check for the credit block
        if (salesOrder.TotalCreditCheckStatus == 'B') {
            // If TotalCreditCheckStatus = B then the order is CreditBlocked
            message.setProperty("creditBlocked", 'true');
            if (salesOrder.SalesDocApprovalStatus == 'A'){
                message.setProperty("soInApproval", 'true');
            } else {
                message.setProperty("soInApproval", 'false');
            }
        } else {
            message.setProperty("creditBlocked", 'false');
        }
        
        // check for external approval
        if (salesOrder.SalesDocApprovalStatus == 'A' && salesOrder.SalesOrderApprovalReason != '') {
            // If SalesDocApprovalStatus = A then the order is in approval
            reasonList = message.properties.salesOrderApprovalReason.split(',');
            if (reasonList.length > 0) {
                // remove spaces before or after the string
                reasonList = reasonList*.trim();
                
                if (reasonList.contains(salesOrder.SalesOrderApprovalReason)) {
                    message.setProperty("approvalRequired", 'true');
                } else {
                    message.setProperty("approvalRequired", 'false');
                }
                ApprovalRelevance = "External Workflow";
            } else {
                ApprovalRelevance = "Internal Workflow";
                message.setProperty("approvalRequired", 'false');
            }
            
        } else {
            message.setProperty("approvalRequired", 'false');
        }
        salesOrder.ApprovalRelevance = ApprovalRelevance;
        
        // prepare sales order created event for process visibility
        def root = payload 
            {
              processDefinitionId "managesalesorder"
              processInstanceId  message.properties.processInstanceId
              eventType  message.properties.eventType
              timestamp  message.properties.eventTimestamp
              context salesOrder
            }
        message.setBody(payload.toString());
        message.setHeader("Content-Type","application/json");
        
    } else {
        message.setProperty("approvalRequired", 'false');
        message.setProperty("creditBlocked", 'false');
    }
    return message;
    
}

def Message prepareCreditblockedEvent(Message message) {
    def payload = new groovy.json.JsonBuilder();
    def now = new Date().format("yyyy-MM-dd'T'HH:mm:ss'Z'", TimeZone.getTimeZone("UTC"));
    
    def root = payload 
            {
              processDefinitionId "managesalesorder"
              processInstanceId  message.properties.processInstanceId
              eventType  "Sales Order Credit Blocked"
              timestamp now
              context message.properties.SalesOrder
            }
    message.setBody(payload.toString());
    message.setHeader("Content-Type","application/json");
    return message;
}

def Message prepareApprovalStartedEvent(Message message) {
    def payload = new groovy.json.JsonBuilder();
    def now = new Date().format("yyyy-MM-dd'T'HH:mm:ss'Z'", TimeZone.getTimeZone("UTC"));
    
    def root = payload 
            {
              processDefinitionId "managesalesorder"
              processInstanceId  message.properties.processInstanceId
              eventType  "Sales Order Approval Started"
              timestamp now
              context message.properties.SalesOrder
            }
    message.setBody(payload.toString());
    message.setHeader("Content-Type","application/json");
    return message;
}


def Message preparePostSOApprovalWorkflowContext(Message message) {
    message.setProperty("workflowCallType", "POST");
    def jsonContext = new groovy.json.JsonSlurper().parseText('{"SalesOrderDetails": {},"History" : [], "Status" : {}}');
    jsonContext.SalesOrderDetails = message.properties.salesOrder;
    def payload = new groovy.json.JsonBuilder()
    def root = payload 
            {
              //definitionId "salesorderapprovaldemo"
              definitionId "approvesalesorder_leadingworkflow"
              context jsonContext
            }
    message.setBody(payload.toString());
    message.setHeader("Content-Type","application/json");
    return message;
}

def Message preparePostUnblockCreditWorkflowContext(Message message) {
    message.setProperty("workflowCallType", "POST");

    def workflowPayload = {
        SalesOrder message.properties.salesOrder
    };
    def payload = new groovy.json.JsonBuilder();
    def jsonContext = new groovy.json.JsonSlurper().parseText('{"SalesOrder": {},"History" : [], "Status" : {}}');
    jsonContext.SalesOrder = message.properties.salesOrder;
    def root = payload {
        definitionId "releasecreditblockedsalesorders_leadingworkflow"
        context jsonContext
    }
    message.setBody(payload.toString());
    message.setHeader("Content-Type", "application/json");
    return message;
}

def Message prepareWorkflowContext(Message message) {

    def jsonContext = new groovy.json.JsonSlurper().parseText('{"SalesOrderDetails": {},"History" : [], "Status" : {}}');
    jsonContext.SalesOrderDetails = message.properties.salesOrder;
    def payload = new groovy.json.JsonBuilder()
    def root = payload 
            {
              //definitionId "salesorderapprovaldemo"
              definitionId "approvesalesorder_leadingworkflow"
              context jsonContext
            }
    message.setBody(payload.toString());
    message.setHeader("Content-Type","application/json");
    return message;
}