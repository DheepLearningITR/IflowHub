import groovy.json.JsonSlurper;

import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {

def parsedObj = new JsonSlurper().parseText(message.getBody(String.class));
def RegionCodeToIdMap = [:];

    if(parsedObj.data.size() == 0){
        throw new RuntimeException("Could not find passed Regions in FSM.")
    }
    
// Form map of Region code and ID from the query response
    parsedObj.data.each{
        RegionCodeToIdMap.put(it.re.code,it.re.id)
    };

    String regionIdValue;
    def PersonsMappedData = new XmlParser().parseText(message.getProperty("MappedBody"));

    PersonsMappedData.data.each {
        if(!(it.regions.size() == 1 && it.regions[0].text() == "")){
            //if no org assignment is present or mapping present then one blank regions node is added
            // to clear the regions data of the employee in FSM. For such case, to avoid below loop execution
            // and send null value above if condition is added.
            
            it.regions.each {
                regionIdValue = RegionCodeToIdMap.get(it.text())
                if(regionIdValue == null){
                // if Regions value not found in FSM then delete the node  
                    it.parent().remove(it)
                }else {
                // If Regions value found in FSM then replace the code value with ID value
                    it.value = regionIdValue
                }
            }
        }
        
    }

    StringWriter stringWriter = new StringWriter()
    XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
    nodePrinter.setPreserveWhitespace(true)
    nodePrinter.print(PersonsMappedData)
    message.setBody(stringWriter.toString())

    return message;
}