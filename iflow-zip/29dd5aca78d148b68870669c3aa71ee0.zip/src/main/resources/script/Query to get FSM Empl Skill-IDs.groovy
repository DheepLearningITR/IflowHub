
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    //Get Body and parse it.
       def body = message.getBody(String.class);
       def parsedObj = new XmlSlurper().parseText(body);
       String query = "{\"query\": \"SELECT skil.externalId FROM Skill skil JOIN UnifiedPerson per ON skil.person = per.id WHERE skil.externalId IS NOT NULL AND per.externalId IN (";
       String s = '\'';
       String e = '\',';
       String eend = '\')\"}';
       String whereIn;
       ArrayList c4c_skill_ids = []
    // Form the where clause of Employee IDs for which skill IDs needs to be fetched from FSM
      parsedObj.EmployeesReplicationRequest.each{
          it.Employee.EmployeeProviderSkills.each{
          	    c4c_skill_ids.add(it.UUID.text().trim())
          }
          if (whereIn == null)
          {
              whereIn = s + it.children().BusinessPartnerID + eend;
          }
          else
          {
              whereIn = s + it.children().BusinessPartnerID + e + whereIn;
          }
          };
    //Set final query statement which has to be send as payload of the query API request     
       query = query + whereIn;
    // Temporarily store inbound payload as property   
       message.setProperty("InPayload",body);
       message.setProperty("c4c_skill_ids",c4c_skill_ids);
    // Set the query in the message body   
       message.setBody(query);
       return message;
}
