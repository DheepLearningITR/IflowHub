/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-IN/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-IN/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def root = new XmlParser().parseText(body);
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    
    def Persons = new NodeBuilder().Persons{}
    def employeeNode, fsmData, regionValue, OrgAssignment
    
    root.EmployeesReplicationRequest.each {
        employee = it.Employee
        
        fsmData = new NodeBuilder().data{
            externalId(employee.BusinessPartnerID.text())
            id(employee.ReceiverBusinessPartnerUUID.text())
            code(employee.ObjectIdentifierMapping.RemoteObjectID.text())
            firstName(employee.Common.Name.GivenName.text())
            lastName(employee.Common.Name.FamilyName.text())
            userName(employee.EmployeeID.text())
            types("ERPUSER")
            types("EMPLOYEE")
            emailAddress(employee.WorkplaceAddress.EmailURI.text())
            fax(employee.WorkplaceAddress.FaxNumberDescription.text())
            mobilePhone(employee.WorkplaceAddress.MobilePhoneNumberDescription.text())
            officePhone(employee.WorkplaceAddress.PhoneNumberDescription.text())
            refId(employee.ReceiverBusinessPartnerUUID.text())
        }
        
        employee.EmployeeOrgAssignment.each{
            OrgAssignment = it
            if("true".equals(OrgAssignment.ServiceIndicator.text())){
                regionValue = valueMapApi.getMappedValue('C4C', 'Service_technician_team', OrgAssignment.OrganizationalCenterID.text(), 'FSM', 'REGION')
                
                if(!regionValue.equals(null)){
                    fsmData.append(new NodeBuilder().regions(regionValue))
                }    
            }
        }
        
        Persons.append(fsmData)
    }

    StringWriter stringWriter = new StringWriter()
    XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
    nodePrinter.setPreserveWhitespace(true)
    nodePrinter.print(Persons)
    message.setBody(stringWriter.toString())

    return message;
}