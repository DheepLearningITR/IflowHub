import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
 //Get Body and parse it.
 def body = message.getBody(String.class);
 def parsedObj = new XmlParser().parseText(body);
 String query = "{\"query\": \"SELECT re.id, re.code from Region re WHERE re.code IN (";
 String s = '\'';
 String e = '\',';
 String eend = '\')\"}';
 String whereIn;
 
 // loop over regions and form query
 parsedObj.data.each {
  it.regions.each {
   if (whereIn == null) {
    whereIn = s + it.text() + eend;
   } else {
    whereIn = s + it.text() + e + whereIn;
   }
  }
  
  if(!it.find({node -> node.name().equals('regions')})){
      //to clear the wrongly mapped region value in FSM
    it.append(new NodeBuilder().regions(""))
  }
 }
 
    StringWriter stringWriter = new StringWriter()
    XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
    nodePrinter.setPreserveWhitespace(true)
    nodePrinter.print(parsedObj)
    
 
 if (whereIn == null){
     message.setBody(stringWriter.toString())
 }else {
    message.setProperty("FetchRegionId","true")
    
    query = query + whereIn;
 // Temporarily store inbound payload as property   
    message.setProperty("MappedBody", stringWriter.toString());
 // Set the query in the message body  
    message.setBody(query);
 }
 
 return message;
}