import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       //def body = message.getBody();
       //message.setBody(body + "Body is modified");
       //Headers 
       def map = message.getHeaders();
       String value = map.get("CamelHttpPath");
       def value1 = map.get("CamelHttpQuery");
       //def value2 = value1.substring(6,18);
       //message.setHeader("oldHeader", value + "modified");
       //message.setHeader("newHeader", "newHeader");
       //Properties 
       //value = map.get("oldProperty");
       //message.setProperty("oldProperty", value + "modified");
       
       //String path = value;
       String[] str;
       str = value.split('/');
      
       if(value.indexOf('/') == -1){
            message.setProperty("CompanyCode", str[0]);
       message.setProperty("asset", null);
       message.setProperty("costcenter", "");
       message.setProperty("subnum", "");
       message.setProperty("deprarea", "");
           }
       else if(str.length == 2){
            message.setProperty("CompanyCode", str[0]);
       message.setProperty("asset", null);
       message.setProperty("costcenter", "<SELECTIONCRITERIA><item><PARAMETER>TIMEDEPENDENTDATA</PARAMETER><FIELD>COSTCENTER</FIELD><SIGN>I</SIGN><OPTION>EQ</OPTION><LOW>" + str[1] + "</LOW><HIGH/></item></SELECTIONCRITERIA>");
       message.setProperty("subnum", "");
       message.setProperty("deprarea", "");
       }
       else if(str.length == 3){
           message.setProperty("CompanyCode", str[0]);
       message.setProperty("asset", str[2]);
       message.setProperty("costcenter", "<item><PARAMETER>TIMEDEPENDENTDATA</PARAMETER><FIELD>COSTCENTER</FIELD><SIGN>I</SIGN><OPTION>EQ</OPTION><LOW>" + str[1] + "</LOW><HIGH/></item>");
       message.setProperty("subnum", "");
       message.setProperty("deprarea", "");
       }
       else if(str.length == 4){
           message.setProperty("CompanyCode", str[0]);
       message.setProperty("asset", str[2]);
       message.setProperty("costcenter", "<item><PARAMETER>TIMEDEPENDENTDATA</PARAMETER><FIELD>COSTCENTER</FIELD><SIGN>I</SIGN><OPTION>EQ</OPTION><LOW>" + str[1] + "</LOW><HIGH/></item>");
       message.setProperty("subnum", "<item><PARAMETER>GENERALDATA</PARAMETER><FIELD>SUBNUMBER</FIELD><SIGN>I</SIGN><OPTION>EQ</OPTION><LOW>" + str[3] + "</LOW><HIGH/></item>");
       message.setProperty("deprarea", "");
       }
       else if(str.length == 5){
           message.setProperty("CompanyCode", str[0]);
       message.setProperty("asset", str[2]);
       message.setProperty("costcenter", "<item><PARAMETER>TIMEDEPENDENTDATA</PARAMETER><FIELD>COSTCENTER</FIELD><SIGN>I</SIGN><OPTION>EQ</OPTION><LOW>" + str[1] + "</LOW><HIGH/></item>");
       message.setProperty("subnum", "<item><PARAMETER>GENERALDATA</PARAMETER><FIELD>SUBNUMBER</FIELD><SIGN>I</SIGN><OPTION>EQ</OPTION><LOW>" + str[3] + "</LOW><HIGH/></item>");
       message.setProperty("deprarea", "<DEPRECIATIONAREA>" + str[4] + "</DEPRECIATIONAREA>");
       }
       //map = message.getProperties();
       //message.setProperty("CompanyCode", value);
       //message.setProperty("asset", value1);
       return message;
}