import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.osgi.framework.FrameworkUtil;
import com.sap.it.api.pd.BinaryData;

def Message processData(Message message) {
        def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 
        if (service == null){
          throw new IllegalStateException("Partner Directory Service not found");
        }

        def headers   = message.getHeaders();
	    def partnerID = headers.get("SAP_TPM_PARTNER_ID");
	    
       /* // Abhsihek -Strat
         def parameterName = "TARGET_MIG_XSD";

 

    def binaryData = service.getBinaryContent(partnerID, parameterName);
     byte[] binaryContent = binaryData.getData();
     message.setProperty("SAP_TPM_Target_Overlay_MIG", binaryContent);

    //Abhishek End	*/    
	    

        def recTargetOverlayMIGxsd = service.getParameter("TARGET_MIG_XSD", partnerID, BinaryData.class); // com.sap.it.api.pd.BinaryData.class
        byte[] binaryContent = recTargetOverlayMIGxsd.getData();

        message.setProperty("SAP_TPM_Target_Overlay_MIG", recTargetOverlayMIGxsd);
        message.setProperty("SAP_TPM_Target_Overlay_MIG1", binaryContent); //.toString()
        message.setBody(binaryContent);
        // message.setBody(recTargetOverlayMIGxsd);

        return message;
}