import org.apache.camel.Exchange;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.camel.CamelContext;
import java.util.List;
import java.lang.StringBuilder;
import org.apache.camel.Endpoint;
import org.apache.camel.component.xslt.XsltEndpoint;
import org.apache.camel.builder.xml.XsltBuilder;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.StringWriter;
import javax.xml.transform.Templates;
import net.sf.saxon.jaxp.TemplatesImpl;
import net.sf.saxon.s9api.XsltExecutable;
import java.io.ByteArrayOutputStream;

def Message processData(Message message) {
    //Body
    StringBuilder builder = new StringBuilder();
    def messageLog = messageLogFactory.getMessageLog(message);
    
    try {
        def header = message.getHeader("OVERLAY_MAPPING_XSLT", String.class)
        Exchange exchange = message.exchange;
        Endpoint mappingEndPoint;
        
        CamelContext context = message.exchange.getContext();
        List<Endpoint> endpoints = context.getEndpoints();
        for(Endpoint e : endpoints){
            if(e.getEndpointUri().contains(header)){
                mappingEndPoint = e;
            }
        }
        
        if (mappingEndPoint != null){
            builder.append("Matching Endpoint: ");
            builder.append(mappingEndPoint.getEndpointUri())
            builder.append("\n");
            builder.append("Class: " + mappingEndPoint.getClass().getName());
        }
        
        if(!(mappingEndPoint instanceof XsltEndpoint)){
            builder.append("Not a proper instance, exiting");
            messageLog.addAttachmentAsString("Endpoint Information:", builder.toString(), "text/plain");
            return message;
        }
        
        builder.append("\n");
        builder.append("Resource URI: ");
        builder.append(mappingEndPoint.getResourceUri());
        
        builder.append("\n");
        builder.append("Cache Cleared: ")
        builder.append(mappingEndPoint.cacheCleared);
        
        XsltBuilder xslt = mappingEndPoint.xslt;
        Source source = xslt.getUriResolver().resolve(mappingEndPoint.getResourceUri(), null);
        builder.append("\n");
        builder.append("Resource: ")
        builder.append(source.getClass().getName());
        
        try {
            StringWriter writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            TransformerFactory tFactory = TransformerFactory.newInstance();
            Transformer transformer = tFactory.newTransformer();
            transformer.transform(source,result);
            String strResult = writer.toString();
            messageLog.addAttachmentAsString("OVERLAY_MAPPING_MappingXMLFromSource", strResult, "application/xml");
        } catch (Exception e) {
            builder.append(e.getMessage());
        }
        
        try{
            Templates template = xslt.getTemplate();
            builder.append("\n");
            builder.append("Template Class: ")
            builder.append(template.getClass().getName());
            def executable = template.getImplementation();
            builder.append("\n");
            builder.append("Execuable Class: ")
            builder.append(executable.getClass().getName());
            
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            executable.export(baos);
            
            String strFromTemplate = baos.toString();
            messageLog.addAttachmentAsString("OVERLAY_MAPPING_MappingXMLFromTemplate", strFromTemplate, "application/xml");
        }catch(Exception e){
            builder.append(e.getMessage());
        }    
    }catch (Exception e){
        builder.append(e.getMessage());
    }
    messageLog.addAttachmentAsString("EndpointInformation", builder.toString(), "text/plain");
    return message;
}