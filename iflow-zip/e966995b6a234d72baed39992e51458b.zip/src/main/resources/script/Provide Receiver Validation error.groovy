// =============================================================================================
// This script sets the header attribute SAP_EDI_REC_Validation_Result_Code with an error
// code depending on the XML receiver validation result.
//
// History:
// 2022-12-21 SAP [GS] - Initially Created
// 2022-01-10 SAP [AB] - Exception Created in case of Fatal error
// =============================================================================================
import com.sap.gateway.ip.core.customdev.util.Message;
import org.apache.commons.lang.StringEscapeUtils;
import java.util.HashMap;

def Message processData(Message message) {
    message.setHeader("newHeader", "newHeader");
    //Properties
    def properties = message.getProperties();
    def validationResult = properties.get("SAP_XmlValidationResult");
    def validationResultCode = "OK";
    
    if (validationResult =~ /fatal errors:/) {
        validationResultCode = "ERROR";
        message.setHeader("SAP_EDI_REC_Validation_Result_Code", validationResultCode);
        throw new IllegalStateException("Fatal error found in Receiver Payload Validation");
    }
    
    message.setHeader("SAP_EDI_REC_Validation_Result_Code", validationResultCode);

    return message;
}