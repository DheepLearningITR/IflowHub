/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

       
       map = message.getProperties();
       ID_value1 = map.get("documentIDs"); // documentID
       Name_value2 = map.get("documentNames"); // documentName
       Filter_value3 = map.get("filterIDs"); // filterID
       
       def ID_Array = ID_value1.split(";") //documentID
       def Name_Array = Name_value2.split(";") // documentName
       def Filter_Array = Filter_value3.split(";") // filterID
       
       def i = map.get("Index"); // index for which document is called
       
       message.setProperty("documentID", ID_Array[i.toInteger()]);
       message.setProperty("documentName", Name_Array[i.toInteger()]);
       message.setProperty("filterID", Filter_Array[i.toInteger()]);

       message.setProperty("Index", i.toInteger()+1); //iterate to next document
       
       return message; 

    
}