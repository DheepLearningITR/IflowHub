import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    String logHeader = "";
    def body = message.getBody(java.lang.String) as String;
    def map = message.getProperties();
    logHeader = map.get("LogHeader");
    def ENABLE_PAYLOAD_LOGGING = map.get("ENABLE_PAYLOAD_LOGGING");
    if (logHeader == null || logHeader == "") {
        logHeader = "LogPayload";
    }
    def messageLog = messageLogFactory.getMessageLog(message);
    if ((messageLog != null) && (ENABLE_PAYLOAD_LOGGING.equalsIgnoreCase("TRUE"))) {

        messageLog.setStringProperty("Logging", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString(logHeader, body, "text/plain");
    }
    return message;
}