import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {
    String logHeader = "";
    def body = message.getBody(java.lang.String) as String;
    def header = message.getHeaders();
	
	def lookupEndpoint = header.get("CamelHttpPath")
	def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
	def value = valueMapApi.getMappedValue('Twenty5.Source', 'Twenty5.Source.HttpPath', lookupEndpoint, 'Twenty5.Target', 'Twenty5.Target.iFlow.PD.URL')
	
	if(!value){
		throw new Exception("target iFlow/endpoint not found/defined in the valueMapping table")
	}	
	message.setProperty("DestinationIFLOWEndpoint",value)
    return message;
}