// =============================================================================================
// This script removes the body
//
// History:
// 2024-05-10 SAP [MÖ]- Script created
// =============================================================================================
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) { 
    def body = " "; 
    message.setBody(body)  
    return message; 
} 