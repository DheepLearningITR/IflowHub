import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.osgi.framework.FrameworkUtil;
import com.sap.it.api.pd.BinaryData;

def Message processData(Message message) {
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 
    if (service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }

    def headers   = message.getHeaders();
	def partnerID = headers.get("SAP_TPM_ACTIVITYPARTNER_ID");
	def sourceMessageXsd = service.getParameter("SOURCE_MIG_XSD", partnerID, BinaryData.class); 
    byte[] binaryContent = sourceMessageXsd.getData();

    message.setProperty("SAP_TPM_Source_Message_XSD", sourceMessageXsd);
    message.setBody(binaryContent);

    return message;
}