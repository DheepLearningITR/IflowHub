// =============================================================================================
// This script is used for creating the type system related process direct address
// so that the corresponding ASSEMBLY_XSLT will be used for the assembly of the whole
// interchange.
//
// History:
// 2023-12-08 SAP [GS]- Document_standard mapped to common representation: GS1XML
// 2023-12-01 SAP [GS]- Document_standard mapped to common representation: UN-EDIFACT and ASC_X12
// 2023-07-12 SAP [GS]- Changed header to property
// 2022-07-12 SAP [GS]- Script created
// =============================================================================================
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    //Headers
    def properties = message.getProperties();
    
    
    // Get the document standad (type system) for the receiver side.
    def document_standard = properties.get("SAP_EDI_REC_Document_Standard");
    
    if (document_standard == "UNEDIFACT" || document_standard == "UN_EDIFACT"){
        document_standard = "UN-EDIFACT";
    }

    if (document_standard == "ASC-X12" || document_standard == "ASCX12"){
        document_standard = "ASC_X12";
    }

    if (document_standard == "GS1"){
        document_standard = "GS1XML";
    }

    def process_direct_address = "/tpm/assembly/" + document_standard;
   
    message.setHeader("SAP_B2B_Interchange_Assembly_ProcessDirectAddress",process_direct_address);


    return message;
}
