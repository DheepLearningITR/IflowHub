// =============================================================================================
// This flow step is responsible for spliting the flat file into fixed 128-character segments 
// History:
// 2025-08-14 SAP [MÖ] - Script created
// =============================================================================================
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    def flatFile = message.getBody(String)
    
    // Remove all newline characters
    flatFile = flatFile.replaceAll(/[\r\n]+/, "")
    // Convert to full 128-character segments, padding if needed
    List<String> segments = []
    int index = 0
    while (index < flatFile.length()) {
        int end = Math.min(index + 128, flatFile.length())
        String segment = flatFile.substring(index, end)
        if (segment.length() < 128) {
            segment = segment.padRight(128, ' ') // pad last segment
        }
        segments.add(segment)
        index += 128
    }

    // Build XML output with preserved whitespace
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.setDoubleQuotes(true)
    xml.Segments {
        segments.each { seg ->
            def satzart = seg.substring(0, 3)
            Segment(id: satzart) {
                mkp.yield(seg) // preserve raw text including spaces
            }
        }
    }

    message.setProperty("flatXML",writer.toString())
    return message
}
