
// =============================================================================================
// This script is responsible to check the DS entries and determine duplicates
//
// History:
// 2024-05-10 SAP [MÖ]- Script created
// =============================================================================================
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*
import java.util.HashMap;

def Message processData(Message message) {
    def headers                      =   message.getHeaders();
    def sapInterchangeControlNumber  =   headers.get("SAP_EDI_Interchange_Control_Number");
    def rows ="";
    def body = message.getBody(java.lang.String) as String 
    
    List<String> myList = Arrays.asList(body.split(" "));
    
    for(i=0;i < myList.size();i++){

        rows= rows + (myList[i]+"\n");
 
        if (myList[i] == sapInterchangeControlNumber){
            message.setProperty('SAP_EDI_Duplicate_Check','true')
        } 
    }
 
return message;
}    