/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
   
       //Properties 
       map = message.getProperties();
       def CWValue = map.get("cus_ContractWorkspaceID");
       def PRIDValue = map.get("PR_Ext_ID");
       def PRID_Str;
       def ExtensionFieldValue
       
       if (CWValue.length() > 0) {
        if (CWValue.contains('(')) {
            value = CWValue.substring(CWValue.indexOf('(')+1,CWValue.indexOf(')'))
            message.setProperty("CW_ID", value);
        } else {
            message.setProperty("CW_ID", "false");
        }
       } else {
           message.setProperty("CW_ID", "false");
       }
       
       if(!PRIDValue.equals("")) {
            if(PRIDValue.contains('$')) {
                PRID_Str = PRIDValue.substring(0, PRIDValue.indexOf('$'))
                message.setProperty("PR_Ext_ID", PRID_Str);
            }
       }
        /*
        if (PRID_Str.length() > 0) {
            ExtensionFieldValue = PRIDValue.substring(PRIDValue.indexOf('$') + 1, PRIDValue.length())
            message.setProperty("ExtensionField", ExtensionFieldValue);
        }
        */

       return message;
}