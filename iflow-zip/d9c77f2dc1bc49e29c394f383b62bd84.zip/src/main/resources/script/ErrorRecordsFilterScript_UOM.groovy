import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import java.util.HashMap;
import groovy.json.*;
import groovy.util.*;

def Message processData(Message message) {

	def body = message.getBody(String.class);
	def output;
	message.setProperty("isError", "true");
     
	//Setting the timestamp
	def now = new Date();
	message.setProperty("timestamp", now.format("yyyyMMddHHmmss", TimeZone.getTimeZone('UTC')));
	
	//parsing error message
	output = getErrorResponse(body,message); 
	if(!body.contains('error')) {
		message.setProperty("isError", "false");
	}
	message.setBody(output);
    
	return message;
}

def String getErrorResponse(String response,Message message) {

    def jsonSlurper = new JsonSlurper()
    def errorJson = jsonSlurper.parseText("{}");
    def units = message.getProperty("Units");
    def UOM =[];
    try{
    if(units != null || units != ""){
        UOM =  units.split(',') as List;
    }
    }catch(Exception e){
        UOM =[];
    }
   
    
    errorJson["Errors"] = [];
    int iSuccess = 0, iTotal = 0, iFailure =0;
	def errMsg, errObj, records;
	response.split("HTTP/1.1").each { unit ->
	
	   if("$unit".contains("201 Created") || "$unit".contains("200 OK"))
	   {
	       iSuccess = iSuccess + 1;
	   }
		if(!"$unit".contains("201 Created") && !"$unit".startsWith("--changeset")) {
	   		if(!"$unit".contains("200 OK") && !"$unit".startsWith("--changeset")) {
			errMsg = "$unit".substring("$unit".indexOf("{\"error\""), "$unit".indexOf("--changeset")).trim()
            errObj = jsonSlurper.parseText(errMsg.toString().replaceAll("@",""));
            iFailure = iFailure + 1;
            iTotal = iSuccess + iFailure - 1;
            errObj.error["unit"] =  UOM[iTotal];
            errorJson.Errors.push(errObj);
		    
		    }    
		}
	
	}

message.setProperty("iSuccess",iSuccess);
message.setProperty("iFailure",iFailure);
iTotal = iSuccess +  iFailure;
message.setProperty("iTotal",iTotal);
records = JsonOutput.toJson(errorJson);
return records;
	
}