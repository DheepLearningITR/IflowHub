import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext
import com.sap.gateway.ip.core.customdev.util.Message



def String getExternalSalesOrderId(String propertyName, MappingContext context) {
    String orderId = context.getHeader("externalSalesOrderId")
    return orderId
}


def Message createQuery(Message message) {
   
    def properties = message.getProperties();
    client = properties.get("P_Client")
    
    def headers = message.getHeaders();
    lang = headers.get("language")
    
    
    if (lang.length() == 0 ){
        lang = "EN"
        message.setProperty("P_Language",lang)
    }
    if (client.length() == 0 )
        message.setProperty("P_CustomQuery", "sap-language="+lang)
    else
        message.setProperty("P_CustomQuery", "sap-client=" + client + "&" + "sap-language=" + lang)
    return message
}