import com.sap.it.api.mapping.*;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String checkPercent(String prop_name,MappingContext context){
    
    def percentage="100";
    def prop = prop_name;
    if(prop.equals(percentage)){
        prop="0";
    }
    return prop;
    }