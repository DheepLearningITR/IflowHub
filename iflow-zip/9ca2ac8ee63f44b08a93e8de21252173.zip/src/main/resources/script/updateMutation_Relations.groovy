/**
 * Script Name: updateMutation
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script processes an incoming XML message to update an application's name based on a value mapping.
 *              It first checks if both the application name and ID are present in the XML message. Then, it looks for 
 *              a mapped name using a value mapping API. If a valid mapped name is found, it replaces the application's 
 *              name; otherwise, the current name is used. The script constructs a GraphQL update payload and sets it 
 *              as the message body. If the script is in debug mode, it adds the update payload as an attachment to the 
 *              message log for review.
 * 
 * Notes:
 * - The script processes the application name and ID from the XML and checks if a mapping exists for the name.
 * - If a valid mapped name is found, it replaces the application name with the mapped value. If no valid mapping exists,
 *   the original name is used.
 * - The update request is constructed in GraphQL format and set as the message body.
 */

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Retrieve message log for debugging purposes
    def messageLog = messageLogFactory.getMessageLog(message)
    def traceLevel = message.getProperty("TraceLevel")

    // Retrieve tag name property
    def tagName = message.getProperty("TagNameApplication")?.toString()?.trim()

    // Parse the incoming XML message
    def xml = new XmlSlurper().parseText(message.getBody(String))
    
    // Extract the <Application> element from the XML
    def application = xml.'**'.find { it.name() == 'Application' }

    if (!application) {
        throw new RuntimeException("No <Application> element found in input XML.")
    }

    // Extract the application name and ID from the XML
    def currentName = application.update?.Name?.text() ?: application.Name?.text()
    def factSheetId = application.Id.text()?.trim()

    // Ensure that both name and ID are present
    if (!currentName || !factSheetId) {
        throw new RuntimeException("Application Name or Id is missing or empty in the input XML.")
    }

    // Set the fact sheet ID for further use
    message.setProperty("updateFactsheetID", factSheetId)

    // Initialize the ValueMapping API for mapping technical names to LeanIX labels
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    
    // Retrieve the mapped name for the application using ValueMapping API
    def mappedName = valueMapApi.getMappedValue("SAPPO_Component", "Name", currentName, "LeanIX_Application", "Label")

    // Decide the new name to use: either the mapped name or the current name
    def newName = currentName
    if (mappedName && mappedName.trim() && mappedName.trim() != "...") {
        // Use mappedName if it is valid
        newName = mappedName.trim()
    }

    // Prepare the patch list for GraphQL update
    def patchList = [
        [
            op   : "replace",
            path : "/name",
            value: newName
        ]
    ]

    // If the tagName is present and not empty, add it to the patch list
    if (tagName) {
        def tagsJsonString = "[{\"tagName\":\"${tagName}\"}]"
        patchList << [
            op   : "add",
            path : "/tags",
            value: tagsJsonString
        ]
    }

    // Construct the GraphQL update payload
    def graphqlBody = [
        variables: [
            patches: patchList
        ]
    ]

    // Set the content type to JSON and add the GraphQL payload as the message body
    message.setHeader("Content-Type", "application/json")
    def jsonBody = JsonOutput.toJson(graphqlBody)
    message.setBody(jsonBody)

    // If the trace level is "debug", add the update payload as an attachment to the message log for review
    if (traceLevel == "debug" && messageLog) {
        messageLog.addAttachmentAsString("Update Payload", jsonBody, "application/json")
    }

    return message
}
