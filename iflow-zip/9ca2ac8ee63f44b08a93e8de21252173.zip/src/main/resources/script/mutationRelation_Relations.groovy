/**
 * Script Name: MutationRelation
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script processes the incoming message containing integrated configurations and creates or updates the 
 *              relations between applications based on the provided fact sheet IDs. The script generates mutations for 
 *              associating applications as either providers or consumers, depending on the configuration. It also supports 
 *              simulation mode, where it logs the changes without performing any actual updates.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Document
import groovy.json.JsonOutput

Message processData(Message message) {
    def isSimulation = message.getProperty("isSimulationModeActive") == "true"

    def applicationIdMap = message.getProperty("ApplicationIDHashMap") ?: [:]
    def relationHashMap = message.getProperty("RelationHashMap") ?: [:]
    def factSheetMap = message.getProperty("FactSheetMap") ?: [:]

    def body = message.getBody(java.lang.String) as String
    def doc = parseXml(body)

    def externalId = doc.getElementsByTagName("externalID").item(0)?.textContent?.trim()
    def factSheetId = factSheetMap[externalId]
    def displayName = doc.getElementsByTagName("factsheetname").item(0)?.textContent?.trim() ?: externalId

    def sender = doc.getElementsByTagName("Sender").item(0)?.textContent?.trim()

    def receiverList = []
    def receivers = doc.getElementsByTagName("Receiver")
    for (int i = 0; i < receivers.length; i++) {
        def val = receivers.item(i)?.textContent?.trim()
        if (val) receiverList << val
    }

    def mutationBlocks = []
    def patchIndex = 1

    def involvedAppIds = []
    def applicationsToAddAsProvider = []
    def applicationsToAddAsConsumer = []

    def senderId = applicationIdMap[sender]
    if (senderId) {
        involvedAppIds << [id: senderId, type: "Provider"]
        applicationsToAddAsProvider << sender
    }

    receiverList.each {
        def id = applicationIdMap[it]
        if (id) {
            involvedAppIds << [id: id, type: "Consumer"]
            applicationsToAddAsConsumer << it
        }
    }

    def existingRelations = relationHashMap[externalId] ?: []
    def missingRelations = involvedAppIds.findAll { !existingRelations.contains(it.id) }

    def resultMessage = new StringBuilder()

    // 🆕 New FactSheet in simulation mode
    if (!factSheetMap.containsKey(externalId) && isSimulation) {
        def parts = []
        if (sender) {
            parts << "sender ${sender}"
        }
        if (receiverList) {
            parts << (receiverList.size() == 1
                ? "receiver ${receiverList[0]}"
                : "receivers ${receiverList.join(', ')}")
        }

        resultMessage << "FactSheet \"${displayName}\" (\"NEW_INTERFACE\") would be created and extended with ${parts.join(' and ')}."
        def text = resultMessage.toString()
        message.setProperty("ApplicationRelationResult", text)
        message.setBody(text)
        return message
    }

    // 🔁 No updates needed
    if (missingRelations.isEmpty()) {
        resultMessage << "FactSheet \"${displayName}\" (\"${factSheetId}\") has no relation updates."
        def text = resultMessage.toString()
        message.setProperty("ApplicationRelationResult", text)

        if (isSimulation) {
            message.setBody(text)
        } else {
            message.setProperty("NoRelationUpdate", "true")
            message.setBody("")
        }

        return message
    }

    // ✏️ Description of updates (simulation or real)
    resultMessage << "FactSheet \"${displayName}\" (\"${factSheetId}\") "
    resultMessage << (isSimulation ? "would be extended with" : "was extended with")

    if (applicationsToAddAsProvider) {
        resultMessage << " sender application"
        resultMessage << (applicationsToAddAsProvider.size() > 1 ? "s " : " ")
        resultMessage << "\"${applicationsToAddAsProvider.join(' and ')}\""
    }

    if (applicationsToAddAsConsumer) {
        if (applicationsToAddAsProvider) resultMessage << " and"
        resultMessage << " receiver application"
        resultMessage << (applicationsToAddAsConsumer.size() > 1 ? "s " : " ")
        resultMessage << "\"${applicationsToAddAsConsumer.join(' and ')}\""
    }

    resultMessage << "."

    def finalText = resultMessage.toString()
    message.setProperty("ApplicationRelationResult", finalText)

    if (isSimulation) {
        message.setBody(finalText)
        return message
    }

    // 🛠️ Build mutations
    missingRelations.each { rel ->
        def relationType = (rel.type == "Provider") ? "relInterfaceToProviderApplication" : "relInterfaceToConsumerApplication"
        mutationBlocks << buildSingleMutation(factSheetId, relationType, rel.id, patchIndex++)
    }

    if (!mutationBlocks.isEmpty()) {
        def mutationQuery = "mutation {\n${mutationBlocks.join("\n\n")}\n}"
        message.setBody(JsonOutput.toJson([query: mutationQuery]))
    } else {
        message.setProperty("NoRelationUpdate", "true")
        message.setBody("")
    }

    return message
}

Document parseXml(String xmlString) {
    def factory = DocumentBuilderFactory.newInstance()
    factory.setNamespaceAware(true)
    def builder = factory.newDocumentBuilder()
    return builder.parse(new ByteArrayInputStream(xmlString.getBytes("UTF-8")))
}

String buildSingleMutation(String factSheetId, String path, String appId, int patchIndex) {
    return """  upd${patchIndex}: updateFactSheet(id: \"${factSheetId}\", validateOnly: false, patches: [
    {
      op: add,
      path: \"/${path}/new_${patchIndex}\",
      value: \"{\\\"factSheetId\\\": \\\"${appId}\\\"}\"
    }
  ]) {
    factSheet {
      id
      name
    }
  }"""
}
