/**
 * Script Name: addSimulationOutput
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script generates and formats a simulation output or flow log, depending on the simulation mode.
 *              It processes the incoming message body and formats the text according to certain rules.
 *              Specifically, it inserts line breaks after periods, unless the period is inside double quotes.
 * 
 * Notes:
 * - The script processes the message to format the body and adds a detailed header to the log.
 * - If the script is in simulation mode, it generates a message that describes what would happen.
 * - If not in simulation mode, it logs what actually happened.
 * - The generated log is added as an attachment to the message log for further review.
 */
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Check if the script is running in simulation mode
    def isSimulation = message.getProperty("isSimulationModeActive")?.toString()?.toBoolean()

    // Retrieve the message log to add attachments if necessary
    def messageLog = messageLogFactory.getMessageLog(message)

    // Set the header title based on the simulation mode
    def headerTitle = isSimulation ? "Simulation Output Relation" : "FlowLogApplicationRelation"

    // Prepare the log header with appropriate formatting
    def logHeader = new StringBuilder()
    logHeader << "=".multiply(134) + "\n"
    logHeader << (isSimulation ? "Simulation Output Relation" : "FlowLogApplicationRelation").center(134) + "\n"
    logHeader << "=".multiply(134) + "\n"
    logHeader << (isSimulation 
        ? "This output shows which FactSheets would be updated in LeanIX based on interface and application relations from SAP PO/PI."
        : "This output shows which FactSheets were updated in LeanIX based on interface and application relations from SAP PO/PI.") + "\n"

    // Add separator for readability in the output
    def separator = "\n" + "-".multiply(120) + "\n\n"
    def relationBlock = new StringBuilder()

    // Retrieve the body text from the message
    def bodyText = message.getBody(String)

    // Format the text by inserting a newline after each period, unless the period is inside quotation marks
    def formatted = new StringBuilder()
    boolean inQuotes = false

    for (int i = 0; i < bodyText.length(); i++) {
        char c = bodyText.charAt(i)

        // Toggle quote tracking if unescaped quote found
        if (c == '"' && (i == 0 || bodyText.charAt(i - 1) != '\\')) {
            inQuotes = !inQuotes
        }

        formatted.append(c)

        // If a period is outside quotes, insert newline
        if (c == '.' && !inQuotes) {
            formatted.append('\n')
        }
    }

    // Append the formatted text to the relationBlock
    relationBlock << formatted.toString()

    // Combine the log header, separator, and formatted body text
    def finalOutput = new StringBuilder()
    finalOutput << logHeader
    finalOutput << separator
    finalOutput << relationBlock.toString()

    // Set the formatted output as the message body
    message.setBody(finalOutput.toString())

    // If the message log is available, add the generated output as an attachment for review
    if (messageLog) {
        messageLog.addAttachmentAsString(headerTitle, finalOutput.toString(), "text/plain")
    }

    // Return the updated message
    return message
}
