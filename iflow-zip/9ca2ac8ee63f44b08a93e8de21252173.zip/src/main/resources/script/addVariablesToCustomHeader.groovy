/**
 * Script Name: addVariablesToCustomHeader
 * Author: Christian Riesener
 * Date: 2024-05-10
 * Description: This script analyzes messages from LeanIX in SAP to count and log the number of successful updates and errors.
 *              It only performs this analysis when not in simulation mode, ensuring that actual data manipulation is tracked without interference.
 *
 * Modifications:
 * - 2024-05-13 - Comment added - Christian Riesener
 *
 * Notes:
 * - The script parses JSON responses to identify "errors" and "data" elements, counting their occurrences to determine success and error rates.
 * - It logs the counts as custom header properties in the message, which can be useful for auditing and troubleshooting integration flows.
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    // Retrieve the message log for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    // Check if simulation mode is active using a property from the message.
    def isSimulationModeActive = message.getProperty("isSimulationModeActive").toBoolean();
    def messageBody = message.getBody(String);

    // Initialize counters for errors and successful updates.
    int countErrors = 0;
    int countNoErrors = 0;

    // Process error and success counts only if not in simulation mode.
    if (!isSimulationModeActive) {
        // Parse the message body to count successful created/updated factsheets
        countNoErrors = (messageBody =~ "\\*\\*\\* Technical Details from SAP PO \\*\\*\\*").count;
        countErrors = message.getProperty("icosFiltered") - countNoErrors;
    }

    // Log the counts of successful updates and errors as custom header properties.
    messageLog.addCustomHeaderProperty("__LeanIX Inserted/Updated - Successful", countNoErrors.toString());
    messageLog.addCustomHeaderProperty("__LeanIX not Inserted/Updated - Error", countErrors.toString() - 1);

    // Return the modified message.
    return message;
}
