/**
 * Script Name: createMutation
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script processes incoming XML messages, maps application names, and generates a mutation request 
 *              to create or update an application in a system. It ensures that the application name is mapped correctly 
 *              (if a mapping exists), formats the external ID as a JSON string, and prepares a GraphQL mutation 
 *              for further processing. If running in debug mode, the mutation request is added as an attachment to the message.
 * 
 * Notes:
 * - The script performs an automatic mapping of application names using a value mapping API.
 * - It creates a mutation request in the format expected by the target system, with the application name, description, 
 *   external ID, and optionally a tag if available.
 * - The mutation request is generated as a JSON object and can be reviewed in debug mode.
 */

import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Retrieve message log for attaching debug information if needed
    def messageLog = messageLogFactory.getMessageLog(message)
    def traceLevel = message.getProperty("TraceLevel")
    def tagName = message.getProperty("TagNameApplication")?.toString()?.trim() // Retrieve the tag name property

    // Parse the incoming XML payload
    def xml = new XmlSlurper().parseText(message.getBody(String))
    
    // Extract the <Application> element from the XML payload
    def application = xml.'**'.find { it.name() == 'Application' }
    if (!application) {
        throw new RuntimeException("No <Application> element found in input XML.")
    }

    // Extract the application name from the <Application> element
    def currentName = application.create?.Name?.text() ?: application.Name?.text()
    if (!currentName) {
        throw new RuntimeException("Application Name missing in the input XML.")
    }

    // Retrieve the value mapping for the application name, if available
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def mappedName = valueMapApi.getMappedValue("SAPPO_Component", "Name", currentName, "LeanIX_Application", "Label")

    // Finalize the application name: use mapped name if available, otherwise use the current name
    def finalName = (mappedName && mappedName.trim() != "..." && mappedName.trim()) ? mappedName.trim() : currentName

    // Format the external ID as a JSON string
    def externalIdJsonString = JsonOutput.toJson([
        type: "ExternalId",
        externalId: currentName
    ])

    // Initialize the patch list with the description and externalId
    def patchList = [
        [
            op    : "add",
            path  : "/description",
            value : "Factsheet created automatically by SAP Cloud Integration"
        ],
        [
            op    : "add",
            path  : "/externalId",
            value : externalIdJsonString
        ]
    ]

    // Add the tag if the tagName is provided and not empty
    if (tagName) {
        // Use the tagName as part of a list of objects, correctly formatted for GraphQL
        def tagsJsonString = "[{\"tagName\":\"${tagName}\"}]"
        patchList << [
            op    : "add",
            path  : "/tags",
            value : tagsJsonString // Correctly formatted as JSON string for tags
        ]
    }

    // Create the mutation request body in the required format
    def graphqlBody = [
        variables: [
            input: [
                type : "Application",
                name : finalName
            ],
            patches: patchList
        ]
    ]

    // Convert the mutation request body to a JSON string
    def jsonBody = JsonOutput.toJson(graphqlBody)
    
    // Set the JSON body as the message body
    message.setBody(jsonBody)

    // If the trace level is "debug", add the mutation request as an attachment to the message log for review
    if (traceLevel == "debug" && messageLog) {
        messageLog.addAttachmentAsString("Create Payload", jsonBody, "application/json")
    }

    return message
}
