/**
 * Script Name: SaveID
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script processes an incoming JSON payload, extracts information about a fact sheet (name and ID),
 *              and generates an XML payload containing the fact sheet data in a structured format.
 *              If the required information (name and ID) is missing in the JSON, an exception is thrown.
 * 
 * Notes:
 * - The script expects a JSON payload containing a "createFactSheet" object with a "factSheet" object inside.
 * - If the required fact sheet data (name and ID) is missing, the script throws a runtime exception.
 * - The script generates an XML string with the extracted data and sets it as the message body.
 */

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    // Retrieve the incoming JSON message body
    def body = message.getBody(String)
    
    // Parse the JSON body into a Groovy object
    def json = new JsonSlurper().parseText(body)

    // Extract the 'factSheet' data from the JSON
    def factSheet = json.data?.createFactSheet?.factSheet

    // Check if 'factSheet' is present in the JSON; if not, throw an exception
    if (!factSheet) {
        throw new RuntimeException("No createFactSheet -> factSheet found in JSON!")
    }

    // Extract the 'name' and 'id' from the 'factSheet'
    def name = factSheet.name
    def id = factSheet.id

    // If 'name' or 'id' are missing, throw an exception
    if (!name || !id) {
        throw new RuntimeException("Name or Id missing in createFactSheet!")
    }

    // Build the XML string with the extracted 'name' and 'id'
    def applicationsXml = new StringBuilder()
    applicationsXml << "<?xml version='1.0' encoding='UTF-8'?>"
    applicationsXml << "<Applications>"
    applicationsXml << "<Application>"
    applicationsXml << "<create>"
    applicationsXml << "<Name>${escapeXml(name)}</Name>"
    applicationsXml << "<Id>${escapeXml(id)}</Id>"
    applicationsXml << "</create>"
    applicationsXml << "</Application>"
    applicationsXml << "</Applications>"

    // Set the generated XML string as the message body
    message.setBody(applicationsXml.toString())
    
    // Return the modified message
    return message
}

/**
 * Helper method to safely escape XML special characters.
 * @param input The string to be escaped for XML.
 * @return The XML-safe version of the input string.
 */
def escapeXml(String input) {
    input.replace("&", "&amp;")
         .replace("<", "&lt;")
         .replace(">", "&gt;")
         .replace("\"", "&quot;")
         .replace("'", "&apos;")
}
