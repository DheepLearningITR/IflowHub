import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import java.security.MessageDigest
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Parse the incoming XML payload
    def xml = new XmlSlurper().parseText(message.getBody(String))

    // Initialize variables for output
    def factSheetName = new StringBuilder()
    def externalID = ""
    def sender = ""
    def receivers = []
    
    // Extract relevant data from the XML
    def integratedConfiguration = xml.'**'.find { it.name() == 'IntegratedConfiguration' }

    // Check if IntegratedConfiguration exists
    if (!integratedConfiguration) {
        return message
    }

    def senderPartyID = integratedConfiguration.IntegratedConfigurationID.SenderPartyID.text() ?: "";
    def senderComponentID = integratedConfiguration.IntegratedConfigurationID.SenderComponentID.text();
    def interfaceName = integratedConfiguration.IntegratedConfigurationID.InterfaceName.text();
    def interfaceNamespace = integratedConfiguration.IntegratedConfigurationID.InterfaceNamespace.text();
    def receiverPartyID = integratedConfiguration.IntegratedConfigurationID.ReceiverPartyID.text() ?: "" ;
    def receiverComponentID = integratedConfiguration.IntegratedConfigurationID.ReceiverComponentID.text() ?: "";

    // Extract Receiver components and build receivers list
    def receiverComponents = integratedConfiguration.Receivers.'**'.findAll { it.name() == 'Receiver' }
    receiverComponents.each { receiver ->
        def receiverText = receiver.PartyID.text() ?: "" + (receiver.ComponentID.text() ? "|${receiver.ComponentID.text()}" : "")
        receivers << receiverText
    }

    // Initialize the Value Mapping API
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    // Get the mapped values for sender and receiver
    def labelSender = valueMapApi.getMappedValue("SAPPO_Component", "Name", senderPartyID +"|"+ senderComponentID , "LeanIX_Application", "Label");
    def labelReceiver = valueMapApi.getMappedValue("SAPPO_Component", "Name", receiverPartyID +"|"+ receiverComponentID , "LeanIX_Application", "Label");

    // Build factSheetName with "from" and "to" format
    factSheetName << "${interfaceName}|${interfaceNamespace} from "
    
    // Apply value mapping for the sender
    if (labelSender && labelSender != '...') {
        sender = labelSender
        factSheetName << sender
    } else {
        sender = senderPartyID + (senderComponentID ? "|${senderComponentID}" : "")
        factSheetName << sender
    }
    
    // Apply value mapping for the receiver (similar to sender logic)
    if (labelReceiver && labelReceiver != '...') {
        factSheetName << " to ${labelReceiver}"
    } else {
        // Ensure receiver info is included even if labelReceiver is empty or invalid
        factSheetName << " to ${receiverComponents.collect { it.PartyID.text() + (it.ComponentID.text() ? "|${it.ComponentID.text()}" : "") }.join(', ')}"
    }

    String hashGuid = generateHashGuid(senderPartyID, senderComponentID, interfaceName, interfaceNamespace, receiverPartyID, receiverComponentID);
    
    // Create the new XML output
    def combinedXml = """
<ICO>
    <factsheetname>${factSheetName.toString()}</factsheetname>
    <externalID>${hashGuid}</externalID>
    <Sender>${sender}</Sender>
    <Receivers>
        ${receivers.collect { "<Receiver>${it}</Receiver>" }.join("\n        ")}
    </Receivers>
</ICO>
"""
    
    // Set the new XML as the body of the message
    message.setBody(combinedXml.toString())

    return message
}

// Function to generate the external ID (Hashing the relevant fields)
String generateHashGuid(String senderPartyID, String senderComponentID, String interfaceName, String interfaceNamespace, String receiverPartyID, String receiverComponentID) {
    // Concatenate the input fields with "|" separator
    String inputString = [senderPartyID, senderComponentID, interfaceName, interfaceNamespace, receiverPartyID, receiverComponentID].join('|')

    // Create MessageDigest object for SHA-256
    MessageDigest digest = MessageDigest.getInstance("SHA-256")

    // Calculate the hash value
    byte[] hashBytes = digest.digest(inputString.getBytes("UTF-8"))

    // Convert the byte array to a hexadecimal string
    String guid = hashBytes.collect { String.format("%02x", it) }.join()

    return guid
}
