/**
 * Script Name: createHashmapForFactsheetIds
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script processes an incoming XML payload containing multiple application entries. It iterates over the 
 *              applications and determines whether each one should be created or updated based on the presence of "create" 
 *              or "update" nodes. It creates a mapping of application names to their corresponding IDs and logs the actions 
 *              (create, update, or no changes) for each application. In simulation mode, the script logs which applications 
 *              would be created or updated without actually performing any changes.
 */

import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {
    def isSimulation = message.getProperty("isSimulationModeActive") == "true"
    def messageLog = messageLogFactory.getMessageLog(message)

    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)

    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)

    def applicationIdMap = new HashMap<String, String>()
    def flowLogLines = []

    xml.'**'.findAll { it.name() == 'Application' }.each { application ->
        def createNode = application.create
        def updateNode = application.update
        def name, id

        if (createNode && createNode.size() > 0) {
            name = createNode.Name.text()
            id = createNode.Id.text()
            if (isSimulation) {
                flowLogLines << "Application \"${name}\" (${id}) would be created."
            } else {
                flowLogLines << "Application \"${name}\" (${id}) was created."
            }
            applicationIdMap.put(name, id)
        } 
        else if (updateNode && updateNode.size() > 0) {
            name = updateNode.Name.text()
            id = updateNode.Id.text()
            if (isSimulation) {
                flowLogLines << "Application \"${name}\" (${id}) would be updated."
            } else {
                flowLogLines << "Application \"${name}\" (${id}) was updated."
            }
            applicationIdMap.put(name, id)
        } 
        else {
            name = application.Name.text()
            id = application.Id.text()

            def mappedName = valueMapApi.getMappedValue("SAPPO_Component", "Name", name, "LeanIX_Application", "Label")
            mappedName = (mappedName && mappedName.trim() != "...") ? mappedName.trim() : null
            def finalName = mappedName ?: name

            flowLogLines << "Application \"${finalName}\" (${id}) had no updates."
            applicationIdMap.put(finalName, id)
        }
    }

    message.setProperty("ApplicationIDHashMap", applicationIdMap)

    if (messageLog) {
        def headerTitle = isSimulation ? "Simulation Output Application" : "FlowLogApplications"
        def logHeader = new StringBuilder()

        if (isSimulation) {
            logHeader << """\
======================================================================================================================================
                                                           Simulation Output
======================================================================================================================================
This output shows which applications would be created or updated.
It is based on technical names and potential replacements.
"""
        } else {
            logHeader << """\
======================================================================================================================================
                                                       FlowLogApplications
======================================================================================================================================
This output shows which applications were created or updated.
It is based on technical names and potential replacements.
"""
        }

        def separator = "\n" + "-".multiply(120) + "\n\n"
        def finalOutput = logHeader.toString() + separator + flowLogLines.join("\n")

        messageLog.addAttachmentAsString(headerTitle, finalOutput, "text/plain")
    }

    return message
}
