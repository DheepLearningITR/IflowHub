/**
 * Script Name: logLeanIXQueryResponse
 * Author: Christian Riesener
 * Date: 2024-05-10
 * Description: This script is designed to log the response body of a message from LeanIX queries. It captures the entire message body
 *              and logs it as a plain text attachment within the message log for auditing and debugging purposes.
 *
 * Modifications:
 * - 2024-05-13 - Comment added - Christian Riesener
 *
 * Notes:
 * - This script is only used when TraceLevel = "debug"
 */
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    // Retrieve the message log object for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // Add the entire message body as a plain text attachment to the message log, tagged as "LeanIX Query Response".
    messageLog.addAttachmentAsString("LeanIX Query Response", message.getBody(String), "text/plain");    

    // Return the modified (or unmodified) message object back to the process flow.
    return message;
}
