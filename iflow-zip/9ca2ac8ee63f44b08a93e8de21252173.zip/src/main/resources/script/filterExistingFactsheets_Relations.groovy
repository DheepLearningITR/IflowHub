/**
 * Script Name: filterExistingFactsheets
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script processes an incoming XML message containing interface configurations and relates them to 
 *              existing fact sheets from a system. It checks whether applications are already present in the system 
 *              and either updates their information or creates new entries. The script also handles simulation mode 
 *              to log what changes would be made without actually applying them.
 * 
 * Notes:
 * - The script uses value mapping to check whether application names exist and associates them with corresponding fact sheets.
 * - In simulation mode, the script logs the changes that would occur, including new or updated applications.
 * - The XML output contains both existing applications (with IDs) and new applications (without IDs).
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.XmlUtil
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

Message processData(Message message) {
    // Retrieve the ValueMapping API for application name mappings
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    
    // Check if the script is running in simulation mode
    def isSimulation = message.getProperty("isSimulationModeActive") == "true"

    // Retrieve and clean the incoming XML body
    def payloadXml = message.getBody(String)?.replaceAll(/^[\s\uFEFF\x00-\x1F]+/, '')?.trim()
    if (!payloadXml || payloadXml.isEmpty()) {
        throw new Exception("SOAP payload body could not be extracted or is empty.")
    }

    // Parse the XML content and find the relevant interface configurations
    def envelope = new XmlSlurper(false, false).parseText(payloadXml)
    def xml = envelope.'**'.find { it.name().toString().endsWith('IntegratedConfigurationReadResponse') }
    if (!xml) {
        throw new Exception("IntegratedConfigurationReadResponse not found in SOAP body.")
    }

    // Retrieve the LeanIX applications JSON from the message property
    def leanixJsonBytes = message.getProperty("LeanIXApplications") as byte[]
    def leanixJsonText = new String(leanixJsonBytes, "UTF-8")
    if (!leanixJsonText) {
        throw new Exception("LeanIXApplications property not found or empty.")
    }

    // Parse the LeanIX JSON to extract fact sheet data
    def leanixJson = new JsonSlurper().parseText(leanixJsonText)
    def externalIdToFactSheetId = [:]
    def externalIdToDisplayName = [:]
    def idToDisplayName = [:]
    def idToTags = [:]

    leanixJson.data.allFactSheets.edges.each { edge ->
        def node = edge.node
        def displayName = node.displayName?.trim()
        def externalId = node.externalId?.externalId?.trim()
        def fsId = node.id

        if (externalId) externalIdToFactSheetId[externalId] = fsId
        if (externalId) externalIdToDisplayName[externalId] = displayName
        if (fsId) idToDisplayName[fsId] = displayName
        if (fsId) idToTags[fsId] = node.tags
    }

    // Initialize lists to track applications to create or update
    def applicationsToCreate = []
    def applicationsToUpdate = []
    def knownApplicationsXml = new StringBuilder("<Applications>")
    def newApplicationsXml = new StringBuilder("<Applications>")
    def participants = []

    // Iterate through the integrated configurations and process the sender and receiver applications
    xml.IntegratedConfiguration.each { ic ->
        def senderParty = ic.IntegratedConfigurationID.SenderPartyID?.text()?.trim() ?: ""
        def senderComponent = ic.IntegratedConfigurationID.SenderComponentID?.text()?.trim() ?: ""
        def sender = "${senderParty}|${senderComponent}"

        def receivers = []
        ic.Receivers.'**'.findAll { it.name() == "Receiver" }.each { receiver ->
            def receiverPartyID = receiver.PartyID?.text()?.trim() ?: ""
            def receiverComponentID = receiver.ComponentID?.text()?.trim() ?: ""
            if (receiverPartyID || receiverComponentID) {
                receivers << "${receiverPartyID}|${receiverComponentID}"
            }
        }

        // Add the sender and receivers to the list of participants
        if (sender != "|") participants << sender
        receivers.unique().each { receiver ->
            if (receiver != "|") participants << receiver
        }
    }

    // Process each unique participant (application) and check if it already exists in LeanIX
    participants.unique().each { technicalName ->
        def mappedLabel = valueMapApi.getMappedValue("SAPPO_Component", "Name", technicalName, "LeanIX_Application", "Label")
        def isValidMapping = mappedLabel && mappedLabel != "..." && mappedLabel.trim()
        def trimmedMapped = isValidMapping ? mappedLabel.trim() : null

        // Check if the application exists in LeanIX using the externalId or mapped name
        def factSheetIdFromExternal = externalIdToFactSheetId[technicalName]
        def factSheetIdFromMapped = trimmedMapped ? externalIdToFactSheetId[trimmedMapped] : null
        def finalFactSheetId = factSheetIdFromExternal ?: factSheetIdFromMapped

        // If a fact sheet ID exists, generate XML for the known applications
        if (finalFactSheetId) {
            knownApplicationsXml.append("<Application><Name>${escapeXml(technicalName)}</Name><Id>${finalFactSheetId}</Id>")

            def tags = idToTags[finalFactSheetId]
            if (tags && tags.size() > 0) {
                def cleanedTags = tags.collect { cleanTags(it) }.join(', ')
                knownApplicationsXml.append("<Tag>${cleanedTags}</Tag>")
            } else {
                knownApplicationsXml.append("<Tag></Tag>")
            }

            knownApplicationsXml.append("</Application>")

            // If in simulation mode, check if the application needs to be updated
            if (isSimulation && factSheetIdFromExternal) {
                def currentDisplayName = externalIdToDisplayName[technicalName]
                if (trimmedMapped && trimmedMapped != currentDisplayName) {
                    applicationsToUpdate << "${technicalName} → ${trimmedMapped}"
                } else if (!isValidMapping && currentDisplayName && currentDisplayName != technicalName) {
                    applicationsToUpdate << "${technicalName} → ${technicalName} (update displayName)"
                }
            }

        } else {
            // If no fact sheet ID is found, add the application to the new applications XML
            newApplicationsXml.append("<Application><Name>${escapeXml(technicalName)}</Name></Application>")
            if (isSimulation) {
                applicationsToCreate << technicalName
            }
        }
    }

    // Close the XML tags
    knownApplicationsXml.append("</Applications>")
    newApplicationsXml.append("</Applications>")

    // Generate simulation output if in simulation mode
    if (isSimulation) {
        def outputBuilder = new StringBuilder()
        outputBuilder << "*** Simulation Mode: Application Mapping ***\n\n"

        if (applicationsToUpdate) {
            outputBuilder << "Applications to update (DisplayName mismatch or new mapping):\n"
            applicationsToUpdate.each { outputBuilder << " - ${it}\n" }
        }

        if (applicationsToCreate) {
            outputBuilder << "\nApplications that would be created:\n"
            applicationsToCreate.each { outputBuilder << " - ${it}\n" }
        }

        message.setProperty("ApplicationSimulationOutput", outputBuilder.toString())
    }

    // Combine the known and new applications into a final XML
    def combinedXml = new StringBuilder()
    combinedXml << "<?xml version='1.0' encoding='UTF-8'?>"
    combinedXml << "<Applications>"
    combinedXml << knownApplicationsXml.toString().replaceFirst("<Applications>", "").replaceFirst("</Applications>", "")
    combinedXml << newApplicationsXml.toString().replaceFirst("<Applications>", "").replaceFirst("</Applications>", "")
    combinedXml << "</Applications>"

    // Set the combined XML as the message body
    message.setBody(combinedXml.toString())
    return message
}

/**
 * Helper method to escape XML special characters.
 * @param input The string to be escaped for XML.
 * @return The XML-safe version of the input string.
 */
def escapeXml(String input) {
    input.replace("&", "&amp;")
         .replace("<", "&lt;")
         .replace(">", "&gt;")
         .replace("\"", "&quot;")
         .replace("'", "&apos;")
}

/**
 * Cleans the tags for XML compliance by removing unnecessary characters.
 * @param tags The tags to clean.
 * @return A cleaned version of the tags.
 */
def cleanTags(def tags) {
    if (tags instanceof Map) {
        tags = tags.values().join(", ")
    }
    if (tags instanceof String) {
        tags = tags.replaceAll("\\[name:", "").replaceAll("\\]", "").trim()
    }
    return tags
}
