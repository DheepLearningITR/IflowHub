/**
 * Script Name: SaveResponse
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script processes the `ApplicationRelationResult` property of the incoming message, which contains 
 *              information about the relations between applications (senders and receivers). It generates a human-readable 
 *              output that summarizes the updates, such as whether an application was extended with sender and/or receiver 
 *              applications. The output is built into a string and set as the message body.
 * 
 * Notes:
 * - The script processes a map of application relations and generates an output summarizing which applications were extended 
 *   with sender and receiver applications.
 * - If no updates were made to the relations, the script logs that there were no relation updates for the given fact sheet.
 */
import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    // Retrieve the ApplicationRelationResult property (a map of fact sheet relations)
    def relationResult = message.getProperty("ApplicationRelationResult") as Map ?: [:]
    
    // Initialize a StringBuilder to build the output
    def output = new StringBuilder()

    // Iterate through the relation results to process each fact sheet and its relations
    relationResult.each { factSheetLabel, relationInfo ->
        // Remove the fact sheet ID (in parentheses) to leave only the name
        def nameOnly = factSheetLabel.replaceFirst(/\s*\(.*?\)$/, '') 

        // Check if there were no relation updates for this fact sheet
        if (relationInfo == "no Update") {
            output << "${nameOnly} has no relation update.\n"
        } else {
            // Split the relation info by commas and process the senders and receivers
            def entries = relationInfo.split(/\s*,\s*/).toList()
            def senders = []
            def receivers = []

            // Iterate through the entries to categorize them into senders and receivers
            for (int i = 0; i < entries.size(); i += 2) {
                def type = entries[i]
                def appName = (i + 1 < entries.size()) ? entries[i + 1] : null
                if (appName) {
                    if (type.equalsIgnoreCase("Sender")) {
                        senders << appName
                    } else if (type.equalsIgnoreCase("Receiver")) {
                        receivers << appName
                    }
                }
            }

            // Construct the output string based on the senders and receivers
            if (!senders.isEmpty() || !receivers.isEmpty()) {
                output << "${nameOnly} was extended with"
                if (!senders.isEmpty()) {
                    output << " Sender application"
                    output << (senders.size() > 1 ? "s " : " ")
                    output << "\"${senders.join('\" and \"')}\""
                }
                if (!receivers.isEmpty()) {
                    if (!senders.isEmpty()) output << " and"
                    output << " Receiver application"
                    output << (receivers.size() > 1 ? "s " : " ")
                    output << "\"${receivers.join('\" and \"')}\""
                }
                output << ".\n"
            }
        }
    }

    // Set the generated output as the message body
    message.setBody(output.toString())
    return message
}
