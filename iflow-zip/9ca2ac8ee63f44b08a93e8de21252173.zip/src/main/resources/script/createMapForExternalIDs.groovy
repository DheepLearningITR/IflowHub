/**
 * Script Name: createMapForExternalIDs
 * Author: Christian Riesener
 * Date: 2024-05-10
 * Description: This script processes the Query JSON Response from LeanIX which contains the internal and externalIDs from all FactSheets . 
 *              It stores the mappings in a message property and conditionally logs these mappings if the trace level is set to debug. 
 *              This assists in tracking and managing FactSheet data integration and reconciliation processes.
 * 
 * Modifications:
 * - 2024-05-13 - Comment added - Christian Riesener
 * 
 * Notes: 
 * - The mappings of ExternalID to Internal FactSheet ID are stored in a HashMap and can be used by other processes downstream.
 * - Debugging logs include a detailed printout of all FactSheet mappings for verification and auditing purposes.
 * - The script uses Groovy's JsonSlurper for parsing JSON and extracting necessary data.
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper

def Message processData(Message message) {

    // Retrieve the message log object for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // Retrieve the trace level from the message properties to control logging detail.
    def traceLevel = message.getProperty("TraceLevel");
    
    // Initialize a HashMap to store FactSheet ID mappings.
    HashMap<String, String> factSheetMap = new HashMap<>();
    
    // Get the JSON response as a string from the message body.
    def jsonResponse = message.getBody(String);

    // Create an instance of JsonSlurper to parse the JSON response.
    JsonSlurper jsonSlurper = new JsonSlurper();
    
    // Parse the JSON data.
    def responseData = jsonSlurper.parseText(jsonResponse);

    // Iterate through each FactSheet data node, and if an external ID exists, map it to the FactSheet ID.
    responseData.data.allFactSheets.edges.each { edge ->
        if (edge.node.externalId != null) {
            factSheetMap.put(edge.node.externalId.externalId, edge.node.id)
        }
    }

    // Store the entire FactSheet ID map in a message property for use in subsequent processes.
    message.setProperty("FactSheetMap", factSheetMap);

    // If trace level is set to debug, log the mapping content as an attachment for review.
    if (traceLevel == "debug") {
        String content = factSheetMap.collect { key, value -> "$key: $value" }.join("\n");
        messageLog.addAttachmentAsString("FactSheetMap", content, "text/plain");
    }

    // Return the modified message.
    return message;
}
