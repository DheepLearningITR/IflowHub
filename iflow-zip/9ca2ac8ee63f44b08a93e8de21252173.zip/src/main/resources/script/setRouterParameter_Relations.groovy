/**
 * Script Name: setRouterParameter
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script evaluates whether an application should be created, updated or skipped based on the provided XML input.
 *              It uses a preloaded application mapping from message properties and value mapping via ValueMapping API.
 *              The result is written back into the message body as XML, and properties are set to control routing.
 * 
 * Notes: 
 * - If the application ID is missing, a create operation is triggered.
 * - If the application name matches the mapped display name AND required tag is present, no action is taken.
 * - If there is a mismatch in name or the tag is missing, an update operation is triggered.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import groovy.json.JsonSlurper

Message processData(Message message) {
    def isSimulation = message.getProperty("isSimulationModeActive") == "true"
    def tagNameRequired = message.getProperty("TagNameApplication")?.trim()

    def xmlRaw = message.getBody(String)
    def xml = new XmlSlurper().parseText(xmlRaw)
    def application = xml.'**'.find { it.name() == 'Application' }
    if (!application) throw new RuntimeException("No <Application> element found in input XML.")

    def currentName = application.Name?.text()?.trim()
    def factSheetId = application.Id?.text()?.trim()
    def currentTag = application.Tag?.text()?.trim()
    if (!currentName) throw new RuntimeException("Application Name is missing in the input XML.")

    // Read LeanIXApplications JSON and build externalId -> displayName map
    def leanixJsonBytes = message.getProperty("LeanIXApplications") as byte[]
    def leanixJsonText = new String(leanixJsonBytes, "UTF-8")
    if (!leanixJsonText) {
        throw new Exception("LeanIXApplications property not found or empty.")
    }

    def leanixJson = new JsonSlurper().parseText(leanixJsonText)
    def idToDisplayName = [:]
    leanixJson.data.allFactSheets.edges.each { edge ->
        def node = edge.node
        def fsId = node.id
        def displayName = node.displayName?.trim()
        if (fsId && displayName) {
            idToDisplayName[fsId] = displayName
        }
    }

    def create = !factSheetId
    def update = false

    if (!create && factSheetId) {
        def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
        def mappedName = valueMapApi.getMappedValue("SAPPO_Component", "Name", currentName, "LeanIX_Application", "Label")?.trim()
        def isValidMappedName = mappedName && mappedName != "..."
        def displayNameFromLeanIX = idToDisplayName[factSheetId]
        def nameMismatch = false
        if (displayNameFromLeanIX) {
            if (isValidMappedName) {
                nameMismatch = mappedName != displayNameFromLeanIX
            } else {
                nameMismatch = currentName != displayNameFromLeanIX
            }
        }

        def tagList = currentTag?.split(",")?.collect { it.trim() } ?: []
        def tagMissing = tagNameRequired && !(tagList.contains(tagNameRequired))

        update = nameMismatch || tagMissing
    }

    if (isSimulation) {
        def wrapperTag = create ? "create" : (update ? "update" : null)
        def newXml = new StringBuilder()
        newXml.append("<?xml version='1.0' encoding='UTF-8'?>\n")
        newXml.append("<Applications>\n")
        newXml.append("  <Application>\n")

        if (wrapperTag) {
            newXml.append("    <${wrapperTag}>\n")
            newXml.append("      <Name>${escapeXml(currentName)}</Name>\n")
            if (factSheetId) newXml.append("      <Id>${escapeXml(factSheetId)}</Id>\n")
            newXml.append("    </${wrapperTag}>\n")
        } else {
            newXml.append("    <Name>${escapeXml(currentName)}</Name>\n")
            if (factSheetId) newXml.append("    <Id>${escapeXml(factSheetId)}</Id>\n")
            if (currentTag) newXml.append("    <Tag>${escapeXml(currentTag)}</Tag>\n")
        }

        newXml.append("  </Application>\n")
        newXml.append("</Applications>")
        message.setBody(newXml.toString())
    }

    if (!isSimulation) {
        message.setProperty("ApplicationCreate", create)
        message.setProperty("ApplicationUpdate", update)
    }

    return message
}

def escapeXml(String input) {
    input.replace("&", "&amp;")
         .replace("<", "&lt;")
         .replace(">", "&gt;")
         .replace("\"", "&quot;")
         .replace("'", "&apos;")
}
