/**
 * Script Name: determineExternalId
 * Author: Christian Riesener
 * Date: 2024-05-10
 * Description: This script processes incoming SAP ICO XML messages to generate informaton of the interfaces and their corresponding descriptions for LeanIX.
 *              It constructs a FactSheet name based on existing LeanIX descriptions, handles simulation output for testing, and prepares properties for further processing.
 * 
 * Modifications:
 * - 2024-05-13 - Comment added - Christian Riesener
 * - 2024-11-13 - Tagging added in the SQL mutation
 * - 2025-03-06 - Tag added only if value exist
 * 
 * Notes:
 * - The script parses XML to extract interface details, utilizes value mapping for descriptions, and checks the existence of corresponding FactSheets in LeanIX.
 * - It dynamically generates and applies a unique hash GUID for interfaces to manage FactSheet identification.
 * - The script also provides simulation capabilities for testing without impacting live data, along with detailed debug outputs.
 * - During message processing, a mutation request for LeanIX is created, which either creates a new FactSheet or updates an existing one.
 * - If the trace level is set to "debug", the script attaches the output as an attachment to the message log for detailed review.
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.security.MessageDigest;
import groovy.json.JsonBuilder;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def isCreationNeeded = false;

def Message processData(Message message) {

    def simulationOutput = new StringBuilder();
    def traceLevel = message.getProperty("TraceLevel");
    def messageLog = messageLogFactory.getMessageLog(message);
    
    HashMap<String, String> factSheetMap = new HashMap<>();
    factSheetMap = message.getProperty("FactSheetMap");
    def jsonMutation = new JsonBuilder();
    
    // Check if Interface is already existing in LeanIX by checking with the externalId
    def ico = new XmlSlurper().parseText(message.getBody(String));
        //def icID = ico.'**'.find { it.name() == 'IntegratedConfigurationID' };
    
    def integratedConfigurations = ico.'**'.findAll { it.name() == 'IntegratedConfiguration' };

    def factSheetNames = [];
    def counter = 0;
    def mutation_requests = new StringBuilder ("mutation { ");
    integratedConfigurations.each { ic ->  
            counter++
            createOutput(ic, ico, factSheetMap, message, factSheetNames, simulationOutput, mutation_requests, counter);
    }
    
    def mutation_end = " } ";
    jsonMutation {
        query mutation_requests.toString() + mutation_end
    }
    
    // Save simulationOutput
    message.setProperty("simulationOutput", simulationOutput);
    
    // Save Mutation Request in case of errors
    message.setProperty("mutationRequest", jsonMutation.toString());
    
    // If the trace level is debug, add the JSON request as an attachment to the message log for detailed review.
    if (traceLevel == "debug") {
        messageLog.addAttachmentAsString("LeanIX Mutation Request", jsonMutation.toString(), "text/plain");
    }
    
    message.setBody(jsonMutation.toString());

    return message
}

def StringBuilder buildDescription(def ic, def lineFeed) {
    def description = new StringBuilder();
    
    description << "FactSheet Description:" + lineFeed;
    description << "Automatically generated Description by SAP Cloud Integration" + lineFeed + lineFeed;
    description << "Technical Details from SAP PO" + lineFeed + lineFeed;
    description << "Sender Party: ${ic.IntegratedConfigurationID.SenderPartyID.text()}" + lineFeed;
    description << "Sender Component: ${ic.IntegratedConfigurationID.SenderComponentID.text()}" + lineFeed;
    description << "Interface: ${ic.IntegratedConfigurationID.InterfaceName.text()}" + lineFeed;
    description << "Namespace: ${ic.IntegratedConfigurationID.InterfaceNamespace.text()}" + lineFeed;
    description << "Receiver Party: ${ic.IntegratedConfigurationID.ReceiverPartyID.text()}" + lineFeed;
    description << "Receiver Component: ${ic.IntegratedConfigurationID.ReceiverComponentID.text()}" + lineFeed;
    
    return description;

}

def createOutput(def ic, def ico, def factSheetMap, def message, def factSheetNames, def simulationOutput, def mutation_requests, def counter) {
    
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    def subType = message.getProperty("LeanIX_FactSheet_Subtype");
    
    def senderPartyID = ic.IntegratedConfigurationID.SenderPartyID.text() ?: "";
    def senderComponentID = ic.IntegratedConfigurationID.SenderComponentID.text();
    def interfaceName = ic.IntegratedConfigurationID.InterfaceName.text();
    def interfaceNamespace = ic.IntegratedConfigurationID.InterfaceNamespace.text();
    def receiverPartyID = ic.IntegratedConfigurationID.ReceiverPartyID.text() ?: "" ;
    def receiverComponentID = ic.IntegratedConfigurationID.ReceiverComponentID.text() ?: "";
    def tagname = message.getProperty("TagName");

    String hashGuid = generateHashGuid(senderPartyID, senderComponentID, interfaceName, interfaceNamespace, receiverPartyID, receiverComponentID);
    def receiverText = new StringBuilder();
    
    // Check for LeanIX Label in Value Mapping
    def labelSender = valueMapApi.getMappedValue("SAPPO_Component", "Name", senderPartyID +"|"+ senderComponentID , "LeanIX_Application", "Label");
    def labelInterface = valueMapApi.getMappedValue("SAPPO_Interface", "Name", interfaceName +"|"+ interfaceNamespace , "LeanIX_Interface", "Label");

    simulationOutput << "\n--------------------------------------------------------------------------------------------------------------------------------------\n";
    simulationOutput << "\n*** Technical Details from SAP PO ***\n";
    simulationOutput << "Sender Party: ${senderPartyID}\n";
    simulationOutput << "Sender Component: ${senderComponentID}\n";
    simulationOutput << "Interface: ${interfaceName}\n";
    simulationOutput << "Namespace: ${interfaceNamespace}\n";
    simulationOutput << "Receiver Party: ${receiverPartyID}\n";
    simulationOutput << "Receiver Component: ${receiverComponentID}\n\n";
        
    simulationOutput << "*** Checking if ValueMapping 'Value Mapping LeanIX Label' contains any replacements for technical Names ***\n";
    if (labelSender && labelSender != '...') {
        simulationOutput << "Found LeanIX Label for ${senderPartyID}|${senderComponentID} : ${labelSender}\n";
    } else {
        simulationOutput << "Found no LeanIX Label for ${senderPartyID}|${senderComponentID}\n";
    }
    if (labelInterface && labelInterface != '...') {
        simulationOutput << "Found LeanIX Label for ${interfaceName}|${interfaceNamespace} : ${labelInterface}\n";
    } else {
        simulationOutput << "Found no LeanIX Label for ${interfaceName}|${interfaceNamespace}\n";
    }
    
    def numberOfReceivers = 0;
    def receivers = ic.Receivers.'**'.findAll { it.name() == 'Receiver' }.each { receiver ->
            def labelReceiver = valueMapApi.getMappedValue("SAPPO_Component", "Name", receiver.PartyID.text() +"|"+ receiver.ComponentID.text() , "LeanIX_Application", "Label");
            if (labelReceiver && labelReceiver != '...') {
                simulationOutput << "Found LeanIX Label for ${receiver.PartyID.text()}|${receiver.ComponentID.text()} : ${labelReceiver}\n"
                
                if (numberOfReceivers == 0) {
                   receiverText << "${labelReceiver}";
                } else {
                    receiverText << ", ${labelReceiver}";
                }
            } else {
                simulationOutput << "Found no LeanIX Label for ${receiver.PartyID.text()}|${receiver.ComponentID.text()}\n"
                
                if (numberOfReceivers == 0) {
                   receiverText << "${receiver.PartyID.text()}|${receiver.ComponentID.text()}";
                } else {
                    receiverText << ", ${receiver.PartyID.text()}|${receiver.ComponentID.text()}";
                }
            }
            
            numberOfReceivers++
        }
    
    simulationOutput << "\n*** Checking LeanIX if FactSheet already exists or if the Flow needs to create the FactSheet ***\n"    
    def factSheetId = factSheetMap.get(hashGuid);
    def updateFactSheet = false;
    
    if (factSheetId) {
        simulationOutput << "Interface FactSheet already exists with ID: ${factSheetId}\n";
        updateFactSheet = true;
    } else {
        simulationOutput << "Interface FactSheet doesn't exists and will be created\n";
    }

    // Generate FactSheet Name and reuse transport it via property to the other scripts which need the same logic
    def factSheetName = new StringBuilder()
    if (labelInterface && labelInterface != '...') {
        factSheetName << "${labelInterface} from "; 
    } else {
        factSheetName << "${interfaceName}|${interfaceNamespace} from ";
    }
        
    if (labelSender && labelSender != '...') {
        factSheetName << "${labelSender} to ${receiverText}";
    } else {
        factSheetName << "${senderPartyID}|${senderComponentID} to ${receiverText}";
    }
    
    // Add FactSheet Name to Array
    factSheetNames.add(factSheetName);

    simulationOutput << "\n*** Preview of how the values would be created in LeanIX ***\n";
    simulationOutput << "FactSheet Name:\n";
    simulationOutput << factSheetName.toString() + "\n\n";
    simulationOutput << buildDescription(ic, "\n");
    simulationOutput << "\nExternalID:";
    simulationOutput << "\n${hashGuid}";
    // Build description and mutation request
    def description = buildDescription(ic, "\\n");

    
    if (updateFactSheet) {
    // Create Mutation Request for updating a FactSheet
        def mutation = " upd${counter}:  updateFactSheet(id: \"${factSheetId}\", validateOnly: false, comment: \"Adding data automatically via SAP CI Flow\", patches: [{ op: replace, path: \"/name\", value: \"${factSheetName}\" },{ op: add, path: \"/description\", value: \"${description}\" }, { op: add, path: \"/category\", value: \"${subType}\" }, { op: add, path: \"/externalId\", value: \"{\\\"comment\\\": null,\\\"externalId\\\": \\\"${hashGuid}\\\",\\\"externalUrl\\\": null,\\\"externalVersion\\\": null,\\\"status\\\": \\\"ACTIVE\\\" }\"} "
    
    // Tag wird nur hinzugefügt, wenn ein Wert gegeben ist
    if (tagname?.trim()) {
        mutation += ", { op: add, path: \"/tags\", value: \"[{\\\"tagName\\\": \\\"${tagname}\\\"}]\" } "
    }
    mutation += "]) { factSheet{id name category status description} }"

    mutation_requests << mutation


    } else {
        def mutation = " cre${counter}:  createFactSheet(input: { type: Interface, name: \"${factSheetName}\" } patches: [{ op: replace, path: \"/name\", value: \"${factSheetName}\" },{ op: add, path: \"/description\", value: \"${description}\" }, { op: add, path: \"/category\", value: \"${subType}\" }, { op: add, path: \"/externalId\", value: \"{\\\"comment\\\": null,\\\"externalId\\\": \\\"${hashGuid}\\\",\\\"externalUrl\\\": null,\\\"externalVersion\\\": null,\\\"status\\\": \\\"ACTIVE\\\" }\"} "
    
    // Tag wird nur hinzugefügt, wenn ein Wert gegeben ist
    if (tagname?.trim()) {
        mutation += ", { op: add, path: \"/tags\", value: \"[{\\\"tagName\\\": \\\"${tagname}\\\"}]\" } "
    } 
    mutation += "]) { factSheet{ id name} } ";
    
    mutation_requests << mutation
    }
}

    // Build description and mutation request
    /*def description = buildDescription(ic, "\\n");
    if (subType != "")
    {
        
    } else {
        mutation_requests << " upd${counter}:  updateFactSheet(id: \"cre${counter}.factSheet.id\", validateOnly: false, comment: \"Adding data automatically via SAP CI Flow\", patches: [{ op: replace, path: \"/name\", value: \"${factSheetName}\" },{ op: add, path: \"/description\", value: \"${description}\" },  { op: add, path: \"/externalId\", value: \"{\\\"comment\\\": null,\\\"externalId\\\": \\\"${hashGuid}\\\",\\\"externalUrl\\\": null,\\\"externalVersion\\\": null,\\\"status\\\": \\\"ACTIVE\\\" }\"} ]){ factSheet { id name category status description }}";
    }*/
    

String generateHashGuid(String senderPartyID, String senderComponentID, String interfaceName, String interfaceNamespace, String receiverPartyID, String receiverComponentID) {
    // Verkettet die Eingabefelder mit dem Trennzeichen "|"
    String inputString = [senderPartyID, senderComponentID, interfaceName, interfaceNamespace, receiverPartyID, receiverComponentID].join('|');
    
    // Erstellen eines MessageDigest-Objekts für SHA-256
    MessageDigest digest = MessageDigest.getInstance("SHA-256");
    
    // Berechnung des Hash-Wertes
    byte[] hashBytes = digest.digest(inputString.getBytes("UTF-8"));
    
    // Konvertierung des Byte-Arrays in einen Hexadezimal-String
    String guid = hashBytes.collect { String.format("%02x", it) }.join();
    
    return guid
}