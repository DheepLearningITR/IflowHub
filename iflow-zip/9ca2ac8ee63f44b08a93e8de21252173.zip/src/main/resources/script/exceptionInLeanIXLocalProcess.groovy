/**
 * Script Name: exceptionInLeanIXLocalProcess
 * Author: Christian Riesener
 * Date: 2024-05-10
 * Description: This script is designed, in case of an exception, to create a detailed log with all available data- It captures the body, headers (excluding sensitive ones),
 *              and properties of the message, formatting them for clarity and compliance with security standards.
 * 
 * Modifications:
 * - 2024-05-13 - Comment added - Christian Riesener
 * 
 * Notes:
 * - The script filters out sensitive headers such as 'Authentication' and 'Authorization' to maintain security.
 * - It uses StringBuilder to construct a readable and well-formatted log of the message details.
 * - Logs are added as plain text attachments, making them easy to access and review.
 */

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message)  {

    // Attempt to retrieve and utilize the message log, applying operations only if the log is available.
    messageLogFactory.getMessageLog(message)?.with {
        // Build a content string using StringBuilder to log details about the message.
        def content = new StringBuilder().with {
            it << "Body".padRight(60, '-').padLeft(70, '-') + "\n"
            it << message.getBody(String) + "\n\n"
            it << "Headers".padRight(60, '-').padLeft(70, '-') + "\n"
            // Filter and format headers to exclude sensitive authentication information.
            it << map(message.getHeaders().findAll { !["Authentication", "Authorization"].contains(it.key)})
            it << "Properties".padRight(60, '-').padLeft(70, '-') + "\n"
            // Format and append properties of the message.
            it << map(message.getProperties())
        }
        
        // Add the constructed content as a plain text attachment to the message log for debugging and auditing.
        it.addAttachmentAsString("Exception Log", content.toString(), "text/plain");
    }

    // Return the possibly modified message.
    return message;
}

// Helper function 'map' to format maps (headers and properties) into a structured, readable string.
def String map(Map map) {
    // Sort the map by key in a case-insensitive manner and format each entry with its type and value.
    return map
        .sort { a, b -> a.key.toLowerCase() <=> b.key.toLowerCase() }
        .collect{ "$it.key (${it.value.getClass().getSimpleName()}): $it.value" }
        .join("\n") + "\n\n"
}
