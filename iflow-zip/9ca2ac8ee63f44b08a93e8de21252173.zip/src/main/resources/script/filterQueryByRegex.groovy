import com.sap.it.api.mapping.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

def String isIcoRelevant(String sSenderParty, String sSenderComponent, String sInterface, String sNamespace, MappingContext context){
    
	String sRegexSenderParty = context.getProperty("FilterSenderParty") ?: ".*";
	String sRegexSenderComponent = context.getProperty("FilterSenderComponent")?: ".*";
	String sRegexInterface = context.getProperty("FilterInterface")?: ".*";
	String sRegexNamespace = context.getProperty("FilterNamespace")?: ".*";
	
	// Create Pattern-Objects
    Pattern patternSenderParty = Pattern.compile(sRegexSenderParty);
    Pattern patternSenderComponent = Pattern.compile(sRegexSenderComponent);
    Pattern patternInterface = Pattern.compile(sRegexInterface);
    Pattern patternNamespace = Pattern.compile(sRegexNamespace);
    
    // Create Matcher-Objects
    Matcher matcherSenderParty = patternSenderParty.matcher(sSenderParty);
    Matcher matcherSenderComponent = patternSenderComponent.matcher(sSenderComponent);
    Matcher matcherInterface = patternInterface.matcher(sInterface);
    Matcher matcherNamespace = patternNamespace.matcher(sNamespace);
    
    if (matcherSenderParty.find() && matcherSenderComponent.find() && matcherInterface.find() && matcherNamespace.find() ) {
        return "true";
    } else {
        return "false";
    }
}

// Count Number of Interfaces and save in MessageProperty
def void countInterfaces(String[] interfaces, Output output, MappingContext context) {
    int numberOfPOIs = interfaces.length;

    String numberOfPOIsAsString = numberOfPOIs.toString();
    context.setProperty("NumberOfPOICos",numberOfPOIsAsString);
    
    interfaces.each { str ->
        output.addValue(str)
    }
}
