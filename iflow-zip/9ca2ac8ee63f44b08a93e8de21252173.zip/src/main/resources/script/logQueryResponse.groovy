/**
 * Script Name: logQueryResponse
 * Author: Christian Riesener
 * Date: 2024-05-10
 * Description: This simple script is designed to log the response of a query from SAP Process Orchestration (PO).
 *              It captures and logs the entire message body as a plain text attachment within the message log for auditing and debugging purposes.
 *
 * Modifications:
* - 2024-05-13 - Comment added - Christian Riesener
 *
 * Notes:
 * - This script is only used when TraceLevel = "debug"
 */

// Import necessary SAP class for handling message transformations.
import com.sap.gateway.ip.core.customdev.util.Message;

// Define the 'processData' function to process an incoming 'Message' object and return a 'Message' object.
def Message processData(Message message) {

    // Retrieve the message log object for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);

    // Add the entire message body as a plain text attachment to the message log, tagged as "SAP PO Query Response".
    messageLog.addAttachmentAsString("SAP PO Query Response", message.getBody(String), "text/plain");

    // Return the message, potentially modified with log entries.
    return message;
}