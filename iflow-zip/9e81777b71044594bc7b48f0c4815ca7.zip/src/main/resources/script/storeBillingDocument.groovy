import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.gateway.ip.core.customdev.util.SoapHeader;

import javax.xml.namespace.QName;
import java.util.UUID;

def Message processData(Message message) {
    def headers = new ArrayList();
    def messageIdPayload = "<?xml version=\"1.0\" encoding=\"utf-8\"?><messageId xmlns=\"http://www.w3.org/2005/08/addressing\">urn:uuid:" + UUID.randomUUID().toString() + "</messageId>";
    def header = new SoapHeader(new QName("http://www.w3.org/2005/08/addressing", "messageId"), messageIdPayload, false, "");
    headers.add(header);
    message.setSoapHeaders(headers);
    return message;
}