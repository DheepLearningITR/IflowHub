import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat; 
import java.util.Date;
import groovy.time.TimeCategory;

def Message processData(Message message) {
    
    def map = message.getProperties();

    def pattern = 'yyyy-MM-dd HH:mm:ss';
    Date dateSaved = new SimpleDateFormat(pattern).parse(map.get("DateSaved"));
    Date now       = new SimpleDateFormat(pattern).parse(map.get("Now"));
    
    String temp =  map.get("DeltaSecs");
    
    int deltaSecs  = temp.toInteger();
    
    use( TimeCategory ) {
        expirationDate = dateSaved + deltaSecs.seconds
    }
    
    if (expirationDate.after(now) == true ) {
        message.setProperty("TokenExpired", '0');
    }
    else {
       message.setProperty("TokenExpired", '1');
    }

    return message;
}