import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential
import com.sap.it.api.securestore.exception.SecureStoreException


def Message processData(Message message) {
    def map = message.getProperties();
    String peruwstokencredentials =  map.get("peruwstokencredentials");
    def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null);
    def secureParameter = secureStorageService.getUserCredential(peruwstokencredentials);
    def unm = secureParameter.getUsername().toString();
    def pwd = secureParameter.getPassword().toString();
    message.setHeader('username',unm);
    message.setHeader('password',pwd);

    def secureParam = secureStorageService.getUserCredential("peruclientcredentials");
    def clientid = secureParam.getUsername().toString();
    def clientsecret = secureParam.getPassword().toString();
    message.setHeader('client_id',clientid);
    message.setHeader('client_secret',clientsecret);
return message;
}