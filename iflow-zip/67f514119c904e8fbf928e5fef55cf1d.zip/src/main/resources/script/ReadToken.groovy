import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {
    def json = new JsonSlurper().parseText(message.getBody(String));
    def auth = "Bearer "+json.access_token;
    message.setHeader('Authorization',auth);
    return message;
}