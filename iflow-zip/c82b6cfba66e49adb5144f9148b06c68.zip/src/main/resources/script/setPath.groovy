import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message)
{

  def map = message.getProperties();
  String docType = map.get("DocType");
  String serviceProvider = map.get("serviceProvider");
  
  if(docType.equalsIgnoreCase("MX_WTC"))
  {
      message.setProperty("TargetPath", "/" + serviceProvider + "_wtc");
  }else 
  {
      message.setProperty("TargetPath", "/" + serviceProvider);
  }
  return message;

}