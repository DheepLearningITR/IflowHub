import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Callable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import groovy.transform.Field;


def Message processData(Message message) {
def headers = message.getHeaders();
def props   = message.getProperties();
def cxfMsg = headers.get("CamelCxfMessage");
Map<String, List<String>> cxf_headers = (Map<String, List<String>>) cxfMsg.get(org.apache.cxf.message.Message.PROTOCOL_HEADERS);
message.setProperty("EndPointURL", "/" + props.get("serviceProvider"));
return message
}