import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.ArrayList;
import java.lang.*;
import com.sap.it.api.mapping.*;
import groovy.json.*

def Message processData(Message message) {
     message.setHeader("Content-Type", "application/json" + "; charset=utf-8" );
    
    def jsonBody = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def jsonObj = jsonSlurper.parseText(jsonBody);
    
    def dataResults = [];
    
     //Open PO
    def openSegment = [:]
    openSegment.name = "open";
    openSegment.y = 0;
    
    //Completed PO
    def completedSegment = [:]
    completedSegment.name = "completed";
    completedSegment.y = 0;
    
    def extData = [:];
    extData.open = [];
    extData.completed = [];
    
    jsonObj.get("messageResponses").get(0).get("body").get("extData").each{ val ->
        if(val.releaseIsNotCompleted.equals("true")){
            openSegment.y = openSegment.y + 1;
            extData.open.push(val);
        }else{
            completedSegment.y = completedSegment.y + 1;
            extData.completed.push(val);
        }
    } 
    
    jsonObj.get("messageResponses").get(0).get("body").put("extData", extData);
    
    dataResults.push(openSegment);
    dataResults.push(completedSegment);
     
    jsonObj.get("messageResponses").get(0).get("body").put("data",dataResults);
    def newBody = JsonOutput.toJson(jsonObj);
    message.setBody(newBody);
    return message;
}