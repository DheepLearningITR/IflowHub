import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    def localTimeZone = TimeZone.getTimeZone('America/New_York');
    def cal = Calendar.instance;
    def date = cal.time;
    def dateFormat = "yyyyMMdd"
  
    message.setProperty("sysDate",date.format(dateFormat, localTimeZone));
       
      
    return message;
}