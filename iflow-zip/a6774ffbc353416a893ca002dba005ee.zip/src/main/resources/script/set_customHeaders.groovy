import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def xmEventType = message.getProperties().get("xmEventType");
    	if(xmEventType!=null){
    		messageLog.addCustomHeaderProperty("sfsf_xmEventType", xmEventType);		
        } 
	}
	return message;
}

def Message switchedOff(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
		messageLog.addCustomHeaderProperty("sfsf_XMLogStatus", 'OFF');		
	}
	return message;
}
def Message notFound(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
		messageLog.addCustomHeaderProperty("sfsf_XMLogStatus", 'START_NOT_FOUND');		
	}
	return message;
}
