import com.sap.gateway.ip.core.customdev.util.Message;

def Message waithere(Message message) {

    // Retrieve property value
    def properties = message.getProperties();
    def retryWaitTime = properties.get("retryWaitTime") as Integer; // Get wait time from properties

	//wait, could be that the START event hasn't been sent yet (so DS doesn't exist yet). 
	//The START event is done at the end of the REPLICATION iflow, after all the splitting messages
    if (retryWaitTime) {
        Thread.sleep(retryWaitTime);
    } else {
        //default 10seconds
        Thread.sleep(10000); // 10000 milliseconds = 10 seconds
    }
	return message;
}