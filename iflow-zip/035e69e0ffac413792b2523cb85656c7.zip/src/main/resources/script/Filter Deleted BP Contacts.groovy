import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message)
{
    def ReadPayload = message.getProperty("ContactMessage");
    def BPPayload = new XmlSlurper().parseText(ReadPayload)

    def updateBPAddress = false

    BPPayload.'**'.findAll { it.name() == 'BusinessPartnerSUITEReplicateRequestMessage' }.each { messageNode ->
        def deletedIndicator = messageNode.BusinessPartner.Common.DeletedIndicator.text()
        if (deletedIndicator == 'true') {
            messageNode.replaceNode {}
        }
    }

    if (BPPayload.'**'.findAll { it.name() == 'BusinessPartnerSUITEReplicateRequestMessage' }.size() > 0) {
        updateBPAddress = true
    }

    def UpdatedBPPayload = XmlUtil.serialize(BPPayload)

    message.setProperty("UpdateBPAddress", updateBPAddress.toString())
    message.setBody(UpdatedBPPayload)

    return message;
}
