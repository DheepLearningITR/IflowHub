import com.sap.it.api.mapping.*;

def String reqBoolean(String input) {
    if (input == "true") {
        return "X"
    } else if (input == "false") {
        return ""
    }
    
    return input
}
