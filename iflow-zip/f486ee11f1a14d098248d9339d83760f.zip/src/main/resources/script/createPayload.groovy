import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Properties
    def properties = message.getProperties();
    degreedManagerId = properties.get("idToCreateManager");
    degreedManagerFisrtName = properties.get("UserDegreedFirstName");
    degreedManagerLastName = properties.get("UserDegreedLastName");
    degreedManagerFullName = properties.get("UserDegreedFullName");
    
    
    payload = [
        "type": "users",
        "attributes": [
            "first-name": degreedManagerFisrtName,
            "last-name": degreedManagerLastName,
            "full-name": degreedManagerFullName,
            ],
        "relationships": [
            [
                "manager": [
                    "data": [
                        "type": "users",
                        "id": degreedManagerId
                        ]
                ]
            ]
        ]
    ]

    def json = new groovy.json.JsonBuilder();
    json data: payload;
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString())
    message.setBody(bodyPayload);
    
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("Patch payload to Degreed", bodyPayload, "text/plain");
    
    return message;
}