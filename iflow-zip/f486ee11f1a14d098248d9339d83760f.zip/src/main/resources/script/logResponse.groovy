import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    // Los activate?
    def properties = message.getProperties();
    //logsActivate = properties.get("logsActivate").toBoolean();
    
    // Body
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);

    // Logs logic
    if(messageLog != null) { // & logsActivate){
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("Body of message", body, "text/plain");
    }
    return message;
}