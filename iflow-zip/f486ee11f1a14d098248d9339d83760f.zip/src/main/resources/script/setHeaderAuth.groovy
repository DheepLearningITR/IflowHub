import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    //Variables in cache
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("token");
    HashMap<String, String> t1CacheData = map.get("t1_token");
    HashMap<String, String> t2CacheData = map.get("t2_token");

    // Set variables
    def headerParam = "application/json";
    def auth_value = "Bearer " + cacheData.get("token");
    def t1_auth_value = "Bearer " + t1CacheData.get("t1_token");
    def t2_auth_value = "Bearer " + t2CacheData.get("t2_token");
    message.setHeader("accept",headerParam);
    message.setHeader("content-type",headerParam);
    def no_auth_code = "false"
    
    //Properties
    def properties = message.getProperties();
    def messageLog = messageLogFactory.getMessageLog(message);
    def gat_enabled = properties.get("is_GAT_enabled")
    if (gat_enabled == 'true') {
        def country = properties.get("Country")
        def tenant1 = properties.get("tenantCountryList1")
        def tenant2 = properties.get("tenantCountryList2")
        
        def tenantList1 = tenant1.split(',')
        def tenantList2 = tenant2.split(',')
        
        if (country in tenantList1) {
            message.setHeader("Authorization",t1_auth_value);
            //messageLog.addAttachmentAsString("T1 auth is enabled", country, "text/plain");
        }
        else if (country in tenantList2) {
            message.setHeader("Authorization",t2_auth_value);
           // messageLog.addAttachmentAsString("T2 auth is enabled", country, "text/plain");
        }
        else {
            no_auth_code = "true"
        }
        
    }
    
    
    else {
        message.setHeader("Authorization",auth_value);
       // messageLog.addAttachmentAsString("Auth is enabled", country, "text/plain");
    }
    
    message.setProperty("no_auth_code", no_auth_code)
    return message;
}