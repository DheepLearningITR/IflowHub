import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    Thread.sleep(20000);

    //Body
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def payload = jsonSlurper.parseText(body);
    def data = payload['messages']['message']['root']['data'];
    def attemp = payload['messages']['message']['root']['attemp'];
    message.setProperty("attempsNumbers", attemp);
    

    def json = new groovy.json.JsonBuilder(data);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString())
    message.setBody(bodyPayload);
    return message;
}
