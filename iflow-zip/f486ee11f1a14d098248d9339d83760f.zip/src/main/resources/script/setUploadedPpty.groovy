import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Date;
def Message processData(Message message) {

    //Properties
    def properties = message.getProperties();
    def wasUpdated = false;
    def stringLastRun = properties.get("lastExecutionDate").replace("T", " ").replace("Z", "");
    def stringLastModifyJobInfoNav = properties.get("lastModifyDateJobInfoNav").replace("T", " ").replace("Z", ""); // Job
    
    if (stringLastRun.length() > 0) {
        def format = "yyyy-MM-dd HH:mm:ss.SSS";
        def stringLastRunDate = new Date().parse(format, stringLastRun);
        def stringLastModifyDateJobInfoNav = new Date().parse(format, stringLastModifyJobInfoNav);
        
        if (stringLastModifyDateJobInfoNav > stringLastRunDate) {
            wasUpdated = true;
        };
    } else {
        wasUpdated = true;
    };
    
    message.setProperty("updated", wasUpdated);
    return message;
}

