import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Properties
    def properties = message.getProperties();
    value = properties.get("t1_access_token");
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("t1_token");
    cacheData.put("t1_token",value)
    message.setHeader("t1_token",cacheData);
    message.setHeader("degreedAccessToken", 'true');
    return message;
}
