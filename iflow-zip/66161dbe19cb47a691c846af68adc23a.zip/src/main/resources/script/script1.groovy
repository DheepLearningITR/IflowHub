/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def String idpayload = message.getBody(java.lang.String);   
    def iddata = new XmlSlurper().parseText(idpayload)
    def String Institutes = ''
    def String primaryInstitute = ''
    def String roles = ''
    def String EmployeeSalesResponsibility = '<EmployeeSalesResponsibilities>'
    def String OrganizationalAssignment = '<OrganizationalAssignments>'
    def String RolesAssignment = '<RolesAssignments>'
    def String RoleCode = ''
    def  institutesend = false
    def  rolesend = false
    iddata.Root.User.attributes.each {
        if (it.name == 'z_assignedInstitutes') {
          Institutes = it.value
        }
        if (it.name == 'z_primaryInstitute') {
          primaryInstitute = it.value
        }        
        if (it.name == 'z_roles') {
          roles = it.value
        }   
    }
    if (Institutes == '') {
        institutesend = true
        EmployeeSalesResponsibility = '<EmployeeSalesResponsibilities></EmployeeSalesResponsibilities>'
        OrganizationalAssignment = '<OrganizationalAssignments><OrganizationalAssignment><OrganizationalCenterBusinessCharacterCode>14</OrganizationalCenterBusinessCharacterCode><OrganizationalCenterIDTypeCode>917</OrganizationalCenterIDTypeCode><ReceiverOrganizationalCenterID>1</ReceiverOrganizationalCenterID><RoleCode>219</RoleCode></OrganizationalAssignment></OrganizationalAssignments>'
    }
    while (institutesend == false) {
        if (Institutes.indexOf(",") != -1) {
          CurrentInstitute = Institutes.substring(0,Institutes.indexOf(",")) 
          if (CurrentInstitute == primaryInstitute) {
              RoleCode = '219'
          }
          else 
          {
              RoleCode = '222'
          }
          Institutes = Institutes.substring(Institutes.indexOf(",")+1,Institutes.length())
          EmployeeSalesResponsibility = EmployeeSalesResponsibility + '<EmployeeSalesResponsibility><ReceiverSalesOrganizationID>' + CurrentInstitute + '</ReceiverSalesOrganizationID><SalesOrganizationIDTypeCode>917</SalesOrganizationIDTypeCode></EmployeeSalesResponsibility>'
          OrganizationalAssignment = OrganizationalAssignment + '<OrganizationalAssignment><OrganizationalCenterBusinessCharacterCode>14</OrganizationalCenterBusinessCharacterCode><OrganizationalCenterIDTypeCode>917</OrganizationalCenterIDTypeCode><ReceiverOrganizationalCenterID>' + CurrentInstitute + '</ReceiverOrganizationalCenterID><RoleCode>' + RoleCode + '</RoleCode></OrganizationalAssignment>'
        }
        else
        {
          CurrentInstitute = Institutes
          if (CurrentInstitute == primaryInstitute) {
              RoleCode = '219'
          }
          else 
          {
              RoleCode = '222'
          }
          EmployeeSalesResponsibility = EmployeeSalesResponsibility + '<EmployeeSalesResponsibility><ReceiverSalesOrganizationID>' + CurrentInstitute + '</ReceiverSalesOrganizationID><SalesOrganizationIDTypeCode>917</SalesOrganizationIDTypeCode></EmployeeSalesResponsibility>'
          OrganizationalAssignment = OrganizationalAssignment + '<OrganizationalAssignment><OrganizationalCenterBusinessCharacterCode>14</OrganizationalCenterBusinessCharacterCode><OrganizationalCenterIDTypeCode>917</OrganizationalCenterIDTypeCode><ReceiverOrganizationalCenterID>' + CurrentInstitute + '</ReceiverOrganizationalCenterID><RoleCode>' + RoleCode + '</RoleCode></OrganizationalAssignment>'
          institutesend = true
        }
    }
    
    //Default Role if emtpy READONLY
    if (roles == '') {
        rolesend = true
        //RolesAssignment = '<RolesAssignments><BusinessRole><ID>READONLY</ID></BusinessRole></RolesAssignments>'
    }
    while (rolesend == false) {
        if (roles.indexOf(",") != -1) {
          CurrentRole = roles.substring(0,roles.indexOf(",")) 
          roles = roles.substring(roles.indexOf(",")+1,roles.length())
          RolesAssignment = RolesAssignment + '<BusinessRole><ID>' + CurrentRole + '</ID></BusinessRole>'
        }
        else
        {
          CurrentRole = roles
          RolesAssignment = RolesAssignment + '<BusinessRole><ID>' + CurrentRole + '</ID></BusinessRole>'
          rolesend = true
        }
    }
    if (OrganizationalAssignment != '<OrganizationalAssignments><OrganizationalAssignment><OrganizationalCenterBusinessCharacterCode>14</OrganizationalCenterBusinessCharacterCode><OrganizationalCenterIDTypeCode>917</OrganizationalCenterIDTypeCode><ReceiverOrganizationalCenterID>1</ReceiverOrganizationalCenterID><RoleCode>219</RoleCode></OrganizationalAssignment></OrganizationalAssignments>') {
        OrganizationalAssignment = OrganizationalAssignment + '</OrganizationalAssignments>'
    }
    if (EmployeeSalesResponsibility != '<EmployeeSalesResponsibilities></EmployeeSalesResponsibilities>') {
        EmployeeSalesResponsibility = EmployeeSalesResponsibility + '</EmployeeSalesResponsibilities>'
    }
    if (RolesAssignment != '<RolesAssignments><BusinessRole><ID>READONLY</ID></BusinessRole></RolesAssignments>') {
        RolesAssignment = RolesAssignment + '</RolesAssignments>'
    }
    idpayload = idpayload.substring(0,idpayload.indexOf('</Root>')) + EmployeeSalesResponsibility + OrganizationalAssignment + RolesAssignment + '</Root></root>'
       message.setBody(idpayload);
       return message;
}