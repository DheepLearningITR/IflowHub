import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody();
    
    def headers = message.getHeaders();

    def properties = message.getProperties();
    
    def jsonSlurper = new JsonSlurper();
    def dbResult = jsonSlurper.parse(body);
    
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('Result SQL SELECT', dbResult.toString(), 'text/plain');
    
    def projectValidToUpdate = '0';
    def projectId = message.getProperty('projectId');
    
    if (dbResult && dbResult.SelectStatement_response && 
            dbResult.SelectStatement_response.row && dbResult.SelectStatement_response.row.size() > 0) {
                
        projectValidToUpdate = '1';
        
         //log Result
        //def messageLog = messageLogFactory.getMessageLog(message);
        //messageLog.addAttachmentAsString('resultRows-'+eventId, dbResult.toString(), 'text/plain');
    }

    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('DB Result -' + projectId, dbResult.toString(), 'text/plain');
    
    message.setProperty("projectValidToUpdate", projectValidToUpdate);
    message.setProperty("projectId",  projectId);
    
   

    return message;
}