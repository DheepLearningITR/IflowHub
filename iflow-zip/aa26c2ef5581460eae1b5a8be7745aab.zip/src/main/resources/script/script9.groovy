/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    //Body
    def body = message.getBody();

    //Headers
    def headers = message.getHeaders();
    
    //Properties
    def properties = message.getProperties();
    
    //get Json result
    def jsonSlurper = new JsonSlurper();
    def apiResult = jsonSlurper.parse(body);
    
     // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    //get db Schema
    def db_schema = properties.get('Database_Schema_Name');
    
    def projectExists = '0';
    
    if (apiResult) {
        projectExists = '1';
        sqlStatement.root {
            sqlStatement.UpdateStatement {
                sqlStatement.app_sourcing_projects(action: 'UPDATE') {
                    sqlStatement.table(db_schema + '.APP_SOURCING_PROJECTS')
                    sqlStatement.access {
                        sqlStatement.TITLE(apiResult.title)
                        sqlStatement.DESCRIPTION(apiResult.description)
                        sqlStatement.STATUS(apiResult.status)
                        sqlStatement.BEGIN_DATE(apiResult.beginDate)
                        sqlStatement.OWNER_NAME(apiResult.owner.name)
                        sqlStatement.PARENT_DOCUMENT_ID(apiResult.parentDocumentId)
                        sqlStatement.PROCESS_STATUS(apiResult.processStatus)
                        sqlStatement.CURRENCY_CODE(apiResult.currency)
                        sqlStatement.ORIGIN(apiResult.origin)
                        if (apiResult.baselineSpend) {
                            sqlStatement.BASE_LINE_SPEND_AMOUNT(apiResult.baselineSpend.amount)
                            sqlStatement.BASE_LINE_SPEND_CURRENCY(apiResult.baselineSpend.currency)
                        }
                        sqlStatement.MODIFIEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                        sqlStatement.MODIFIEDBY(properties.get('Extension_User'))
                        for (customField in apiResult.sourcingProjectCustomFields) {
                            if (customField.textValue && !customField.textValue.empty) {
                                switch(customField.fieldId) {
                                    case 'cus_NombredelaGestiondeCompra':
                                        sqlStatement.NOMBRE_GC(customField.textValue[0])
                                        break;
                                    case 'cus_NReferenciaGestiondeCompra':
                                         sqlStatement.NOMBRE_REF_GC(customField.textValue[0])
                                        break;
                                    case 'cus_TipodeGestiondeCompra':
                                        sqlStatement.NOMBRE_TIPO_GC(customField.textValue[0])
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                    }
                    sqlStatement.key {
                        sqlStatement.INTERNAL_ID(apiResult.internalId)
                    }
                }
            }
        };
    }

    message.setProperty("projectExists", projectExists);
    
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //def eventId = message.getProperty('eventId')
    //messageLog.addAttachmentAsString('API Result bids - Event: '+ eventId, apiResult.toString(), 'text/plain');
   
   //set body
   message.setBody(writer.toString());
  
    return message;
}