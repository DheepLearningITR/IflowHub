/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    //Body
    def body = message.getBody();

    //Headers
    def headers = message.getHeaders();
    
     //Properties
    def properties = message.getProperties();
    def eventId = properties.get("eventId");
    
     // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    //get db Schema
    def db_schema = properties.get('Database_Schema_Name');
    
    sqlStatement.root {
        sqlStatement.UpdateStatement {
            sqlStatement.app_sourcing_events(action: 'UPDATE') {
                sqlStatement.table(db_schema + '.APP_SOURCING_EVENTS')
                sqlStatement.access {
                    sqlStatement.MODIFIEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                    sqlStatement.MODIFIEDBY(properties.get('Extension_User'))
                    sqlStatement.COMMENTS('The existing project was updated.')
                    sqlStatement.BID_UPDATED(message.getProperty('eventTimeUpdated'))
                }
                sqlStatement.key {
                    sqlStatement.INTERNAL_ID(eventId)
                }
            }
        }
    };
   
   //set body
   message.setBody(writer.toString());
  
    return message;
}