import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    
    CRM_Attachment_IDs = message.getProperty('CRM_Attachment_IDs');
    ArrayList FSM_Attachment_IDs = []
    def parsedObj = new JsonSlurper().parseText(body);
    
    parsedObj.data.each{
        FSM_Attachment_IDs.add(it.at.externalId);
    }

    CRM_Attachment_IDs.intersect(FSM_Attachment_IDs).each{FSM_Attachment_IDs.remove(it)}

    String Delete_JSON_str = "";
    FSM_Attachment_IDs.each{
        if (Delete_JSON_str == ""){
            Delete_JSON_str = '{\"externalId\" : ' + '\"'+it+'\"}]';
        }
        else
        {
            Delete_JSON_str = '{\"externalId\" : ' + '\"'+it+'\"}, ' + Delete_JSON_str; 
        }
    }
    
    if (Delete_JSON_str == "")
    {
        message.setProperty('CRM_Attachment_IDs','DELETE_NOTHING');
    }
    else
    {
        Delete_JSON_str = '[' + Delete_JSON_str;
        message.setBody(Delete_JSON_str);
    }

    return message;
}
