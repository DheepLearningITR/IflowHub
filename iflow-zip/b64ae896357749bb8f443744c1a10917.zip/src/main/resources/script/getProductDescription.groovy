import com.sap.it.api.mapping.*;

def String getTextForProductDesc(String longTextID, String longText, MappingContext context)
{
    if(longTextID != null && 
	longTextID.trim().length() > 0 && 
	longText != null && 
	longText.trim().length() > 0 &&
	longTextID == '0001'){
		
		return longText;
		   
    }
 	
	return "";
}
