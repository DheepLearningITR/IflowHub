import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.mapping.MappingContext;
import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message) {
    def logLevel = message.getProperty("LogLevel")
    if (logLevel != "4"){
        return message
    }
    
    def body = message.getBody(java.lang.String) as String
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
        messageLog.setStringProperty("Logging#1", "Printing Response Payload As Attachment")
        messageLog.addAttachmentAsString("FinalResponsePayload:", body, "text/plain")
     }
    return message;
}

def String getProperty(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty(propertyName);
    return propertyValue;
}

def String getHeader(String headerName, MappingContext context) {
    def headerValue = context.getHeader(headerName);
    return headerValue;
}


def String dynamicValueMap(String sAgency, String sSchema, String tAgency, String tSchema, String key, String language){

      def service = ITApiFactory.getApi(ValueMappingApi.class, null);
      def sKey    = language + "_" + key; 

      if( service != null) {

         String val= service.getMappedValue(sAgency, sSchema, sKey, tAgency, tSchema);
         if ( val.equals("") || val ==null )
         {
             return key
         }
         else
             return val
     }   

     return null;

}