import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {

  def shopifyOrderList = message.getProperty("shopify_order_list") as String;
  def responseBody = message.getBody(java.lang.String) as String;

  def jsonSlurper = new JsonSlurper()

  def savedOrderList = jsonSlurper.parseText(shopifyOrderList)
  def responceOrderList = jsonSlurper.parseText(responseBody)
  if (shopifyOrderList.isEmpty()) {
    savedOrderList = responceOrderList
  } else {
    savedOrderList.putAll(responceOrderList)
  }

  def builder = new JsonBuilder(savedOrderList)
  def newSavedList = builder.toPrettyString()

  message.setProperty("shopify_order_list", newSavedList);

  return message;
}