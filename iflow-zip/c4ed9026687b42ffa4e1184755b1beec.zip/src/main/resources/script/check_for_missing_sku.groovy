import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(String).trim();
    if (body.startsWith("<?xml")) {
        body = body.substring(body.indexOf("?>") + 2).trim();
    }

        def xmlParser = new XmlSlurper();
        def xmlPayload = xmlParser.parseText(body);
        def allSkuValid = true;
        def lineItems = xmlPayload.data.orders.edges.node.lineItems.edges;

        if (lineItems) {
            lineItems.each { item ->
                def sku = item.node.sku.text();
                if (sku == null || sku.trim().isEmpty()) {
                    allSkuValid = false;
                }
            }
        } else {
            allSkuValid = false; 
        }

        if (allSkuValid) {
            message.setProperty("missing_sku", false);
        } else {
            message.setProperty("missing_sku", true);
        }

    return message;
}