import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    def graphQLQuery = message.getProperty("gql_orders_search_filter");
    String lastShopifyOrderRequestTimestampDate = "'" + message.getProperty("lastShopifyOrderRequestTimestampDate") + "'";

    String updatedAt = " updated_at:>";

    String updatedQuery = graphQLQuery + updatedAt + lastShopifyOrderRequestTimestampDate;

    message.setProperty("gql_orders_search_filter", updatedQuery);

    return message;
}