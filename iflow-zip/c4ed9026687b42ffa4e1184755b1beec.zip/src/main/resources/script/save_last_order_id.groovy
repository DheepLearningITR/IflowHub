import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper

def Message processData(Message message) {
  def responseBody = message.getBody(java.lang.String) as String;
  if (isEmptyOrderResponse(responseBody)) {
    message.setProperty("last_order_reached", 'true');
  } else {
    def jsonSlurper = new JsonSlurper();

    def responseOrderList = jsonSlurper.parseText(responseBody);

    def lastOrderId = responseOrderList.orders[-1].id as String;

    message.setProperty("last_order_id", lastOrderId);
  }

  return message;
}

private boolean isEmptyOrderResponse(responseBody) {
  boolean lastOrderReached = false;
  def slurper = new JsonSlurper();
  def jsonObject = slurper.parseText(responseBody);

  if (jsonObject.orders) { 
    if (jsonObject.orders instanceof List) { 
      if (jsonObject.orders.empty) { 
        lastOrderReached = true;
      }
    }
  } else {
    lastOrderReached = true;
  }
  return lastOrderReached;
}