import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {

def body = message.getBody(java.lang.String) as String;
def jsonSlurper = new JsonSlurper()

def parsedBody = jsonSlurper.parseText(body)
parsedBody.root.to_Item = parsedBody.root.to_Item.results

def jsonBuilder = new JsonBuilder(parsedBody)
message.setBody(jsonBuilder)
       return message;
}