import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {

        def shopifyOrderId = message.getProperty("shopifyOrderId") as String;
        if (shopifyOrderId != null && !shopifyOrderId.isEmpty()) {
            messageLog.addCustomHeaderProperty("Updated Shopify Order", shopifyOrderId);
        }
    }
    return message;
}