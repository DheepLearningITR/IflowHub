import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def responseBody = message.getBody(java.lang.String) as String;
    
    if (isEmptyOrderResponse(responseBody)) {
        message.setProperty("last_order_reached", 'true');
    } else {
        def xmlSlurper = new XmlSlurper();
        
        def responseOrderList = xmlSlurper.parseText(responseBody);
        
        // Grab the last <orders> element
        def orders = responseOrderList.'orders'.last();
        
        // Extract the last order ID
        def lastOrderId = orders.id.text();
        
        // Set property with last order ID
        message.setProperty("last_order_id", lastOrderId);
    }

    return message;
}

private boolean isEmptyOrderResponse(String responseBody) {
    def xmlSlurper = new XmlSlurper();
    def xml = xmlSlurper.parseText(responseBody);
    
    // Check if there are any <orders> elements
    return xml.'orders'.size() == 0;
}