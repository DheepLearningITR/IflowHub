import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    
    def body = message.getBody(java.io.Reader);
    def jsonSlurper = new JsonSlurper();
    def jsonObject = jsonSlurper.parse(body);
    
    def orders = jsonObject.orders;
    int orderCount = jsonObject.orders.size();
    message.setProperty("orderCount", orderCount.toString());
    
    return message;
}