import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def single_business_partner = message.getProperty("single_business_partner")
    message.setProperty("sold_to_party", single_business_partner)

    return message;
}
