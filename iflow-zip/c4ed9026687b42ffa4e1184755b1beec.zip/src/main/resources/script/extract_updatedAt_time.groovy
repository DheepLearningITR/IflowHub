import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def root = new XmlSlurper().parseText(body)
    def orderNode = root.data.orders.edges.node

    def currentProcessedShopifyOrderUpdatedAtTimestamp = orderNode.updatedAt;

    if(currentProcessedShopifyOrderUpdatedAtTimestamp && currentProcessedShopifyOrderUpdatedAtTimestamp.text()) {
        message.setProperty("currentProcessedShopifyOrderUpdatedAtTimestamp", currentProcessedShopifyOrderUpdatedAtTimestamp)
    }

    return message
}