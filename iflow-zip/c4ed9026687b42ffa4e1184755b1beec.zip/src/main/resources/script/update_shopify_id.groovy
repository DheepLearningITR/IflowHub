import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def soldToParty = message.getProperty("sold_to_party")
    def single_business_partner = message.getProperty("single_business_partner")
    def matcher = body =~ /<PurchaseOrderByCustomer>.*?(\d+)<\/PurchaseOrderByCustomer>/
    
    if (matcher.find()) {
        def purchaseOrderNumber = matcher.group(1)

        body = body.replaceAll(/<PurchaseOrderByCustomer>.*?<\/PurchaseOrderByCustomer>/, 
                               "<PurchaseOrderByCustomer>${purchaseOrderNumber}</PurchaseOrderByCustomer>")
                               
        if (single_business_partner != "") {
            body = body.replaceAll(/<SoldToParty>.*?<\/SoldToParty>/, "<SoldToParty>${soldToParty}</SoldToParty>")
        }
        
        body = body.replaceAll(/<SoldToParty\/>/, "<SoldToParty>${soldToParty}</SoldToParty>")

    }

    message.setBody(body)

    return message
}