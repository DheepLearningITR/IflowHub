import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.StreamingMarkupBuilder

def Message processData(Message message) {

    def shopifyOrderListXML = message.getProperty("shopify_order_list") as String;
    def responseBody = message.getBody(java.lang.String) as String;

    def xmlSlurper = new XmlSlurper(false, false)

    def savedOrderList = xmlSlurper.parseText(shopifyOrderListXML)
    def responseOrderList = xmlSlurper.parseText(responseBody)

    if (shopifyOrderListXML.isEmpty()) {
        savedOrderList = responseOrderList
    } else {
        // Merge responseOrderList into savedOrderList
        responseOrderList.children().each { node ->
            savedOrderList.appendNode {
                name = node.name()
                value = node.text()
            }
        }
    }

    def builder = new StreamingMarkupBuilder()
    def newSavedList = builder.bind {
        mkp.declareNamespace("": "http://www.w3.org/1999/xhtml")
        mkp.yield savedOrderList
    }

    message.setProperty("shopify_order_list", newSavedList.toString());

    return message;
}