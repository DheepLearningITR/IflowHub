import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def String X_CSRF_TOKEN_PROP = "X-CSRF-Token"
	
	def headers = message.getHeaders();
    def csrfToken = headers.get(X_CSRF_TOKEN_PROP);

    if (csrfToken) {
        message.setHeader(X_CSRF_TOKEN_PROP, csrfToken);
    } else {
        message.setHeader(X_CSRF_TOKEN_PROP, X_CSRF_TOKEN_PROP);
    }
    
    return message;
}