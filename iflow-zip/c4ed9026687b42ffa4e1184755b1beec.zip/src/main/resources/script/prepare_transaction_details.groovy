import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def root = new XmlSlurper().parseText(body)
    def orderNode = root.data.orders.edges.node
    orderNode.transactions.each { transactionNode ->
        def status = transactionNode.status.text()
        def kind = transactionNode.kind.text()
        
        if (status == 'SUCCESS' && kind == 'SALE') {
            def transactionId = transactionNode.id.text()
            def gateway = transactionNode.gateway.text()
            def createdAt = transactionNode.createdAt.text()
            def paymentId = transactionNode.paymentId.text()
            
            def transactionText = """Transaction ID: ${transactionId}
Gateway: ${gateway}
Created At: ${createdAt}
Payment ID: ${paymentId}"""
           
            message.setProperty("s4hana_payment_transaction_details", transactionText)
            return message
        }
    }

    return message
}