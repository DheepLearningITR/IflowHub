/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper 
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String ) as String;
       map = message.getProperties();
       rutSender = map.get("RUTEnvia");
       dvSender = map.get("DvEnvia");
       rutCompany = map.get("RUTEmis");
       dvCompany = map.get("DvEmisor");
       token = map.get("SIIToken");
       signed_boleta = map.get("signedBoleta");
       
       message.setHeader("CamelHttpMethod", "POST");
       message.setHeader("Cookie", "TOKEN=" + token);
       message.setHeader("Accept", "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg,application/vnd.ms-powerpoint, application/ms-excel,application/msword, */*");
       message.setHeader("Accept-Encoding", "gzip, deflate");
       message.setHeader("User-Agent", "Mozilla/4.0 (compatible; PROG 1.0; Windows NT 5.0; YComp 5.0.2.4)");
       message.setHeader("Accept-Language", "es-cl");
       message.setHeader("Cache-Control", "no-cache");
       body = '------7d23e2a11301c4\r\nContent-Disposition: form-data; name="rutSender"\r\n\r\n' + rutSender + '\r\n------7d23e2a11301c4\r\nContent-Disposition: form-data; name="dvSender"\r\n\r\n' + dvSender + '\r\n------7d23e2a11301c4\r\n------7d23e2a11301c4\r\nContent-Disposition: form-data; name="rutCompany"\r\n\r\n' + rutCompany + '\r\n------7d23e2a11301c4\r\n------7d23e2a11301c4\r\nContent-Disposition: form-data; name="dvComapny"\r\n\r\n' + dvCompany + '\r\n------7d23e2a11301c4\r\nContent-Disposition: form-data; name="archivo";  filename=envioBoleta.xml\r\nContent-Type: text/xml\r\n\r\n' + signed_boleta + '\r\n\r\n------7d23e2a11301c4--\r\n';
       message.setBody(body);
       return message; 
       */
}