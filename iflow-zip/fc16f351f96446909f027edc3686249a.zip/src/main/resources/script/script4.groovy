import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat; 
import java.util.Date;
import groovy.time.TimeCategory;

def Message processData(Message message) {

    //Body 
    
    def map = message.getProperties();
    value = map.get("oldProperty");

    def pattern = 'yyyy-MM-dd HH:mm:ss';
    Date dateSaved = new SimpleDateFormat(pattern).parse(map.get("DateSaved"));
    Date now       = new SimpleDateFormat(pattern).parse(map.get("Now"));
    
    String temp =  map.get("DeltaSecs");
    
    int deltaSecs  = temp.toInteger();
    
    use( TimeCategory ) {
        expirationDate = dateSaved + deltaSecs.seconds;
    }
    
    if (expirationDate.after(now) == true ) {
        message.setProperty("SiiTokenExpired", '0');
    }
    else {
       message.setProperty("SiiTokenExpired", '1');
    }

    return message;
}