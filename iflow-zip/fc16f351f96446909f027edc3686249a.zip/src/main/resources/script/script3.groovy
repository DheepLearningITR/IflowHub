/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    def body = '''<?xml version="1.0" encoding="ISO-8859-1"?>
<EnvioBOLETA version="1.0" xmlns="http://www.sii.cl/SiiDte" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sii.cl/SiiDte EnvioBOLETA_v11.xsd ">
	<SetDTE ID="SetDoc">
		<Caratula version="1.0">
			<RutEmisor>76255466-6</RutEmisor>
			<RutEnvia>12415975-K</RutEnvia>
			<RutReceptor>60803000-K</RutReceptor>
			<FchResol>2014-12-15</FchResol>
			<NroResol>0</NroResol>
			<TmstFirmaEnv>2020-06-04T10:42:35</TmstFirmaEnv>
			<SubTotDTE>
				<TpoDTE>39</TpoDTE>
				<NroDTE>1</NroDTE>
			</SubTotDTE>
		</Caratula>
		<DTE version="1.0">
			<Documento ID="F378T39">
				<Encabezado>
					<IdDoc>
						<TipoDTE>39</TipoDTE>
						<Folio>378</Folio>
						<FchEmis>2020-06-04</FchEmis>
						<IndServicio>1</IndServicio>
						<IndMntNeto>2</IndMntNeto>
						<FchVenc>2020-06-04</FchVenc>
					</IdDoc>
					<Emisor>
						<RUTEmisor>76255466-6</RUTEmisor>
						<RznSocEmisor>SAP Chile Limitada</RznSocEmisor>
						<GiroEmisor>Mineria</GiroEmisor>
					</Emisor>
					<Receptor>
						<RUTRecep>76821240-6</RUTRecep>
						<CdgIntRecep>CLIENTE_CL</CdgIntRecep>
						<RznSocRecep>Glencore Chile S.A.</RznSocRecep>
						<DirRecep>Calle Miguel Aguirre 280</DirRecep>
						<CmnaRecep>Ovalle</CmnaRecep>
						<CiudadRecep>Coquimbo</CiudadRecep>
						<DirPostal>Calle Miguel Aguirre 280</DirPostal>
						<CmnaPostal>Coquimbo</CmnaPostal>
						<CiudadPostal>Ovalle</CiudadPostal>
					</Receptor>
					<Totales>
						<MntNeto>8700</MntNeto>
						<IVA>1653</IVA>
						<MntTotal>10353</MntTotal>
					</Totales>
				</Encabezado>
				<Detalle>
					<NroLinDet>1</NroLinDet>
					<CdgItem>
						<TpoCodigo/>
						<VlrCodigo>CLMATERIAL001</VlrCodigo>
					</CdgItem>
					<NmbItem>Facturacion electronica Chile 001</NmbItem>
					<InfoTicket>
						<FolioTicket>1234</FolioTicket>
						<FchGenera>2020-06-04T08:42:35Z</FchGenera>
						<NmbEvento>Sample Event</NmbEvento>
						<TpoTicket>T1</TpoTicket>
						<CdgEvento>C1234</CdgEvento>
						<FchEvento>2020-06-04T08:42:35Z</FchEvento>
						<LugarEvento>Street1 street2 city1 city 2</LugarEvento>
						<UbicEvento>Street</UbicEvento>
					</InfoTicket>
					<QtyItem>1.0</QtyItem>
					<UnmdItem>ST</UnmdItem>
					<PrcItem>10000.0</PrcItem>
					<DescuentoMonto>1300</DescuentoMonto>
					<MontoItem>8700</MontoItem>
				</Detalle>
				<TED version="1.0">
					<DD>
						<RE>76255466-6</RE>
						<TD>39</TD>
						<F>378</F>
						<FE>2020-06-04</FE>
						<RR>76821240-6</RR>
						<RSR>Glencore Chile S.A.</RSR>
						<MNT>10353</MNT>
						<IT1>Facturacion electronica Chile 001</IT1>
						<CAF version="1.0">
							<DA>
								<RE>96853390-8</RE>
								<RS>ROBERT BOSCH S.A.</RS>
								<TD>39</TD>
								<RNG>
									<D>201</D>
									<H>500</H>
								</RNG>
								<FA>2017-11-03</FA>
								<RSAPK>
									<M>0c7jr/RZ2cUyXCoFT1PlJB3mkag4gIYOB9SK4G/9j/5Du8TbDEEyYbEiZaLQh3+kFfKtkJTYN71JCOCacyMiuQ==</M>
									<E>Aw==</E>
								</RSAPK>
								<IDK>300</IDK>
							</DA>
							<FRMA algoritmo="SHA1withRSA">FDlEcl3aDuGtrMn2M/Ya/m27cDzENzSSGqyJB7ZSsUM9kLG7WIzNxS+FMnmzcdZCDqCCsQ/qiT+cjb2AlpwShA==</FRMA>
						</CAF>
						<TSTED>2020-06-04T10:42:35</TSTED>
					</DD>
					<FRMT algoritmo="SHA1withRSA">vSHZJxHH6qZdDpSPh6YgF1O9/NiZdYOpJX4/lk+Oq9h7Ga87QWhayUrBzAmxkh8NKATzT2g+fU4Osf3EPGY63w==</FRMT>
				</TED>
				<TmstFirma>2020-06-04T10:42:35</TmstFirma>
			</Documento>
			<Signature xmlns="http://www.w3.org/2000/09/xmldsig#">
				<SignedInfo>
					<CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
					<SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>
					<Reference URI="#F378T39">
						<Transforms>
							<Transform Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
						</Transforms>
						<DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
						<DigestValue>dcK5MRYJrbD3Vj5t1BzGQ47+qFc=</DigestValue>
					</Reference>
				</SignedInfo>
				<SignatureValue>G5hn00kBA2GH6ENmaN/8SnRfZ+pp195dRUpMtdNfuKoObczJW6d/BCNB/AfylmGzoTjXUQv0wHE1hYedjd8Uz5IjkZ4MMH6/elDEaBx3eoOXhkGeo6PBkn//wq4CdmlGFcUjbHQP2Bkz8gy+qWGTWvGlFdnhja4ChFHMgj51fBQ=</SignatureValue>
				<KeyInfo>
					<KeyValue>
						<RSAKeyValue>
							<Modulus>3kRMcC+zNr0t54fsnx3x80wGMiELfZRsxseq2iXCzydFXLKABwgufR3ypwSmdeuY4FdcImb0SaLJSUTxHKhyIMt1nPbVaTvLkJJPOU/WxvQ18ShWgiPGSq+6+xYZDbOzlM9phvw3qV87R8JryhxEkwVReenJOJqVOElvE6qY5Ck=</Modulus>
							<Exponent>AQAB</Exponent>
						</RSAKeyValue>
					</KeyValue>
					<X509Data>
						<X509Certificate>MIIGPDCCBSSgAwIBAgIKOw5bQQAAAAjZWDANBgkqhkiG9w0BAQUFADCB0jELMAkGA1UEBhMCQ0wxHTAbBgNVBAgTFFJlZ2lvbiBNZXRyb3BvbGl0YW5hMREwDwYDVQQHEwhTYW50aWFnbzEUMBIGA1UEChMLRS1DRVJUQ0hJTEUxIDAeBgNVBAsTF0F1dG9yaWRhZCBDZXJ0aWZpY2Fkb3JhMTAwLgYDVQQDEydFLUNFUlRDSElMRSBDQSBGSVJNQSBFTEVDVFJPTklDQSBTSU1QTEUxJzAlBgkqhkiG9w0BCQEWGHNjbGllbnRlc0BlLWNlcnRjaGlsZS5jbDAeFw0xNzA5MDYxODQ3MDBaFw0yMDA5MDUxODQ3MDBaMIG/MQswCQYDVQQGEwJDTDEjMCEGA1UECBMaTUVUUk9QT0xJVEFOQSBERSBTQU5USUFHTyAxETAPBgNVBAcTCFNhbnRpYWdvMRswGQYDVQQKExJRdWFkcmVtIENoaWxlIEx0ZGExDDAKBgNVBAsTA1RheDEpMCcGA1UEAxMgTHVpcyBDYW1wb3MgQXZpbGVzIENhbXBvcyBBdmlsZXMxIjAgBgkqhkiG9w0BCQEWE2x1aXMuY2FtcG9zQHNhcC5jb20wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAN5ETHAvsza9LeeH7J8d8fNMBjIhC32UbMbHqtolws8nRVyygAcILn0d8qcEpnXrmOBXXCJm9EmiyUlE8RyociDLdZz21Wk7y5CSTzlP1sb0NfEoVoIjxkqvuvsWGQ2zs5TPaYb8N6lfO0fCa8ocRJMFUXnpyTialThJbxOqmOQpAgMBAAGjggKnMIICozA9BgkrBgEEAYI3FQcEMDAuBiYrBgEEAYI3FQiC3IMvhZOMZoXVnReC4twnge/sPGGBy54UhqiCWAIBZAIBBDAdBgNVHQ4EFgQUroXyslOOGbm6eM8XNSmLzQnL3JYwCwYDVR0PBAQDAgTwMB8GA1UdIwQYMBaAFHjhPp/SErN6PI3NMA5Ts0MpB7NVMD4GA1UdHwQ3MDUwM6AxoC+GLWh0dHA6Ly9jcmwuZS1jZXJ0Y2hpbGUuY2wvZWNlcnRjaGlsZWNhRkVTLmNybDA6BggrBgEFBQcBAQQuMCwwKgYIKwYBBQUHMAGGHmh0dHA6Ly9vY3NwLmVjZXJ0Y2hpbGUuY2wvb2NzcDAjBgNVHREEHDAaoBgGCCsGAQQBwQEBoAwWCjEyNDE1OTc1LUswIwYDVR0SBBwwGqAYBggrBgEEAcEBAqAMFgo5NjkyODE4MC01MIIBTQYDVR0gBIIBRDCCAUAwggE8BggrBgEEAcNSBTCCAS4wLQYIKwYBBQUHAgEWIWh0dHA6Ly93d3cuZS1jZXJ0Y2hpbGUuY2wvQ1BTLmh0bTCB/AYIKwYBBQUHAgIwge8egewAQwBlAHIAdABpAGYAaQBjAGEAZABvACAARgBpAHIAbQBhACAAUwBpAG0AcABsAGUALgAgAEgAYQAgAHMAaQBkAG8AIAB2AGEAbABpAGQAYQBkAG8AIABlAG4AIABmAG8AcgBtAGEAIABwAHIAZQBzAGUAbgBjAGkAYQBsACwAIABxAHUAZQBkAGEAbgBkAG8AIABoAGEAYgBpAGwAaQB0AGEAZABvACAAZQBsACAAQwBlAHIAdABpAGYAaQBjAGEAZABvACAAcABhAHIAYQAgAHUAcwBvACAAdAByAGkAYgB1AHQAYQByAGkAbzANBgkqhkiG9w0BAQUFAAOCAQEAbUKOB+kxLbEwbDCxPHKAx5kVRYnToMHUhuNY3FI1D2+oNAj0Is5/Wt+UXPe0RHD/i0X7zlSlGlX7UxLBoNoP2XckaZVP00rzZx3uAMx7bJNQZmoyQL2aCQ4K7gMQe5edh2TRMiZ9G4AXEeiuTA8OGju1ScsUrhD6wZHeNz0Q5SSF3dF763SGMnKFfNzRtZEBCzjOt9IKeqyHYIx+n8ARmVJxPWTB4ZhIe4og/VBngZh+51XVQAvfF+1rH9bmXjL13dBbWOJKIovfGnuDYVZaPsTP7R2Mk5zW8MLLFVz/yM552zio5q2w07FvABu30dAE5K9mc8aHdJCih4LPXpde2Q==</X509Certificate>
					</X509Data>
				</KeyInfo>
			</Signature>
		</DTE>
	</SetDTE>
	<Signature xmlns="http://www.w3.org/2000/09/xmldsig#">
		<SignedInfo>
			<CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
			<SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>
			<Reference URI="#SetDoc">
				<Transforms>
					<Transform Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
				</Transforms>
				<DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
				<DigestValue>DUBzGIClr6of9Y8bjHTNnJmkr0w=</DigestValue>
			</Reference>
		</SignedInfo>
		<SignatureValue>uj41wT2ID7g2x4RSZ7SOn77iV0e3LzJR8TPKLyJgE3FgpmpvtrqzfMyLkJ7WTCUcxBZyF3UxCNb06wWDZgnQFmtVMagPOsC9i0V+gY3sjUiT7s12LlAz0vucD3FW4DFGX3S6c+xeODgJROijkjukUE+EAvfB4EIf8dC6qW0DBmU=</SignatureValue>
		<KeyInfo>
			<KeyValue>
				<RSAKeyValue>
					<Modulus>3kRMcC+zNr0t54fsnx3x80wGMiELfZRsxseq2iXCzydFXLKABwgufR3ypwSmdeuY4FdcImb0SaLJSUTxHKhyIMt1nPbVaTvLkJJPOU/WxvQ18ShWgiPGSq+6+xYZDbOzlM9phvw3qV87R8JryhxEkwVReenJOJqVOElvE6qY5Ck=</Modulus>
					<Exponent>AQAB</Exponent>
				</RSAKeyValue>
			</KeyValue>
			<X509Data>
				<X509Certificate>MIIGPDCCBSSgAwIBAgIKOw5bQQAAAAjZWDANBgkqhkiG9w0BAQUFADCB0jELMAkGA1UEBhMCQ0wxHTAbBgNVBAgTFFJlZ2lvbiBNZXRyb3BvbGl0YW5hMREwDwYDVQQHEwhTYW50aWFnbzEUMBIGA1UEChMLRS1DRVJUQ0hJTEUxIDAeBgNVBAsTF0F1dG9yaWRhZCBDZXJ0aWZpY2Fkb3JhMTAwLgYDVQQDEydFLUNFUlRDSElMRSBDQSBGSVJNQSBFTEVDVFJPTklDQSBTSU1QTEUxJzAlBgkqhkiG9w0BCQEWGHNjbGllbnRlc0BlLWNlcnRjaGlsZS5jbDAeFw0xNzA5MDYxODQ3MDBaFw0yMDA5MDUxODQ3MDBaMIG/MQswCQYDVQQGEwJDTDEjMCEGA1UECBMaTUVUUk9QT0xJVEFOQSBERSBTQU5USUFHTyAxETAPBgNVBAcTCFNhbnRpYWdvMRswGQYDVQQKExJRdWFkcmVtIENoaWxlIEx0ZGExDDAKBgNVBAsTA1RheDEpMCcGA1UEAxMgTHVpcyBDYW1wb3MgQXZpbGVzIENhbXBvcyBBdmlsZXMxIjAgBgkqhkiG9w0BCQEWE2x1aXMuY2FtcG9zQHNhcC5jb20wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAN5ETHAvsza9LeeH7J8d8fNMBjIhC32UbMbHqtolws8nRVyygAcILn0d8qcEpnXrmOBXXCJm9EmiyUlE8RyociDLdZz21Wk7y5CSTzlP1sb0NfEoVoIjxkqvuvsWGQ2zs5TPaYb8N6lfO0fCa8ocRJMFUXnpyTialThJbxOqmOQpAgMBAAGjggKnMIICozA9BgkrBgEEAYI3FQcEMDAuBiYrBgEEAYI3FQiC3IMvhZOMZoXVnReC4twnge/sPGGBy54UhqiCWAIBZAIBBDAdBgNVHQ4EFgQUroXyslOOGbm6eM8XNSmLzQnL3JYwCwYDVR0PBAQDAgTwMB8GA1UdIwQYMBaAFHjhPp/SErN6PI3NMA5Ts0MpB7NVMD4GA1UdHwQ3MDUwM6AxoC+GLWh0dHA6Ly9jcmwuZS1jZXJ0Y2hpbGUuY2wvZWNlcnRjaGlsZWNhRkVTLmNybDA6BggrBgEFBQcBAQQuMCwwKgYIKwYBBQUHMAGGHmh0dHA6Ly9vY3NwLmVjZXJ0Y2hpbGUuY2wvb2NzcDAjBgNVHREEHDAaoBgGCCsGAQQBwQEBoAwWCjEyNDE1OTc1LUswIwYDVR0SBBwwGqAYBggrBgEEAcEBAqAMFgo5NjkyODE4MC01MIIBTQYDVR0gBIIBRDCCAUAwggE8BggrBgEEAcNSBTCCAS4wLQYIKwYBBQUHAgEWIWh0dHA6Ly93d3cuZS1jZXJ0Y2hpbGUuY2wvQ1BTLmh0bTCB/AYIKwYBBQUHAgIwge8egewAQwBlAHIAdABpAGYAaQBjAGEAZABvACAARgBpAHIAbQBhACAAUwBpAG0AcABsAGUALgAgAEgAYQAgAHMAaQBkAG8AIAB2AGEAbABpAGQAYQBkAG8AIABlAG4AIABmAG8AcgBtAGEAIABwAHIAZQBzAGUAbgBjAGkAYQBsACwAIABxAHUAZQBkAGEAbgBkAG8AIABoAGEAYgBpAGwAaQB0AGEAZABvACAAZQBsACAAQwBlAHIAdABpAGYAaQBjAGEAZABvACAAcABhAHIAYQAgAHUAcwBvACAAdAByAGkAYgB1AHQAYQByAGkAbzANBgkqhkiG9w0BAQUFAAOCAQEAbUKOB+kxLbEwbDCxPHKAx5kVRYnToMHUhuNY3FI1D2+oNAj0Is5/Wt+UXPe0RHD/i0X7zlSlGlX7UxLBoNoP2XckaZVP00rzZx3uAMx7bJNQZmoyQL2aCQ4K7gMQe5edh2TRMiZ9G4AXEeiuTA8OGju1ScsUrhD6wZHeNz0Q5SSF3dF763SGMnKFfNzRtZEBCzjOt9IKeqyHYIx+n8ARmVJxPWTB4ZhIe4og/VBngZh+51XVQAvfF+1rH9bmXjL13dBbWOJKIovfGnuDYVZaPsTP7R2Mk5zW8MLLFVz/yM552zio5q2w07FvABu30dAE5K9mc8aHdJCih4LPXpde2Q==</X509Certificate>
			</X509Data>
		</KeyInfo>
	</Signature>
</EnvioBOLETA>
''';
    
       message.setBody(body);
       return message;
}