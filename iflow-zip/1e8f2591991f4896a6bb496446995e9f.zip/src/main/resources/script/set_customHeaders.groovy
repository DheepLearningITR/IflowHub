import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
	    def testRun = message.getHeaders().get("testRun");
		if(testRun != null && testRun != 'false' && testRun != ''){
			messageLog.addCustomHeaderProperty("cbr_testRun", testRun);		
        }
        def familyCode = message.getProperties().get("sfsfJobFamilyCode");
		if(familyCode != null){
			messageLog.addCustomHeaderProperty("sfsf_jobFamilyCode", familyCode);		
        }
		def cbrJobFamilyId = message.getProperties().get("cbrJobFamilyId");
		if(cbrJobFamilyId!=null){
			messageLog.addCustomHeaderProperty("cbr_JobFamilyId", cbrJobFamilyId);		
        }
	}
	return message;
}