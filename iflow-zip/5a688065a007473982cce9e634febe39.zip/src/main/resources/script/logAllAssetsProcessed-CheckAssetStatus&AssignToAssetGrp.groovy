import com.sap.gateway.ip.core.customdev.util.Message
def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def errorMsg = "IBP-Everstream Assets are in Sync!"
 
    if(messageLog != null) {
    	messageLog.addAttachmentAsString("Success - No Location(s) in PENDING Status", errorMsg, "text/plain")
     }
	return message
}
