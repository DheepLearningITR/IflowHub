import com.sap.gateway.ip.core.customdev.util.Message
def Message processData(Message message) {
   def body = message.getBody()
   sleep(10000)
   message.setBody(body)
   return message
}