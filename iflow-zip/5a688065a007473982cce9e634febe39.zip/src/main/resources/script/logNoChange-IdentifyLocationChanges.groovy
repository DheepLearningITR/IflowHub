import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
def properties = message.getProperties()
def commaSpace = ", "
def commaNewline = ",\n"
def locIdsWithSpaces = properties.get('ID_WITH_SPACES')?.toString().replaceAll(commaSpace, commaNewline)
def locIdsWith0Geo = properties.get('ID_WITH_0_GEO')?.toString().replaceAll(commaSpace, commaNewline)
def locIdsWithOobGeo = properties.get('ID_WITH_OOB_GEO')?.toString().replaceAll(commaSpace, commaNewline)
def messageLog = messageLogFactory.getMessageLog(message)
def successMsg = "Success - No IBP Location(s) Added/Changed"
def successMsgBody = "All IBP locations are in Sync with Everstream!"
def invalidIbpLocationsIds = "Please Check - IBP Location(s) with Invalid Data!"
def msgLogFormat = "text/plain"

def invalidIbpPayloads = formatInvalidIBPLocationMsg(locIdsWithSpaces, locIdsWith0Geo, locIdsWithOobGeo)

if(messageLog != null) {
    messageLog.addAttachmentAsString(successMsg, successMsgBody, msgLogFormat)
}
if(messageLog != null && (locIdsWithSpaces.length()>0 || locIdsWith0Geo.length()>0 || locIdsWithOobGeo.length()>0)) {
    messageLog.addAttachmentAsString(invalidIbpLocationsIds, invalidIbpPayloads.toString(), msgLogFormat)
}
return message
}

def formatInvalidIBPLocationMsg(locIdsWithSpaces, locIdsWith0Geo, locIdsWithOobGeo) {
    
def idsWithSpaceMsg = "Please check, following IBP IDs have spaces in them:\n"
def idsWith0GeoMsg = "\n\nPlease check, following IBP IDs have invalid geo-coordinates:\n"
def idsWithOobMsg = "\n\nPlease check, following IBP IDs have geo-coordinates that are out of range:\n"
def sInvalidMsg =  idsWithSpaceMsg+locIdsWithSpaces+idsWith0GeoMsg+locIdsWith0Geo+idsWithOobMsg+locIdsWithOobGeo
return sInvalidMsg
    
}