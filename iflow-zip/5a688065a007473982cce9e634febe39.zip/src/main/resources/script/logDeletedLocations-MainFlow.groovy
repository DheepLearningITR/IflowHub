import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message)
	def properties = message.getProperties();
	def listOfDeletedItems = properties.get("DELETED_ASSET_IDs")
	def prefix = properties.get("PREFIX")
	def mdtName = properties.get("MDT")
	def separator = properties.get("SEPARATOR")
	
	def sListOfDeletedLocs = listOfDeletedItems.split(",")
	def sPrefix = prefix.toString()
	def sMDTName = mdtName.toString()
	def sSeparator = separator.toString()
	
	def successNoIBPLocDelMsg = "Success - No IBP Location(s) Deleted"
	def successNoIBPLocDelMsgBdy = "All IBP locations are in Sync with Everstream!"
	def messageLogFormat = "text/plain"
	
	
	def formattedIDs = sListOfDeletedLocs.collect { input ->
	    formatIDs(input, sPrefix, sMDTName, sSeparator)
	}
	
	def formattedIDSize = formattedIDs.findAll { it != null && it.trim() }
	
	
	def numOfLocDel = "Number of Locations Deleted: " + formattedIDSize.size() + "\n\n"
	def delLocs = "Deleted Locations: \n\n" + formattedIDs.join("\n").replaceAll("\"", "")
	
	
	def sResult =  numOfLocDel + delLocs

    if(messageLog != null  && formattedIDSize.size() == 0) {
        
        messageLog.addAttachmentAsString(successNoIBPLocDelMsg, successNoIBPLocDelMsgBdy, messageLogFormat)
        
    }
    
    if(messageLog != null && formattedIDSize.size() > 0) {
	
	    messageLog.addAttachmentAsString("Success - Deleted Location(s)", sResult.toString(), messageLogFormat)
	    
     }
	
	return message
}



def formatIDs(input, sPrefix, sMDTName, sSeparator) {
    
    def withoutPrefix = ""
    def withoutMDTName = ""
    def defaultSeparator = "-"
    
    if(!(sPrefix.isEmpty() || sSeparator.isEmpty())) {

     withoutPrefix = input.replaceAll(sPrefix + sSeparator, "")
     withoutMDTName = withoutPrefix.replaceAll(sMDTName + sSeparator, "")
    
    } else if (sPrefix.isEmpty() && !sSeparator.isEmpty()) {

        withoutMDTName = input.replaceAll(sMDTName + sSeparator, "")
        
    } else if (!sPrefix.isEmpty() && sSeparator.isEmpty()) {

        withoutPrefix = input.replaceAll(sPrefix + defaultSeparator, "")
        withoutMDTName = withoutPrefix.replaceAll(sMDTName + defaultSeparator, "")
        
    } else {

        withoutMDTName = input.replaceAll(sMDTName + defaultSeparator, "")

    }
    return withoutMDTName
    
}
