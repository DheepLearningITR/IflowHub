/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def properties = message.getProperties()
    def ibpLocations = properties.get("IBP_LOCATIONS_LIST") //Added def
    def everstreamLocations = properties.get("EVERSTREAM_LOCATIONS_LIST") //Added def
    def ibpLocationsParsed = new XmlParser().parse(new StringReader(ibpLocations.trim()))
    def everstreamLocationsParsed = new XmlParser().parse(new StringReader(everstreamLocations.trim()))
    def ibpLocs = ibpLocationsParsed.LOCATION
    def everstreamLocs = everstreamLocationsParsed.LOCATION
    def modifiedLocations = []
    
    ibpLocs.each { ibpLocs1 ->
        def id2 = ibpLocs1.ID.text()
        def matched = false
    
        everstreamLocs.each { everstreamLocs1 ->
            def id1 = everstreamLocs1.ID.text()
            if (id1 == id2) {
                if (!compareElements(everstreamLocs1, ibpLocs1)) {
                    modifiedLocations << ibpLocs1
                }
                matched = true
            }
        }
    
        if (!matched) {
            modifiedLocations << ibpLocs1
        }
    }
    
    def changedXML = new StringBuilder()
    changedXML.append('<?xml version="1.0" encoding="UTF-8"?>\n<LOCATIONS>\n')
    modifiedLocations.each { changedXML.append(groovy.xml.XmlUtil.serialize(it) + '\n') }
    changedXML.append('</LOCATIONS>\n')
    message.setProperty("NO_OF_MODIFIED_LOCs", modifiedLocations.size().toString())
    message.setBody(changedXML.toString())
    return message
}

def compareElements(element1, element2) {
    def children1 = element1.children()
    def children2 = element2.children()

    if (children1.size() != children2.size()) {
        return false
    }

    for (int i = 0; i < children1.size(); i++) {
        def child1 = children1[i]
        def child2 = children2[i]

        if (child1.name() != child2.name()||child1.text() != child2.text()) {
            return false
        }
    }

    return true
}
