import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def body = message.getBody(String)
    def statusChangedLocsParsed = new XmlParser().parse(new StringReader(body))
    def properties = message.getProperties()
    def prefix = properties.get("PREFIX")
    def mdtName = properties.get("MDT")
    def separator = properties.get("SEPARATOR")
    def sPrefix = prefix.toString()
    def sMDTName = mdtName.toString()
    def sSeparator = separator.toString()
    def ibpId = ""
    def assetId = ""
    def status = ""
    def eventUri = ""
    def errorMessage = ""
    def result = ""

    statusChangedLocsParsed.each { locations ->
        locations.LOCATION.each { loc ->
			assetId = loc.ID.text()
			ibpId = formatIDs(assetId, sPrefix, sMDTName, sSeparator)
			status = loc.STATUS.text()
			eventUri = loc.EVENT_URI.text()
			errorMessage = loc.MESSAGE.text()
		
			result +="""
			IBP ID: $ibpId
			Asset ID: $assetId
			STATUS: $status
			Everstream Event URI: $eventUri
			Message: $errorMessage
			"""
			}
        
    }
    
    result = result.replaceAll('[\t ]+',' ')

    //message.setProperty('PENDING_ERROR_DETAILED_INFO', result.toString())
    message.setBody(result.toString())
    binding.variables.clear() //Purging all variables used in the script
    return message
}


def formatIDs(input, sPrefix, sMDTName, sSeparator) {
    def withoutPrefix = ""
    def withoutMDTName = ""
    def defaultSeparator = "-"
    
    if(!(sPrefix.isEmpty() || sSeparator.isEmpty())) {

     withoutPrefix = input.replaceAll(sPrefix + sSeparator, "")
     withoutMDTName = withoutPrefix.replaceAll(sMDTName + sSeparator, "")
    
    } else if (sPrefix.isEmpty() && !sSeparator.isEmpty()) {

        withoutMDTName = input.replaceAll(sMDTName + sSeparator, "")
        
    } else if (!sPrefix.isEmpty() && sSeparator.isEmpty()) {

        withoutPrefix = input.replaceAll(sPrefix + defaultSeparator, "")
        withoutMDTName = withoutPrefix.replaceAll(sMDTName + defaultSeparator, "")
        
    } else {

        withoutMDTName = input.replaceAll(sMDTName + defaultSeparator, "")

    }    
    return withoutMDTName    
}