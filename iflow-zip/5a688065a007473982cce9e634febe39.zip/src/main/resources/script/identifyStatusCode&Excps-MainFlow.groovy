import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*


def Message processData(Message message) {
    def errorMessage = ""
    def map = message.getProperties()
    def ex = map.get("CamelExceptionCaught")
    def httpStatusText = "HTTP_STATUSTXT"
    def httpStatusCode = "HTTP_STATUSCODE"
    def oDataExceptionClass = "com.sap.gateway.core.ip.component.odata.exception.OsciException"
    def httpExceptionClass = "org.apache.camel.component.ahc.AhcOperationFailedException"
    
if (ex && ex.getClass().getCanonicalName() == httpExceptionClass) {
     
    def body = ex.getResponseBody().toString()
       
   if(body) {
    def statusCode = ex.getStatusCode().toString()

    switch(statusCode) { 
        case "400": 
            def httpResponseStr400 = new JsonSlurper().parse(new StringReader(body))
            errorMessage = handle400Errors(httpResponseStr400, body)
			break

        case "404": 
			errorMessage = "Not Found: The server cannot find the requested resource."
			break
			
		case "401": 
			def httpResponseStr401 = new JsonSlurper().parse(new StringReader(body))
			errorMessage = handle401Errors(httpResponseStr401)
			break
		
		case "405": 
			def httpResponseStr405 = new JsonSlurper().parse(new StringReader(body))
			errorMessage = handle405Errors(httpResponseStr405)
			break
			
		case "500": 
			def httpResponseStr500 = new JsonSlurper().parse(new StringReader(body))
			errorMessage = handle500Errors(httpResponseStr500)
			break
		default:
			errorMessage = "\n This error response is a generic \"catch-all\" response. "
			break
		}
    
    
    //Update Properties 
    message.setProperty(httpStatusCode , statusCode ? statusCode : 'Not Available')
    message.setProperty(httpStatusText , ex.getStatusText() ? ex.getStatusText() : 'Not Available')
    message.setProperty("EX_RESPONSEBODY" , body ? body : 'Not Available')
    message.setProperty("EX_MSG" , ex.getMessage() ? ex.getMessage() : 'Not Available')
    
    message.setBody(errorMessage.toString())
    }
 } else if (ex.getClass().getCanonicalName() == oDataExceptionClass) {
        
    
    def httpResponseCode = message.getHeaders().get("CamelHttpResponseCode")
    def httpResponseBody = message.getBody(java.io.Reader).toString()
    def httpResponseBodyResult = ''
    
    if(httpResponseBody) {
        new JsonSlurper().parse(new StringReader(httpResponseBody))    
    }
    
    if(httpResponseCode != "null") {
      message.setProperty(httpStatucCode , httpResponseCode ? httpResponseCode : 'Not Available')
      message.setProperty(httpStatusText , httpResponseBodyResult ? httpResponseBodyResult : 'Not Available')
    }
    
    message.setProperty("EX_MSG" , ex.getMessage() ? ex.getMessage() : '')
     
    message.setBody("ODATA Error - Check Stack Trace Below \nRequested URI: " + ex.getRequestUri())
}

 binding.variables.clear() //Purging all variables used in the script
 return message
}


def handle400Errors(httpResponseStr, body) {
    def errors = httpResponseStr.errors
    def errorMessage
    
    if(httpResponseStr.toString().contains("field is required") || 
        httpResponseStr.toString().contains("field may not be blank")) {
        errorMessage = errors.collect { error ->
        def fieldName = error.code.replaceAll('\\.blank|\\.required', '')
        def message = error.message

        "<$fieldName>: $message"
        }.join(" ")
    }
    else if (httpResponseStr.toString().contains("JSON parse error")) {
        errorMessage = "Error in parsing the JSON payload."
    } else if(httpResponseStr.toString().contains("already exists")) {
        errorMessage = httpResponseStr.errors.message.toString()
    } else {
        errorMessage = body
    }

    return errorMessage
}

def handle401Errors(httpResponseStr) {
    return errorMessage = httpResponseStr.detail.toString()
}

def handle405Errors(httpResponseStr) {
    return errorMessage = httpResponseStr.detail.toString()
}

def handle500Errors(httpResponseStr) {
    return errorMessage = httpResponseStr.errors.message.toString()
}









