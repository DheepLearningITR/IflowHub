import com.sap.gateway.ip.core.customdev.util.Message
def Message processData(Message message) {
	def body = message.getBody(java.lang.String) as String
	def properties = message.getProperties()
	def payload = properties.get("PAYLOAD")
	def logMsgFormat = "text/plain"
	def logMsgExpInfo = "Check Asset Status Subflow - Exception Info"
	def logMsgFailedPayload = "Check Asset Status Subflow - Failed Payload"
	def messageLog = messageLogFactory.getMessageLog(message)
	if(messageLog != null) {
    	messageLog.addAttachmentAsString(logMsgExpInfo, body, logMsgFormat)
    	messageLog.addAttachmentAsString(logMsgFailedPayload, payload.toString(), logMsgFormat)
     }
	return message
}