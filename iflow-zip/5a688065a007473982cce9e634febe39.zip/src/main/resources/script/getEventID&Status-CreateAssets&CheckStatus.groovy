import com.sap.gateway.ip.core.customdev.util.Message
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def jsonSlurper = new groovy.json.JsonSlurper()
    def jsonBody = jsonSlurper.parse(new StringReader(body))
    def eventID = jsonBody.event.id
    def eventStatus = jsonBody.event.status
	message.setProperty("EVENT_ID", eventID)
	message.setProperty("EVENT_STATUS", eventStatus)
	return message
}