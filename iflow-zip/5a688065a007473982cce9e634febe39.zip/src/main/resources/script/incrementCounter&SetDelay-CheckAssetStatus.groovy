import com.sap.gateway.ip.core.customdev.util.Message
def Message processData(Message message) {
    def properties = message.getProperties()
	def loopCounterKey = 'LOOP_COUNTER'
	def pendingLocsCountKey = 'PENDING_LOCATIONS_COUNT'
	def stuckInPendingKey = 'STUCK_IN_PENDING'
	def zeroKey = '0'
	def yesKey = 'Yes'
    def defaultCounter = properties.get(loopCounterKey)?: zeroKey
	def currentCounter = defaultCounter.toInteger() + 1
	message.setProperty(loopCounterKey, currentCounter.toString())
	
	switch(currentCounter) {
	
		case 1: break;
		case 2: sleep(1000)
				break;
		case 3: sleep(180000)
				break;
		case 4: sleep(600000)
				break;
		case 5: sleep(900000)
				break;
		case 6: sleep(1800000)
				break;
	    case 7: message.setProperty(pendingLocsCountKey, zeroKey)
	            message.setProperty(stuckInPendingKey, yesKey)
				break;
		default: 
		message.setProperty(pendingLocsCountKey, zeroKey)
	    message.setProperty(stuckInPendingKey, yesKey)
		break;
	}
    binding.variables.clear() //Purging all variables used in the script
	return message
}