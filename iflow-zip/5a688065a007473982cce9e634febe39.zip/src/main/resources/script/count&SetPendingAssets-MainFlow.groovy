import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def pendingLocsCountKey = 'PENDING_LOCATIONS_COUNT'
	def pendingLocsKey = 'PENDING_LOCATIONS'
    def body = message.getBody(java.lang.String) as String
    def pendingLocationsParsed = new XmlParser().parse(new StringReader(body))
    def numberOfPendingLocs = pendingLocationsParsed.LOCATION.size()
    
	message.setProperty(pendingLocsCountKey, numberOfPendingLocs)
	if(numberOfPendingLocs == 0) {
	    message.setProperty(pendingLocsKey, "")
	} else {
	    message.setProperty(pendingLocsKey, body)
	}
	
	message.setBody("")
	binding.variables.clear() //Purging all variables used in the script
    return message
}
