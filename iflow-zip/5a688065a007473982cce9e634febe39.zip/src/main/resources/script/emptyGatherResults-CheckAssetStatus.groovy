import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
	message.setProperty('GATHER_RESULT', "")
	binding.variables.clear() //Purging all variables used in the script
    return message
}
