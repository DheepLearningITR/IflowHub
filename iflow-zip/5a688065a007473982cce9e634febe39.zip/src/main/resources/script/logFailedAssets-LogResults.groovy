import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
def messageLog = messageLogFactory.getMessageLog(message)
def properties = message.getProperties()
def listOfFailedItems = properties.get("FAILED_ASSETS")
def prefix = properties.get("PREFIX").toString()
def mdtName = properties.get("MDT").toString()
def separator = properties.get("SEPARATOR").toString()
def messageLogFormat = "text/plain"
def successLogMsg = "Success - No Failures in Location(s) Processing"
def successLogMsgBody = "All IBP locations are in Sync with Everstream!"
def formattedIDSize = []
def sFailedLocs
def sResult
if(listOfFailedItems) {
    sFailedLocs = listOfFailedItems.split(",")
    
    def formattedIDs = sFailedLocs.collect { input ->
        formatIDs(input, prefix, mdtName, separator)
    }
    formattedIDSize = formattedIDs.findAll { it != null && it.trim() }
    def numberOfLocFailedProcessing = "Number of Locations Failed to be Processed: " + formattedIDSize.size()
    def failedLocs = "\n\nFailed Locations: \n\n" + formattedIDs.join("\n").replaceAll("\"", "")
    sResult = numberOfLocFailedProcessing + failedLocs
}

if(messageLog != null && formattedIDSize.size() == 0) {
    messageLog.addAttachmentAsString(successLogMsg, successLogMsgBody, messageLogFormat)
} 

if(messageLog != null && formattedIDSize.size() > 0) {
	messageLog.addAttachmentAsString("Location(s) Failed to be Processed", sResult.toString(), messageLogFormat)
}
	return message
}

def formatIDs(input, sPrefix, sMDTName, sSeparator) {
    
    def withoutPrefix = ""
    def withoutMDTName = ""
    def defaultSeparator = "-"
    
    if(!(sPrefix.isEmpty() || sSeparator.isEmpty())) {

     withoutPrefix = input.replaceAll(sPrefix + sSeparator, "")
     withoutMDTName = withoutPrefix.replaceAll(sMDTName + sSeparator, "")
    
    } else if (sPrefix.isEmpty() && !sSeparator.isEmpty()) {

        withoutMDTName = input.replaceAll(sMDTName + sSeparator, "")
        
    } else if (!sPrefix.isEmpty() && sSeparator.isEmpty()) {

        withoutPrefix = input.replaceAll(sPrefix + defaultSeparator, "")
        withoutMDTName = withoutPrefix.replaceAll(sMDTName + defaultSeparator, "")
        
    } else {

        withoutMDTName = input.replaceAll(sMDTName + defaultSeparator, "")

    }
    return withoutMDTName
    
}

