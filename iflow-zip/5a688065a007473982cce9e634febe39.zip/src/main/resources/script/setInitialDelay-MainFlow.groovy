import com.sap.gateway.ip.core.customdev.util.Message
def Message processData(Message message) {
	def thousandSeconds = 1000
    def initialDelay = 0
    def properties = message.getProperties()
    def intervalInSecs = properties.get('INITIAL_DELAY_IN_SEC')
	//def intervalInMs = intervalInSecs.toLong() * thousandSeconds
	def body = message.getBody(String) as String    
    def xmlParsed = new XmlParser().parse(new StringReader(body))    
    def loadSize = xmlParsed.LOCATION.size()
	
	if(intervalInSecs && intervalInSecs.toInteger() > 0) {
	    initialDelay =  intervalInSecs.toLong() * thousandSeconds
	}
	
	if(!initialDelay) {
	    
	    switch(loadSize) {
            case { it = 0 }: break
            case { it < 100 }: initialDelay = 180000 //3min
                break
            case { it < 500 }: initialDelay = 300000 //5min
                break
            case { it <= thousandSeconds }: initialDelay = 600000 //10min
                break
            default: initialDelay = 3600000 //60min
        }
	}
	
	sleep(initialDelay)
	
	message.setProperty('INITIAL_DELAY', initialDelay)
	binding.variables.clear() //Purging all variables used in the script
	return message
}
