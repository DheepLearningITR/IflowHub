import com.sap.gateway.ip.core.customdev.util.Message
def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def body = message.getBody(String)
	def errorMsg = "Locations Not Processed:\n"+body
 
    if(messageLog != null) {
    	messageLog.addAttachmentAsString("Failed - Location(s) Not Processed", errorMsg, "text/plain")
     }
	return message
}
