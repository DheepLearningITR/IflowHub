import com.sap.gateway.ip.core.customdev.util.Message
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def jsonSlurper = new groovy.json.JsonSlurper()
    def jsonBody = jsonSlurper.parse(new StringReader(body))
    def eventStatus = jsonBody.status
	message.setProperty("EVENT_STATUS", eventStatus)
	message.setProperty("EVENT_RESPONSE_BODY", body)
	binding.variables.clear() //Purging all variables used in the script
	return message
}