import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {  
    
    def properties = message.getProperties()
    def ibpLocListPropName = 'IBP_LOCATIONS_LIST'
    def ibpLocationList = properties.get(ibpLocListPropName)
    def ibpLocations = new XmlSlurper().parse(new StringReader(ibpLocationList))
    def idsWithSpaces = []
    def idsWith0Geos = []
    def idsWithOutOfBoundGeos = []
    def locationIdsWithSpaces
    def locationIdsWith0Geo
    def locationIdsWithOobGeo
    def xmlResult
    def zeroGeoCoordinates = '0.000000'
    def commaSpace = ', '
    
    ibpLocations.LOCATION.each { location ->
        def id = location.ID.text()
        def latitude = location.LATITUDE.text()
        def longitude = location.LONGITUDE.text()
        def dLat = latitude.toDouble()
        def dLong = longitude.toDouble()
        
        if(id.contains(" ")) {
            idsWithSpaces << id
        }
        
        if(latitude == zeroGeoCoordinates || longitude == zeroGeoCoordinates) {
            idsWith0Geos << id
        }
        
        if(dLat < -90 || dLat > 90 || dLong < -180 || dLong > 180) {
            idsWithOutOfBoundGeos << id
        }
        
    }
    
    locationIdsWithSpaces = idsWithSpaces.join(commaSpace)
    locationIdsWith0Geo = idsWith0Geos.join(commaSpace)
    locationIdsWithOobGeo = idsWithOutOfBoundGeos.join(commaSpace)
    
    //Remove locations with fault and re-create Xml
    idsWithSpaces.each { id ->
        ibpLocations.LOCATION.find { it.ID.text() == id }?.replaceNode {}
    }
    
    idsWith0Geos.each { id ->
        ibpLocations.LOCATION.find { it.ID.text() == id }?.replaceNode {}
    }
    
    idsWithOutOfBoundGeos.each { id ->
        ibpLocations.LOCATION.find { it.ID.text() == id }?.replaceNode {}
    }
    
    xmlResult = groovy.xml.XmlUtil.serialize(ibpLocations)
    
    //Update properties
    message.setProperty(ibpLocListPropName, xmlResult)
    message.setProperty('ID_WITH_SPACES', locationIdsWithSpaces)
    message.setProperty('ID_WITH_0_GEO', locationIdsWith0Geo)
    message.setProperty('ID_WITH_OOB_GEO', locationIdsWithOobGeo)
    
    
    //UpdateEmpty Body
    message.setBody("")
return message;
}