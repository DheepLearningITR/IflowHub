import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
def Message processData(Message message) {
def properties = message.getProperties()
def responseBody = properties.get('EVENT_RESPONSE_BODY')
def jsonSlurper = new groovy.json.JsonSlurper()
def responseBodyParsed = jsonSlurper.parse(new StringReader(responseBody))
def errorMsg = "The processing time exceeded maxiumum duration. 'PENDING' status is now assumed as 'ERROR'."

if(!responseBodyParsed.result) {
    responseBodyParsed.result = [:]
}
responseBodyParsed.status = "ERROR"
responseBodyParsed.result.message = errorMsg
def jsonResult = JsonOutput.toJson(responseBodyParsed)
//message.setProperty('MODIFIED_EVENT_RESPONSE', jsonResult)
message.setBody(jsonResult.toString())
return message
}