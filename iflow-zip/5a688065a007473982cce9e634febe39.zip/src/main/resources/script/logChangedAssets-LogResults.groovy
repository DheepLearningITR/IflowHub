import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
	
def messageLog = messageLogFactory.getMessageLog(message)
def properties = message.getProperties()
def assetGroupName = properties.get("ASSET_GROUP_NAME")
def listOfModifiedItems = properties.get("ASSET_ID_LIST")
def prefix = properties.get("PREFIX")
def mdtName = properties.get("MDT")
def separator = properties.get("SEPARATOR")
def sModifiedLocs
def sPrefix = prefix.toString()
def sMDTName = mdtName.toString()
def sSeparator = separator.toString()
def messageLogFormat = "text/plain"
def successMsgLog = "Success - No IBP Location(s) Added/Changed"
def successMsgLogBody = "All IBP locations are in Sync with Everstream!"
def numberofLocationAssignedMsg = "Number of Added/Changed Locations Assigned to "
def formattedIDSize = []
def sResult

if(listOfModifiedItems) {
    sModifiedLocs = listOfModifiedItems.split(",")
    def formattedIDs = sModifiedLocs.collect { input ->
        formatIDs(input, sPrefix, sMDTName, sSeparator)
    }
     formattedIDSize = formattedIDs.findAll { it != null && it.trim() }
    def numOfLocChangedAdded = numberofLocationAssignedMsg + assetGroupName +" : " + formattedIDSize.size()
    def changedAddedLocs = "\n\nAdded/Changed Locations: \n\n" + formattedIDs.join("\n").replaceAll("\"", "")
    sResult = numOfLocChangedAdded + changedAddedLocs
}

if(messageLog != null && formattedIDSize.size() == 0) {
    	messageLog.addAttachmentAsString(successMsgLog, successMsgLogBody, messageLogFormat)
} 

if(messageLog != null && formattedIDSize.size() > 0) {
    messageLog.addAttachmentAsString("Success - Added/Changed Location(s)", sResult.toString(), messageLogFormat)
}
    return message
}


def formatIDs(input, sPrefix, sMDTName, sSeparator) {
    
    def withoutPrefix = ""
    def withoutMDTName = ""
    def defaultSeparator = "-"
    
    if(!(sPrefix.isEmpty() || sSeparator.isEmpty())) {

     withoutPrefix = input.replaceAll(sPrefix + sSeparator, "")
     withoutMDTName = withoutPrefix.replaceAll(sMDTName + sSeparator, "")
    
    } else if (sPrefix.isEmpty() && !sSeparator.isEmpty()) {

        withoutMDTName = input.replaceAll(sMDTName + sSeparator, "")
        
    } else if (!sPrefix.isEmpty() && sSeparator.isEmpty()) {

        withoutPrefix = input.replaceAll(sPrefix + defaultSeparator, "")
        withoutMDTName = withoutPrefix.replaceAll(sMDTName + defaultSeparator, "")
        
    } else {

        withoutMDTName = input.replaceAll(sMDTName + defaultSeparator, "")

    }
    return withoutMDTName
    
}