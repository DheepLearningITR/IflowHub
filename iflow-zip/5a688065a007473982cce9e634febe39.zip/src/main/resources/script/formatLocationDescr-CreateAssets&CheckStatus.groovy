import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def properties = message.getProperties()
    def assetID = properties.get("ASSET_ID").toString()
    def locID = properties.get("LOC_ID").toString()
    def locDescr = properties.get("LOC_DESCR").toString()
    def result = ""
    def leftParanthesisWithSpace = " ("
    def rightParanthesis = ")"

    if (!locDescr.isEmpty()) {
        result = locDescr + leftParanthesisWithSpace + assetID + rightParanthesis 
    } 

    if(locDescr.isEmpty()) {
        result = locID + leftParanthesisWithSpace + assetID + rightParanthesis
    } 
    
    message.setProperty("ASSET_NAME", result.toString())
    return message
}