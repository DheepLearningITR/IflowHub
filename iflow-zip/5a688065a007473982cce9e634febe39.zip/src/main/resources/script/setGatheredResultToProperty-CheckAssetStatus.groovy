import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String
	message.setProperty('GATHER_RESULT', body)
	binding.variables.clear() //Purging all variables used in the script
    return message
}
