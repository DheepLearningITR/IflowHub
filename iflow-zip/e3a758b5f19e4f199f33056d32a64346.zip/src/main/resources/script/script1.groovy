import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;


def Message processData(Message msg) {
    def helperValMap = ITApiFactory.getApi(ValueMappingApi.class, null)
    def headers = msg.getHeaders();
    def properties = msg.getProperties();

    def input = headers.get('CamelHttpPath');
    def splitted_str = input.split('/');
    def logsys = splitted_str[0];
    def interfacename = splitted_str[1];
    
    def url = helperValMap.getMappedValue('GK', 'logsys', logsys , 'SAP', 'sap_binding_url_ws_xi');
    def credentials = helperValMap.getMappedValue('GK', 'logsys', logsys , 'SAP', 'sap_credentials_id_ws_xi');
    def carcloudconnectionid = helperValMap.getMappedValue('GK', 'logsys', logsys , 'SAP' , 'sap_cloud_connector_id_xi');
   
   def namespace = helperValMap.getMappedValue('SAP', 'ServiceName', interfacename , 'SAP' , 'ServiceNamespace');
   
    msg.setProperty( 'logsys', logsys );
    msg.setProperty( 'binding_url', url );
    msg.setProperty( 'credentials_id', credentials);
    msg.setProperty( 'cloud_connector_id', carcloudconnectionid);
    msg.setProperty( 'SERVICE_INTERFACE', interfacename); 
    msg.setProperty( 'SERVICE_NAMESPACE', namespace);
    
	return msg;
	
}