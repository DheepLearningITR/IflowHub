import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def payload = new JsonSlurper().parse(message.getBody(java.io.Reader))

    message.setBody(payload.body)
    message.setProperty("topic", payload.topic)

    return message
}
