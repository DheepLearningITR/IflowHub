/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String);
    
    def root = new JsonSlurper().parseText(body);

    if(root.totais) {
        
        if(root.totais.erros) {
            def errors_size = root.totais.erros.size();
            
            if(errors_size) {
                def new_payload_log = message.getProperties().get("p_ec_payload_log") as String;
                
                if(!new_payload_log.isEmpty())
                    new_payload_log += "\n--------------\n\n";
                
                for(int i = 0; i < errors_size; ++i)
                    new_payload_log += root.totais.erros[i] + '\n';
                
                message.setProperty("p_ec_payload_log", new_payload_log.bytes.encodeBase64().toString());
            }
        }
        
    }
    
    return message;
}