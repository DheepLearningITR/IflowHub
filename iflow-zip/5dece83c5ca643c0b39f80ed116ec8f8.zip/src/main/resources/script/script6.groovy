/*
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    
    sleep(60000)
    
    final result_txt = '<?xml version="1.0" encoding="UTF-8"?><root></root>';
    
    def result_xml   = new XmlSlurper().parseText(result_txt);
    
    def body_xml     = new XmlSlurper().parseText(message.getBody(java.lang.String));
    
    def body_rows    = [];
    
    for(int i = 0; i < body_xml.getProperty("employees").size(); ++i)
        body_rows.push(body_xml.getProperty("employees")[i]);
    
    if(body_rows.size()) {
        
        body_rows.each {
            
            node ->
                if(!node.dataAdmissao.text().isEmpty())
                    node.appendNode{ sort_only_date(node.dataAdmissao.text()) };
                else if(!node.dataDemissao.text().isEmpty())
                    node.appendNode{ sort_only_date(node.dataDemissao.text()) };
                
                result_xml.appendNode(node);
            
        };
        
    }
    
    result_xml = new XmlParser().parseText( (String)XmlUtil.serialize(result_xml) );

    result_xml.children().sort(true) {
        
        row ->
            new Date().parse("ddMMyyyy", row.sort_only_date.text());
        
    };
    
    // result_xml.children().reverse(true);
    
    result_xml.children().each {
        
        row ->
            row.remove(row.sort_only_date);
            
    };
    
    message.setBody( (String)XmlUtil.serialize(result_xml) );
    
    return message;
    
}