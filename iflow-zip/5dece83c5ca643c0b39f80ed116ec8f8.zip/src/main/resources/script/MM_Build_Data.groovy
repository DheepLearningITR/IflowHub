import groovy.xml.XmlUtil;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

//Body
def body_xml = message.getBody();
 
def xml_old = new XmlSlurper().parseText(body_xml)
def new_xml = new Node(null, 'Record')


// parce do XML

xml_old.cust_FeriasProgramacao.each {
  p ->  
  def control = '1';
  def new_node = new Node(new_xml, 'row')
  def cnpj = p.EmpJob.locationNav.FOLocation.customString1.text();
  def userId = p.EmpJob.userId.text();
  def cust_type = p.cust_transaction.text();

  new Node(new_node, 'cont', control)
  new Node(new_node, 'cnpj', cnpj)
  new Node(new_node, 'userId', userId)
  new Node(new_node, 'cust_type', cust_type)

  if (p.cust_prog_dt_saida1.text() != '') {

    def date_saida1 = p.cust_prog_dt_saida1.text()
    def date_retorno1 = p.cust_data_retorno1.text()

    new Node(new_node, 'date_start', date_saida1)
    new Node(new_node, 'date_end', date_retorno1)

    control = '2'

  }


  if (p.cust_prog_dt_saida2.text() != '') {

    def date_saida2 = p.cust_prog_dt_saida2.text()
    def date_retorno2 = p.cust_data_retorno2.text()
    

    if (control == '2')

    {
      new_node = new Node(new_xml, 'row')
      new Node(new_node, 'cnpj', cnpj)
      new Node(new_node, 'userId', userId)
      new Node(new_node, 'cust_type', cust_type)
    }

    new Node(new_node, 'cont', control)
    new Node(new_node, 'date_start', date_saida2)
    new Node(new_node, 'date_end', date_retorno2)



    control = '3'

  }

  if (p.cust_prog_dt_saida3.text() != '') {
    def date_saida3 = p.cust_prog_dt_saida3.text()
    def date_retorno3 = p.cust_data_retorno3.text()


    if (control == '2' || control == '3')

    {
      new_node = new Node(new_xml, 'row')
      new Node(new_node, 'cnpj', cnpj)
      new Node(new_node, 'userId', userId)
      new Node(new_node, 'cust_type', cust_type)
    }

    new Node(new_node, 'cont', control)
    new Node(new_node, 'date_start', date_saida3)
    new Node(new_node, 'date_end', date_retorno3)


  }

}

 message.setBody(new_xml);
  
return message;
}

