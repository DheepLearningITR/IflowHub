import com.sap.it.api.mapping.*;
import groovy.util.Node;
import groovy.util.XmlParser;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String get_picklist_label(String custom_string_name, String custom_string, MappingContext context) {
    
    String result = "";
    
    HashMap p_custom_strings = (HashMap)(context.getProperty("p_custom_strings"));
    
    List custom_string_list = p_custom_strings[custom_string_name];
    
    for(pair in custom_string_list) {
        
        if((boolean)(pair[custom_string])) {
            
            result = pair[custom_string];
            break;
            
        }
        
    }
    
    return result;
    
}