/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    def xml           = new XmlParser().parseText(message.getBody(java.lang.String));
    
    def docs_property = [:];//message.getProperties().get("p_docs");
    
    xml.
        EmpJob.each {
            emp_job ->
            
                docs_property[emp_job.userId.text()] = [:];
            
                emp_job.employmentNav.
                    EmpEmployment.
                        empWorkPermitNav.
                            EmpWorkPermit.each {
                                
                                emp_work_permit ->
                                    
                                    def externalCode = emp_work_permit.documentTypeNav.
                                            PicklistOption[0].
                                                externalCode.text();
                                
                                    def doc_number   = emp_work_permit.documentNumber.text();
                                
                                    docs_property[emp_job.userId.text()][externalCode] = doc_number;
                            }
        }
    
    message.setProperty("p_docs", docs_property);
    
    return message;
    
}