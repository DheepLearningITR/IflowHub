import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
       
       //Properties
    v_today             = new Date()
    v_newDate           = v_today.format("dd/MM/yyyy")
    map                 = message.getProperties();
    p_process_type      = map.get("p_process_type");
    p_Error_Message     = map.get("p_Error_Message");
    p_Error_Stacktrace  = map.get("p_Error_Stacktrace");
	p_SAP_MessagePr     = map.get("SAP_MessageProcessingLogID");
	p_eventType  		= map.get("p_eventType");
	p_yesterday 	    = map.get("p_yesterday");
    String value;
    String value3;
    String v_data = v_newDate.toString()

    value3 = p_SAP_MessagePr; 
    
         if (p_process_type == 'START')
    {
		  value = 'Processo iniciado - interface dados de funcionário'.concat(' - Data: ').concat(v_data);
		  p_eventType = 'START'; 
    } 
    
    if (p_process_type == 'ERROR')
    
    {
             value = 'Erro na interface de dados do funcionário'.concat(' - Data: ').concat(v_data).concat(' - detalhe do erro: ').concat(p_Error_Message);
			p_eventType = 'FAILED';
    }
     if (p_process_type == 'END')
    {
		  value = 'Interface de dados de funcionário executada com sucesso!';
		  p_eventType = 'END'; 
    }  

		message.setProperty("p_eventType", p_eventType );
		message.setProperty("p_process_descr", value );
		message.setProperty("p_id_msg", value3 );
  
       return message;
}