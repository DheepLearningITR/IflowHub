import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.mapping.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.lang.String;

def Message processData(Message message) {

        def map                 = message.getProperties()
        String p_SAP_MessagePr  = map.get("SAP_MessageProcessingLogID")

       message.setProperty("p_id_msg", p_SAP_MessagePr )
        return message

}