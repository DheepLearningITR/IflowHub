
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	

 def body = message.getBody();
 def TargetData = "<Output>"+body+"<\\Output>"
 



	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
		messageLog.addAttachmentAsString("New Body", TargetData, "text/xml");
	}


	if(TargetData != null){
		message.setProperty("p_Body_new", TargetData);
		message.setBody(TargetData);
	}   
	 
	return message;
}
