import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
           
       //Properties 
    map                 = message.getProperties();
    p_process_type      = 'ERROR';

  message.setProperty("p_process_type", p_process_type );
  
return message;
}