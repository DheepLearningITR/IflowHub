/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    def new_date = new Date().minus(1).format("yyyy-MM-dd'T'HH:mm:ssZ");
    
    def yesterday_a;
    def yesterday_b;
    
    new_date = new_date.substring(0, new_date.size() - 14);//5); // pra tirar aquele "+0000"
    
    yesterday_a = new_date + "T00:00:00";//.000";
    yesterday_b = new_date + "T23:59:59";//.000";
    
    message.setProperty("p_yesterday_a", yesterday_a);
    message.setProperty("p_yesterday_b", yesterday_b);
       
    return message;
    
}