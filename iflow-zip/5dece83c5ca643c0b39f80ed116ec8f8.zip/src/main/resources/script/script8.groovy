/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    Node root                  = new XmlParser().parseText(message.getBody(java.lang.String));
    
    HashMap new_custom_strings = [
    
        customString6  : [],
        customString10 : [],
        customString13 : []
        
    ];
    
    root.EmpJob.each {
        
        emp_job->
        
            emp_job.PickListValueV2.each {
                
                pick_list ->
                    
                    push_pick_list(emp_job.customString6,  pick_list, new_custom_strings.customString6);
                    push_pick_list(emp_job.customString10, pick_list, new_custom_strings.customString10);
                    push_pick_list(emp_job.customString13, pick_list, new_custom_strings.customString13);
                    
                    
            }
        
    }
    
    for(key in new_custom_strings) {
        
        List custom_list = key.getValue();
        
        custom_list.unique {
            
            pair_a, pair_b ->
            
                pair_a.keySet()[0] <=> pair_b.keySet()[0];
            
        };
        
    }
    
    message.setProperty("p_custom_strings", new_custom_strings);
    
    return message;
    
}

def void push_pick_list(NodeList custom_string, Node pick_list, List custom_string_list) {
    
    if(custom_string.size()) {
        
        if(pick_list.optionId.text() == custom_string.text()) {
            
            String option_id   = pick_list.optionId.text();
            String label_pt_br = pick_list.label_pt_BR.text();
            HashMap pair       = [:];
            
            pair[option_id]    = label_pt_br;
            
            custom_string_list.push(pair);
            
        }
        
    }
    
}
