/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    String body = message.getBody(java.lang.String);
    
    final String dismissal_node = '"dataDemissao":"",';
    
    int from_index = 0;
    
    for(int i = 0; i < body.length(); ++i) {
        
        int new_index = body.indexOf("{", from_index);
        
        if(new_index == -1)
            break;
        
        ++new_index;
        
        String body_part_a = body.substring(0, new_index);
        
        String body_part_b = body.substring(new_index);
        
        body = body_part_a + dismissal_node + body_part_b;
        
        from_index = new_index;
        
    }
    
    message.setBody(body);
    
    return message;
    
}