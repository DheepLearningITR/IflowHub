import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String get_employment_type_description(String employment_type) {
    
    switch(employment_type) {
        
        case "27556": return "CLT";
        case "27558": return "MENOR APRENDIZ";
        case "27560": return "PENSAO VITALICIA";
        case "27562": return "INTERMITENTE";
        case "27568": return "CLT";
        case "27557": return "CLT";
        case "27559": return "CONSELHEIRO";
        case "27561": return "ESTAGIARIO";
        case "27567": return "AUTONOMO";
        case "36272": return "COMISSIONADO";
        case "36273": return "FOLHA CONFIDENCIAL";
        case "36012": return "ESTATUTARIO";

        default: return "";
        
    }
    
}