import com.sap.it.api.mapping.*;
import groovy.util.XmlSlurper;

def String get_first_n_last_name(String arg) {
    
    def xml    = new XmlSlurper().parseText(arg);

    def result = xml.User.firstName.text() + " " + xml.User.lastName.text();
    
	return result;
	
}