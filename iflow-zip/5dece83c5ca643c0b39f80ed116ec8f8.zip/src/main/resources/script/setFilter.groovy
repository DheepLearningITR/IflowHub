import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.*;

def Message processData(Message message) {

  String p_userId;
  String p_filter;

    p_userId = message.getProperty("p_userId");
    p_filter = '&$filter=userId eq ' + p_userId;
     message.setProperty("p_userId", p_filter);

 return message;

}