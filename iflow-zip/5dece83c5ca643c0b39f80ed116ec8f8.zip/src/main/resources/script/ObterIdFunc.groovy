import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.*;

def Message processData(Message message) {


    def XML = new XmlSlurper().parseText(message.getBody(java.lang.String))

    // obter propriedades (id do funcionário ... id do empregado... id)
    String query_userId;
    query_userId = message.getProperty("p_userId");

    // verificar se já existe valor
    if (query_userId == null || query_userId == '') {
        query_userId = 'initial';
    }


    // parce do XML - EmpJob
    XML.EmpJob.each {
        EmpJob ->

            if (query_userId == 'initial') {
                if (EmpJob.userId.text() != '') {
                     query_userId = 'userId eq ' + "'" + EmpJob.userId.text() + "'" 
                }
            }
        else {
                if (EmpJob.userId.text() != '') {
                    query_userId = query_userId + ' or userId eq ' + "'" + EmpJob.userId.text() + "'"
            }
        }

    }

        // parce do XML - PerPerson
    XML.PerPerson.each {
        PerPerson ->

            if (query_userId == 'initial') {
                if (PerPerson.personIdExternal.text() != '') {

                     query_userId = 'userId eq ' + "'" + PerPerson.personIdExternal.text() + "'"                    
                }
            }
        else {
            if (PerPerson.personIdExternal.text() != '') {
                query_userId = query_userId + ' or userId eq ' + "'" + PerPerson.personIdExternal.text() + "'" 
            }
        }
    }

        // parce do XML - EmpWorkPermit
    XML.EmpWorkPermit.each {
        EmpWorkPermit ->

            if (query_userId == 'initial') {
                if (EmpWorkPermit.userId.text() != '') {
                    query_userId = 'userId eq ' + "'" + EmpWorkPermit.personIdExternal.text() + "'" 
                }
            }
        else {
            if (EmpWorkPermit.userId.text() != '') {
                query_userId = query_userId + ' or userId eq ' + "'" + EmpWorkPermit.userId.text()  + "'" 
           
            }
        }

    }

 
    if (query_userId != 'initial')
    {
        message.setProperty("p_userId", query_userId);    }

    return message;
}