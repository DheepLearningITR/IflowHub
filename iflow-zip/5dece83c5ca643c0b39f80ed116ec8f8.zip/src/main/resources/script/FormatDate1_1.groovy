/*
    Script para conversão de datas
	
	Versão: 1.1
	
	By: Müller
*/

import com.sap.it.api.mapping.*;

def String format_date(final String date, final MappingContext mc) {
    
    if(date.length() == 0)
        return ""
    
    final format_from = mc.getProperty("p_format_date_from")
    final format_to   = mc.getProperty("p_format_date_to")
    
    if(!format_from || !format_to)
        return ""

    return Date.parse(parse_pattern(format_from), date).format(parse_pattern(format_to))
    
}

def String parse_pattern(final int pattern) {

    switch(pattern) {

		case 1:  return "ddMMyyyy"
        case 2:  return "dd.MM.yyyy"
        case 3:  return "yyyy.MM.dd"
        case 4:  return "dd-MM-yyyy"
        case 5:  return "yyyy-MM-dd"
        case 6:  return "dd_MM_yyyy"
        case 7:  return "yyyy_MM_dd"
        case 8:  return "yyyy.MM.dd G 'at' HH:mm:ss z"
        case 9:  return "EEE, MMM d, ''yy"
        case 10:  return "h:mm a"
        case 11: return "hh 'o''clock' a, zzzz"
        case 12: return "K:mm a, z"
        case 13: return "yyyyy.MMMMM.dd GGG hh:mm aaa"
        case 14: return "EEE, d MMM yyyy HH:mm:ss Z"
        case 15: return "yyMMddHHmmssZ"
        case 16: return "yyyy-MM-dd'T'HH:mm:ss.SSS"
        case 17: return "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        case 18: return "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
        case 19: return "YYYY-'W'ww-u"

        default: return ""

    }
	
}