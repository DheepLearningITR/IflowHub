import com.sap.gateway.ip.core.customdev.util.Message

Message countReturned(Message message){
    def body = message.getProperty("jsonArraySize") as String
    
    if (body?.isNumber()){
        message.setProperty("totalReturned",""+(Integer.parseInt(message.getProperty("totalReturned"))+ Integer.parseInt(body)))
        
    }
    
    return message
}



Message countAccruals(Message message) {
    def body = message.getBody(String.class)
    
    def xml = new XmlSlurper().parseText(body)
    def currentCount = xml.'*'.size()
    

    message.setProperty("accruals", currentCount)
   
    
    return message
}