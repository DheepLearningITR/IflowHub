// =============================================================================================
// This flow step is responsible for subsituting some of the content in UN/EDIFACT
// or ASC X12 interchange payloads so that this conctent will be sufficiently processed by
// the subsequent flow steps.
//
// History:
// 2024-02-19 SAP [MÖ] - Update to reg expression for extracting currency from UN/EDIFACT CUX segment.
// 2024-01-17 SAP [GS] - Regular expression for extracting country code from UN/EDIFACT RFF+ZZZ segment.
// 2023-12-14 SAP [MÖ] - Split script and manipulate interchange payload in step2 Flow
// 2023-12-14 SAP [PS] - 1. Substitute comma with dot: , -> . 2. Add release character for dot: . -> ?. 3. remove release character for comma: ?, -> ,
// 2023-11-20 SAP [AG] - EDIFACT message with IMD Segment has item description in payload more than field length of 35 chars. Additional data truncated
// 2023-08-24 SAP [GS] - Subsitute codepage UNOY to UNOC
// 2023-06-01 SAP [GS] - Set sender/receiver id qualifiers ZZ to ZZZ
// 2023-01-01 SAP [GS] - Initially created
// 2023-11-02 SAP [AH] - UNB:1 segment changed to UNOC:3
// =============================================================================================

import com.sap.gateway.ip.core.customdev.util.Message;
import org.apache.commons.lang.StringEscapeUtils;
import java.util.HashMap;
import java.util.regex.Pattern;
def Message processData(Message message) {

    //Headers
    def headers     = message.getHeaders();
    def contentType = headers.get("SAP_EDI_Document_Standard")as String;
    def version     = headers.get("SAP_EDI_Message_Version")as String;
    def syntax      = headers.get("SAP_EDI_Syntax_Version_Number")as String;
    def release     = headers.get("SAP_EDI_Message_Release")as String;
    def body        = message.getBody(java.lang.String) as String;

    if (contentType == "ASC-X12") {
        version = version.replaceFirst("VICS", "");
        message.setHeader("SAP_EDI_Message_Version", version);
        body = body.replaceFirst("VICS", "");
    } else if (contentType == "UN-EDIFACT") {
        def sndSenderIdQualifier = headers.get("SAP_EDI_Sender_ID_Qualifier")as String;
        def sndReceiverIdQualifier = headers.get("SAP_EDI_Receiver_ID_Qualifier")as String;

        if (sndSenderIdQualifier == "ZZ") {
            sndSenderIdQualifier = "ZZZ";
            message.setHeader("SAP_EDI_Sender_ID_Qualifier", sndSenderIdQualifier);
        }
        if (sndReceiverIdQualifier == "ZZ") {
            sndReceiverIdQualifier = "ZZZ";
            message.setHeader("SAP_EDI_Receiver_ID_Qualifier", sndReceiverIdQualifier);
            message.setHeader("EDI_Receiver_ID_Qualifier", sndReceiverIdQualifier);
        }

        version = version + "." + release + " S" + "3";
        message.setHeader("SAP_EDI_Message_Version", version);

        // /Remove unwanted new lines
        def body_temp = body.replace("\n", "");
        def compsiteSeparator, dataElementSeparator, decimalSeparator, releaseCharacter, repet, segmentSeparator;
        
        try {
        // Obtain syntax delimiters from interchange which should work if UNA segment present
            (_, compsiteSeparator, dataElementSeparator, decimalSeparator, releaseCharacter, repet, segmentSeparator) = (body_temp =~ (/UNA([^A-Z])([^A-Z])([^A-Z])([^A-Z])([^A-Z])?([^A-Z])/))[0]
        } catch (Exception e) {
        // When reading from UNA fails, assume default meta
            (_, compsiteSeparator, dataElementSeparator, decimalSeparator, releaseCharacter, repet, segmentSeparator) = ["", ":", "+", ".", "?", "", "'"];  
        }

        // Construct regex
        segmentSeparator = "\\" + segmentSeparator;                 // '
        releaseCharacter = "\\" + releaseCharacter;                 // ?
        compsiteSeparator = "\\" + compsiteSeparator;               // :
        dataElementSeparator = "\\" + dataElementSeparator;         // +

        // Regex for extracting value from first RFF+ZZZ segment and write it to the exchange header parameter: TPM_SND_CountryCodeIdentifier. 
        def ref_zzz_value = "";
        try {
            ref_zzz_value = (body_temp =~ /RFF${dataElementSeparator}ZZZ${compsiteSeparator}([A-Z]{2})${segmentSeparator}/)[0][1];
            message.setHeader("TPM_SND_CountryCodeIdentifier", ref_zzz_value);
        } catch (Exception e) {
            message.setHeader("TPM_SND_CountryCodeIdentifier", ref_zzz_value );
        }

        // Regex for extracting value from first CUX+2 segment and write it to the exchange header parameter: TPM_SND_CurrencyCode. 
        def cux_value = "";
        try {
            cux_value = (body_temp =~ /CUX${dataElementSeparator}2${compsiteSeparator}([A-Z]{3})${compsiteSeparator}[0-9]{1,2}${segmentSeparator}/)[0][1];
            message.setHeader("TPM_SND_CurrencyCode", cux_value);
        } catch (Exception e) {
            message.setHeader("TPM_SND_CurrencyCode", cux_value);
        }
    }

    return message;
}