import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message enrichJsonOutput(Message message) {
 

  def body = message.getBody(java.io.Reader);

  JsonSlurper slurper = new JsonSlurper()
  Map parsedJson = slurper.parse(body)
    
  // handle null
  def respbody = JsonOutput.toJson(parsedJson)
  def body2 = respbody.replace('""','null')
  def body3 = body2.replace('{}','null')
  message.setBody(body3)
  
  return message;
}


def Message setCustomMessageHeader(Message message) {
    
  def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
       
		def messageHeaderId = message.getProperties().get("p_msg_header_id")		
		if(messageHeaderId != null){
			messageLog.addCustomHeaderProperty("customerPartNumberS4Replication_msg_id", messageHeaderId)
        }
	}
	return message;
}