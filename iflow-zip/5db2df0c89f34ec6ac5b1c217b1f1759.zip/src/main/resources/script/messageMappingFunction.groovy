import com.sap.it.api.mapping.*;
import org.apache.commons.lang3.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String getDateTime(String arg1, MappingContext context){

	def datetime = context.getProperty("DateTime");
	return datetime;
 
}

def String getSBSystemId( String arg1,MappingContext context){

	def id = context.getProperty("SBSystemId");
	return id;
 
}

def String getS4SystemId(String arg1, MappingContext context){

	def SYSTEMID = context.getProperty("S4SystemId");
	return SYSTEMID;
}

def String getS4ProductType(String arg1, MappingContext context){

	def productType = context.getProperty("S4ProductType");
	return productType;
}

def String formatDescription(String arg1){
    if(StringUtils.trim(arg1).length() > 40) {
        return StringUtils.trim(arg1).substring(0, 40)
    } else {
        return StringUtils.trim(arg1)
    }
}