import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;
import groovy.util.XmlParser;
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.ITApiFactory

def Message processData(Message message) {
def body = message.getBody(java.lang.String) as String;

def parsedObj = new XmlParser().parseText(body);
def mid_json  = ""
def root = "";
def root2 = "";
def lang_code = "";
def desc = "";
def append = ""
def append2 = ""
def tot_json = ""
def final_json = ""
def final_json_obj = ""
valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)

parsedObj.MaterialReplicationRequest.each{
    response = it.MaterialRequest.'**'.findAll { it.name() == 'Description' && it.parent().name() == 'Description' }
    product_Id = it.MaterialRequest.ID.text()
    mid_json = "";
    append = ""
    tot_json = ""

    response.each{
            lang_code = valueMapApi.getMappedValue('C4C', 'LANG_CODE', it.@languageCode.trim(), 'FSM', 'LANG_CODE')
            if(lang_code.equals(null)){
        	   lang_code = it.@languageCode.trim()
            }
            lang_code = lang_code.toLowerCase();
            desc = it.value()[0].toString();
            if(mid_json == ""){
            mid_json = new JsonBuilder();
            
            root = mid_json "$lang_code":desc
            
            }else{
               def appendBuilder = new JsonBuilder();
               append = appendBuilder{
                   "$lang_code" desc
               }
            }
            
            if(tot_json == ""){
                tot_json = new JsonSlurper().parseText(mid_json.toString());
            }
             if(append != ""){
               tot_json."$lang_code" = append."$lang_code";
             }
        }
        
        if(final_json == ""){
           final_json = new JsonBuilder();
           root2 = final_json "$product_Id":tot_json
        }else{
          app_builder = new JsonBuilder();
           append2 = app_builder{
               "$product_Id" tot_json
           }
        }
        if(final_json_obj == ""){
        final_json_obj = new JsonSlurper().parseText(final_json.toString());
        }
        if(append2 != ""){
            print("append")
        final_json_obj."$product_Id" = append2."$product_Id";
        } 
    }
    JsonBuilder builder = new JsonBuilder(final_json_obj);
       String jsonBody = JsonOutput.prettyPrint(builder.toString());
       message.getProperties().put("translations",jsonBody);
    return message;
}
