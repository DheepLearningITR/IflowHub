import com.sap.it.api.mapping.*;

def String getPropertyValue(String propertyValue, MappingContext context) {

         return context.getProperty(propertyValue).toString().toUpperCase();
}