import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;



def Message processData(Message message) {
 def body = message.getBody(java.lang.String) as String;

 def map = message.getProperties();
 def translations = map.get("translations");


 def parsedObj = new JsonSlurper().parseText(translations);
 def parsedObj2 = new JsonSlurper().parseText(body);
 


 parsedObj2.each {
  it.nameTranslations = parsedObj[it.externalId.toString()];
 }

 JsonBuilder builder = new JsonBuilder(parsedObj2);
 String jsonBody = JsonOutput.prettyPrint(builder.toString());

 message.setBody(jsonBody);
 return message;
}