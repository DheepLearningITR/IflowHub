/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    //Get Body and parse it.
       def body = message.getBody(String.class);
       def parsedObj = new XmlSlurper().parseText(body);
       String query = "{\"query\": \"SELECT req.externalId FROM Requirement req JOIN Item ite ON req.object.objectId = ite.id WHERE req.object.objectType = 'ITEM' AND req.externalId IS NOT NULL AND ite.externalId IN (";
       String s = '\'';
       String e = '\',';
       String eend = '\')\"}';
       String whereIn;
        ArrayList c4c_skill_ids = []
    // Form the where clause of Item IDs for which Requirement IDs needs to be fetched from FSM
      parsedObj.MaterialReplicationRequest.each{
          it.MaterialRequest.MaterialSkills.MaterialReplicationSkill.each{
          	    c4c_skill_ids.add(it.MaterialSkillUUID.text().trim())
          }
          if (whereIn == null)
          {
              whereIn = s + it.MaterialRequest.ID + eend;
          }
          else
          {
              whereIn = s + it.MaterialRequest.ID + e + whereIn;
          }
          };
    //Set final query statement which has to be send as payload of the query API request     
       query = query + whereIn;
    // Temporarily store inbound payload as property   
       message.setProperty("InPayload",body);
       message.setProperty("c4c_skill_ids",c4c_skill_ids);
    // Set the query in the message body   
       message.setBody(query);
       return message;
}
