/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

//def body = '{"data":[{"externalId":"3997642","types":["ERPUSER",{"EMPLOYEE":"Aditya"},"CLOUDUSER",{"EMPLOYEE":"Akshay"}],"subject":"BTD Test3","origin":"-3","status":"-5","priority":"HIGH","problemType":"","earliestStartDateTime":"2019-06-10T00:00:00Z","dueDateTime":"2019-06-13T07:41:22Z","resolution":"","remarks":"BTD Test3\n\n","activities":[{"externalId":"00163e8e-1597-1ed9-a29e-f49f63b897ef","subject":"FSM Material","dueDateTime":"2019-06-11T00:00:00Z","earliestStartDateTime":"2019-06-10T00:00:00Z","equipment":{"externalId":"3294"}},{"externalId":"00163e8e-1597-1ed9-a29e-f49f63b8b7ef","subject":"Washing Machine","dueDateTime":"2019-06-11T00:00:00Z","earliestStartDateTime":"2019-06-10T00:00:00Z","equipment":{"externalId":"3294"}}],"address":{"city":"","country":" ","street":" ","zipCode":" "},"businessPartner":{"externalId":"1073461"},"contact":{"externalId":"1073462~ID-JOIN~1073461"},"equipments":[{"externalId":"3294"}],"reservedMaterials":[{"externalId":"00163e8e-1597-1ed9-a29e-f49f63b8d7ef","item":{"externalId":"MAT_FSM_013"},"warehouse":{"externalId":"DefaultWarehouse"},"quantity":"1.0"}],"responsibles":[""]}]}';

def addnull(java.lang.Object parsedObj){
    
       def map = parsedObj.keySet();
       def nString;
       for (int i=0; i<map.size();i++)
       {
            def value = parsedObj.get(map[i]);
            if (value == " " || value == "")
            {
                parsedObj.put(map[i],null);
            }
            else if (value.class == null)
            {
             addnull(value);
            }
            else if (value.class.name == 'java.util.ArrayList')
            {
                if( value.toString() == '[]') // empty array
                {
                   parsedObj.put(map[i],null);
                }
                else
                {
                //lOOP over each array element
                    for(n in value)
                    { 
                        nString = n.toString();
                        //to cater follwing kind of data--> ["ERPUSER",{"EMPLOYEE":"Aditya"},"CLOUDUSER",{"EMPLOYEE":"Akshay"}]
                        if(nString[0..0] == "{" || nString[0..0] == "[") 
                        {
                            addnull(n);   
                        }
                   }                    
                }
            }
       }
}

def Message processData(Message message) {
    //Get Body and parse it.
       def body = message.getBody(String.class);
    //Assuming input body is in follwing JSON format: {"data":[ ]} or  {"data":{ }} or {"data": " "}
       def parsedObj = new JsonSlurper().parseText(body);
    //Start recursive method call
    //   addnull(parsedObj);
    // Build JSON data again. Used parsedObj.data to build JSON, to remove data keyword from payload {"data":[ ]} 
       JsonBuilder builder = new JsonBuilder(parsedObj.data);
       String jsonBody = JsonOutput.prettyPrint(builder.toString());
       message.setBody(jsonBody);
       return message;
}