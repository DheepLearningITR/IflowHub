import com.sap.gateway.ip.core.customdev.util.Message


Message updateAccumulated(Message message){
    def jsonArraySize = message.getProperty("jsonArraySize")?:0
    def accumulated = message.getProperty("accumulated")?:'0'
    
    
    message.setProperty("accumulated",""+(Integer.parseInt(accumulated) + jsonArraySize))
        
    return message
}

Message setEndLoopFlag(Message message){
    def jsonArraySize = message.getProperty("jsonArraySize")?:0
    def accumulated = message.getProperty("accumulated")?:'0'
    def totalRecords = message.getProperty("totalRecords")?:'0'
    def currentLoop = message.getProperty("currentLoop")?:'0'
    def pageSize = message.getProperty("pageSize")?:'0'
    
    def loopedRecords = (Integer.parseInt(currentLoop)-1)*Integer.parseInt(pageSize)
    
    def endLoop = 'true'
    
    if (jsonArraySize > 0 && Integer.parseInt(totalRecords) >= Integer.parseInt(accumulated) && Integer.parseInt(totalRecords) > 0 && loopedRecords < totalRecords){
        endLoop = 'false'
    }
    message.setProperty("endLoop", endLoop)
    
    return message
}

