import com.sap.gateway.ip.core.customdev.util.Message;
import java.nio.charset.StandardCharsets;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;
import groovy.json.JsonSlurper;

def Message trimEncodedExtension(Message message) {
    def body = message.getBody(String.class);
    message.setBody(body.replaceAll("\\s",""));
    message.setProperty("extensionEncodedValue", body.replaceAll("\\s",""));
    return message;
}

def Message trimEncodedCSR(Message message) {
    def body = message.getBody(String.class);
    message.setBody(body.replaceAll("\\s",""));
    message.setProperty("encodedCSR", body.replaceAll("\\s",""));
    return message;
}

def Message prepareURLforCCSID(Message message) {
    def properties = message.getProperties();
    def op_mode = properties.get("Mode");
    def testURL = properties.get("Test_URL");
    def prodURL = properties.get("Prod_URL");
    if(op_mode == "TEST") {
        receiver_endpoint = testURL;
    }
    else if(op_mode == "PROD") {
        receiver_endpoint = prodURL;
    }
    else {
       def errorMsg = "Communication Mode: " + op_mode + " is incorrect; Only 'TEST' or 'PROD' are allowed";
       message.setHeader("ErrorCode", "SCI Error");
       message.setHeader("ErrorText", errorMsg);
       throw new Exception(errorMsg);
    }
    
    def path = "/compliance";
    message.setHeader("urlCCSID", receiver_endpoint + path);
    return message;
}

def Message prepareURLforCSID(Message message) {
    def properties = message.getProperties();
    def headers = message.getHeaders();
    
    def op_mode = properties.get("Mode");
    def testURL = properties.get("Test_URL");
    def prodURL = properties.get("Prod_URL");
    def isRenew = properties.get("isRenew");
    def solutionUnitId = headers.get("SolutionUnitId");
    def csidSeqNo = headers.get("CSIDSequenceNo");
    def alias;
    
    if(op_mode == "TEST") {
       receiver_endpoint = testURL;
    }
    else if(op_mode == "PROD") {
        receiver_endpoint = prodURL;
    }
    else {
       def errorMsg = "Communication Mode: " + op_mode + " is incorrect; Only 'TEST' or 'PROD' are allowed";
       message.setHeader("ErrorCode", "SCI Error");
       message.setHeader("ErrorText", errorMsg);
       throw new Exception(errorMsg);
    }
    
    def path = "/production/csids";
    message.setHeader("urlCSID", receiver_endpoint + path);
    
    if(isRenew == "1") {
        if(csidSeqNo.isInteger()) {
            def csidSeqNo_int = csidSeqNo as Integer;
            def csid = properties.get("CurrentCSID");
            csid = csid.replaceAll("\\s","");
            csidSeqNo_int --;
            alias = solutionUnitId + "_" + csidSeqNo_int.toString() + "_p";
            message = addAuthHeader(message, alias, csid);
            message.setHeader("CSIDSequenceNoMinusOne", csidSeqNo_int.toString());
        }
        else {
            def errorMsg = "CSID Sequence Number: " + csidSeqNo + " is incorrect; Only Integers are allowed";
            message.setHeader("ErrorCode", "SCI Error");
            message.setHeader("ErrorText", errorMsg);
            throw new Exception(errorMsg);
        }
    }
    else {
        def ccsid = properties.get("CurrentCCSID");
        ccsid = ccsid.replaceAll("\\s","");
        alias = solutionUnitId + "_" + csidSeqNo + "_c";
        message = addAuthHeader(message, alias, ccsid);
    }
    
    return message;
}

def Message generateKeypairAttributes(Message message) {
    def properties = message.getProperties();
    String invoiceTypeForCSR, codeSigning;
    
    def invoiceType = properties.get("invoiceType");
    def op_mode = properties.get("Mode");
    
    if (invoiceType == "TAX") {
        invoiceTypeForCSR = "1000";
    }
    else if(invoiceType == "SIMP") {
        invoiceTypeForCSR = "0100";
    }
    else {
        def errorMsg = "Invoice Type: " + invoiceType + " is incorrect; Only 'TAX' or 'SIMP' are allowed";
        message.setHeader("ErrorCode", "SCI Error");
        message.setHeader("ErrorText", errorMsg);
        throw new Exception(errorMsg);
    }
    
    if(op_mode == "TEST") {
        codeSigning = "PREZATCA-Code-Signing";
    }
    else if(op_mode == "PROD") {
        codeSigning = "ZATCA-Code-Signing";
    }
    else {
        def errorMsg = "Communication Mode: " + op_mode + " is incorrect; Only 'TEST' or 'PROD' are allowed";
        message.setHeader("ErrorCode", "SCI Error");
        message.setHeader("ErrorText", errorMsg);
        throw new Exception(errorMsg);
    }
    
    message.setProperty("invoiceTypeForCSR", invoiceTypeForCSR);
    message.setProperty("codeSigning", codeSigning);
    
    def currentDate = new Date().format("yyyy/MM/dd");
    def currentTime = new Date(currentDate);
    message.setProperty("validNotBefore", currentTime.getTime());
    message.setProperty("validNotAfter", currentTime.plus((5*365) + 1).getTime())
    
    return message;
}

def Message prepareBodyForKeypairUpdation(Message message) {
    def properties = message.getProperties();
    def csid = properties.get("binarySecurityToken");
    message.setBody(new String(csid.decodeBase64()));
    return message;
}

def Message addAuthHeader(Message message, String alias, String userId) {
    SecureStoreService sss = ITApiFactory.getService(SecureStoreService.class, null);
    if (sss != null)
    {   
        //Getting User Credentials from Secure Store Service
        def userCred = sss.getUserCredential(alias);
        if (userCred != null)
        {
            //Setting Basic Authorization Header
            message.setHeader("Authorization", "Basic " + (userId + ":" + userCred.getPassword()).getBytes(StandardCharsets.UTF_8).encodeBase64().toString());
        }
        else
        { 
            def errorMsg = "Error while getting User Credentials from Security Material; Check if User Credential '" + alias + "' is present in Security Material";
            message.setHeader("ErrorCode", "SCI Error");
            message.setHeader("ErrorText", errorMsg);
            throw new Exception(errorMsg);
        }
    }
    else{
        def errorMsg = "Error while creating object for Class SecureStoreService";
        message.setHeader("ErrorCode", "SCI Error");
        message.setHeader("ErrorText", errorMsg);
        throw new Exception(errorMsg);
    }
    
    return message;
}

def Message extractErrorMessage(Message message) {
    def properties = message.getProperties();
    def headers = message.getHeaders();
    boolean flag = false;
	
	//Handle HTTP Exceptions
    def ex = properties.get("CamelExceptionCaught");
    if (ex != null) {
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
            if ( headers.get("ErrorCode") == null && headers.get("ErrorText") == null && isValidJson(ex.getResponseBody()) ) {
                message.setBody(ex.getResponseBody());
                message.setProperty("isErrorParsed", "0");
            }
            else {
                message = updateErrorDataIfEmpty(message);
                message.setProperty("isErrorParsed", "1");
            }
            flag = true;
        }
        else if (ex.getClass().getCanonicalName().equals("java.util.concurrent.TimeoutException")) {
            message.setHeader("ErrorCode", "408");
            message.setHeader("ErrorText", "Request Timeout");
            message.setProperty("isErrorParsed", "1");
            flag = true;
        }
    }
    
    //Handle Renew CSID Exceptions
    def isRenew = properties.get("isRenew");
    def renewResponse = properties.get("RenewCSIDResponse");
    if ( isRenew == "1" && headers.get("ErrorCode") == null && headers.get("ErrorText") == null && isValidJson(renewResponse) ) {
        message.setBody(renewResponse);
        message.setProperty("isErrorParsed", "0");
        flag = true;
    }
    
    //Handle Other Exceptions
    if ( !flag ) {
        def errorMsg;
        if(headers.get("CamelHttpResponseCode") == 401 || properties.get("exceptionMessage") == null) {
            errorMsg = "HTTP Status " + headers.get("CamelHttpResponseCode") + " - " + headers.get("CamelHttpResponseText");
        }
        else {
            errorMsg = properties.get("exceptionMessage");   
        }
        
        message.setHeader("ErrorCode", "SCI Error");
        message.setHeader("ErrorText", errorMsg);
        message.setProperty("isErrorParsed", "1");
    }
    
    if(message.getBody(String.class) == '') {
        message = updateErrorDataIfEmpty(message);
        message.setProperty("isErrorParsed", "1");
    }
    
    return message;
}

def Message updateErrorDataIfEmpty(Message message) {
    def headers = message.getHeaders();
    
    if( headers.get("ErrorCode") == null ) {
        message.setHeader("ErrorCode", "SCI Error");
    }
    if( headers.get("ErrorText") == null ) {
        def errorMsg = "HTTP Status " + headers.get("CamelHttpResponseCode") + " - " + headers.get("CamelHttpResponseText");
        message.setHeader("ErrorText", errorMsg);
    }
    
    return message;
}

def boolean isValidJson(String str) {
    try {
        new JsonSlurper().parseText(str);
        return true;
    }
    catch (Exception e) { return false; }
    return false;
}