import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.text.ParseException;
import java.util.Date;

def Message processData(Message message) {
    def properties =  message.getProperties();
    def LAST_RUN_DATE = properties.get("LAST_RUN_DATE");
    def lastRunDateTime = properties.get("LAST_RUN_TIME");
    def bpg1 = properties.get("BusinessPartnerGrouping1");
    def bpg2 = properties.get("BusinessPartnerGrouping2");
    def bpg3 = properties.get("BusinessPartnerGrouping3");
    def bpg4 = properties.get("BusinessPartnerGrouping4");
    def bpg5 = properties.get("BusinessPartnerGrouping5");
        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat("'PT'HH'H'mm'M'ss'S'");
        try {
			date = sdf.parse(lastRunDateTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR,calendar.get(Calendar.HOUR)+8);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("'PT'HH'H'mm'M'ss'S'");
        def finalCST = simpleDateFormat.format(calendar.getTime());
        
        def filterClause = "LastChangeDate ge datetime'" + LAST_RUN_DATE + "' and LastChangeTime ge time'" + finalCST + "' and   (BusinessPartnerGrouping eq '" + bpg1 + "'" + " or BusinessPartnerGrouping eq '" + bpg2 + "'" + " or BusinessPartnerGrouping eq '" + bpg3 +"'" + " or BusinessPartnerGrouping eq '" + bpg4 + "'" + " or BusinessPartnerGrouping eq '" + bpg5 + "')" ;
       // message.setProperty("LAST_QUERY_TIME", finalCST);
        message.setProperty("filterClause", filterClause);
     return message;
}