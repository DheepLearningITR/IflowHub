/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;

class Attachment{
    String docType;
    String docNumber;
    String logicalDocument;
    String docID;
    String vendorNumber;
    String objectType;
    String contentType;
    String fileName;
    
    public Attachment(docType,docNumber,logicalDocument,docID,vendorNumber,objectType,contentType,fileName){
        this.docType = docType;
        this.docNumber =docNumber;
        this.logicalDocument = logicalDocument;
        this.docID = docID;
        this.vendorNumber = vendorNumber;
        this.objectType = objectType;
        this.contentType = contentType;
        this.fileName = fileName;
    }
    
}
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def root = new XmlSlurper().parseText(body);
    def attachmentMap = [:];
    def loopIndex = root.entry.size();
    def indexNumber = 1;
    def attachCount;
   
    indexNumber = loopIndex;
    if (loopIndex > 0) {
    root.entry.each{ record ->
    def docType = record.properties.DocumentInfoRecordDocType.text();
    def docNumber = record.properties.DocumentInfoRecordDocNumber.text();
    def logicalDocument = record.properties.LogicalDocument.text();
    def docID = record.properties.ArchiveDocumentID.text();
    def vendorNumber = record.properties.LinkedSAPObjectKey.text();
    def objectType = record.properties.BusinessObjectType.text();
    def contentType = record.properties.MimeType.text();
    def fileName = record.properties.FileName.text();
    /*if (!attachmentMap.isEmpty()){
        Integer count = attachmentMap.size();
        for(int i = 1;i<=count;i++){
        def attachment = attachmentMap.get(i);
        if(!fileName.equals(attachment.fileName)){
        attachmentMap.put(indexNumber,new Attachment(docType,docNumber,logicalDocument,docID,vendorNumber,objectType,contentType,fileName));
            }
        }
    }else{
        attachmentMap.put(indexNumber,new Attachment(docType,docNumber,logicalDocument,docID,vendorNumber,objectType,contentType,fileName));
    }*/
    
    attachmentMap.put(indexNumber,new Attachment(docType,docNumber,logicalDocument,docID,vendorNumber,objectType,contentType,fileName));
    
    indexNumber = indexNumber - 1;
        };
    }
    
    message.setProperty("loopIndex", loopIndex);
    message.setProperty("attachmentMap", attachmentMap);
    return message;
}