/* We are trying to build up a JSON body to send to the Microsoft Graph Email API which is different from the "normal"
   API's typically used, but FMG requires use of Graph as less ongoing maintenance issues. Anyway output should look
   something like the below, see the attachments section has the base64 of the attachment embedded.
   
   Note: This script builds up most of the API message format but omits recipients which is then added later in
   the shared email iFlow so we dont have to duplicate config everywhere

   Spec: https://learn.microsoft.com/en-us/graph/api/user-sendmail?view=graph-rest-1.0&tabs=http

{
  "message": {
    "subject": "testing email api",
    "body": {
      "contentType": "Text",
      "content": "Hello, this is the email content"
    },
    "toRecipients": [
      {
        "emailAddress": {
          "address": "chris.mills@dyflex.com.au"
        }
      }
    ],
    "attachments": [
      {
        "@odata.type": "#microsoft.graph.fileAttachment",
        "name": "attachment.txt",
        "contentType": "text/plain",
        "contentBytes": "SGVsbG8gV29ybGQh" <--- NOTE: This is base64 encoded
      }
    ]
  }
}
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder

class Attachment {
    String name;
    String contentType;
    String base64Content
}

def Message processData(Message message) {
    def headers = message.getHeaders();
    def properties = message.getProperties()

    //for attachments just push them as a local class in to an array which we can then iterate during the builder
    def respBody = message.getHeader("responseBody", java.lang.String)
    def httpRespBody = message.getHeader("httpResponseBody", java.lang.String)
    def errAttach = message.getHeader("emailAttachment", java.lang.String)
    def attachmentsContent = [
            new Attachment(name: "httpResponseBody.txt", contentType: "text/plain", base64Content: getBase64(httpRespBody)),
            new Attachment(name: "ErrorAttachment.txt", contentType: "text/plain", base64Content: getBase64(errAttach))
    ]
    //remove anything that had empty content
    attachmentsContent = attachmentsContent.findAll { it.base64Content != "" }
    
    def emptyMap = []
    
    def builder = new JsonBuilder()
    builder.message {
        subject message.getHeader("emailSubject", java.lang.String)
        body {
            contentType 'text'
            content message.getBody(java.lang.String)
        }
        //recipients are mapped in the iFlow we call after so centralised
        toRecipients emptyMap
        //slightly different approach for attachments since its in a closure
        attachments attachmentsContent.collect { att ->
            [
                    "@odata.type" : "#microsoft.graph.fileAttachment",
                    "name"        : att.name,
                    "contentType" : att.contentType,
                    "contentBytes": att.base64Content
            ]

        }
    }
    message.setBody(builder.toString())
    
    return message;
}

def String getBase64(def attachment){
    //quick shortcut to avoid null errors, just return empty string if doesnt exist
    if(attachment != null ){
        return attachment.bytes.encodeBase64().toString()
    }else{
        return ""
    }
}