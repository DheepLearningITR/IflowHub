/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import java.io.*;

def Message processData(Message message) {
    //def body = message.getBody();
    def properties = message.getProperties();
    def headers = message.getHeaders();
    
    //def token = headers.get("x-csrf-token");
    //def supplier = properties.get("Supplier");
    Integer count = properties.get("loopIndex");
    def vendorattachmentMap = properties.get("attachmentMap");
    def fileStream = properties.get("byteStream");
    def attachment = vendorattachmentMap.get(count);
    def contentType = attachment.contentType;
    def fileName = attachment.fileName;
    def objectType = attachment.objectType;
    def vendorNumber = attachment.vendorNumber;

    count = count - 1;
    
    //String delay_c = properties.get("SupplierDelay");
	//Integer delay = delay_c as Integer ;
    
    //Set delay
    //sleep(delay);
    //Set header and property
    message.setHeader("Slug", fileName);
    message.setHeader("Content-Type", contentType);
    message.setHeader("BusinessObjectTypeName", objectType);
    message.setHeader("LinkedSAPObjectKey", vendorNumber);
    message.setProperty("loopIndex", count);
    message.setProperty("contentType", contentType);
    message.setBody(fileStream);
    
    return message;
}