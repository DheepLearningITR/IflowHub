import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

Message processData(Message message) {
    //Get Properties
    def property = message.getProperties();
	//String errorCountString = property.get("retryCounter");
	int errorCount = 0;
	
	errorCount = errorCount + 1;
	String delay_c = property.get("SupplierDelay");
	Integer delay = delay_c as Integer ;
    
    //Set delay
    sleep(delay);
    
    //Set Payload
    //message.setProperty("retryCounter", errorCount);
    
    return message;
}
