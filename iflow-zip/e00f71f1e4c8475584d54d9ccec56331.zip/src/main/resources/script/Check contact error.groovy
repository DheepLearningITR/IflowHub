/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.util.XmlParser;
import groovy.json.*;

def Message processData(Message message) {
    //Body 
		def bodyPayload = message.getBody(java.lang.String) as String;
		def messageLog = messageLogFactory.getMessageLog(message);
        def batchPartResponse = new XmlParser().parseText(bodyPayload);
        message.setProperty("ContactError", false);
        
        
		if(batchPartResponse != null && !batchPartResponse.equals("") && batchPartResponse.batchChangeSetResponse != null && !batchPartResponse.batchChangeSetResponse.equals("") 
			&& batchPartResponse.batchChangeSetResponse.batchChangeSetPartResponse != null && !batchPartResponse.batchChangeSetResponse.batchChangeSetPartResponse.equals("")){
			 //   NodeList batchChangeSetPartResponseNodes = batchPartResponse.batchChangeSetResponse.batchChangeSetPartResponse;
			    
			    batchPartResponse.batchChangeSetResponse.batchChangeSetPartResponse.findAll { it.statusCode }.each {

			           if(it.statusCode.text() != "204" || 
			              it.statusCode.text() != "202" ||
			              it.statusCode.text() != "201" ){
			               message.setProperty("ContactError", true);
			           }
			    }

			}        
        
       return message;
}