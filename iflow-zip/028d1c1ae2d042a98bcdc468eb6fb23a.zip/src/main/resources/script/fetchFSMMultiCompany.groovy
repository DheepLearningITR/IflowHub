import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import com.sap.it.api.ITApiFactory
import com.sap.it.api.asdk.datastore.*
import com.sap.it.api.asdk.runtime.*

def Message processData(Message message) {
    def body = message.getBody(java.lang.String)
    def query = new XmlParser().parseText(body)
    
    /*START: Logic to handle all FSM Company mapping*/
		def fsmCompanyList;
        def messageLog = messageLogFactory.getMessageLog(message)
        def DSservice = new Factory(DataStoreService.class).getService()
        
        // get the FSM Company List from data store
        def dsEntry = DSservice.get("FSMCompanyList", 'FSMCompanyList')?DSservice.get("FSMCompanyList", 'FSMCompanyList'):'NA'
        message.setProperty("dsEntry",dsEntry);
		if (dsEntry != 'NA'){
			def result = new String(dsEntry.getDataAsArray())
			fsmCompanyList = new XmlParser().parseText(result)
			//message.setProperty("fsmCompanyList",fsmCompanyList);

		}else{
		    fsmCompanyList = new XmlParser().parseText("<FSMMultiCompany><FSMCompany>NA|NA</FSMCompany></FSMMultiCompany>")
		}
		
        query.MaterialGroup.each { materialGroup ->
            materialGroup.append(fsmCompanyList)
        }
        
        /*END: Logic to handle all FSM Company mapping*/
			
    def FSMCompanyData = XmlUtil.serialize(query)
    message.setBody(FSMCompanyData)
    return message
}
