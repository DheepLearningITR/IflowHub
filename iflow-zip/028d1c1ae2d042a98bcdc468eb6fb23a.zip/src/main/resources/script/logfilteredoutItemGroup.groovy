import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil;
import groovy.util.slurpersupport.NodeChild;

def Message processData(Message message) {
    /* This script is to log the Item Group IDs that are filtered out with no FSM company. */
	
    def body = message.getBody(java.lang.String)
    def query = new XmlSlurper().parseText(body)
    def messageLog = messageLogFactory.getMessageLog(message)
	
    query.MaterialGroupMasterDataReplicationBundleRequest.MaterialGroup.each { ItemMessage ->
        ItemMessage.Code.each { ig ->
            def code = ig.content.text()
            if (messageLog != null) {
                messageLog.addCustomHeaderProperty("BPFSMCompanyNotFound", code)
            }
        }
    }
    return message
}
