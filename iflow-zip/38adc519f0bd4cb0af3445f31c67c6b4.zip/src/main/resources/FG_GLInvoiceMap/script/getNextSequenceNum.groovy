import com.sap.it.api.mapping.*;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String getNextSequenceNum(String prop_name,MappingContext context){

	def prop = context.getProperty(prop_name);
	String nextSeq = Integer.parseInt(prop) + 1;
	context.setProperty(prop_name,nextSeq);
    return nextSeq;
    }