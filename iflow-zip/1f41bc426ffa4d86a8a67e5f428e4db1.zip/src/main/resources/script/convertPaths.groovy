import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper;


Map transformToJson(Message message) {

    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    return json

}

void updateMessageBody(Message message, Map messageBody) {

    def messageBodyJson = JsonOutput.toJson(messageBody);
    def prettyMessageBody = JsonOutput.prettyPrint(messageBodyJson);

    message.setBody(prettyMessageBody)

}

def convertPathTree(List pathTokens, Map tree) {

    def FIRST_TOKEN = 0
    def REMAINING_TOKENS = 1..-1

    def token = pathTokens[FIRST_TOKEN]

    if (tree[token] == null) {
        return
    }

    if (pathTokens.size() == 1) {

        if (tree[token].isNumber()) {
            tree[token] = tree[token].toBigDecimal()
        } else if (tree[token].toLowerCase() == "true" || tree[token].toLowerCase() == "false") {
            tree[token] = Boolean.parseBoolean(tree[token])
        }

    } else {

        def tmpValueAtPath = tree[token]
        def newPathTokens = pathTokens[REMAINING_TOKENS]

        if (tmpValueAtPath instanceof List) {
            tmpValueAtPath.each { arrayElement ->
                if (arrayElement instanceof Map) {
                    convertPathTree(newPathTokens, arrayElement)
                }
            }
        } else if (tmpValueAtPath instanceof Map) {
            convertPathTree(newPathTokens, tmpValueAtPath)
        }
    }
}

Message convertPaths(Message message) {

    def FIELD_DELIMITER = ";"

    def messageJson = transformToJson(message)
    def conversionFields = message.getProperty("ConversionPaths")

    conversionFields.split(FIELD_DELIMITER).each { path ->
        def PATH_DELIMITER = "/"
        def pathTokens = path.tokenize(PATH_DELIMITER)
        convertPathTree(pathTokens, messageJson)
    }

    updateMessageBody(message, messageJson)

    return message

}