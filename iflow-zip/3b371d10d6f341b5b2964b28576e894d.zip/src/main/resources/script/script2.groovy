/*
    This script manages a simple cache which is used to avoid
    unnecesarry requests to vies validation service.
    If VIES validation service itself is not reachable or returns and error code
    that signifies a problem that would be common for all further requests,
    no more request are sent.
    If VIES validation service returns a country-specific error, no more validations
    are done for that specific country.
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

/*
 This script declares the map of errors right before the splitter step.
 This enables modification of the map during splitter iterations (map is a mutable object by default)
 */
def Message initialize(Message message) {
   def errors = [:]
   message.setProperty("errors", errors);
   return message;
}

/** This script maintains the cache **/
def Message updateAvailability(Message message) {
    def properties = message.getProperties();
    def errors = properties.get("errors");
    String countryCode = properties.get("countryCode");

    String errorCode = message.getProperties().get("CamelExceptionCaught").getMessage();
    String errorKey;
    switch (errorCode) {
        case ~/.*MS_UNAVAILABLE.*/:
        case ~/.*TIMEOUT.*/: // not sure if this is ms timeout or global timeout
        case ~/.*MS_MAX_CONCURRENT_REQ.*/:
        case ~/.*MS_MAX_CONCURRENT_REQ_TIME.*/:
            errorKey = countryCode;
            break;        
        case ~/.*INVALID_REQUESTER_INFO.*/:
        case ~/.*SERVICE_UNAVAILABLE.*/:
        case ~/.*IP_BLOCKED.*/:
        case ~/.*GLOBAL_MAX_CONCURRENT_REQ.*/:
        case ~/.*GLOBAL_MAX_CONCURRENT_REQ_TIME.*/:
            errorKey = "all";
            break;
        case ~/.*VAT_BLOCKED.*/: // not sure what this means at all
        default:
            break;
    }

    if (errorKey) {
        if (!errors.containsKey(errorKey)) {
            errors[errorKey] = errorCode;
        }
        message.setProperty("errorCode", errors[errorKey]);
    }
    else {
        message.setProperty("errorCode", errorCode);
    }
    
    return message;
}

/** This script reads the cache **/
def Message checkAvailability(Message message) {
    def properties = message.getProperties();
    def errors = properties.get("errors");
    String countryCode = properties.get("countryCode");
    if (errors.containsKey("all")) {
        throw new Exception(errors["all"]);
    }
    else if (errors.containsKey(countryCode)) {
        throw new Exception(errors[countryCode]);
    }
    return message;
}