/*
 This script tests whether the cached entry is from today (=valid) or older (=invalid)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

    boolean cacheHit = false;
    def entryDate = message.getHeaders().get("validationTimestamp");
    
    try {
        def parsedEntryDate = Date.parse("dd-MM-yyyy HH:mm z", entryDate);
        def now = new Date();
        cacheHit = parsedEntryDate.format("ddMMyyyy") == now.format("ddMMyyyy");        
    }
    catch(e) {
        cacheHit = false;
    }
    
    message.setProperty("cacheHit", cacheHit);
       
    return message;
}