import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonBuilder

def Message processPricingProcedureResponse(Message message) {
  //Body
  def body = message.getBody(java.io.Reader)
  def xml = new XmlSlurper().parse(body)

    // Process each A_SlsPricingProcedureType
    def result = xml.A_SlsPricingProcedureType.collect { procedureType ->
        def descriptions = procedureType.to_Text.A_SlsPricingProcedureTextType.collect { textType ->
        [
            languageCode: textType.Language.text(),
            content: textType.PricingProcedureName.text()
        ]
        }
        [
            code: procedureType.PricingProcedure.text(),
            descriptions: descriptions
        ]
    }

    // Convert to JSON using JsonOutput
    def json = JsonOutput.toJson(result)
    message.setBody(json)


    return message
}

def Message processPricingProcedureStepsResponse(Message message) {
  //Body
  def body = message.getBody(java.io.Reader)
  // Parse XML
  def xml = new XmlSlurper().parse(body)
  
        // Extract steps and map fields
        def steps = xml.A_SlsPricingProcedureType.to_SalesPricingProcedureItem.A_SlsPricingProcedureItemType.collect { step ->
            [
                    stepNumber                   : step.PricingProcedureStep.text(),
                    conditionCounter             : step.PricingProcedureCounter.text(),
                    conditionType                : step.ConditionType.text(),
                    fromStep                     : step.PrcgProcedItemFromRefStep.text(),
                    toStep                       : step.PrcgProcedItemToRefStep.text(),
                    isConditionDeterminedManually: step.ConditionIsManuallyDtmnd.text() == 'true',
                    conditionSubtotal            : step.PrcgProcedItemSubtotal.text(),
                    isStatistical                : step.ConditionIsForStatistics.text() == 'true',
                    isMandatoryCondition         : step.ConditionIsMandatory.text() == 'true',
                    printId                      : step.PricingProcedureItemPrintType.text()
            ]
        }

        // Create the final JSON structure
        def result = [
                steps: steps
        ]

   // Convert to JSON using JsonOutput
  def json = JsonOutput.toJson(result)
  
  

  message.setBody(json)
  return message

}


def Message processBatchPricingProcedureStepTextsResponse(Message message) {
    def bodyReader = message.getBody(java.io.Reader)

    if (bodyReader == null) {
        message.setBody(new JsonBuilder([]))
        return message
    }

    try {
        def parsedXml = new XmlParser(false, false).parse(bodyReader)

        // Step 1: Collect all items under statusCode=200
        def items = []
        parsedXml.'batchQueryPartResponse'.each { part ->
            def status = part.'statusCode'?.text()?.trim()
            if (status == '200') {
                def itemContainer = part.body.'A_SlsPrcgProcedItemText'
                itemContainer?.'A_SlsPrcgProcedItemTextType'?.each { node ->
                    items << [
                        code:             node.'PricingProcedure'?.text()?.trim() ?: '',
                        stepNumber:       node.'PricingProcedureStep'?.text()?.trim() ?: '',
                        conditionCounter: node.'PricingProcedureCounter'?.text()?.trim() ?: '',
                        languageCode:     node.'Language'?.text()?.trim() ?: '',
                        content:          node.'ConditionTypeName'?.text()?.trim() ?: ''
                    ]
                }
            }
        }

        // Step 2: Group by code/stepNumber/conditionCounter, maintaining first-appearance order
        def seenCombinations = []  // List of [code,step,counter] in first-seen order
        def groups = [:]           // Key: tuple -> array of descriptions

        items.each { rec ->
            def key = [rec.code, rec.stepNumber, rec.conditionCounter]
            if (!groups.containsKey(key)) {
                groups[key] = []
                seenCombinations << key
            }
            groups[key] << [
                languageCode: rec.languageCode,
                content: rec.content
            ]
        }

        // Step 3: Build output in first-appearance order
        def result = seenCombinations.collect { key ->
            [
                code: key[0],
                stepNumber: key[1],
                conditionCounter: key[2],
                descriptions: groups[key]
            ]
        }

        // Step 4: Output JSON to body
        def jsonOutput = new JsonBuilder(result)
        message.setBody(jsonOutput)

        return message

    } catch(Exception e) {

        message.setBody(new JsonBuilder([error: "Exception during XML-to-JSON: ${e.getMessage()}"]))
        return message
    }
}

def Message processConditionTypes(Message message) {
  //Body
  def body = message.getBody(java.io.Reader)
  def xml = new XmlSlurper().parse(body)

  // Process each batchQueryPartResponse with statusCode 200 and valid body content
  def root = xml.batchQueryPartResponse.findAll {
    it.statusCode.text() == '200' && it.body.A_SlsPricingConditionType.A_SlsPricingConditionTypeType.size() > 0
  }.collect {
    part ->
      def type = part.body.A_SlsPricingConditionType.A_SlsPricingConditionTypeType

    // Create descriptions array
    def descriptions = type.to_Text.A_SlsPrcgCndnTypeTextType.collect {
      text -> [
        languageCode: text.Language.text(),
        content: text.ConditionTypeName.text()

      ]
    }

    // Create main object
    [
        code: type.ConditionType.text(),
        accessSequence: type.AccessSequence.text() ?: '',
        conditionClass: type.ConditionClass.text() ?: '',
        calculationType: type.ConditionCalculationType.text() ?: '',
        conditionCategory: type.ConditionCategory.text() ?: '',
        roundingRule: type.PrcgCndnAmountRoundingRule.text() ?: '',
        structureCondition: type.StructureCondition.text()?: '',
        plusMinusSign: type.PrcgConditionAmountSign.text()?: '',
        isGroupCondition: type.IsGroupCondition.text() == 'X',
        groupKeyRoutineIPC: type.PrcgGroupConditionRoutine.text() ?: '',
        manualPriority: type.CndnManualEntries.text() ?: '',
        isHeaderCondition: type.CndnAppliesHeader.text() == 'true',
        isItemCondition: type.CndnAppliesItems.text() == 'true',
        isDeleteScopeForChangingRate: type.PrcgCndnTypeDeletionIsAllowed.text() == 'true',
        isRateChangeable: type.PrcgCndnAmountChangedIsAllowed.text() == 'true',
        isConvertCurrencyPostMultiplication: type.PrcgCndnQtyCnvrsnIsActivated.text() == 'true',
        validFrom: type.PrcgCndnPrpsdValidFromDateCode.text() ?: '',
        validTo: type.PrcgCndnPrpsdValidToDateCode.text() ?: '',
        scaleType: type.PricingScaleType.text() ?: '',
        scaleBaseType: type.PricingScaleBasisShort.text() ?: '',
        checkingRuleForScaleRate: type.PricingScaleCheckingRule.text() ?: '',
        descriptions: descriptions
    ]
  }

  // Create final JSON structure
  //def jsonStructure = [root: root]

 
  // Convert to JSON using JsonOutput
  def json = JsonOutput.toJson(root)
  message.setBody(json)
  return message
}

def Message processExclusionProcedureSteps(Message message) {
    // Body
    def body = message.getBody(java.io.Reader)

    // Parse XML
    def xmlSlurper = new XmlSlurper()
    def xml = xmlSlurper.parse(body)

 // Extract data and create the desired structure
        def pricingProcedure = xml.SlsCndnExclsnForPrcgProced_Type[0].PricingProcedure.text()
        def steps = xml.SlsCndnExclsnForPrcgProced_Type.collect { exclusionType ->
            [
                    seqNo          : exclusionType.CndnExclusionSequentialNumber.text(),
                    exclusionType  : exclusionType.ConditionExclusionProcedure.text(),
                    exclusionGroup1: exclusionType.ConditionExclusionGroup1.text(),
                    exclusionGroup2: exclusionType.ConditionExclusionGroup2.text()
            ]
        }

        def result = [
                code : pricingProcedure,
                steps: steps
        ]


    def json = JsonOutput.toJson(result)

    message.setBody(json)
    return message
}

def Message processAccessSequenceResponse(Message message) {
  //Body
  def body = message.getBody(java.io.Reader)
  def xml = new XmlSlurper().parse(body)



        def result = xml.batchSetResponse.findAll {
            it.statusCode.text() == '200'
        }.collect { batchPart ->
            batchPart.body.SalesPricingAccessSequence.SalesPricingAccessSequenceType.collect { accessSequenceType ->
                def code = accessSequenceType.AccessSequence.text()
                def accesses = []
                if(accessSequenceType._SalesPricingAccess.SalesPricingAccessType){
                    accesses = accessSequenceType._SalesPricingAccess.SalesPricingAccessType.collect { accessType ->
                        [
                                accessNumber: accessType.AccessNumberOfAccessSequence.text(),
                                tableNumber: accessType.ConditionTable.text(),
                                isExclusive: accessType.PrcgConditionAccessIsExclusive.text() == 'true',
                                requirement: accessType.ConditionRequirement.text()
                        ]
                    }
                }

                def descriptions = []
                if(accessSequenceType._Text.SlsPricingAccessSequenceTextType){
                    descriptions = accessSequenceType._Text.SlsPricingAccessSequenceTextType.collect { textType ->
                        [
                                languageCode: textType.Language.text(),
                                content: textType.AccessSequenceText.text()
                        ]
                    }
                }

                [
                        code: code,
                        accesses: accesses,
                        descriptions: descriptions
                ]
            }
        }.flatten()


 
  // Convert to JSON using JsonOutput
  def json = JsonOutput.toJson(result)
  message.setBody(json)
  return message
}

def Message processAccessSequenceFieldResponse(Message message) {
  //Body
  def body = message.getBody(java.io.Reader)
  def xml = new XmlSlurper().parse(body)


       def outputJson = []

        xml.batchSetResponse.findAll { it.statusCode.text() == '200' }.each { batchPart ->
            batchPart.body.SalesPricingAccess.SalesPricingAccessType.each { accessType ->
                def accessSequence = accessType.AccessSequence.text()
                def accessNumberOfAccessSequence = accessType.AccessNumberOfAccessSequence.text()
                def fieldMappings = []
                def counter = 1

                accessType._SalesPricingAccessField.SalesPricingAccessFieldType.each { fieldType ->
                    def fieldMapping = [:]
                    fieldMapping.counter = counter++
                    fieldMapping.sourceFieldTable = fieldType.PrcgCndnAccDocumentStructure.text()
                    fieldMapping.targetFieldName = fieldType.PricingConditionField.text()
                    fieldMapping.sourceFieldName = fieldType.PrcgCndnAccessDocumentField.text()
                    fieldMapping.sourceFieldConstant = fieldType.PrcgCndnAccConstantValueSource.text()
                    fieldMapping.isInitialValueAllowed = fieldType.PrcgCndnValueInitialIsAllowed.text() == 'true'
                    fieldMapping.accessType = fieldType.PricingConditionAccessType.text()
                    fieldMapping.priorityForEvaluation = fieldType.PricingConditionAccessPriority.text()
                    fieldMappings.add(fieldMapping)
                }

                outputJson.add([
                        accessSequence                 : accessSequence,
                        accessNumberOfAccessSequence: accessNumberOfAccessSequence,
                        fieldMappings                 : fieldMappings
                ])
            }
        }
 
  // Convert to JSON using JsonOutput
  def json = JsonOutput.toJson(outputJson)
  message.setBody(json)
  return message
}

def Message processConditionTableResponse(Message message) {
    // Body
    def body = message.getBody(java.io.Reader)

    // Parse XML
    def xmlSlurper = new XmlSlurper()
    def xml = xmlSlurper.parse(body)

    // Convert XML to String
    def xmlString = groovy.xml.XmlUtil.serialize(xml)

    // Check for and remove XML declaration if present
    def xmlDeclarationRegex = /<\?xml.*?\?>/
    if (xmlString.find(xmlDeclarationRegex)) {
        xmlString = xmlString.replaceAll(xmlDeclarationRegex, '')
        println "XML declaration removed from input."
    }

    // Parse the modified XML string
    def parsedXml = new XmlSlurper().parseText(xmlString)

    def result = parsedXml.batchSetResponse.findAll {
        it.statusCode.text() == '200'
    }.collect { batchPart ->
        batchPart.body.SalesPricingConditionTable.SalesPricingConditionTableType.collect { conditionTableType ->
            def code = conditionTableType.ConditionTable.text()
            def fields = []
            def counter = 0
            if (conditionTableType._SlsPrcgConditionTableField.SlsPrcgConditionTableFieldType) {
                fields = conditionTableType._SlsPrcgConditionTableField.SlsPrcgConditionTableFieldType.collect { fieldType ->
                    [
                            fieldNum        : counter++,
                            targetFieldName: fieldType.PricingConditionField.text()
                    ]
                }
            }

            def descriptions = []
            if (conditionTableType._Text.SlsPricingConditionTableTextType) {
                descriptions = conditionTableType._Text.SlsPricingConditionTableTextType.collect { textType ->
                    [
                            languageCode: textType.Language.text(),
                            content : textType.ConditionTableText.text()
                    ]
                }
            }

            [
                    code        : code,
                    tableFields      : fields,
                    descriptions: descriptions
            ]
        }
    }.flatten()

    def json = JsonOutput.toJson(result)

    message.setBody(json)
    return message
}

def Message processExclusionProcedureGroupResponse(Message message) {
  //Body
  def body = message.getBody(java.io.Reader)
  def xml = new XmlSlurper().parse(body)

        def outputJson = []

        xml.batchSetResponse.findAll { it.statusCode.text() == '200' }.each { batchPart ->
            batchPart.body.SlsPrcgCndnExclusionGroup.SlsPrcgCndnExclusionGroup_Type.each { groupType ->
                def groupData = [:]
                groupData.code = groupType.ConditionExclusionGroup.text()
                groupData.conditionTypes = []
                groupData.descriptions = []

                groupType._SlsPrcgCndnTypeInExclsnGroup.SlsPrcgCndnTypeInExclsnGroup_Type.each { conditionType ->
                    groupData.conditionTypes.add(conditionType.ConditionType.text())
                }

                groupType._Text.SlsPrcgCndnExclsnGroupText_Type.each { textType ->
                    def description = [:]
                    description.languageCode = textType.Language.text()
                    description.content = textType.ConditionExclusionGroupText.text()
                    groupData.descriptions.add(description)
                }
                outputJson.add(groupData)
            }
        }



    // Convert to JSON using JsonOutput
    def json = JsonOutput.toJson(outputJson)
    message.setBody(json)


    return message
}


