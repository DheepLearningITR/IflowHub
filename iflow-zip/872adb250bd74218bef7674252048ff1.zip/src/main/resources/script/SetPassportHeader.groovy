import com.sap.gateway.ip.core.customdev.util.Message;
//Imports for DataStoreService-class
import com.sap.it.api.asdk.datastore.*
import com.sap.it.api.asdk.runtime.*

def Message processData(Message message)
 {
   
    def service = new Factory(DataStoreService.class).getService()
    if( service != null) {		
		def dsEntry = service.get("PassportStore","PassportValue")
		def result = new String(dsEntry.getDataAsArray())
		message.setHeader("sap-passport", result)
	}	


    return message;             
 }