import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential
import com.sap.it.api.securestore.exception.SecureStoreException

def Message processData(Message message) {
      def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)
      def map = message.getProperties();   
       def path = map.get("sharedsecretpath");
    try{
        def secureParameter = secureStorageService.getUserCredential(path)
        def aribasharedsecret = secureParameter.getPassword().toString()
       message.setProperty("sharedsecretariba", aribasharedsecret)
    } catch(Exception e){
        throw new SecureStoreException("Secure Parameter " + path + " is not available.")
    }
    return message;
}