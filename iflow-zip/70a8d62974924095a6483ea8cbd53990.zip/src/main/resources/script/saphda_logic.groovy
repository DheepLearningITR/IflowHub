import groovy.json.JsonBuilder
import com.sap.it.api.mapping.*;
import org.json.JSONObject;
import org.json.JSONException;
import java.nio.charset.StandardCharsets
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher
import java.util.regex.Pattern
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message CustomerSalesOrg(Message message) {

    HashMap<String, String> map = new HashMap<String, String>();
    map.put("0017100001","1710");
    map.put("0017100002","1710");
    map.put("0017100003","1710");
    map.put("0017100008","1710");
    map.put("0017100009","1710");

    message.setProperty("saphda_CustomerSalesorg", map);

    return message;
}

def Message catch_camels(Message message){

    def map  = message.getProperties();
    def ex   = map.get("CamelExceptionCaught");
    def exceptionText;

    if (ex != null) {
        exceptionText    = ex.getMessage();
        def messageLog   = messageLogFactory.getMessageLog(message);
        messageLog.addAttachmentAsString("Exception", exceptionText,"application/text");

        // copy the http error response body as a property
        message.setProperty("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());

        try {

            def mp = [
                    "jobStatus": "ERROR",
                    "jobStatusDescription": exceptionText,
                    "modelID" : message.getProperty('saphda_modelID'),
                    "current/nextmonth" :  message.getProperty('saphda_current_calmonth')
            ];

            def ibpCommitStatus = new JSONObject(mp).toString();

            message.setProperty("http.response", ibpCommitStatus);

            message.setBody(ibpCommitStatus);

        } catch (JSONException e) {
            message.setBody(e);
        }
    }
    return message;
}

def Message checkStatus(Message message) {

    Reader body = message.getBody(Reader)

    def input = new JsonSlurper().parse(body)

    message.setProperty("jobStatus", input.jobStatus);
    message.setProperty("failedNumberRows", input.additionalInformation.failedNumberRows);

    if (input.jobStatus != 'COMPLETED') {
        sleep(1000);
    }

    return message;
}

def Message clearBody(Message message) {
    //Body
    def body = message.getBody();
    message.setBody("");
    return message;
}

def Message save_ibp_payload(Message message) {

    Reader body = message.getBody(Reader)

    def input = new JsonSlurper().parse(body)

    def properties = message.getProperties();

    saphda_jobname = properties.get("saphda_jobname");
    if ( saphda_jobname == 'initial' ) {
        message.setProperty("saphda_jobname", input.jobID);
    }

    value = properties.get("body");
    message.setBody(value);

    return message;
}

def Message handleRequestBody(Message message) {

    def body = message.getBody(java.io.Reader);
    def input = new JsonSlurper().parse(body)

    def saphda_calmonth_from = URLEncoder.encode(input.calmonthFrom, StandardCharsets.UTF_8.name())
    message.setProperty("saphda_calmonth_from", convertToDateLong(saphda_calmonth_from));
    message.setProperty("saphda_current_calmonth", convertToDateLong(saphda_calmonth_from));

    def saphda_calmonth_to = URLEncoder.encode(input.calmonthTo,StandardCharsets.UTF_8.name())
    message.setProperty("saphda_calmonth_to", convertToDateLong(saphda_calmonth_to));

    def modelID = URLEncoder.encode(input.modelID,StandardCharsets.UTF_8.name())
    message.setProperty("saphda_modelID", modelID);
    return message;
}

def String convertDate(String arg1){

    Pattern pattern = Pattern.compile("\\d+")
    Matcher matcher = pattern.matcher(arg1)

    String converted_datetime =  ""
    if (matcher.find()) {
        def arg1_long = Long.valueOf(matcher.group())
        Date result_date = new Date( arg1_long );
        DateFormat simple = new SimpleDateFormat(
                "yyyyMM");
        converted_datetime = simple.format(result_date);
    }

    return converted_datetime;
}

def String convertDateLong(String arg1){

    Pattern pattern = Pattern.compile("\\d+")
    Matcher matcher = pattern.matcher(arg1)

    String converted_datetime =  ""
    if (matcher.find()) {
        def arg1_long = Long.valueOf(matcher.group())
        Date result_date = new Date( arg1_long );
        DateFormat simple = new SimpleDateFormat(
                'yyyy-MM-dd\'T\'00:mm:ss');
        converted_datetime = simple.format(result_date);
    }

    return converted_datetime;
}

def String convertCustID(String arg1) {

    return arg1.replaceFirst("^0+(?!\$)", "")
}

def BigDecimal convertKyf(arg1){

    BigDecimal f = 0
    try {
        f = new BigDecimal(arg1).setScale(7, java.math.RoundingMode.HALF_UP);
    } catch (Exception e) {
        f = 0
    }
    return f;
}

def Message transform(Message message) {

    def propMap = message.getProperties()
    def SalesOrgCompcodeProp = propMap.get("saphda_SalesOrgCompcode")
    Map SalesOrgCompcodeMap= new JsonSlurper().parseText(SalesOrgCompcodeProp)
    HashMap<String, String> map = new HashMap<String, String>();
    SalesOrgCompcodeMap.d.results.each { item -> map.put(item.SalesOrganization,item.CompanyCode);}

    def ribp = propMap.get("saphda_ibp_response")
    Map ibpdata = new JsonSlurper().parseText(ribp)
    def result_array = ibpdata.get("d").get("results")

    def TreeMap<String,HashMap> CustomerSalesorgMap = propMap.get("saphda_CustomerSalesorg");

    def data_raw = result_array.collect {[
            "Version": "public.Plan",
            "Date": convertDate(it.PERIODID3_TSTAMP),
            "SAP_ALL_COMPANY_CODE": map.getOrDefault(CustomerSalesorgMap.getOrDefault(it.CUSTID,"#"),"#"),
            "SAP_ALL_SALESORGANISATION": CustomerSalesorgMap.getOrDefault(it.CUSTID, "#"),
            "SAP_ALL_PRODUCT": it.PRDID,
            "SAP_ALL_DISTRIBUTIONCHANNEL": "10",
            "SAP_FI_XPA_GLAccount": "41000000",
            "SAP_SD_SalesActivity": "#",
            "SAP_SD_Tactic": "#",
            "SpendType": "#",
            "SAP_FI_IFP_QUANTITY_UNIT": it.UOMTOID,
            "SAP_ALL_CUSTOMER": convertCustID(it.CUSTID),
            "SAP_ALL_PLANT": it.LOCID,
            "QUANTITY": convertKyf(it.BASEFCSTQTY) * -1,
    ] }

    def data_sum = data_raw
            .groupBy {
                [ it.Version,
                  it.Date,
                  it.SAP_ALL_COMPANY_CODE,
                  it.SAP_ALL_SALESORGANISATION,
                  it.SAP_ALL_PRODUCT,
                  it.SAP_ALL_DISTRIBUTIONCHANNEL,
                  it.SAP_FI_XPA_GLAccount,
                  it.SAP_SD_SalesActivity,
                  it.SAP_SD_Tactic,
                  it.SpendType,
                  it.SAP_FI_IFP_QUANTITY_UNIT,
                  it.SAP_ALL_CUSTOMER,
                  it.SAP_ALL_PLANT
                ] }

    def data_sum2 = data_sum
            .collectEntries { [ (it.key): [
                    Version: it.value.Version.first(),
                    Date: it.value.Date.first(),
                    SAP_ALL_COMPANY_CODE: it.value.SAP_ALL_COMPANY_CODE.first(),
                    SAP_ALL_SALESORGANISATION: it.value.SAP_ALL_SALESORGANISATION.first(),
                    SAP_ALL_PRODUCT: it.value.SAP_ALL_PRODUCT.first(),
                    SAP_ALL_DISTRIBUTIONCHANNEL: it.value.SAP_ALL_DISTRIBUTIONCHANNEL.first(),
                    SAP_FI_XPA_GLAccount: it.value.SAP_FI_XPA_GLAccount.first(),
                    SAP_SD_SalesActivity: it.value.SAP_SD_SalesActivity.first(),
                    SAP_SD_Tactic: it.value.SAP_SD_Tactic.first(),
                    SpendType: it.value.SpendType.first(),
                    SAP_FI_IFP_QUANTITY_UNIT: it.value.SAP_FI_IFP_QUANTITY_UNIT.first(),
                    SAP_ALL_CUSTOMER : it.value.SAP_ALL_CUSTOMER.first(),
                    SAP_ALL_PLANT : it.value.SAP_ALL_PLANT.first(),
                    QUANTITY: it.value.sum {it.QUANTITY} ] ] }


    def builder = new JsonBuilder()
    builder { Data data_sum2.collect {[
            "Version": it.key[0],
            "Date": it.key[1],
            "SAP_ALL_COMPANY_CODE": it.key[2],
            "SAP_ALL_SALESORGANISATION": it.key[3],
            "SAP_ALL_PRODUCT": it.key[4],
            "SAP_ALL_DISTRIBUTIONCHANNEL": it.key[5],
            "SAP_FI_XPA_GLAccount": it.key[6],
            "SAP_SD_SalesActivity": it.key[7],
            "SAP_SD_Tactic": it.key[8],
            "SpendType": it.key[9],
            "SAP_FI_IFP_QUANTITY_UNIT": it.key[10],
            "SAP_ALL_CUSTOMER" : it.key[11],
            "SAP_ALL_PLANT" : it.key[12],
            "QUANTITY": it.value.QUANTITY
    ] }}

    def prettyBody = builder.toPrettyString()

    message.setBody(prettyBody);

    return message;
}

def Message calcCurrentMonth(Message message) {
    
    def propMap = message.getProperties()
    def saphda_IBPTimestamps = propMap.get('saphda_IBPTimestamps')
    def saphda_IBPTimestamps_json = new JsonSlurper().parse(new StringReader(saphda_IBPTimestamps))
    def saphda_IBPTimestamps_array = saphda_IBPTimestamps_json.get("d").get("results")

    def saphda_current_calmonth = propMap.get('saphda_current_calmonth')
    def saphda_calmonth_to = propMap.get('saphda_calmonth_to')
    def saphda_calmonth_from = propMap.get('saphda_calmonth_from')

    saphda_IBPTimestamps_array = saphda_IBPTimestamps_array.sort{ it.PERIODID3_TSTAMP }
    
    def found = false
    saphda_IBPTimestamps_array.any { f ->
        def period3 = convertDateLong(f.PERIODID3_TSTAMP)
        if ( period3.compareTo(saphda_current_calmonth) > 0 && found == false ) {
          saphda_current_calmonth = period3
          found = true
        }
    }
    
    message.setProperty("saphda_current_calmonth",saphda_current_calmonth)

    return message;
}

def Message setJobName(Message message) {

    Reader body = message.getBody(Reader)

    def input = new JsonSlurper().parse(body)

    def properties = message.getProperties();
    
    saphda_jobname = properties.get("saphda_jobname");
    if ( saphda_jobname == 'initial' ) {
        message.setProperty("saphda_jobname", input.jobID);
    }
    
    value = properties.get("body");    
    message.setBody(value);

    return message;
}