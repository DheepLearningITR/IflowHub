import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    def err_message = "Error during JSON handling";
    
    
    messageLog.addAttachmentAsString('Error', err_message, "text/plain");
	
	return message;
}
