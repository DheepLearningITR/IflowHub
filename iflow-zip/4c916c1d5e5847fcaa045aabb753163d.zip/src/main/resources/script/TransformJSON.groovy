import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.Arrays;
import groovy.json.JsonSlurper
import java.lang.String;
import java.lang.StringBuilder
import groovy.json.JsonBuilder

def Message mapData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    def body = message.getBody(java.io.Reader);
    def headers = message.getHeaders();
    def properties = message.getProperties();
    

    def slurper = new JsonSlurper()
    def result = slurper.parse(body)
    
    //defining the order of the fields
    def fieldList = properties.get("FieldList");
    def fieldOrder = fieldList.split(",")


    //reorder it in the payload
def reorderedItems = result.ITEMS.collect { item ->
def orderedMap = new LinkedHashMap()
fieldOrder.each { fieldName ->
// For each fieldName assign the value from the original item map
orderedMap[fieldName] = item[fieldName] ?: '' // Returns empty string if fieldName doesn't exist
}
orderedMap
}

    // Create a new map with the key "ITEMS" with the reordered items
    def resultMap = [ITEMS: reorderedItems]
    //convert it into JSON
    def builder = new JsonBuilder(resultMap)
    def buildedJson = builder.toPrettyString()
    def reorderedJson = slurper.parseText(buildedJson)
    

//input: {
//"ITEMS": [
//{
//"CUSTID": "10100003",
//"CUSTCOUNTRY": "DE",
//"CUSTDESCR": "Example Description",
//"CUSTREGION": "Example"
//}

    StringBuilder sbOutput = new StringBuilder();

    sbOutput.append("<items>")
    
    //String[] full_items = Arrays.stream(reorderedJson.ITEMS.toArray()).parallel().map({item -> '<item><DATA_STRING>' +  item.values().collect { "\"$it\"" }.join(",") + '</DATA_STRING></item>'}).toArray({size -> new String[size]});
    
    String[] full_items = Arrays.stream(reorderedJson.ITEMS.toArray()).parallel().map({item -> '<item><DATA_STRING>' + item.values().collect { it != '' ? "\"$it\"" : "$it" }.join(",") + '</DATA_STRING></item>'}).toArray({size -> new String[size]});

    sbOutput.append(full_items.join(""))
    
    sbOutput.append("</items>")
    
    message.setBody(sbOutput.toString())

    
//output:
//<items><item><DATA_STRING>"10100003","10","DE","Example Description","Example"</DATA_STRING></item></items>
    
 
    //get the opening tag   
    def xmlWithoutItem = properties.get("xmlWithoutItem")
    
    //remove the closing / from the xmlWithoutItem
    String modifiedXmlWithoutItem = xmlWithoutItem.replaceAll('/>$', '>')
    
    // Extract the tag name using regular expression
    def tagName = xmlWithoutItem.find(/(?<=<)\w+/)

    //Create the closing tag
    String closingTag = "</${tagName}>"
    
    message.setProperty("closingTag",closingTag);
    message.setProperty("xmlWithoutItem",modifiedXmlWithoutItem);
    
    

    return message;
}
