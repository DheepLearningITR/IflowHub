import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    def err_message = "Invalid data format. Please provide a valid data format.(XML or JSON)";
    
	throw new Exception(err_message);

	
	return message;
}
