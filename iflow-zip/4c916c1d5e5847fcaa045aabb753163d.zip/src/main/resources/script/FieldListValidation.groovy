import groovy.json.JsonSlurper;
import com.sap.it.api.msglog.*;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message fieldListValidation(Message message) {
    
    //prerequisite
    def messageLog = messageLogFactory.getMessageLog(message);
    def body = message.getBody(java.io.Reader);
    def headers = message.getHeaders();
    def properties = message.getProperties();
    
    
    def slurper = new JsonSlurper()
    def parsed_body = slurper.parse(body)
   

    //extract the first item to get the tag names
    def item = parsed_body.ITEMS[0]
    def tagNames = item.keySet()
    
    //Log the tag names
    message.setProperty("TagNames",tagNames.join(", "));
    
    
    //check if tags and the field list are the same ignoring the order
    def fieldList = properties.get('FieldList');
    def tags = properties.get('TagNames');

    Set<String> fieldListSet = fieldList.split(',').collect { it.trim() }.toSet()
    Set<String> tagsSet = tags.split(',').collect { it.trim() }.toSet()
    
    boolean isSame = fieldListSet == tagsSet;
    
    
    
    //check if tags and the field list are the same not ignoring the order
    if(isSame==true) { 
        fieldListSet = fieldList.split(',').toList().toSet()
        tagsSet = tags.split(',').toList().toSet()
        
        boolean fieldListCorrectOrder = fieldListSet == tagsSet;
        message.setProperty("fieldListCorrectOrder",fieldListCorrectOrder);
        
        //if order is not correct then reorder
        if(fieldListCorrectOrder==false){
            def xmlWithoutItem = properties.get('xmlWithoutItem');
            def modifiedXmlWithoutItem = xmlWithoutItem.replaceFirst(/(?<=FieldList=").*?(?=")/, tags)
            message.setProperty("xmlWithoutItem",modifiedXmlWithoutItem);
        }
    }
    
    //TEST
    message.setProperty("set1",fieldListSet);
    message.setProperty("set2",tagsSet);
    
    message.setProperty("fieldListCorrect",isSame);
    
    
    return message;
    
}

def Message fieldListValidationError(Message message) {
	
	def messageLog = messageLogFactory.getMessageLog(message);
	
	throw new Exception("The value of Fieldlist parameter is not consistent with the data in the body.");
	
	return message;
}