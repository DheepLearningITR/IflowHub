/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.List; 
import java.lang.String;
import com.sap.it.api.mapping.*;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    def headers = message.getHeaders();
	    def headerWriteBatches = headers.get('IBPWriteBatches')
	    
	    def body = message.getBody(java.io.Reader);
	    def xmlBatchPackages = new XmlSlurper().parse(body);
	    
	    if(headerWriteBatches != null){
	        def headerWriteBatchesReader = new StringReader(headerWriteBatches)
            def xmlBatches = new XmlSlurper().parse(headerWriteBatchesReader);
    	    xmlBatches.children()?.@Key.each { } collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Batch Key", it2) };	
    	    xmlBatches.children()?.@Destination.each { } collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Destination", it2) };	
    	    xmlBatches.children()?.@CreatedAt.findAll {it.text() != ''} collect{ messageLog.addCustomHeaderProperty('IBP Write Batch Created At', it.text()) }; 
    	    xmlBatches.children()?.@Id.findAll {it.text() != ''} collect{ messageLog.addCustomHeaderProperty('IBP Write Batch ID', it.text()) };
    	    
	    } 
	    else{
    	    xmlBatchPackages.'**'.findAll {it.@BatchKey != null && it.@BatchKey.text() != ''}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Batch Key", it2.@Key.text()) };	
    	    xmlBatchPackages.'**'.findAll {it.@Destination != null && it.@Destination.text() != ''}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Destination", it2.@Destination.text()) };	
    	    xmlBatchPackages.'**'.findAll {it.@BatchId != null && it.@BatchId.text() != ''}.each { it2 -> messageLog.addCustomHeaderProperty('IBP Write Batch ID', it2.@BatchId.text()) };
	    }
	    xmlBatchPackages?.IBPWriteBatchPackage?.Request?.children()?.findAll {it.@FieldList != '' && it.parent().parent().@Status != 'OK'} collect{it.@FieldList.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Failed Field List", it2) };	
	    xmlBatchPackages?.IBPWriteBatchPackage?.Request?.children()?.findAll {it.@FieldList != '' && it.parent().parent().@Status == 'OK'} collect{it.@FieldList.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Field List", it2) };	
	    xmlBatchPackages?.IBPWriteBatchPackage?.Response?.Status.findAll {it.text() != ''} collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Status", it2) };	
	    xmlBatchPackages?.IBPWriteBatchPackage?.Response?.Messages?.Message.findAll {it.text() != ''} collect{ it.@Type.text() + ': ' + it.text() }.eachWithIndex { it2,index2 -> 
	        def messageLength = it2.length();
	        if (messageLength<=198) messageLog.addCustomHeaderProperty("IBP Write Message " + (index2 + 1), it2);
	        else {
	            int i = 0;
	            for (int j = 0; j < messageLength;j += 198) {
	                def k = j + 198;
	                i++;
	                messageLog.addCustomHeaderProperty("IBP Write Message " + (index2 + 1) + '.' + i, it2.substring(j,k<=messageLength?k:messageLength));
	            }
	        }
	    };
/*	    def statusItems = xmlBatchPackages.'_-IBP_-INTIS_GET_PP_STATUS.Response'.'ET_PP_STATUS'.item;
	    statusItems.BATCH.findAll {it.text() != ''} collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Batch ID", it2) };	
	    statusItems.BATCH_NAME.findAll {it.text() != ''} collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Batch Name", it2) };	
	    statusItems.BATCH_STATUS.findAll {it.text() != ''} collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Batch Status", it2) };	
	    statusItems.BATCH_COMMAND.findAll {it.text() != ''} collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Batch Command", it2) };	
	    statusItems.BATCH_STATUS.findAll {it.text() != ''} collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Batch Status", it2) };	
	    statusItems.TYPE_OF_DATA.findAll {it.text() != ''} collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Type of Data", it2) };
	    statusItems.PLAREA.findAll {( it.parent().TYPE_OF_DATA.text() == 'Key Figure' || ( it.parent().TYPE_OF_DATA.text() == 'Master Data' && it.parent().SCENARIO.text() != '' && it.parent().SCENARIO.text() != '__BASELINE' ) ) && it.text() != ''} collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Planning Area", it2) };
	    statusItems.SCENARIO.findAll {it.text() != ''} collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Planning Area Version", it2) };	
	    statusItems.TPID.findAll {it.parent().TYPE_OF_DATA.text() == 'Time Profile' && it.text() != '' && it.text() != '0' } collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Time Profile", it2) };	
	    statusItems.PACKET.findAll {it.text() != ''} collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Package", it2) };	
	    statusItems.PLOBJTYPE.findAll {it.text() != ''} collect{it.text()}.each { it2 -> messageLog.addCustomHeaderProperty("IBP Master Data Type", it2) };	
	    statusItems.each {  
	        def result = 'batch:' + it.BATCH.text() + ', package:' + it.PACKET.text();
	        if (it.BATCH_STATUS.text() == 'ERROR') { result += ', unprocessed:' }
	        else { result += ', count:' };
	        result += it.RECORD_COUNT.text();
	        if (it.ERROR_RECORD_COUNT.text() > '0') { result += ', errors:' + it.ERROR_RECORD_COUNT.text() };
	        messageLog.addCustomHeaderProperty("IBP Write Result", result);
	        if (it.ERROR_MSG.text() != '') { messageLog.addCustomHeaderProperty("IBP Write Process Error", 'batch:' + it.BATCH.text() + ', package:' + it.PACKET.text() + ', 1st error:' + it.ERROR_MSG.text()) };
	    } 
	    */
	    def writeBatches = headers.get('IBPWriteBatches');
	    if (writeBatches != '') {
	        messageLog.addAttachmentAsString('IBPWriteBatches', writeBatches, 'text/xml');
	    }

	    xmlBatchPackages?.IBPWriteBatchPackage?.Request?.children().findAll {it.parent().parent().@Status != 'OK'} collect{ 'ID:' + it.@BatchId.text() + ', Key:' + it.@BatchKey.text() + ', Destination:' + it.@Destination.text() + ', Count:' + it.@count.text() + ', Type:' + it.name().find(/(?:\.)([^.]*)/).substring(1) }.each { it2 -> messageLog.addCustomHeaderProperty("IBP Write Failed Batch", it2) };	
	        
/*	    
	            <xsl:variable name="batchStatus" select="./BATCH_STATUS"/>
        <xsl:variable name="recordCount" select="./RECORD_COUNT"/>
        <xsl:variable name="errorCount" select="./ERROR_RECORD_COUNT"/>
        <xsl:variable name="ibpResultValue" select="concat('Status:', $batchStatus,if($batchStatus='ERROR') then (' Unprocessed:') else (' Count:'), $recordCount,if($errorCount!=0) then (concat(' Errors:',$errorCount)) else ())"/>
        <xsl:variable name="ibpResultName" select="concat('IBPResult_',./BATCH/text(),'_',./PACKET/text())"/>
*/
	    def body2 = message.getBody(java.io.Reader);
	    messageLog.addAttachmentAsString('IBPWriteBatchPackages', body2.text, 'text/xml');
	    
	   
	}
	return message;
    
}

def String mapAbapMessageTypeToString(String abapMessageType) {
    switch (abapMessageType) {
        case 'A': return 'Abort';
        case 'E': return 'Error';
        case 'W': return 'Warning';
        case 'I': return 'Information';
        case 'S': return 'Success';
        default: return abapMessageType;
    }
}

def Message setLogCustomHeaders(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    def headers = message.getHeaders();
	    String emailBody = headers.get('emailBody') + "\r\nLog custom headers:";
    	def logCustomHeaders = headers.get("LogCustomHeaders");
    	def logCustomProperties = headers.get("LogCustomProperties");
    	def logAttachmentHeaders = headers.get("LogAttachmentHeaders");
	    if(logCustomHeaders!=null) {
    	    logCustomHeaders.tokenize(',').each() {
    	        setLogCustomHeader(headers, messageLog, it);		
    	        emailBody += "\r\n\${it}: ${headers.get(it)}"
    	    }
	    }
	    if(logCustomProperties!=null) {
    	    logCustomProperties.tokenize(',').each() {
    	        setLogCustomProperty(message, messageLog, it);
    	        emailBody += "\r\n\${it}: ${message.getProperty(it)}"
    	    }
	    }
	    if(logAttachmentHeaders!=null) {
    	    logAttachmentHeaders.tokenize(',').each() {
    	        setLogAttachmentHeader(headers, messageLog, it);		
    	    }
	    }
	    
	}
	return message;
}

def void setLogCustomHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addCustomHeaderProperty(headerName, header.toString());		
    }
}

def void setLogCustomProperty(Message message, MessageLog messageLog, String propertyName) {
    
	def property = message.getProperty(propertyName);		
	if(property!=null){
		messageLog.addCustomHeaderProperty(propertyName, property.toString());		
    }
}

def void setLogAttachmentHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addAttachmentAsString(headerName, header.toString(), 'text/plain')	
    }
}
