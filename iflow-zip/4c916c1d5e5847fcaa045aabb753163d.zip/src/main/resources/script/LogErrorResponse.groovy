/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.HashMap;
import java.util.UUID; 
import java.util.Iterator; 
import java.util.List; 
import java.lang.Thread;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
	def body = message.getBody(java.lang.String);
    def camelSplitIndex = message.getProperty('CamelSplitIndex') ?:'';
    def requestBody = message.getProperty('IBPWriteRequestBody' + camelSplitIndex);
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null && requestBody != null){
		messageLog.addAttachmentAsString('Request Body', requestBody, "text/plain");
	};
	if(messageLog != null && body != null){
		messageLog.addAttachmentAsString('Response Body with Error', body, "text/plain");
	};
	message = setLogCustomHeaders(message);
	return message;
}

def String mapAbapMessageTypeToString(String abapMessageType) {
    switch (abapMessageType) {
        case 'A': return 'Abort';
        case 'E': return 'Error';
        case 'W': return 'Warning';
        case 'I': return 'Information';
        case 'S': return 'Success';
        default: return abapMessageType;
    }
}

def Message setLogCustomHeaders(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    def headers = message.getHeaders();
	    String emailBody = headers.get('emailBody') + "\r\nLog custom headers:";
    	def logCustomHeaders = headers.get("LogCustomHeaders");
    	def logCustomProperties = headers.get("LogCustomProperties");
    	def logAttachmentHeaders = headers.get("LogAttachmentHeaders");
	    if(logCustomHeaders!=null) {
    	    logCustomHeaders.tokenize(',').each() {
    	        setLogCustomHeader(headers, messageLog, it);		
    	        emailBody += "\r\n\${it}: ${headers.get(it)}"
    	    }
	    }
	    if(logCustomProperties!=null) {
    	    logCustomProperties.tokenize(',').each() {
    	        setLogCustomProperty(message, messageLog, it);
    	        emailBody += "\r\n\${it}: ${message.getProperty(it)}"
    	    }
	    }
	    if(logAttachmentHeaders!=null) {
    	    logAttachmentHeaders.tokenize(',').each() {
    	        setLogAttachmentHeader(headers, messageLog, it);		
    	    }
	    }
	    
	}
	return message;
}

def void setLogCustomHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addCustomHeaderProperty(headerName, header.toString());		
    }
}

def void setLogCustomProperty(Message message, MessageLog messageLog, String propertyName) {
    
	def property = message.getProperty(propertyName);		
	if(property!=null){
		messageLog.addCustomHeaderProperty(propertyName, property.toString());		
    }
}

def void setLogAttachmentHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addAttachmentAsString(headerName, header.toString(), 'text/plain')	
    }
}
