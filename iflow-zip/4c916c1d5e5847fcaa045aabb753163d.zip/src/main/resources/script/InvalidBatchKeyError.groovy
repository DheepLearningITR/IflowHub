import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	
	def messageLog = messageLogFactory.getMessageLog(message);
	
	throw new Exception("Could not find 'Id' and 'Destination' based on the 'BatchKey'. Please either provide the 'Id' and 'Destination' combination or a valid 'BatchKey'.");
	
	return message;
}
