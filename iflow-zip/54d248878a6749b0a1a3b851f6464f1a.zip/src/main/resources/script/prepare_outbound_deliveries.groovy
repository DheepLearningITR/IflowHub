import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.util.XmlParser
import groovy.xml.XmlUtil

def Message processData(Message message) {
    def xmlBody = message.getBody(java.io.Reader)
    def linkedDeliveriesString = message.getProperty("alreadyLinkedS4HanaCloudOutboundDeliveries") ?: "[]"
    def linkedDeliveries = new JsonSlurper().parseText(linkedDeliveriesString)

    def deliveries = new XmlParser().parse(xmlBody)

    def nodesToRemove = deliveries.'**'.findAll { node ->
        node.name() == 'A_OutbDeliveryItemType' && linkedDeliveries.contains(node.DeliveryDocument.text())
    }

    nodesToRemove.each { node ->
        node.parent().remove(node)
    }

    if (deliveries.value().size() > 0) {
        def newDeliveriesToLink = deliveries.collect { node -> node.DeliveryDocument.text() }
        message.setProperty("newDeliveriesToLink", JsonOutput.toJson(newDeliveriesToLink))
    }

    def filteredXmlString = XmlUtil.serialize(deliveries)
    message.setBody(filteredXmlString)

    return message
}