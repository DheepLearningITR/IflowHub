import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def orderString = message.getProperty("bigCommerce_response_body")
    def outboundDeliveriesString = message.getProperty("alreadyLinkedS4HanaCloudOutboundDeliveries") ?: "[]"
    def alreadyLinkedDeliveries = new JsonSlurper().parseText(outboundDeliveriesString)

    // if (orderString.startsWith("<?xml")) {
    //     orderString = orderString.substring(orderString.indexOf("?>") + 2).trim();
    // }

    def slurper = new XmlSlurper()
    def outboundDeliveryItemsXml = slurper.parse(body)
    def orderXml = slurper.parse(orderString)

    def expectedPayload = getOrderShippingPayload(orderXml, outboundDeliveryItemsXml, alreadyLinkedDeliveries)

    message.setProperty("has_shipping_items", (expectedPayload?.items?.size() ?: 0) > 0)
    message.setBody(JsonOutput.toJson(expectedPayload))
    return message
}

def getOrderShippingPayload(def orderXml, def outboundDeliveryItemsXml, def alreadyLinkedDeliveries) {
    def id = orderXml?.order?.consignments?.shipping?.shipping?.id?.text()
    def items = getOrderShippingItems(orderXml, outboundDeliveryItemsXml, alreadyLinkedDeliveries)
    return ["order_address_id": id, "tracking_number": "", "shipping_provider": "",
            "tracking_carrier": "", "items": items]
}

def getOrderShippingItems(def orderXml, def outboundDeliveryItemsXml, def alreadyLinkedDeliveries) {
    def itemsMap = new HashMap<String, Integer>()

    outboundDeliveryItemsXml?.A_OutbDeliveryItemType.forEach { deliveryItemType ->
        def deliveryDocument = deliveryItemType.DeliveryDocument.text()
        def material = deliveryItemType.Material?.text()
        def quantity = new BigDecimal(deliveryItemType.ActualDeliveryQuantity.text())?.intValueExact()
        def lineItems = orderXml.order.consignments.shipping.shipping.line_items.line_items

        def lineItemForMaterial = lineItems.find { lineItem -> lineItem.sku == material }
        def lineItemProductId = lineItemForMaterial?.id.text()

        if (material && quantity && deliveryDocument && lineItemProductId && !alreadyLinkedDeliveries.contains(deliveryDocument)) {

            itemsMap.putIfAbsent(lineItemProductId, 0)

            def newValue = itemsMap.get(lineItemProductId) + quantity
            itemsMap.put(lineItemProductId, newValue)
        }
    }

    def result = []
    itemsMap.forEach { key, quantity -> result << ["order_product_id": key, "quantity": quantity]
    }

    return result
}