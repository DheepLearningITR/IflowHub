import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def bigCommerceOrderQueryPage = message.getProperty("bigCommerce_orders_page")
    def body = message.getBody(String)

    if (!body) {
        message.setProperty("hasNextPage", false)
        message.setProperty("isEmptyResponse", true)
        return message
    }

    def xmlSlurper = new XmlSlurper()
    def xml = xmlSlurper.parseText(body)

    if (!xml.order) {
        message.setProperty("hasNextPage", false)
        message.setProperty("isEmptyResponse", true)
    } else {
        def nextPageNumber = bigCommerceOrderQueryPage.toInteger() + 1
        message.setProperty("bigCommerce_orders_page", nextPageNumber)
    }

    return message
}