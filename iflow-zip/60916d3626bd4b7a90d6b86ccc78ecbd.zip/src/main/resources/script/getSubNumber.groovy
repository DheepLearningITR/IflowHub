import com.sap.it.api.mapping.*;

def String extractSubNo(String subn){
    def value = subn.tokenize("-");
    def str = value[1].tokenize(" ");
    subn = str[0];
	return subn 
}