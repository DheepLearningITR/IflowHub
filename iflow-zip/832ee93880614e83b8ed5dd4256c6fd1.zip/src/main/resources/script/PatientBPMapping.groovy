import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def responseBody = message.getBody(String);
    def jsonSlurper = new JsonSlurper();
    def jsonResponse = jsonSlurper.parseText(responseBody);
    
    def businessPartnerID = jsonResponse.A_BusinessPartner.A_BusinessPartnerType.BusinessPartner;
    def patientPath = "Patient/" + message.getProperty("patientID");

    // Build S4Mapping.subject object for Patient
    def patientIdentifier = [
        system: message.getProperty("patientSystem"),
        use: message.getProperty("patientUse"),
        value: message.getProperty("patientValue")
    ];
    
    def patientSubject = [
        type: "Patient",
        identifier: patientIdentifier,
        reference: patientPath
    ];
    
    //Build S4Mapping.target object for Business Partner
    def businessPartnerTarget = [
        type: "BusinessPartner",
        identifier: [
            system: message.getProperty("TargetSystemHost"),
            value: businessPartnerID
        ]
    ];
    
    Object[] target = [ businessPartnerTarget ];
    
    // Build the S/4 mapping resource
    def s4Mapping = [
        resourceType: "S4Mapping",
        subject: patientSubject,
        target: target
    ];
    
    def s4MappingRequestPaylod = JsonOutput.toJson(s4Mapping);
    
    message.setBody(s4MappingRequestPaylod.toString());
    message.setHeader("Content-Type", "application/json");
    
    return message;
}