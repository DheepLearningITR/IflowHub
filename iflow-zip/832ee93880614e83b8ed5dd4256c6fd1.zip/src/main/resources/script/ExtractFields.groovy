import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message)
    
    def body = message.getBody(String)
    
    //Extract Patient GUID
    def startDelimiterPatientID = "Patient/";
    int lengthOfPatientID = 36;
    def startPosPatientID = body.indexOf(startDelimiterPatientID) + startDelimiterPatientID.length();
    def endPosPatientID = startPosPatientID + lengthOfPatientID;
    def patientID = body.substring(startPosPatientID, endPosPatientID);
    
    
    //Extract Patient Operation. eg. Patient-created
    def startDelimiterOperation = "Patient-";
    int lengthOfOperation = 7;
    def startPosOperation = body.indexOf(startDelimiterOperation) + startDelimiterOperation.length();
    def endPosOperation = startPosOperation + lengthOfOperation;
    def operation = body.substring(startPosOperation, endPosOperation);
    
    message.setProperty("patientID", patientID)
    message.setProperty("operation", operation)
    
    if (messageLog != null) {
        messageLog.setStringProperty("patientID", patientID)
        messageLog.setStringProperty("operation", operation)
    }
    

    return message;
}