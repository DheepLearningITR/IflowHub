
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.security.SecureRandom;

def Message processData(Message message) {

    final IDENTIFIER_USE_OFFICIAL = "official";
    
    def responseBody = message.getBody(String);
    def jsonSlurper = new JsonSlurper();
    def jsonResponse = jsonSlurper.parseText(responseBody);
    
    def secureRandom = new SecureRandom();
    
    def writer = new StringWriter();
    def xml = new groovy.xml.MarkupBuilder(writer);
    
    // BusinessPartner root entity set related fields
    def bpCategory = 1  // Category value 1 is for Business Partner individual.
    def bpGrouping = message.getProperty("BusinessPartnerGrouping");
    
    def language = "";
    def patientLangExists = false;
    Object[] communications = jsonResponse.communication;
    
    // Check if Paitent.communication is defined with a preferred language.
    if(communications) {
        patientLangExists = true;
        for(communication in communications) {
            if(communication.preferred) {
                language = communication.language.coding[0].code;
                break;
            }
        }
    }
    
    /**
     * This line has 3 parts:
     * 1. If there is no Paitent.communication.language defined then we default it to EN.
     * 2. If Paitent.communication.language exists with a preferred language then we pick that language. 
     * If there are multiple preferred languages then we pick only the first one in order.
     * 3. If Paitent.communication.language exists without a preferred language then we pick whichever language is first in order.
     */
    def bpLang = patientLangExists ? (language != "" ? language : communication[0].language) : "EN";
    
    def name = jsonResponse.name[0];
    def lastName = name.family.replaceAll("(?!^.{1})[^\\s]", "*"); // Masking of lastName
    def firstName = name.given[0].replaceAll("(?!^.{1})[^\\s]", "*"); // Masking of firstName
    
    // BusinessPartnerAddress entity set related fields
    def country = jsonResponse.address[0].country;
    def cityName = "";
    def city = jsonResponse.address[0].city;
    if(city) {
        cityName = city.replaceAll("(?!^.{1})[^\\s]", "*");  // Masking of city name
    }
    
    // BusinessPartnerRole entity set related fields
    def bpRole = "FLCU00";
    
    // Customer entity set related fields
    def customer = Math.abs( secureRandom.nextInt() % (99999999 - 22222222) ) + 22222222; //Random number for customer ID
    def accountGroup = "DEBI";

    xml.A_BusinessPartner {
      A_BusinessPartnerType {
        BusinessPartnerCategory(bpCategory)
        BusinessPartnerGrouping(bpGrouping)
        CorrespondenceLanguage(bpLang)
        FirstName(firstName)
        LastName(lastName)
        
        to_BusinessPartnerAddress {
          A_BusinessPartnerAddressType {
            Country(country)
            CityName(cityName)
            Language(bpLang)
          }
        }
        
        to_BusinessPartnerRole {
          A_BusinessPartnerRoleType {
            BusinessPartnerRole(bpRole)
          }
        }
        
        to_Customer {
          A_CustomerType {
            Customer(customer)
            CustomerAccountGroup(accountGroup)
          }
        }
      }
    }
    message.setBody(writer.toString());
    
    // Set properties for patient identifier where use is official
    for(identifier in jsonResponse.identifier) {
        if(identifier.use.equals(IDENTIFIER_USE_OFFICIAL)) {
            message.setProperty("patientSystem", identifier.system);
            message.setProperty("patientValue", identifier.value);
            message.setProperty("patientUse", identifier.use);
            break;
        }
    }
    
    return message;
}