import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody() ;
       def FileName = message.getProperty ("OT_Name");
       FileName = FileName.take(FileName.lastIndexOf('.'));
       lengthValue = body.getBytes().length;
       //Properties 
       message.setProperty("Totallength", lengthValue);
       message.setProperty("OT_Name", FileName);
       return message;
}