import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;



def Message processData(Message message) {
 def body = message.getBody(String.class);

 def parsedObj = new JsonSlurper().parseText(body);
 def contact_guid;
 if (!parsedObj.d.results.isEmpty()) {
  parsedObj.d.results.each {
   contact_guid = it.ObjectID.substring(0, 8) + "-" + it.ObjectID.substring(8, 12) + "-" + it.ObjectID.substring(12, 16) + "-" + it.ObjectID.substring(16, 20) + "-" + it.ObjectID.substring(20, 32);
   message.getProperties().put("c4cContactUUID", contact_guid)
  }
 } else {
  throw new Exception("Contact not present in C4C");
 }

 message.setBody(body);
 return message;
}