import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;



def Message processData(Message message){
def body = message.getBody(String.class);
body = "["+body+"]";
def parsedObj = new JsonSlurper().parseText(body);
parsedObj.each{
message.getProperties().put("event",it.eventType);
}
parsedObj.data.each{
    message.getProperties().put("messageId",it.contact.id);
}
return message
}
