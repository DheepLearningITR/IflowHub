import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;



def Message processData(Message message) {
    def body = message.getBody(String.class);
    sleep(40000)
	message.setBody(body);
    return message;
}