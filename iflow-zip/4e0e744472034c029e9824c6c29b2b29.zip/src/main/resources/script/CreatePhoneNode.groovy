/*
 * @Author: Chintan Raiyani 
 * @Date: 2019-11-26 15:17:46 
 * @Last Modified by: Chintan Raiyani
 * @Last Modified time: 2019-11-26 20:20:47
 */

import com.sap.gateway.ip.core.customdev.util.Message;

/*
*Creates contactno nodes under phone nodes

Params:
------
    message(com.sap.gateway.ip.core.customdev.util.Message):
        input message
Returns:
--------
    message(com.sap.gateway.ip.core.customdev.util.Message):
        output message
*/
def Message processData(Message message) {
     
    try{
        def body = message.getBody(java.lang.String) as String;
        def response = new XmlParser().parseText(body)
        //find phoneno and create hierarchy
        response.fsm_body.data.contact.each{
            contact->
            //create phone node
            def phone = new Node(contact,'phone')
            
            //attach mobileno child to phone
            try{
                def phoneno = contact.'**'.find { it.name() == 'mobilePhone' }
                def numberNode = new Node(phone,'number',[type:'mobile', code:'AD_MBDEFAU', value:phoneno.text()])

                // phoneno.parent().remove(phoneno)
            }catch(Exception e){}
            
            //attach officeno child to phone
            try{
                phoneno = contact.'**'.find { it.name() == 'officePhone' }
                numberNode = new Node(phone,'number',[type:'office', code:'AD_DEFAULT', value:phoneno.text()])
                // phoneno.parent().remove(phoneno)
            }catch(Exception e){}
            
            //attach otherno child to phone
            // try{
            //     phoneno = contact.'**'.find { it.name() == 'otherPhone' }
            //     new Node(phone,'number',[type:'other',code:'',value:phoneno.text()])
            //     phoneno.parent().remove(phoneno)
            // }catch(Exception e){}
        }
        
        // convert to string and setbody
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(response)
        message.setBody(stringWriter.toString())
        
    }catch(Exception ex){
        //send input body in case of error
        throw Exception(ex)
    }
    return message;
       
}
