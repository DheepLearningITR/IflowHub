import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;



def Message processData(Message message) {
    def body = message.getBody(String.class);
    body = "[" + body + "]";
    def parsedObj = new JsonSlurper().parseText(body);
    def contact_externalId = parsedObj.data.contact.externalId[0];
    if (contact_externalId == null) {
        throw new Exception("Contact not replicated");
    }
    def contactId_accountId = contact_externalId.split('~ID-JOIN~');
 
    message.getProperties().put("contactId",contactId_accountId[0]);
    message.getProperties().put("existing_accountId",contactId_accountId[1]);
    return message;
}