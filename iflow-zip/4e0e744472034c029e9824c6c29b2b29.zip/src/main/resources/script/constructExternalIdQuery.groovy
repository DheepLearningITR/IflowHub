/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {
    //Get Body and parse it.
       def body = message.getBody(String.class);
       def parsedObj = new JsonSlurper().parseText(body);
       String query = "{\"query\": \"SELECT ct.externalId from Contact ct WHERE ct.externalId IN (";
       String s = '\'';
       String e = '\',';
       String eend = '\')\"}';
       String whereIn;
        if(!parsedObj.d.results.isEmpty()){
     parsedObj.d.results.each{
          if (whereIn == null)
          {
              whereIn = s + it.SecondBusinessPartnerID+"~ID-JOIN~"+it.FirstBusinessPartnerID + eend;
          }
          else
          {
              whereIn = s + it.SecondBusinessPartnerID+"~ID-JOIN~"+it.FirstBusinessPartnerID + e + whereIn;
          }
          };
    //Set final query statement which has to be send as payload of the query API request     
       query = query + whereIn;
    // Temporarily store inbound payload as property   
       message.setProperty("InPayload",body);
    // Set the query in the message body   
       message.setBody(query);
       message.setProperty("RelationshipExists","true")
        }else{
            message.setProperty("RelationshipExists","false")
        }
       return message;
}
