import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {
    //Get Body and parse it.
       def body = message.getBody(String.class);
       def parsedObj = new JsonSlurper().parseText(body);
        if(parsedObj.d.results.isEmpty()){
       message.setProperty("empty","true")
        }else{
            message.setProperty("empty","false")
        }
       return message;
}