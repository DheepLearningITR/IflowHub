import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;



def Message processData(Message message) {
    def body = message.getBody(String.class);
    def map = message.getProperties();
	String externalIds_contact = map.get("queryResults");
	
	def parsedObj_contact_externalIds = new JsonSlurper().parseText(externalIds_contact);
	def parsedObj=[];
	def itr=0;
	parsedObj_contact_externalIds.data.each{
	parsedObj[itr] = new JsonSlurper().parseText(body)[0];
	parsedObj[itr].externalId = it.ct.externalId;
    itr = itr + 1;
}
	JsonBuilder builder = new JsonBuilder(parsedObj);
	String jsonBody = JsonOutput.prettyPrint(builder.toString());
	message.setBody(jsonBody);
    return message;
}