import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;



def Message processData(Message message) {
    def body = message.getBody(String.class);
    body = "[" + body + "]";
    def parsedObj = new JsonSlurper().parseText(body);
    def contact_externalId = parsedObj.data.contact.externalId[0];
    if (contact_externalId == null) {
        throw new Exception("Contact not replicated");
    }
    def account_externalId = parsedObj.data.contact.object.objectId.externalId[0];
    if (account_externalId == null) {
        throw new Exception(" Account not replicated");
    }
    def contactId_accountId = contact_externalId.split('~ID-JOIN~');
    if (account_externalId == contactId_accountId[1]) {
        message.getProperties().put("Update", "Contact")
    } else {
        message.getProperties().put("Update", "Relationship")
    }
    message.getProperties().put("contactId",contactId_accountId[0]);
    message.getProperties().put("existing_accountId",contactId_accountId[1]);
    message.getProperties().put("accountId",account_externalId);
    return message;
}