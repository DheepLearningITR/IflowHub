import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;



def Message processData(Message message) {
    def body = message.getBody(String.class);
    def parsedObj = new JsonSlurper().parseText(body);
	def map = message.getProperties();
	def ContactID = map.get('contactId');
	message.getProperties().put("dummy",ContactID);
	def itr = 0
	if(!parsedObj.d.results.isEmpty()){
    parsedObj.d.results.each{
        parsedObj.d.results.find{
        if(it.LocalObjectID == ContactID){
            message.getProperties().put("ObjectIdFound","true")
            message.getProperties().put("RemoteObjectId",it.RemoteObjectID)
            return true;
        }else{
            message.getProperties().put("ObjectIdFound","false")
            message.getProperties().put("RemoteObjectId","RemoteObjectID")
            return false
        }
    }
}
}else{
	message.getProperties().put("ObjectIdFound","nf")
}
    return message;
}