import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

// process message
def Message processData(Message message) { 
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)
    message.setProperty("ValidData",'true')

    // Replace null values with empty strings and remove empty arrays
    replaceNullsAndRemoveEmptyArrays(jsonResult)

    jsonResult.remove("objectId")
    jsonResult.remove("objectType")
    jsonResult.data?.checklistInstance?.remove("lastChanged")
    jsonResult.data?.checklistInstance?.remove("owners")
    jsonResult.data?.checklistInstance?.remove("syncObjectKPIs")
    jsonResult.data?.checklistInstance?.remove("groups")
    jsonResult.data?.checklistInstance?.remove("branches")
    jsonResult.data?.checklistInstance?.remove("udfValues")

    //set OData url prefix path to UpdateMaintenanceOrder
    if ((jsonResult.eventType == 'checklistinstance.deleted' && !jsonResult.data?.checklistInstance?.externalId) || !jsonResult.data?.checklistInstance?.id || (jsonResult.eventType == 'checklistinstance.deleted' && !jsonResult.data?.checklistInstance?.externalId)){
        message.setProperty("ValidData",'false')
    }
    jsonResult.data?.checklistInstance?.template?.remove("externalId")
    message.setProperty("InstanceID",jsonResult.data?.checklistInstance?.id)
    message.setHeader("SAP_ApplicationID",jsonResult.data?.checklistInstance?.id)

    def updatedJsonString = JsonOutput.toJson(jsonResult)
    message.setProperty("S4HRequestPayload",JsonOutput.prettyPrint(updatedJsonString))
    message.setBody(JsonOutput.prettyPrint(updatedJsonString))
    
    
    def messageLog = messageLogFactory.getMessageLog(message)
    if(jsonResult.data?.checklistInstance?.template?.id)
        messageLog.addCustomHeaderProperty("FSMTemplateID", jsonResult.data?.checklistInstance?.template?.id)
    if(jsonResult.data?.checklistInstance?.id)    
        messageLog.addCustomHeaderProperty("FSMInstanceID", jsonResult.data?.checklistInstance?.id)
    if(jsonResult.data?.checklistInstance?.externalId)    
        messageLog.addCustomHeaderProperty("S4InstanceID", jsonResult.data?.checklistInstance?.externalId)

    return message
}

// Recursive function to replace all null values with empty strings and remove empty arrays
def replaceNullsAndRemoveEmptyArrays(obj) {
    if (obj instanceof Map) {
        def keysToRemove = [] // List to track empty arrays
        obj.each { key, value ->
            if (value == null || value == 'null' || value == '') {
                //obj[key] = ""
                keysToRemove.add(key) // Mark empty array for removal
            } else if (value instanceof List && value.isEmpty()) {
                keysToRemove.add(key) // Mark empty array for removal
            } else {
                replaceNullsAndRemoveEmptyArrays(value)
            }
        }
        // Remove the keys after iteration
        keysToRemove.each { key ->
            //obj.remove(key)
            obj.remove(key)
        }
    } else if (obj instanceof List) {
        def itemsToRemove = [] // List to track null and empty arrays
        obj.each { item ->
            if (item == null || item == 'null' || item == '' || (item instanceof List && item.isEmpty())) {
                itemsToRemove.add(item) // Mark for removal
            } else {
                replaceNullsAndRemoveEmptyArrays(item)
            }
        }
        // Remove the items after iteration
        itemsToRemove.each { item ->
            obj.remove(item)
        }
    }
}
