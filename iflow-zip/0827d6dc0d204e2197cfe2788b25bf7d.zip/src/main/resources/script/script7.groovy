
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper

def Message processData(Message message) {
    //Body 
       // def body = message.getBody();
        def body = message.getBody(java.lang.String);

        
        def jsonSlurper = new JsonSlurper()
        cfg = jsonSlurper.parseText(body)

       if(cfg['totalCount'] == 1){
           def map = message.getProperties();
           def value = map.get("searchCounter");
           def newcounter = value.toInteger() +2;
           message.setProperty("searchCounter", newcounter);
       }else{
            def map = message.getProperties();
            def value = map.get("dalayCounter");
            sleep( Long.valueOf(value))
       }    
       
   return message;
}
