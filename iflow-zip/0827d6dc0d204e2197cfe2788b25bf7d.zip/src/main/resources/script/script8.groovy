import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
        
        // def body = message.getBody(java.lang.String);
        
        // def jsonSlurper = new XmlSlurper()
        // def bupaResponse = jsonSlurper.parseText(body);
        
        def mdmPayload = message.getBody(java.lang.String);
        def bupaResponse = new JsonSlurper().parseText(mdmPayload);
        def resultCount = bupaResponse.d.results.size();

        
        if(!bupaResponse.d.results.isEmpty() && resultCount == 1){
            
            message.setProperty("mdmUUID",bupaResponse.d.results[0].Id);
            /*message.setProperty("mdmInternalID",bupaResponse.d.results[0].BusinessPartner);
            message.setProperty("mdmIAMId",bupaResponse.d.results[0].IAMId);*/
            
            // Properties 
            map = message.getProperties();
            
            String mdmIAMId = bupaResponse.d.results[0].IAMId;
            String CDCIAMId = map.get("CDCAccountUid");
            
            if(mdmIAMId && !CDCIAMId.equals(mdmIAMId)){
                throw new Exception("IAM ID mismatch. Replication not possible.");
            }
        }
        else if(resultCount > 1){
            throw new Exception("More than one record found in MDM. Replication not possible.");
        }
    
       return message;
}