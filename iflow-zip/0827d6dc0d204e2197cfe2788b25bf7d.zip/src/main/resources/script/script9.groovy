import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper;
import java.io.StringWriter;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.OutputKeys;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.Gson;
import groovy.json.JsonSlurper;


def Message processData(Message message) {
    
    //Properties 
       map = message.getProperties();
      
       def cdcData = new XmlSlurper().parseText(map.get("cdcPayload").toString());

       def isRecordModified = false;
       def isPhoneModified = false;
       def profileData = new JsonObject();
       def phoneArray = new JsonArray();
       def CDCphoneArray = new JsonArray();
       
       def mdmPayload = message.getBody(java.lang.String);
       def bupaResponse = new JsonSlurper().parseText(mdmPayload);
        
       def messageLog = messageLogFactory.getMessageLog(message);    

       def resultCount = bupaResponse.d.results.size();

        if(bupaResponse.d.results.isEmpty()){
            // return if create senario
            // zero results means email doesn't exist in mdm hence it is a create senario
            
           message.setProperty("isRecordModified", true);
           return message;
        }
        else if(resultCount > 1){
		    throw new Exception("More than one record found in MDM. Update is not possible.");
        }

        def mdmData = bupaResponse.d.results[0];

        def to_Person = mdmData.to_Person.results[0];
        
        def VerifyRecord = { CDCAttribute, MDMAttribute, req_attrib ->

            // Set profile data only if the data is modified
            if((CDCAttribute.equals(MDMAttribute) ? false : true)){
                profileData.addProperty(req_attrib, CDCAttribute.toString()+" = "+MDMAttribute.toString());
                // Log the modified status
                if(!isRecordModified){
                    isRecordModified = true;
                }
            }
        }

        // First name
        VerifyRecord(cdcData.profile.firstName,to_Person.FirstName,"firstName");
       
        // Last name
        VerifyRecord(cdcData.profile.lastName,to_Person.LastName,"lastName");
      
        // Set Modified Status in a property
        message.setProperty("isRecordModified",isRecordModified );
        
        if(messageLog != null && map.get("enableLog") == "true" ) {

            messageLog.addAttachmentAsString("Modified data", "\n Modified data \n ----------   \n" + profileData.toString(), "text/json");
        
        }
        
        // to handle in exception
        if(!isRecordModified){
                message.setBody("No modified records found"+ profileData.toString());
        }
      
        return message;
}


