import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //sleep(10000);
    map = message.getProperties();
    def mdmAccessToken = map.get("mdmAccessToken");
   
    message.setHeader("Authorization", "Bearer "+mdmAccessToken.toString());
    message.setHeader("Content-Type","text/xml");
    return message;
}