import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.*;

def Message processData(Message message) {
      def body = message.getBody();
      def valid_data=XmlUtil.serialize(body.toString())
      message.setProperty("cdcPayload", valid_data);
      return message;
}