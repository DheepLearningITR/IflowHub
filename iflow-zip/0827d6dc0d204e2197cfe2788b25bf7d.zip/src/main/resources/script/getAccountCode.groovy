import com.sap.it.api.mapping.*;
import java.util.UUID; 
import java.util.Arrays;
import java.util.Set;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;

// Script to get number range group code of business partner
def String getAccountCode(String arg1, MappingContext context){
    
    def accType = context.getProperty("accountType");
	if(accType == 'full'){
		return context.getProperty("customerRole")
	}
	else if(accType == 'lite'){
		return context.getProperty("prospectRole")
	}
	
}