import com.sap.it.api.mapping.*;


def String getIAMID(String arg1){
    
    // Compiled regex for UUID
    //def p = ~"(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})"
    //String getIAMID = p.matcher(arg1).replaceAll("\$1-\$2-\$3-\$4-\$5");

	return arg1.replaceAll("-","") 
}