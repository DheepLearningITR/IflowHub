import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    body_str = "";
                    
    // Header
    message.setHeader("Content-Type", "application/x-www-form-urlencoded");
    
    
    //Properties 
    map = message.getProperties();
    
    def accType = map.get("accountType")
    
    //Body 
    body_str = "apiKey=" + URLEncoder.encode(map.get("apiKey"), "UTF-8");
    
    if(accType == 'full'){
        body_str += "&UID=" + URLEncoder.encode(map.get("CDCAccountUid"), "UTF-8");
        body_str += "&include=" + URLEncoder.encode(map.get("include"), "UTF-8");
        body_str += "&extraProfileFields=" + URLEncoder.encode("phones", "UTF-8");    
    }
    else if(accType == 'lite'){
        body_str += "&query=" + URLEncoder.encode("SELECT * FROM accounts WHERE UID='"+map.get("CDCAccountUid")+"'", "UTF-8");
        body_str += "&accountTypes=" + URLEncoder.encode("lite", "UTF-8");    
    }
    

    
    message.setBody(body_str);
       
    return message;
}


