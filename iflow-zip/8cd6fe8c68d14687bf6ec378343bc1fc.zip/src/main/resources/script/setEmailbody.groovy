/*
 * =============================================================================
 * Logic Details 
 * =============================================================================
 * This script helps to build the email body by using the available property in a tabular format 
 * ==============================================================================
*/

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {    
    def map = message.getProperties();                             
    def mailBody = map.get("body");
    def msgID = map.get("SAP_MessageProcessingLogID");
    def iflowName = map.get("iflowName");
    def packageName = map.get("PackageName");
    def today = new Date();
    def todayDate = today.format("dd-MM-yyyy", TimeZone.getTimeZone('CET'))
    def todayTime = today.format("HH:mm:ss", TimeZone.getTimeZone('CET'))
    def subject = "";
    def MSDObject = map.get("MSDObject");
    def ErrorType = map.get("ErrorType")    

    String systemName = System.getenv("TENANT_NAME")
    String url = System.getenv("TENANT_NAME") + "." + System.getenv("IT_SYSTEM_ID") + "." + System.getenv("IT_TENANT_UX_DOMAIN")

    def msgIDLink = "https://" + url + ":443/itspaces/shell/monitoring/MessageDetails/%7B%22messageGuid%22%3A%22" + msgID + "%22%7D";
    
    def ex = map.get("CamelExceptionCaught");
    
    if (ex != null) {
        subject = "Error - " + iflowName;
        def exceptionName = "";
        def exceptionMessage = "";
        def exceptionResponseBody = "";

        exceptionName = ex.getClass().getName();
        exceptionMessage = ex.getMessage();
        
        if (ErrorType == "SignavioAPIError") {
            // Check if ex has the method getResponseBody
            if (ex.metaClass.respondsTo(ex, "getResponseBody")) {
                exceptionResponseBody = ex.getResponseBody();
            } else {
                exceptionResponseBody = "Unable to retrieve response body. Exception type: " + ex.getClass().getName();
            }
        }

        mailBody = "<html><head><style>table, th, td {" +
                   "border: 1px solid black;" +
                   "}</style></head><body><p>Hello Team,</p><p>We regret to inform you that an exception has been raised in the integration process while processing the <b>" + MSDObject + "</b> entity. Please find detailed information below:</p>" +
                   "<table><tr><th colspan='2'><b><center>" + iflowName + "</center></b></th></tr>" +
                   "<tr><td><b>CPI System ID</b></td><td>" + systemName + "</td></tr>" +
                   "<tr><td><b>Package Details</b></td><td>" + packageName + "</td></tr>" +
                   "<tr><td><b>Date of Run </b></td><td>" + todayDate + " <b>CET</b></td></tr>" +
                   "<tr><td><b>Time of Run </b></td><td>" + todayTime + " <b>CET</b></td></tr>" +
                   "<tr><td><b>Salesforce Entity </b></td><td>" + MSDObject + "</td></tr>" +
                   "<tr><td><b>Message ID  </b></td><td><a href='" + msgIDLink + "'>" + msgID + "</a></td></tr>" +
                   "<tr><th colspan='2'><b><center>Exception Details</center></b></th></tr>" +
                   "<tr><td><b> Exception Name </b></td><td>" + exceptionName + "</td></tr>" +
                   "<tr><td><b> Exception Message </b></td><td>" + exceptionMessage + "</td></tr>" +
                   "<tr><td><b> HTTP Response Message </b></td><td>" + exceptionResponseBody + "</td></tr></table>" +
                   "<br/><p>Thanks and Regards<br/>" + systemName + " CPI System</p>" +
                   "</body></html>";
    }

    message.setProperty("body", mailBody);
    message.setProperty("mailSubject", subject);              
    return message;
}