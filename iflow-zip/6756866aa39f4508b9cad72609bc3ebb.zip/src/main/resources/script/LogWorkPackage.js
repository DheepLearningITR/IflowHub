importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var projectId = String(message.getProperty('projectID'));
  var logBody = message.getProperty('LogMessageBody');
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('WorkPackage:' + projectId, body, 'text/json');
  }
  return message;
}