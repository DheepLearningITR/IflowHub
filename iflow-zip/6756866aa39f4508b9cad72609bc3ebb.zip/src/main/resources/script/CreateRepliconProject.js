importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
importClass(com.sap.it.api.ITApiFactory);
importClass(com.sap.it.api.mapping.ValueMappingApi);

function processData(message) {
  var body = String(message.getProperty('projectJSON'));
  var project = JSON.parse(body);
  project = project.Project;

  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');

  var projectName = project.ProjectName;
  var projectCode = project.ProjectID;
  var clientCode = project.Customer;
  var startDate = project.StartDate;
  var endDate = project.EndDate;

  var stage = project.StageDesc;
  var projectStatus = String(getRepliconStatus(stage));
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ProjectStatus', projectStatus, 'text/json');
  }

  if (!projectStatus || projectStatus === 'null') {
    projectStatus = 'In Progress';
  }

  message.setProperty('CostCenterId', project.CostCenter);
  message.setProperty('ServiceCenterId', project.OrgID);

  var tenant = String(message.getProperty('tenant'));
  var value = String(message.getProperty('ExistingProject'));
  var controllingAreaOefName = String(message.getProperty('ProjectControllingAreaOEFName'));
  var controllingArea = String(message.getProperty('controllingArea'));
  var billingRates = String(message.getProperty('ProjectBillingRates'));
  var projectManagerUri = String(message.getProperty('ProjectManagerUri'));
  var resourcesToAdd = JSON.parse(String(message.getProperty('ResourcesToAdd')));
  var token = message.getProperty('RepliconToken');
  message.setHeader('Authorization', token);
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ProjectBilling:', billingRates, 'text/json');
  }
  var projectJson = getProjectJson(billingRates, startDate, endDate, controllingAreaOefName, controllingArea, value, projectCode, clientCode, projectName, projectStatus, tenant, projectManagerUri, resourcesToAdd);
  message.setHeader('Content-Type', 'application/json');
  message.setBody(JSON.stringify(projectJson));

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ProjectJson', JSON.stringify(projectJson, undefined, 4), 'text/json');
  }
  return message;
}

function getProjectJson(billingRates, startDate, endDate, controllingAreaOefName, controllingArea, value, projectCode, clientCode, projectName, projectStatus, tenant, projectManagerUri, resources) {
  var billingRatesToApply = getBillingRatesToApply(billingRates);

  var keyValuesToApply = [];
  var billingType = {
    value: 'urn:replicon:billing-type:time-and-material'
  };

  var target = null;
  var clientToApply = null;
  var startDateToApply = getRepliconDateObject(getDateValue(startDate));
  var endDateToApply = getRepliconDateObject(getDateValue(endDate));
  var oefsToApply = getOEFJson(controllingAreaOefName, controllingArea);
  var projectLeaderToApply = null;
  var resourcesToAdd = getResourcesToAdd(resources);
  if (value === 'true') {
    target = {
      code: projectCode
    };
  }

  if (projectManagerUri !== null && projectManagerUri !== '') {
    projectLeaderToApply = {
      user: {
        uri: projectManagerUri
      }
    };
  }


  clientToApply = getClientJson(clientCode, clientToApply);
  var projectJson = {
    target: target,
    modifications: {
      nameToApply: {
        value: projectName
      },
      codeToApply: {
        value: projectCode
      },
      descriptionToApply: {
        value: ''
      },
      percentCompletedToApply: '0',
      startDateToApply: startDateToApply,
      endDateToApply: endDateToApply,
      billingTypeToApply: billingType,
      clientBillingAllocationMethodToApply: 'urn:replicon:client-billing-allocation-method:split',
      clientAssignmentsSchedulesToApply: clientToApply,
      statusToApply: {
        name: projectStatus
      },
      projectLeaderToApply: projectLeaderToApply,
      isProjectLeaderApprovalRequired: 'false',
      isTimeEntryAllowed: 'false',
      defaultBillingCurrencyToApply: {
        currency: {
          name: 'US Dollar'
        }
      },
      timeAndMaterials: {
        billingRateFrequency: {
          name: 'Hourly'
        },
        billingRates: billingRatesToApply
      },
      billingContractToApply: {
        name: 'Default Contract'
      },
      customFieldsToApply: [],
      resourceAssignmentModifications: {
        resourcesToAdd: resourcesToAdd,
        resourcesToRemove: []
      },
      keyValuesToApply: keyValuesToApply,
      objectExtensionFieldsToApply: oefsToApply
    },
    projectModificationOptionUri: 'urn:replicon:project-modification-option:save',
    unitOfWorkId: makeid(6)
  };
  return projectJson;
}

function getResourcesToAdd(userResources) {
  var users = [];
  if (userResources && userResources.length > 0) {
    for (var i = 0; i < userResources.length; i++) {
      var json = {
        user: {
          uri: userResources[i].uri
        }
      };
      users.push(json);
    }
  }
  return users;
}

function getClientJson(clientCode, clientToApply) {
  if (clientCode) {
    clientToApply = {
      clients: [
        {
          client: {
            code: clientCode
          },
          costAllocationPercentage: '100'
        }
      ]
    };
  }
  return clientToApply;
}

function getOEFJson(controllingAreaOefName, controllingArea) {
  var oefsToApply = [];
  var applyOefs = true;
  if (applyOefs) {
    oefsToApply = [
      {
        definition: {
          name: controllingAreaOefName
        },
        textValue: controllingArea
      }
    ];
  }
  return oefsToApply;
}

function getRepliconStatus(stageName) {
  var valueMapApi = ITApiFactory.getApi(ValueMappingApi, null);
  var value = valueMapApi.getMappedValue('S4Hana', 'Project Status', stageName, 'Replicon', 'Project Status');
  return value;
}

function getBillingRatesToApply(billingRates) {
  billingRates = JSON.parse(billingRates);
  if (billingRates && billingRates && billingRates.length > 0) {
    var rates = [];
    for (var i = 0; i < billingRates.length; i++) {
      rates.push(
        {
          billingRate: {
            uri: billingRates[i].uri
          }
        }
      );
    }
    return rates;
  }
  return [];
}

function getRepliconDateObject(dateValue) {
  var repliconDate = {
    date: {
      year: dateValue.getFullYear(),
      month: dateValue.getMonth() + 1,
      day: dateValue.getDate()
    }
  };
  return repliconDate;
}

function getDateValue(dateVariable) {
  var regex = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/;
  var dateArray = regex.exec(dateVariable);
  var syncDate = new Date(
    (Number(dateArray[1])),
    (Number(dateArray[2])) - 1,
    (Number(dateArray[3])),
    (Number(dateArray[4])),
    (Number(dateArray[5])),
    (Number(dateArray[6]))
  );
  return syncDate;
}


function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}