importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var costCenterListData = getCostCenterListData();
  costCenterListData = JSON.stringify(costCenterListData);
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogCostCenterJson');
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('costCenterListData request ', costCenterListData, 'text/json');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(costCenterListData);
  return message;
}

function getCostCenterListData() {
  return {
    page: 1,
    pagesize: 1000,
    columnUris: [ 'urn:replicon:cost-center-list-column:cost-center', 'urn:replicon:cost-center-list-column:name', 'urn:replicon:cost-center-list-column:code' ]
  };
}
