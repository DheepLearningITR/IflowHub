importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Project Role:', body, 'text/json');
  }
  body = JSON.parse(body);
  if (body.ProjectRole.BusinessPartnerID) {
    message.setProperty('BusinessPartnerID', body.ProjectRole.BusinessPartnerID);
  }
  return message;
}