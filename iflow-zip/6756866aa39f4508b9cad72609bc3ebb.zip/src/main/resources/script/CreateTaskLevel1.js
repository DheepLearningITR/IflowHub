importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  //body
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);

  var logBody = message.getProperty('LogMessageBody');
  var projectCode = String(message.getProperty('projectID'));
  var repliconTask = message.getProperty('RepliconTask');
  var resourcesToAdd = JSON.parse(String(message.getProperty('ResourcesToAdd')));
  var planSet = JSON.parse(String(message.getProperty('PlanSetJson')));

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('TasksFromHana:', body, 'text/json');
  }

  body = JSON.parse(body);

  var taskName = body.Workpackage.WorkPackageName;
  var taskCode = body.Workpackage.WorkPackageID;
  var taskStartDate = body.Workpackage.WPStartDate;
  var taskEndDate = body.Workpackage.WPEndDate;
  var isTimeEntryAllowed = true;

  if (body.Workpackage.WorkItemSet && body.Workpackage.WorkItemSet.WorkItem) {
    isTimeEntryAllowed = false;
  }


  taskStartDate = getRepliconDateObject(getDateValue(taskStartDate));
  taskEndDate = getRepliconDateObject(getDateValue(taskEndDate));

  message.setProperty('rootTaskName', taskName);
  message.setProperty('rootTaskCode', taskCode);
  message.setProperty('rootTaskStartDate', JSON.stringify(taskStartDate));
  message.setProperty('rootTaskEndDate', JSON.stringify(taskEndDate));

  var token = message.getProperty('RepliconToken');
  var applicationName = message.getProperty('ApplicationName');


  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setHeader('Content-Type', 'application/json');

  var taskJson = getTaskJson(projectCode, taskName, taskCode, taskStartDate, taskEndDate, repliconTask, isTimeEntryAllowed, resourcesToAdd, planSet);

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Task' + taskName + 'json', JSON.stringify(taskJson, undefined, 4), 'text/json');
  }

  message.setBody(JSON.stringify(taskJson));

  return message;
}

function getTaskJson(projectCode, taskName, taskCode, taskStartDate, taskEndDate, repliconTasks, isTimeEntryAllowed, resourcesToAdd, planSet) {
  var taskTarget = getTaskTarget(taskCode, repliconTasks, projectCode);
  var taskResources = getTaskResources(taskCode, resourcesToAdd, planSet);
  return {
    project: {
      uri: null,
      name: null,
      code: projectCode,
      parameterCorrelationId: null
    },
    taskHierarchy: [
      {
        target: taskTarget,
        parameterCorrelationId: null,
        taskModificationToApply: {
          name: taskName,
          codeToApply: { value: taskCode },
          descriptionToApply: null,
          isClosed: false,
          timeEntryStartDateToApply: {
            date: taskStartDate
          },
          timeEntryEndDateToApply: { date: taskEndDate },
          timeAndExpenseEntryTypeToApply: {
            value: 'urn:replicon:time-and-expense-entry-type:billable-and-non-billable'
          },
          isTimeEntryAllowed: isTimeEntryAllowed,
          costTypeToApply: null,
          estimatedHoursToApply: null,
          estimatedCostToApply: null,
          resourceAssignmentModifications: {
            resourcesToAdd: taskResources,
            resourcesToRemove: []
          },
          customFieldsToApply: [],
          keyValuesToApply: [],
          objectExtensionFieldsToApply: []
        }
      }
    ],
    taskModificationOptionUri: 'urn:replicon:task-modification-option:save',
    unitOfWorkId: makeid(6)
  };
}

function getTaskResources(taskCode, resourcesToAdd, planSet) {
  var resources = [];
  var planData = [];
  if (planSet && planSet.PlanDataSet && planSet.PlanDataSet.PlanData) {
    if (planSet.PlanDataSet.PlanData.length > 0) {
      planData = planSet.PlanDataSet.PlanData;
    } else {
      planData = [ planSet.PlanDataSet.PlanData ];
    }
  }
  if (resourcesToAdd) {
    for (var index = 0; index < planData.length; index++) {
      var planDataItem = planData[index];
      if (planDataItem && (planDataItem.WorkPackageID === taskCode)) {
        for (var j = 0; j < resourcesToAdd.length; j++) {
          if (planDataItem.Employee === resourcesToAdd[j].Employee) {
            resources.push({
              user: {
                uri: resourcesToAdd[j].uri,
                loginName: null,
                parameterCorrelationId: null
              },
              department: null,
              placeholder: null,
              location: null,
              division: null,
              costCenter: null,
              serviceCenter: null,
              employeeType: null,
              departmentGroup: null
            }
            );
          }
        }
      }
    }
  }
  return resources;
}

function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

function getRepliconDateObject(dateValue) {
  var repliconDate = {
    year: dateValue.getFullYear(),
    month: dateValue.getMonth() + 1,
    day: dateValue.getDate()
  };
  return repliconDate;
}

function getDateValue(dateVariable) {
  var regex = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/;
  var dateArray = regex.exec(dateVariable);
  var syncDate = new Date(
    (Number(dateArray[1])),
    (Number(dateArray[2])) - 1,
    (Number(dateArray[3])),
    (Number(dateArray[4])),
    (Number(dateArray[5])),
    (Number(dateArray[6]))
  );
  return syncDate;
}

function getTaskTarget(taskCode, repliconTasks, projectCode) {
  var target = null;
  repliconTasks = JSON.parse(repliconTasks);
  if (repliconTasks && repliconTasks.d && repliconTasks.d.length > 0) {
    for (var index = 0; index < repliconTasks.d.length; index++) {
      if (repliconTasks.d[index].task && repliconTasks.d[index].task.code === taskCode) {
        target = {
          uri: null,
          name: repliconTasks.d[index].task.name,
          parent: null,
          project: {
            uri: null,
            name: null,
            code: projectCode,
            parameterCorrelationId: null
          },
          parameterCorrelationId: null
        };
      }
    }
  }
  return target;
}