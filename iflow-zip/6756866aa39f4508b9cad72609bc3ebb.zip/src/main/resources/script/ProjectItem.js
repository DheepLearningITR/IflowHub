
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  message.setProperty('projectJSON', body);

  var token = message.getProperty('RepliconToken');
  var applicationName = message.getProperty('ApplicationName');
  var logBody = message.getProperty('LogMessageBody');

  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setHeader('Content-Type', 'application/json');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ProjectItemJSON:', body, 'text/json');
  }
  var project = JSON.parse(body);
  project = project.Project;
  var projectName = project.ProjectName;
  var projectId = project.ProjectID;
  var modifiedOn = project.ChangedOn;
  var costCenter = project.CostCenter;

  message.setProperty('projectName', projectName);
  message.setProperty('projectID', projectId);
  message.setProperty('costCenter', costCenter);
  message.setProperty('ProjectBillingRates', JSON.stringify([]));

  var lastSyncDateLocal = message.getProperty('lastProjectSyncDate');


  var lastSyncDate = getDateValue(lastSyncDateLocal);
  var modifiedDate = getDateValue(modifiedOn);

  if (modifiedDate >= lastSyncDate) {
    message.setHeader('ProcessRequest', 'Yes');
  } else {
    message.setHeader('ProcessRequest', 'Yes');
  }

  var getProjectJson = getJson(projectId);
  message.setBody(JSON.stringify(getProjectJson));
  message.setHeader('Content-Type', 'application/json');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('getprojects:', JSON.stringify(getProjectJson), 'text/json');
  }
  return message;
}

function getJson(projectId) {
  return {
    projects: [
      {
        uri: null,
        name: null,
        code: projectId,
        parameterCorrelationId: null
      }
    ]
  };
}

function getDateValue(dateVariable) {
  var regex = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/;
  var dateArray = regex.exec(dateVariable);
  var syncDate = new Date(
    (Number(dateArray[1])),
    (Number(dateArray[2])) - 1,
    (Number(dateArray[3])),
    (Number(dateArray[4])),
    (Number(dateArray[5])),
    (Number(dateArray[6]))
  );
  return syncDate;
}
