
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogServiceCenterJson');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ServiceCenterCreateResponse:', body, 'text/xml');
  }
  var jsonResponse = JSON.parse(body);
  var groups = message.getProperty('ServiceCenters');
  var serviceCenterCode = String(message.getProperty('ServiceCenterCode'));
  var serviceCenterGroupCells = createServiceCenterGroupsCells(jsonResponse.d.slug, jsonResponse.d.displayText, jsonResponse.d.uri, serviceCenterCode);
  groups = JSON.parse(groups);
  groups.d.rows.push(serviceCenterGroupCells);
  message.setProperty('ServiceCenters', JSON.stringify(groups));
  return message;
}

function createServiceCenterGroupsCells(serviceCenterSlug, serviceCenterName, serviceCenterUri, serviceCenterCode) {
  return {
    cells: [
      {
        dataType: 'urn:replicon:list-type:object',
        objectType: 'urn:replicon:object-type:service-center',
        slug: serviceCenterSlug,
        textValue: serviceCenterName,
        uri: serviceCenterUri
      },
      {
        dataType: 'urn:replicon:list-type:string',
        textValue: serviceCenterCode
      },
      {
        dataType: 'urn:replicon:list-type:string',
        textValue: serviceCenterName
      }
    ]
  };
}
