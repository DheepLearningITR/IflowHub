importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var serviceCenterListData = getServiceCenterListData();
  serviceCenterListData = JSON.stringify(serviceCenterListData);
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogServiceCenterJson');
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ServiceCenterListData request ', serviceCenterListData, 'text/json');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(serviceCenterListData);
  return message;
}

function getServiceCenterListData() {
  return {
    page: 1,
    pagesize: 1000,
    columnUris: [ 'urn:replicon:service-center-list-column:service-center', 'urn:replicon:service-center-list-column:name', 'urn:replicon:service-center-list-column:code' ]
  };
}
