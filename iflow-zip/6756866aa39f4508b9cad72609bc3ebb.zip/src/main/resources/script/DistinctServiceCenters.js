importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogServiceCenterJson');
  body = JSON.parse(body);
  var projects = [];
  if (body && body.ProjectSet && body.ProjectSet.Project) {
    if (body.ProjectSet.Project.length > 0) {
      projects = body.ProjectSet.Project;
    } else {
      projects = [ body.ProjectSet.Project ];
    }
  }
  var serviceCenters = [];
  var addedServiceCenterNames = [];
  for (var index = 0; index < projects.length; index++) {
    var project = projects[index];
    var serviceCenter = project.OrgID;
    var serviceCenterName = project.OrgDesc;

    if (addedServiceCenterNames.indexOf(serviceCenterName) === -1) {
      serviceCenters.push({ name: serviceCenterName, code: serviceCenter });
      addedServiceCenterNames.push(serviceCenterName);
    }
  }
  var messageBody = getXMLFromServiceCenters(serviceCenters);
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('distinctCostCenters:', JSON.stringify(messageBody), 'text/json');
  }
  message.setBody(messageBody);
  return message;
}

function getXMLFromServiceCenters(serviceCenters) {
  var xml = '<ProjectSet>';
  if (serviceCenters && serviceCenters.length > 0) {
    for (var index = 0; index < serviceCenters.length; index++) {
      xml += '<Project><OrgID>' + serviceCenters[index].code + '</OrgID><OrgDesc>' + serviceCenters[index].name + '</OrgDesc></Project>';
    }
  }
  return xml + '</ProjectSet>';
}