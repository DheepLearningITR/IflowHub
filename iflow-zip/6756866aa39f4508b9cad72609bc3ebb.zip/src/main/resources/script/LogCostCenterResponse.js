
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogCostCenterJson');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('CostCenterCreateResponse:', body, 'text/xml');
  }
  var costCenters = message.getProperty('CostCenters');
  var jsonResponse = JSON.parse(body);
  var costCenterCode = String(message.getProperty('CostCenterCode'));
  var costCenterGroupCells = createCostCenterGroupsCells(jsonResponse.d.slug, jsonResponse.d.displayText, jsonResponse.d.uri, costCenterCode);
  costCenters = JSON.parse(costCenters);
  costCenters.d.rows.push(costCenterGroupCells);
  message.setProperty('CostCenters', JSON.stringify(costCenters));
  return message;
}

function createCostCenterGroupsCells(costCenterSlug, costCenterName, costCenterUri, costCenterCode) {
  return {
    cells: [
      {
        dataType: 'urn:replicon:list-type:object',
        objectType: 'urn:replicon:object-type:cost-center',
        slug: costCenterSlug,
        textValue: costCenterName,
        uri: costCenterUri
      },
      {
        dataType: 'urn:replicon:list-type:string',
        textValue: costCenterCode
      },
      {
        dataType: 'urn:replicon:list-type:string',
        textValue: costCenterName
      }
    ]
  };
}
