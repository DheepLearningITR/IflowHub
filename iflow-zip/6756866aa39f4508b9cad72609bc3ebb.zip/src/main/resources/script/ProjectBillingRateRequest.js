importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Plan Data:', body, 'text/json');
  }
  var billingRates = message.getProperty('BillingRates');
  billingRates = JSON.parse(billingRates);
  body = JSON.parse(body);
  var billingRateToAdd = getBillingRatesArray(billingRates, body);

  if (billingRateToAdd) {
    message.setProperty('ProjectBillingRates', JSON.stringify(billingRateToAdd));
  }

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ProjectBillingRates:', JSON.stringify(billingRateToAdd), 'text/json');
  }
  return message;
}

function getBillingRatesArray(billingRates, billingRatesToAdd) {
  var projectBillingRates = [];
  var planData = [];
  if (billingRatesToAdd && billingRatesToAdd.PlanDataSet && billingRatesToAdd.PlanDataSet.PlanData) {
    if (billingRatesToAdd.PlanDataSet.PlanData.length > 0) {
      planData = billingRatesToAdd.PlanDataSet.PlanData;
    } else {
      planData = [ billingRatesToAdd.PlanDataSet.PlanData ];
    }
  }

  if (planData.length > 0) {
    if (billingRates && billingRates.length > 0) {
      for (var index = 0; index < planData.length; index++) {
        for (var i = 0; i < billingRates.length; i++) {
          if (billingRates[i].uri !== 'urn:replicon:user-specific-billing-rate' && billingRates[i].name === planData[index].ResourceText) {
            projectBillingRates.push(billingRates[i]);
          }
        }
      }
    }
  }

  return projectBillingRates;
}
