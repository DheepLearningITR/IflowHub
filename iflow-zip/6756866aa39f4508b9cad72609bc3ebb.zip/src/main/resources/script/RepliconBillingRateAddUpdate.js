importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);

  var logBody = message.getProperty('LogMessageBody');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('EnglishBillingRateBody:', body, 'text/json');
  }
  body = JSON.parse(body);
  var billingRateType = body.PlanData.ResourceId;
  var billingRateName = body.PlanData.ResourceText;
  message.setProperty('billingRateName', billingRateName);
  message.setProperty('billingRateCode', billingRateType);

  var headers = message.getHeaders();
  var token = message.getProperty('RepliconToken');
  var applicationName = message.getProperty('ApplicationName');

  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setHeader('Content-Type', 'application/json');
  var existingBillingRates = JSON.parse(String(headers.get('BillingRates')));
  var isExisting = isExistingRate(billingRateName, existingBillingRates, billingRateType);
  var billingRateJson = getBillingRateJson(isExisting, message, billingRateType, billingRateName);
  message.setBody(JSON.stringify(billingRateJson));

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('BillingRateJson:', JSON.stringify(billingRateJson), 'text/json');
  }
  return message;
}

function getBillingRateJson(isExisting, message, billingRateType, billingRateName) {
  var billingRateJson = '';
  if (isExisting) {
    if (isExisting === true) {
      message.setProperty('IsUpdate', 'false');
    } else {
      message.setProperty('IsUpdate', 'true');
      billingRateJson = {
        billingRateUri: isExisting,
        description: billingRateType
      };
    }
  } else {
    message.setProperty('IsAdd', 'true');
    billingRateJson = {
      billingRate: {
        target: {
          uri: null,
          name: billingRateName
        },
        name: billingRateName,
        description: billingRateType,
        isEnabled: 'true',
        defaultRates: []
      }
    };
  }
  return billingRateJson;
}

function isExistingRate(billingRateName, existingBillingRates, billingRateType) {
  if (existingBillingRates && existingBillingRates.length > 0) {
    for (var i = 0; i < existingBillingRates.length; i++) {
      if (billingRateName === existingBillingRates[i].name) {
        if (billingRateType === existingBillingRates[i].code) {
          return true;
        }

        return existingBillingRates[i].uri;
      }
    }
  }
  return null;
}