importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('BillingRates:', body, 'text/json');
  }
  var allBillingRates = processListServiceData(body);
  message.setBody(String(message.getProperty('Projects')));

  message.setProperty('BillingRates', JSON.stringify(allBillingRates));

  return message;
}

function processListServiceData(allBillingRates) {
  var billingRates = [];
  allBillingRates = JSON.parse(allBillingRates).d.rows;
  for (var rowId = 0; rowId < allBillingRates.length; rowId++) {
    var billingRate = {
      name: allBillingRates[rowId].cells[0].textValue,
      uri: allBillingRates[rowId].cells[0].uri,
      code: allBillingRates[rowId].cells[1].textValue
    };
    billingRates.push(billingRate);
  }
  return billingRates;
}