
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('CostCenter:', body, 'text/xml');
  }
  var controllingArea = getValue2('d:ControllingArea', body);
  var companyCode = getValue2('d:CompanyCode', body);

  message.setProperty('controllingArea', controllingArea);
  message.setProperty('companyCode', companyCode);

  var projectDetails = message.getProperty('projectJSON');
  message.setBody(projectDetails);
  return message;
}

function getValue2(tag, xmlString) {
  var value = null;
  var startPos = null;
  var endPos = null;
  var startTag = '<' + tag + '>';
  var endTag = '</' + tag + '>';
  var tempString = xmlString;
  startPos = tempString.search(startTag) + startTag.length;
  var indices = getAllIndexes(xmlString, endTag);
  if (indices && indices.length > 1) {
    endPos = indices[indices.length - 1];
  } else {
    endPos = tempString.search(endTag);
  }
  value = tempString.slice(startPos, endPos);
  return value;
}

function getAllIndexes(arr, val) {
  var indexes = [];
  var i = -1;
  while ((i = arr.indexOf(val, i + 1)) !== -1) {
    indexes.push(i);
  }
  return indexes;
}