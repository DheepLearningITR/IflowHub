importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogCostCenterJson');

  var repliconCostCenters = message.getProperty('CostCenters');
  repliconCostCenters = JSON.parse(repliconCostCenters);

  body = JSON.parse(body);
  var costCenter = body.Project.CostCenter;
  var costCenterName = body.Project.CostCenterName;
  var costCenterValues = filterGroupsByListData(costCenterName, costCenter, repliconCostCenters.d.rows);

  var costCenterJson = getCostCenterJson(costCenterValues[0], costCenterValues[1], costCenter);
  message.setProperty('CostCenterCode', costCenter);
  message.setBody(JSON.stringify(costCenterJson));

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('costCenterJson:', JSON.stringify(costCenterJson), 'text/json');
  }
  return message;
}

function getCostCenterJson(costCenterGroupUri, costCenterName, costCenter) {
  var costCenterJson = {
    costCenter: costCenterGroupUri ? {
      uri: costCenterGroupUri
    } : null,
    modifications: {
      name: costCenterName,
      codeToApply: {
        value: costCenter
      },
      isEnabled: true
    },
    unitOfWorkId: makeid(6)
  };
  return costCenterJson;
}

function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

function filterGroupsByListData(groupName, groupId, responseBody) {
  var groupNameIdCombined = groupName + ' (' + groupId + ')';
  if (responseBody.length > 0) {
    for (var index = 0; index < responseBody.length; index++) {
      if (responseBody[index].cells && responseBody[index].cells.length && responseBody[index].cells[2] !== null) {
        if (responseBody[index].cells[2].textValue === groupId) {
          // if groupId matches code
          if ((responseBody[index].cells[1].textValue === groupName) || (responseBody[index].cells[1].textValue === groupNameIdCombined)) {
            // if replicon group name matches SFSF groupName or SFSF name + id. match and assign
            return [ responseBody[index].cells[0].uri, responseBody[index].cells[1].textValue ];
          }
          // else update group name
          return [ responseBody[index].cells[0].uri, groupName ];
        }
      }
    }
    // Create group with code inside parenthesis
    return [ null, groupNameIdCombined ];
  }
  // if rows are not present, create cost center directly with name
  return [ null, groupName ];
}