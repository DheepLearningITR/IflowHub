importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var messageLog = messageLogFactory.getMessageLog(message);
  var projectUri = String(message.getProperty('ProjectUri'));
  var serviceCenter = String(message.getProperty('ServiceCenterId'));
  var serviceCentersList = String(message.getProperty('ServiceCenters'));
  var groupUri = getServiceCenterUriByCode(JSON.parse(serviceCentersList), serviceCenter);
  var json = getProjectServiceCenterJson(projectUri, groupUri);
  message.setBody(JSON.stringify(json));
  var map = message.getHeaders();
  map.remove('Accept');
  map.remove('Content-Security-Policy');
  map.remove('RepliconToken');
  map.remove('Transfer-Encoding');

  var logBody = message.getProperty('LogMessageBody');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ProjectServiceCenter:', JSON.stringify(json), 'text/json');
  }
  return message;
}

function getProjectServiceCenterJson(projectUri, groupUri) {
  return {
    projectUri: projectUri,
    serviceCenter: groupUri ? {
      uri: groupUri
    } : null
  };
}

function getServiceCenterUriByCode(serviceCentersList, serviceCenter) {
  var serviceCenterListRowsResponse = serviceCentersList.d.rows;
  if (serviceCenterListRowsResponse.length > 0) {
    for (var index = 0; index < serviceCenterListRowsResponse.length; index++) {
      if (serviceCenterListRowsResponse[index].cells && serviceCenterListRowsResponse[index].cells.length && serviceCenterListRowsResponse[index].cells[2] !== null) {
        if (serviceCenterListRowsResponse[index].cells[2].textValue === serviceCenter) {
          return serviceCenterListRowsResponse[index].cells[0].uri;
        }
      }
    }
  }
  return null;
}
