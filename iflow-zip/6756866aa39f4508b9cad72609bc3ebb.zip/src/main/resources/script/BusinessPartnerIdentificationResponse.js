importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('BusinessPartnerIdentification:', body, 'text/json');
  }
  var employeeId = getValue('d:BPIdentificationNumber', body);
  if (employeeId !== null) {
    var userJson = getUserJson(employeeId);
    message.setBody(JSON.stringify(userJson));

    if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
      messageLog.addAttachmentAsString('userListServiceJson:', JSON.stringify(userJson), 'text/json');
    }
  }

  var token = message.getProperty('RepliconToken');
  var applicationName = message.getProperty('ApplicationName');

  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setHeader('Content-Type', 'application/json');

  return message;
}

function getUserJson(employeeId) {
  var json = {
    page: 1,
    pagesize: 10,
    columnUris: [ 'urn:replicon:user-list-column:user', 'urn:replicon:user-list-column:employee-id' ],
    sort: [],
    filterExpression: {
      leftExpression: {
        filterDefinitionUri: 'urn:replicon:user-list-filter:text'
      },
      operatorUri: 'urn:replicon:filter-operator:text-search',
      rightExpression: {
        value: {
          text: employeeId
        }
      }
    }
  };
  return json;
}

function getValue(tag, xmlString) {
  var value = null;
  var startPos = null;
  var endPos = null;
  var startTag = '<' + tag + '>';
  var endTag = '</' + tag + '>';
  var tempString = xmlString;
  startPos = tempString.search(startTag) + startTag.length;
  endPos = tempString.search(endTag);
  value = tempString.slice(startPos, endPos);
  return value;
}