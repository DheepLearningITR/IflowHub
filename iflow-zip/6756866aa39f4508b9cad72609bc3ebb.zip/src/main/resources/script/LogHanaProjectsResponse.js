importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');

  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ProjectsFromHana:', body, 'text/json');
  }
  if (body === '<ProjectSet/>') {
    message.setProperty('ProjectFound', 'false');
  } else {
    message.setProperty('ProjectFound', 'true');
  }

  var token = message.getProperty('RepliconToken');
  var applicationName = message.getProperty('ApplicationName');

  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setHeader('Content-Type', 'application/json');
  message.setProperty('BillingRates', {});
  message.setProperty('Projects', body);
  message.setBody('{}');
  return message;
}