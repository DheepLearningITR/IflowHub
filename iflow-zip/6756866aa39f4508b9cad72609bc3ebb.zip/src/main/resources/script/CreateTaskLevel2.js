importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);

  var projectCode = String(message.getProperty('projectID'));
  var rootTaskName = String(message.getProperty('rootTaskName'));
  var rootTaskCode = String(message.getProperty('rootTaskCode'));
  var startDate = String(message.getProperty('rootTaskStartDate'));
  var endDate = String(message.getProperty('rootTaskEndDate'));
  var resourcesToAdd = JSON.parse(String(message.getProperty('ResourcesToAdd')));
  var planSet = JSON.parse(String(message.getProperty('PlanSetJson')));


  var token = message.getProperty('RepliconToken');
  var applicationName = message.getProperty('ApplicationName');
  var logBody = message.getProperty('LogMessageBody');

  startDate = JSON.parse(startDate);
  endDate = JSON.parse(endDate);
  body = JSON.parse(body);

  var taskName = body.WorkItem.Workitemname;
  var taskCode = body.WorkItem.Workitem;

  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setHeader('Content-Type', 'application/json');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Tasks:', body, 'text/json');
  }

  var taskJson = getTaskJson(projectCode, taskName, rootTaskName, rootTaskCode, taskCode, startDate, endDate, resourcesToAdd, planSet);

  message.setHeader('Content-Type', 'application/json');
  message.setBody(JSON.stringify(taskJson));

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('TaskLevel2Json', JSON.stringify(taskJson, undefined, 4), 'text/json');
  }

  return message;
}

function getTaskJson(projectCode, taskName, rootTaskName, rootTaskCode, taskCode, startDate, endDate, resourcesToAdd, planSet) {
  var taskResources = getTaskResources(rootTaskCode, resourcesToAdd, planSet);
  return {
    project: {
      uri: null,
      name: null,
      code: projectCode,
      parameterCorrelationId: null
    },
    task: {
      target: {
        uri: null,
        name: taskName,
        parent: {
          uri: null,
          name: rootTaskName,
          parent: null,
          parameterCorrelationId: null
        },
        parameterCorrelationId: null
      },
      name: taskName,
      code: taskCode,
      description: null,
      timeEntryDateRange: {
        startDate: startDate,
        endDate: endDate,
        relativeDateRangeUri: null,
        relativeDateRangeAsOfDate: null
      },
      percentCompleted: '0',
      isTimeEntryAllowed: 'true',
      estimatedHours: null,
      isClosed: 'false',
      customFieldValues: [],
      estimatedCost: null,
      costTypeUri: null,
      timeAndExpenseEntryTypeUri: null,
      assignedResources: taskResources,
      keyValues: []
    }
  };
}

function getTaskResources(taskCode, resourcesToAdd, planSet) {
  var resources = [];
  var planData = [];
  if (planSet && planSet.PlanDataSet && planSet.PlanDataSet.PlanData) {
    if (planSet.PlanDataSet.PlanData.length > 0) {
      planData = planSet.PlanDataSet.PlanData;
    } else {
      planData = [ planSet.PlanDataSet.PlanData ];
    }
  }
  if (resourcesToAdd) {
    for (var index = 0; index < planData.length; index++) {
      var planDataItem = planData[index];
      if (planDataItem && (planDataItem.WorkPackageID === taskCode)) {
        for (var j = 0; j < resourcesToAdd.length; j++) {
          if (planDataItem.Employee === resourcesToAdd[j].Employee) {
            resources.push({
              user: {
                uri: resourcesToAdd[j].uri,
                loginName: null,
                parameterCorrelationId: null
              },
              department: null,
              placeholder: null,
              location: null,
              division: null,
              costCenter: null,
              serviceCenter: null,
              employeeType: null,
              departmentGroup: null
            }
            );
          }
        }
      }
    }
  }
  return resources;
}