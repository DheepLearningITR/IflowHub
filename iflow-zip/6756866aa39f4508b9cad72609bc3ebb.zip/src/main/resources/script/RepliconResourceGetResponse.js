importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('RepliconResources:', body, 'text/json');
  }
  var resourceExtIds = String(message.getProperty('S4HanaResources'));
  var resources = getAssignedResources(JSON.parse(body), JSON.parse(resourceExtIds));
  message.setProperty('ResourcesToAdd', JSON.stringify(resources));
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ResourcesToAdd:', JSON.stringify(resources), 'text/json');
  }
  return message;
}

function getAssignedResources(userData, resourceExtIds) {
  var userUris = [];
  if (userData && userData.d && userData.d.rows && userData.d.rows.length > 0) {
    var userRows = userData.d.rows;
    for (var i = 0; i < userRows.length; i++) {
      var matchedUser = isUserPresent(resourceExtIds, userRows[i].cells[1].textValue);
      if (matchedUser) {
        userUris.push({ uri: userRows[i].cells[0].uri, employeeId: userRows[i].cells[1].textValue, Employee: matchedUser.Employee });
      }
    }
  }
  return userUris;
}

function isUserPresent(resources, userId) {
  if (resources && resources.length > 0) {
    for (var i = 0; i < resources.length; i++) {
      if (resources[i].EmployeeId === userId) {
        return resources[i];
      }
    }
  }
  return null;
}