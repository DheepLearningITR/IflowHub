importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogCostCenterJson');
  body = JSON.parse(body);
  var projects = [];
  if (body && body.ProjectSet && body.ProjectSet.Project) {
    if (body.ProjectSet.Project.length > 0) {
      projects = body.ProjectSet.Project;
    } else {
      projects = [ body.ProjectSet.Project ];
    }
  }
  var costCenters = [];
  var addedCostCenterNames = [];
  for (var index = 0; index < projects.length; index++) {
    var project = projects[index];
    var costCenter = project.CostCenter;
    var costCenterName = project.CostCenterName;

    if (addedCostCenterNames.indexOf(costCenterName) === -1) {
      costCenters.push({ name: costCenterName, code: costCenter });
      addedCostCenterNames.push(costCenterName);
    }
  }
  var messageBody = getXMLFromCostCenters(costCenters);
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('distinctCostCenters:', JSON.stringify(messageBody), 'text/json');
  }
  message.setBody(messageBody);
  return message;
}

function getXMLFromCostCenters(costCenters) {
  var xml = '<ProjectSet>';
  if (costCenters && costCenters.length > 0) {
    for (var index = 0; index < costCenters.length; index++) {
      xml += '<Project><CostCenter>' + costCenters[index].code + '</CostCenter><CostCenterName>' + costCenters[index].name + '</CostCenterName></Project>';
    }
  }
  return xml + '</ProjectSet>';
}