importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ProjectTeamMemberJSON:', body, 'text/json');
  }
  body = JSON.parse(body);
  var billingRates = String(message.getProperty('ProjectBillingRates'));
  billingRates = JSON.parse(billingRates);
  var projectUri = String(message.getProperty('ProjectUri'));
  var resourcesToAdd = JSON.parse(String(message.getProperty('ResourcesToAdd')));
  var resourceUri = getResourceUri(body.PlanData.User, resourcesToAdd);
  if (resourceUri) {
    message.setProperty('AssignBillingRates', 'yes');
  } else {
    message.setProperty('AssignBillingRates', 'no');
  }

  var json = getJson(projectUri, billingRates, resourcesToAdd, body);
  message.setBody(JSON.stringify(json));

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ProjectTeamMemberBillingRate:', JSON.stringify(json), 'text/json');
  }
  return message;
}

function getJson(projectUri, billingRates, resourcesToAdd, body) {
  var resourceUri = getResourceUri(body.PlanData.User, resourcesToAdd);
  var json = {
    projectUri: projectUri,
    resourceUri: resourceUri,
    billingRateUris: getBillingRatesArray(billingRates, body)
  };
  return json;
}

function getBillingRatesArray(billingRates, body) {
  var array = [];
  var rates = [];
  if (body.PlanData && body.PlanData.User && body.PlanData.Rates && body.PlanData.Rates.Rate && body.PlanData.Rates.Rate.length > 0) {
    rates = body.PlanData.Rates.Rate;
  } else {
    rates = [ body.PlanData.Rates.Rate ];
  }
  if (billingRates && billingRates && billingRates.length > 0 && rates.length > 0) {
    for (var j = 0; j < rates.length; j++) {
      for (var i = 0; i < billingRates.length; i++) {
        if (billingRates[i].name === rates[j].Name) {
          array.push(billingRates[i].uri);
          break;
        }
      }
    }
  }
  return array;
}

function getResourceUri(user, resourcesToAdd) {
  if (user && resourcesToAdd && resourcesToAdd.length > 0) {
    for (var index = 0; index < resourcesToAdd.length; index++) {
      if (resourcesToAdd[index].Employee === user) {
        return resourcesToAdd[index].uri;
      }
    }
  }
  return null;
}