importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var messageLog = messageLogFactory.getMessageLog(message);
  var projectUri = String(message.getProperty('ProjectUri'));
  var costCenter = String(message.getProperty('CostCenterId'));
  var costCentersList = String(message.getProperty('CostCenters'));
  var costCenterUri = getCostCenterUriByCode(JSON.parse(costCentersList), costCenter);
  var json = getCostCenterJson(projectUri, costCenterUri);
  message.setBody(JSON.stringify(json));
  var map = message.getHeaders();
  map.remove('Accept');
  map.remove('Content-Security-Policy');
  map.remove('RepliconToken');
  map.remove('Transfer-Encoding');

  var logBody = message.getProperty('LogMessageBody');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ProjectCostCenter:', JSON.stringify(json), 'text/json');
  }
  return message;
}

function getCostCenterJson(projectUri, costCenterUri) {
  return {
    projectUri: projectUri,
    costCenter: costCenterUri ? {
      uri: costCenterUri
    } : null
  };
}

function getCostCenterUriByCode(costCentersList, costCenter) {
  var costCenterListRowsResponse = costCentersList.d.rows;
  if (costCenterListRowsResponse.length > 0) {
    for (var index = 0; index < costCenterListRowsResponse.length; index++) {
      if (costCenterListRowsResponse[index].cells && costCenterListRowsResponse[index].cells.length && costCenterListRowsResponse[index].cells[2] !== null) {
        if (costCenterListRowsResponse[index].cells[2].textValue === costCenter) {
          return costCenterListRowsResponse[index].cells[0].uri;
        }
      }
    }
  }
  return null;
}
