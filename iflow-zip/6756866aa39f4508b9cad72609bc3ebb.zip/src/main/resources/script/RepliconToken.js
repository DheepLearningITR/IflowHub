/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var map = message.getProperties();
  var token = message.getProperty('RepliconToken');
  var applicationName = message.getProperty('ApplicationName');
  var messageLog = messageLogFactory.getMessageLog(message);

  updateLastSyncDate(message, map, messageLog);

  var lasSyncDate = message.getProperty('lastProjectSyncDate');
  var isLastSuccessfulTime = String(message.getProperty('LastSuccessfulProjectSyncTime'));
  var isFirstRun = false;
  if (!isLastSuccessfulTime) {
    isFirstRun = true;
  }

  var offset = message.getProperty('ProjectRunOffsetTimeInMM');
  var logProperty = message.getProperty('LogMessageProperty');
  var statusToSync = message.getProperty('ProjectSyncOnlyOpenProjects');

  if (statusToSync && isFirstRun) {
    var statuses = statusToSync.split(',');
    var strFilter = '';
    if (statuses && statuses.length > 0) {
      for (var index = 0; index < statuses.length; index++) {
        if (!strFilter) {
          strFilter = 'StageDesc eq \'' + statuses[index].trim() + '\'';
        } else {
          strFilter += ' or StageDesc eq \'' + statuses[index].trim() + '\'';
        }
      }
    }
    message.setProperty('AdditionalFilter', ' and (' + strFilter + ')');
  } else {
    message.setProperty('AdditionalFilter', ' ');
  }


  lasSyncDate = getDateValue(lasSyncDate);
  lasSyncDate = addMinutes(lasSyncDate, offset * -1);
  lasSyncDate = lasSyncDate.toISOString().split('.')[0];
  message.setProperty('lastProjectSyncDate', lasSyncDate);
  if (messageLog && logProperty !== null && logProperty.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('preDate:', lasSyncDate, 'text/json');
    messageLog.addAttachmentAsString('postDate:', lasSyncDate, 'text/json');
  }
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setHeader('Content-Type', 'application/json');
  return message;
}

function addMinutes(dt, minutes) {
  return new Date(dt.getTime() + (minutes * 60000));
}

function getDateValue(dateVariable) {
  var regex = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/;
  var dateArray = regex.exec(dateVariable);
  var syncDate = new Date(
    (Number(dateArray[1])),
    (Number(dateArray[2])) - 1,
    (Number(dateArray[3])),
    (Number(dateArray[4])),
    (Number(dateArray[5])),
    (Number(dateArray[6]))
  );
  return syncDate;
}

function updateLastSyncDate(message, map, messageLog) {
  var lastSuccessSyncDate = String(message.getProperty('LastSuccessfulProjectSyncTime'));
  if (lastSuccessSyncDate) {
    lastSuccessSyncDate = getDateValue(lastSuccessSyncDate);
  } else {
    lastSuccessSyncDate = getUTCDate();
  }
  var resetTimeThreshold = message.getProperty('resetTimeThresholdInMins');
  var utcDate = getUTCDate();
  if ((utcDate.getTime() - lastSuccessSyncDate.getTime()) > resetTimeThreshold * 60000) {
    var logMessageBody = message.getProperty('LogMessageBody');

    var lastSyncDate = addMinutes(utcDate, -1 * resetTimeThreshold);
    lastSyncDate = lastSyncDate.toISOString().split('.')[0];
    message.setProperty('lastProjectSyncDate', lastSyncDate);
    if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
      messageLog.addAttachmentAsString('Reset Time', lastSyncDate, 'text/json');
    }
  }
}

function getUTCDate() {
  var utcDate = new Date(new Date().toUTCString().slice(0, -4));
  return utcDate;
}