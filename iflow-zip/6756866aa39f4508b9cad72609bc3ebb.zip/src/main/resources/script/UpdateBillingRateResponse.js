importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('BillingRateUpdate:', body, 'text/json');
  }
  var billingRates = String(message.getProperty('BillingRates'));
  billingRates = updateBillingRateArray(billingRates, String(message.getProperty('BillingRateName')), String(message.getProperty('BillingRateCode')));
  message.setProperty('BillingRates', billingRates);
  message.setBody(String(message.getProperty('Projects')));


  return message;
}

function updateBillingRateArray(billingRates, name, code) {
  if (billingRates !== null && billingRates.length > 0) {
    for (var i = 0; i < billingRates.length; i++) {
      if (billingRates[i].name === name) {
        billingRates[i].code = code;
      }
    }
  }
  return billingRates;
}
