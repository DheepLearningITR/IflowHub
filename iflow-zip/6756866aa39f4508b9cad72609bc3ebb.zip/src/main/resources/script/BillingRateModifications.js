importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');
  message.setProperty('PlanSetJson', body);

  var existingBillingRates = JSON.parse(String(message.getProperty('BillingRates')));
  body = JSON.parse(body);

  var changedBillingRates = getBillingRateModifications(body.PlanDataSet, existingBillingRates);

  var token = message.getProperty('RepliconToken');
  var applicationName = message.getProperty('ApplicationName');

  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setHeader('Content-Type', 'application/json');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('changedBillingRates:', changedBillingRates, 'text/json');
  }
  message.setBody(changedBillingRates);
  return message;
}

function getBillingRateModifications(projectBillingRates, repliconBillingRates) {
  var xmlString = '<PlanDataSet>';
  var isAdded = [];
  var planData = [];
  if (projectBillingRates && projectBillingRates.PlanData) {
    if (projectBillingRates.PlanData.length > 0) {
      planData = projectBillingRates.PlanData;
    } else {
      planData = [ projectBillingRates.PlanData ];
    }
  }
  if (planData && planData.length > 0) {
    for (var i = 0; i < planData.length; i++) {
      var planSetName = planData[i].ResourceText;
      var planSetId = planData[i].ResourceId;
      var isFound = false;
      if (isAdded.indexOf(planSetName) === -1) {
        var matchingRate = filterRepliconRate(repliconBillingRates, planSetName);
        if (matchingRate) {
          isFound = true;
          isAdded.push(planSetName);
          if (planSetId === matchingRate.code) {
            // do nothing
          } else {
            xmlString += '<PlanData><ResourceText>' + planSetName + '</ResourceText><ResourceId>' + planSetId + '</ResourceId></PlanData>';
          }
        }
        if (!isFound) {
          xmlString += '<PlanData><ResourceText>' + planSetName + '</ResourceText><ResourceId>' + planSetId + '</ResourceId></PlanData>';
        }
      }
    }
  }
  xmlString += '<PlanDataSet>';
  return xmlString;
}

function filterRepliconRate(repliconBillingRates, planSetName) {
  if (repliconBillingRates !== null && repliconBillingRates.length > 0) {
    var billingRates = repliconBillingRates.filter(function(item) {
      return item.name === planSetName;
    });
    if (billingRates && billingRates.length > 0) {
      return billingRates[0];
    }
  }
  return null;
}