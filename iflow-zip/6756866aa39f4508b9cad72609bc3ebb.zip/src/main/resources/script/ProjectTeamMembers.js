importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');

  var planSet = String(message.getProperty('PlanSetJson'));
  planSet = JSON.parse(planSet);

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('planSet:', JSON.stringify(planSet), 'text/json');
  }

  var projectBillingRatesXML = getProjectBillingRatesXML(planSet.PlanDataSet);
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('ProjectTeamXML:', projectBillingRatesXML, 'text/json');
  }
  message.setBody(projectBillingRatesXML);
  return message;
}

function getProjectBillingRatesXML(planSet) {
  var xmlString = '<PlanDataSet>';
  var planData = [];
  if (planSet && planSet.PlanData) {
    if (planSet.PlanData.length > 0) {
      planData = planSet.PlanData;
    } else {
      planData = [ planSet.PlanData ];
    }
  }
  var isAdded = [];
  var billingRateUsers = [];

  for (var i = 0; i < planData.length; i++) {
    var planSetName = planData[i].ResourceText;
    var user = planData[i].Employee;
    if (isAdded.indexOf(user) === -1) {
      billingRateUsers.push({
        user: user,
        rates: [ planSetName ]
      });
      isAdded.push(user);
    } else if (billingRateUsers && billingRateUsers.length > 0) {
      for (var j = 0; j < billingRateUsers.length; j++) {
        if (user === billingRateUsers[j].user) {
          if (billingRateUsers[j].rates.indexOf(planSetName) === -1) {
            billingRateUsers[j].rates.push(planSetName);
          }
        }
      }
    }
  }

  for (var index = 0; index < billingRateUsers.length; index++) {
    xmlString += '<PlanData><User>' + billingRateUsers[index].user + '</User><Rates>';
    for (var rateIndex = 0; rateIndex < billingRateUsers[index].rates.length; rateIndex++) {
      xmlString += '<Rate><Name>' + billingRateUsers[index].rates[rateIndex] + '</Name></Rate>';
    }
    xmlString += '</Rates>';
    xmlString += '</PlanData>';
  }
  xmlString += '</PlanDataSet>';
  return xmlString;
}