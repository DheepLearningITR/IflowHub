importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
  var body = getListServiceJson();
  var messageLog = messageLogFactory.getMessageLog(message);
  body = JSON.stringify(body);
  var logBody = message.getProperty('LogMessageBody');
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('BillingRateListServiceRequest:', body, 'text/json');
  }
  message.setBody(body);

  var token = message.getProperty('RepliconToken');
  var applicationName = message.getProperty('ApplicationName');

  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setHeader('Content-Type', 'application/json');

  return message;
}

function getListServiceJson() {
  var json = {
    page: '1',
    pagesize: '1000',
    columnUris: [ 'urn:replicon:billing-rate-list-column:name', 'urn:replicon:billing-rate-list-column:description' ],
    sort: []
  };
  return json;
}