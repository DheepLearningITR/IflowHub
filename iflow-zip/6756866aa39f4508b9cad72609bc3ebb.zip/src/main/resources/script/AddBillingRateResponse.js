importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('BillingRateCreateResponse:', body, 'text/json');
  }

  var billingRates = String(message.getProperty('BillingRates'));
  billingRates = JSON.parse(billingRates);

  billingRates.push({ name: String(message.getProperty('BillingRateName')), code: String(message.getProperty('BillingRateCode')), uri: JSON.parse(body).d.uri });
  message.setProperty('BillingRates', JSON.stringify(billingRates));
  return message;
}
