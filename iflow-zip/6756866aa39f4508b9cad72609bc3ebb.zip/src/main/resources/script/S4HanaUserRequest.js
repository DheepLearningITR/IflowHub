importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('PlanSetForS4HanaAgreement:', body, 'text/xml');
  }

  message.setProperty('PlanSetJson', body);
  var users = getWorkAgreementsToQuery(body);
  if (!users || !users.length) {
    message.setProperty('UsersExist', 'no');
  }
  message.setProperty('WorkAgreements', users);

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('WorkAgreementsFilter:', users, 'text/xml');
  }
  return message;
}

function getWorkAgreementsToQuery(planSet) {
  planSet = JSON.parse(planSet);
  var workAgreements = '';
  var isAdded = false;
  var addedEmployees = [];
  var planData = [];
  if (planSet && planSet.PlanDataSet && planSet.PlanDataSet.PlanData) {
    if (planSet.PlanDataSet.PlanData.length > 0) {
      planData = planSet.PlanDataSet.PlanData;
    } else {
      planData = [ planSet.PlanDataSet.PlanData ];
    }
  }
  for (var i = 0; i < planData.length; i++) {
    if (planData[i] && planData[i].Employee) {
      var employee = planData[i].Employee;
      if (addedEmployees.indexOf(employee) === -1) {
        addedEmployees.push(employee);
        if (isAdded) {
          workAgreements += ' or ';
        }
        isAdded = true;
        workAgreements += 'PersonWorkAgreement eq \'' + employee + '\'';
      }
    }
  }
  return workAgreements;
}
