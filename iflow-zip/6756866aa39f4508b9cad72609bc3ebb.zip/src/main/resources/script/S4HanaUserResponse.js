importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('S4HanaUsersResponse:', body, 'text/xml');
  }
  var usersJson = getUsersListServiceRequest(JSON.parse(body));
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('RepliconResourceRequest:', JSON.stringify(usersJson), 'text/xml');
  }
  var token = message.getProperty('RepliconToken');
  message.setHeader('Authorization', token);
  message.setBody(JSON.stringify(usersJson.listServiceJson));
  message.setProperty('S4HanaResources', JSON.stringify(usersJson.employeeIds));
  message.setHeader('Content-Type', 'application/json');
  return message;
}

function getUsersListServiceRequest(s4HanaUsers) {
  var isFilterAdded = false;
  var finalFilterExpression = null;
  var employeeIds = [];
  var userRecords = [];
  if (s4HanaUsers && s4HanaUsers.YY1_EmployeeWorkAgreement && s4HanaUsers.YY1_EmployeeWorkAgreement.YY1_EmployeeWorkAgreementType) {
    if (s4HanaUsers.YY1_EmployeeWorkAgreement.YY1_EmployeeWorkAgreementType.length > 0) {
      userRecords = s4HanaUsers.YY1_EmployeeWorkAgreement.YY1_EmployeeWorkAgreementType;
    } else {
      userRecords = [ s4HanaUsers.YY1_EmployeeWorkAgreement.YY1_EmployeeWorkAgreementType ];
    }
  }
  for (var i = 0; i < userRecords.length; i++) {
    var userRecord = userRecords[i];
    if (userRecord && userRecord.PersonWorkAgreementExternalID) {
      var filterExpression = getFilterExpression(userRecord.PersonWorkAgreementExternalID);
      employeeIds.push({ EmployeeId: userRecord.PersonWorkAgreementExternalID, Employee: userRecord.PersonWorkAgreement });
      if (!isFilterAdded) {
        finalFilterExpression = filterExpression;
        isFilterAdded = true;
      } else {
        finalFilterExpression = joinFilter(finalFilterExpression, filterExpression, 'urn:replicon:filter-operator:or');
      }
    }
  }
  var listServiceJson = {
    page: '1',
    pagesize: '1000',
    columnUris: [ 'urn:replicon:user-list-column:user', 'urn:replicon:user-list-column:employee-id' ],
    sort: [],
    filterExpression: finalFilterExpression
  };
  return {
    employeeIds: employeeIds,
    listServiceJson: listServiceJson
  };
}

function joinFilter(leftExpression, rightExpression, operatorUri) {
  return {
    leftExpression: leftExpression,
    operatorUri: operatorUri,
    rightExpression: rightExpression,
    value: null,
    filterDefinitionUri: null
  };
}

function getFilterExpression(employeeId) {
  return {
    leftExpression: {
      leftExpression: null,
      operatorUri: null,
      rightExpression: null,
      value: null,
      filterDefinitionUri: 'urn:replicon:user-list-filter:text'
    },
    operatorUri: 'urn:replicon:filter-operator:text-search',
    rightExpression: {
      leftExpression: null,
      operatorUri: null,
      rightExpression: null,
      value: {
        uri: null,
        uris: [],
        bool: null,
        date: null,
        money: null,
        number: null,
        text: employeeId,
        time: null,
        calendarDayDurationValue: null,
        workdayDurationValue: null,
        dateRange: null,
        dateTimeUtc: null,
        dateTimeUtcRange: null
      },
      filterDefinitionUri: null
    },
    value: null,
    filterDefinitionUri: null
  };
}