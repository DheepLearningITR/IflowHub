importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogServiceCenterJson');

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('AllRepliconServiceCenters:', body, 'text/xml');
  }

  message.setProperty('ServiceCenters', body);
  message.setProperty('CreateServiceCenters', 'true');
  var projectDetails = String(message.getProperty('Projects'));
  message.setBody(projectDetails);

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('projectXML:', projectDetails, 'text/json');
  }
  return message;
}
