importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var projectName = String(message.getProperty('projectName'));
  //always log exception
  if (messageLog) {
    messageLog.addAttachmentAsString('Failed ' + projectName, body, 'text/json');
  }

  return message;
}