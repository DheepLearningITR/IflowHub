import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    /* This script is to log the BP IDs that are filtered out with no FSM company. */
    def body = message.getBody(java.io.Reader)
    def query = new XmlSlurper().parse(body)
    def messageLog = messageLogFactory.getMessageLog(message)
	
    query.BusinessPartnerSUITEBulkReplicateRequest.BusinessPartnerSUITEReplicateRequestMessage.each { bpMessage ->
        bpMessage.BusinessPartner.each { bp ->
            def internalID = bp.InternalID.text()
            if (messageLog != null) {
                messageLog.addCustomHeaderProperty("FSMCompanyNotFoundForEmployee", internalID)
            }
        }
    }
    return message
}
