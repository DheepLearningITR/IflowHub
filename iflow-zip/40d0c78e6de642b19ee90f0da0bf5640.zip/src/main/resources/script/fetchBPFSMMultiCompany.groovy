import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import com.sap.it.api.asdk.datastore.DataStoreService
import com.sap.it.api.asdk.runtime.Factory

def Message processData(Message message) {
    def body = message.getBody(java.lang.String)
    def query = new XmlParser().parseText(body)
    def allfsmCompanyList;
    
    def getAllCompanies = {
        def DSservice = new Factory(DataStoreService.class).getService()
        // get the FSM Company List from data store
        def dsEntry = DSservice.get("FSMCompanyList", 'FSMCompanyList')?DSservice.get("FSMCompanyList", 'FSMCompanyList'):'NA'
		if (dsEntry != 'NA'){
			def result = new String(dsEntry.getDataAsArray())
			allfsmCompanyList = new XmlParser().parseText(result)
		}else{
		   allfsmCompanyList = new XmlParser().parseText("<FSMMultiCompany><FSMCompany>NA|NA</FSMCompany></FSMMultiCompany>")
		}
    }
    
    
    /*START: Logic to handle all FSM Company mapping*/
	getAllCompanies();
	
    query.BusinessPartnerSUITEReplicateRequestMessage.each { bpMessage ->
        bpMessage.BusinessPartner.each { bp ->
            bp.append(allfsmCompanyList)
        }
    }
    /*END: Logic to handle all FSM Company mapping*/


    def FSMCompanyData = XmlUtil.serialize(query)
    message.setBody(FSMCompanyData)
    return message
}
