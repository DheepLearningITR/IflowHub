import groovy.json.JsonSlurper
import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def content = jsonSlurper.parseText(body);
    def properties  = message.getProperties();
    def messageLog = messageLogFactory.getMessageLog(message);
    def multiCompFlag = properties.get("EnableMultiCompany");
    

    if (content.hasErrors){
        message.setProperty("ErrorType", "FSMSkillAssignmentError");
        def errorDetail = ""
        def erroredBPID = ""
        content.results.each {
            if (it.status >= 400 && it.status < 600) {
                message.setProperty('http.StatusCode', it.status)
                message.setProperty('http.ResponseBody', body)
                errorDetail += it.error.detail + '\n'
                erroredBPID += it.technician.externalId + ','
                //log failed BPs in MPL headers                
                if(multiCompFlag == "true"){                    
			        messageLog.addCustomHeaderProperty("SkillAssignmentFailedtoLoad", it.technician.externalId + '|' + properties.get("X-Company-ID"));
                }                                            
            }
        }
        message.setProperty('http.StatusText', errorDetail); 
        message.setProperty('erroredBPID', erroredBPID); 
    }

    return message;
}
