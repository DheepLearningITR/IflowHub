import groovy.json.JsonSlurper
import groovy.xml.XmlUtil
import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def content = jsonSlurper.parseText(body);
    def properties  = message.getProperties();
    def messageLog = messageLogFactory.getMessageLog(message);
    def multiCompFlag = properties.get("EnableMultiCompany");
    def FSMEmployees = "<ValidEmployees></ValidEmployees>"
    def FSMEmployeesxml = new XmlParser().parseText(FSMEmployees)
    
    content.each{
        if (it.status >= 400 && it.status < 600) {
            message.setProperty("ErrorType", "FSMError");
            message.setProperty('http.StatusCode', it.status)
            message.setProperty('http.ResponseBody', body)
            if (it.status == 500) {
                message.setProperty('http.StatusText', it.message);
            } else {
                message.setProperty('http.StatusText', it.ex.message);
            }

            //log failed BPs in MPL headers
            if(messageLog != null){
                if(multiCompFlag == "true"){
                   //if (it.ex.size()>0)
			        messageLog.addCustomHeaderProperty("EmployeeFailedToLoad", it.externalId + '|' + properties.get("X-Company-ID"));
                }
            }
        }else{
            FSMEmployeesxml.appendNode("EmployeeID", [:], it.unifiedPerson.externalId)
            println it.unifiedPerson.externalId
        }
    }

    message.setProperty("FSMEmployeesxml",XmlUtil.serialize(FSMEmployeesxml));
    return message;
}
