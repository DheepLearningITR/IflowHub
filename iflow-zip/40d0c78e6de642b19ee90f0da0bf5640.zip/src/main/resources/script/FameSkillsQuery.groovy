import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil

def Message processData(Message message) {
    //this script is to frame the filter query to fetch Skill assigned to an Employee from S4HANA    
    def body = message.getBody(String) as String
    message.setProperty("EmployeeList",body)
    def empxml = new XmlParser().parseText(body)
    def skillfilter = """(("""   

    def employeeIDs = []
    empxml.EmployeeID.each { emp ->
        def employeeID = emp.text()
        employeeIDs << "EmployeeInternalID eq '" + employeeID + "'"
    }
    
    // Join the individual conditions with ' or '
    skillfilter += employeeIDs.join(" or ")
    skillfilter += ")" 
    skillfilter +=  " and HCMQualificationID ne '' and HCMQualificationProficiency ne '0' and HCMValidityEndDate eq 9999-12-31)"

    message.setProperty("skillsQueryFilter",skillfilter)
    def sapclient = message.getProperty("sap-client")
    message.setHeader("sap-client",sapclient)

    message.setBody(XmlUtil.serialize(empxml));
    return message
}
