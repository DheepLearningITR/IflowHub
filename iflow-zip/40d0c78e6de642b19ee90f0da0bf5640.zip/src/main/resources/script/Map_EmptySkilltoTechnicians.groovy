import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) { 
    // this script is to format the empty skills to employee payload
    def body = new StringReader(message.getProperty("EmployeeList") as String)
    def empList = new XmlSlurper().parse(body);
    
    def jsonList = []    
    empList.EmployeeID.each { employeeIdNode ->
        def id = employeeIdNode.text()

        //Construct the JSON object FSM structure for each employee
        def technicianObject = [
            skills: [], 
            technician: [
                externalId: id
            ]
        ]
    
        jsonList.add(technicianObject)
    }

    def jsonOutput = JsonOutput.prettyPrint(JsonOutput.toJson(jsonList))
    message.setBody(JsonOutput.prettyPrint(jsonOutput))
 
    return message
}
