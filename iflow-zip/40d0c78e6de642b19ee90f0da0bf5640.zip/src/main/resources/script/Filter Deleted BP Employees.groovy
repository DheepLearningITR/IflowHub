import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil

def Message processData(Message message)
{
    def ReadPayload = new StringReader(message.getProperty("OriginalPayload") as String)
    def BPPayload = new XmlSlurper().parse(ReadPayload);

    def updateBPAddress = false

    BPPayload.'**'.findAll { it.name() == 'BusinessPartnerSUITEReplicateRequestMessage' }.each { messageNode ->
        def deletedIndicator = messageNode.BusinessPartner.Common.DeletedIndicator.text()
        if (deletedIndicator == 'true') {
            messageNode.replaceNode {}
        }
    }

    if (BPPayload.'**'.findAll { it.name() == 'BusinessPartnerSUITEReplicateRequestMessage' }.size() > 0) {
        updateBPAddress = true
    }

    def UpdatedBPPayload = XmlUtil.serialize(BPPayload)

    message.setProperty("UpdateBPAddress", updateBPAddress.toString())
    message.setBody(UpdatedBPPayload)

    return message;
}
