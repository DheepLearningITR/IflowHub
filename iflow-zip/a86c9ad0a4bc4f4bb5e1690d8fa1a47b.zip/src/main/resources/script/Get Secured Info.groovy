import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Calendar.*;
import groovy.xml.*;
import com.sap.it.api.ITApiFactory; 
import com.sap.it.api.securestore.SecureStoreService; 
import com.sap.it.api.securestore.UserCredential; 
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import groovy.json.JsonSlurper;
import groovy.transform.Field;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Field Logger log = LoggerFactory.getLogger("com.sap.hci.metviewer.iflow");

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def map = message.getProperties();
    
    String taxNo = map.get("taxNo");
    message.setProperty("successCode", "");
    
    def service = ITApiFactory.getApi(SecureStoreService.class, null);  
    try{
        def GTIsalt = service.getUserCredential("BaiWang_" + taxNo + "_Salt");
        String salt = new String(GTIsalt.getPassword()); 
        message.setProperty("salt", salt);
    }catch(e){
        message.setProperty("invoiceStatus","E");
        message.setProperty("successCode","200013");
        message.setProperty("errorMessage","未在CPI中找到相应的Security Material");
        message.setProperty("detailMessage","未在CPI中找到相应的Security Material，请确保（BaiWang_" + taxNo + "_Salt）维护在CPI中");
        return message;
    }

    try{
        def GTIclientSercet = service.getUserCredential("BaiWang_" +taxNo +"_ClientSercet");
        String clientSecret = new String(GTIclientSercet.getPassword()); 
        message.setProperty("clientSecret", clientSecret);
    }catch(e){
        message.setProperty("invoiceStatus","E");
        message.setProperty("successCode","200013");
        message.setProperty("errorMessage","未在CPI中找到相应的Security Material");
        message.setProperty("detailMessage","未在CPI中找到相应的Security Material，请确保（BaiWang_" +taxNo +"_ClientSercet）维护在CPI中");
        return message;
    }

    try{
        def GTIclientId = service.getUserCredential("BaiWang_" +taxNo +"_ClientId");
        String clientId = new String(GTIclientId.getPassword()); 
        message.setProperty("clientId", clientId);
    }catch(e){
        message.setProperty("invoiceStatus","E");
        message.setProperty("successCode","200013");
        message.setProperty("errorMessage","未在CPI中找到相应的Security Material");
        message.setProperty("detailMessage","未在CPI中找到相应的Security Material，请确保（BaiWang_" +taxNo +"_ClientId）维护在CPI中");
        return message;
    }

    try{
        def GTIcredentials = service.getUserCredential("BaiWang_" +taxNo +"_Credentials");
        String username = new String(GTIcredentials.getUsername());
        String password = new String(GTIcredentials.getPassword()); 
        message.setProperty("username", username);
        message.setProperty("password", password);
    }catch(e){
        message.setProperty("invoiceStatus","E");
        message.setProperty("successCode","200013");
        message.setProperty("errorMessage","未在CPI中找到相应的Security Material");
        message.setProperty("detailMessage","未在CPI中找到相应的Security Material，请确保（BaiWang_" +taxNo +"_Credentials）维护在CPI中");
        return message;
    }

    return message;
}