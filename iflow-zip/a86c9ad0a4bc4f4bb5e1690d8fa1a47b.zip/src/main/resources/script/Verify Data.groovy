/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
   
    def map = message.getProperties();
    def method = map.get("method");
    def taxNo = map.get("taxNo");
  
    if(method != 'Q'){
    	message.setProperty("successCode","200001");
        message.setProperty("errorMessage","不支持的操作类型");
        message.setProperty("detailMessage","操作为空或不支持的操作类型，目前支持的类型为query");
        return message;
    }
    if(taxNo == ''){
        message.setProperty("successCode","200002");
        message.setProperty("errorMessage","税号不能为空");
        message.setProperty("detailMessage","发票请求中，税号不能为空，请确保taxnumber不为空");
        return message;
    }
    
    
    return message;
}

def Message verifyGtdnmbr(Message message){
    
    def map = message.getProperties();
    def gtdNo = map.get("gtdNo");
    
    if(gtdNo == ''){
        message.setProperty("successCode","200003");
        message.setProperty("errorMessage","发票流水号不能为空");
        message.setProperty("detailMessage","查询请求中，发票流水号不能为空，请确保gtdnmbr不为空");
        return message;
    }
    
    return message;
    
}