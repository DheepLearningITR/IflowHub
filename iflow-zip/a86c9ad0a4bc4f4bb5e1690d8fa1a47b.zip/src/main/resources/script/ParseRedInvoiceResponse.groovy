/*
 The integration developer needs to create the method processData
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
which includes helper methods useful for the content developer:
The methods available are:
	public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
	public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
	public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
	public void setHeader(java.lang.String name, java.lang.Object value)
	public java.util.Map<java.lang.String,java.lang.Object> getProperties()
	public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties)
	public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput;
import groovy.json.JsonSlurper;

def Message processData(Message message)
{
	def map = message.getProperties();
	String isFE = message.getProperty("invoiceMedium");
	String paperFlag = "F";
	def jsonStr = '{"taxNo":"","data":{"invoiceNo":""}}';
	def jsonObj = new JsonSlurper().parseText(jsonStr);
	jsonObj.taxNo = message.getProperty("taxNo");
	jsonObj.data.invoiceNo = message.getProperty("redInvoiceNo");
	if (paperFlag.equals(isFE)) {
		message.setProperty("body", JsonOutput.toJson(jsonObj));
	}
	
	return message;
}

def Message setErrorMessages(Message message) {
    def redInvoiceNo = message.getProperty("redInvoiceNo");
    def redConfirmUUID = message.getProperty("redConfirmUUID");
    String detailMessage = "红字信息确认单" + redConfirmUUID + "未找到对应发票信息，请重新确认查询";
	if (redInvoiceNo=="") {
	    message.setProperty("errorMessage", "未查询到发票信息");
	    message.setProperty("successCode", "100006");
	    message.setProperty("detailMessage", detailMessage);
	}
	return message;
}


