import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.String;
import groovy.xml.XmlUtil;
import groovy.util.*;

def Message processData(Message message) {
    def map = message.getProperties()

    String content = message.getBody(java.lang.String) as String

    def rootNode = new XmlParser().parseText(content)

    calculateDiscountAmountAndTax(rootNode, message)

    return message
}

def calculateDiscountAmountAndTax(rootNode, message) {
    def invoiceItems = rootNode.response.invoiceDetailsList
    def discountAmount = 0
    def discountTax = 0
    
    
    if (invoiceItems) {
        invoiceItems.each { item ->
            if (item?.invoiceLineNature.text() == '1') {
                def goodsPrice = item?.goodsTotalPrice?.text()?.toDouble()
                def goodsTax = item?.goodsTotalTax?.text()?.toDouble()
                discountAmount += goodsPrice ?: 0
                discountTax += goodsTax ?: 0
            }
        }
    }
    
    if (discountAmount != 0) {
        message.setProperty("discountAmount", discountAmount)
        message.setProperty("discountTax", discountTax)
    } else {
        message.setProperty("discountAmount", '')
        message.setProperty("discountTax", '')
    }
}
