import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

def String getProperty(String propertyName,MappingContext context){
    String PropertyValue= context.getProperty(propertyName);
    PropertyValue= PropertyValue.toString();
    return PropertyValue;
}