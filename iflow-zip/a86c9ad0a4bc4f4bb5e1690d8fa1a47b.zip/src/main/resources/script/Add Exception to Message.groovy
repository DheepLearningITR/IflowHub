/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    def map = message.getProperties();
    def errorMessage = map.get("errorMessage");
    
    def sourceSystem = map.get("sourceSystem");
    if(sourceSystem == null || sourceSystem == ""){
        sourceSystem = "Unknown System";
    }
    message.setProperty("sourceSystem",sourceSystem);
    
    if(errorMessage == null || errorMessage == "")
    {
        message.setProperty("successCode","299999");
        message.setProperty("errorMessage","CPI运行时发生异常");
     //   def detailMessage = map.get("exceptionStackTrace");
     //   def detailMessageCDATA = "<![CDATA[" + detailMessage + "]]>";
        message.setProperty("detailMessage","CPI运行时发生异常，请联系CPI系统管理员");
    }
    
    return message;
}