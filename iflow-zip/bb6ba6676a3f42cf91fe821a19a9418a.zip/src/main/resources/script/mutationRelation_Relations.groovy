/**
 * Script Name: MutationRelation
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script analyzes integration flows and determines which application-to-interface relationships should be added in LeanIX.
 *              It uses value mapping, existing application and interface IDs, and generates GraphQL mutations or a simulation output accordingly.
 * 
 * Notes:
 * - Only the first valid sender is processed.
 * - All receivers are processed individually.
 * - Relationships are only added if they do not already exist.
 * - Detailed logs are created per flow for traceability.
 */

import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import groovy.json.JsonOutput

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def traceLevel = message.getProperty("TraceLevel")
    def isSimulation = message.getProperty("isSimulationModeActive") == "true"

    // Read input hash maps from message properties
    def appIdMap = message.getProperty("ApplicationIDHashMap") ?: [:]
    def interfaceIdMap = message.getProperty("FactSheetMap") ?: [:]
    def relationMap = message.getProperty("RelationHashMap") ?: [:]

    def xml = new XmlSlurper().parseText(message.getBody(String))
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)

    def mutationBlocks = []
    def flowLogLines = []
    def applicationRelationResult = [:]
    def patchCounter = 1

    xml.Flows.Flow.each { flow ->
        def flowId = flow.Id.text()?.trim()
        if (!flowId) return

       def interfaceId = interfaceIdMap[flowId]

    if (!interfaceId) {
    def sender = flow.Sender.text()?.trim()
    def receivers = (flow.Receiver.text()?.split(",") ?: []).collect { it.trim() }.findAll { it }

    if (!sender && receivers.isEmpty()) {
    return
    }

    if (isSimulation) {
        def line = new StringBuilder()
        line << "FactSheet \"${flowId}\" (\"NEW_INTERFACE\") would be created and extended with"

        if (sender) {
            line << " sender application"
            line << " \"${sender}\""
        }

        if (receivers) {
            if (sender) line << " and"
            line << " receiver application"
            line << (receivers.size() > 1 ? "s " : " ")
            line << "\"${receivers.join('\" and \"')}\""
        }

        line << "."

        flowLogLines << line.toString()
        return
        } else {
        if (traceLevel == "debug" && messageLog) {
            messageLog.addAttachmentAsString("Skipped Flow", "No matching FactSheet ID for Flow ID: ${flowId}", "text/plain")
            }
        return
        }
    }   
    
        def existingAppIds = relationMap[flowId] ?: []
        def applicationsToAddAsProvider = []
        def applicationsToAddAsConsumer = []

        // Process sender (only the first valid one)
        def firstSender = (flow.Sender.text()?.split(",") ?: []).collect { it.trim() }.find { it }
        if (firstSender) {
            def mappedSender = valueMapApi.getMappedValue("SAPCI_Component", "Name", firstSender, "LeanIX_Application", "Label")
            def senderOptions = [firstSender]
            if (mappedSender?.trim() && mappedSender.trim() != "...") {
                senderOptions << mappedSender.trim()
            }

            def matchedId = senderOptions.collect { appIdMap[it] }.find { it }
            if (matchedId && !existingAppIds.contains(matchedId)) {
                applicationsToAddAsProvider << firstSender
                if (!isSimulation) {
                    mutationBlocks << buildSingleMutation(interfaceId, "relInterfaceToProviderApplication", matchedId, patchCounter++)
                }
            }
        }

        // Process receivers (all valid entries)
        def receivers = (flow.Receiver.text()?.split(",") ?: []).collect { it.trim() }.findAll { it }
        receivers.each { receiver ->
            def mappedReceiver = valueMapApi.getMappedValue("SAPCI_Component", "Name", receiver, "LeanIX_Application", "Label")
            def receiverOptions = [receiver]
            if (mappedReceiver?.trim() && mappedReceiver.trim() != "...") {
                receiverOptions << mappedReceiver.trim()
            }

            def matchedId = receiverOptions.collect { appIdMap[it] }.find { it }
            if (matchedId && !existingAppIds.contains(matchedId)) {
                applicationsToAddAsConsumer << receiver
                if (!isSimulation) {
                    mutationBlocks << buildSingleMutation(interfaceId, "relInterfaceToConsumerApplication", matchedId, patchCounter++)
                }
            }
        }

        // Create trace log per flow
        def line = new StringBuilder()
        if (applicationsToAddAsProvider || applicationsToAddAsConsumer) {
            line << "FactSheet \"${flowId}\" (\"${interfaceId}\") "
            line << (isSimulation ? "would be extended with" : "was extended with")
            if (applicationsToAddAsProvider) {
                line << " sender application"
                line << (applicationsToAddAsProvider.size() > 1 ? "s " : " ")
                line << "\"${applicationsToAddAsProvider.join(' and ')}\""
            }
            if (applicationsToAddAsConsumer) {
                if (applicationsToAddAsProvider) line << " and"
                line << " receiver application"
                line << (applicationsToAddAsConsumer.size() > 1 ? "s " : " ")
                line << "\"${applicationsToAddAsConsumer.join(' and ')}\""
            }
            line << "."
        } else {
            line << "FactSheet \"${flowId}\" (\"${interfaceId}\") has no relation updates."
        }

        flowLogLines << line.toString()

        // Store results for later use (non-simulation mode only)
        if (!isSimulation) {
            def resultEntries = []
            resultEntries.addAll(applicationsToAddAsProvider.collect { "Sender, ${it}" })
            resultEntries.addAll(applicationsToAddAsConsumer.collect { "Receiver, ${it}" })
            def relationKey = "${flowId} (${interfaceId})"
            applicationRelationResult[relationKey] = resultEntries ? resultEntries.join(", ") : "no Update"
        }
    }

    // Set output properties and body
    def simOutput = flowLogLines.join("\n")
    message.setProperty("RelationSimulationOutput", simOutput)

    if (isSimulation) {
        message.setBody(simOutput)
    } else {
        message.setProperty("ApplicationRelationResult", applicationRelationResult)

        if (!mutationBlocks.isEmpty()) {
            def fullMutation = "mutation {\n" + mutationBlocks.join("\n\n") + "\n}"
            message.setBody(JsonOutput.toJson([query: fullMutation]))
        } else {
            message.setProperty("NoRelationUpdate", "true")
            message.setBody("No relation updates required. All sender and receiver applications already exist in LeanIX or no match found.")
        }
    }

    return message
}

// Helper method to generate a LeanIX GraphQL mutation block
def buildSingleMutation(String interfaceId, String path, String appId, int patchIndex) {
    return """  upd${patchIndex}: updateFactSheet(id: "${interfaceId}", validateOnly: false, comment: "Auto relation via SAP CPI", patches: [
    {
      op: add,
      path: "/${path}/new_${patchIndex}",
      value: "{\\\"factSheetId\\\": \\\"${appId}\\\"}"
    }
  ]) {
    factSheet {
      id
      name
    }
  }"""
}
