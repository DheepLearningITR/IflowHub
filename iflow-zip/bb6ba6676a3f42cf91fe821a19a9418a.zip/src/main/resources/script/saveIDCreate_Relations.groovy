/**
 * Script Name: saveIdCreate
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script processes the JSON response from createFactSheet mutation.
 *              It extracts the name and ID of the created FactSheet and constructs an XML structure
 *              which is then set as the new message body.
 * 
 * Notes:
 * - The script expects the structure.
 * - If name or ID are missing, a RuntimeException is thrown.
 * - XML entities are safely escaped using a helper method.
 */

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    def factSheet = json.data?.createFactSheet?.factSheet

    if (!factSheet) {
        throw new RuntimeException("No createFactSheet -> factSheet found in JSON!")
    }

    def name = factSheet.name
    def id = factSheet.id

    if (!name || !id) {
        throw new RuntimeException("Name or Id missing in createFactSheet!")
    }

    def applicationsXml = new StringBuilder()
    applicationsXml << "<?xml version='1.0' encoding='UTF-8'?>"
    applicationsXml << "<Applications>"
    applicationsXml << "<Application>"
    applicationsXml << "<create>"
    applicationsXml << "<Name>${escapeXml(name)}</Name>"
    applicationsXml << "<Id>${escapeXml(id)}</Id>"
    applicationsXml << "</create>"
    applicationsXml << "</Application>"
    applicationsXml << "</Applications>"

    message.setBody(applicationsXml.toString())
    return message
}

// Escapes XML special characters in a string
def escapeXml(String input) {
    input.replace("&", "&amp;")
         .replace("<", "&lt;")
         .replace(">", "&gt;")
         .replace("\"", "&quot;")
         .replace("'", "&apos;")
}
