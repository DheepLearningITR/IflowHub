/**
 * Script Name: checkLeanIXCreateResponse
 * Author: Christian Riesener
 * Date: 2024-05-10
 * Description: This script processes responses from LeanIX FactSheet creation requests by parsing JSON response. It extracts the FactSheet ID if the creation is successful and logs it.
 *              If there are errors in the creation process, it throws a runtime exception with the error details.
 * 
 * Modifications:
 * - 2024-05-13 - Comment added - Christian Riesener
 * 
 * Notes:
 * - Assumes response data is formatted in JSON and contains either a 'data' field with creation details or an 'errors' field indicating problems.
 * - The script uses JsonSlurper for parsing JSON.
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper

def Message processData(Message message) {
    
    // Initialize a new instance of JsonSlurper for parsing JSON data.
    def jsonParser = new JsonSlurper();
    
    // Parse the JSON response data from the message body.
    def responseData = jsonParser.parseText(message.getBody(String));

    // Check if the JSON response contains no errors.
    if (!responseData.errors) {
        // Extract the FactSheet ID from the parsed JSON.
        def factSheetId = responseData.data.createFactSheet.factSheet.id;
        
        // Set the extracted FactSheet ID as a property of the message for further processing.
        message.setProperty("factSheetId", factSheetId);
    } else {
        // Throw a runtime exception with a detailed error message if the creation was not successful.
        throw new RuntimeException("Create of FactSheet wasn't successful - see LeanIX response: ${message.getBody(String)}")
    }
    
    // Return the message, modified with the new FactSheet ID if applicable.
    return message;
}
