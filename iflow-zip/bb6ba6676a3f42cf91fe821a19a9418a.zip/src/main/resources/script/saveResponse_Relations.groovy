/**
 * Script Name: SaveResponseRelation
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script formats the final output from the previously collected relation results.
 *              It transforms the internal application-to-interface relation results into a human-readable summary string.
 * 
 * Notes:
 * - It reads the property "ApplicationRelationResult" containing flow-to-application relation info.
 * - If no update occurred, the flow is noted as unchanged.
 * - If sender or receiver applications were added, they are listed accordingly.
 * - The result is written into the message body as plain text.
 */

import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    def relationResult = message.getProperty("ApplicationRelationResult") as Map ?: [:]
    def output = new StringBuilder()

    // Iterate over each relation result entry
    relationResult.each { factSheetLabel, relationInfo ->
        // Extract flow name and FactSheet ID from label
        def matcher = factSheetLabel =~ /(.*)\s+\(([^)]+)\)$/
        def flowName = matcher.matches() ? matcher[0][1] : factSheetLabel
        def factSheetId = matcher.matches() ? matcher[0][2] : "UNKNOWN_ID"

        if (relationInfo == "no Update") {
            // No update needed for this FactSheet
            output << "FactSheet \"${flowName}\" (\"${factSheetId}\") has no relation update.\n"
        } else {
            // Process updated sender and receiver information
            def entries = relationInfo.split(/\s*,\s*/).toList()
            def senders = []
            def receivers = []

            for (int i = 0; i < entries.size(); i += 2) {
                def type = entries[i]
                def appName = (i + 1 < entries.size()) ? entries[i + 1] : null
                if (appName) {
                    if (type.equalsIgnoreCase("Sender")) {
                        senders << appName
                    } else if (type.equalsIgnoreCase("Receiver")) {
                        receivers << appName
                    }
                }
            }

            // Construct the output line for this FactSheet
            if (!senders.isEmpty() || !receivers.isEmpty()) {
                output << "FactSheet \"${flowName}\" (\"${factSheetId}\") was extended with"
                if (!senders.isEmpty()) {
                    output << " Sender application"
                    output << (senders.size() > 1 ? "s " : " ")
                    output << "\"${senders.join('\" and \"')}\""
                }
                if (!receivers.isEmpty()) {
                    if (!senders.isEmpty()) output << " and"
                    output << " Receiver application"
                    output << (receivers.size() > 1 ? "s " : " ")
                    output << "\"${receivers.join('\" and \"')}\""
                }
                output << ".\n"
            }
        }
    }

    // Set formatted result as message body
    message.setBody(output.toString())
    return message
}
