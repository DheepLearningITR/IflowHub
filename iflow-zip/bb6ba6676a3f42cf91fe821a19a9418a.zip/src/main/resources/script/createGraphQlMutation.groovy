/**
 * Script Name: createGraphQlMutation
 * Author: Christian Riesener
 * Date: 2024-05-10
 * Description: This script constructs a JSON mutation request to create FactSheets in based on provided properties such as the FactSheet name.
 *              It logs the request detail if the trace level is set to debug, ensuring transparency and aiding in debugging.
 * 
 * Modifications:
 * - 2024-05-13 - Comment added - Christian Riesener
 * 
 * Notes:
 * - This script dynamically constructs a GraphQL mutation for creating a FactSheet.
 * - The mutation request is logged when the trace level is set to debug for detailed analysis.
 * - Utilizes JsonBuilder to programmatically build JSON structures.
 * - The property factSheetName was defined in script determineExternalId.groovy
*/
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder

def Message processData(Message message) {

    // Retrieve the message log object for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // Get the trace level and FactSheet name from message properties.
    def traceLevel = message.getProperty("TraceLevel");
    def factSheetName = message.getProperty("factSheetName");

    // Create a new JSON object for the GraphQL mutation request using JsonBuilder.
    def jsonCreate = new JsonBuilder()
    jsonCreate {
        query "mutation { createFactSheet(input: { type: Interface, name: \"${factSheetName.toString()}\" } ) { factSheet{ id name} }}"
    }

    // Set the constructed JSON as the message body to be processed downstream.
    message.setBody(jsonCreate.toString());
    
    // If the trace level is debug, add the JSON request as an attachment to the message log for detailed review.
   if (traceLevel == "debug") {
        messageLog.addAttachmentAsString("LeanIX Mutation Create Request", jsonCreate.toString(), "text/plain");
    }

    // Return the modified message.
    return message;
}
