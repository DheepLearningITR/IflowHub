/**
 * Script Name: exceptionInLocalProcess
 * Author: Christian Riesener
 * Date: 2024-05-18
 * Description: This script is designed, in case of an exception, to create a detailed log with all available data- It captures the body, headers (excluding sensitive ones),
 *              and properties of the message, formatting them for clarity and compliance with security standards.
 *
 * Modifications:
 *
 * Notes:
 * - The script excludes sensitive headers like 'Authentication' and 'Authorization' to safeguard security.
 * - Utilizes StringBuilder for constructing a clear and detailed textual representation of the message content.
 * - Logs are added as plain text attachments, making them easy to access and review.
 */

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    // Retrieve the message log object and utilize it if available.
    messageLogFactory.getMessageLog(message)?.with {
        // Construct a string with detailed information about the message.
        def content = new StringBuilder().with {
            it << "Body".padRight(60, '-').padLeft(70, '-') + "\n"
            it << message.getBody(String) + "\n\n"
            it << "Headers".padRight(60, '-').padLeft(70, '-') + "\n"
            // Apply a custom mapping function to filter and format message headers.
            it << map(message.getHeaders().findAll { !["Authentication", "Authorization"].contains(it.key)})
            it << "Properties".padRight(60, '-').padLeft(70, '-') + "\n"
            // Format message properties using the same mapping function.
            it << map(message.getProperties())
        }
        
        // Attach the constructed content as a plain text file to the message log for auditing purposes.
        it.addAttachmentAsString("Exception Log", content.toString(), "text/plain");
    }

    // Return the modified message.
    return message;
}

// Helper function 'map' to format map data into a structured, readable string.
def String map(Map map) {
    // Sort map entries by key in a case-insensitive manner and format each entry with its type and value.
    return map
        .sort { a, b -> a.key.toLowerCase() <=> b.key.toLowerCase() }
        .collect{ "$it.key (${it.value.getClass().getSimpleName()}): $it.value" }
        .join("\n") + "\n\n"
}
