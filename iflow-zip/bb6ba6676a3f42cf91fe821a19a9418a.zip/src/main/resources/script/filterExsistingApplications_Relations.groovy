/**
 * Script Name: filterExsistingApplications
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script processes a JSON response from LeanIX containing FactSheet data and builds a mapping of external IDs 
 *              to display names and internal IDs. It then parses an existing XML structure from a message property to extract sender 
 *              and receiver applications, and finally generates a new XML body with matched application IDs.
 * 
 * Notes: 
 * - The mapping is stored in a message property ("ApplicationMap") for downstream usage.
 * - The flowResponse property is expected to be a well-formed XML string.
 * - Only the first sender per flow is considered for mapping to match LeanIX constraints.
 * - Applications without a matching ID in the map are included with empty IDs in the generated XML.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder
import javax.xml.parsers.DocumentBuilderFactory

Message processData(Message message) {

    // Parse JSON and build externalId-to-FactSheet mapping
    def jsonSlurper = new JsonSlurper()
    def jsonBody = message.getBody(String)
    def json = jsonSlurper.parseText(jsonBody)

    // Map: externalId -> [displayName, id, tags]
    def applicationMap = [:]

    json.data.allFactSheets.edges.each { edge ->
        def node = edge.node
        def externalIdField = node.externalId

        if (externalIdField && externalIdField.externalId) {
            def extId = externalIdField.externalId.trim()
            def displayName = node.displayName
            def factSheetId = node.id
            def tags = node.tags

            def cleanedTags = ""
            if (tags instanceof List && !tags.isEmpty()) {
                cleanedTags = tags.collect { cleanTags(it) }.join(", ")
            }

            if (extId) {
                applicationMap[extId] = [
                    displayName: displayName,
                    id: factSheetId,
                    tags: cleanedTags
                ]
            }
        }
    }

    message.setProperty("ApplicationMap", applicationMap)

    def flowResponseXML = message.getProperty("flowResponse")

    def xmlParser = DocumentBuilderFactory.newInstance().newDocumentBuilder()
    def xmlDoc = xmlParser.parse(new ByteArrayInputStream(flowResponseXML.getBytes("UTF-8")))

    def senderList = []
    def receiverList = []

    def flowNodes = xmlDoc.getElementsByTagName("Flow")
    for (int i = 0; i < flowNodes.getLength(); i++) {
        def flowNode = flowNodes.item(i)

        def sender = flowNode.getElementsByTagName("Sender").item(0)?.getTextContent()
        def receiver = flowNode.getElementsByTagName("Receiver").item(0)?.getTextContent()

        if (sender) {
            def firstSender = sender.split(",").collect { it.trim() }.find { it }
            if (firstSender) {
                senderList << firstSender
            }
        }

        if (receiver) {
            receiverList.addAll(receiver.split(",").collect { it.trim() })
        }
    }

    def allApps = (senderList + receiverList).unique()

    def writer = new StringWriter()
    def xmlBuilder = new MarkupBuilder(writer)

    xmlBuilder.Applications {
        allApps.each { appName ->
            def match = applicationMap[appName]
            Application {
                Name(appName)
                Id(match?.id ?: "")
                Tag(match?.tags ?: "")
            }
        }
    }

    message.setBody(writer.toString())
    return message
}

def cleanTags(def tagObj) {
    if (tagObj instanceof Map && tagObj.name) {
        return tagObj.name.toString().trim()
    } else if (tagObj instanceof String) {
        return tagObj.trim()
    }
    return ""
}
