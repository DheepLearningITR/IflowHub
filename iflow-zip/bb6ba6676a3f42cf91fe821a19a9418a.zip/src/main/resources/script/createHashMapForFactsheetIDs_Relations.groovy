/**
 * Script Name: createHashMapForFactsheetsIds
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: Parses XML payload to extract application names and IDs.
 *              Stores them in a HashMap for later steps.
 *              Logs either a simulation output or actual operation log.
 */

import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def isSimulation = message.getProperty("isSimulationModeActive") == "true"
    def messageLog = messageLogFactory.getMessageLog(message)

    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)

    def applicationIdMap = new HashMap<String, String>()
    def flowLogLines = []

    xml.'**'.findAll { it.name() == 'Application' }.each { application ->
        def createNode = application.create
        def updateNode = application.update
        def name, id

        if (createNode && createNode.size() > 0) {
            name = createNode.Name.text()?.trim()
            id = createNode.Id.text()?.trim()
            if (isSimulation) {
                flowLogLines << "Application \"${name}\" (${id}) would be created."
            } else {
                flowLogLines << "Application \"${name}\" (${id}) was created."
            }
            applicationIdMap.put(name, id)

        } else if (updateNode && updateNode.size() > 0) {
            name = updateNode.Name.text()?.trim()
            id = updateNode.Id.text()?.trim()
            if (isSimulation) {
                flowLogLines << "Application \"${name}\" (${id}) would be updated."
            } else {
                flowLogLines << "Application \"${name}\" (${id}) was updated."
            }
            applicationIdMap.put(name, id)

        } else {
            name = application.Name.text()?.trim()
            id = application.Id.text()?.trim()
            flowLogLines << "Application \"${name}\" (${id}) had no updates."
            applicationIdMap.put(name, id)
        }
    }

    message.setProperty("ApplicationIDHashMap", applicationIdMap)

    if (messageLog) {
        def headerTitle = isSimulation ? "Simulation Output Application" : "FlowLogApplications"
        def logHeader = new StringBuilder()

        if (isSimulation) {
            logHeader << """\
======================================================================================================================================
                                                           Simulation Output Applications
======================================================================================================================================
This output shows which sender and receiver applications would be created or updated.
It is based on technical names and optional mapping results.
"""
        } else {
            logHeader << """\
======================================================================================================================================
                                                       FlowLogApplications
======================================================================================================================================
This output shows which sender and receiver applications were created or updated.
It is based on technical names and optional mapping results.
"""
        }

        def separator = "\n" + "-".multiply(120) + "\n\n"
        def finalOutput = logHeader.toString() + separator + flowLogLines.join("\n")

        messageLog.addAttachmentAsString(headerTitle, finalOutput, "text/plain")
    }

    return message
}
