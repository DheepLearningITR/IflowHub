/**
 * Script Name: checkLeanIXUpdateResponse
 * Author: Christian Riesener
 * Date: 2024-05-10
 * Description: This script logs LeanIX responses from mutation requests (e.g., updates to FactSheets). It employs conditional logging based on the trace level,
 *              handles errors by throwing exceptions, and supports simulation mode for testing purposes.
 * 
 * Modifications:
 * - 2024-05-13 - Comment added - Christian Riesener
 * 
 * Notes:
 * - This script checks the 'TraceLevel' property to decide whether to log the full response for debugging.
 * - Errors in the mutation response trigger a RuntimeException, clearly indicating process failures.
 * - In simulation mode, the response body is replaced with predefined simulation output for safe testing.
 * - The script uses JsonSlurper for JSON parsing.
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper

def Message processData(Message message) {

    // Retrieve the message log object for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    // Retrieve the trace level from the message properties to control logging detail.
    def traceLevel = message.getProperty("TraceLevel");
    // Check if simulation mode is activated based on a message property.
    def isSimulationModeActive = message.getProperty("isSimulationModeActive").toBoolean();
    // Obtain any pre-defined simulation output, or initialize a new StringBuilder if none exists.
    def simulationOutput = message.getProperty("simulationOutput") ?: new StringBuilder();

    if (!isSimulationModeActive) {
        // Initialize a new instance of JsonSlurper for parsing JSON data.
        def jsonParser = new JsonSlurper();
        // Parse the JSON response data from the message body.
        def responseData = jsonParser.parseText(message.getBody(String));
    
        // in case of an error add Request and Response to be able to analyze the problem
        if (responseData.errors) {
            if (traceLevel != "debug") {
                messageLog.addAttachmentAsString("LeanIX Mutation Request",  message.getProperty("mutationRequest"), "text/plain");    
            }
            messageLog.addAttachmentAsString("LeanIX Mutation Response", message.getBody(String), "text/plain");
            //Exception not necessary but clear simulationOutput - should only contain successful entries
            //throw new RuntimeException("Update of FactSheet wasn't successfull - see LeanIX Mutation Request & Response: ${message.getBody(String)}");
            simulationOutput = new StringBuilder();

        } else {
            // If trace level is set to debug, log the entire response for detailed debugging.
            if (traceLevel == "debug" && !isSimulationModeActive) {
                messageLog.addAttachmentAsString("LeanIX Mutation Response", message.getBody(String), "text/plain");
            }        
        }
    }
    
    // replace the message body with the simulation output or flow log output.    
    message.setBody(simulationOutput);
    
    // Return the possibly modified message.    
    return message;
}