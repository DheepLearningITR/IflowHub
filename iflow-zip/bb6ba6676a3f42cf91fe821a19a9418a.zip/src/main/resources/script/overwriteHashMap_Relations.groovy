/**
 * Script Name: overwriteHashmap
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: Parses JSON response to extract application identifiers and their relationships.
 *              Builds two hash maps:
 *              - One for externalId -> internalId
 *              - One for externalId -> related application IDs
 */

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message)
    def traceLevel = message.getProperty("TraceLevel")

    HashMap<String, String> factSheetMap = new HashMap<>()
    HashMap<String, List<String>> relationMap = new HashMap<>()

    def jsonResponse = message.getBody(String)
    def json = new JsonSlurper().parseText(jsonResponse)

    json.data.allFactSheets.edges.each { edge ->
        def node = edge.node
        def externalId = node.externalId?.externalId

        if (externalId) {
            factSheetMap.put(externalId, node.id)

            // Collect sender IDs
            def senderIds = node.relInterfaceToProviderApplication?.edges?.collect {
                it.node?.factSheet?.id
            }?.findAll { it } ?: []

            // Collect receiver IDs
            def receiverIds = node.relInterfaceToConsumerApplication?.edges?.collect {
                it.node?.factSheet?.id
            }?.findAll { it } ?: []

            // Combine all related application IDs
            def relatedApps = (senderIds + receiverIds).unique()

            if (!relatedApps.isEmpty()) {
                relationMap.put(externalId, relatedApps)
            }
        }
    }

    message.setProperty("FactSheetMap", factSheetMap)
    message.setProperty("RelationHashMap", relationMap)

    if (traceLevel == "debug" && messageLog) {
        def fsContent = factSheetMap.collect { k, v -> "$k: $v" }.join("\n")
        def relContent = relationMap.collect { k, v -> "$k: ${v.join(', ')}" }.join("\n")

        messageLog.addAttachmentAsString("Updated FactSheetMap", fsContent, "text/plain")
        messageLog.addAttachmentAsString("Updated RelationHashMap", relContent, "text/plain")
    }

    return message
}
