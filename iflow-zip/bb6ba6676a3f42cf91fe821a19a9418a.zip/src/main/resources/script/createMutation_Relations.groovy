/**
 * Script Name: createMutation
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script generates a GraphQL mutation payload for creating a new Application FactSheet.
 *              It reads the application name from the input XML, performs a value mapping if available, and constructs
 *              the required JSON structure including external ID and description.
 * 
 * Notes:
 * - The external ID is serialized as a JSON string as required.
 * - ValueMapping is used to transform the name if a valid mapping exists.
 */

import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import groovy.json.JsonOutput

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def traceLevel = message.getProperty("TraceLevel")
    def tagName = message.getProperty("TagNameApplication")?.toString()?.trim()

    def xml = new XmlSlurper().parseText(message.getBody(String))
    def application = xml.'**'.find { it.name() == 'Application' }

    if (!application) {
        throw new RuntimeException("No Application element found in input XML.")
    }

    def currentName = application.create.Name.text()

    if (!currentName) {
        throw new RuntimeException("Application Name missing in the input XML.")
    }

    // Retrieve mapped name if available
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def mappedName = valueMapApi.getMappedValue("SAPCI_Component", "Name", currentName, "LeanIX_Application", "Label")

    def finalName = (mappedName && mappedName.trim() != "..." && mappedName.trim()) ? mappedName.trim() : currentName

    // Format externalId as a proper JSON string
    def externalIdJsonString = JsonOutput.toJson([
        type      : "ExternalId",
        externalId: currentName
    ])

    // Prepare patch list
    def patchList = [
        [
            op   : "add",
            path : "/description",
            value: "Factsheet created automatically by SAP Cloud Integration"
        ],
        [
            op   : "add",
            path : "/externalId",
            value: externalIdJsonString
        ]
    ]

    // Add tag patch if tagName is present
    if (tagName) {
        def tagJson = JsonOutput.toJson([
            [tagName: tagName]
        ])
        patchList << [
            op   : "add",
            path : "/tags",
            value: tagJson
        ]
    }

    // Build final GraphQL payload
    def graphqlBody = [
        variables: [
            input  : [
                type: "Application",
                name: finalName
            ],
            patches: patchList
        ]
    ]

    def jsonBody = JsonOutput.toJson(graphqlBody)
    message.setBody(jsonBody)

    // Debug log
    if (traceLevel == "debug" && messageLog) {
        messageLog.addAttachmentAsString("LeanIX Create Payload", jsonBody, "application/json")
    }

    return message
}
