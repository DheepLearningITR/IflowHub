/**
 * Script Name: saveIdUpdate
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script processes the JSON response from updateFactSheet mutation.
 *              It checks for a duplicate error or extracts the updated FactSheet's name and ID.
 *              Based on the condition, it builds a corresponding XML response structure.
 * 
 * Notes:
 * - If a "already exists" error is found, the name is taken from the message property "applicationtoupdate".
 * - If update was successful, name and ID from factSheet are used.
 */

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    def factSheet = json.data?.updateFactSheet?.factSheet
    def errorMsg = json.errors?.find { it.message?.contains("already exists") }

    def applicationsXml = new StringBuilder()
    applicationsXml << "<?xml version='1.0' encoding='UTF-8'?>"
    applicationsXml << "<Applications>"
    applicationsXml << "<Application>"

    if (errorMsg) {
        // Duplicate error case -> use name from property
        def duplicateName = message.getProperty("applicationtoupdate") ?: "UNKNOWN"
        applicationsXml << "<duplicate>"
        applicationsXml << "<Name>${escapeXml(duplicateName)}</Name>"
        applicationsXml << "</duplicate>"
    } else if (factSheet && factSheet.name && factSheet.id) {
        // Normal case -> data from updateFactSheet
        applicationsXml << "<update>"
        applicationsXml << "<Name>${escapeXml(factSheet.name)}</Name>"
        applicationsXml << "<Id>${escapeXml(factSheet.id)}</Id>"
        applicationsXml << "</update>"
    } else {
        // Fallback case for incomplete JSON without a duplicate error
        applicationsXml << "<error>"
        applicationsXml << "<message>Incomplete or missing updateFactSheet data</message>"
        applicationsXml << "</error>"
    }

    applicationsXml << "</Application>"
    applicationsXml << "</Applications>"

    message.setBody(applicationsXml.toString())
    return message
}

// Escapes XML special characters in a string
def escapeXml(String input) {
    input?.replace("&", "&amp;")
          ?.replace("<", "&lt;")
          ?.replace(">", "&gt;")
          ?.replace("\"", "&quot;")
          ?.replace("'", "&apos;")
}
