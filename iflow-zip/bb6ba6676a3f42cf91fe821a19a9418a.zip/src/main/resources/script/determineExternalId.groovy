/**
 * Script Name: determineExternalId
 * Author: Christian Riesener
 * Date: 2024-05-10
 * Description: This script processes incoming SAP ICO XML messages to generate informaton of the interfaces and their corresponding descriptions for LeanIX.
 *              It constructs a FactSheet name based on existing LeanIX descriptions, handles simulation output for testing, and prepares properties for further processing.
 * 
 * Modifications:
 * - 2024-05-13 - Comment added - Christian Riesener
 * - 2024-05-26 - Changed Create/Update to Batch Runs - Christian Riesener
 * - 2024-11-13 - Added TagName/version Variable
 * - 2025-03-06 - Tag added only if value exist
 * 
 * Notes:
 * - The script parses XML to extract interface details, utilizes value mapping for descriptions, and checks the existence of corresponding FactSheets in LeanIX.
 * - It dynamically generates and applies a unique hash GUID for interfaces to manage FactSheet identification.
 * - The script also provides simulation capabilities for testing without impacting live data, along with detailed debug outputs.
 * - During message processing, a mutation request for LeanIX is created, which either creates a new FactSheet or updates an existing one.
 * - If the trace level is set to "debug", the script attaches the output as an attachment to the message log for detailed review.
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.security.MessageDigest;
import groovy.json.JsonBuilder;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def isCreationNeeded = false;

def Message processData(Message message) {

    def simulationOutput = new StringBuilder();
    def traceLevel = message.getProperty("TraceLevel");
    def messageLog = messageLogFactory.getMessageLog(message);
    
    HashMap<String, String> factSheetMap = new HashMap<>();
    factSheetMap = message.getProperty("FactSheetMap");
    def jsonMutation = new JsonBuilder();
    
    
    // Check if Interface is already existing in LeanIX by checking with the externalId
    def xml = new XmlSlurper().parseText(message.getBody(String));
    
    def flows = xml.'**'.findAll { it.name() == 'Flow' };

    def factSheetNames = [];
    def counter = 0;
    def mutation_requests = new StringBuilder ("mutation { ");
    flows.each { flow ->  
            counter++
            createOutput(flow, factSheetMap, message, factSheetNames, simulationOutput, mutation_requests, counter);
    }
    
    def mutation_end = " } ";
    jsonMutation {
        query mutation_requests.toString() + mutation_end
    }
    
    // Save simulationOutput
    message.setProperty("simulationOutput", simulationOutput);
    
    // Save Mutation Request in case of errors
    message.setProperty("mutationRequest", jsonMutation.toString());
    
    // If the trace level is debug, add the JSON request as an attachment to the message log for detailed review.
    if (traceLevel == "debug") {
        messageLog.addAttachmentAsString("LeanIX Mutation Request", jsonMutation.toString(), "text/plain");
    }
    
    message.setBody(jsonMutation.toString());

    return message
}

def StringBuilder buildDescription(def flow, def lineFeed) {
    def description = new StringBuilder();
    
    description << "FactSheet Description:" + lineFeed;
    description << "Automatically generated Description by SAP Cloud Integration" + lineFeed + lineFeed;
    description << "Technical Details from SAP Cloud Integration" + lineFeed + lineFeed;
    description << "Flow Name: ${flow.Name.text()}" + lineFeed;
    description << "Flow Id: ${flow.Id.text()}" + lineFeed;
    description << "Sender: ${flow.Sender.text()}" + lineFeed;
    description << "Receiver: ${flow.Receiver.text()}" + lineFeed;
    description << "PackageId: ${flow.PackageId.text()}" + lineFeed;
    description << "Version: ${flow.Version.text()}" + lineFeed;
    if (lineFeed == '\\n') {
        description << "Description: ${flow.Description.text().replace("\n","\\n")}" + lineFeed;
    } else {
        description << "Description: ${flow.Description.text()}" + lineFeed;
    }
    
    return description;

}

def createOutput(def flow, def factSheetMap, def message, def factSheetNames, def simulationOutput, def mutation_requests, def counter) {
    
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    def subType = message.getProperty("LeanIX_FactSheet_Subtype");
    
    def flowId = flow.Id.text() ?: "";
    def flowName = flow.Name.text() ?: "";
    def flowDescription = flow.Description.text() ?: "";
    def flowVersion = flow.Version.text() ?: "";
    def flowPackageId = flow.PackageId.text() ?: "";
    def sender = flow.Sender.text().split(",") ?: [];
    def receiver = flow.Receiver.text().split(",") ?: [];
    def tagname = message.getProperty("TagName");

    
    simulationOutput << "\n--------------------------------------------------------------------------------------------------------------------------------------\n";
    simulationOutput << "\n*** Technical Details from SAP Cloud Integration ***\n";
    simulationOutput << "Sender: ${sender}\n";
    simulationOutput << "Receiver: ${receiver}\n";
    simulationOutput << "Flow: ${flowName}\n";
    simulationOutput << "Flow ID: ${flowId}\n";
    simulationOutput << "Package: ${flowPackageId}\n";
    simulationOutput << "Version: ${flowVersion}\n";
    simulationOutput << "Description: ${flowDescription}\n\n";
    simulationOutput << "*** Checking if ValueMapping 'Value Mapping LeanIX Label for SAP CI' contains any replacements for technical Names ***\n";

   // Create Interface Texts and check if there is an LeanIX Label for this
    def labelFlow = valueMapApi.getMappedValue("SAPCI_Interface", "Name", flowName , "LeanIX_Interface", "Label");
    
   // Create Sender Texts
    def senderText = new StringBuilder();
    sender.eachWithIndex { item, index -> 
        if (item != "") {
            if (index > 0) {
                senderText << ", ";
            }
    
            // Check if there is an LeanIX Label for this sender
            def labelSender = valueMapApi.getMappedValue("SAPCI_Component", "Name", item , "LeanIX_Application", "Label");
            if (labelSender && labelSender != '...') {
                senderText << labelSender;
                simulationOutput << "Found LeanIX Label for ${item} : ${labelSender}\n";
            } else {
                senderText << item;
                simulationOutput << "Found no LeanIX Label for ${item} \n";
            }
        }
    }

    // Create Receiver Texts
    def receiverText = new StringBuilder();
    receiver.eachWithIndex { item, index -> 
        if (item != "") {
            if (index > 0) {
                receiverText << ", ";
            }
    
            // Check if there is an LeanIX Label for this receiver
            def labelReceiver = valueMapApi.getMappedValue("SAPCI_Component", "Name", item , "LeanIX_Application", "Label");
            if (labelReceiver && labelReceiver != '...') {
                receiverText << labelReceiver;
                simulationOutput << "Found LeanIX Label for ${item} : ${labelReceiver}\n";
            } else {
                receiverText << item;
                simulationOutput << "Found no LeanIX Label for ${item} \n";
            }
        }
    }

    simulationOutput << "\n*** Checking LeanIX if FactSheet already exists or if the Flow needs to create the FactSheet ***\n";
    def updateFactSheet = false;
    def factSheetId = factSheetMap.get(flowId);
    if (factSheetId) {
        message.setProperty("factSheetId", factSheetId)
        simulationOutput << "Interface FactSheet already exists with ID: ${factSheetId}\n";
        updateFactSheet = true;
    } else {
        simulationOutput << "Interface FactSheet doesn't exists and will be created\n";
    }

    // Generate FactSheet Name and reuse transport it via property to the other scripts which need the same logic
    def factSheetName = new StringBuilder();
    
    if (labelFlow && labelFlow != "...") {
        factSheetName << "${labelFlow}";
    } else {
        factSheetName << "${flowName}";
    }
    
    if (senderText.length() > 0 && !factSheetName.toString().contains(" from ")) {
        factSheetName << " from ${senderText}";
    }
    
    if (receiverText.length() > 0 && !factSheetName.toString().contains(" to ")) {
        factSheetName << " to ${receiverText}";
    }
    
    // Add FactSheet Name to Array
    factSheetNames.add(factSheetName);

    simulationOutput << "\n*** Preview of how the values would be created in LeanIX ***\n";
    simulationOutput << "FactSheet Name:\n";
    simulationOutput << factSheetName.toString() + "\n\n";
    simulationOutput << buildDescription(flow, "\n");
    simulationOutput << "\nExternalID:";
    simulationOutput << "\n${flowId}";
    // Build description and mutation request
    def description = buildDescription(flow, "\\n");
    

    
  if (updateFactSheet) {
    // Create Mutation Request for updating a FactSheet
    def mutation = " upd${counter}:  updateFactSheet(id: \"${factSheetId}\", validateOnly: false, comment: \"Adding data automatically via SAP CI Flow\", patches: [{ op: replace, path: \"/name\", value: \"${factSheetName}\" },{ op: add, path: \"/description\", value: \"${description}\" },{ op: add, path: \"/release\", value: \"${flowVersion}\" },{ op: add, path: \"/category\", value: \"${subType}\" }, { op: add, path: \"/externalId\", value: \"{\\\"comment\\\": null,\\\"externalId\\\": \\\"${flowId}\\\",\\\"externalUrl\\\": null,\\\"externalVersion\\\": null,\\\"status\\\": \\\"ACTIVE\\\" }\"} "

    // Tag wird nur hinzugefügt, wenn ein Wert gegeben ist
    if (tagname?.trim()) {
        mutation += ", { op: add, path: \"/tags\", value: \"[{\\\"tagName\\\": \\\"${tagname}\\\"}]\" } "
    }

    mutation += "]){ factSheet { id name category status description }}"

    mutation_requests << mutation
    
    } else {
    // Create Mutation Request for new FactSheet
    def mutation = " cre${counter}:  createFactSheet(input: { type: Interface, name: \"${factSheetName}\" } patches: [{ op: replace, path: \"/name\", value: \"${factSheetName}\" },{ op: add, path: \"/release\", value: \"${flowVersion}\" },{ op: add, path: \"/description\", value: \"${description}\" }, { op: add, path: \"/category\", value: \"${subType}\" },  { op: add, path: \"/externalId\", value: \"{\\\"comment\\\": null,\\\"externalId\\\": \\\"${flowId}\\\",\\\"externalUrl\\\": null,\\\"externalVersion\\\": null,\\\"status\\\": \\\"ACTIVE\\\" }\"} "

   // Tag wird nur hinzugefügt, wenn ein Wert gegeben ist
    if (tagname?.trim()) {
        mutation += ", { op: add, path: \"/tags\", value: \"[{\\\"tagName\\\": \\\"${tagname}\\\"}]\" } "
    }

    mutation += "]) { factSheet{ id name} }"

    mutation_requests << mutation
    }
}