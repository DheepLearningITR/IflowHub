/**
 * Script Name: AddSimulationOutputForRelation
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script formats the simulation or actual output of relation updates between interfaces and applications.
 *              It prepares a readable summary and attaches it to the message log for visibility during integration execution.
 * 
 * Notes:
 * - The script checks whether simulation mode is active to adjust the message header accordingly.
 * - It reads the current message body containing relation update information (plain text).
 * - Formatting enhancements ensure punctuation spacing is consistent and readable.
 * - The output is written back to the message body and attached to the message log.
 */

import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def isSimulation = message.getProperty("isSimulationModeActive")?.toString()?.toBoolean()
    def messageLog = messageLogFactory.getMessageLog(message)

    // Set log title depending on simulation mode
    def headerTitle = isSimulation ? "Simulation Output Relation" : "FlowLogApplicationRelation"

    // Build the header section of the output
    def logHeader = new StringBuilder()
    logHeader << "=".multiply(134) + "\n"
    logHeader << (isSimulation ? "Simulation Output Relation" : "FlowLogApplicationRelation").center(134) + "\n"
    logHeader << "=".multiply(134) + "\n"
    logHeader << (isSimulation 
        ? "This output shows which FactSheets would be updated in LeanIX based on interface and application relations from SAP CPI."
        : "This output shows which FactSheets were updated in LeanIX based on interface and application relations from SAP CPI.") + "\n"

    def separator = "\n" + "-".multiply(120) + "\n\n"
    def relationBlock = new StringBuilder()

    // Format the body content for better readability
    def bodyText = message.getBody(String)
    def formatted = bodyText
        .replaceAll(/(?<=\w)\.(?=\S)/, ". ") // Ensures space after a dot if followed by a word character
        .replaceAll(/(?<=\.) {2,}/, " ")     // Reduces multiple spaces after dots to a single space

    relationBlock << formatted

    // Combine all parts into final output
    def finalOutput = new StringBuilder()
    finalOutput << logHeader
    finalOutput << separator
    finalOutput << relationBlock.toString()

    // Set final output as message body
    message.setBody(finalOutput.toString())

    // Optionally log the output as an attachment
    if (messageLog) {
        messageLog.addAttachmentAsString(headerTitle, finalOutput.toString(), "text/plain")
    }

    return message
}
