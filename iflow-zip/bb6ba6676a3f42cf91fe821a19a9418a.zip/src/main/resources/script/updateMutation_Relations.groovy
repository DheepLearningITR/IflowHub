/**
 * Script Name: updateMutation
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script builds a GraphQL mutation payload to update an existing Application FactSheet.
 *              It extracts the application name and ID from the input XML, optionally applies a value mapping,
 *              and prepares a patch operation for the application name.
 * 
 * Notes:
 * - The FactSheet ID is stored in the property "updateFactsheetID" for later use.
 * - The resolved application name is stored in the property "applicationtoupdate".
 * - The GraphQL payload replaces the application's name based on mapping or original name.
 */

import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import groovy.json.JsonOutput

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def traceLevel = message.getProperty("TraceLevel")
    def tagName = message.getProperty("TagNameApplication")?.toString()?.trim()

    def xml = new XmlSlurper().parseText(message.getBody(String))
    def application = xml.'**'.find { it.name() == 'Application' }

    if (!application) {
        throw new RuntimeException("No Application element found in input XML.")
    }

    def currentName = application.update.Name.text()
    def factSheetId = application.update.Id.text()

    if (!currentName || !factSheetId) {
        throw new RuntimeException("Application Name or Id missing in the input XML.")
    }

    // Store FactSheet ID and resolved name
    message.setProperty("updateFactsheetID", factSheetId)

    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def mappedName = valueMapApi.getMappedValue("SAPCI_Component", "Name", currentName, "LeanIX_Application", "Label")
    def newName = (mappedName && mappedName.trim() != "..." && mappedName.trim()) ? mappedName.trim() : currentName

    message.setProperty("applicationtoupdate", newName)

    // Prepare patch list
    def patchList = [
        [
            op   : "replace",
            path : "/name",
            value: newName
        ]
    ]

    // Add tag patch if tagName is present
    if (tagName) {
        def tagJson = JsonOutput.toJson([
            [tagName: tagName]
        ])
        patchList << [
            op   : "add",
            path : "/tags",
            value: tagJson
        ]
    }

    // Build final GraphQL payload
    def graphqlBody = [
        variables: [
            patches: patchList
        ]
    ]

    def jsonBody = JsonOutput.toJson(graphqlBody)
    message.setBody(jsonBody)

    // Debug log
    if (traceLevel == "debug" && messageLog) {
        messageLog.addAttachmentAsString("LeanIX Update Payload", jsonBody, "application/json")
    }

    return message
}
