/**
 * Script Name: updateGraphQlMutation
 * Author: Christian Riesener
 * Date: 2024-05-19
 * Description: This script processes the SAP CI Flows constructing a detailed description and updating a FactSheet in LeanIX based on SAP Cloud Integration data.
 *              It uses the unique flow ID for external ID, constructs a comprehensive description, and forms a GraphQL mutation request to update FactSheets in LeanIX.
 *
 * Modifications:
 *
 * Notes:
 * - It utilizes XML parsing to extract interface details, regex for data extraction, and JSON construction for API interactions.
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder;
import java.security.MessageDigest;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def traceLevel = message.getProperty("TraceLevel");
    def factSheetName = message.getProperty("factSheetName");
    def isSimulationModeActive = message.getProperty("isSimulationModeActive").toBoolean();
    def simulationOutput = message.getProperty("simulationOutput") ?: new StringBuilder();

    // Retrieve ICO XML and other necessary properties
    def flowXML = message.getProperty("flowXML");
    def factSheetId = message.getProperty("factSheetId") ?: "default-id";
    def subType = message.getProperty("LeanIX_FactSheet_Subtype");

    // Read XML Values
    def xml = new XmlSlurper().parseText(flowXML);
    def flowId = xml.Flows.Flow.Id.text();

    // Build description and mutation request
    def description = buildDescription(xml, simulationOutput, isSimulationModeActive);
    def jsonUpdate = new JsonBuilder()
    if (subType != "")
    {
        jsonUpdate {
            query "mutation { updateFactSheet(id: \"${factSheetId}\", validateOnly: false, comment: \"Adding data automatically via SAP CI Flow\", patches: [{ op: replace, path: \"/name\", value: \"${factSheetName}\" },{ op: add, path: \"/description\", value: \"${description.toString()}\" }, { op: add, path: \"/category\", value: \"${subType}\" },  { op: add, path: \"/externalId\", value: \"{\\\"comment\\\": null,\\\"externalId\\\": \\\"${flowId}\\\",\\\"externalUrl\\\": null,\\\"externalVersion\\\": null,\\\"status\\\": \\\"ACTIVE\\\" }\"} ]){ factSheet { id name category status description }}}" 
        }
    } else {
       jsonUpdate {
            query "mutation { updateFactSheet(id: \"${factSheetId}\", validateOnly: false, comment: \"Adding data automatically via SAP CI Flow\", patches: [{ op: replace, path: \"/name\", value: \"${factSheetName}\" },{ op: add, path: \"/description\", value: \"${description.toString()}\" },  { op: add, path: \"/externalId\", value: \"{\\\"comment\\\": null,\\\"externalId\\\": \\\"${flowId}\\\",\\\"externalUrl\\\": null,\\\"externalVersion\\\": null,\\\"status\\\": \\\"ACTIVE\\\" }\"} ]){ factSheet { id name category status description }}}" 
        }
    }


    // Set mutation JSON as the message body
    message.setBody(jsonUpdate.toString());

    // Debug logging
    if (traceLevel == "debug") {
        messageLog.addAttachmentAsString("LeanIX Mutation Update Request", jsonUpdate.toString(), "text/plain");
    }

    // Handle simulation output
    if (isSimulationModeActive) {
        simulationOutput << "\nExternalID:";
        simulationOutput << "\n${flowId}";
        message.setProperty("simulationOutput", simulationOutput.toString());
    }

    return message;
}

def buildDescription(def xml, StringBuilder simulationOutput, boolean isSimulationMode) {
    
    StringBuilder description = new StringBuilder();
    if (isSimulationMode) simulationOutput<< "FactSheet Description:\n"
    description << "Automatically generated Description by SAP Cloud Integration\\n\\n";
    simulationOutput << "Automatically generated Description by SAP Cloud Integration\n\n";
    description << "Technical Details from SAP Cloud Integration\\n\\n";
    simulationOutput << "Technical Details from SAP Cloud Integration\n\n";
    description << "Flow Name: ${xml.Flows.Flow.Name.text()}\\n";
    simulationOutput << "Flow Name: ${xml.Flows.Flow.Name.text()}\n";
    description << "Flow Id: ${xml.Flows.Flow.Id.text()}\\n";
    simulationOutput << "Flow Id: ${xml.Flows.Flow.Id.text()}\n";
    description << "Sender: ${xml.Flows.Flow.Sender.text()}\\n";
    simulationOutput << "Sender: ${xml.Flows.Flow.Sender.text()}\n";
    description << "Receiver: ${xml.Flows.Flow.Receiver.text()}\\n";
    simulationOutput << "Receiver: ${xml.Flows.Flow.Receiver.text()}\n"; 
    description << "PackageId: ${xml.Flows.Flow.PackageId.text()}\\n";
    simulationOutput << "PackageId: ${xml.Flows.Flow.PackageId.text()}\n";
    description << "Version: ${xml.Flows.Flow.Version.text()}\\n";
    simulationOutput << "Version: ${xml.Flows.Flow.Version.text()}\n";
    description << "Description: ${xml.Flows.Flow.Description.text().replace("\n","\\n")}\\n";
    simulationOutput << "Description: ${xml.Flows.Flow.Description.text().replace("\n","\\n")}\n";

    return description;
}
