/**
 * Script Name: addSimulationToAttachment
 * Author: Christian Riesener
 * Date: 2024-05-10
 * Description: This script adds the result of an simulation run as attachment to the message
 * 
 * Modifications:
 * - 2024-05-13 - Comment added - Christian Riesener
 * 
 * Notes:
 * - This script will only be called if External Parameter isSimulationModeActive = true
 */

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    // Obtain the message log object associated with the current message for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    def isSimulationModeActive = message.getProperty("isSimulationModeActive").toBoolean();
    
        // Define the explanatory header
    def header = "";
    if (isSimulationModeActive) {
        header = """\
======================================================================================================================================
                                                           Simulation Output
======================================================================================================================================
This output serves to determine how the FactSheets would be created in LeanIX. It checks whether the FactSheets already exist and if 
LeanIX descriptions for applications or interfaces have been stored in SAP CI.
""";
    } else {
        header = """\
======================================================================================================================================
                                                                Flow Log
======================================================================================================================================
This output serves to determine how and which FactSheets will be created/updated in LeanIX. It checks whether the FactSheets already 
exist and if LeanIX descriptions for applications or interfaces have been stored in SAP CI. """;
    }
    // Obtain the current message body
    def body = message.getBody(String);
    
    // Combine the header and the body
    def fullOutput = header + body;
    
    // Add the current message body which contains the simulation result as an attachment to the log so the customer can check which FactSheets would have been created, tagged as "Simulation Output".
    if (isSimulationModeActive) {
        messageLog.addAttachmentAsString("Simulation Output", fullOutput, "text/plain");    
    } else {
        messageLog.addAttachmentAsString("Flow Log", fullOutput, "text/plain");    
    }
    
    // Return the modified
    return message;
}
