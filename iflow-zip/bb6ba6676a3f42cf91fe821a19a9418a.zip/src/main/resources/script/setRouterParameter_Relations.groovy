/**
 * Script Name: setRouterParameter
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script evaluates whether an application should be created, updated or skipped based on the provided XML input.
 *              It uses a preloaded application mapping from message properties and value mapping via ValueMapping API.
 *              The result is written back into the message body as XML, and properties are set to control routing.
 * 
 * Notes: 
 * - If the application ID is missing, a create operation is triggered.
 * - If the application name matches the mapped display name AND required tag is present, no action is taken.
 * - If there is a mismatch in name or the tag is missing, an update operation is triggered.
 */

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.xml.MarkupBuilder
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

Message processData(Message message) {
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)

    // Read input XML body
    def body = message.getBody(String)
    def parser = new XmlParser()
    def root = parser.parseText(body)
    def applicationNode = root.Application

    def name = applicationNode.Name.text()?.trim()
    def id = applicationNode.Id.text()?.trim()

    // Load application mapping from message property
    def applicationMap = message.getProperty("ApplicationMap") ?: [:]

    // Attempt to retrieve a mapped name using the Value Mapping API
    def mappedName = null
    try {
        def tempValue = valueMapApi.getMappedValue(
            "SAPCI_Component", "Name",
            name,
            "LeanIX_Application", "Label"
        )
        mappedName = tempValue?.trim()
        if (mappedName == "..." || mappedName == "") {
            mappedName = null
        }
    } catch (Exception e) {
        mappedName = null
    }

    // Lookup the display name from the application map using the ID
    def displayNameFromMap = null
    def externalIdMatch = applicationMap.find { entry ->
        entry.value.id?.trim() == id
    }
    if (externalIdMatch) {
        displayNameFromMap = externalIdMatch.value.displayName?.trim()
    }

    // Get tag from property and compare with XML tags
    def tagNameApplication = message.getProperty("TagNameApplication")?.trim()
    def tagNodes = applicationNode.Tag

    def tagValues = tagNodes.collect { it.text().trim() }
                            .collectMany { Arrays.asList(it.split(/[,;|]/)) }
                            .collect { it.trim() }
                            .findAll { it }

    def tagMatched = tagValues.contains(tagNameApplication)

    // Set default routing properties
    message.setProperty("ApplicationCreate", "false")
    message.setProperty("ApplicationUpdate", "false")

    def writer = new StringWriter()
    def builder = new MarkupBuilder(writer)

    if (!id) {
        // Application does not exist yet, prepare create payload
        builder.Applications {
            Application {
                create {
                    Name(name)
                    Id("")
                }
            }
        }
        message.setProperty("ApplicationCreate", "true")

    } else if (
        ((mappedName && mappedName == displayNameFromMap) || (!mappedName && name == displayNameFromMap))
        && tagMatched
    ) {
        // No changes required, keep original input unchanged
        message.setBody(XmlUtil.serialize(root))
        message.setProperty("ApplicationCreate", "false")
        message.setProperty("ApplicationUpdate", "false")
        return message

    } else {
        // Existing application needs to be updated
        builder.Applications {
            Application {
                update {
                    Name(name)
                    Id(id)
                }
            }
        }
        message.setProperty("ApplicationUpdate", "true")
    }

    message.setBody(writer.toString())

    // If simulation mode is active, override all routing flags
    def isSimulation = message.getProperty("isSimulationModeActive") == "true"
    if (isSimulation) {
        message.setProperty("ApplicationCreate", "false")
        message.setProperty("ApplicationUpdate", "false")
    }

    return message
}
