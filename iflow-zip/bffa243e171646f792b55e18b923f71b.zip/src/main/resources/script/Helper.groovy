import java.math.BigDecimal;
import java.net.URLEncoder;
import com.sap.gateway.ip.core.customdev.util.Message;

def String convertDecimal(String decimalIn) {
  try {
    return new BigDecimal(decimalIn).toPlainString() // get rid of exponential representation
  } catch (NumberFormatException e) {
    return decimalIn; // map through
  }
}

def Message encodeParameters(Message message) {

  def map = message.getProperties()

  // encode material
  def materialNumber = map.get("P_Material_Id")
  String encodedMaterialNumber = URLEncoder.encode(materialNumber, "UTF-8")
  message.setProperty("P_Material_Id", encodedMaterialNumber)

  // encode stock type
  def stockType = map.get("P_Stock_Type")
  String encodedStockType = URLEncoder.encode(stockType, "UTF-8")
  message.setProperty("P_Stock_Type", encodedStockType)

  // encode stock type
  def specialStockType = map.get("P_Special_Stock_Type")
  if (specialStockType?.trim()) {
    String encodedSpecialStockType = URLEncoder.encode(specialStockType, "UTF-8")
    message.setProperty("P_Special_Stock_Type", encodedSpecialStockType)
  }

  return message
}