import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;

def Message processData(Message message) {
		def messageLog = messageLogFactory.getMessageLog(message);
		def map = message.getProperties();
		def LSRD = map.get("LSRD");
		def UserSetDate = map.get("UserSetDate");
		def date="";
		if(!(UserSetDate.equals(null)) && (!(UserSetDate.equals(""))))
		{
		    date=UserSetDate;
		}
		else if(!(LSRD.equals(null)) && (!(LSRD.equals(""))))
		{
		    date=LSRD;
		}
	else
	{
	    date = new Date();
        sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        date = sdf.format(date)
	}
	    def rundatetime = new Date();
        sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        rundatetime = sdf.format(rundatetime);
        
        def rundat = new Date();
        sdf = new SimpleDateFormat("yyyy-MM-dd");
        rundat = sdf.format(rundat)
        message.setProperty("Date", rundat);
        message.setProperty("LMD", date);
        message.setProperty("RunDate",rundatetime)
        messageLog.addAttachmentAsString("Date:", date, "text/plain");
return message;
}