import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
def body = message.getBody(java.lang.String) as String;
def pmap = message.getProperties();
def messageLog = messageLogFactory.getMessageLog(message);
def map = message.getProperties()
def userName = map.get("userName")
def password = map.get("password")

body=body.replaceAll("&","&amp;")
body=body.replaceAll("ns1","urn")
body=body.substring(38)
       def body1='''
<soapenv:Envelope
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:urn="urn:RAC:CTM:People_Sync_WS">
    <soapenv:Header>
        <urn:AuthenticationInfo>
            <urn:userName>''' + userName + '''</urn:userName>
            <urn:password>''' + password + '''</urn:password>
        </urn:AuthenticationInfo>
    </soapenv:Header>
    <soapenv:Body>'''+ body +'''
   </soapenv:Body>
</soapenv:Envelope>'''
message.setBody(body1)

	String enableLogging = pmap.get("ENABLE_LOGGING");
	Integer loopCounter = message.getProperty("loopCounter");
	//log payload after mapping
	if(enableLogging != null && enableLogging.toUpperCase().equals("TRUE")){
		if(messageLog != null){
			messageLog.addAttachmentAsString("Payload " + loopCounter.toString() + " After Mapping", body, "text/xml");
		}
	}
return message;
}
