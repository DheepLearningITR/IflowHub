import com.sap.it.api.mapping.*;
def String customFunc(String username){
    username = username.replaceAll("@rac.sa","")
    username = username.replaceAll("@RAC.SA","")
    username = username.replaceAll("@RAC.sa","")
	return username
}