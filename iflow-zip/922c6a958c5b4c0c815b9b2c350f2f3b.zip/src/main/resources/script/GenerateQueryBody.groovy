import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;
import groovy.json.JsonOutput;


class ServiceContractEquipment {
    String serviceContract, equipment;
    ServiceContractEquipment(String serviceContract, String equipment) {
        this.serviceContract = serviceContract;
        this.equipment = equipment;
    }
}

def Message processData(Message message){
    def body = message.getBody(java.lang.String);
    def CRMXIF_ORDER_SAVE_U05 = new XmlSlurper().parseText(body);
    
    def equipments = []; //list of externalIds to query FSM for ids.
    def serviceContractEquipments = []; //list of linkages for linkage payload.
    
    
    CRMXIF_ORDER_SAVE_U05.IDOC.E101CRMXIF_BUSTRANS.E101CRMXIF_BUSTRANS_ITEM.each { item->
        item.E101CRMXIF_ORDPRP_I_X.E101CRMXIF_ORDPRP_I.E101CRMXIF_ORDPRP_OBJL_I_D.each { ibase->
            def contractID = item.FSM_ITEM_ID.text()
            
            def emptyEquipment = '000000000000000000';
            def equipmentExternalId = null;
            if(!ibase.IBASE_HEADER.equals(emptyEquipment))
                equipmentExternalId = ibase.IBASE_HEADER.text();
            else if(!ibase.IBASE_COMPONENT.equals(emptyEquipment))
                equipmentExternalId = ibase.IBASE_COMPONENT.text();
            
            if(equipmentExternalId != null) {
                serviceContractEquipments.add(new ServiceContractEquipment(contractID, equipmentExternalId));
                equipments.add(equipmentExternalId);
            }
        }
    }

    
    
    def areEquipmentsPresent = equipments.size > 0;
    message.setProperty("areEquipmentsPresent", areEquipmentsPresent);
    if(areEquipmentsPresent) {
        //save linkage payload to send to FSM.
        message.setProperty("LinkagePayload", JsonOutput.toJson(serviceContractEquipments));
        
        def queryString = "select e.externalId, e.id from Equipment e where e.externalId IN (" + equipments.collect{"'"+it+"'"}.join(",") + ")";
        message.setBody(JsonOutput.toJson([query:queryString]));
    }
    return message;
}