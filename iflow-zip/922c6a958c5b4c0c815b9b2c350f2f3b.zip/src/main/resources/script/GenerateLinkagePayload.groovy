import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String) as String;
    def map = message.getProperties();
    
    def queryResponse = new JsonSlurper().parseText(body);
    def linkagePayload = new JsonSlurper().parseText(map.get("LinkagePayload"));
    
    def equipmentMap = [:];
    queryResponse.data.each {
        equipmentMap[it.e.externalId] = it.e.id;
    }
    
    linkagePayload.each {
        it.equipment = equipmentMap[it.equipment];
        it.externalId = it.serviceContract + "-" + it.equipment;
    }
    
    message.setBody(JsonOutput.toJson(linkagePayload));
    message.setProperty("RequestPayload", JsonOutput.toJson(linkagePayload));
    
    return message;
}