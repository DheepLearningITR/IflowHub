import com.sap.it.api.mapping.*;


def String getRootUnitId(String id){
    if (id.contains("_"))
    {
	    return id.substring(0, id.firstIndexOf("_"));
    }
    else 
    {
        return id;
    }
}