import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Get the JSON string from the header
    def headers = message.getHeaders()
    def jsonString = headers.get("FormattedHTTPQuery")
    
    // Parse the JSON string
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(jsonString)

    // Initialize the writer for XML
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.setDoubleQuotes(true)

    // Build the XML structure with namespace
    xml.'n0:IsuC4cV2ReturnsGet'('xmlns:n0': 'urn:sap-com:document:sap:soap:functions:mc-style') {
        // Separate handling for dueDateFrom and dueDateTo
        if (jsonObject.dateFrom || jsonObject.dateTo) {
            ItPostingDate {
                'item' {
                    Sign('I')
                    Option('BT')
                    DateFrom(jsonObject.dateFrom?.get(0)?.value ?: '')
                    DateTo(jsonObject.dateTo?.get(0)?.value ?: '')
                }
            }
        }
		// Define a mapping from JSON field names to XML field names only for "orderBy" field conversions
    def fieldMapping = [
        'returnDocNum'      : 'RET_DOC_NUM',
        'returnsAmount'     : 'RETURNS_AMOUNT',
        'postingDate'       : 'POSTING_DATE',
		'returnsReason'     : 'RETURNS_REASON_CODE',
		'returnsReasonCode' : 'RETURNS_REASON_CODE',
		'reversedFlag'      : 'REVERSED_FLAG',
		'numOfReturns'      : 'NUM_OF_RETURNS',
		'returnsCharge1'    : 'RETURNS_CHARGE1',
		'returnsCharge2'    : 'RETURNS_CHARGE2',
		'returnsLot'        : 'RETURNS_LOT',
		'partialAmount'     : 'PARTIAL_AMOUNT'
    ]
        

        jsonObject.each { key, value ->
            switch (key) {
                case 'top':
                    IvTop(value)
                    break
                case 'search':
                    IvSearchValue(value)
                    break
                case 'skip':
                    IvSkip(value)
                    break
				case 'orderBy':
                    // Convert the value if a mapping exists; otherwise, use the original value
                    def mappedValue = fieldMapping.get(value, value)
                    IvSortField(mappedValue)
                    break
                case 'orderByType':
                    IvSortType(value)
                    break
                case 'businessPartnerId':
                    ItBusinessPartner {
                        value.each { BP ->
                            'item'(BP.value.trim())
                        }
                    }
                    break
                                 
                case 'reversedFlag':
                    IvIncludeReversedRet(value[0].value == 'true' ? 'X' : '')
                    break
                default:
                    // Handle any additional dynamic fields here if necessary
                    break
            }
        }

        // Always include ItFilter with constant values
        ItAdditionalFilter {
            'item' {
                Fieldname('QueryFilter')
                FieldValue(headers.get("QueryFilter"))
                Sign('I')
                Option('')
                Low("")
                High("")
            }
        }
    }

    // Set the XML output as the message body
    message.setBody(writer.toString())

    return message
}
