import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def payload = message.getBody(String)    
    def json = new JsonSlurper().parseText(payload)
    def fieldsToConvert = ['sequence', 'totalMessageCount']
    
    if (json.header.eventGroup){
        fieldsToConvert.each { f -> json.header.eventGroup[f] = json.header.eventGroup[f].toInteger() }
    }
    
    def materialItems = json.data.materialItem

    if (json.data.materialItem){
        json.data.materialItem.each{
            it.quantity = new BigDecimal(it.quantity)
            if (it.materialSubUnit){
                it.materialSubUnit.each{ s -> s.quantity = new BigDecimal(s.quantity)}
            }
        }
    }

    message.setBody(JsonOutput.toJson(json))

    return message

}