import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.security.MessageDigest;
import org.apache.commons.codec.binary.Hex;

def String HashValue(String arg1) {
    // Get an instance of the SHA-256 message digest
    MessageDigest digest = MessageDigest.getInstance("SHA-256");
    
    // Perform the hash
    byte[] hashBytes = digest.digest(arg1.getBytes("UTF-8"));
    
    // Convert the byte array to a hexadecimal string
    String hashedValue = new String(Hex.encodeHex(hashBytes));
    
    // Return the hashed value
    return hashedValue;
}