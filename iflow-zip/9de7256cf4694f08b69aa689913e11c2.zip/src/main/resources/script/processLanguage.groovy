package src.main.resources.script
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.pd.PartnerDirectoryService;
import java.util.HashMap;
import groovy.transform.Field;
import groovy.util.slurpersupport.GPathResult;
import groovy.xml.XmlUtil;
@Field static final Map LANG_ID_CODE_MAPPING = [SR:"0",
                                                ZH:"1",
                                                TH:"2",
                                                KO:"3",
                                                RO:"4",
                                                SL:"5",
                                                HR:"6",
                                                MS:"7",
                                                UK:"8",
                                                ET:"9",
                                                AR:"A",
                                                HE:"B",
                                                CS:"C",
                                                DE:"D",
                                                EN:"E",
                                                FR:"F",
                                                EL:"G",
                                                HU:"H",
                                                IT:"I",
                                                JA:"J",
                                                DA:"K",
                                                PL:"L",
                                                ZF:"M",
                                                NL:"N",
                                                NO:"O",
                                                PT:"P",
                                                SK:"Q",
                                                RU:"R",
                                                ES:"S",
                                                TR:"T",
                                                FI:"U",
                                                SV:"V",
                                                BG:"W",
                                                LT:"X",
                                                LV:"Y",
                                                AF:"a",
                                                IS:"b",
                                                CA:"c",
                                                SH:"d",
                                                ID:"i"
										                ];
def Message processData(Message message) {
	
	return message;
}

def Message readLanguage(Message message) {
	
	Reader payload = message.getBody(java.io.Reader);
	GPathResult root = new XmlSlurper().parse(payload);
	
		List<GPathResult> searchResult = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase("LANGU") && it.children().size() == 0; }
		if (!searchResult.isEmpty()) {
			searchResult.each{ GPathResult it ->
				message.setProperty("Language", it.toString());
			}
            searchResult.each { GPathResult it ->
    			it.replaceBody(LANG_ID_CODE_MAPPING[it.toString()]);
    		}
		}
/*
        searchResult = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase("LANGU") && it.children().size() >0;  }
    	if (!searchResult.isEmpty()) {
    		searchResult.each { GPathResult it ->
    			it.replaceBody(LANG_ID_CODE_MAPPING[it.toString()]);
    			}
    	}*/
    message.setBody(XmlUtil.serialize(root));
	return message;
}

def Message writeLanguage(Message message) {
	def lang = message.getProperty("Language");
	def languageNode = { LANGUAGE "$lang"}
	Reader payload = message.getBody(java.io.Reader);
	GPathResult root = new XmlSlurper().parse(payload);
	
	List<GPathResult> searchResult = root.'**'.findAll { GPathResult it -> it.name().equalsIgnoreCase("item") && it.children().size() >0;  }
	if (!searchResult.isEmpty()) {
		searchResult.each { GPathResult it ->
            it.leftShift(languageNode);
			}
	}
	
	message.setBody(XmlUtil.serialize(root));
	
	return message;
}
