import com.sap.gateway.ip.core.customdev.util.Message;

Message processData(Message message) {

	def body = message.getBody(java.io.Reader);
	def root = new XmlSlurper().parse(body);
	
	// BAPI Part
	def errItems = root.Name.findAll { it -> it.text().matches("SELECTED_SET_NOT_FOUND") };
	if (errItems.size() == 0) {
		def errText = "\r\n-----BAPI errors begin-----\r\n";
		errText += errItems.TEXT.join(";\r\n");
		errText += "\r\n-----BAPI errors end-----\r\n";
		throw new Exception(errText);
	}
	
	return message;
}