import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def httpCode = message.getHeader("CamelHttpResponseCode", String)

    if (httpCode != "200") {
        throw new Exception("The Integration flow cannot be processed further while creating the Operation. Please check the ResponseLog Attachment for details");
    }

   return message;
}
