import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

// Process message
def Message processData(Message message) { 
    // check for warehouseexternalId
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)
    def getwarehouseExternalIdFlag = "false"
    def warehouseId
    
    jsonResult.data?.serviceCall?.activity?.materials.each { MT ->
        def warehouse = MT?.warehouse
        if (warehouse instanceof Map && warehouse.containsKey('externalId')) {
	        getwarehouseExternalIdFlag = "false"
        } else {
	        getwarehouseExternalIdFlag = "true"
	        warehouseId = warehouse
        }
    }
    message.setProperty("warehouseId",warehouseId)
    message.setProperty("getwarehouseExternalIdFlag",getwarehouseExternalIdFlag)
 
    return message
}
