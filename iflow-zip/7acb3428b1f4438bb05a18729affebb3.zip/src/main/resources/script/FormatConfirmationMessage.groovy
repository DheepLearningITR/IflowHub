import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.text.SimpleDateFormat
import java.util.TimeZone

// Process message
def Message processData(Message message) { 
    // Get the JSON payload as a string
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)

    // Replace null values with empty strings and remove empty arrays
    replaceNullsAndRemoveEmptyArrays(jsonResult)

    // Original timestamp (milliseconds since epoch)
    //def timestamp = jsonResult.data?.serviceCall?.activity?.activityData?.lastChanged as String
    
    //def dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
    //dateFormat.setTimeZone(TimeZone.getTimeZone("UTC")) 
    // Set the timezone to UTC
    //jsonResult.data?.serviceCall?.activity?.remove("expenses")
    jsonResult.data?.serviceCall?.activity?.remove("mileages")
    jsonResult.data?.serviceCall?.activity?.activityData?.remove("orgLevelIds")
    jsonResult.data?.serviceCall?.activity?.activityData?.remove("lastChanged")
    jsonResult.data?.serviceCall?.activity?.activityData?.remove("sourceActivity")
    jsonResult.data?.serviceCall?.activity?.activityData?.remove("attachments")
    jsonResult.data?.serviceCall?.activity?.activityData?.remove("requirements")
    jsonResult.data?.serviceCall?.activity?.activityData?.remove("workflowStep")
    jsonResult.data?.serviceCall?.activity?.activityData?.reservedMaterials.each { RM ->
		RM.remove("orgLevelIds")
		RM.remove("serialNumber")
		RM.remove("fromWarehouse")
		RM.remove("udfValues")
	}
    jsonResult.data?.serviceCall?.activity?.activityData?.address?.remove("location")
	jsonResult.data?.serviceCall?.activity?.timeEfforts.each { TE ->
        TE.remove("owners")
        TE.remove("syncObjectKPIs")
        //TE."inactive" = TE."inactive" as String
        TE.remove("inactive")
        TE.remove("groups")
        TE.remove("branches")
        TE.remove("udfMetaGroups")
        TE.remove("lastChanged")
        TE.remove("lastChangedBy")
    }
    
    jsonResult.data?.serviceCall?.activity?.materials.each { MT ->
        MT.remove("date")
        MT.remove("owners")
        MT.remove("syncObjectKPIs")
        MT.remove("inactive")
        MT.remove("serialNumbers")
        MT.remove("lastChanged")
    }
    
    jsonResult.data?.serviceCall?.activity?.expenses.each { EX ->
        EX.remove("date")
        //EX.remove("owners")
        //EX.remove("syncObjectKPIs")
        EX.remove("inactive")
        //EX.remove("serialNumbers")
        EX.remove("lastChanged")
    }

    jsonResult.data?.serviceCall?.activity?.activityData?.remove("expenses")
    jsonResult.data?.serviceCall?.activity?.activityData?.remove("mileages")
    
    // Convert the modified JSON back to a string
    def updatedBody = JsonOutput.toJson(jsonResult)
    
    message.setProperty("ActivityId", jsonResult.data?.serviceCall?.activity?.unifiedIdentifier?.id)
    message.setProperty("S4HRequestPayload",JsonOutput.prettyPrint(updatedBody))
    message.setBody(JsonOutput.prettyPrint(updatedBody))
    return message
}

// Recursive function to replace all null values with empty strings and remove empty arrays
def replaceNullsAndRemoveEmptyArrays(obj) {
    if (obj instanceof Map) {
        def keysToRemove = [] // List to track empty arrays
        obj.each { key, value ->
            if (value == null || value == 'null' || value == '') {
                //obj[key] = ""
                keysToRemove.add(key) // Mark empty array for removal
            } else if (value instanceof List && value.isEmpty()) {
                keysToRemove.add(key) // Mark empty array for removal
            } else {
                replaceNullsAndRemoveEmptyArrays(value)
            }
        }
        // Remove the keys after iteration
        keysToRemove.each { key ->
            //obj.remove(key)
            obj.remove(key)
        }
    } else if (obj instanceof List) {
        def itemsToRemove = [] // List to track null and empty arrays
        obj.each { item ->
            if (item == null || item == 'null' || item == '' || (item instanceof List && item.isEmpty())) {
                itemsToRemove.add(item) // Mark for removal
            } else {
                replaceNullsAndRemoveEmptyArrays(item)
            }
        }
        // Remove the items after iteration
        itemsToRemove.each { item ->
            obj.remove(item)
        }
    }
}
