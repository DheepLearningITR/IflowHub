import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    //This script is to check S4 status and set the FSM confirmation update payload
    def hdr = message.getHeaders()
    def S4response = hdr.get("sap-messages") as String;
    message.setProperty("FSMRequestPayload","NA")
    if(S4response){
        def jsonSlurper = new JsonSlurper()
        def jsonResult = jsonSlurper.parseText(S4response)
    
        //construct payload
        def FSMPayload = []
        def responseParts = jsonResult.findAll { it.code.contains("EAM_FSM_MORDER_REPL/") }
    
        responseParts.each { rsp -> 
            if (rsp.message.contains("PMOrder:") && rsp.message.contains("ConfirmationOrder:") && rsp.message.contains("FSMID:")){
                def PMOrderID = rsp.message.split(',')[0].split(':')[1]
                def ConfirmationPart = rsp.message.split(',')[1]
                def ConfirmationID = PMOrderID + '/' + ConfirmationPart.split(':')[1] + '/' + ConfirmationPart.split(':')[2] 
                def FSMConfirmationID = rsp.message.split(',')[2].split(':')[1]
                def object = new JsonBuilder()
                object { "id" (FSMConfirmationID)
                         "confirmationitem" (ConfirmationID) }
    
                FSMPayload.add(object)
            }
        }
        if (FSMPayload.size() > 0)
            message.setProperty("FSMRequestPayload", new JsonBuilder(FSMPayload).content.toString())
    }
        
    message.setProperty("CamelHttpMethod","PATCH")
    
// To access FSM, company and account are required -- either their name or their ID.
// If the IDs are configured, they are used; otherwise, the names are used.
    def accountCompanyUser = '';
    def headers = message.getHeaders();
    def accountID = headers.get("X-Account-ID") 
    accountID = accountID ? accountID : message.getProperty('X-Account-ID');
    def accountName = message.getProperty('X-Account-Name');
    def companyID = headers.get("X-Company-ID")
    companyID = companyID ? companyID : message.getProperty('X-Company-ID');
    def companyName = message.getProperty('X-Company-Name');
    def userName = message.getProperty('UserName');

    if (accountID == null || accountID == '' || accountID == '<FSM_Account_ID>' || companyID == null || companyID == '' || companyID == '<FSM_Company_ID>') {
        accountCompanyUser = '&account='+accountName+'&company='+companyName+'&user='+userName;
        message.setHeader('X-Account-Name', accountName);
        message.setHeader('X-Company-Name', companyName);
    } else {
        accountCompanyUser = '';
        message.setHeader('X-Account-ID', accountID);
        message.setHeader('X-Company-ID', companyID);
    }
    message.setProperty('AccountCompanyUser', accountCompanyUser);
    
    return message;
}
