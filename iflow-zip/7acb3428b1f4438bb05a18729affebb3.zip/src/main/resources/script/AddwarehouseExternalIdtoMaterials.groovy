import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) { 
    // this script is to add warehouse externalId nodes to the material
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)
    def prop = message.getProperties()
    def FSMRequestPayload = prop.get("FSMRequestPayload") as String
    def FSMpayloadParsed = jsonSlurper.parseText(FSMRequestPayload)
    
    FSMpayloadParsed.data?.serviceCall?.activity?.materials.each { MT ->
        def warehouse = MT?.warehouse        
        if (jsonResult.data[0]?.warehouse.id == warehouse) {
            MT?.warehouse = [
                id: jsonResult.data[0]?.warehouse.id,
                code: jsonResult.data[0]?.warehouse.code,
                externalId: jsonResult.data[0]?.warehouse.externalId
            ]
        }
        
    }

    FSMpayloadParsed = JsonOutput.toJson(FSMpayloadParsed)
    message.setBody(JsonOutput.prettyPrint(FSMpayloadParsed))
    message.setProperty("FSMRequestPayload",JsonOutput.prettyPrint(FSMpayloadParsed))
 
    return message
}
