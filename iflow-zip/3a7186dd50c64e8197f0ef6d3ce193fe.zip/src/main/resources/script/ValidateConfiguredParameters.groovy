import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def properties = message.getProperties()

    if (!properties.get("signavioHost") || properties.get("signavioHost").equals('https://*****.signavio.com')) {
        throw new Exception("'Signavio Host' is not configured.")
    }

    if (!properties.get("ramHost") || properties.get("ramHost").equals('https://')) {
        throw new Exception("'SAP Risk and Assurance Management Host' is not configured.")
    }

    return message
}
