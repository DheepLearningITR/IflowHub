import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.transform.CompileStatic
import groovy.transform.Field

@Field public static final String ACKNOWLEDGE_MESSAGE_STATUS_SUCCESS = 'SUCCESS'
@Field public static final String ACKNOWLEDGE_MESSAGE_STATUS_PARTIAL_SUCCESS = 'PARTIAL_SUCCESS'
@Field public static final String ACKNOWLEDGE_MESSAGE_RESPONSE_SEVERITY_SUCCESS = 'SUCCESS'
@Field public static final String ADDRESS_FORMAT = "%s/cp.portal/site#RiskAssessment-manage?sap-ui-app-id-hint=com.sap.grc.risk.assessment&/RiskAssessment('%s')"

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def acknowledgeMessageJson = new JsonSlurper().parse(body)
    def data = acknowledgeMessageJson.data
    def messageStatus = data.messageStatus

    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addCustomHeaderProperty("messageStatus", messageStatus)
    messageLog.addCustomHeaderProperty("xsapcorrelationid", acknowledgeMessageJson.xsapcorrelationid)
    messageLog.addCustomHeaderProperty("messageId", acknowledgeMessageJson.id)

    message.setProperty('messageStatus', messageStatus)
    def riskList = []

    if (messageStatus.equals(ACKNOWLEDGE_MESSAGE_STATUS_SUCCESS) || messageStatus.equals(ACKNOWLEDGE_MESSAGE_STATUS_PARTIAL_SUCCESS)) {
        def ramHost = message.getProperty('ramHost')
        for (def response : data.messageResponses) {
            if (response.severity.equals(ACKNOWLEDGE_MESSAGE_RESPONSE_SEVERITY_SUCCESS)) {
                RamRiskInfo riskInfo = new RamRiskInfo(response.id, response.displayId, response.externalId, String.format(ADDRESS_FORMAT, ramHost, response.displayId))
                //Even risk create support batch, Initial Risk job send only one risk in one batch.
                messageLog.addCustomHeaderProperty("signavioRiskId", riskInfo.externalId)
                messageLog.addCustomHeaderProperty("ramRiskId", riskInfo.id)
                riskList.add(riskInfo)
            }
        }
    }

    if (!messageStatus.equals(ACKNOWLEDGE_MESSAGE_STATUS_SUCCESS)) {
        messageLog.addAttachmentAsString("Failure Message Body", JsonOutput.prettyPrint(JsonOutput.toJson(acknowledgeMessageJson)), "text/plain")
    }

    if (riskList.size() > 0) {
        message.setProperty("riskList", riskList)
        message.setProperty("index", 0)
        message.setProperty("currentSignavioRiskId", riskList.get(0).externalId)

    }else{
        message.setProperty("currentSignavioRiskId", "")
    }

    return message
}

@CompileStatic
class RamRiskInfo {
    String id
    String displayId
    String externalId
    String url

    RamRiskInfo(String id, String displayId, String externalId, String url) {
        this.id = id
        this.displayId = displayId
        this.externalId = externalId
        this.url = url
    }
}