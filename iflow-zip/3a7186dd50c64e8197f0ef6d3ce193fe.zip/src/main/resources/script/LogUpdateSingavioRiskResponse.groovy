import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message)
    def body = message.getBody(java.io.Reader);
    def response = new JsonSlurper().parse(body)
    if (!response instanceof ArrayList && response.errors) {
        messageLog.addCustomHeaderProperty("IsWriteToSignavioError", "true")
        messageLog.addCustomHeaderProperty("WriteToSignavioErrorMessage", response.message)
    } else {
        messageLog.addCustomHeaderProperty("IsWriteToSignavioError", "false")
    }

    def riskList = message.getProperty("riskList")
    def index = message.getProperty("index")
    if (riskList.size() > index + 1) {
        index++
        message.setProperty("index", index)
        message.setProperty("currentSignavioRiskId", riskList.get(index).externalId)
    } else {
        message.setProperty("currentSignavioRiskId", "")
    }
    return message
}