import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.CompileStatic
import groovy.transform.Field

@Field public static final String RISK_URL_LABEL = 'RAM Risk'
@Field public static final String META_RISKDISPLAYID = 'meta-ramriskid'
@Field public static final String META_RISKID = 'meta-ramrisktechnicalid'

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def jsonBody = new JsonSlurper().parse(body)
    def riskList = message.getProperty("riskList")
    def index = message.getProperty("index")
    def ramRisk = riskList.get(index)
    def signavioRisk = new SignavioRisk(jsonBody.title, jsonBody.description, jsonBody.category.split("/")[2], jsonBody.attachments, jsonBody.metaDataValues, jsonBody.formats)
    
    def needToUpdateSignavioRisk = false

    if (signavioRisk.metaDataValues[META_RISKDISPLAYID] != ramRisk.displayId || signavioRisk.metaDataValues[META_RISKID] != ramRisk.id) {
        needToUpdateSignavioRisk = true
        signavioRisk.metaDataValues[META_RISKDISPLAYID] = ramRisk.displayId
        signavioRisk.metaDataValues[META_RISKID] = ramRisk.id
    }

    if (signavioRisk.attachments == null) {
        signavioRisk.attachments = []
    }

    def riskUrlExistInAttachment = false
    for (def attachment : signavioRisk.attachments) {
        if (attachment instanceof Map) {
            if (attachment.label == RISK_URL_LABEL) {
                riskUrlExistInAttachment = true
                break
            }
        }
    }

    if (!riskUrlExistInAttachment) {
        needToUpdateSignavioRisk = true
        def grcRiskUrl = [label: RISK_URL_LABEL, url: ramRisk.url]
        signavioRisk.attachments.add(grcRiskUrl)
    } else {
        for (def attachment : signavioRisk.attachments) {
            if (attachment instanceof Map) {
                if (attachment.label == RISK_URL_LABEL && attachment.url != ramRisk.url) {
                    needToUpdateSignavioRisk = true
                    attachment.url = ramRisk.url
                    break
                }
            }
        }
    }

    if (!needToUpdateSignavioRisk) {
        if (riskList.size() > index + 1) {
            index++
            message.setProperty("index", index)
            message.setProperty("currentSignavioRiskId", riskList.get(index).externalId)
        } else {
            message.setProperty("currentSignavioRiskId", "")
        }
    }

    message.setProperty("needToUpdateSignavioRisk", needToUpdateSignavioRisk)
    
    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addCustomHeaderProperty("needToUpdateSignavioRisk", needToUpdateSignavioRisk.toString())

    message.setProperty("signavioRisk", signavioRisk)

    return message
}

@CompileStatic
class SignavioRisk {
    String title
    String description
    String category
    List attachments
    Map<String, String> metaDataValues
    Map<String, String> formats


    SignavioRisk(String title, String description, String category, List attachments, Map<String, String> metaDataValues, Map<String, String> formats) {
        this.title = title
        this.description = description
        this.category = category
        this.attachments = attachments
        this.metaDataValues = metaDataValues
        this.formats = formats
    }
}
