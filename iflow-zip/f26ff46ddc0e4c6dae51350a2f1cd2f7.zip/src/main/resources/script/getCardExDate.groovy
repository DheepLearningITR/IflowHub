import com.sap.it.api.mapping.*;


def String getCardExpDate(String P1, String P2){
    Integer day;
    String date;
    Integer Year = Integer.parseInt(P1);
    Integer Month = Integer.parseInt(P2);
    
    if (Year%4 == 0){
        String leapYear = 'X';
    }
    
    if (Month == 4 || Month == 6 || Month == 9 || Month == 11)
    {
     day = 30;
    }
    else 
    if(Month == 2)
    {
        day = (leapYear)?29:28;
    }
    else{
        day =31;
    }
    
    if(Month <= 9 && Month.length() == 1){
        P2 = 0 + Month;
    }
 
    date = P1+P2+day; 
    return date;
 
}
