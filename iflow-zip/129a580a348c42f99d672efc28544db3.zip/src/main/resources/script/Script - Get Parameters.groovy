
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();

       //Headers 
       def map = message.getHeaders();
       def value = map.get("CamelHttpPath");

       //Properties 
       map = message.getProperties();
       //value = map.get("oldProperty");
       message.setProperty("companyCode", value.substring(0,4));
       message.setProperty("costCenter", value.substring(4,14));
       return message;
}