import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def result=""
    String json = JsonOutput.toJson(body)
    JsonSlurper slurper = new JsonSlurper()
    result = slurper.parseText(json);
    def map = message.getProperties();
    String namespace = map.get("RFCNAME");
    namespace=namespace.replaceAll("/","_-");
    String rpmFmName = map.get("RPMFUNCTIONMODULE");
    if (!(namespace == "") && !namespace.isEmpty() && result.contains(namespace)) {
        result=result.replaceAll(namespace,rpmFmName);
    }

    def output
    output=JsonOutput.toJson(new RPMDataResponse(data:result,status:"Success",remarks:"",code:"000"))
    message.setBody(output)
    return message
}

class RPMDataResponse{
    def data;
    String status,remarks,code;
}