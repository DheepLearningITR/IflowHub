import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def body = message.getBody(String.class);
   
    String json = JsonOutput.toJson(body)
    JsonSlurper slurper = new JsonSlurper()
    def result = slurper.parseText(json)
    result=result.replaceAll("SPE/","")
    
    def map = message.getProperties();
    String namespace = map.get("RFCNAME");
    namespace=namespace.replaceAll("/","_-");
    String rpmFmName = map.get("RPMFUNCTIONMODULE");
    if(namespace == "" && 
        namespace.isEmpty()){
        String exceptionBody = 'Enter a Parameter Function Module Name in the integration flow. It cannot be empty.';
        throw new Exception(exceptionBody);
    }
    if ( result.contains(rpmFmName) 
        && namespace != rpmFmName){
        result=result.replaceAll(rpmFmName,namespace);
    }

    message.setBody(result)
    return message
}
