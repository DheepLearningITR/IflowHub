import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;
import java.io.*;
import groovy.json.JsonOutput;
import java.time.*



def Message processData(Message message) { 
    
    def body = message.getBody(String.class);
    def exceptionMsg = message.getProperty("CamelExceptionCaught")
    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addAttachmentAsString("Cannot fetch information ",exceptionMsg.getMessage(),"text/plain")
    
    String code=message.getProperty("code")
    String remarks=message.getProperty("remarks")
    
    if(null==code || "" == code){
        code="001"
    }
    
   if(null==remarks || "" == remarks){
    remarks=exceptionMsg
   }
    
  
 def output=JsonOutput.toJson(new RPMDataResponse(data:null,status: 'Failure',remarks:remarks,code:code));
 
  message.setBody(output)
 	return message
}

class RPMDataResponse{
    def data;
    String status,remarks,code;
}

