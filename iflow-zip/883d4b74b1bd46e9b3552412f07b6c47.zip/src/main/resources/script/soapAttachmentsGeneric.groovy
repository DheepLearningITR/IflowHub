import com.sap.gateway.ip.core.customdev.util.Message
import java.util.Map
import java.util.Iterator
import javax.activation.DataHandler



def Message processData(Message message) {
   
   def replacepayload = message.getProperty("replace_payload").toLowerCase() as String;
   def nodename = message.getProperty("node_name") as String;
   def singlebase64 = message.getProperty("singlebase64").toLowerCase() as String;
   def datachunkbase64 = message.getProperty("datachunkbase64").toLowerCase() as String;
   def singledatachunkbase64 = message.getProperty("singledatachunkbase64").toLowerCase() as String;
   def chunksize = message.getProperty("chunksize") as Integer; 
    
   Map < String, DataHandler > attachments = message.getAttachments();

    if (!attachments.isEmpty())
    {

       def body = message.getBody(java.io.Reader);
       def xmlSlurper = new XmlSlurper()
       def iattachments = new Node(null, 'root');
      
       //split base64 string in small chunks
       def chunkSize = chunksize
       int c = 0; 
       Iterator < DataHandler > it = attachments.values().iterator();
       int i = 1;

    // Loop attachments in SOAP Adapter and convert to Base64 String
      
        while (it.hasNext())
        {
            // bas64 conversion takes place here
            DataHandler attachment = it.next();
            InputStream inputStream = attachment.getInputStream()
            byte[] binaryData = inputStream.bytes; 
            String base64 = Base64.getEncoder().encodeToString(binaryData);
            // bas64 conversion takes place here
            
            def item = new Node(iattachments,'item',[SEGMENT: i])
            new Node(item,'FILE_ID',i);
            new Node(item,'FILE',attachment.getName());
            new Node(item,'FILESIZE',binaryData.length);
            new Node(item,'DESCRIPTION',attachment.getName());
        
             if (singlebase64 == 'true') {   
            //  example for single base64 line in XML structure 
                 new Node(item,'base64',base64);
            //  example for single base64 line in XML structure 
             }
         
             if (datachunkbase64 == 'true') { 
            // example for base64 chunks in XML structure covert under multiple data nodes    
                def base64Aschunksv1 = new Node(item,'base64',[SEGMENT: i]);
                for (int y = 0; y < base64.length(); y += chunkSize) {
                     int endIndex = Math.min(y + chunkSize, base64.length())
                     new Node(base64Aschunksv1,'data',base64.substring(y, endIndex).toUpperCase()); 
                }
            // example for base64 chunks in XML structure covert under multiple data nodes    
              }
              
            if (singledatachunkbase64 == 'true') {    
            // example for multiple base64 chunks in XML structure each chunk contains a data node     
                for (int y = 0; y < base64.length(); y += chunkSize) {
                     int endIndex = Math.min(y + chunkSize, base64.length())
                     c++; 
                     def base64Aschunksv2 = new Node(item,'base64',[SEGMENT: c]);
                     new Node(base64Aschunksv2,'data',base64.substring(y, endIndex).toUpperCase()); 
                }
            // example for multiple base64 chunks in XML structure each chunk contains a data node      
            }
            message.setProperty("hasAttachment" + i, "true");
            i++;
            c = 0; 
        }
       
       
        def iattachmentxml = groovy.xml.XmlUtil.serialize(iattachments); 

        if (replacepayload == 'true') {
            // ####################### Option 1: Attachments as payload - ignore incomming payload ####################### 
              message.setBody(iattachmentxml);  
            // ####################### Option 1: Attachments as payload - ignore incomming payload ####################### 
        } else {
        // ####################### Option 2: Merge existing XML with new created attachment XML a a specific node ####################### 
                def Node1 = xmlSlurper.parseText(iattachmentxml)
                def Node2 = xmlSlurper.parse(body)
                
                // // find a specific node to insert the attachments  
                def nodetoadd = Node2.'**'.find{it.name() == nodename }
                    nodetoadd.appendNode(Node1.'item')
                def mergedXml = groovy.xml.XmlUtil.serialize(Node2)
                
                message.setBody(mergedXml); 
        // ####################### Option 2: Merge existing XML with new created attachment XML a a specific node ####################### 
        }
    }
    
    return message
}
