import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.ZoneOffset

def Message processData(Message message) {
    def event = prepareEventMeshData(message)

    def eventJsonString = JsonOutput.toJson(event)
    def topic= prepareEventMeshTopic(message)

    def body = [:]
    body.topic = topic
    body.body = eventJsonString

    message.setBody(JsonOutput.toJson(body))

    return message
}

def prepareEventMeshTopic(Message message) {
    def namespace = message.getProperty("eventMeshNamespace")
    return "topic:${namespace}/ce/sap/grc/risk/ComplianceRisk/Create/v1".toString()
}

def prepareEventMeshData(Message message) {
    def data = message.getProperty("riskData")
    def event = [data: [items: [data]]]
    event.id = UUID.randomUUID().toString()
    event.specversion = '1.0'
    event.type = 'sap.grc.risk.ComplianceRisk.Create.v1'
    event.source = message.getProperty("eventMeshNamespace")
    event.xsapcorrelationid = message.getHeader("SAP_MplCorrelationId", String.class)
    event.datacontenttype = 'application/json'
    event.time = getTime()

    return event
}

def getTime() {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSX")

    return LocalDateTime.now().atOffset(ZoneOffset.UTC).format(formatter);
}
