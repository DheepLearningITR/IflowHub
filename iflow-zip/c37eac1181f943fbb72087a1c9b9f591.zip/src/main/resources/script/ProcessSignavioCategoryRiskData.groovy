import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def data = new JsonSlurper().parse(message.getBody(java.io.Reader))
    def dataInProperty = getData(message)
    data.findAll {"gitem".equals(it.rel)}.forEach {i -> dataInProperty.add(i)}

    return message
}

def getData(Message message) {
    def data = message.getProperty("data")
    if (data == null) {
        message.setProperty("data", [])
    }

    return message.getProperty("data")
}
