import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def data = new JsonSlurper().parse(body)

    data = data.find {"info".equals(it.rel)}
    def riskSize = data?.rep.size
    message.setProperty("riskSize", riskSize)

    return message
}
