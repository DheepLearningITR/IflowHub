import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def riskSize = message.getProperty("riskSize") as Integer
    def offset = message.getProperty("riskOffset") as Integer
    def currentLast = (offset + 1) * 100
    if (currentLast >= riskSize) {
        message.setProperty("hasMore", false)
    } else {
        message.setProperty("hasMore", true)
        message.setProperty("riskOffset", offset + 1)
    }

    return message
}
