import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def offset = message.getProperty("riskOffset")
    def categoryId = message.getProperty("categoryId")
    def body = "limit=100&offset=${offset}&category=${categoryId}".toString()
    message.setBody(body)

    return message
}
