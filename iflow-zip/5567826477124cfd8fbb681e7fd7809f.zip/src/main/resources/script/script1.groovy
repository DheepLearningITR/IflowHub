import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import java.util.HashMap;

def Message processData(Message message) {
    
  
    def exceptionMessage = message.getProperty("p_ExceptionMessage");
    def messageLog = messageLogFactory.getMessageLog(message);

    exceptionMessage = exceptionMessage.replaceAll('"', '')

    message.setProperty("p_ExceptionMessage", exceptionMessage);

    return message;
}


  
