import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	def lastSyncDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss",message.getProperty("queryLastRunTime"));
	def sapClient=message.getProperty("SAPClient");
	def itemList = []
    def outBoundDeliveryItems=[]
	def outBoundDeliveryRec=[]
	
	def inBoundDeliveryItems=[]
	def inBoundDeliveryRec=[]

	String outBoundDelvDoc=""
	String inBoundDelvDoc=""
	int postRecNo=0
	def processDocFlag=false
	def outBoundDelivery = 'notExist'
	def inBoundDelivery = 'notExist'
	if (!object.A_MaterialDocumentItem.isEmpty()) {
	    itemList = object.A_MaterialDocumentItem.A_MaterialDocumentItemType;
		
		if (!isCollectionOrArray(itemList)) {
		    itemList = [itemList].toArray();
		}
        
	}
	
	
  itemList.each { record ->
		if(null!=record.Delivery && !record.Delivery.isEmpty()){
	        // Check for STO Flag
            // if Flag is False ,will process inbound Deliveries 
            // If Flag is True , will process outbound and Inbound
            if(!record.Supplier.isEmpty()){
					if(null==record.IsAutomaticallyCreated || ""==record.IsAutomaticallyCreated){
						getDeliveries(record,inBoundDeliveryRec)
					} 
			}else if(record.Customer.isEmpty() && record.Supplier.isEmpty()){
					if(null==record.IsAutomaticallyCreated || ""==record.IsAutomaticallyCreated){
						getDeliveries(record,outBoundDeliveryRec)
					}     
				}
			
		}
  }

	//List of OutBound Deliveries
	if(outBoundDeliveryRec.size()>0 ){
        outBoundDelvDoc=prepareDocumentDeliveryFilter(outBoundDeliveryRec)+")"

        if(null!=sapClient&&!sapClient.isEmpty()){
		  outBoundDelvDoc=outBoundDelvDoc.concat(getSapClient(sapClient))
	    }
	    outBoundDelivery = 'exist'
	    
    }
    
    //List of inbound Deliveries
    if(inBoundDeliveryRec.size()>0 ){
        inBoundDelvDoc=prepareDocumentDeliveryFilter(inBoundDeliveryRec)+")"
        
        if(null!=sapClient&&!sapClient.isEmpty()){
		  inBoundDelvDoc=inBoundDelvDoc.concat(getSapClient(sapClient))
	    }
	     inBoundDelivery = 'exist'
	   
    }
    
	
     
	message.setProperty("postingDocument", itemList);
	message.setProperty("outBoundDelvDoc", outBoundDelvDoc);
	message.setProperty("inBoundDelvDoc", inBoundDelvDoc);
	message.setProperty("payload",body);
	message.setProperty("inBoundDelivery",inBoundDelivery);
	message.setProperty("outBoundDelivery",outBoundDelivery);
	message.setBody(body)
	
    return message
    
}

// Prepare the query for Delivery Doucment with list of deliveries 
def String prepareDocumentDeliveryFilter(def deliveryList) {
		//String[] materialCode = materialCodelist.split(',');
		String delvDocFilter = "(";
		
		int count=0
		deliveryList.each { record ->
			String tempPayload
			if (count==0) {
				tempPayload = "(DeliveryDocument eq '"
			} else {
				tempPayload = " or (DeliveryDocument eq '"
			}
			record=record.replaceAll("'","''")
			record=record.replaceAll("%","%25")
			record=record.replaceAll("&","%26")
			record=record.replaceAll("#","%23")
			record=record.replaceAll("\\+","%2B")
			record=record.replaceAll("\\?","%3F")
			record=record.replaceAll("\\\\","%2F")
			record=record.replaceAll("\\[","%5B")
			record=record.replaceAll("\\]","%5D")
			record=record.replaceAll(";","%3B")
			tempPayload = tempPayload + record.trim() +"'"+")"
			delvDocFilter=delvDocFilter.concat(tempPayload)
			count++
		}
	return delvDocFilter;
}

//Returns true if object is an array
boolean isCollectionOrArray(object) {
    [Collection, Object[]].any {
        it.isAssignableFrom(object.getClass())
    }
}

//Fetch the list of deliveries in record
def getDeliveries(def record,def deliveries){
        deliveries.add(record.Delivery)
	return deliveries
}

// Get SAP client
def String getSapClient(def sapClient){
  if(!sapClient.equals("Define SAP Client")&&(null!=sapClient && !sapClient.isEmpty())){
		    sapClient ="&sap-client=".concat(sapClient)
         }
   return sapClient
}
