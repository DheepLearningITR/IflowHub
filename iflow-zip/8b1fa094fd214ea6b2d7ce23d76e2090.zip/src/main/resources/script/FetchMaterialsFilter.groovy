import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Date;
import java.util.TimeZone;

def Message processData(Message message) { 
    
    message.setProperty("timestamp", new Date().format("yyyy-MM-dd'T'HH:mm:ss", TimeZone.getTimeZone(message.getProperty("Timezone")))); 
    String queryLastRunTime = Date.parse("yyyy-MM-dd'T'HH:mm:ss",message.getProperty("lastSyncDate")).format("yyyy-MM-dd'T'HH:mm:ss");
    message.setProperty("queryLastRunTime", queryLastRunTime);
	def materialTypes = message.getProperty("MaterialTypes");
	def materialsFrom = message.getProperty("MaterialsFrom");
		def bulkPosting = message.getProperty("BulkPosting");
	def sapClient=message.getProperty("SAPClient");		
	def isBulkPosting = 'false'
	if(null!=bulkPosting){
	 isBulkPosting = 'true'   
	}
	
	
	
	def materialCodelist=""
	def materialSelect=""
	def materialSrcCount=""
    def materialSrc=""
	def materialTypeSelect = ""
	def resourcePath=""
	if(null!=materialsFrom && !materialsFrom.isEmpty()){
	    if(materialsFrom=='RPM'||materialsFrom.equals('RPM')){
	        materialTypeSelect = "materialType"
	        message.setProperty("XpathExpression","MaterialMasterGeneralData/MaterialMasterGeneralData");
	        materialCodlist="MaterialMasterGeneralData.MaterialMasterGeneralData.materialCode";
	        //materialSrcCount="/odata/v2/MasterDataService/MaterialMasterGeneralData"
	        //materialSrc="/odata/v2/MasterDataService"
	        //resourcePath="MaterialMasterGeneralData"
	        materialSelect="materialCode"
	        
	    }else if(materialsFrom=='S/4HANA'||materialsFrom.equals('S/4HANA')){
	        materialTypeSelect = "ProductType"
	        message.setProperty("XpathExpression","A_Product/A_ProductType/Product");
	        materialCodelist="A_Product.A_ProductType.Product"
	        //materialSrc="/sap/opu/odata/sap/API_PRODUCT_SRV"
	        ///sap/opu/odata/sap/API_PRODUCT_SRV
	        //materialSrcCount="/sap/opu/odata/sap/API_PRODUCT_SRV/A_Product"
	        //resourcePath="A_Product"
	        materialSelect="Product"
	        
	    }
	    else{
	        throw new Exception("Cannot fetch material information. The value in Material Master Source (RPM/S/4HANA) can either be RPM or S/4HANA.")
	    }
	}else{
	    throw new Exception("Cannot fetch material information. Material Master Source (RPM/S/4HANA) cannot be empty.")
	}
	
	
	String materialTypeFilter;
	if(materialTypes != null) {
		String[] types = materialTypes.split(',');
		int count=0
		types.each { record ->
			String tempPayload
			if (count==0) {
				tempPayload = "("+materialTypeSelect+ " eq '"
			} else {
				tempPayload = " or ("+materialTypeSelect+" eq '"
			}
			tempPayload = tempPayload + record.trim() +"'"+")"
			
			if(materialTypeFilter != null) {
				materialTypeFilter=materialTypeFilter.concat(tempPayload)
			} else {
				materialTypeFilter = tempPayload
			}
			count++
		}
	}
    
    if(materialsFrom=='S/4HANA'||materialsFrom.equals('S/4HANA')){
	    if(!sapClient.equals("Define SAP Client")&&(null!=sapClient && !sapClient.isEmpty())){
		    sapClient ="&sap-client=".concat(sapClient)
        }else{
            sapClient=""
        }
		if(null!=sapClient&&!sapClient.isEmpty()){
		  materialTypeFilter=materialTypeFilter.concat(sapClient)
		}
	        
	}

	message.setProperty("materialCodelist", materialCodelist);
	message.setProperty("materialTypeFilter", materialTypeFilter);
	message.setProperty("materialSrc", materialSrc);
	message.setProperty("materialSrcCount", materialSrcCount);
	message.setProperty("resourcePath", resourcePath);
	message.setProperty("materialSelect", materialSelect);
	message.setBody("");
   
    return message
}