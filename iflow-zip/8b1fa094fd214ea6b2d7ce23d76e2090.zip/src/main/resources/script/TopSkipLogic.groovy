import com.sap.gateway.ip.core.customdev.util.Message;
    
def Message processData(Message message) {
def totalCount =  message.getProperty("totalCount")
def exitFlag = false
def skipVal = message.getProperty("skipVal");
def topVal = message.getProperty("TopVal");
def skipValTemp=topVal.toInteger()+skipVal.toInteger()
    
if(skipValTemp.toInteger() >= totalCount.toInteger()){
    exitFlag=true;
    
}
skipVal=skipValTemp.toString()
message.setProperty("exitFlag",exitFlag);
message.setProperty("skipVal", skipVal);




return message;
}
