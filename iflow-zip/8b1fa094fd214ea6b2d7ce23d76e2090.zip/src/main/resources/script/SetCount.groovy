import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) { 
    
    int totalCount=0;
    int topVal=0;
    def materialsFrom = message.getProperty("MaterialsFrom");
    String maxCount = message.getProperty("MaxCount");
    String threshold = message.getProperty("CountThreshold");
    int thresholdCount=threshold.toInteger();
    def isInteger=isValidCount(message.getBody(java.lang.String))
    if(isInteger){
        totalCount=message.getBody(java.lang.String).toInteger()
        if(materialsFrom=='S/4HANA'||materialsFrom.equals('S/4HANA')){
         // if(totalCount>thresholdCount){
         //       throw new Exception("Cannot fetch material information. The value fetched from source system is more than the threshold limit of "+threshold)
         //   }  
        }
          
        int max = maxCount.toInteger()
        if(totalCount>=max){
            topVal=maxCount.toInteger()
        }else{
            topVal = totalCount
        }
        
    }
    
	message.setProperty("totalCount",totalCount.toString())
	message.setProperty("skipVal", "0");
	message.setProperty("TopVal",topVal.toString());
	message.setBody("")

	return message;
   
    
}

def isValidCount(value) {
     //if(!value.toString().isInteger()){
        //throw new Exception("Cannot fetch material information. Please verify the URL for the Material Master Source , URL might be incorrect")
    //}
    value.toString().isInteger()
}
