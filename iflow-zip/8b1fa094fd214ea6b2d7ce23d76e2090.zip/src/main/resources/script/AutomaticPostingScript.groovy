import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def messageLog = messageLogFactory.getMessageLog(message);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	def lastSyncDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss",message.getProperty("queryLastRunTime"));
	def custGoodsRec = message.getProperty("CustGoodsRec");
	def itemList = []
	def materialDocumentList = []
	
	if (null!=object.A_MaterialDocumentItem && !object.A_MaterialDocumentItem.isEmpty()) {
	    itemList = object.A_MaterialDocumentItem.A_MaterialDocumentItemType;
		
		if (!isCollectionOrArray(itemList)) {
			itemList = [itemList].toArray();		}
	}else{
	    itemList=message.getProperty("postingDocument")
	}
	
	// Batch Payload
    String completePayload = "";
  
    // Generate Random Id to be used in Batch Code
    String batchId = UUID.randomUUID().toString();
  
    // Prepare Batch Code
    String batchCode = "--batch_id-" + batchId; 

	// Generate changeset Id to be used in changeset Code
	String changesetID = UUID.randomUUID().toString();
	
	// Prepare changeset Code
	String changeset = "--changeset_" + changesetID; 
	
	completePayload=completePayload.concat(batchCode + "\n")
	completePayload=completePayload.concat("Content-Type: multipart/mixed; boundary=changeset_"+changesetID+ "\n")
	String underscore="_"
	// Prepare changeset data by looping the list of records
	itemList.each { record ->
	    def inBoundDelivery = "";
	    def externalDelivery = "";
	    def outboundDelivery="";
	    def outboundDeliveryCust="";
	    if(null==record.IsAutomaticallyCreated || ""==record.IsAutomaticallyCreated){
	    def header = record.to_MaterialDocumentHeader.A_MaterialDocumentHeaderType;
		if(record.Customer.isEmpty() && record.Supplier.isEmpty()){
            record.Customer=message.getProperty(record.Delivery)     
        }
		String tempPayload = changeset + "\n"
		tempPayload = tempPayload + "Content-Type:application/http " + "\n" + "Content-Transfer-Encoding:binary" + "\n" + "\n"
		tempPayload = tempPayload + "POST Documents HTTP/1.1" + "\n"
		tempPayload = tempPayload + "Accept:application/json;odata.metadata=minimal;IEEE754Compatible=true" + "\n" 
		tempPayload = tempPayload + "Accept-Language:en-US" + "\n" 
		tempPayload = tempPayload + "Content-Type:application/json;charset=UTF-8;IEEE754Compatible=true" + "\n" + "\n" 
		if(null!=record.Delivery && ""!=record.Delivery){
		    inBoundDelivery = record.Delivery.concat("IN")
		    externalDelivery = message.getProperty(inBoundDelivery) 
		    outboundDelivery = record.Delivery.concat("Outbound")
		    outboundDeliveryCust = message.getProperty(outboundDelivery)
		}

		def postingDocument = prepareDocument(header, record, externalDelivery, outboundDeliveryCust,custGoodsRec)
		tempPayload = tempPayload + JsonOutput.toJson(postingDocument) + "\n"	
		completePayload=completePayload.concat(tempPayload)
		materialDocumentList.add(record.MaterialDocument)
	    }
		
	}
	
	// Close the full payload
	completePayload = completePayload + "--changeset_" + changesetID + "--" + "\n"
	
	// Prepare Message Body
	message.setBody(completePayload)
	
	// Prepare Boundary Header Parameter to be added in message header
	String boundaryParam = "multipart/mixed; boundary=changeset_" + changesetID;
	
	message.setProperty("materialDocumentList",materialDocumentList)
	// Prepare Message Header
	message.setHeader('Content-Type', boundaryParam)
	message.setHeader('Prefer', "odata.continue-on-error")
	 /*if(messageLog != null && itemList.size() > 0){
        messageLog.setStringProperty("postingDocumentLog", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("RequestPayload_postingDocumentLog:", body , "text/plain");
    }*/
	
    return message
}

def Object prepareDocument(Object header, Object item, Object externalDelivery, Object outboundDeliveryCust,Object custGoodsRec) {

		def record = new Document().with  {
		        def outBoundConst="Outbound"
				assert delegate.class.name == 'Document'
				postingDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss",header.PostingDate).format('yyyy-MM-dd')
				documentDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss",header.DocumentDate).format('yyyy-MM-dd')
				//postingYear = Date.parse("yyyy-MM-dd'T'HH:mm:ss",header.PostingDate).format('yyyy')
				if (item.QuantityInBaseUnit != null){
				    //returnableMaterialQuantity = Integer.parseInt(item.QuantityInBaseUnit)   
				    returnableMaterialQuantity=(int)Double.parseDouble(item.QuantityInBaseUnit)
				    
				}
			
				returnableMaterialUOM_code = item.EntryUnit
				plant = item.Plant
				if(custGoodsRec=="X"){
				    if(null!=item.GoodsRecipientName && ""!=item.GoodsRecipientName && null!=item.Customer && ""!=item.Customer){ 
				        if(item.GoodsRecipientName.length()> 10){
				            customerCode = item.GoodsRecipientName.substring(0, 10);
				        }else{
				            customerCode = item.GoodsRecipientName;    
				        }
				        
                    }else{
                        if(null!=item.Customer && ""!=item.Customer){
				            customerCode = item.Customer    
				        } else {
                            if(null!=outboundDeliveryCust &&""!=outboundDeliveryCust){
				                customerCode=outboundDeliveryCust
				            }
                      
				        }    
                    }    
				}else {
                    if(null!=item.Customer && ""!=item.Customer){
				        customerCode = item.Customer    
				    } else {
                          if(null!=outboundDeliveryCust &&""!=outboundDeliveryCust){
				            customerCode=outboundDeliveryCust
				        }
                      
				    }
                }
	            storageLocation=item.StorageLocation
                unloadingPoint=item.UnloadingPointName
				vendorCode = item.Supplier
				movementType = item.GoodsMovementType
				//inventoryStockTypeID_ID = item.InventoryStockType
				inventoryStockTypeID_ID = fetchInventoryUsabilityCode(item)
				materialCode = item.Material
				materialDocumentNumber = item.MaterialDocument
				materialDocumentItemNumber = item.MaterialDocumentItem
				if (item.DeliveryItem != null) {
                    deliveryNoteItemNumber = Integer.parseInt(item.DeliveryItem)
                }
                if(!item.to_MaterialDocumentHeader.isEmpty() && !item.to_MaterialDocumentHeader.A_MaterialDocumentHeaderType.isEmpty() &&
				       item.to_MaterialDocumentHeader.A_MaterialDocumentHeaderType.ReferenceDocument != null){
				    deliveryNote = item.to_MaterialDocumentHeader.A_MaterialDocumentHeaderType.ReferenceDocument
				}
				postingDocSerialNumbers = prepareSerialNumberList(item)
				if(null!=item.IssuingOrReceivingPlant && ""!=item.IssuingOrReceivingPlant){
				    if(null==item.Delivery || ""==item.Delivery){
				        receivingPlant=item.IssuingOrReceivingPlant    
				    }
				}
				
				if(null!=externalDelivery && !externalDelivery.isEmpty()){
				    externalDeliveryNoteNumber = externalDelivery
				}else{
				    externalDeliveryNoteNumber = deliveryNote
				}
				if(null!=header.MaterialDocumentYear && !header.MaterialDocumentYear.isEmpty()){
				    //materialDocumentYear = Integer.parseInt(header.MaterialDocumentYear)
				    materialDocumentYear = header.MaterialDocumentYear
				    
				}
				if (null!=header.MaterialDocumentHeaderText && !header.MaterialDocumentHeaderText.isEmpty()) {
                    referenceDocument = prepareBillOfLaden(header)
                }
				
			return delegate
        }
		
	return record;
}

def Object fetchInventoryUsabilityCode(record){
    def stockType="01"
    if(record.InventoryUsabilityCode!=null && !record.InventoryUsabilityCode.isEmpty()){
        if(record.InventoryUsabilityCode=="2" || record.InventoryUsabilityCode=="X"){
            stockType="02"
        }
        else if(record.InventoryUsabilityCode =="3" || record.InventoryUsabilityCode=="S"){
            stockType="07"
        }else if(record.InventoryUsabilityCode =="F"){
            stockType="01"
        }
    }
    return stockType
}

def Object prepareSerialNumberList(record) {

	def postingDocSerialNumbers = []
	if (null!=record.to_SerialNumbers && !record.to_SerialNumbers.isEmpty()) {
	   def serialNumbersList = record.to_SerialNumbers.A_SerialNumberMaterialDocumentType;
	   if (!isCollectionOrArray(serialNumbersList)) {
			serialNumbersList = [serialNumbersList].toArray();
	    }
	   for(Object serialNumberObj in serialNumbersList) {
    		def serialNumberItem = prepareSerialNumberItem(serialNumberObj);
    		postingDocSerialNumbers.add(serialNumberItem)
        }
	
	}
	return postingDocSerialNumbers;
}

def Object prepareBillOfLaden(record) {

	def referenceDocument = []
	if (null!=record.MaterialDocumentHeaderText && !record.MaterialDocumentHeaderText.isEmpty()) {
	    referenceDocument = prepareRefrenceDocument(record.MaterialDocumentHeaderText)
	   }
	return referenceDocument;
}

def Object prepareSerialNumberItem(Object item) {

		def record = new SerialNumber().with  {
				assert delegate.class.name == 'SerialNumber'
				serialNumberCode = item.SerialNumber
			return delegate
        }
		
	return record;
}


def Object prepareRefrenceDocument(String documentHeaderText){
    def record = new ReferenceDocument().with  {
				assert delegate.class.name == 'ReferenceDocument'
				billOfLading = documentHeaderText
			return delegate
        }
        
    return record;        
}

class SerialNumber {
    String serialNumberCode
}

class ReferenceDocument{
    String billOfLading
}




class Document {
    String postingDate, documentDate, returnableMaterialUOM_code, plant, customerCode, vendorCode, movementType, materialCode, materialDocumentNumber, materialDocumentItemNumber, deliveryNote,inventoryStockTypeID_ID,receivingPlant,externalDeliveryNoteNumber,materialDocumentYear,storageLocation,unloadingPoint
	int returnableMaterialQuantity, deliveryNoteItemNumber
	def postingDocSerialNumbers
	def referenceDocument
}


//Returns true if object is an array
boolean isCollectionOrArray(object) {
    [Collection, Object[]].any {
        it.isAssignableFrom(object.getClass())
    }
}