import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import java.time.LocalDateTime

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString("ResponsePayload_postingDocumentLog: ", body , "text/plain");
	throw new IOException();

	message.setBody(completePayload)
	
	
	message.setProperty("DocumentPosted", docPosted);
    return message
}

