/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message
import java.util.Date
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.HashMap
import groovy.xml.XmlUtil
import groovy.util.XmlParser
import com.sap.it.api.mapping.*
import com.sap.it.api.securestore.*
import com.sap.it.api.ITApiFactory
import java.util.Calendar

def Message formatCompanyCodes(Message message){
//This script is to add single quotes to each of the company codes

    def pMap = message.getProperties()
    def companyCodes = pMap.get("CompanyCode")
    if(!(companyCodes.trim().isEmpty())){
        //Split the multiple company codes inputted from the exernal parameter
        def ids = companyCodes.split(',')
        def formattedIDs = ""
        //Add single quotes
        for (int i = 0; i < ids.size(); i++){
            formattedIDs = formattedIDs + "'" + ids[i] + "'" + ","
        }
        
        formattedCompanyCodes =  formattedIDs.reverse().drop(1).reverse()
    }
    else{
        def exceptionBody = "Please maintain value for company codes"
        throw new Exception(exceptionBody)
    }
    message.setProperty("formattedCompanyCodes", formattedCompanyCodes)
    return message
}
def Message queryBuilder(Message message){
    
    //This script is used to build the query for Success Factors call
    def pMap = message.getProperties()
    def lastModifiedOn = pMap.get("LastModifiedOn")
    def fromDateExt = pMap.get("fromDate")
    def lastExecutionTimeStampPersisted = pMap.get("LastExecutionTimeStampPersisted")
    def formattedCompanyCodes = pMap.get("formattedCompanyCodes")
   
    //Format the dates based on the query requirement
    DateFormat onlyDate= new SimpleDateFormat("yyyy-MM-dd",Locale.ENGLISH)
    Date date = new Date()
    String today = date.format("yyyy-MM-dd")
    
     def parameters = "queryMode=periodDelta;"
     //check if first run of the day
	    if(!(lastExecutionTimeStampPersisted.isEmpty())){
	        Date dateCheck = onlyDate.parse(lastExecutionTimeStampPersisted)
	        String dateString = dateCheck.format("yyyy-MM-dd")
	        if(dateString == today)//not first run
	        {
	            parameters = parameters + "resultOptions=isNotFirstQuery;"
	        }
	    }
	    parameters = parameters + "resultOptions=renderPreviousTags"

    //Add company codes to the filter query
    def filterQuery = "company in (" + formattedCompanyCodes + ")"
    
    //If LastModifiedOn (external parameter) is not blank, 
	//use the same for the 'last_modified_on', the next day for 'fromDate' and current date for 'toDate'
	if(!(lastModifiedOn.trim().isEmpty())){	    
	    
	    Date advanceDate = onlyDate.parse(lastModifiedOn) + 1
	    String fromDate = ""
	    if(!(fromDateExt.isEmpty())){
	        fromDate = fromDateExt
	    }
	    else {fromDate = advanceDate.format("yyyy-MM-dd")}
	    String toDate = ""
	    //'fromDate' should not be greater than 'toDate'
	    if(advanceDate>date){
	        toDate = fromDate
	    }
	    else{
	        toDate = today
	    }
	  
		if(!(filterQuery.isEmpty())){
                filterQuery = filterQuery + " " + "AND" + " " + "last_modified_on > to_datetime('" +
				lastModifiedOn+ "')"+ " AND " + "fromDate = to_date('"+fromDate+ "','yyyy-mm-dd') AND toDate = to_date('"+
				toDate+"','yyyy-mm-dd')"
            }
            else{
                filterQuery = "last_modified_on > to_datetime('" +lastModifiedOn+ "')"+ " AND " + 
				"fromDate = to_date('"+fromDate+ "','yyyy-mm-dd') AND toDate = to_date('"+
				toDate+"','yyyy-mm-dd')"
            }
        
	}
	
	//If LastModifiedOn(external parameter)is blank, use the last execution timestamp from the variables
	else{
	    String modDate=lastExecutionTimeStampPersisted+'Z';
	    Date advanceModDate = onlyDate.parse(lastExecutionTimeStampPersisted) + 1
	    String fromDate = advanceModDate.format("yyyy-MM-dd")
	    String toDate
	    //'fromDate' should not be greater than 'toDate'
	    if(advanceModDate>date){
	        toDate = fromDate
	    }
	    else{
	        toDate = today
	    }
	    
	    if(!(filterQuery.isEmpty())){
                filterQuery = filterQuery + " " + "AND" + " " + "last_modified_on > to_datetime('" +
				modDate+ "')"+ " AND " + "fromDate = to_date('"+fromDate+ "','yyyy-mm-dd') AND toDate = to_date('"+
				toDate+"','yyyy-mm-dd')"
            }
            else{
                filterQuery = "last_modified_on > to_datetime('" +modDate+ "')"+ " AND " + "fromDate = to_date('"+
				fromDate+ "','yyyy-mm-dd') AND toDate = to_date('"+toDate+"','yyyy-mm-dd')"
            }
        
	}
	message.setProperty("parameters", parameters)
	message.setProperty("filterQuery", filterQuery)
	
    return message
}    
def Message concatPayload(Message message) 
{
    //This script merges payload fetched on every loop execution  
    
    map = message.getProperties();
    def  value = map.get("ConcatPayload")
    String mergePayload = '';
    String str1 = message.getBody(String.class)
	if (value != null)
	{
    	mergePayload = value + str1;
	}
	else
	{ 
	   mergePayload = str1;
	    
	}
	
    message.setProperty("ConcatPayload", mergePayload);
   	return message;
}
def Message convertToCSV(Message message)
{
    //convert payload to flat file, no delimiter
    def input = message.getBody(java.io.Reader)
    def map = "true"
    def content = new XmlSlurper(keepWhitespace:map).parse(input)
    def header = content.Header.children().collect().join('')
    //group all the records by record number
    def csv = content.Records.Record1.inject(header){result, row -> 
    [result,row.children().collect().join('')].join("\n")}
    header=""
    csv = csv + content.Records.Record02D.inject(header){result, row -> 
    [result,row.children().collect().join('')].join("\n")}
    csv = csv + content.Records.Record02E.inject(header){result, row -> 
    [result,row.children().collect().join('')].join("\n")}
    csv = csv + content.Records.Record301.inject(header){result, row -> 
    [result,row.children().collect().join('')].join("\n")}
    csv = csv + content.Records.Record302.inject(header){result, row -> 
    [result,row.children().collect().join('')].join("\n")}
    csv = csv + content.Records.Record4.inject(header){result, row -> 
    [result,row.children().collect().join('')].join("\n")}
    csv = csv + content.Records.Record6.inject(header){result, row -> 
    [result,row.children().collect().join('')].join("\n")}
    csv = csv + content.Records.Record11.inject(header){result, row -> 
    [result,row.children().collect().join('')].join("\n")}
    csv = csv + content.Records.Record60.inject(header){result, row -> 
    [result,row.children().collect().join('')].join("\n")}
    message.setBody(csv.toString())
    return message
}
def Message determineEvents(Message message)
{
    def input = message.getBody(java.io.Reader)
    def map = "true"
    def content = new XmlSlurper(keepWhitespace:map).parse(input)
    def records = [:]
    content.CompoundEmployee.person.each { person ->
        def recReqd = []
        
        //Change in DOB
        if (!(person.action.text().equalsIgnoreCase("NO CHANGE")) && person.date_of_birth_previous.text()!= null){
                recReqd.add("02D")}
                
        //Change in employee no
        if (!(person.action.text().equalsIgnoreCase("NO CHANGE")) && person.person_id_external_previous.text()!= null){
                recReqd.add("02E")}
        
        person.employment_information.job_event_information.each { emplInfo ->
        if(!(emplInfo.action.text().equalsIgnoreCase("NO CHANGE"))){
        //Check for hire or rehire
            if (emplInfo.event.text().equalsIgnoreCase("H")|| emplInfo.event.text().equalsIgnoreCase("R")){
                recReqd.add("1")
                recReqd.add("02D")
                recReqd.add("02E")
                recReqd.add("3")
                recReqd.add("4")
                recReqd.add("6")
                recReqd.add("11")}
           //Event Reason = Death     
            if (emplInfo.event_reason.text().equalsIgnoreCase("TER_DTH")){
                recReqd.add("02D")   
                recReqd.add("11")}
            //Short term disability
            if (emplInfo.event_reason.text().equalsIgnoreCase("PLA_PST")){
                recReqd.add("11") }
            //Long term disability, retirement
            if (emplInfo.event_reason.text().equalsIgnoreCase("PLA_ULT") 
            || emplInfo.event_reason.text().equalsIgnoreCase("TER_RTM") 
            || emplInfo.event_reason.text().equalsIgnoreCase("TER_ERT") 
            || emplInfo.event_reason.text().equalsIgnoreCase("TER_RET")){
                recReqd.add("02D")
                recReqd.add("11")  }
            //Termination
            if (emplInfo.event.text().equalsIgnoreCase("26")){
                recReqd.add("02D")    
                recReqd.add("11")}
            //LOA-unpaid by employer
            if (emplInfo.event_reason.text().equalsIgnoreCase("PLA_ASL") 
            || emplInfo.event_reason.text().equalsIgnoreCase("PLA_UFC") 
            || emplInfo.event_reason.text().equalsIgnoreCase("PLA_UMT") 
            || emplInfo.event_reason.text().equalsIgnoreCase("PLA_PML") 
            || emplInfo.event_reason.text().equalsIgnoreCase("PLA_UPM") 
            || emplInfo.event_reason.text().equalsIgnoreCase("PLA_UPL") ){
                recReqd.add("02D")
                recReqd.add("11") }
             //LOA-paid by employer
            if (emplInfo.event_reason.text().equalsIgnoreCase("PLA_PAS") 
            || emplInfo.event_reason.text().equalsIgnoreCase("PLA_PFC") 
            || emplInfo.event_reason.text().equalsIgnoreCase("PLA_MTL") 
            || emplInfo.event_reason.text().equalsIgnoreCase("PLA_POL") 
            || emplInfo.event_reason.text().equalsIgnoreCase("PLA_MIL") 
            || emplInfo.event_reason.text().equalsIgnoreCase("PLA_CML") 
            || emplInfo.event_reason.text().equalsIgnoreCase("PLA_PPM") 
            || emplInfo.event_reason.text().equalsIgnoreCase("PLA_PPL")){
                recReqd.add("11") }
            //Military leave, return from leave
            if (emplInfo.event_reason.text().equalsIgnoreCase("PLA_MLV") 
            || emplInfo.event_reason.text().equalsIgnoreCase("RFL_RFL")){
                recReqd.add("11")    }
        }
    }
    
    person.personal_information.each { perInfo ->
    
            //Check for name change
            if (!(perInfo.action.text().equalsIgnoreCase("NO CHANGE")) && perInfo.formal_name_previous.text()!= null){
                recReqd.add("1")}
               
    }
    
    person.address_information.each { addrInfo ->
    
            //Check for address change
            if (!(addrInfo.action.text().equalsIgnoreCase("NO CHANGE")) && (addrInfo.address1_previous.text()!= null 
            || addrInfo.address2_previous.text()!= null 
            || addrInfo.address4_previous.text()!= null || addrInfo.address_type_previous.text()!= null 
            || addrInfo.city_previous.text()!= null || addrInfo.country_previous.text()!= null 
            || addrInfo.zip_code_previous.text()!= null || addrInfo.address5_previous.text()!= null)){
                recReqd.add("3")
                recReqd.add("4")}
               
    }
    recReqd.unique()
    records.put(person.person_id_external.text().toString(),recReqd)
    
    
}
message.setProperty("records", records)
return message
}
def String checkRecords(String record,String personid, MappingContext context) {
    // Check which records are applicable for the employee
         def recReqd = context.getProperty("records")
         def records = recReqd.get(personid)
         if(records.contains(record)){
         return "true"}
         else {return "false"}
}
def String participantDate(String date) {
    //Get first day of next month for the value of field: participantDate     
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd",Locale.ENGLISH)
    String value = date
    Date myDate = sdf.parse(value)
    
    Calendar cal = Calendar.getInstance()
    cal.setTime(myDate)
    def nextMonth = cal[(Calendar.MONTH)]+1 //get next month
    cal.set(Calendar.MONTH, nextMonth)
    cal.set(Calendar.DAY_OF_MONTH, 1) // first day of the next month
    
    Date firstDayOfnextMonth = cal.getTime()
    return firstDayOfnextMonth.format("MMddyyyy")
}
def String zipcode(String zipcode){
    //Logic for the field zip+4code - 4 characters post hyphen in zipcode field
    String[] zip
    def zip4code
    if (zipcode.contains('-'))
    {
        zip = zipcode.split('-')
        zip4code = zip[1]
    }
    else {zip4code = "    "}
    return zip4code
}
def String padding(String input, int fieldLength){
    //Check the required fieldlength and add padding/truncate as necessary
    int padding = fieldLength-input.length()
    if (input.length()< fieldLength){
        for(int i=0;i<padding;i++){
            input=input+" " //add padding
        }
    }
    else if (input.length()> fieldLength){
        input = input.substring(0,fieldLength)} //truncate to the required field length
    return input
}
def Message convertToFile(Message message){
    //convert simple xml to csv format
    def input = message.getBody(java.io.Reader)
    def map = "true"
    def content = new XmlSlurper(keepWhitespace:map).parse(input)
    def csv = "Employee Numbers:\n" + content.Employee.children().collect().join('\n')
    message.setBody(csv.toString())
    return message
}
def Message storeLocations(Message message){
    
    //This script is to fetch the names of the location from EC and store them in a HashMap
    
    //message Body
    def records = message.getBody(java.io.Reader)
    
    // Define XML parser for records
    def xmlRecords = new XmlParser().parse(records)
    
    //Add values in locations HashMap
    def locations = [:]
    xmlRecords.each { p -> locations.put(p.externalCode[0].text().toString(),(p.name[0].text().toString()))}
    
    //Store the locations HashMap as a property
    message.setProperty("locations", locations)
    
    return message
}
def Message replaceCodes(Message message){
    
    //This script is to replace location codes with the names from the HashMaps
    
    def records = message.getBody(java.io.Reader)
    def map = message.getProperties()
    String locationName
    
    def locations = map.get("locations")
    
    def xmlRecords = new XmlParser().parse(records)
    xmlRecords.Records.Record6.each
	{   
	    it ->
	    if(it.DivisionName[0] != null){
	        locationName = locations.get(it.DivisionName[0].text())
	        Node replace = new Node(null, 'DivisionName',locationName)
	        it.DivisionName[0].replaceNode(replace)
	    }
	}
	message.setBody(XmlUtil.serialize(xmlRecords))
	return message
}
def String replaceLocation(String location, MappingContext context){
    
    //This script is to replace location codes with the names from the HashMaps
    
    String locationName
    def locations = context.getProperty("locations")
    locationName = locations.get(location)
    
	return locationName
}

def String populateHeaderInformation(String externalParameter, MappingContext context){
    
    //This script is to replace External Parameter value used during configuration of iFlow. If no value is maintained the empty value will be passed
    
    def externalParameterValue = context.getProperty(externalParameter)
    if(externalParameterValue == null)
        externalParameterValue = ''
        
	return externalParameterValue
}



