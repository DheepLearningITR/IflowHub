/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import java.util.HashMap
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
def Message processErrorMessage(Message message) {  //For EMEvent type FAILED

	def msg = message.getProperties().get("CamelExceptionCaught").getMessage().toString() //Extract exception message
	def messageLog = messageLogFactory.getMessageLog(message)
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssz",Locale.ENGLISH)
	sdf.setTimeZone(TimeZone.getTimeZone("GMT"))
	String date = sdf.format(new Date()).replace("GMT","Z")
	
	if(msg.contains("download throwable"))
	{
		msg="No data returned from Employee Central"
	}
	
	message.setProperty("exceptionMessage",msg)   //store exception message as a property
	messageLog.addCustomHeaderProperty("ErrorMsg",msg)
	messageLog.addCustomHeaderProperty("Status","Error")
	message.setProperty("eventTime",date)
	
	return message
}
def Message logSFPayload(Message message) {
    
	def body = message.getBody(java.lang.String) as String    
    def map = message.getProperties()
	def isLogEnabled=map.get("enableLogging")
	def logConfig = map.get("SAP_MessageProcessingLogConfiguration")
	def logLevel = (String) logConfig.logLevel
	
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
        // Only log when LogLevel of iFlow == Debug || Trace
        if(((logLevel.equals("DEBUG") || logLevel.equals("TRACE")) && ( isLogEnabled .equalsIgnoreCase("Y")))) {
            //def formattedData = XmlUtil.serialize(body) 
            messageLog.addAttachmentAsString("Step 1: Input from SF EC", body, "text/xml")
        } 
    }
    
    return message
}
def Message logPostMapping(Message message) {
    
	def body = message.getBody(java.lang.String) as String    
    def map = message.getProperties()
	def isLogEnabled=map.get("enableLogging")
	def logConfig = map.get("SAP_MessageProcessingLogConfiguration")
	def logLevel = (String) logConfig.logLevel
	
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
        // Only log when LogLevel of iFlow == Debug || Trace
        if(((logLevel.equals("DEBUG") || logLevel.equals("TRACE")) && ( isLogEnabled .equalsIgnoreCase("Y")))) {
            //def formattedData = XmlUtil.serialize(body) 
            messageLog.addAttachmentAsString("Step 2: Output to Fidelity", body, "text/xml")
        } 
    }
    message.setProperty("ECPayload",body)
    return message
}
def Message logEmptyFileMessage(Message message)
{   //When record count is 0
	def messageLog = messageLogFactory.getMessageLog(message)

	//Add below custom header logs on monitor
	messageLog.addCustomHeaderProperty("Msg", "No records were changed since last run")
	
	return message;
}
def Message logSuccessResponse(Message message) {
    
	def body = message.getBody(java.lang.String)
	def map = message.getProperties()
	def isLogEnabled=map.get("enableLogging")
	def logConfig = map.get("SAP_MessageProcessingLogConfiguration")
	def logLevel = (String) logConfig.logLevel
	
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
        // Only log when LogLevel of iFlow == Debug || Trace
        if(((logLevel.equals("DEBUG") || logLevel.equals("TRACE")) && ( isLogEnabled .equalsIgnoreCase("Y")))) {
            //def formattedData = XmlUtil.serialize(body) 
	messageLog.addAttachmentAsString("Step 3: Succcessful employees", body, "text/xml")
        }
    }
        
    return message
}
def Message logFailureResponse(Message message) {
    
	def body = message.getBody(java.lang.String)
	def map = message.getProperties()
	def isLogEnabled=map.get("enableLogging")
	def logConfig = map.get("SAP_MessageProcessingLogConfiguration")
	def logLevel = (String) logConfig.logLevel
	
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null){
        // Only log when LogLevel of iFlow == Debug || Trace
        if(((logLevel.equals("DEBUG") || logLevel.equals("TRACE")) && ( isLogEnabled .equalsIgnoreCase("Y")))) {
            //def formattedData = XmlUtil.serialize(body) 
    messageLog.addAttachmentAsString("Step 3: Failed Employees", body, "text/xml")
        }
    }
     
    return message
}

def Message processCompletedMessage(Message message) {  //For EMEvent type END
	
	//This script prints a summary report of the count of employees in the customer header & 
	//sets the eventTime for the execution manager as the current time
	def messageLog = messageLogFactory.getMessageLog(message)
	def map = message.getProperties()
	def totalEmpCount = map.get("TotalEmpCount")
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssz",Locale.ENGLISH)
	sdf.setTimeZone(TimeZone.getTimeZone("GMT"))
	String date = sdf.format(new Date()).replace("GMT","Z")
	message.setProperty("ProcessCompleted","Process Completed")
	message.setProperty("eventTime",date)
	String summary = "Total No. of Employees: "+totalEmpCount
	messageLog.addCustomHeaderProperty("Summary Report",summary)
	message.setProperty("summary",summary)
	messageLog.addCustomHeaderProperty("SuccessMsg", "Posted successfully to Fidelity")
	
	return message
}