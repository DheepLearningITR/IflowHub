import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {

	def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	
    def isError;
	
	// Batch Payload
    String completePayload = "{\"row\":";
	
	completePayload = completePayload + body + "}"
	
	message.setProperty("isError", "true");
     
	//Setting the timestamp
	def now = new Date();
	message.setProperty("timestamp", now.format("yyyyMMddHHmmss", TimeZone.getTimeZone('UTC')));

	if(!completePayload.contains("Error"))
	{
	 message.setProperty("isError", "false");
	}

	message.setBody(completePayload);
	return message;
}