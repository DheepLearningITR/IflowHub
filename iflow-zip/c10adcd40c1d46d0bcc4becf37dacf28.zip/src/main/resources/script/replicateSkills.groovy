import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.json.JsonOutput;

def Message parseHeaders(Message message) {

	def map = message.getHeaders();

    def sfsfAttributeType = map.get("sfsfAttributeType");
	message.setProperty("sfsfAttributeType", sfsfAttributeType);
	
    def sfsfAttributeFound = map.get("sfsfAttributeFound");
	message.setProperty("sfsfAttributeFound", sfsfAttributeFound);
	
	def sfsfTagFound = map.get("sfsfTagFound");
	message.setProperty("sfsfTagFound", sfsfTagFound);
	
    def testRun = map.get("testRun");
	message.setProperty("testRun", testRun);	
	
    def sfsfDeactivateAttributes = map.get("sfsfDeactivateAttributes");
	message.setProperty("sfsfDeactivateAttributes", sfsfDeactivateAttributes);
	
    def sfsfUpdateAttributeTags = map.get("sfsfUpdateAttributeTags") ?: 'true';
	message.setProperty("sfsfUpdateAttributeTags", sfsfUpdateAttributeTags);	
	
    def mapCBRCompetency2SFSFTag = map.get("mapCBRCompetency2SFSFTag");
	message.setProperty("mapCBRCompetency2SFSFTag", mapCBRCompetency2SFSFTag);	

	def sfsfSkillTypeTags = message.getProperties().get("sfsfSkillTypeTags") ?: "null";
	message.setProperty("sfsfSkillTypeTags",sfsfSkillTypeTags);
	
	//used to clear hashmap global variables
	def emptyHmap = new HashMap<String, String>();
	emptyHmap.put('null','');
	message.setProperty("emptyHmap", emptyHmap);	
	
	return message;
}


def Message gather_filenames(Message message) {
    def body = message.getBody(String);
    def root = new XmlSlurper().parseText(body);
    
    List<String> files = [
        "filenameUPD",
        "filenameUPDTags"
    ];

    files.each { file ->
        Set<String> filenames = new HashSet<>();
        def elements = root."$file";
        elements.each(){
            def fname = it.text().trim();
            if(fname && fname != '[]'){
                filenames.add(fname)
            }
        }
        if(!filenames.isEmpty()){
            message.setHeader(file, JsonOutput.toJson(filenames));
        }
    }
    
    return message;
}

def Message process_updates(Message message) {
	
	def body = message.getBody(java.lang.String);
	def map = message.getProperties();
	HashMap<String, String> hmap_cbrAttributes = map.get("hmap_cbrAttributes"); 
	if(hmap_cbrAttributes==null){
	    hmap_cbrAttributes = new HashMap<String, String>();	
	}	
	
	def sfsfDeactivateAttributes = map.get("sfsfDeactivateAttributes");
    
	//change status 
	def updatesFound = false;
	def sumReactivate = 0;
	def sumArchive = 0;
	def Root = new XmlParser().parseText(body);
	
    Root.AttributeEntity.each{r->
        def cbrAttribId = r.externalId[0].text().replaceFirst(/^cbr_/, ""); //remove prefix
        if(hmap_cbrAttributes.containsKey(cbrAttribId)){
            //Attribute FOUND in Talent, check status
            if(r.status[0].text() == 'I'){
                //Inactive Attribute FOUND in Talent, UPDATE
                r.status[0].value = "A";
                r.description[0].value = format_desc(r.description[0].text());
                sumReactivate = sumReactivate + 1; //counter
                updatesFound = true;
            }else{
                r.replaceNode{}; //remove node, Attribute still active
            }
        }else{
            if(sfsfDeactivateAttributes=='false'){
                //do NOT deactivate attributes!
                r.replaceNode{};
            }else{
                //Attribute NOT FOUND in Talent, check status
                if(r.status[0].text() == 'A'){
                    //ACTIVE Attribute NOT FOUND in Talent, check status ARCHIVE
                    r.status[0].value = "I"
                    r.description[0].value = format_desc(r.description[0].text());
                    sumArchive = sumArchive + 1; //counter
                    updatesFound = true;
                }else{
                    r.replaceNode{}; //remove node, Attribute already inactive
                }
            }
        }
    }
    
    message.setProperty("sfsfAttributes_payload",null);   //clear processed data
    
    message.setBody(XmlUtil.serialize(Root));
    message.setHeader("sumArchive",sumArchive.toString());
    message.setHeader("sumReactivate",sumReactivate.toString());
    message.setProperty("updatesFound", updatesFound.toString());
    
	return message;
}

def String escapeText(txt){
    //escape special including '&'. This is a TEMPORARY fix until SAP Fixes Note 3459488!!  
    //txt = StringEscapeUtils.escapeHtml4(txt);        
    def stxt = txt.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    return stxt;
}

def String format_desc(description){
    String descr = description;
    descr = descr.replaceAll(/\/n/, "\n");  //replace with actual new line
    descr = descr.replaceAll ('"','\\\\\\"'); //escape double quotes
    descr = descr.take(4000);  //4000 char limit    
    return descr;
}

def Message filter_cbrCompetencies(Message message) {
    
    def body = message.getBody(java.lang.String)
    def map = message.getProperties();
    
    def sfsfSkillTypeTags = map.get("sfsfSkillTypeTags");
	HashMap<String, String> hmapTags = map.get("hmap_sfsfTags");
	if(hmapTags==null){
	    hmapTags = new HashMap<String, String>();	
	}
	
    HashMap<String, String> hmap_cbrComp = new HashMap<String, String>();	
	HashMap<String, String> hmap_cbrSkillType = new HashMap<String, String>();	
	
	Set<String> hsetSkillTypeTags = map.get("hsetSkillTypeTags");
	if(hsetSkillTypeTags==null){
	    hsetSkillTypeTags = new HashSet<>();
	}	
	
    Set<String> missingTags = new HashSet<>();

    //check if universal tag exists in sfsf
    def sfsfAttributeTagIsMissing = false;
    missingTags = check_uniAttributeTag_ifExists(missingTags, message);
    if(!missingTags.isEmpty()){
        sfsfAttributeTagIsMissing = true;
    }

    def Root = new XmlParser().parseText(body);
    Root.attribute.each{s->
        
        //INT-362 Soft & Hard Skills tagging if it's configured
        if(sfsfSkillTypeTags!="null"){
            if(s.skillType[0].text()){
                def sfsfTagId = 'cbr_'+s.skillType[0].text();

                if(sfsfSkillTypeTags.contains(sfsfTagId)){
                    //skillType exists in the VM SkillTypeTags configuration 
                    if(hmapTags.containsKey(sfsfTagId)){
                        //add only if the skillType's sfsfTag exists in sfsf
                        hmap_cbrSkillType.put(s.id[0].text(),sfsfTagId);
                        hsetSkillTypeTags.add(sfsfTagId);
                    }else{
                        //Id does not exist, add to missing list
                        missingTags.add(sfsfTagId);
                        s.skillType[0].replaceNode{};   //skillTypeTag does not exist in SFSF, remove node
                    }
                }else{
                    //skillType does not exist in VM Config, remove node
                    s.skillType[0].replaceNode{};
                }
            }
        }else{
            //no skillTypeTags configured, remove node
            s.skillType[0].replaceNode{};
        }
    
        s.competency.each{c->
            if(c.id){
                /*sample value: <competency>
                                    <id>f63a2370-a548-5a3b-9c14-8e6b4815e5c9,4ca7e38f-9c3c-531d-a6e3-b3ef3cc2b80f</id>
                                </competency>*/
                def compIds = c.id[0].text().split(",");
                def existingCompIds = '';  //initialize each skill
                compIds.each{ compId ->
                    def sfsfTagId = 'cbr_'+compId;
                    if(hmapTags.containsKey(sfsfTagId)){
                        //include CompetencyId in list if FOUND
                        if(existingCompIds==''){
                            existingCompIds = sfsfTagId; 
                        }else{
                            //concatenate Id
                            existingCompIds = existingCompIds+'|'+sfsfTagId;
                        }
                    }else{
                        //Id does not exist, add to missing list
                        missingTags.add(sfsfTagId);
                    }
                }
                if(existingCompIds==''){
                    //no existing Comp Ids found
                     c.replaceNode{};  //remove competency Node
                }else{
                    c.id[0].value = existingCompIds; //replace with competency list that's already existing as sfsf Tag
                    hmap_cbrComp.put(s.id[0].text(),existingCompIds); //add to hmap
                }
            }
        }
    }
    
    //do not clear hmap_sfsfTags as it's still used in the Create tags
    message.setBody(XmlUtil.serialize(Root));
    
    if(sfsfAttributeTagIsMissing == true && hmap_cbrSkillType.isEmpty() && hmap_cbrComp.isEmpty() ){
        //no tags found
        message.setProperty("sfsfUpdateAttributeTags", 'false');
    }else{
        if(!hmap_cbrSkillType.isEmpty()){
            message.setProperty("hmap_cbrSkillType",hmap_cbrSkillType);
        }    
        if(!hmap_cbrComp.isEmpty()){
            message.setProperty("hmap_cbrComp",hmap_cbrComp);
        }
    }
    
    if(hsetSkillTypeTags.size() > 0){
        message.setProperty("hsetSkillTypeTags",hsetSkillTypeTags);
    }
    
    message.setHeader("sumMissingTags", missingTags.size());
    message.setHeader("missingTags",JsonOutput.toJson(missingTags));        
    return message;
}


def Message build_hmapCBRSkillType(Message message) {
    
    //INT-362 Soft & Hard Skills tagging
    def body = message.getBody(java.lang.String)
    def map = message.getProperties();
    def sfsfSkillTypeTags = map.get("sfsfSkillTypeTags");
    
    HashMap<String, String> hmapTags = map.get("hmap_sfsfTags");
	if(hmapTags==null){
	    hmapTags = new HashMap<String, String>();	
	}
	
	Set<String> hsetSkillTypeTags = map.get("hsetSkillTypeTags");
	if(hsetSkillTypeTags==null){
	    hsetSkillTypeTags = new HashSet<>();
	}
	
    HashMap<String, String> hmap_cbrSkillType = new HashMap<String, String>();	
	Set<String> missingTags = new HashSet<>();
	
    //check if universal tag exists in sfsf
    def sfsfAttributeTagIsMissing = false;
    missingTags = check_uniAttributeTag_ifExists(missingTags, message);
    if(!missingTags.isEmpty()){
        sfsfAttributeTagIsMissing = true;
    }
	
	def skillTypeTagExists = false;    
    def Root = new XmlParser().parseText(body);
    Root.attribute.each{s->
    
        if(s.skillType[0].text()){
            def sfsfTagId = 'cbr_'+s.skillType[0].text();
            
            if(sfsfSkillTypeTags.contains(sfsfTagId)){
                //skillType exists in the VM SkillTypeTags configuration 
                if(hmapTags.containsKey(sfsfTagId)){
                    //add only if the skillType's sfsfTag exists in sfsf
                    hmap_cbrSkillType.put(s.id[0].text(),sfsfTagId);
                    hsetSkillTypeTags.add(sfsfTagId);
                    skillTypeTagExists = true;  //process Tag Updates if at least 1 SkillType Tag is found
                }else{
                    //Id does not exist, add to missing list
                    missingTags.add(sfsfTagId);
                    s.skillType[0].replaceNode{}; //skillTypeTag does not exist in SFSF, remove node
                }    
            }else{
                //skillType does not exist in VM Config, remove node
                s.skillType[0].replaceNode{};
            }
        }
    }
    
    if(sfsfAttributeTagIsMissing==true && skillTypeTagExists==false ){
        //no tags found
        message.setProperty("sfsfUpdateAttributeTags", 'false');
    }else{
        if(!hmap_cbrSkillType.isEmpty()){
            message.setProperty("hmap_cbrSkillType",hmap_cbrSkillType);
        }    
    }
    
    if(hsetSkillTypeTags.size() > 0){
        message.setProperty("hsetSkillTypeTags",hsetSkillTypeTags);
    }
    
    message.setBody(XmlUtil.serialize(Root));
    message.setHeader("sumMissingTags", missingTags.size());
    message.setHeader("missingTags",JsonOutput.toJson(missingTags));      
    
    return message;
}


def Message check_uniAttributeTag(Message message) {
    
    def map = message.getProperties();
    def sfsfAttributeTag = map.get("sfsfAttributeTag"); //optional    
    
    Set<String> missingTags = new HashSet<>();
    if(sfsfAttributeTag){
        missingTags = check_uniAttributeTag_ifExists(missingTags, message);
        if(!missingTags.isEmpty()){
            //universal tag is missing!
            message.setProperty("sfsfUpdateAttributeTags", 'false');
        }
    }else{
        //not configured
        message.setProperty("sfsfUpdateAttributeTags", 'false');
    }
    
    message.setHeader("sumMissingTags", missingTags.size());
    message.setHeader("missingTags",JsonOutput.toJson(missingTags));        
    return message;
}

def Set<String> check_uniAttributeTag_ifExists(Set<String> missingTags, Message message){

    def map = message.getProperties();
    def sfsfAttributeTag = map.get("sfsfAttributeTag"); //optional
    HashMap<String, String> hmapTags = map.get("hmap_sfsfTags");
	if(hmapTags==null){
	    hmapTags = new HashMap<String, String>();	
	}  

    Set<String> missingTagsUpd = missingTags;

    if(sfsfAttributeTag){
        if(!hmapTags.containsKey(sfsfAttributeTag)){
            //Tag does not exist, add to missing list
            missingTags.add(sfsfAttributeTag);
            message.setProperty("sfsfAttributeTagIsMissing",true);
        }
    }

    return missingTagsUpd;
}

def Message process_tagUpdates(Message message) {
	
	def body = message.getBody(java.lang.String);
	def map = message.getProperties();
	def sfsfAttributeTag = map.get("sfsfAttributeTag") ?: ''; //optional
	def sfsfAttributeTagIsMissing = map.get("sfsfAttributeTagIsMissing") ?: 'false';

	HashMap<String, String> hmap_cbrAttributes = map.get("hmap_cbrAttributes"); 
	if(hmap_cbrAttributes==null){
	    hmap_cbrAttributes = new HashMap<String, String>();	
	}	
	
	HashMap<String, String> hmap_cbrComp = map.get("hmap_cbrComp"); 
	if(hmap_cbrComp==null){
	    hmap_cbrComp = new HashMap<String, String>();	
	}	
	HashMap<String, String> hmap_cbrSkillType = map.get("hmap_cbrSkillType"); 
	if(hmap_cbrSkillType==null){
	    hmap_cbrSkillType = new HashMap<String, String>();	
	}
	
	//change status 
	def updatesFound = false;
	def sumTagUpdates = 0;
	def Root = new XmlParser().parseText(body);
	
    Root.data.each{r->
        def updateSkill = false;
        def updatedTags = '';
        
        //INT-362 Soft & Hard Skills tagging
        //get sfsfTag based on Skill Type (e.g: {5e58f6bc-dd32-55fd-aeaa-a11d50bd6c31=cbr_soft})
        def cbrAttribId = r.libraryExternalId[0].text().replaceFirst(/^cbr_/, ""); //remove prefix
        
        def sfsfSkillTypeTag = hmap_cbrSkillType.get(cbrAttribId); 
        def sfsfTags    = r.tagExternalIds[0].text();
        def sfsfTagList = sfsfTags.split(",");        
        
        if(!hmap_cbrComp.isEmpty()){
            if(hmap_cbrComp.containsKey(cbrAttribId)){
                //Attribute FOUND in Cobrainer, lookup Competencies
    
                //e.g. {3a44a12c-df8f-56a3-b78f-ef24b74f5f35=cbr_a249b723-a811-54b6-856b-150adeaedffc|cbr_dc01bd88-b269-5f2f-a977-183f5f46ab4a|cbr_23026336-04ac-5732-bb47-b38710a2b299}
                def cbrCompIds  = hmap_cbrComp.get(cbrAttribId); 
                
                //INT-362 Soft & Hard Skills tagging
                if(sfsfSkillTypeTag){
                    //e.g. soft,hard
                    //include SkillTypeTag in the list of Competency Tags for existence check
                    cbrCompIds = cbrCompIds + '|' + sfsfSkillTypeTag;
                }
                
                sfsfTagList.each{sfsfTag->
                    if(!sfsfTag.contains('cbr_') || sfsfTag==sfsfAttributeTag || cbrCompIds.contains(sfsfTag)){
                        //Tag is NOT a Cobrainer Competency, OR is Cobrainer Generic Tag, OR Tag is a Cobrainer Competency and mapping is still valid in Cobrainer, do NOT remove
                        if(updatedTags==''){
                            updatedTags= sfsfTag;
                        }else{
                            updatedTags= updatedTags+','+sfsfTag;
                        }
                    }else{
                        //remove Tag, no longer found in Cobrainer Skill-Comp mapping
                        updateSkill = true;
                    }
                }
                
                //check if all of Cobrainer's Competency list is in SFSF 
                def cbrCompIdList = cbrCompIds.split("\\|");
                cbrCompIdList.each{compId->
                    //find cbrCompetencies which do not exist in SFSF Attribute Tag mapping
                    if(!sfsfTags.contains(compId)){
                        //Competency not found in sfsfTags, ADD!
                        updateSkill = true;
                        if(updatedTags==''){
                            updatedTags= compId;
                        }else{
                            updatedTags= updatedTags+','+compId;
                        }                    
                    }
                }
                
                //check if Cobrainer_Library tag is in SFSFTags
                if(sfsfAttributeTag!='' && sfsfAttributeTagIsMissing == 'false'){
                    if(!r.tagExternalIds[0].text().contains(sfsfAttributeTag)){
                        //Cobrainer Library tag missing, add tag
                        updateSkill = true;
                        if(updatedTags==''){
                            updatedTags=sfsfAttributeTag;
                        }else{    
                            updatedTags=updatedTags+','+sfsfAttributeTag;
                        }
                    }            
                }
            }
        }else if(sfsfSkillTypeTag){
            
            //INT-362 Soft & Hard Skills tagging is configured
            sfsfTagList.each{sfsfTag->
                if(!sfsfTag.contains('cbr_') || sfsfTag==sfsfAttributeTag || sfsfTag==sfsfSkillTypeTag){
                    //Tag is NOT a Cobrainer Competency, OR is Cobrainer Generic Tag, OR Tag is a Cobrainer Skill Type Tag, do NOT remove
                    if(updatedTags==''){
                        updatedTags= sfsfTag;
                    }else{
                        updatedTags= updatedTags+','+sfsfTag;
                    }
                }else{
                    //Competency tags (cbr_), since Comp>Tag is not configured, remove Competency Tags!!
                    updateSkill = true;
                }
            }
            
            if(!sfsfTags.contains(sfsfSkillTypeTag) ){
                //SkillTypeTag not found in sfsfTags, ADD!
                updateSkill = true;
                if(updatedTags==''){
                    updatedTags= sfsfSkillTypeTag;
                }else{
                    updatedTags= updatedTags+','+sfsfSkillTypeTag;
                }                
            }
            
            //check if Cobrainer_Library tag is in SFSFTags
            if(sfsfAttributeTag!='' && sfsfAttributeTagIsMissing == 'false'){
                if(!r.tagExternalIds[0].text().contains(sfsfAttributeTag)){
                    //Cobrainer Library tag missing, add tag
                    updateSkill = true;
                    if(updatedTags==''){
                        updatedTags=sfsfAttributeTag;
                    }else{    
                        updatedTags=updatedTags+','+sfsfAttributeTag;
                    }
                }            
            }
            
        }else if(sfsfAttributeTag!='' && sfsfAttributeTagIsMissing == 'false'){
            
            if(hmap_cbrAttributes.containsKey(cbrAttribId)){
                //update Tags only if it exists in Cobrainer! otherwise, it should've been for deactivation, do not touch the Tags
                sfsfTagList.each{sfsfTag->
                    if(!sfsfTag.contains('cbr_') || sfsfTag==sfsfAttributeTag ){
                        //Tag is NOT a Cobrainer Competency, OR is Cobrainer Generic Tag, do NOT remove
                        if(updatedTags==''){
                            updatedTags= sfsfTag;
                        }else{
                            updatedTags= updatedTags+','+sfsfTag;
                        }                       
                    }else{
                        //remove Cobrainer Tag as it should only have the Attribute Tag
                        updateSkill = true;
                    }
                }
                
                //check if universal Tag exists
                if(!r.tagExternalIds[0].text().contains(sfsfAttributeTag)){
                    //Cobrainer Library tag missing, add tag
                    updateSkill = true;
                    if(updatedTags==''){
                        updatedTags=sfsfAttributeTag;
                    }else{    
                        updatedTags=updatedTags+','+sfsfAttributeTag;
                    }
                } 
            }
        }
        
        if(updateSkill== true){
            sumTagUpdates++; //counter
            updatesFound = true;
            r.tagExternalIds[0].value = updatedTags; //update Tags
        }else{
            //attribute no longer found in Cobrainer Competencies OR SkillType, NO CHANGES, remove from payload
            r.replaceNode{};
        }        
        
    }
    
    message.setProperty("hmap_cbrAttributes",null);           //clear processed data
    message.setProperty("hmap_cbrSkillType",null);           //clear processed data
    message.setProperty("hmap_cbrSkillComp",null);           //clear processed data
    message.setProperty("sfsfAttributeTags_payload",null);   //clear processed data
    
    message.setBody(XmlUtil.serialize(Root));
    message.setHeader("sumTagUpdates",sumTagUpdates.toString());
    message.setProperty("updatesFound",updatesFound.toString());
    
	return message;
}

