/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

// Below is the format in which business logic error is raised from FSM for bulk messages.
// [{"status":400,"externalId":"1073260","ex":{"error":"CA-10","message":"CA-10: Object [Contact:123456] is not valid."}},{"status":400,"externalId":"1073260","ex":{"error":"CA-10","message":"CA-10: Object [Contact:B0DED0812E6943FB8FA7CF1B8B3B9B5C] is not valid.","values":["Contact","B0DED0812E6943FB8FA7CF1B8B3B9B5C"],"children":[{"error":"CA-154","message":"CA-154: Object [BusinessPartner] with externalId [1073024] was not found.","values":["BusinessPartner","1073024"],"id":"a9dd585acacd43868737efc98d7ada37"}],"id":"f47523f09b554de98269080f38df1b97"}},{"status":500,"externalId":null,"message":"RESTEASY003830: NULL value for template parameter: externalId"}]

def Message processData(Message message) {
     //Get Body and parse it.
       def body = message.getBody(String.class);
     //Input response body of bulk API from FSM is always an array, [{},{}]  
       def parsedObj = new JsonSlurper().parseText(body);
       def error_msg;
         for(n in parsedObj)
         {
            if (!(n.status == 201 || n.status == 200)) // 201 is created, which is sent by FSM on success create/update , 200 for successfull delete
            {
            // header level error message for each object instance in bulk message
                if (n.ex != null)
                {
                   if (n.ex.message != null)
                    {
                        if (error_msg == null)
                        {
                            error_msg = 'C4C ID ' + n.externalId + ':- ' + n.ex.message;
                        }
                        else
                        {
                            error_msg = error_msg + ' C4C ID ' + n.externalId + ':- ' + n.ex.message;
                        }
                        // for each object instance in bulk message if a detailed error message is present     
                        if (n.ex.children != null)
                        {
                            error_msg = error_msg + ' ' + n.ex.children.message;
                        }
                    }
                }
            //Another  structure of error message which may come   
                 if (n.message != null)
                {
                    if (error_msg == null)
                    {
                        error_msg = 'C4C ID ' + n.externalId + ':- ' + n.message;
                    }
                    else
                    {
                        error_msg = error_msg + ' C4C ID ' + n.externalId + ':- ' + n.message;
                    }
                }

            }
         }
         
         if ( error_msg != null)
         {
             throw new Exception(error_msg);
         }
         else
         {
             return message;
         }
       
}