import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    
    
                
                // get a map of iflow properties
                def map = message.getProperties();
                def header = message.getHeaders();
                def properties = message.getProperties();
                def responseCode = header.get("CamelHttpResponseCode");
                def payload = properties.get("P_Original_Payload") ;
                
                def messageLog = messageLogFactory.getMessageLog(message);
                if(messageLog != null)
                    {
                         messageLog.setStringProperty("Request Body", "Printing Payload As Attachment")
                         messageLog.addAttachmentAsString("Request Body", payload, "text/xml");
                     }
                
                if(responseCode == 400 || responseCode == 401 || responseCode == 403 || responseCode == 404)
                {
                    message.setBody(map.get("exception"));
                }
                
                
                else{
                    def ex = map.get("CamelExceptionCaught");
                    if (ex!=null) {
                                
                                //wrong Odata endpoint
                         if (ex.getClass().getCanonicalName().equals("com.sap.gateway.core.ip.component.odata.exception.OsciException") || ex.getClass().getCanonicalName().equals("com.google.common.util.concurrent.UncheckedExecutionException")){
                                header.put("CamelHttpResponseCode", 404 );
                                message.setBody(map.get("exception"));
                                                
                            }
                             //message mapping exception
                        else if(ex.getClass().getCanonicalName().equals("com.sap.xi.mapping.camel.XiMappingException"))
                        {
                            header.put("CamelHttpResponseCode", 400 );
                                message.setBody(map.get("exception"));
                        }
                        
                        //message mapping exception
                         else if(ex.getClass().getCanonicalName().equals("com.thoughtworks.xstream.converters.ConversionException"))
                         {
                             header.put("CamelHttpResponseCode", 400 );
                                message.setBody(map.get("exception"));
                         }
                         
                         //catch other generic exceptions
                         else 
                         {
                             header.put("CamelHttpResponseCode", 500 );
                                message.setBody(map.get("exception"));
                         }
                            
                    }
                }

                return message;
}