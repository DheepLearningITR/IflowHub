import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def compCode = message.getProperties().get("compExtCode");
		if(compCode != null){
			messageLog.addCustomHeaderProperty("sfsf_competencyExtCode", compCode);		
        }
        def jobExtId = message.getProperties().get("roleExtCode");
		if(jobExtId != null){
			messageLog.addCustomHeaderProperty("cbr_jobExtId", jobExtId);		
        }
	}
	return message;
}
