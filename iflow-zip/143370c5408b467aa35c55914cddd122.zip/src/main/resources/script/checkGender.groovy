import com.sap.it.api.mapping.*;
def String genderCheck(String gender){
    if (gender.isEmpty())
	return false ;
	else
	return true;
}