import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    Set <String> set = new HashSet <String> ();

    jsonObject.each {
        set.add(JsonOutput.toJson(it));
    }
  
    Map parsedJson;
    int count = 0;
  
    for (String s : set) {
        parsedJson = jsonParser.parseText(s);
        if(parsedJson.keySet().contains("externalId")){
            count ++;
        }
    }
    
    if(count == set.size())
    {
        message.setProperty("warehouseId",true);
    }
    else
    {
        message.setProperty("warehouseId",false);
    }
    
    message.setBody(body);
    return message;
}
