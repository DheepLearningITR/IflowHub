import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    throw new Exception("Waredhouse ID is null or Plant/StorageLocation is Empty");
}
