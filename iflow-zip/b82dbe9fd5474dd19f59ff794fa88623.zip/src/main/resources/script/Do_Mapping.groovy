import com.sap.it.api.mapping.*
import com.sap.it.api.mapping.MappingContext;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;
import static java.util.UUID.randomUUID;
import java.text.*; 
import java.util.*;


def String genMapping(String Template_PM_ID,String Input_Value,String Attribute_Name,MappingContext context){
    
	// Get Value Mapping Service
	def valueMapService = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    String valueFSPMVersion   = 'FSPM_'+ context.getProperty("com.sap.commercecloud.fsa.insurance.issuepolicy.FSPM_Version");
    String valueHybrisVersion = 'FSA_'+ context.getProperty("com.sap.commercecloud.fsa.insurance.issuepolicy.FSA_Version");
    
    String valueMappedPayFrqId = Input_Value;
    
            // Go for attributes with mapping (first template specific)
            valueMappedPayFrqId = valueMapService.getMappedValue(valueHybrisVersion, Template_PM_ID+"_"+Attribute_Name, Input_Value, valueFSPMVersion, Template_PM_ID+"_"+Attribute_Name);
            if (valueMappedPayFrqId == null) {
                // ...second try is without template ID
                   valueMappedPayFrqId = valueMapService.getMappedValue(valueHybrisVersion, Attribute_Name, Input_Value, valueFSPMVersion, Attribute_Name); 
            }
    return valueMappedPayFrqId;
}



def String getProperty(String property_name, MappingContext context) {

    def propValue= context.getProperty(property_name);
    return propValue;

}

def String genAttrMapping(String FSA_Context,String FSPM_Context,String Input_Value,String FSA_Attribute_Name,String FSPM_Attribute_Name,MappingContext context){
    
	// Get Value Mapping Service
	def valueMapService = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    String valueFSPMVersion   = 'FSPM_'+ context.getProperty("com.sap.commercecloud.fsa.insurance.issuepolicy.FSPM_Version");
    String valueHybrisVersion = 'FSA_'+ context.getProperty("com.sap.commercecloud.fsa.insurance.issuepolicy.FSA_Version");
    
    if (FSA_Context != '') {
        FSA_Context = FSA_Context+"_";
    }
    
    if (FSPM_Context != '') {
        FSPM_Context = FSPM_Context+"_";
    }
    
    String valueMapped = Input_Value;
    
            // Go for attributes with mapping (first template specific)
           valueMapped = valueMapService.getMappedValue(valueHybrisVersion, FSA_Context+FSA_Attribute_Name, Input_Value, valueFSPMVersion, FSPM_Context+FSPM_Attribute_Name);
            if (valueMapped == null) {
                // ...second try is without template ID
               valueMapped = valueMapService.getMappedValue(valueHybrisVersion, FSA_Attribute_Name, Input_Value, valueFSPMVersion, FSPM_Attribute_Name); 
            }
            
           // if (valueMapped == null) {
                valueMapped == 'MAPPING_ERROR';
           // }
    return valueMapped;
}

def void multiplyParentData(String[] parent_field,String[] children, Output output , MappingContext context) {
     for(i = 0;i<children.length;i++)
{
        output.addValue(parent_field[0]);
}
}

def void multiplyParentField(String[] parent_field,Integer count_children, Output output , MappingContext context) {
     for(i = 0;i<count_children;i++)
{
        output.addValue(parent_field[0]);
}
}