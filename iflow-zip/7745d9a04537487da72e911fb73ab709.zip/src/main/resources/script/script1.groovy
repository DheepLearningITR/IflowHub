import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) 
{
       def map = message.getProperties();
       def value = map.get("counter");
       def newcounter = value.toInteger() +2;
       message.setProperty("counter", newcounter);
       return message;
}