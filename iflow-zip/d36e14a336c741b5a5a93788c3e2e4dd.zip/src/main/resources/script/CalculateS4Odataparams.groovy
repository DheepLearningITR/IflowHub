/*
    The integration developer needs to create the method processData 
    This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
    which includes helper methods useful for the content developer:
    The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
    public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.util.List; 
import com.sap.it.api.mapping.*;

def Message getSalesHistoryParams(Message message) {
    def headers = message.getHeaders();
    def props = message.getProperties();
   
    //Get the parameters required for filter construction
    def salesHistoryFilter = headers.get('FurtherFilters')?:'';
    def dateFrom = headers.get('DateFrom')?:'';
    def dateTo = headers.get('DateTo')?:'';
    def dateAndQuantityType = headers.get('QuantityType')?:'';
    def timeAggregationLevel = headers.get('TimePeriodTypeinSAPS4HANACloud')?:'';
    def productFrom = headers.get('S4ProductFrom')?:'';
    def productTo = headers.get('S4ProductTo')?:'';
    def customerSourceField = headers.get('CustomerSourceforSAPIBP')?:'';
    
    //Get the value from the SourceFieldsfromSAPS4HANACloud parameter split it by the commas and create a LinkedHashSet from it.
    //After the set creation substract the date and quantity fields from it because those fields will be handled automatically based on other parameters.
    //Then it is turned to a list so that we can freely replace the placeholder field(s).
    //LinkedHashSet is used because it removes duplicates and keeps the insertion order.
    List SourceFieldsfromSAPS4HANACloud = (new LinkedHashSet(headers.get('SourceFieldsfromSAPS4HANACloud').tokenize(',').collect{ it.replaceAll("( )+", "") }).minus(['RequestedDeliveryDate','ConfirmedDeliveryDate','DeliveryDate','FirstDayOfWeekDate','FirstDayOfMonthDate','ScheduleLineOrderQuantity','ConfdOrderQtyByMatlAvailCheck','DeliveredQuantityInBaseUnit','DeliveredQtyInOrderQtyUnit','OrderToBaseQuantityDnmntr','OrderToBaseQuantityNmrtr'])).toList()
    
    //If the List that is created empty then the default value will be set.
    if(SourceFieldsfromSAPS4HANACloud.isEmpty()) SourceFieldsfromSAPS4HANACloud = ['Product','Plant','CustomerSourceforSAPIBP'];
    
    //Create the OData filter for plants
    def plants = (headers.get("PlantFilter")?:'').tokenize(',');
    def filters=[];
    def plantFilters=[];
    def pattern = '(?<=(?:^|-))(([^-\"]*?)|(\"(?:[^\"]+|\"\")*\"))(?=(?:-|$))';
    for (plant in plants) {
        //def singlePlants = plant.tokenize('-');
        def singlePlants = plant.findAll(pattern);
        plantFilters += (singlePlants.size() <= 1) ? "Plant eq '${singlePlants[0].replaceAll('^\"|\"$','')}'":"Plant ge '${singlePlants[0].replaceAll('^\"|\"$','')}' and Plant le '${singlePlants[1].replaceAll('^\"|\"$','')}'";
    }
    
    //Create the OData filter for products
    def products = (headers.get("ProductFilter")?:'').tokenize(',');
    def productFilters=[];
    for (product in products) {
        def singleProducts = product.findAll(pattern);
        productFilters += (singleProducts.size() <= 1) ? "Product eq '${singleProducts[0].replaceAll('^\"|\"$','')}'":"Product ge '${singleProducts[0].replaceAll('^\"|\"$','')}' and Product le '${singleProducts[1].replaceAll('^\"|\"$','')}'";
    }
    
    //Add the further filters to the filters List
    if (salesHistoryFilter!='') filters += '(' + salesHistoryFilter + ')';
     
    //Add the plant filters to the filters List 
    if (plantFilters.size() > 0 ) {
        filters += (((plantFilters.size() > 1)?'(':'') + plantFilters.join(' or ') + ((plantFilters.size() > 1)?')':'')); 
    }
    
    //Add the product filters to the filters List 
    if (productFilters.size() > 0 ) {
        filters += (((productFilters.size() > 1)?'(':'') + productFilters.join(' or ') + ((productFilters.size() > 1)?')':''));
    }
    
    //When the CustomerSourceforSAPIBP field is present in the SourceFieldsfromSAPS4HANACloud parameter then replace the placeholder CustomerSourceforSAPIBP field with the value contained in the parameter with the same name and create the OData Customer Filters and add them to the filters List
    if('CustomerSourceforSAPIBP' in SourceFieldsfromSAPS4HANACloud ){
        def customerSourceFieldUpper = customerSourceField.length()>0 ? customerSourceField.toUpperCase() : ' ';
        
        switch (customerSourceFieldUpper) {
            case 'SOLDTOPARTY':
                customerSourceField = 'SoldToParty';
                break;
            case 'SHIPTOPARTY':
                customerSourceField = 'ShipToParty';
                break;
            case 'DUMMYCUSTOMERID': 
                //In case of Dummy then there is no customer aggregation.
                SourceFieldsfromSAPS4HANACloud.remove('CustomerSourceforSAPIBP')
                break;
            default:
                throw new Exception("Unsupported Customer Source Field '$customerSourceField' (Use SoldToParty, ShipToParty or DummyCustomerID) ");
                break;
        }
        
        //Customer filters can't be interpreted in the dummy case.
        if (customerSourceField in ['SoldToParty','ShipToParty']){
            SourceFieldsfromSAPS4HANACloud.set(SourceFieldsfromSAPS4HANACloud.indexOf('CustomerSourceforSAPIBP'),customerSourceField)
            def customers = (headers.get("CustomerFilter")?:'').tokenize(',');
            def customerFilters=[];
            for (customer in customers) {
                def singleCustomers = customer.findAll(pattern);
                customerFilters += (singleCustomers.size() <= 1) ? "${customerSourceField} eq '${singleCustomers[0].replaceAll('^\"|\"$','')}'":"${customerSourceField} ge '${singleCustomers[0].replaceAll('^\"|\"$','')}' and ${customerSourceField} le '${singleCustomers[1].replaceAll('^\"|\"$','')}'";
            }
            if (customerFilters.size() > 0) filters += (((customerFilters.size() > 1)?'(':'') + customerFilters.join(' or ') + ((customerFilters.size() > 1)?')':'')); 
        } 
    }
    
    def dateAndQuantityTypeUpper = dateAndQuantityType.length()>0?dateAndQuantityType.toUpperCase():' ';
    def timeAggregationLevelUpper = timeAggregationLevel.length()>0?timeAggregationLevel.toUpperCase():' ';
    def quantityField = '';
    
    //Based on the time period type add the necessary field to the SourceFieldsfromSAPS4HANACloud parameter and create the date filters.
    switch (timeAggregationLevelUpper) {
        case 'DATE': 
            SourceFieldsfromSAPS4HANACloud.add('DeliveryDate')
            
            if (dateFrom!='') filters += "DeliveryDate ge " + dateFrom;
            if (dateTo!='') filters += "DeliveryDate le " + dateTo;
            break;
        case 'TECHNICAL WEEK':    
            SourceFieldsfromSAPS4HANACloud.add('FirstDayOfWeekDate')
            SourceFieldsfromSAPS4HANACloud.add('FirstDayOfMonthDate')
            
            if (dateFrom!='') filters += "(FirstDayOfWeekDate ge " + dateFrom + " or FirstDayOfMonthDate ge " + dateFrom + ")";
            if (dateTo!='') filters += "FirstDayOfWeekDate le " + dateTo + " and FirstDayOfMonthDate le " + dateTo + "";
            break;
        case 'WEEK':    
            SourceFieldsfromSAPS4HANACloud.add('FirstDayOfWeekDate')
            
            if (dateFrom!='') filters += "FirstDayOfWeekDate ge " + dateFrom;
            if (dateTo!='') filters += "FirstDayOfWeekDate le " + dateTo;
            break;
        case 'MONTH':    
            SourceFieldsfromSAPS4HANACloud.add('FirstDayOfMonthDate')
            
            if (dateFrom!='') filters += "FirstDayOfMonthDate ge " + dateFrom;
            if (dateTo!='') filters += "FirstDayOfMonthDate le " + dateTo;
            break;
        default:
            throw new Exception("Unsupported S4 Time Aggregation Level '$timeAggregationLevel' (Use Date, Technical week, Week or Month)");
            break;
    }
    
    //Based on the required quantity add the fields to the SourceFieldsfromSAPS4HANACloud parameter. In the Required and Confirmed case extra fields are required for base unit conversion
    switch (dateAndQuantityTypeUpper) {
        case 'REQUESTED':
            quantityField = 'ScheduleLineOrderQuantity';
            filters += "IsRequestedDelivSchedLine eq true";
            SourceFieldsfromSAPS4HANACloud << 'OrderToBaseQuantityDnmntr,OrderToBaseQuantityNmrtr';
            break;
        case 'CONFIRMED':
            quantityField = 'ConfdOrderQtyByMatlAvailCheck';
            filters += "IsConfirmedDelivSchedLine eq true";
            SourceFieldsfromSAPS4HANACloud << 'OrderToBaseQuantityDnmntr,OrderToBaseQuantityNmrtr';
            break;
        case 'DELIVERED':    
            quantityField = 'DeliveredQuantityInBaseUnit';
            filters += "IsConfirmedDelivSchedLine eq true";
            break;
        default:
            throw new Exception("Unsupported Quantity Type '$dateAndQuantityType' (Use Requested, Confirmed or Delivered)");
            break;
    }
    
    //Set the headers based on the previous calculations.
    message.setHeader("S4Filters",filters.join(' and '));
    message.setHeader("S4QuantityField",quantityField);
    //LinkedHashSet is used here to keep the order and get rid of duplicates that can happen when replacing placeholder fields.
    message.setHeader("S4OrderByGroupByFields",new LinkedHashSet(SourceFieldsfromSAPS4HANACloud).join(','));
    
    
    return message;
}
