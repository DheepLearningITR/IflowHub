import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.lang.String;
import java.lang.Integer;
import com.sap.it.api.mapping.*;
import java.util.regex.*;


def processData(Message message){
    def headers = message.getHeaders();
    validateFieldExtensions(headers.get('AttributesinSAPIBP'),headers.get('FieldExtensions'));
    
    def oDataTop = (headers.get('ODataPackageSize')?:'') as Integer
    if(oDataTop < 5000){
        throw new Exception("OData Package Size is too small")
    }
    
    return message
}

def validateFieldExtensions(String attributesinSAPIBP, String fieldExtensions) {

    if (!fieldExtensions.isEmpty()) {

        //check if field extensions starts with < and ends with >
    
        if (fieldExtensions.startsWith('<') && fieldExtensions.endsWith('>')) {
            
        } else {
             throw new Exception ("Start the Field Extensions parameter with '<' and end it with '>'.")
        }   
        
        //check if all tag names in field extensions are included in the Fields to Update in SAP IBP parameter      
    
        // Define a pattern to match tag names: it gets every string which is directly following the '<' sign
        def pattern = /<(\w+)\s/
    
        // Find all matches for the pattern in the string
        def matches = (fieldExtensions =~ pattern)
    
        // Extract tag names
        def tagNames = matches.collect { it[1] }
    
        //check if all tag names are included    
        boolean allTagsInFieldList = tagNames.every { tagName -> attributesinSAPIBP.split(',').contains(tagName) }
    
        //Could check if we want to skip the field that has attribute skip = true in the field extensions parameter
        if (allTagsInFieldList) {
            
        } else {
            def missingTags = tagNames.findAll { tagName -> !attributesinSAPIBP.split(',').contains(tagName) }
            throw new Exception ("Fields are missing from the Attributes in SAP IBP parameter which are included in the Field Extensions parameter. Missing fields: $missingTags")
        }
        
        //only checks the syntax
        def fieldExtensionsXML = '<Root>'+fieldExtensions+'</Root>'
        def xmlVal = new XmlSlurper().parse(new StringReader(fieldExtensionsXML))
        
    		
    }   

}
