import com.sap.gateway.ip.core.customdev.util.Message

//function CreateIBPBatches definition
Message CreateIBPBatches(Message message) {
    def map = message.headers
    def property_EnableLogging = map.get('DetailedTraceLog')
    message.setHeader('SAP_IsIgnoreProperties', true)
    //logs if EnableLogging property is set as true
    if(property_EnableLogging){
        if (property_EnableLogging.toUpperCase() == 'TRUE') {
            String body = message.getBody(String) as String
            def messageLog = messageLogFactory.getMessageLog(message)
            //name of the file
            messageLog.addAttachmentAsString('Create IBP Batches Log', body, 'text/plain')
        }
    }

    return message
}

//function WriteData definition
Message WriteData(Message message) {
    def map = message.headers
    def property_EnableLogging = map.get('DetailedTraceLog')
    message.setHeader('SAP_IsIgnoreProperties', true)
    //logs if EnableLogging property is set as true
    if(property_EnableLogging){
        if (property_EnableLogging.toUpperCase() == 'TRUE') {
         String body = message.getBody(String) as String
            def messageLog = messageLogFactory.getMessageLog(message)
            //name of the file
            messageLog.addAttachmentAsString('Write Data Log', body, 'text/plain')
        }
    }

    return message
}

//function DataLog definition
Message DataLog(Message message) {
    def map = message.headers
    def property_EnableLogging = map.get('DetailedTraceLog')
    message.setHeader('SAP_IsIgnoreProperties', true)
    if(property_EnableLogging){
        //logs if EnableLogging property is set as true
        if (property_EnableLogging.toUpperCase() == 'TRUE') {
            String body = message.getBody(String) as String
         def messageLog = messageLogFactory.getMessageLog(message)
         //name of the file
         messageLog.addAttachmentAsString('Data Log or Errors', body, 'text/plain')
        }
    }

    return message
}

//function Mapping definition
Message Mapping(Message message) {
    def map = message.headers
    def property_EnableLogging = map.get('DetailedTraceLog')
    message.setHeader('SAP_IsIgnoreProperties', true)
    if(property_EnableLogging){
        //logs if EnableLogging property is set as true
        if (property_EnableLogging.toUpperCase() == 'TRUE') {
            String body = message.getBody(String) as String
            def messageLog = messageLogFactory.getMessageLog(message)
            //name of the file
            messageLog.addAttachmentAsString('Mapping Log', body, 'text/plain')
        }
    }

    return message
}

//function processDataInitial definition
Message noDataFound(Message message) {
    def map = message.headers
    def property_EnableLogging = map.get('DetailedTraceLog')
    message.setHeader('SAP_IsIgnoreProperties', true)
    if(property_EnableLogging){
        //logs if EnableLogging property is set as true
        if (property_EnableLogging.toUpperCase() == 'TRUE') {
         String body = message.getBody(String) as String
            def messageLog = messageLogFactory.getMessageLog(message)
            //name of the file
         messageLog.addAttachmentAsString('No Data Found Log', body, 'text/plain')
        }
    }

    return message
}