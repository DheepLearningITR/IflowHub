import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.lang.String;
import com.sap.it.api.mapping.*;

def Message setLogCustomHeaders(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    def headers = message.getHeaders();
	    def properties = message.getProperties();
	    String emailBody = headers.get('emailBody') + "\r\nLog custom headers:";
    	def logCustomHeaders = properties.get("LogCustomHeaders") + ',' + properties.get("LogStandardCustomHeaders");
    	def logCustomProperties = properties.get("LogStandardCustomProperties");
    	def logAttachmentHeaders = properties.get("LogAttachmentHeaders") + ',' + properties.get("LogStandardAttachmentHeaders");
	   // if(logCustomHeaders!=null) {
    // 	    logCustomHeaders.tokenize(',').each() {
    // 	        if (it !='' && it != null) setLogCustomHeader(headers, messageLog, it);		
    // 	        emailBody += "\r\n\${it}: ${headers.get(it)}";
    // 	    }
	   // }
	   // if(logCustomProperties!=null) {
    // 	    logCustomProperties.tokenize(',').each() {
    // 	        if (it !='' && it != null) setLogCustomProperty(message, messageLog, it);
    // 	        emailBody += "\r\n\${it}: ${message.getProperty(it)}";
    // 	    }
	   // }
	    
	    if(logCustomHeaders!=null) {
    	    logCustomHeaders.tokenize(',').each() {
    	        if (it != '') addLogCustomHeaderWithSplit(messageLog, headers, it);		
    	    }
	    }

 	    if(logCustomProperties!=null) {
   	        logCustomProperties.tokenize(',').each() {
    	        if (it !='') addLogCustomHeaderWithSplit(messageLog, properties, it);		
    	    }
	    }
	    
	    if(logAttachmentHeaders!=null) {
    	    logAttachmentHeaders.tokenize(',').each() {
    	         if (it !='' && it != null) setLogAttachmentHeader(headers, messageLog, it);		
    	    }
	    }
	    
	    
	    
	    def ProductPlantFilter = properties.get('ProductPlantFilter')
	    if(ProductPlantFilter != null){
	        messageLog.addAttachmentAsString("ProductPlantFilter", ProductPlantFilter, 'text/plain')	
	    }
	    
	    //ExceptionMessage,IBPStep
	    
	    def attachment = """Attributes in SAP IBP: ${headers.get('AttributesinSAPIBP')}
Batch Name: ${headers.get('BatchName')}
Batch Command: ${headers.get('BatchCommand')}
Customer Filter: ${headers.get('CustomerFilter')}
Customer Source for SAPIBP: ${headers.get('CustomerSourceforSAPIBP')}
Datastore ID for Product Plant Filter: ${headers.get('DatastoreIDforProductPlantFilter')}
Date From: ${headers.get('DateFrom')}
Date To: ${headers.get('DateTo')}
Destination for SAP IBP: ${headers.get('DestinationforSAPIBP')}
DummyCustomerID: ${headers.get('DummyCustomerID')}
Field Extensions: ${headers.get('FieldExtensions')}
Further Filters: ${headers.get('FurtherFilters')}
Host for SAP S4HANA Cloud Public Edition: ${headers.get('HostforSAPS4HANACloud')}
Keyfigure Name: ${headers.get('KeyfigureName')}
OData Package Size: ${headers.get('ODataPackageSize')}
Planning Area: ${headers.get('PlanningArea')}
Planning Area Version: ${headers.get('PlanningAreaVersion')}
Plant Filter: ${headers.get('PlantFilter')}
Product Filter: ${headers.get('ProductFilter')}
Quantity Type: ${headers.get('QuantityType')}
Source fields from SAP S4HANA Cloud Public Edition: ${headers.get('SourceFieldsfromSAPS4HANACloud')}
Time Period Type in SAP S4HANA Cloud Public Edition: ${headers.get('TimePeriodTypeinSAPS4HANACloud')}
Time Profile Level in SAP IBP: ${headers.get('TimeProfileLevelinSAPIBP')}
Detailed Trace Log: ${headers.get('DetailedTraceLog')}
Top Rows Per Package For Log: ${headers.get('TopRowsPerPackageForLog')}"""
	    
	    
	    messageLog.addAttachmentAsString("Parameters" , attachment.toString(), "text/xml");
	}
	return message;
}

def Message addBodyToLog(Message message){
    
    
    	/*add message body to logs in case of an exception.*/
	def bodyAsString = message.getBody(java.lang.String);
	
	def headers = message.getHeaders();	
	def ibpStep = headers.get("IBPStep");
	
	def messageLog = messageLogFactory.getMessageLog(message);
	messageLog.addAttachmentAsString('Latest message body coming from step: ' + ibpStep, bodyAsString, 'text/xml');
	
    return message;
}

def Message addResultsToLogAndEmailList(Message message) {
	def headers = message.getHeaders();
	def messagesForEmail = headers.get("EmailIBPMessagesForBody")?:[];
	def ibpMessages = headers.get("IBPMessages");
	def messageLog = messageLogFactory.getMessageLog(message);
	def ibpStep = headers.get("IBPStep");
	def worstIBPMessageType = headers.get("IBPWorstMessageType");
	def messageTruncated = false;
	if (ibpMessages != null) {
    	for (int i = 0; i < ibpMessages.length; i++) {
    	    def content = mapAbapMessageTypeToString(ibpMessages.item(i).getFirstChild().getTextContent()) + ': ' + ibpMessages.item(i).getLastChild().getTextContent();
            messagesForEmail.push(content) ;
            if(messageLog != null){
                if (content.length() > 198) messageTruncated = true;
                messageLog.addCustomHeaderProperty('Message from IBP step ' + ibpStep, content);
            }
        }
        if (messageTruncated == true && messageLog != null) {
            messageLog.addCustomHeaderProperty('Message from IBP step ' + ibpStep, " (There is at least one truncated message. See attachment 'Response Body with Error' for the full message)");
        }
    
        message.setHeader("EmailIBPMessagesForBody",messagesForEmail);
        if (worstIBPMessageType in ['Abort','Error']) {
    	    String customStatus = '';
            switch (ibpStep) {
                case 'Handshake': customStatus = 'IBP Handshake Error'; break;
                case 'WriteData': customStatus = 'IBP WriteData Error'; break;
                case 'ScheduleProcessing': customStatus = 'IBP ScheduleProcessing Error'; break;
                case 'GetProcessingStatus': customStatus = 'IBP GetProcessingStatus Error'; break;
                case 'GetProcessingMessages': customStatus = 'IBP GetProcessingMessages Error'; break;
                default: customStatus = "Unexpected IBP Step ${ibpStep}"; break;
    	    }
    	    message.setHeader("IFlowCustomStatus",customStatus);
    	    message.setProperty("SAP_MessageProcessingLogCustomStatus",customStatus);
    	}
	}
	return message;
}


def void setLogCustomHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	//if(header!=null && header != ''){
		messageLog.addCustomHeaderProperty(headerName, header.toString());		
    //}
}

def void setLogCustomProperty(Message message, MessageLog messageLog, String propertyName) {
    
	def property = message.getProperty(propertyName);		
	//if(property!=null && property != ''){
		messageLog.addCustomHeaderProperty(propertyName, property.toString());		
    //}
}

def void setLogAttachmentHeader(Map<String,Object> headers, MessageLog messageLog, String headerName) {
    
	def header = headers.get(headerName);		
	if(header!=null){
		messageLog.addAttachmentAsString(headerName, header.toString(), 'text/plain')	
    }
}

def void addLogCustomHeaderWithSplit(MessageLog messageLog, Map<String,Object> candidates, String name ) {
    def candidat = candidates.get(name);
    //if (candidat != '' && candidat != null) {
        def messageLength = candidat.length();
        if (messageLength<=198) messageLog.addCustomHeaderProperty(name, candidat);
        else {
            int i = 0;
            for (int j = 0; j < messageLength;j += 198) {
                def k = j + 198;
                i++;
                messageLog.addCustomHeaderProperty(name + '.' + i.toString(), candidat.substring(j,k<=messageLength?k:messageLength));
            }
        }
    //}
}

def String mapAbapMessageTypeToString(String abapMessageType) {
    switch (abapMessageType) {
        case 'A': return 'Abort';
        case 'E': return 'Error';
        case 'W': return 'Warning';
        case 'I': return 'Information';
        case 'S': return 'Success';
        default: return abapMessageType;
    }
}
