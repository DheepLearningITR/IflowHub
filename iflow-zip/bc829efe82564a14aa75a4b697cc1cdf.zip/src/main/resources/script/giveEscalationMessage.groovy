import com.sap.gateway.ip.core.customdev.util.Message;

def Message giveEscalationMessage(Message message) {
    //Throw a custom exception and set an escalation message based on status and the existence of fetch messages
    def messageLog = messageLogFactory.getMessageLog(message);
    String fetchMessages = message.getProperty('FetchMessages') ?: '';

    if (messageLog != null) {
        String status = getStatus(message)
        String escalationMessage = "There was a error during the read process check the logs"
        if (fetchMessages != '') {
            try {
                //Expectation is that the status is the worst one so we rethrow the worst message type
                escalationMessage = getFirstFetchMessageWithTypeMatchingStatus(message, status)
            }
            catch (Exception e) {
                throw new Exception(e.getMessage());
            }
            throw new FetchException(escalationMessage);
        } else {
            switch (status) {
                //Finished case is only executed when the method is called from the first status check, 
                //so it should not cause problems when called after fetch messages
                case "Finished":
                    escalationMessage = "The fetch process finished there is no more data in the system"
                    break
            }
            messageLog.addCustomHeaderProperty("Escalation message", escalationMessage);
            throw new FetchException(escalationMessage);
        }

    }

    return message;
}

def String getStatus(Message message) {
    //Returns the status of the iflow property has a higher priority compared to body
    String status = message.getProperty('Status') ?: ''
    if (status != '') {
        return status
    } else {
        def parsedBody = new XmlSlurper().parse(message.getBody(java.io.Reader));
        return parsedBody?.@Status?.text()
    }
}

def String getFirstFetchMessageWithTypeMatchingStatus(Message message, String status) {
    //Get the first message with the given type
    def parsedFetchMessages =new XmlSlurper().parseText(("<Messages>" + (message.getProperty('FetchMessages') as String)  + "</Messages>") as String)
    def firstFetchMessageWithTypeMatchingStatus = parsedFetchMessages?.'**'?.find { it -> it.name() == 'Message' && it.@Type.text() == status && it.text() != "" }

    return firstFetchMessageWithTypeMatchingStatus.text()
}

public class FetchException extends Exception {
    //Custom exception for fetch
    public FetchException(String message) {
        super(message);
    }
}