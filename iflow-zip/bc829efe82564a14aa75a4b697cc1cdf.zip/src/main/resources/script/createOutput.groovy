import groovy.util.XmlSlurper
import groovy.xml.MarkupBuilder
import com.sap.gateway.ip.core.customdev.util.Message
import java.io.StringWriter

def Message transform(Message message) {
    // Get the message body as a string
    def xml = message.getBody().toString()

    // Parse the XML
    def parsedXml = new XmlSlurper().parseText(xml)

    // Determine static info
    def status = determineStatus(parsedXml)
    def messages = collectMessages(parsedXml)
    def DestinationforAddon = message.getProperty('CurrentDestination')
    def FetchPointer = message.getProperty('FetchPointer')
    def Fields = message.getProperty('Fields')
    def FieldTypes = message.getProperty('FieldTypes')
    def FieldLengths = message.getProperty('FieldLengths')

    // Extract package ID (not used in output)
    def packageId = parsedXml.E_PACKAGE.text()

    // Create the new XML structure using MarkupBuilder
    def writer = new StringWriter()
    def xmlBuilder = new MarkupBuilder(writer)
    xmlBuilder.IBPRead(
        DestinationforAddon: DestinationforAddon,
        FetchPointer: FetchPointer,
        Fields: Fields,
        FieldTypes: FieldTypes,
        FieldLengths: FieldLengths,
        Status: status,
        InputPackageID: packageId,
        RedoPackage: 'True'
    ) {
        // Messages(messages)
        Messages {
            mkp.yieldUnescaped messages
        }
    }

    // Set the new XML as the message body
    message.setBody(writer.toString())
    return message
}

// Function to determine status
def determineStatus(parsedXml) {
    if (parsedXml.ET_RETURN.item.TYPE.find { it.text() == 'A' }) {
        return 'Abort'
    } else if (parsedXml.ET_RETURN.item.TYPE.find { it.text() == 'E' }) {
        return 'Error'
    } else if (parsedXml.E_NO_MORE_DATA.text() == 'X') {
        return 'Finished'
    } else if (parsedXml.ET_RETURN.item.TYPE.find { it.text() == 'W' }) {
        return 'Warning'
    }  else {
        return 'Fetch'
    }
}

// Function to collect messages
def collectMessages(parsedXml) {
    def messages = new StringWriter()
    def msgBuilder = new MarkupBuilder(messages)
    parsedXml.ET_RETURN.item?.each { item->
        msgBuilder.Message(Type: typeToFullLength(item.TYPE.text()), Origin: 'RODPS_REPL_SOURCE_PREFETCH') {
            mkp.yield item.MESSAGE.text()
        }
    }
    return messages.toString()
}

// Function to map type to full length
def typeToFullLength(type) {
    switch (type) {
        case 'A':
            return 'Abort'
        case 'E':
            return 'Error'
        case 'W':
            return 'Warning'
        case 'I':
            return 'Information'
        default:
            return type
    }
}
