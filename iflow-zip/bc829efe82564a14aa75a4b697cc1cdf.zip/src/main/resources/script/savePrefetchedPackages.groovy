import com.sap.gateway.ip.core.customdev.util.Message

def Message savePackages(Message message) {
    def xml = message.getBody().toString()
    def ibpRead = new XmlSlurper().parseText(xml)

    def status = ibpRead.@Status?.toString()
    def inputPackageID = ibpRead.@InputPackageID?.toString()
    def redoPackage = ibpRead.@RedoPackage?.toString()

    if (status == 'Fetch' && inputPackageID == '%% TO BE DEFINED %%' && redoPackage == 'True') {
        // Do not save this message body, as it would break logic during the Fetch iFlow. 
        // This message is returned by the Add-on if there are 0 records available for reading after Initialization
        return message
    }

    def existingPackageXml = message.getProperty('PreFetchPackages')?.toString()
    if (!existingPackageXml || existingPackageXml == 'null') {
        message.setProperty('PreFetchPackages', xml)
    } else {
        message.setProperty('PreFetchPackages', existingPackageXml + xml)
    }

    return message
}