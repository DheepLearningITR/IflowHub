import com.sap.gateway.ip.core.customdev.util.Message;

def Message logExceptionAndMessages(Message message) {
    // Get the messageLogFactory and the FetchMessages property
    def messageLog = messageLogFactory.getMessageLog(message);
    def properties = message.getProperties();
    String fetchMessages = properties.get("FetchMessages") ?: '';

    if (messageLog != null) {
        // Log and format the ERPReadFetchMessages attachment and Add the exception message to it if there is any
        try {
            def ex = properties.get("CamelExceptionCaught");
            String exMessage = "<Message Type=\"Error\" Origin=\"SAP IBP Add-On Read - Fetch Data\">" + ex.getMessage() + "</Message>";
            String fetchMessagesAndErrorMessage = (exMessage + fetchMessages).replaceAll(/<.xml.*?>/, "").replaceAll("[\\t\\n\\r]+","")
            messageLog.addAttachmentAsString('ERPReadFetchMessages', "<Messages>" + fetchMessagesAndErrorMessage + "</Messages>", 'text/XML')
            //Update the fetchMessages property for creating the exception body
            message.setProperty("FetchMessages", fetchMessagesAndErrorMessage);
        } catch (Exception e) {
            if (fetchMessages != '') {
                fetchMessages = "<Messages>" + fetchMessages + "</Messages>"
                messageLog.addAttachmentAsString('ERPReadFetchMessages', "<Messages>" + fetchMessages + "</Messages>", 'text/XML') 
            }
        }
        //Set the body so that the next XSLT step will always have a valid body
        message.setBody("<Root/>");
    }

    return message;
}