import com.sap.gateway.ip.core.customdev.util.Message;
def Message addMessagesToAttachment(Message message) {
    
    def properties = message.getProperties();
    String status = properties.get("Status") ?: '';
    def trace = properties.get("DetailedTraceLog");
    
    if ((!(status == "Fetch") && !(status == "Finished")) || (trace != null && trace.toUpperCase() == "TRUE")) {
        
        String fetchMessages = properties.get("FetchMessages") ?: '';

        // Log and format the ERPReadFetchMessages attachment
        if (fetchMessages != '') {
            def messageLog = messageLogFactory.getMessageLog(message);
            if (messageLog != null) {
                messageLog.addAttachmentAsString('ERPReadPreFetchMessages', "<Messages>" + fetchMessages + "</Messages>", 'text/XML')
            }
        }
    }
    return message;
}