import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import javax.xml.parsers.SAXParser
import javax.xml.parsers.SAXParserFactory
import groovy.xml.*;

class Globals {
  static String MASK_STRING = "********";
  static List<String> personalDataFieldNames = ["AddressName", "StreetName", "StreetAddressName", "street", "building","apartment","houseNumber","district","ADDR_NO","POSTL_COD1","postalCode",
                                                "firstName","lastName","middleName2","middleName","telNumber","NAME","NAME_2",
                                                "validToMonth", "validToYear", "ccOwner",
                                                "email", "EmailAddress","E_MAIL",
                                                "faxNumber", "pobox"];
  static String ERROR_MESSAGE = "\n***********************\nWarning:Failed to mask personal data information in '%s',\nexception message:\n%s\n***************************\n\n"
}

def Message processData(Message message) {
	def body = message.getBody(java.lang.String) as String;
	def properties = message.getProperties() as Map<String, Object>;
	
	def propertiesAsString ="\n";
	properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };

	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null && properties.get("enableLog") == "true") {
	    def bodyWithMaskedPersonalData =  maskPersonalDataInBody(body);
		messageLog.addAttachmentAsString("Log - IDoc" , "\n Properties \n ----------   \n" + propertiesAsString +
		                                                   "\n Body \n ----------  \n\n" + bodyWithMaskedPersonalData,
		                                                   "text/xml");
	}
	
	return message;
}

String maskPersonalDataInBody(String body) {
  return maskPersonalData(body, "body");
}

String maskPersonalData(String content, String location) {
  if (content == null) {
    return content;
  }
  try {
    def factory = SAXParserFactory.newInstance();
    factory.setNamespaceAware(true);
    factory.setValidating(false);
    SAXParser parser = factory.newSAXParser();
    def xmlSluper = new XmlSlurper(parser);
    def root = xmlSluper.parseText(content);

    root.depthFirst().findAll {
      node->Globals.personalDataFieldNames.stream().anyMatch {fieldName->fieldName.equalsIgnoreCase(node.name())} && node.children().isEmpty();
    }.forEach {node-> node.replaceBody(maskData(node.text()));}
    return XmlUtil.serialize(root);
  }catch (Exception e) {
    return String.format(S4HANACE.ReplicateOrdersFromSAPCommerceClouldToS4HANACE.Globals.ERROR_MESSAGE, location, e.getMessage()) + content;
  }
}

String maskData(String content) {
  if(content == null || content.length() <=2) {
    return content;
  }
  def trimmedContent= content.trim();
  def size = trimmedContent.length();
  if(size <=2) {
    return content;
  }
  return trimmedContent.substring(0,1) + Globals.MASK_STRING + trimmedContent.substring(size-1, size);
}
