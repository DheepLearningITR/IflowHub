
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
 
       def map = message.getProperties();
       String value = map.get("locationID");

       
       def parts = value.tokenize( '-' );
       
       String locationIDnew = parts[0] + parts[1] + parts[2] + parts[3] + parts[4];
       
       locationIDnew = locationIDnew.toUpperCase();
       
       message.setProperty("locationID", locationIDnew);

       return message;
}