/*
This Groovy script processes the XML content of a message in SAP CPI. The steps involved are:

1. Retrieves the message body as a string and parses the XML content.
2. Identifies and removes all <value> elements where the <changedata> field does not contain the 'changedAttributes' key. If the JSON inside <changedata> is invalid or cannot be parsed, the corresponding <value> element is also removed.
3. Iterates through each <changedata> element, parsing its JSON content and filtering the attributes based on a predefined list of allowed attribute logical names.
4. Builds a new XML structure based on the filtered attributes, retaining only the specified fields ('opportunityid', 'createdon', etc.).
5. Replaces the original <changedata> element with the newly created XML structure.
6. Converts the modified XML back to a string and sets it as the updated message body.

This script is designed to filter and clean XML data by removing unnecessary fields and restructuring it based on specified criteria.
*/


import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder
import groovy.xml.XmlUtil

def Message processData(Message message) {
    // Retrieve the message body as a string
    def body = message.getBody(java.lang.String) as String
    
    // Parse the XML content
    def xml = new XmlParser().parseText(body)

    // Find all <value> elements where <changedata> doesn't contain 'changedAttributes' and remove them
    def valuesToRemove = xml.'**'.findAll { valueElement ->
        valueElement.name() == 'value' && 
        valueElement.changedata.text()?.with { changedataText ->
            try {
                def json = new JsonSlurper().parseText(changedataText)
                return !json.containsKey('changedAttributes') // Remove if 'changedAttributes' is not present
            } catch (Exception e) {
                return true // Remove in case of parse errors or invalid JSON
            }
        }
    }
    valuesToRemove.each { it.parent().remove(it) }

    // Iterate through each <changedata> element
    xml.'**'.findAll { it.name() == 'changedata' }.each { changedata ->
        // Parse the JSON content inside <changedata>
        def json = new JsonSlurper().parseText(changedata.text())

        // Filter only the required attributes
        def filteredAttributes = json.changedAttributes.findAll { 
            it.logicalName in ['opportunityid','_createdby_value','_ownerid_value','_parentaccountid_value','createdon','modifiedon','actualclosedate','salesstage','name','totalamount','_transactioncurrencyid_value','statecode','prioritycode','closeprobability']
        }

        // Build new XML structure from filtered JSON data
        def writer = new StringWriter()
        def xmlBuilder = new MarkupBuilder(writer)

        xmlBuilder.changedAttributes {
            filteredAttributes.each { attr ->
                attribute(logicalName: attr.logicalName) {
                    oldValue(attr.oldValue ?: "")
                    newValue(attr.newValue ?: "")
                }
            }
        }

        // Replace the original <changedata> element with the new XML structure
        def newNode = new XmlParser().parseText(writer.toString())
        changedata.replaceNode(newNode)
    }

    // Convert the modified XML back to a string
    def updatedXml = XmlUtil.serialize(xml)

    // Set the updated XML as the message body
    message.setBody(updatedXml)

    return message
}