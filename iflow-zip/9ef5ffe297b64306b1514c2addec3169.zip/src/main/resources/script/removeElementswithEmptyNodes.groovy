/*
This Groovy script processes the XML content of a message in SAP CPI. The following operations are performed:

1. Retrieves the message body as a string and parses the XML content.
2. Identifies all <value> elements that contain an empty <changedAttributes> element.
3. Removes any <value> elements where the <changedAttributes> field is empty.
4. Converts the modified XML structure back to a string.
5. Sets the updated XML as the new message body.

This script helps clean up the XML by removing elements with empty fields.
*/

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil

def Message processData(Message message) {
    // Retrieve the XML body as a string
    def body = message.getBody(java.lang.String) as String

    // Parse the XML
    def xml = new XmlParser().parseText(body)

    // Find all <value> elements with empty <changedAttributes/> and remove them
    def valuesToRemove = xml.'**'.findAll { 
        it.name() == 'value' && it.changedAttributes.text().trim().isEmpty()
    }
    
    valuesToRemove.each { it.parent().remove(it) }

    // Convert the updated XML back to string
    def updatedXml = XmlUtil.serialize(xml)

    // Set the modified XML as the message body
    message.setBody(updatedXml)

    return message
}