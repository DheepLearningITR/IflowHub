import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();
       //message.setBody(body + "Body is modified");
       //Properties 
       def map = message.getProperties();
       def value = map.get("openWFList");


       def item = map.get("documentItem");
       def stringLen = 3;
       def strLen = item.toString().size()
       def expectedLen = stringLen.toInteger() - strLen.toInteger()
       for(i = 0; i<=expectedLen-1;i++)
       {
         	item = "0" + item;
       }
    
       String bKey = map.get("companyCode") + '_' + map.get("documentNo") + '_' + map.get("fiscalYear") + '_' + item + '_' + map.get("dunningLevel");
       
       String WFExists = 'N';
       if (value.contains(bKey)){
       WFExists = 'Y'    
       }
       
       message.setProperty("WFExists", WFExists);
       //message.setProperty("newProperty", "newProperty");
       return message;
}