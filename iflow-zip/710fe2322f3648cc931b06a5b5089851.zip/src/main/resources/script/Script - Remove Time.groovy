import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();

       //Properties 
       def map = message.getProperties();
       def value = map.get("LastRunTime");
       message.setProperty("LastRunTimeWF", value.substring(0, 10));
       return message;
}