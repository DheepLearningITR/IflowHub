import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonOutput
import groovy.json.JsonSlurper;

def Message processData(Message message) {

    //Body 
    def body = message.getBody();
	
	def reader = message.getBody(java.io.Reader);
   
    List<String> list = new ArrayList<String>();

	reader.eachLine {String line ->
		list.add(line);
	}

    def map = message.getHeaders();
    map = message.getProperties();
    message.setProperty("P_ArrayData", list);
    message.setProperty("csvfilename", message.getHeaders().get("CamelFileName"));
    
    message.setBody(body);
    return message;
}