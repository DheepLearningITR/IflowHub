import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
//import java.util.Date

def Message processData(Message message) {
 	Reader json = message.getBody(java.io.Reader)
    def contractConfirmation = new JsonSlurper().parse(json)
    def continueRetry = 'Y'
    def contractTimeOut = 'N'
    def contractConfirmed = 'N'
    def startTime = message.getHeaders().get('contractWaitStartTime')
    if(startTime == null) {
        Date date = new Date()
       contractTimeOut = 'N'
    } else {
        long t1 = startTime
        Date date = new Date()
        long t2 = date.getTime()
        if(t2 - t1 > 60000) {
            contractTimeOut = 'Y'
        } else {
            contractTimeOut = 'N'
        }
    }
    if(contractConfirmation.'edc:state' == 'FINALIZED') {
        contractConfirmed = 'Y'
        message.setHeader('ContractConfirmation', contractConfirmation)
        message.setHeader('ContractConfirmationId', contractConfirmation.'@id')
    } else {
        message.setHeader('ContractConfirmed', 'N')
        contractConfirmed = 'N'
    }
    if(contractTimeOut == 'N' && contractConfirmed == 'N') {
        continueRetry = 'Y'
        sleep(2000)
    } else {
        continueRetry = 'N'
    }
    message.setHeader('continueRetry', continueRetry)

    return message;
}
