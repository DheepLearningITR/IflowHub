import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    def bpnMap = [:]
    bpnMap.bpnArray = input
    message.setProperty('partnerEDCUrl', bpnMap.bpnArray[0].connectorEndpoint[0])
    message.setProperty('partnerBPN', bpnMap.bpnArray[0].bpn)
    def mtJson = new JsonBuilder(bpnMap)
    message.setBody(mtJson.toPrettyString())
    return message
}
