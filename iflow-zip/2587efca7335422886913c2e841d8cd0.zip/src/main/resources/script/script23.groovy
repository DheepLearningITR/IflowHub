import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
 	Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    def callbackWaitContinueRetry = 'Y'
    def callbackTimeOut = 'N'
    def callbackConfirmed = 'N'
    def callBackStartTime = message.getHeaders().get('callBackStartTime')
    long t1
    long t2
    if(callBackStartTime == null) {
        Date date = new Date()
        message.setHeader('callBackStartTime', date.getTime())
        callbackTimeOut = 'N'
    } else {
        t1 = callBackStartTime
        Date date = new Date()
        t2 = date.getTime()
        if(t2 - t1 > 120000) {
            callbackTimeOut = 'Y'
        } else {
            callbackTimeOut = 'N'
        }
    }
    if(input.size() > 0) {
      callbackConfirmed = 'Y'
    }
    if(callbackTimeOut == 'N' && callbackConfirmed == 'N') {
        callbackWaitContinueRetry = 'Y'
        sleep(12000)
    } else {
        callbackWaitContinueRetry = 'N'
    }
    message.setHeader('callbackWaitContinueRetry', callbackWaitContinueRetry)
    return message
}
