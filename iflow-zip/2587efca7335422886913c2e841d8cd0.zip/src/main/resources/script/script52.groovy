import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    message.setHeader('discoverEDC', 'N')

    if (input.ReceiveEvents) {
        def catenax_Vendor
        if (input.ReceiveEvents.DeliveryItemKeys instanceof List) {
            catenax_Vendor = getKeyAssignments(input.ReceiveEvents.DeliveryItemKeys[0].KeyAssignments, 'CATENA_X_VENDOR')
        } else if(input.ReceiveEvents.DeliveryItemKeys.KeyAssignments) {
            catenax_Vendor = getKeyAssignments(input.ReceiveEvents.DeliveryItemKeys.KeyAssignments, 'CATENA_X_VENDOR')
        }
        if (catenax_Vendor) {
            message.setHeader('discoverEDC', 'Y')
            message.setBody('[\"' + catenax_Vendor + '\"]')
        }
    } 
    if (input.ReceiveSerialNumberEvents) {
        def catenax_Vendor = getKeyAssignments(input.ReceiveSerialNumberEvents.KeyAssignments,'CATENA_X_VENDOR')
        if (catenax_Vendor) {
            message.setHeader('discoverEDC', 'Y')
            message.setBody('[\"' + catenax_Vendor + '\"]')
        }
    }
    return message
}

def getKeyAssignments(def keyAssignments, def qualifier) {
    def  res = ""
    if (keyAssignments) {
        if (keyAssignments instanceof List) {
            keyAssignments.each{
                if (it.Qualifier == qualifier) {
                    res = it.Value
                }
            }
        }else {
            if (keyAssignments.Qualifier == qualifier) {
                res = keyAssignments.Value
            } else {
                res = ''
            }
        }
    } else {
        res = ''
    }
    return res
}
