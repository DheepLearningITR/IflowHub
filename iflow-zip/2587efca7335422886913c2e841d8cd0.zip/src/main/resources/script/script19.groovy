import com.sap.gateway.ip.core.customdev.util.Message
//import java.util.HashMap
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
 	Reader json = message.getBody(java.io.Reader)
    def contract = new JsonSlurper().parse(json)
    def contractOfferMap = [:]
    getContractOfferPayload(contractOfferMap,contract,message)
    def contractOfferJson = new JsonBuilder(contractOfferMap)
    message.setHeader('Content-Type', 'application/json' + '; charset=utf-8' )        
    message.setBody(contractOfferJson.toPrettyString())
    return message;
}

def getContractOfferPayload(def contractOfferMap, def contract,def message) {
	def contextMap = [:]
	def offerMap = [:]
	def policyMap = [:]
	def permissionMap = [:]
	def actionMap = [:]
	def constraintMap = [:]
	def constraintItemMap = [:]
    def OperatorMap = [:]
        
    def partnerEDCEndPoint = message.getProperties().get('partnerEDCUrl')
    def providerDsp = message.getProperties().get('providerDsp')
    def partnerBPN = message.getProperties().get('partnerBPN')
    def offerId = contract.'odrl:hasPolicy'.'@id'
    def assetId = contract.'edc:id'
	contextMap.'odrl' = 'http://www.w3.org/ns/odrl/2/'
	contextMap.'edc' = 'https://w3id.org/edc/v0.0.1/ns/'
	contextMap.'@vocab' = 'https://w3id.org/edc/v0.0.1/ns/'
	contractOfferMap.'@context' = contextMap
	contractOfferMap.'@type' = 'NegotiationInitiateRequest'
	contractOfferMap.'edc:connectorAddress' =partnerEDCEndPoint+providerDsp
	contractOfferMap.'edc:protocol' = 'dataspace-protocol-http'
	contractOfferMap.'edc:connectorId' = partnerBPN
	contractOfferMap.'edc:providerId' = partnerBPN
	contractOfferMap.'edc:offer' = offerMap
	offerMap.'edc:offerId' = offerId
	offerMap.'edc:assetId' = assetId
	offerMap.'edc:policy' = policyMap
	policyMap.'@type' = 'odrl:Set'
	policyMap.'odrl:target' = assetId
	policyMap.'odrl:permission' = permissionMap
	permissionMap.'odrl:constraint' = constraintMap
	constraintMap.'odrl:and' = constraintItemMap
	constraintItemMap.'odrl:leftOperand' = 'Membership'
	constraintItemMap.'odrl:operator' = OperatorMap
	OperatorMap.'@id' = 'odrl:eq'
	constraintItemMap.'odrl:rightOperand' = 'active'
	permissionMap.'odrl:target' = assetId
	permissionMap.'odrl:action' = actionMap
	actionMap.'odrl:type' = 'USE'
	policyMap.'odrl:prohibition' = []
	policyMap.'odrl:obligation' = []
}
