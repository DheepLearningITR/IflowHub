import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
 	Reader json = message.getBody(java.io.Reader)
    def catalogs = new JsonSlurper().parse(json)
	def var1 = 'data.core.digitalTwinRegistry'

	Closure query1 = { it.'edc:type' == var1}
	def filterlist = catalogs.'dcat:dataset'.findAll (query1)

    if(filterlist.size() == 1) {
        def mtJson = new JsonBuilder(filterlist[0])
        message.setBody(mtJson.toPrettyString())
    } else {
        message.setHeader('Errors', 'Y')
        message.setBody(body + ' Error findig Contract Offer')
    }
    return message
}
