import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
 	Reader json = message.getBody(java.io.Reader)
    def contractResponse = new JsonSlurper().parse(json)
    message.setHeader('negotiationId', contractResponse.'@id')
    
    def emptyBody = ''
    message.setBody(emptyBody) 
    return message
}