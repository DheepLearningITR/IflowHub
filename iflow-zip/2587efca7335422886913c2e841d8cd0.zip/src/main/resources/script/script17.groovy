import com.sap.gateway.ip.core.customdev.util.Message
//import java.util.HashMap
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def catalogMap = [:]
    getCataLogPayload(catalogMap,message)
    def mtJson = new JsonBuilder(catalogMap)
    message.setBody(mtJson.toPrettyString())
    message.getHeaders().remove('CamelHttpPath')
    message.setHeader('Content-Type', 'application/json' + '; charset=utf-8' )
    return message;
}

def getCataLogPayload(def catlogMap, def message) {
    def contextMap = [:]
    def querySpecMap = [:]
    def partnerEDCUrl = message.getProperties().get('partnerEDCUrl')
    def providerDsp = message.getProperties().get('providerDsp')
    contextMap.'edc' = 'https://w3id.org/edc/v0.0.1/ns/'
    contextMap.'@vocab' = 'https://w3id.org/edc/v0.0.1/ns/'
    catlogMap.'@context' = contextMap
    catlogMap.'@type' = 'CatalogRequest'
    catlogMap.'edc:protocol' = 'dataspace-protocol-http'
    catlogMap.'edc:providerUrl' = partnerEDCUrl + providerDsp
    querySpecMap.'@type' = 'QuerySpec'
    querySpecMap.'edc:sortOrder' = 'ASC'
    querySpecMap.'edc:offset' = 0
    querySpecMap.'edc:limit' = 100
    catlogMap.'edc:querySpec' = querySpecMap
}