import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;


def Message setMessageProperties(Message message) {
    //Get message and parse to json
    def json = message.getBody(java.io.Reader)
    def data = new JsonSlurper().parse(json)
    
    //messageHeader
    message.setHeader("SAP_ApplicationID", data.messageHeader.id)
    
    
    message.setProperty("P_SenderParty", data.messageHeader.senderCommunicationSystemDisplayId)
    message.setProperty("P_ReceiverParty", data.messageHeader.receiverCommunicationSystemDisplayId)

   
    message.setProperty("P_SalesQuoteId", data.messageRequests[0].body.id)
    message.setProperty("P_SalesQuoteDisplayId", data.messageRequests[0].body.displayId)
    
    message.setProperty("P_messageHeaderId", java.util.UUID.randomUUID())
    message.setProperty("P_messageRequestHeaderId", java.util.UUID.randomUUID())
    
    // Idempotency
    message.setHeader("RequestID", data.messageHeader.id)
    message.setHeader("RepeatabilityCreation", data.messageHeader.senderCommunicationSystemDisplayId)

    return message
}

def Message readExceptionMessage(Message message){
    def body = message.getBody(java.io.Reader)
     if (body!=null) {
        def data = new XmlSlurper().parse(body)
        String errorMessage = data.message
        message.setBody(errorMessage)
     }
    else {
        def map = message.getProperties();
        def exception = map.get("CamelExceptionCaught");
        if (exception!=null)
        {
            def errorMessage = exception.getMessage();
            message.setBody(errorMessage)
        }
    }
    return message
}