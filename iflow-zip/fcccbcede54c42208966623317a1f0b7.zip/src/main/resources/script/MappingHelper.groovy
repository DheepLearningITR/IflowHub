import com.sap.it.api.mapping.*;


def String getSDDocumentRelatedObjectType(String arg1,MappingContext context){
	return context.getProperty("P_SDDocumentRelatedObjectType") 
}

def String formatPricingUnit(String decimalString){
    try {
            int result = (int) Double.parseDouble(decimalString)
            return result
        } catch (NumberFormatException e) {
           return decimalString
        }
}