import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String);
	
   
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body.toString());
    message.setProperty("EndpointURL",object.destinationConfiguration['URL']);
    message.setProperty("client","sap-client="+object.destinationConfiguration['sap-client']);
    message.setProperty("CloudConnectorLocationId",object.destinationConfiguration.CloudConnectorLocationId);
	 
	 return message;
}