import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
import groovy.util.XmlSlurper
    
def Message processData(Message message) {


 def body = message.getBody(java.lang.String);
    def jsonSlurper = new JsonSlurper()
	 def root = new XmlSlurper(false, false).parseText( body )


 


message.setHeader("destination",root.ComplaintActions.targetType.TargetReferenceTypes.destinationSystem);
 identifier=root.ComplaintActions.items.ComplaintActionItems.identifier;
 constant= "\$filter=CustomerReturn eq '"+identifier +"'";
 
message.setHeader("constant",constant );



return message;
} 