import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
import groovy.xml.*
def Message processData(Message message) {
   
    
// def input=  message.getProperty("input");
// def id=inputList.find{objArr->objArr[1]=="66000262"}?.get(0);
def id = findIdByIdentifier(message.getProperty("input"), "66000262");
 message.setProperty("id",id);
    return message;
}

// Function to find ID by identifier
def findIdByIdentifier(Map<String, List<Map>> groupedBySystem, String targetIdentifier) {
    def resultId = null
    groupedBySystem.each { systemName, items ->
        items.each { item ->
            if (item.items.identifier == targetIdentifier) {
                resultId = item.ID
                return  // Exit loop once the identifier is found
            }
        }
        if (resultId != null) {
            return  // Exit outer loop if result found
        }
    }
    return resultId
}
