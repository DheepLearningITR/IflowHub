import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    
    int totalCount=0;
    int topVal=0;
    String maxCount = message.getProperty("MaxCount");
    def isInteger=isValidCount(message.getBody(java.lang.String))
    if(isInteger){
        totalCount=message.getBody(java.lang.String).toInteger()
        int max = maxCount.toInteger()
        if(totalCount>=max){
            topVal=maxCount.toInteger()
        }else{
            topVal = totalCount
        }
        
    }
    
	message.setProperty("totalCount",totalCount.toString())
	message.setProperty("skipVal", "0");
	message.setProperty("TopVal",topVal.toString());
	message.setBody("")

	return message;
   
    
}

def isValidCount(value) {
    value.toString().isInteger()
}