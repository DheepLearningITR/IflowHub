import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Date;
import java.util.TimeZone;

def Message processData(Message message) { 
      //Body 
    def body = message.getBody(java.lang.String);
    message.setProperty("original_payload",body);
        message.setProperty("skip",0);

    message.setProperty("filterByStatus", " \$filter=(status_code eq 'CRTD' and targetType/targetDocumentCategory_code eq 'DBTMEM' and parentID/lifeCycleStatus_code ne 'CMPL'  ) &  \$expand=targetType(\$select=destinationSystem),items(\$select=identifier) & \$select=ID  & \$count=true");
    return message
}