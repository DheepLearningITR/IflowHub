import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
import groovy.xml.*
def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String);
    
    message.setProperty("InputJSONString",body);
   
    def root = new XmlSlurper(false, false).parseText( body )
    def destination=root.target.Destination;
    message.setHeader("destination",destination);
  
  def identifier=root.target.identifier;
  def identifierList=new ArrayList();
   identifier.each(){e->
   
   identifierList.add("DebitMemoRequest eq '"+e +"'");
   }
identifierList=identifierList.join(" or ")
    constant= "\$filter=("+identifierList;
    
    constant=constant+" ) and OverallOrdReltdBillgStatus eq 'C'";
 
    message.setHeader("constant",constant );
      message.setProperty("EndpointCredentials","SAP_"+destination );

    return message;
}