import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
import groovy.util.XmlSlurper
    
def Message processData(Message message) {
def totalCount =  message.getProperty("totalCount")
def exitFlag = false
def skipVal = message.getProperty("skipVal");
def topVal = message.getProperty("TopVal");
def skipValTemp=topVal.toInteger()+skipVal.toInteger();

 def body = message.getBody(java.lang.String);
    def jsonSlurper = new JsonSlurper()
	 def root = new XmlSlurper(false, false).parseText( body )

    //def object = jsonSlurper.parseText(root.toString());
 
    
if(skipValTemp.toInteger() >= totalCount.toInteger()){
    exitFlag=true;
    
}
skipVal=skipValTemp.toString()
message.setProperty("exitFlag",exitFlag);
message.setProperty("skipVal", skipVal);




return message;
} 