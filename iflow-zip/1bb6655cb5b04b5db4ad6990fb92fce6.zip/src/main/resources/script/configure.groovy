
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil

def Message processData(Message message) {
        def body = message.getBody(String.class);
        if (body.contains("<MessageHeader>")) {
            def bodyXml = new XmlSlurper().parseText(body);
            def toAddXml = new XmlSlurper().parseText("<FromNewCPI>True</FromNewCPI>");
            bodyXml.'**'.find { it.name() == 'MessageHeader' }.appendNode(toAddXml);

            message.setBody(XmlUtil.serialize(bodyXml));
        }
       return message;
}
