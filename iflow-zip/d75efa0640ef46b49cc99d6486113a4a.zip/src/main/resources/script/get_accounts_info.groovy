package main.resources.script;

import com.sap.gateway.ip.core.customdev.util.Message;

import java.util.AbstractMap
import java.util.HashMap;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;

import java.lang.reflect.Type
import java.security.Key;
import java.security.KeyPair;
import java.security.PrivateKey;

import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.GenericJson;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive
import com.google.gson.JsonSerializationContext
import com.google.gson.JsonArray;
import com.google.gson.JsonSerializer;
import com.google.gson.JsonNull;

import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

import com.google.api.services.analytics.Analytics;
import com.google.api.services.analytics.AnalyticsScopes;

import com.google.api.services.analytics.model.Accounts;
import com.google.api.services.analytics.model.Account;
import com.google.api.services.analytics.model.Webproperties;
import com.google.api.services.analytics.model.Webproperty;
import com.google.api.services.analytics.model.Profiles;
import com.google.api.services.analytics.model.Profile;
import com.google.api.services.analytics.model.Columns;
import com.google.api.services.analytics.model.Column;
import com.google.api.services.analytics.model.CustomDimensions;
import com.google.api.services.analytics.model.CustomDimension;
import com.google.api.services.analytics.model.CustomMetrics;
import com.google.api.services.analytics.model.CustomMetric;

class GoogleAnalyticsManager {
	String READ_AND_ANALYZE = "READ_AND_ANALYZE";
	Analytics analytics;
	Gson gson;

	GoogleAnalyticsManager() {
	}

	public GoogleAnalyticsManager(String service_account_id,String service_account_email) {
		//Get Service Account Private Key
		KeystoreService service = ITApiFactory.getApi(KeystoreService.class, null);
		KeyPair keyPair = service.getKeyPair(service_account_id);
		PrivateKey privateKey = keyPair.getPrivate();

		//Get Google Credential
		HttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
		JsonFactory jsonFactory = JacksonFactory.getDefaultInstance();
		GoogleCredential credential = new GoogleCredential.Builder()
				.setTransport(httpTransport)
				.setJsonFactory(jsonFactory)
				.setServiceAccountId(service_account_id)
				.setServiceAccountPrivateKey(privateKey)
				.setServiceAccountScopes(AnalyticsScopes.all())
				.build();
		this.analytics = new Analytics.Builder(httpTransport, jsonFactory, credential).build();
	}

	public void setAnalytics(Analytics analyticsInstance) {
		this.analytics = analyticsInstance;
	}

	private Gson getGson() {
		if (this.gson == null) {
			this.gson = new GsonBuilder()
					.registerTypeAdapter(Accounts.class, new CustomAccountsSerializer())
					.registerTypeAdapter(Webproperties.class, new CustomWebPropertiesSerializer())
					.registerTypeAdapter(Profiles.class, new CustomProfilesSerializer())
					.registerTypeAdapter(Columns.class, new MetricsDimensionsColumnsSerializer())
					.registerTypeAdapter(CustomMetrics.class, new CustomMetricsSerializer())
					.registerTypeAdapter(CustomDimensions.class, new CustomDimensionsSerializer())
					.serializeNulls()
					.create();
		}
		return this.gson;
	}

	private Accounts getAnalyticsAccounts() {
		return this.analytics.management().accounts().list().execute();
	}

	private Webproperties getWebProperties(Account account) {
		return this.analytics.management().webproperties().list(account.getId()).execute();
	}

	private Profiles getProfiles(Account account, Webproperty webProperty) {
		return this.analytics.management().profiles().list(account.getId(), webProperty.getId()).execute();
	}

	public JsonElement getAccountsInfo() {
		JsonObject d = new JsonObject();
		JsonObject results = new JsonObject();
		Accounts accounts = getAnalyticsAccounts();
		Boolean canReadAndAnalyze = false;
		for(Account account: accounts.getItems()) {
			Webproperties webProperties = getWebProperties(account);
			for(Webproperty webProperty: webProperties.getItems()) {
				Profiles profiles = getProfiles(account, webProperty);
				Boolean hasOneAuthorizedView = false;
				for(Profile profile: profiles.getItems()) {
					canReadAndAnalyze = profile.getPermissions().getEffective().contains(READ_AND_ANALYZE);
					if (canReadAndAnalyze) {
						hasOneAuthorizedView = true;
						profile.put("webPropertyName", webProperty.getName());
						profile.put("accountName", account.getName());
					} else {
						profiles.remove(profile);
					}
				}
				if (hasOneAuthorizedView) {
					webProperty.put("profiles", profiles);
					webProperty.put("accountName", account.getName());
				} else {
					webProperties.remove(webProperty);
				}
			}
			account.put("webProperties", webProperties);			
		}

		results.add("results", this.getGson().toJsonTree(accounts));
		d.add("d", results);

		return d;
	}

	public JsonElement getAllDimensionsAndMetrics(String accountId, String webPropertyId) {
		JsonObject d = new JsonObject();
		JsonObject results = new JsonObject()
		JsonObject items = new JsonObject();

		items.add("default", getAllPublicDefaultDimensionsAndMetrics());
		items.add("custom", getAllActiveCustomDimensionsAndMetrics(accountId, webPropertyId));

		results.add("results", items);
		d.add("d", results);
		return d;
	}

	private Columns getAllDefaultDimensionsAndMetrics() {
		String reportType = "ga";
		return this.analytics.metadata().columns().list(reportType).execute();
	}

	private CustomDimensions getAllCustomDimensions(String accountId, String webPropertyId) {
		return this.analytics.management().customDimensions().list(accountId, webPropertyId).execute();
	}

	private CustomMetrics getAllCustomMetrics(String accountId, String webPropertyId) {
		return this.analytics.management().customMetrics().list(accountId, webPropertyId).execute();
	}

	private JsonElement getAllActiveCustomDimensions(String accountId, String webPropertyId) {
		CustomDimensions dimensions = getAllCustomDimensions(accountId, webPropertyId);
		Gson gson = this.getGson();
		return gson.toJsonTree(dimensions, CustomDimensions.class);
	}

	private JsonElement getAllActiveCustomMetrics(String accountId, String webPropertyId) {
		CustomMetrics metrics = getAllCustomMetrics(accountId, webPropertyId);
		Gson gson = this.getGson();
		return gson.toJsonTree(metrics, CustomMetrics.class);
	}

	private JsonElement getAllActiveCustomDimensionsAndMetrics(String accountId, String webPropertyId) {
		JsonObject results = new JsonObject();

		results.add("dimensions", getAllActiveCustomDimensions(accountId, webPropertyId));
		results.add("metrics", getAllActiveCustomMetrics(accountId, webPropertyId));

		return results;
	}

	private JsonElement getAllPublicDefaultDimensionsAndMetrics() {

		Columns columns = getAllDefaultDimensionsAndMetrics();
		Gson gson = this.getGson();

		return gson.toJsonTree(columns, Columns.class);
	}
}

abstract class BaseGsonSerializer<T extends GenericJson> implements JsonSerializer<T> {

	protected <U extends AbstractMap> Object getValueOrJsonNull(U map, String key) {
		return getJsonPrimitiveOrNull(map.get(key));
	}

	protected Object getValueOrJsonNull(Object value) {
		return getJsonPrimitiveOrNull(value);
	}

	protected Object getValueOrJsonNull(Map<Object, Object> map) {
		if (map != null) {
			return map;
		}
		return JsonNull.INSTANCE;
	}

	protected JsonElement getJsonPrimitiveOrNull(Object value) {
		try {
			if (value != null) {
				// TODO: Maybe use the serialize method from serialization context here instead
				return new JsonPrimitive(value);
			}
		} catch (Exception ex) {
			return JsonNull.INSTANCE;
		}
		return JsonNull.INSTANCE;
	}
}

class CustomAccountsSerializer extends BaseGsonSerializer<Accounts> {
	@Override
	public JsonElement serialize(Accounts src, Type typeOfSrc, JsonSerializationContext context) {
		JsonArray jsonAccounts = new JsonArray();
		JsonObject jsonAccount;
		for(Account account: src.getItems()) {
			jsonAccount = new JsonObject();
			jsonAccount.add("accountId", getValueOrJsonNull(account.getId()));
			jsonAccount.add("name", getValueOrJsonNull(account.getName()));
			jsonAccount.add("webProperties", context.serialize(getValueOrJsonNull(account.get("webProperties", Webproperties.class))));
			jsonAccounts.add(jsonAccount);
		}

		return jsonAccounts;
	}
}

class CustomWebPropertiesSerializer extends BaseGsonSerializer<Webproperties> {
	@Override
	public JsonElement serialize(Webproperties src, Type typeOfSrc, JsonSerializationContext context) {
		JsonArray jsonWebProperties = new JsonArray();
		JsonObject jsonWebProperty;
		for(Webproperty webProperty: src.getItems()) {
			jsonWebProperty = new JsonObject();
			jsonWebProperty.add("webPropertyId", getValueOrJsonNull(webProperty.getId()));
			jsonWebProperty.add("accountId", getValueOrJsonNull(webProperty.getAccountId()));
			jsonWebProperty.add("accountName", getValueOrJsonNull(webProperty.get("accountName")))
			jsonWebProperty.add("name", getValueOrJsonNull(webProperty.getName()));
			jsonWebProperty.add("views", context.serialize(getValueOrJsonNull(webProperty.get("profiles", Profiles.class))));
			jsonWebProperty.add("websiteURL", getValueOrJsonNull(webProperty.getWebsiteUrl()));
			jsonWebProperties.add(jsonWebProperty);
		}

		return jsonWebProperties;
	}
}

class CustomProfilesSerializer extends BaseGsonSerializer<Profiles> {
	@Override
	public JsonElement serialize(Profiles src, Type typeOfSrc, JsonSerializationContext context) {
		JsonArray jsonProfiles = new JsonArray();
		JsonObject jsonProfile;
		for(Profile profile: src.getItems()) {
			jsonProfile = new JsonObject();
			jsonProfile.add("viewId", getValueOrJsonNull(profile.getId()))
			jsonProfile.add("webPropertyId", getValueOrJsonNull(profile.getWebPropertyId()));
			jsonProfile.add("webPropertyName", getValueOrJsonNull(profile.get("webPropertyName")));
			jsonProfile.add("accountId", getValueOrJsonNull(profile.getAccountId()));
			jsonProfile.add("accountName", getValueOrJsonNull(profile.get("accountName")));
			jsonProfile.add("name", getValueOrJsonNull(profile.getName()));
			jsonProfiles.add(jsonProfile);
		}

		return jsonProfiles;
	}
}

class CustomDimensionsSerializer extends BaseGsonSerializer<CustomDimensions> {
	@Override
	public JsonElement serialize(CustomDimensions src, Type typeOfSrc, JsonSerializationContext context) {
		JsonArray jsonDimensions = new JsonArray();
		JsonObject jsonDimension;
		for(CustomDimension customDimension: src.getItems()) {
			if (customDimension.getActive()) {
				jsonDimension = new JsonObject();
				jsonDimension.add("accountId", getValueOrJsonNull(customDimension.getAccountId()));
				jsonDimension.add("webPropertyId", getValueOrJsonNull(customDimension.getWebPropertyId()));
				jsonDimension.add("id", getValueOrJsonNull(customDimension.getId()));
				jsonDimension.add("name", getValueOrJsonNull(customDimension.getName()));
				jsonDimension.add("scope", getValueOrJsonNull(customDimension.getScope()));
				jsonDimension.add("type", getValueOrJsonNull("CUSTOM_DIMENSION"));
				jsonDimension.add("dataType", getValueOrJsonNull(customDimension, "type"));
				jsonDimensions.add(jsonDimension);
			}
		}

		return jsonDimensions;
	}
}

class CustomMetricsSerializer extends BaseGsonSerializer<CustomMetrics> {
	@Override
	public JsonElement serialize(CustomMetrics src, Type typeOfSrc, JsonSerializationContext context) {
		JsonArray jsonMetrics = new JsonArray();
		JsonObject jsonMetric;
		for(CustomMetric customMetric: src.getItems()) {
			if (customMetric.getActive()) {
				jsonMetric = new JsonObject();
				jsonMetric.add("accountId", getValueOrJsonNull(customMetric.getAccountId()));
				jsonMetric.add("webPropertyId", getValueOrJsonNull(customMetric.getWebPropertyId()));
				jsonMetric.add("id", getValueOrJsonNull(customMetric.getId()));
				jsonMetric.add("name", getValueOrJsonNull(customMetric.getName()));
				jsonMetric.add("scope", getValueOrJsonNull(customMetric.getScope()));
				jsonMetric.add("type", getValueOrJsonNull("CUSTOM_METRIC"));
				jsonMetric.add("dataType", getValueOrJsonNull(customMetric.getType()));
				jsonMetrics.add(jsonMetric);
			}
		}

		return jsonMetrics;
	}
}

class MetricsDimensionsColumnsSerializer extends BaseGsonSerializer<Columns> {
	@Override
	public JsonElement serialize(Columns src, Type typeOfSrc, JsonSerializationContext context) {
		JsonObject jsonColumns = new JsonObject();
		JsonArray jsonMetrics = new JsonArray();
		JsonArray jsonDimensions = new JsonArray();
		JsonObject jsonColumn;
		Map<String, String> attributes;
		for(Column column: src.getItems()) {
			attributes = column.getAttributes();
			if (attributes != null && isPublic(column)) {
				jsonColumn = new JsonObject();
				jsonColumn.addProperty("id", column.getId());
				jsonColumn.add("name", getValueOrJsonNull(attributes, "uiName"));
				jsonColumn.add("description", getValueOrJsonNull(attributes, "description"));
				jsonColumn.add("group", getValueOrJsonNull(attributes, "group"));
				jsonColumn.add("type", getValueOrJsonNull(attributes, "type"));
				jsonColumn.add("dataType", getValueOrJsonNull(attributes, "dataType"));
				if (isDimension(column)) {
					jsonDimensions.add(jsonColumn);
				} else if (isMetric(column)) {
					jsonMetrics.add(jsonColumn);
				}
			}
		}
		jsonColumns.add("dimensions", jsonDimensions);
		jsonColumns.add("metrics", jsonMetrics);
		return jsonColumns;
	}

	private Boolean isDimension(Column column) {
		return column.getAttributes().get("type") == "DIMENSION";
	}

	private Boolean isMetric(Column column) {
		return column.getAttributes().get("type") == "METRIC";
	}

	private Boolean isPublic(Column column) {
		return column.getAttributes().get("status").equals("PUBLIC");
	}
}
def Message processData(Message message) {
	try {
		GoogleAnalyticsManager analyticsManager = new GoogleAnalyticsManager(message.getProperty("service_account_id").toString(),message.getProperty("service_account_email").toString());
		message.setBody(analyticsManager.getAccountsInfo().toString());
	} catch (GoogleJsonResponseException ex) {
		String errors = build_error_response(ex.getDetails().getCode(),ex.getDetails().getErrors()[0].getMessage());
		message.setBody(errors);
		message.setProperty("response","exception")
	}

	message.setHeader("content-type", "application/json");
	return message;
}

String build_error_response(int code,String message) {

	def error = [
		"code": code,
		"value": message
	]

	def errorObject = [
		"error": error
	]

	def jsonBuilder = new JsonBuilder()
	def response = JsonOutput.toJson(jsonBuilder(errorObject));

	return response;
}