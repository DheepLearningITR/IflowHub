import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import org.json.simple.*
import groovy.json.*
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    
    def succ = message.getHeaders()["CamelHttpResponseCode"]

    def stringWriter = new StringWriter()
    def peopleBuilder = new MarkupBuilder(stringWriter)

    peopleBuilder.root {
        success(succ)
    }
    def xml = stringWriter.toString()    
     
    message.setBody(xml)
    return message
}