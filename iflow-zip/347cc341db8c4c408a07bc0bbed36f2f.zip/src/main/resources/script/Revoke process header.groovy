import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
	
	def map = message.getHeaders()
	map.remove("X-ConsumerKey")
		
	message.setHeader("Authorization", "Basic " + 'U0FQX1BheXJvbGw6RGgxQjBOeURwTzE=')
	//message.setHeader("Authorization", "Basic " + 'U0FQX1BheXJvbGw6b0RTY3VWcnc=')
	return message

}

def Message readParameter( Message message) {
    
    message.setHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
    def parameter = message.getHeaders()["CamelHttpQuery"]
    if(parameter.tokenize("=")[0] == "User") {
	   message.setHeader("TokenKey", parameter.tokenize("=")[1])
    }
    return message
}
