import com.sap.gateway.ip.core.customdev.util.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXParseException;

def Message handleAhcOperationFailedException(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    try {
    	def map = message.getProperties();
		def ex = map.get("CamelExceptionCaught");
        if (ex!=null) {
            if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
                def statusText = ex.getStatusText();
                def statusCode = ex.getStatusCode();
                String response = "StatusCode: " + statusCode + "; StatusText: " + statusText;
                message.setBody("<Exception><category>Exception</category><message>" + response + "</message><DetailMessages></DetailMessages></Exception>");
                if(messageLog != null) {
                  messageLog.addAttachmentAsString("http_handler exception", ex.getMessage(), "plain/text");
                }
                
            } else {
                if (ex.getClass().getCanonicalName().equals("javax.net.ssl.SSLHandshakeException")) {
                    message.setBody("<Exception><category>ConnectionError</category><message>Connection to Concur System failed</message><DetailMessages>" + ex.getMessage() + "</DetailMessages></Exception>");
                    if (messageLog != null) {
                        messageLog.addAttachmentAsString("SSLHandshakeException", ex.getMessage(), "plain/text");
                    }
                } else {
                    message.setBody("<Exception><category>Exception</category><message>Exception of type " + ex.getClass().getCanonicalName() + " occured</message><DetailMessages></DetailMessages></Exception>");
                }
            }
        }    
        
    } catch (Exception ex) {
        if(messageLog != null)
        {
            messageLog.addAttachmentAsString("http_handler exception", ex.getMessage(), "plain/text");
        }
         message.setBody("<Exception><category>Exception</category><message>Exception occured, please check CPI Log Attachment</message><DetailMessages></DetailMessages></Exception>");
    }
    message.setHeader("CamelHttpResponseCode", "400");
    return message;
}

def Message handleXMLValidatorException(Message message, String enhancementFlowName) {
    def messageLog = messageLogFactory.getMessageLog(message);
    try {
    	def map = message.getProperties();
		def ex = map.get("CamelExceptionCaught");
        if (ex!=null) {
            if (ex.getClass().getCanonicalName().equals("org.apache.camel.processor.validation.SchemaValidationException")) {
            //Invalid XML?              
                String errortext = "";
                def errorList = ex.getErrors();
                for(int i = 0; i < errorList.size() ; i++) { errortext = errortext + errorList[i].toString() + " "; };   
                message.setProperty("errorList", errorList.toString());
                message.setBody("<Exception><category>Validation</category><message>" + enhancementFlowName + " enhancement flow violates given XSD Schema</message><DetailMessages>" + errortext  + "</DetailMessages></Exception>");
            } else {
                message.setBody("<Exception><category>Exception</category><message>Exception of type " + ex.getClass().getCanonicalName() + " occured in " + enhancementFlowName + " subflow</message><DetailMessages></DetailMessages></Exception>");
            }
        }
    } catch (Exception ex) {
        if(messageLog != null)
        {
            messageLog.addAttachmentAsString("http_handler exception", ex.getMessage(), "plain/text");
        }
        message.setBody("<Exception><category>Exception</category><message>Exception occured in " +  enhancementFlowName + " subflow, please check CPI Log Attachment</message><DetailMessages></DetailMessages></Exception>");
    }
    message.setHeader("CamelHttpResponseCode", "400");
    return message;
}

def Message handleCostObjectXMLValidatorException(Message message) {
    message = handleXMLValidatorException(message, "Costobject");
    return message;
}

def Message handleEmployeeXMLValidatorException(Message message) {
    message = handleXMLValidatorException(message, "Employee");
    return message;
}

def Message handleEmployeeResponseXMLValidatorException(Message message) {
    message = handleXMLValidatorException(message, "Employee Response");
    return message;
}

def Message handleExpenseReportException(Message message) {
    message = handleXMLValidatorException(message, "Expense Report");
    return message;
}

