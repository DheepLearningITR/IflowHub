import com.sap.gateway.ip.core.customdev.util.Message;

def Message handleProperties(Message message) {
        
    // for Concur the body needs to be in String format
    def body_string = message.getBody(String.class);
    message.setBody(body_string);
 
    //copy target fields to properties
    def headers = message.getHeaders();         
    def target_uri = headers.get("targetURL");       
    def splitIdx = target_uri.indexOf("?"); 
    if (splitIdx != -1){
       message.setProperty('concurAddress',target_uri.substring(0,splitIdx));
       message.setProperty('concurQuery',target_uri.substring(splitIdx+1,target_uri.length()));
    } else {
       message.setProperty('concurAddress',target_uri);
       message.setProperty('concurQuery','');
    }
            
    def target_access_token = headers.get("targetAuthorization");
    message.setHeader("Authorization", target_access_token);       
            
    // Enhancement parameter to upper Case 
    def props = message.getProperties();
    def ehCO = props.get("enhancementForCostObject");
    message.setProperty("enhancementForCostObject", ehCO.toUpperCase());
    def ehEmp = props.get("enhancementForEmployee");
    message.setProperty("enhancementForEmployee", ehEmp.toUpperCase());
    def ehExRep = props.get("enhancementForExpenseReport");
    message.setProperty("enhancementForExpenseReport", ehExRep.toUpperCase());
    def ehCashAd = props.get("enhancementForCashAdvance");
    message.setProperty("enhancementForCashAdvance", ehCashAd.toUpperCase());

    // custom header 
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){

		def bydMsgType = props.get("bydMsgType");		
		if(bydMsgType != null){
			messageLog.addCustomHeaderProperty("bydMsgType", bydMsgType);		
        }
	}
    
    return message;
}
