import com.sap.gateway.ip.core.customdev.util.Message;

def Message stripjson(Message message) {
        
    // for Concur the body needs to be in String format
    def body_string = message.getBody(String.class);
        
    String[] parts1 = body_string.split("\\[");
    String[] parts2 = parts1[1].split("\\]");
        
    body_string = "[" + parts2[0]  + "]";

    message.setBody(body_string);
    return message;
}

def Message preparePayloadConcur(Message message) {

    // for Concur the body needs to be in String format
    def body_string = message.getBody(String.class);
    message.setBody(body_string);
    return message;
}

def Message ShiftToV1Format(Message message) {
         
    // for Concur the body needs to be in String format
    def body_string = message.getBody(String.class);
    
    def v1_body_string = body_string.replace("content","fIDocuments");
    message.setBody(v1_body_string);
    return message;
}

def Message ShiftToV4Format(Message message) {
        
    // for Concur the body needs to be in String format
    def body_string = message.getBody(String.class);
    
    def v4_body_string = body_string.replace("fIDocuments", "content");
    message.setBody(v4_body_string);
    return message;
}

def Message fIDocFromDoc(Message message) {

    def body_string = message.getBody(String.class);
    body_string = body_string.replaceAll("\\[\"\"\\]","\\[\\]");
    // ? body = StringEscapeUtils.escapeJava(body);
    body_string = body_string.replaceAll(":\"\"",":null");

    // since XML to JSON Converter doesn't consider the XSD we have to convert all numeric fields into non-string ("amountField": "123,45" --> "amountField": 123,45)
    body_string = Convert2Num("size", body_string);
    body_string = Convert2Num("totalElements", body_string);
    body_string = Convert2Num("totalPages", body_string);
    body_string = Convert2Num("number", body_string);
    
    
    body_string = Convert2Num("totalApprovedAmount", body_string);
    body_string = Convert2Num("reportKey", body_string);
    body_string = Convert2Num("cashAdvanceReturnsAmount", body_string);
    body_string = Convert2Num("entryApprovedAmount", body_string);
    body_string = Convert2Num("reportEntryTransactionAmount", body_string);
    body_string = Convert2Num("cardTransactionAmount", body_string);
    body_string = Convert2Num("cardTransactionPostedAmount", body_string);
    body_string = Convert2Num("allocationPercentage", body_string);
    body_string = Convert2Num("amountGross", body_string);
    body_string = Convert2Num("amountNetOfReclaim", body_string);
    body_string = Convert2Num("amountNetOfTax", body_string);
    body_string = Convert2Num("amountTax", body_string);
    body_string = Convert2Num("amountReclaim", body_string);
    body_string = Convert2Num("legacyEntryId", body_string);
    body_string = Convert2Num("entryExchangeRate", body_string);
    body_string = Convert2Num("cashAdvanceApplicationAmount", body_string);

    body_string = Convert2Num("exchangeRate", body_string);
    body_string = Convert2Num("requestAmount", body_string);
    body_string = Convert2Num("amount", body_string);

    message.setBody(body_string);
    return message;
}


def String Convert2Num(String numVar, String body_string) {
// This function converts the value of the field numVar into a numeric field (removes "")
// "myField": "123,45" --> "myField": 123,45
// "myField": null remains

    numVar = "\"" + numVar + "\"";
    Integer numVarLength = numVar.length();

//  First occurence of numVar
    Integer variableIndex = body_string.indexOf(numVar, 0);
    while(variableIndex > -1) {
//      Search for comma after numVar = blala,      
        Integer endBracketIndex     = body_string.indexOf("}", variableIndex + numVarLength );
        Integer endCommaIndex       = body_string.indexOf(",", variableIndex + numVarLength );
  
        if (endCommaIndex == -1 || endBracketIndex < endCommaIndex ) {
            endCommaIndex =  endBracketIndex;
        }
  
//      Detect Substring between end of variable name and comma  
        String nullstring   = body_string.substring(variableIndex + numVarLength,  endCommaIndex);
//      Try to find null  
        Integer nullIndex  = nullstring.indexOf("null", 0 );
//      If not null is found remove /"  / "  around value
        if (nullIndex == -1) {
//          Index of starting "        
            Integer startSubstringIndex = body_string.indexOf("\"", variableIndex + numVarLength );     
//          Index of ending  "    
            Integer endSubstringIndex   = body_string.indexOf("\"", startSubstringIndex + 1 ) + 1;
//          Replace Substring "4711" with substring 4711 (without "")    
            StringBuffer buffer = new StringBuffer(body_string);
            body_string = buffer.replace(startSubstringIndex, endSubstringIndex, body_string.substring(startSubstringIndex + 1, endSubstringIndex - 1 ) );
        }
//      Set xIndex after this  occurence     
        Integer xIndex = endCommaIndex;
//      Search for next occurence     
        variableIndex = body_string.indexOf(numVar, xIndex);
    }  
  
    return body_string;
}


