import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message handleExceptionDetails(Message message) {	
	def properties = message.getProperties();
    def exception = properties.get('CamelExceptionCaught');
    if(exception!=null){
        if(exception.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")){
            def body = exception.getResponseBody();
            message.setBody(body);
            def exceptionBody= exception.getResponseBody();
            def js = new JsonSlurper();
            def exceptionObject = js.parseText(exceptionBody);
        	def writer = new StringWriter()
        	def xmlBuilder = new MarkupBuilder(writer)
        	xmlBuilder.doubleQuotes = true;
        	xmlBuilder.'soap:Envelope'('xmlns:soap':soapNamespace){
        	    'soap:Body'{
            	    'soap:Fault'{
            	            'faultcode'(exceptionObject.error.code)
            	            'faultstring'(exceptionObject.error.message)
            	    }
        	    }
        	}
    		String soapResponse = writer.toString()	
    		message.setBody(soapResponse)
        }
    }
	return message;	
}
