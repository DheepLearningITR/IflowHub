import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

//Address Types in OMF
@Field String SHIP_TO_KEY_OMF = 'SHIP_TO';
@Field String BILL_TO_KEY_OMF = 'BILL_TO';
@Field String SOLD_TO_KEY_OMF = 'SOLD_TO';

//Partner Types in S4
@Field String SOLD_TO_KEY_S4 = 'AG';
@Field String SHIP_TO_KEY_S4 = 'WE';
@Field String BILL_TO_KEY_S4 = 'RE';

//Only set refundMethod if it is missing
def Message transformItemRefundMethods(Message message){
    def body = message.getBody(java.lang.String) as String;
	//Parse message body as JSON
	def bodyJson = new JsonSlurper().parseText(body);
	
	def configuredRefundProcgMode = (bodyJson.ROOT.RETURNS_REFUND_PROCG_MODE as String);
	def returnOrderItems = bodyJson.ROOT.BODY.orderItems;
	returnOrderItems.each { orderItem ->
	//Set refundMethod to default (configured value)
	def oiRm = orderItem.refundMethod as String;
	    if(oiRm == null || oiRm.isEmpty()){
	        orderItem["refundMethod"] = configuredRefundProcgMode;
	    }
	}
	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(bodyJson)));
    return message;
}

//Transform customer structure of inbound payload to facilitate field mapping
def Message transformAddresses(Message message) {
	
	def body = message.getBody(java.lang.String) as String;
	//Parse message body as JSON
	def bodyJson = new JsonSlurper().parseText(body);
	//Save Partner Id
	String fulfillmentSystemReferenceId = bodyJson.customer.fulfillmentSystemReference ? bodyJson.customer.fulfillmentSystemReference.id : "";
	String externalSystemReferenceId = bodyJson.customer.externalSystemReference ? bodyJson.customer.externalSystemReference.externalId : "";
	// Use fulfillmentSystemReference->id if available; otherwise fallback to externalSystemReference->externalId
	String soldToPartnerId = fulfillmentSystemReferenceId ?: externalSystemReferenceId;

	//First loop through "customer->addresses" to:
	//1 - Transform address type from OMF to the corresponding partner type of S4
	//2 - Add partnerId to "address" block
	//3 - Verify if sold-to address is present
	bodyJson.customer.addresses.each { address ->
		//convert OMF addressType key to S/4HANA partner type key, and add partnerId
		if (address.addressType == SHIP_TO_KEY_OMF) {
			address.addressType = SHIP_TO_KEY_S4;
			address.partnerId = soldToPartnerId;
		}
		if (address.addressType == BILL_TO_KEY_OMF) {
			address.addressType = BILL_TO_KEY_S4;
			address.partnerId = soldToPartnerId;
		}
		if (address.addressType == SOLD_TO_KEY_OMF) {
			address.addressType = SOLD_TO_KEY_S4;
			address.partnerId = soldToPartnerId;
		}
	}
	
	//add ship-to (WE) node, if structure exists in inbound payload
	if (bodyJson.shipToParty != null) {
		def shipToNode = [:];
		//set partner ID
		String fulfillmentSystemReferenceIdShipTo = bodyJson.shipToParty.fulfillmentSystemReference ? bodyJson.shipToParty.fulfillmentSystemReference.id : "";
		String externalSystemReferenceIdShipTo = bodyJson.shipToParty.externalSystemReference ? bodyJson.shipToParty.externalSystemReference.externalId : "";
		// Use fulfillmentSystemReference->id if available; otherwise fallback to externalSystemReference->externalId
		shipToNode.partnerId = fulfillmentSystemReferenceIdShipTo ?: externalSystemReferenceIdShipTo;
		//set partner type
		shipToNode.addressType = SHIP_TO_KEY_S4;
		//set address fields
		shipToNode.street = bodyJson.shipToParty.address.street;
		shipToNode.houseNumber = bodyJson.shipToParty.address.houseNumber;
		shipToNode.poBox = bodyJson.shipToParty.address.poBox;
		shipToNode.postalCode = bodyJson.shipToParty.address.postalCode;
		shipToNode.city = bodyJson.shipToParty.address.city;
		shipToNode.country = bodyJson.shipToParty.address.country;
		shipToNode.district = bodyJson.shipToParty.address.district;
		shipToNode.state = bodyJson.shipToParty.address.state;
		shipToNode.phone = bodyJson.shipToParty.address.phone;
		shipToNode.email = bodyJson.shipToParty.address.email;
		shipToNode.fax = bodyJson.shipToParty.address.fax;
		shipToNode.correspondenceLanguage = bodyJson.shipToParty.address.correspondenceLanguage;
		if (bodyJson.shipToParty.person != null) {
			//set person fields
			def shipToPersonNode = [:];
			shipToPersonNode.firstName = bodyJson.shipToParty.person.firstName; 
			shipToPersonNode.middleName = bodyJson.shipToParty.person.middleName;
			shipToPersonNode.lastName = bodyJson.shipToParty.person.lastName;
			shipToPersonNode.salutationCode = bodyJson.shipToParty.person.salutationCode;
			shipToNode.put("person", shipToPersonNode);
		} else {
			shipToNode.person = null;
		}
		bodyJson.customer.addresses.add(shipToNode);
	}

	message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(bodyJson)));
						
	return message;
}