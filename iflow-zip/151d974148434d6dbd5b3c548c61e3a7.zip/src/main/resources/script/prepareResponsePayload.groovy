import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.time.Instant;
import org.apache.camel.converter.stream.ByteArrayInputStreamCache;
import groovy.json.JsonSlurperClassic;

def Message processData(Message message) {
    
    def body = message.getBody(String.class);
    def parsedObj = new JsonSlurper().parseText(body);
    
    def finalBody = new JsonSlurper().parseText('{}');
    def answer = new JsonSlurper().parseText('{}');
    def answers = [];
    
    finalBody<<["externalObjectId": message.getProperty("ResponseID").toString()];
    
    finalBody<<["respondedOn": parsedObj.result.values.recordedDate];
    finalBody<<["contextId": parsedObj.result.values.contextId];
    
    def feedbackDefPayload = message.getProperty("FeedbackDefPayload");
    def jsonText = feedbackDefPayload.getText('UTF-8');
    def parsedPayload = new JsonSlurper().parseText(jsonText);
    
    finalBody<<["definitionId": parsedPayload.value[0].id];
    
    def questionId = parsedPayload.value[0].questions[0].id;
    
    answer<<["questionId": questionId];
    if(parsedObj.result.values.containsKey(questionId)){
        answer<<["score": parsedObj.result.values[questionId]];
    }else{
        answer<<["score": parsedPayload.value[0].questions[0].minScore];
    }
    
    answers << answer;

    finalBody<<["answers": answers];
    
    JsonBuilder builder = new JsonBuilder(finalBody);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
    
    message.setBody(jsonBody);
    return message;

}