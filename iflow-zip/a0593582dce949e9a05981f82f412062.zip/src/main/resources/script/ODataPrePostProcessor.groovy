import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;
import org.apache.olingo.odata2.api.uri.UriInfo;
import org.apache.olingo.odata2.api.edm.EdmLiteral;
import org.apache.olingo.odata2.api.edm.EdmTyped;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.uri.expression.FilterExpression;
import org.apache.olingo.odata2.api.uri.expression.LiteralExpression;
import org.apache.olingo.odata2.api.uri.expression.MemberExpression;
import org.apache.olingo.odata2.api.uri.expression.MethodExpression;
import org.apache.olingo.odata2.api.uri.expression.MethodOperator;
import org.apache.olingo.odata2.api.uri.expression.OrderByExpression;
import org.apache.olingo.odata2.api.uri.expression.OrderExpression;
import org.apache.olingo.odata2.api.uri.expression.PropertyExpression;
import org.apache.olingo.odata2.api.uri.expression.SortOrder;
import org.apache.olingo.odata2.api.uri.expression.UnaryExpression;
import org.apache.olingo.odata2.api.uri.expression.UnaryOperator;
import org.apache.olingo.odata2.api.uri.expression.BinaryExpression;
import org.apache.olingo.odata2.api.uri.expression.BinaryOperator;
import org.apache.olingo.odata2.api.uri.expression.ExpressionVisitor;

@Field static final String HEADER_ODATA_METHOD = "ODataMethod";
@Field static final String HEADER_ODATA_FILTER_Supported_Languages = "SAP_DMCSupportedLanguages";
@Field static final String HEADER_URI_INFO = "UriInfo";
@Field static final String HEADER_CUSTOM_ROOT_NAME = "CustomRootName";
@Field static final String HEADER_ETAG = "etag";
@Field static final String ODATA_METHOD_QUERY = "GET_FEED";
@Field static final String ODATA_METHOD_CREATE = "CREATE_ENTRY";
@Field static final String ODATA_METHOD_READ = "GET_ENTRY";
@Field static final String ODATA_METHOD_UPDATE = "UPDATE_ENTRY";
@Field static final String ODATA_METHOD_DELETE = "DELETE_ENTRY";
@Field static final String ODATA_METHOD_FUNCTION = "FUNCTION_IMPORT";

Message odataPreProcessor(Message message) {
	
	String odataMethod = message.getHeaders().get(HEADER_ODATA_METHOD);	
	UriInfo uriInfo = message.getHeaders().get(HEADER_URI_INFO);

	EdmEntitySet startEntitySet = uriInfo.getStartEntitySet();
	String startEntitySetName = startEntitySet.getName();
	String startEntitySetType = startEntitySet.getEntityType().getName();

	if (odataMethod.equals(ODATA_METHOD_QUERY)) {	//Query operation
		FilterExpression filter = uriInfo.getFilter();
		HashMap<String, String> filterValueMap = null;
		if (filter) {
			QueryExpressionVisitor expVisitor = new QueryExpressionVisitor();
			filter.accept(expVisitor);
			filterValueMap = expVisitor.getFilterValueMap();
			if (uriInfo.getExpand() != null && filterValueMap.containsKey("Batch") && filterValueMap.get("Batch") != null && filterValueMap.containsKey("Material") && filterValueMap.get("Material") != null) {
				message.setHeader(HEADER_CUSTOM_ROOT_NAME, "${startEntitySetName}_${odataMethod}_V2");
			}
		}
	}
	return message;
}

class QueryExpressionVisitor implements ExpressionVisitor {
	
		private HashMap<String, String> filterValueMap = new HashMap<String, String>();
		private boolean operator_or_found=false;
		
		public boolean isOperator_or_found(){
			return operator_or_found;
		}
		public HashMap<String, String> getFilterValueMap(){
			return filterValueMap;
		}
		
		@Override
		public Object visitProperty(PropertyExpression propertyExpression, String uriLiteral, EdmTyped edmProperty) {
			return edmProperty;
		}
		
		@Override
		public Object visitLiteral(LiteralExpression literal, EdmLiteral edmLiteral) {
			return edmLiteral;
		}
		
		@Override
		public Object visitBinary(BinaryExpression binaryExpression, BinaryOperator operator, Object leftSide, Object rightSide) {
			
			if (operator.equals(BinaryOperator.EQ)) {
				if (leftSide instanceof EdmTyped && rightSide instanceof EdmLiteral) {
					EdmTyped property = leftSide;
					EdmLiteral literal = rightSide;
					if(null == filterValueMap.get(property.getName()))
					{
						filterValueMap.put(property.getName(), literal.getLiteral());
					}else{
						filterValueMap.put(property.getName(), filterValueMap.get(property.getName()) + "," +literal.getLiteral());
						operator_or_found = true;
					}
				}
			}
			
			return binaryExpression;
		}
	
		@Override
		public Object visitFilterExpression(FilterExpression filterExpression, String expressionString, Object expression) {
			return filterExpression;
		}
	
		@Override
		public Object visitMember(MemberExpression memberExpression, Object path, Object property) {
			return memberExpression;
		}
	
		@Override
		public Object visitMethod(MethodExpression methodExpression, MethodOperator method, List<Object> parameters) {
			return methodExpression;
		}
	
		@Override
		public Object visitOrder(OrderExpression arg0, Object arg1, SortOrder arg2) {
			return OrderExpression;
		}
	
		@Override
		public Object visitOrderByExpression(OrderByExpression orderByExpression, String expressionString, List<Object> orders) {
			return OrderByExpression;
		}
	
		@Override
		public Object visitUnary(UnaryExpression unaryExpression, UnaryOperator operator, Object operand) {
			return UnaryExpression;
		}
	}
