import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {

	def body = message.getBody(String.class);
	def data = new JsonSlurper().parseText(body) 
	def columns = data.row*.keySet().flatten().unique()

	// Wrap strings in double quotes, and remove nulls
	def encode = { e -> e == null ? '' : e instanceof String ? /"$e"/ : "$e" }
	
	// Add all the column names
	String payload = columns.collect { c -> encode( c ) }.join( ',' )
	payload = payload.concat('\n')
	// Add all the rows
	data.row.collect { row ->
		payload = payload.concat(columns.collect { colName -> encode( row[ colName ] ) }.join( ',' ))
		payload = payload.concat('\n')
	}.join( '\n' )
    def tempPayload=payload;
	///Logic for identifying failed records

    List<String> inputlist = new ArrayList<String>();
	List<String> outputlist = new ArrayList<String>();
	def tempstr;
	
	def map = message.getHeaders();
    map = message.getProperties();
    message.setProperty("O_ArrayData", outputlist);

	inputlist = message.getProperty("P_ArrayData");
	
	payload = payload.replace("SNo","Record No.");
	payload = payload.replace("message","Error Message");
	
	payload.eachLine {String line ->
		outputlist.add(line);
		if(tempstr == null) {
			tempstr = line;
			tempstr = tempstr.concat('\n');
		}
	}
	
	for (i = 1; i <outputlist.size(); i++) {
        
		def temp_olist = outputlist[i].replaceAll (/"/, '')    
    
		for (j = 1; j <inputlist.size(); j++) {

			if(temp_olist.contains(inputlist[j])) {
			
				def a = outputlist[i].indexOf('"')
				def b = outputlist[i].indexOf(',')
				
				tempstr = tempstr + outputlist[i].substring(0,a+1) + (j) + outputlist[i].substring(b-1)+"\n";
				//outputlist[i] = tempstr;
				
			}
		}        
    }
	tempstr.replaceAll("SNo","Record No.");
	tempstr.replaceAll("message","Error Message");
	
	//message.setProperty("O_ArrayData2", payload);
	//////////////////////////////////
	
	message.setBody(tempPayload);//payload)
		
	return message;
}
