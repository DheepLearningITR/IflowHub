import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {

	def body = message.getBody(String.class);
	def output;
	message.setProperty("isError", "true");
     
	//Setting the timestamp
	def now = new Date();
	message.setProperty("timestamp", now.format("yyyyMMddHHmmss", TimeZone.getTimeZone('UTC')));
	
	//parsing error message
	output = getErrorResponse(body); 
	if(!body.contains('error')) {
		message.setProperty("isError", "false");
	}
	message.setBody(output);
    
	return message;
}

def String getErrorResponse(String response) {

    def jsonSlurper = new JsonSlurper()
	def sb = new StringBuilder("{\"row\":[");
	def errMsg, errObj, data, records,dtls;
    int seqNumber = 1;

	response.split("HTTP/1.1").each { unit ->
	if(!"$unit".contains("201 Created") && !"$unit".startsWith("--changeset")) {
				errMsg = "$unit".substring("$unit".indexOf("{\"error\""), "$unit".indexOf("--changeset")).trim()
                errObj = jsonSlurper.parseText(errMsg)
                data = jsonSlurper.parseText(errObj.error.details.message[0])
                sb.append("{\"SNo\": \""+ seqNumber +"\",");
				sb.append("\"Status\": \"Error\",");
				sb.append("\"message\": \""+ errObj.error.message +"\",");
				sb.append("\"Material Code\": \""+ data.materialCode +"\",");
				sb.append("\"Serial Number\": \""+ data.serialNumber +"\",");
				sb.append("\"Equipment Number\": \""+ data.equipmentNumber +"\",");
				sb.append("\"Asset Number\": \""+ data.assetNumber +"\",");
				sb.append("\"Status ID\": \""+ data.status_ID +"\",");
				sb.append("\"OwnershipType ID\": \""+ data.ownershipType_ID +"\",");
				sb.append("\"Ownership Code\": \""+ data.ownershipCode +"\",");
				sb.append("\"IMEI Number\": \""+ data.imeiNumber +"\",");
				sb.append("\"Barcode\": \""+ data.barcode +"\",");
				sb.append("\"rfid\": \""+ data.rfid +"\",");
				sb.append("\"color\": \""+ data.color +"\"");
                    
                
				
				sb.append("},");
				seqNumber=seqNumber+1; 				
		}        
	}
	
	records = sb.toString();
	records = records.substring(0, records.length()-1)+"]}";
	return records;
}