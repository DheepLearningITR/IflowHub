import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    final Long ONE_HOUR = 60 * 60 * 1000 // milliseconds in an hour
  
    def properties = message.getProperties();
    
    def last_hours = properties.get('Event_List_Last_Hours') as Integer;
    
    def today = new Date();

    def createdFrom = new Date(today.toInstant().toEpochMilli() - ONE_HOUR*last_hours);
    
    def createdTo = today.next();
    
    allFilters = String.format("{\"updatedDateFrom\":\"%s\", \"updatedDateTo\":\"%s\"}", 
                            createdFrom.format("yyyy-MM-dd'T'HH:mm:ss'Z'"), createdTo.format("yyyy-MM-dd'T'HH:mm:ss'Z'"));
    message.setProperty('filters', URLEncoder.encode(allFilters, 'UTF-8'));
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('ExecutionLog', 'Filters: ' + allFilters + '. ', 'text/plain');
    
    message.setProperty("executionLog", 'Date filters: ' + allFilters + '. ');
    message.setProperty("updatedCount", 0);
    
    //Call the API the 1st time and assing the token = 1
    message.setProperty("hasPageToken", '1');
    message.setProperty("firstExecution", 1);
    message.setProperty("countApiCalls", 0);
        
    return message;
  
}