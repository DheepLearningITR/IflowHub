import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();

    def properties = message.getProperties();
    def countApiCalls = properties.get("countApiCalls");
    
    def executionLog = properties.get('executionLog');
    
    executionLog = executionLog + 'OR API calls: ' + countApiCalls + '. ';
    
    def valueUpdatedCount = properties.get("updatedCount");
    executionLog = executionLog + 'Updated events: ' + valueUpdatedCount + '. ';
    
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString('ExecutionLog', executionLog, 'text/plain');

    return message;
}