import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody();
    
    def headers = message.getHeaders();

    def properties = message.getProperties();
    
    def jsonSlurper = new JsonSlurper();
    def dbResult = jsonSlurper.parse(body);
    def eventId = '';
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('Result SQL SELECT', dbResult.toString(), 'text/plain');
    
    def hasEvents = '0';
    
    if (dbResult && dbResult.SelectStatement_response && 
            dbResult.SelectStatement_response.row && dbResult.SelectStatement_response.row.size() > 0) {
        hasEvents = '1';
        
        eventId = dbResult.SelectStatement_response.row[0].INTERNAL_ID;
    }
    
    message.setProperty("hasEvents", hasEvents);
    message.setProperty("eventId",  eventId);
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('resultRows-'+eventId, dbResult.toString(), 'text/plain');

    return message;
}