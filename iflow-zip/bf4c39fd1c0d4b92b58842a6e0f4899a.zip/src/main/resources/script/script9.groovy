import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def jsonSlurper = new JsonSlurper();
    def apiResult = jsonSlurper.parse(body);
    
    def properties = message.getProperties();
    
     // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    
    def projectId = properties.get("projectId");
    def userList = properties.get("userList");
    
    //get db schema
    def db_schema = properties.get('Database_Schema_Name');
    
    def hasUserTeamsToInsert = '0';
    
    if (apiResult.payload && apiResult.payload.users && apiResult.payload.users.size() > 0) {
       
        
        sqlStatement.root {
            for (user in apiResult.payload.users) {
                if (!userList.contains(user.uniqueName)) {
                     //hasResultsToInsert
                     hasUserTeamsToInsert = '1';
        
                    sqlStatement.InsertStatement {
                         sqlStatement.app_sourcing_project_users(action: 'INSERT') {
                            sqlStatement.table(db_schema + '.APP_SOURCING_PROJECT_USERS')
                            sqlStatement.access {
                                sqlStatement.PROJECT_ID(projectId)
                                sqlStatement.TEAM_ID(apiResult.payload.id)
                                sqlStatement.TEAM_NAME(apiResult.payload.name)
                                sqlStatement.UNIQUE_NAME(user.uniqueName)
                                sqlStatement.NAME(user.name)
                                sqlStatement.EMAIL(user.emailAddress)
                            }
                        }
                    }
                }
                
            }
        }
    }
    
     //hasResultsToInsert
     message.setProperty("hasUserTeamsToInsert", hasUserTeamsToInsert);
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('resultRows-'+projectId, apiResult.toString(), 'text/plain');
    
     //set body
    message.setBody(writer.toString());
    
    return message;
}