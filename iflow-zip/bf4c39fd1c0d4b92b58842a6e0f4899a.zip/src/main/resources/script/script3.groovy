import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

    def properties = message.getProperties();
    
    def dateFilters = properties.get("dateFilters");
    def pageToken = properties.get("pageToken");
    
    def firstExecution = properties.get("firstExecution");
    if (firstExecution == 1) {
        pageToken = '';
        message.setProperty("pageToken", pageToken);
        message.setProperty("firstExecution", 0);
    }
    
    //countApiCalls
    def countApiCalls = properties.get("countApiCalls");
    countApiCalls = countApiCalls + 1;
     message.setProperty("countApiCalls", countApiCalls);
        
    return message;
  
}