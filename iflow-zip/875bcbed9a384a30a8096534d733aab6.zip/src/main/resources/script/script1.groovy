import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def json = message.getBody(java.io.Reader)
    def data = new JsonSlurper().parse(json)
    
    //Define Identifiers To Search In Message Processing Logs
    message.setHeader("SAP_ApplicationID", data.messageHeader.id)
    
    return message

}


def Message setIdocMonitoringIdentifier(Message message){

def messageLog = messageLogFactory.getMessageLog(message)
	if(messageLog != null){

		def idocNo = message.getHeaders().get("SapIDocDbId");		
		if(idocNo!=null){
			messageLog.addCustomHeaderProperty("IDoc Number", idocNo)		
        }
	}
	return message
}