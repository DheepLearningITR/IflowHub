import com.sap.it.api.mapping.*;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String getPRRefId(String prop_name,MappingContext context){
    
    def prRefIdValue1="To Be Updated Via CF Update Integration";
    def prRefIdValue2="To Be Updated via Integration";
    def prop = context.getProperty(prop_name);
    if(prop==null){
       prop="";
    }
    else if(prop.equalsIgnoreCase(prRefIdValue1) || prop.equalsIgnoreCase(prRefIdValue2)){
        prop="";
    }
    return prop;
    }