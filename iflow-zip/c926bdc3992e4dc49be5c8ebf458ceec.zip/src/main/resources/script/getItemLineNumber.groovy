import com.sap.it.api.mapping.*;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String customFunc(String prop_name_prRefId,String prop_name_lineItemNumber,MappingContext context){
    
    def prRefIdValue1="To Be Updated Via CF Update Integration";
    def prRefIdValue2="To Be Updated via Integration";
    def prop_prRefId = context.getProperty(prop_name_prRefId);
    def prop_lineItemNumber = context.getProperty(prop_name_lineItemNumber);
    if(prop_prRefId==null){
        prop_lineItemNumber="";
    }
    else if(prop_prRefId.equalsIgnoreCase(prRefIdValue1) || prop_prRefId.equalsIgnoreCase(prRefIdValue2)){
        prop_lineItemNumber="";
    }
    return prop_lineItemNumber;
    }