import com.sap.it.api.mapping.*;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String getShortDescription(String prop_name,String pattern,String replacementString,int len,MappingContext context){

	def prop = prop_name;
	if(prop!=null || prop!=""){
	    prop=prop.replace(pattern,replacementString);
	    if(prop.length()>len){
	        prop=prop.substring(0,len);
	        prop=prop.trim();
	    }
	}
    return prop;
    }