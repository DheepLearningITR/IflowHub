import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.CompileStatic
import groovy.transform.Field

@Field public static final String RELATION_TASK = 'Task'
@Field public static final String RELATION_BPMN = 'BPMNDiagram'

def Message processData(Message message) {
    def risks = message.getProperty('grcRisks')
    def index = Integer.valueOf(message.getProperty('index'))

    def body = message.getBody(java.io.Reader)
    def links = new JsonSlurper().parse(body)
    def currentRisk = risks[index]

    if (!(links instanceof ArrayList) && links.errors) {
        def nonExistRiskMap = message.getProperty('nonExistRiskMap')
        nonExistRiskMap.put(currentRisk.riskId, currentRisk.signavioRiskId)
    } else {
        def relatedItemIds = []
        links.stream().filter { link -> link.rep.stencilId == RELATION_TASK || link.rep.stencilId == RELATION_BPMN }.forEach { link -> setRiskAssignment(currentRisk, link, relatedItemIds) }
    }
    message.setProperty('index', ++index)
    return message
}

def void setRiskAssignment(risk, link, relatedItemIds) {
    def sriStrings = link.rep.sri.split("/")
    def modelId = sriStrings[sriStrings.length - 1]
    switch (link.rep.stencilId) {
        case RELATION_BPMN:
            if(!(relatedItemIds.contains(RELATION_BPMN + modelId))){
                def process = new AssignedProcess(modelId, link.rep.name)
                risk.signavioProcesses.add(process)
                relatedItemIds.add(RELATION_BPMN + modelId)
            }
            break
        case RELATION_TASK:
            if(!(relatedItemIds.contains(RELATION_TASK + modelId + link.rep.elementId))){
                def process = new AssignedProcess(modelId, link.rep.elementId, link.rep.element)
                risk.signavioProcesses.add(process)
                relatedItemIds.add(RELATION_TASK + modelId + link.rep.elementId)
            }
            break
        default:
            break
    }
}

@CompileStatic
class AssignedProcess {
    String processId
    String signavioProcessId
    String signavioActivityId
    String name

    AssignedProcess(String signavioProcessId, String name) {
        this.signavioProcessId = signavioProcessId
        this.name = name
    }

    AssignedProcess(String signavioProcessId, String signavioActivityId, String name) {
        this.signavioProcessId = signavioProcessId
        this.signavioActivityId = signavioActivityId
        this.name = name
    }
}

