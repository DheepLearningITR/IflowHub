import com.sap.gateway.ip.core.customdev.util.Message
import groovy.transform.CompileStatic
import groovy.transform.Field

@Field public static final String BPMN_URL_FORMAT = "%s/p/hub/model/%s"
@Field public static final String TASK_URL_FORMAT = "%s/p/hub/model/%s/elements/%s"

def Message processData(message) {
    def risks = message.getProperty('grcRisks')
    def processMappingMap = message.getProperty('processMappingMap')

    setGrcProcessIds(risks, processMappingMap)
    def signavioHost = message.getProperty('signavioHost')
    def grcRiskProcessAssignments = convertToGrcRiskProcessAssignments(risks, signavioHost)

    message.setProperty('grcRiskProcessAssignments', grcRiskProcessAssignments)
    message.setProperty('index', 0)

    def nonExistRiskMap = message.getProperty('nonExistRiskMap')
    if (nonExistRiskMap.size() > 0){
        def messageLog = messageLogFactory.getMessageLog(message)
        messageLog.addAttachmentAsString("Not Exist RAM-Signavio Risk Ids  in Signavio", "Not Exist RAM-Signavio Risk Ids  in Signavio: " + nonExistRiskMap, "text/plain")
    }

    return message
}

def List convertToGrcRiskProcessAssignments(risks, signavioHost) {
    List<GrcRiskProcessAssignment> grcRiskProcessAssignments = []
    for (def risk : risks) {
        def riskProcessAssignment = new GrcRiskProcessAssignment(risk.riskId)
        def assignedProcesses = riskProcessAssignment.signavioProcessLinks
        for (def process : risk.signavioProcesses) {
            if (process.signavioActivityId) {
                assignedProcesses.add(new SignavioProcessLink(process.processId, process.name, String.format(TASK_URL_FORMAT, signavioHost, process.signavioProcessId, process.signavioActivityId), process.signavioProcessId + "/" + process.signavioActivityId))
            } else {
                assignedProcesses.add(new SignavioProcessLink(process.processId, process.name, String.format(BPMN_URL_FORMAT, signavioHost, process.signavioProcessId), process.signavioProcessId))
            }
        }
        grcRiskProcessAssignments.add(riskProcessAssignment)
    }
    return grcRiskProcessAssignments
}

def void setGrcProcessIds(risks, processMappingMap) {
    for (def risk : risks) {
        for (def process : risk.signavioProcesses) {
            if (processMappingMap.containsKey(process.signavioProcessId)) {
                def processMapping = processMappingMap.get(process.signavioProcessId)
                if (process.signavioActivityId) {
                    def activityMapping = processMapping.activityMappingMap
                    process.processId = activityMapping.get(process.signavioActivityId).grcActivityId
                } else {
                    process.processId = processMapping.grcProcessId
                }
            }
        }
    }
}

@CompileStatic
class GrcRiskProcessAssignment {
    String riskId
    List signavioProcessLinks

    GrcRiskProcessAssignment(String riskId) {
        this.riskId = riskId
        this.signavioProcessLinks = []
    }
}

@CompileStatic
class SignavioProcessLink {
    String processId
    String label
    String url
    String externalId

    SignavioProcessLink(String processId, String label, String url, String externalId) {
        this.processId = processId
        this.label = label
        this.url = url
        this.externalId = externalId
    }
}