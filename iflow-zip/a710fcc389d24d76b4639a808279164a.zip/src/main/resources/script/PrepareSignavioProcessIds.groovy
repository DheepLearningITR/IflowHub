import com.sap.gateway.ip.core.customdev.util.Message
import groovy.transform.CompileStatic

def Message processData(Message message) {
    def risks = message.getProperty('grcRisks')
    Map<String, ProcessMapping> processMappingMap = [:]

    risks.each { it.signavioProcesses.each { process -> addProcessIdToProcessMappingMap(processMappingMap, process) } }
    
    def modelIds = new ArrayList<>(processMappingMap.keySet())
    message.setProperty('modelIds', modelIds)
    message.setProperty('processMappingMap', processMappingMap)
    message.setProperty('index', 0)

    return message
}

def void addProcessIdToProcessMappingMap(processMappingMap, process) {
    processMappingMap.putIfAbsent(process.signavioProcessId, new ProcessMapping(process.signavioProcessId))
    ProcessMapping currentMap = processMappingMap.get(process.signavioProcessId)
    if (process.signavioActivityId) {
        currentMap.activityMappingMap.putIfAbsent(process.signavioActivityId, new ActivityMapping(process.signavioActivityId))
    }
}

@CompileStatic
class ProcessMapping {
    String signavioId
    String grcProcessId
    Map<String, ActivityMapping> activityMappingMap

    ProcessMapping(String signavioId) {
        this.signavioId = signavioId
        this.activityMappingMap = [:]
    }
}

@CompileStatic
class ActivityMapping {
    String signavioId
    String grcActivityId

    ActivityMapping(String signavioId) {
        this.signavioId = signavioId
    }
}