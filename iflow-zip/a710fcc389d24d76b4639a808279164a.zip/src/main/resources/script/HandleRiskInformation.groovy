import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.CompileStatic
import groovy.transform.Field

@Field public static final String STATUS_RETIRED = 50

def Message processData(Message message) {
    def grcRisks = message.getProperty("grcRisks")
    def skip = message.getProperty("skip")
    def top = message.getProperty("top")

    def body = message.getBody(java.io.Reader)
    def jsonBody = new JsonSlurper().parse(body)
    List riskList = jsonBody.value

    riskList.stream().filter{risk -> risk.externalId != null && risk.externalId.length() > 0 && risk.status.code != STATUS_RETIRED}.forEach{ risk -> grcRisks.add(new GrcRisk(risk.id, risk.externalId))}

    message.setProperty("skip", Integer.valueOf(skip) + Integer.valueOf(top))

    return message
}

@CompileStatic
class GrcRisk {
    String riskId
    String signavioRiskId
    List signavioProcesses

    GrcRisk(String riskId, String signavioRiskId) {
        this.riskId = riskId
        this.signavioRiskId = signavioRiskId
        signavioProcesses = []
    }
}
