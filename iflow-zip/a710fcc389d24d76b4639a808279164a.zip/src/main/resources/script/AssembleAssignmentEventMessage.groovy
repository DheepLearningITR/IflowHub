import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.transform.CompileStatic
import groovy.transform.Field
import java.text.SimpleDateFormat

@Field public static final String GRC_DATE_FORMATTER = "yyyy-MM-dd'T'HH:mm:ss'Z'"
@Field public static final String RISK_PROCESS_ASSIGNMENT_MESSAGE_TYPE = 'sap.grc.risk.ComplianceRisk.UpdateSignavioProcessLinks'
@Field public static final String RISK_PROCESS_ASSIGNMENT_MESSAGE_VERSION = 'v1'
@Field public static final String TYPE_FORMAT = '%s.%s'
@Field public static final String TOPIC_FORMAT = 'topic:%s/ce/%s'
@Field public static final String SEPERATOR = '/'

def Message processData(Message message) {
    def emNamespace = message.getProperty('emNamespace')
    def sapMplCorrelationId = message.getHeader('SAP_MplCorrelationId', String.class)
    def riskProcessAssignments = message.getProperty('grcRiskProcessAssignments')
    def index = Integer.valueOf(message.getProperty('index'))
    def currentRisk = riskProcessAssignments.get(index)

    def body = new EventMessageBody(currentRisk)
    body.time = new SimpleDateFormat(GRC_DATE_FORMATTER).format(new Date())
    body.source = SEPERATOR + emNamespace
    body.type = String.format(TYPE_FORMAT, RISK_PROCESS_ASSIGNMENT_MESSAGE_TYPE, RISK_PROCESS_ASSIGNMENT_MESSAGE_VERSION)
    body.xsapcorrelationid = sapMplCorrelationId
    body.subject += currentRisk.riskId

    def payload = [:]
    payload.body = JsonOutput.toJson(body)
    payload.topic = String.format(TOPIC_FORMAT, emNamespace, body.type.replace('.', SEPERATOR))
    message.setBody(JsonOutput.toJson(payload))
    message.setProperty('index', ++index)

    return message
}

@CompileStatic
class EventMessageBody {
    String xsapcorrelationid
    String id
    String specversion = '1.0'
    String datacontenttype = 'application/json'
    String time
    String type
    String source
    Object data
    String subject ='ComplianceRisk:'

    EventMessageBody(data) {
        this.id = UUID.randomUUID().toString()
        this.data = data
    }
}
