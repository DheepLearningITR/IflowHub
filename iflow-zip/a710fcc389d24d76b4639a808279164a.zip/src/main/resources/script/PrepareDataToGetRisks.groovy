import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def grcRisks = []
    message.setProperty('grcRisks', grcRisks)
    def nonExistRiskMap = [:]
    message.setProperty('nonExistRiskMap', nonExistRiskMap)
    
    return message
}