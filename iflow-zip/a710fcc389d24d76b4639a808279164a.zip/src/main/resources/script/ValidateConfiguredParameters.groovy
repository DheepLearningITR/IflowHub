import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def properties = message.getProperties()

    if (!properties.get('emNamespace')) {
        throw new Exception("'Event Mesh Namespace' is not configured.")
    }

    return message
}