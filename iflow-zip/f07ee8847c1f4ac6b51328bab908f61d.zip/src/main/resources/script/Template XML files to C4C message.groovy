import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.*

@Field def NodeTypeMap, root

def Message processData(Message message) {
    
    def Hazard_Val_Map = ['DANGER':'1','WARNING':'2','CAUTION':'3','':""]
    NodeTypeMap = ['chapter':1,'table':2,'series':3,'textinput':4,'label':5,'dropdown':6,'signature':7,'numberinput':8,
	    'dateinput':9,'attachment':10,'attachmentPicker':11,'calculation':12,'boolinput':13,'objectPicker':14,
	    'stateElement':15,'pageBreak':15,'dropdownoption':18,'header':19,'footer':20]
	    
    root = new XmlParser().parseText(message.getBody(String.class));
        
    def root_output = new NodeBuilder()."n0:ChecklistTemplateReplicationRequest"('xmlns:n0': 'http://sap.com/xi/SAPGlobal20/Global'){
        	MessageHeader{
        	    ID(root.fsm_header."x-request-id".text().toUpperCase())
        		UUID(root.fsm_header."x-message-id".text())
        		CreationDateTime(root.fsm_body.eventTime.text())
        		SenderParty{
        			InternalID(schemeID:'CommunicationSystemID',schemeAgencyID:'310',root.fsm_header."x-company-id".text())
        		}
        		RecipientParty{
        			InternalID(schemeID:'CommunicationSystemID',schemeAgencyID:'310',root.fsm_header.C4C_tenant_ID.text())
        		}
        		BusinessScope{
        			TypeCode(listID:'25201',listAgencyID:'310',"3")
        			ID(schemeID:'10555',schemeAgencyID:'310',"106")
        		}
        	}
        	ChecklistTemplateReplicationRequest{
        		BasicMessageHeader{
        			UUID(root.fsm_body.eventID.text())
        		}
        		ChecklistTemplate(ActionCode:'04'){
        			ExternalID(root.fsm_body.data.checklistTemplate.id.text())
        			ID(root.fsm_body.data.checklistTemplate.externalId.text())
        			VersionID(root.fsm_body.data.checklistTemplate.version.text())
        			Status(root.fsm_body.eventType.text().contentEquals('checklisttemplate.activated') ? '02' : '01')
        			DefaultLanguage(root.fsm_body.data.checklistTemplate.defaultLanguage.text().toUpperCase())
        			Hazard(Hazard_Val_Map[root.fsm_body.data.checklistTemplate.hazardType.text()])
        			Name(root.fsm_body.data.checklistTemplate.name.text())
        			Description(ActionCode:'04'){
        				Description(languageCode:root.fsm_body.data.checklistTemplate.defaultLanguage.text().toUpperCase(),
        				trimText(root.fsm_body.data.checklistTemplate.description.text()))
        			}
        		}
        	}
        }

        if(root.fsm_body.eventType.text().contentEquals('checklisttemplate.activated')){
        	
        	//Loop over all the Chapters
        	root.fsm_body.data.checklistTemplate.Content_XML.checklistTemplate.chapters.chapter.each{
        		// Main chapters will not have any parent chapter
        		forChapterNode(root_output.ChecklistTemplateReplicationRequest.ChecklistTemplate[0], it, "")
        	}	
        }
        
        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(root_output)
        message.setBody(stringWriter.toString())
        return message;
}

//Methods...
private createPositionNode(Node Output_Parent_node, Node current, Integer value_type, String ParentChapterID, String ParentTableID, String ParentSeriesID){
	/* Output_Parent_node -> node of the output XML under which the subsequent nodes has to be created, 
	 current -> Current node in loop, value_type -> C4C value map of the FSM checklist elements,
	 And Parent IDs of the current node*/

	def pos_node = new NodeBuilder().Position(ActionCode:'04'){
		ElementID(current.@elementID)
		ChapterElementID(ParentChapterID)
		SeriesElementID(ParentSeriesID)
		ValueType(value_type)
		TableElementID(ParentTableID)
		ObjectType(current?.@objectType ? current?.@objectType : "")
	}

	def Descriptions = getDesciptions(current, value_type)
	// On each node in the List returned by children(), perform collect where each node is appended to the main Position node.
	Descriptions.children().collect{pos_node.append(it)}

	if (value_type == 6){  //dropdown
		def idx = 0
		current.'*'.each{
			def element_id = it.@elementID
			def dropdown = new NodeBuilder().DropDown(ActionCode:'04'){
				ElementID(element_id)
				IndexPosition(idx)
			}
			Descriptions = getDesciptions(it, 18)
			Descriptions.children().collect{dropdown.append(it)}
			pos_node.append(dropdown)
			idx = idx + 1
		}
	}

	if (value_type == 2){  //table
		def idx = 0
		current.headers[0].header.each{
			if(current.columnTypes[0].'*'[idx].name() in ['textinput', 'label', 'dropdown', 'numberinput', 'dateinput', 'calculation', 'boolinput', 'objectPicker']){
				obj_elem_id = it.@elementID
				def table_element_node = new NodeBuilder().TableElement(ActionCode:'04'){
					ElementID(obj_elem_id)
					BodyElementID(current.headers[0].@elementID)
					Type(1) //Header type
					PositionElementID(current.columnTypes[0].'*'[idx].@elementID)
				}

				Descriptions = getDesciptions(it, 19)
				Descriptions.children().collect{table_element_node.append(it)}
				pos_node.append(table_element_node)
			}
			idx = idx + 1
		}

		idx = 0
		current.footer[0].'*'.each{
			if(it.name() in ['textinput', 'label', 'dropdown', 'numberinput', 'dateinput', 'calculation', 'boolinput', 'objectPicker']){
				def table_element_node = new NodeBuilder().TableElement{
					BodyElementID(current.footer[0].@elementID)
					Type(2) //Footer type
					PositionElementID(current.footer[0].'*'[idx].@elementID)
				}

				pos_node.append(table_element_node)
			}
			idx = idx + 1
		}
	}

	Output_Parent_node.append(pos_node)
}

private forTableNode(Node Output_Parent_node, Node current, Integer value_type, String ParentChapterID, String ParentSeriesID){

	createPositionNode(Output_Parent_node,current,value_type,ParentChapterID,"",ParentSeriesID)
	
    current.columnTypes[0].each{
    		if(it.name() in ['textinput', 'label', 'dropdown', 'numberinput', 'dateinput', 'calculation', 'boolinput', 'objectPicker']){
    			createPositionNode(Output_Parent_node,it,NodeTypeMap[it.name()],ParentChapterID,current.@elementID,ParentSeriesID)
    		}
    	}
    
    current.footer[0].'*'.each{
    		if(it.name() in ['textinput', 'label', 'dropdown', 'numberinput', 'dateinput', 'calculation', 'boolinput', 'objectPicker']){
    			createPositionNode(Output_Parent_node,it,NodeTypeMap[it.name()],ParentChapterID,current.@elementID,ParentSeriesID)
    		}
    	}
}

private forChapterNode(Node Output_Parent_node, Node current, String ParentChapterID){
	//Create Chapter node for the this Chapter
	def chapter_node = new NodeBuilder().Chapter(ActionCode:'04'){
		ElementID(current.@elementID)
		ParentElementID(ParentChapterID)
	}
	def Descriptions = getDesciptions(current, 1)
	Descriptions.children().collect{chapter_node.append(it)}
	Output_Parent_node.append(chapter_node)
	//Get reference of the last Chapter node added
	def parent_node_4_next_call = Output_Parent_node.children().last()

	current.'*'.each{
		def node_name = it.name()
		if (node_name in ['textinput', 'label', 'dropdown', 'numberinput', 'dateinput', 'calculation', 'boolinput', 'objectPicker']){
			createPositionNode(parent_node_4_next_call, it, NodeTypeMap[node_name], current.@elementID, "", "")
		}
		else if(node_name == 'chapter'){
			//Another Chapter inside a Chapter, but output node is not created in that way
			forChapterNode(Output_Parent_node, it, current.@elementID)
		}
		else if(node_name == 'table'){
			forTableNode(parent_node_4_next_call, it, NodeTypeMap[node_name], current.@elementID, "")
		}
		else if(node_name == 'series'){
			forSeriesNode(parent_node_4_next_call, it, NodeTypeMap[node_name], current.@elementID)
		}
	}
}

private forSeriesNode(Node Output_Parent_node, Node current, Integer value_type, String ParentChapterID){
	//Series node can only occur inside a Chapter node
	createPositionNode(Output_Parent_node, current, value_type, ParentChapterID, "", "")

	current.'*'.each{
		def node_name = it.name()
		if (node_name in ['textinput', 'label', 'dropdown', 'numberinput', 'dateinput', 'calculation', 'boolinput', 'objectPicker']){
			createPositionNode(Output_Parent_node, it, NodeTypeMap[node_name], ParentChapterID, "", current.@elementID)
		}
		else if(node_name == 'table'){
			forTableNode(Output_Parent_node, it, NodeTypeMap[node_name], ParentChapterID, current.@elementID)
		}
	}
}

private getDesciptions(Node current, Integer value_type){

	Node Descriptions = new NodeBuilder().Descriptions{}
	String search_key,lang_code, desc_value

	if (value_type in [2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 19]){
		search_key= current.@elementID + '.title'
	}
	else if (value_type in [5, 18]){
		search_key= current.@elementID + '.value'
	}
	else if (value_type == 1){
		search_key= current.@elementID + '.name'
	}
	//Loop over translations node, find the key, read value and
	root.fsm_body.data.checklistTemplate.Content_XML.translations.each{
		lang_code = it.@language.toUpperCase()
		desc_value = it.'*'.find {desc -> desc.@key.endsWith(search_key)}?.text()
		if(desc_value != null){
		    desc_value = trimText(desc_value)
			Descriptions.append(new NodeBuilder().Description(ActionCode:'04'){
				Description(languageCode:lang_code,desc_value)
			})
		}
	}

	return Descriptions
}

private trimText(String value){
    
    return value?.trim()?.length()>255 ? value?.trim()?.substring(0,255) : value?.trim()
}