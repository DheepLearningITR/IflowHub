/*
Scripts' objective is to unzip the base64 encoded zipped data and take out the XML 
files' data and merge with the main XML data.
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.zip.ZipInputStream
import java.util.zip.ZipEntry
import groovy.xml.QName;
import groovy.xml.XmlUtil
def Message processData(Message message) {
    //Body 
    def fsm_body = message.getBody(String.class);
    def parsedObj = new XmlParser().parseText(fsm_body);
    def zip_content = parsedObj.fsm_body.data.checklistTemplate.content.text().toString();
    def pkgBytes = zip_content.decodeBase64();
    def content_string = readEntryFromZipAsString(pkgBytes);
    def parsed_content = new XmlParser().parseText(content_string);
    parsedObj.fsm_body.data.checklistTemplate[0].remove(parsedObj.fsm_body.data.checklistTemplate.content[0])
    parsedObj.fsm_body.data.checklistTemplate[0].children().add(parsed_content);
    message.setBody(XmlUtil.serialize(parsedObj));
    return message;
}

private readEntryFromZipAsString(byte[] content){
	StringBuilder s = new StringBuilder()
	byte[] buffer = new byte[1024]
	int read = 0
    ZipInputStream zi = null
    try {
        zi = new ZipInputStream(new ByteArrayInputStream(content))
        ZipEntry zipEntry = null
        while ((zipEntry = zi.getNextEntry()) != null) {
            if (zipEntry.name.startsWith('translations') || zipEntry.name == 'template.xml') {
            	while ((read = zi.read(buffer, 0, 1024)) >= 0) {
		        	s.append(new String(buffer, 0, read, "UTF-8"))
		    	}
            }
        }
    } finally {
        if (zi != null) {
            zi.close()
        }
    }
    
   String xml_string = s.toString().replaceAll('\\<\\?xml version=\\"1.0\\" encoding=\\"UTF-8\\" standalone=\\"no\\"\\?\\>','');
   xml_string = xml_string.replaceAll('\\<\\?xml version=\\"1.0\\" encoding=\\"utf-8\\" standalone=\\"no\\"\\?\\>','');
   return '<Content_XML>' + xml_string + '</Content_XML>'; //Clubbing nodes under single xml node
}