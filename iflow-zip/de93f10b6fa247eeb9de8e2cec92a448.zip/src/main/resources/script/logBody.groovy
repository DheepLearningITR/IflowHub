import com.sap.gateway.ip.core.customdev.util.Message;

def Message logBody(Message message) {
    // Get the messageLogFactory and write the input to an attachment if DetailedTraceLog is set

    if (message.getProperties().get("DetailedTraceLog") == "true") {
        def messageLog = messageLogFactory.getMessageLog(message);
        if (messageLog != null) {
            messageLog.addAttachmentAsString('inputBody', message.getBody(String), 'text/csv')
        }
    }

    return message;
}