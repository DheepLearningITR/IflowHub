import groovy.util.XmlSlurper
import groovy.xml.MarkupBuilder
import com.sap.gateway.ip.core.customdev.util.Message
import java.io.StringWriter
import groovy.json.JsonOutput

def Message transform(Message message) {
    // Get the message body as a string
    def xml = message.getBody().toString()

    // Parse the XML
    def parsedXml = new XmlSlurper().parseText(xml)

    // Determine static info
    def status = determineStatus(parsedXml)
    def messages = collectMessages(parsedXml)
    def ERPDestination = message.getProperty('CurrentDestination') ?: ""
    def FetchPointer = message.getProperty('FetchPointer') ?: ""
    def MaxPackageSize = message.getProperty('MaxPackageSize') ?: ""
    def CorrelationID = message.getProperty('CorrelationID') ?: ""
    
    def fields = message.getProperty('Fields') ?: ""
    def fieldTypes = message.getProperty('FieldTypes') ?: ""
    def fieldLengths = message.getProperty('FieldLengths') ?: ""

    // Extract package ID (not used in output)
    def packageId = parsedXml.E_PACKAGE.text()


    // Convert the list of items to JSON
    def jsonOutput = transformXmltoJson(parsedXml,message)

    // Create the new XML structure using MarkupBuilder
    def writer = new StringWriter()
    writer << '<?xml version="1.0" encoding="utf-8"?>\n'
    def xmlBuilder = new MarkupBuilder(writer)
    def dataContent = (jsonOutput.ITEMS && jsonOutput.ITEMS.size() > 0) ? JsonOutput.toJson(jsonOutput) : null

    xmlBuilder.IBPRead(
            ERPDestination: ERPDestination,
            FetchPointer: FetchPointer,
            Status: status,
            PackageID: packageId,
            Fields : fields,
            FieldTypes : fieldTypes,
            FieldLengths : fieldLengths
    ) {
        if (dataContent) {
            Data(dataContent)
        } else {
            Data()
        }
        mkp.yieldUnescaped(messages) // Insert Messages as raw XML
    }

    // Set the new XML as the message body
    message.setBody(writer.toString())

    return message
}

// Function to determine status
def determineStatus(parsedXml) {
    if (parsedXml.ET_RETURN.item.TYPE.find { it.text() == 'A' }) {
        return 'Abort'
    } else if (parsedXml.ET_RETURN.item.TYPE.find { it.text() == 'E' }) {
        return 'Error'
    } else if (parsedXml.E_NO_MORE_DATA.text() == 'X') {
        return 'Finished'
    } else if (parsedXml.ET_RETURN.item.TYPE.find { it.text() == 'W' }) {
        return 'Warning'
    } else if (parsedXml.ET_DATA.text().isEmpty()) {
        return 'NoData'
    } else {
        return 'Fetch'
    }
}

// Function to collect messages
def collectMessages(parsedXml) {
    def messages = new StringWriter()
    def msgBuilder = new MarkupBuilder(messages)
    msgBuilder.Messages {
        parsedXml.ET_RETURN.item.each { msg ->
            Message(
                    Origin: 'RODPS_REPL_SOURCE_GET_DETAIL',
                    Type: typeToFullLength(msg.TYPE.text())
            ) {
                mkp.yield(msg.MESSAGE.text())
            }
        }
    }
    return messages 
}

// Function to map type to full length
def typeToFullLength(type) {
    switch (type) {
        case 'A':
            return 'Abort'
        case 'E':
            return 'Error'
        case 'W':
            return 'Warning'
        case 'I':
            return 'Information'
        default:
            return type
    }
}

def formatBasedOnDataType(data, fieldType) {
    switch (fieldType) {
        case 'NUMC':
            return Integer.parseInt(data)
        case 'DEC':
            return data.trim()
        case 'DATS':
            if(data == '00000000'){
                return ''
            }else{
                return data[0..3] + '-' + data[4..5] + '-' + data[6..7]
            }
        default:
            return data.trim()
    }
}

def stringToMap(inputString) {
    def resultMap = [:]
    def pairs = inputString.split(';')

    pairs.each { pair ->
        def keyValue = pair.split(':') 
        if (keyValue.size() == 2) {
            resultMap[keyValue[0].toString().trim()] = keyValue[1].toString().trim()
        }
    }

    return resultMap
}

def transformXmltoJson(rootNode, Message message) {

    def Fields = message.getProperty('Fields').split(';')
    def FieldTypes = stringToMap(message.getProperty('FieldTypes').toString())
    def FieldLengths = stringToMap(message.getProperty('FieldLengths').toString())

    def fieldOffsets = [:]
    def currentOffset = 1

    Fields.each { field ->
        fieldOffsets[field] = currentOffset
        currentOffset += FieldLengths[field].toInteger()
    }
    message.setProperty('fieldOffsets', fieldOffsets)
    def itemsList = []
    def tempDataList = []

    // Process each item
    rootNode.'**'.findAll { it.name() == 'item' }.each { item ->
        tempDataList << item
        if (item.CONTINUATION.text() == '') {
            def data = collectData(tempDataList)
            if (data) {
                def itemData = [:]

                Fields.each { field ->
                    def offset = fieldOffsets[field] as Integer
                    def length = FieldLengths[field] as Integer
                    def rawValue = data.substring(offset - 1, offset - 1 + length).trim()
                    itemData[field] = formatBasedOnDataType(rawValue, FieldTypes[field])
                }

                itemsList << itemData
            }
            tempDataList.clear()
        }
    }

    def result = [ITEMS: itemsList]

    return result
}

// Function to collect and merge data from items
def collectData(tempDataList) {
    def data = ''
    tempDataList.each { item ->
        data += new String(item.DATA.text().decodeBase64(), 'UTF-8')
    }
    return data
}
