import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    //This script is to check S4 status and set the activity ID
    def hdr = message.getHeaders()
    def S4response = hdr.get("sap-messages") as String;
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(S4response)

    def responseParts = jsonResult.findAll { it.code == "EAM_FSM_MORDER_REPL/049" }
    def PMOrderID, OperationID, ActivityExternalId
    if (responseParts){
        if (responseParts.message[0].contains("PMOrder:") && responseParts.message[0].contains("Operation:")){
            PMOrderID = responseParts.message[0].split(',')[0].split(':')[1]
            OperationID = responseParts.message[0].split(',')[1].split(':')[1]
            ActivityExternalId = PMOrderID + '/' + OperationID
            message.setProperty("PMOrderID",PMOrderID)
            message.setProperty("OperationID",OperationID)
        }
    }
    
    if (!PMOrderID && !OperationID){
        message.setProperty("S4error",S4response)
    }else{
        message.setProperty("PMOrderExternalId",PMOrderID)
        message.setProperty("ActivityExternalId",ActivityExternalId)
    }
 
    
// To access FSM, company and account are required -- either their name or their ID.
// If the IDs are configured, they are used; otherwise, the names are used.
    def accountCompanyUser = '';
    def headers = message.getHeaders();
    def accountID = headers.get("X-Account-ID") 
    accountID = accountID ? accountID : message.getProperty('X-Account-ID');
    def accountName = message.getProperty('X-Account-Name');
    def companyID = headers.get("X-Company-ID")
    companyID = companyID ? companyID : message.getProperty('X-Company-ID');
    def companyName = message.getProperty('X-Company-Name');
    def userName = message.getProperty('UserName');

    if (accountID == null || accountID == '' || accountID == '<FSM_Account_ID>' || companyID == null || companyID == '' || companyID == '<FSM_Company_ID>') {
        accountCompanyUser = '&account='+accountName+'&company='+companyName+'&user='+userName;
        message.setHeader('X-Account-Name', accountName);
        message.setHeader('X-Company-Name', companyName);
    } else {
        accountCompanyUser = '';
        message.setHeader('X-Account-ID', accountID);
        message.setHeader('X-Company-ID', companyID);
    }
    message.setProperty('AccountCompanyUser', accountCompanyUser);
    
    return message;
}
