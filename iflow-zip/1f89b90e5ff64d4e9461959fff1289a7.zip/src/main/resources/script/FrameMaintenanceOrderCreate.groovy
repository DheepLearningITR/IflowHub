import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

// process message
def Message processData(Message message) { 
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)

    jsonResult.data?.equipments.each { obj ->
        if (obj.objectCategory == null || obj.objectCategory == '')
            obj.objectCategory = 'EQ'
    }

    // Replace null values with empty strings and remove empty arrays
    replaceNullsAndRemoveEmptyArrays(jsonResult)

    jsonResult.data?.remove("lastChanged")
    jsonResult.data?.remove("updatedProperty")
    jsonResult.data?.remove("orgLevelIds")
    jsonResult.data?.remove("contact")
    jsonResult.data?.remove("attachments")
    jsonResult.data?.remove("requirements")
    jsonResult.data?.remove("chargeableEfforts")
    jsonResult.data?.remove("chargeableExpenses")
    jsonResult.data?.remove("chargeableMaterials")
    jsonResult.data?.remove("chargeableMileages")
    jsonResult.data?.remove("address")
    jsonResult.data?.remove("udfValues")
    jsonResult.data?.remove("serviceContract")
    jsonResult.data?.remove("createPerson")
    jsonResult.data?.remove("reservedMaterials")
    
    //jsonResult.data?.remove("activities")
    jsonResult.data?.activities.each { act ->
        act.remove("lastChanged")
        act.remove("contact")
        act.remove("type")
        act.remove("address")
        act.remove("requirements")
        act.remove("attachments")
        act.remove("equipment")
        act.remove("udfValues")
        act.remove("orgLevelIds")
        act.remove("createPerson")
        act.remove("reservedMaterials")
        act.remove("sourceActivity")
        act.remove("workflowStep")
        act.remove("internalRemarks")
        act.remove("internalRemarks2")
        act.remove("statusChangeReason")
        act.remove("serviceProduct")
        act.remove("activityFeedbacks")
    }

    
    //add objectId and objectType node
    jsonResult["objectId"] = jsonResult.data?.id
    jsonResult["objectType"] = (jsonResult.eventType == "servicecall.created")?"SERVICECALL":"ACTIVITY"

    def updatedJsonString = JsonOutput.toJson(jsonResult)
    message.setBody(JsonOutput.prettyPrint(updatedJsonString))

    //set OData url prefix path to UpdateMaintenanceOrder
    message.setProperty("createpathprefix",'SAP__self.CreateMaintenanceOrder')
    message.setProperty("S4HRequestPayload",JsonOutput.prettyPrint(updatedJsonString))
    message.setProperty("FSMServiceCallID",jsonResult.data?.id)
    message.setProperty("FSMActivityCode",jsonResult.data?.activities[0]?.code)
    message.setProperty("FSMActivityid",jsonResult.data?.activities[0]?.id)

    return message
}

// Recursive function to replace all null values with empty strings and remove empty arrays
def replaceNullsAndRemoveEmptyArrays(obj) {
    if (obj instanceof Map) {
        def keysToRemove = [] // List to track empty arrays
        obj.each { key, value ->
            if (value == null || value == 'null' || value == '') {
                //obj[key] = ""
                keysToRemove.add(key) // Mark empty array for removal
            } else if (value instanceof List && value.isEmpty()) {
                keysToRemove.add(key) // Mark empty array for removal
            } else {
                replaceNullsAndRemoveEmptyArrays(value)
            }
        }
        // Remove the keys after iteration
        keysToRemove.each { key ->
            //obj.remove(key)
            obj.remove(key)
        }
    } else if (obj instanceof List) {
        def itemsToRemove = [] // List to track null and empty arrays
        obj.each { item ->
            if (item == null || item == 'null' || item == '' || (item instanceof List && item.isEmpty())) {
                itemsToRemove.add(item) // Mark for removal
            } else {
                replaceNullsAndRemoveEmptyArrays(item)
            }
        }
        // Remove the items after iteration
        itemsToRemove.each { item ->
            obj.remove(item)
        }
    }
}
