package src.main.resources.script

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	def logHelper = new LogHelper(messageLogFactory, message)
	if (logHelper.isLoggingEnabled('ENABLE_PAYLOAD_LOGGING')) {
		def loopCounter = message.getProperty('loopCounter');
		logHelper.logBodyAsAttachment("Payload $loopCounter after mapping", 'application/json')
	}
	return message
}