package src.main.resources.script;

import src.main.resources.script.ValueType

class AddressMapper {
	def person
	def addresses
	
	def AddressMapper(def person, def addresses) {
		this.person = person
		this.addresses = addresses
	}
	
	def setPrivateAddresses(def mdwWorkforcePerson, def mdwWorkAssignmentsPerUserId) {
		mdwWorkforcePerson.privateAddresses = []
		addresses.each { address ->
			def mdwPrivateAddress = getMdwPrivateAddress(address)
			if (mdwPrivateAddress == null) {
				return
			}
			def userId = XmlHelper.getValue(address, 'empUsersSysId')
			def mdwWorkAssignment = null
			if (userId != null) {
				mdwWorkAssignment = mdwWorkAssignmentsPerUserId[userId]
			}
			if (mdwWorkAssignment != null) {
				if (!mdwWorkAssignment.privateAddresses) {
					mdwWorkAssignment.privateAddresses = []
				}
				mdwWorkAssignment.privateAddresses << mdwPrivateAddress
			} else {
				mdwWorkforcePerson.privateAddresses << mdwPrivateAddress
			}
		}
	}
	
	def getMdwPrivateAddress(def ecAddress) {
		def country = XmlHelper.getValue(ecAddress, 'country')
		def mdwAddress = [:]
		mdwAddress.script_code = null
		
		CountrySpecificAddressMapping.COMMON.mapAddress(ecAddress, mdwAddress)
		CountrySpecificAddressMapping countrySpecificMapping = CountrySpecificAddressMapping.values().find { it.name() == country }
		if (countrySpecificMapping != null) {
			countrySpecificMapping.mapAddress(ecAddress, mdwAddress)
		}
		return mdwAddress
	}
	
	enum CountrySpecificAddressMapping {
		COMMON([
		    'addressType'	: MdwAddressField.USAGE_CODE, 
		    'country' 		: MdwAddressField.COUNTRY_CODE,
		    'endDate' 		: MdwAddressField.VALID_TO,
		    'startDate' 	: MdwAddressField.VALID_FROM
		]),
		DEU([
			'address1' 	: MdwAddressField.THOROUGHFARE_NAME,
		    'address2' 	: MdwAddressField.HOUSE_NUMBER,
			'address3' 	: MdwAddressField.DISTRICT_NAME,
			'city' 		: MdwAddressField.TOWN_NAME,
			'zipCode' 	: MdwAddressField.POST_CODE
		]),
		USA([
			'address1' 	: MdwAddressField.THOROUGHFARE_NAME,
			'address2' 	: MdwAddressField.THOROUGHFARE_SUFFIX1, 
			'city' 		: MdwAddressField.TOWN_NAME,
			'county' 	: MdwAddressField.SECONDARY_REGION_NAME, 
			'state' 	: MdwAddressField.PRIMARY_REGION_CODE,
			'zipCode' 	: MdwAddressField.POST_CODE
		])
		
		def final Map<String, MdwAddressField> mappings
		
		private CountrySpecificAddressMapping(Map<String, MdwAddressField> mappings) {
			this.mappings = mappings
		}
		
		def mapAddress(def ecAddress, def mdwAddress) {
			mappings.each { e ->
				String ecFieldName = e.key
				MdwAddressField field = e.value
				String ecFieldValue = XmlHelper.getValue(ecAddress, ecFieldName, field.valueType)
				if (field.function != null && ecFieldValue != null) {
					if (field.additionalFunctionParameter != null) {
						def additionalParameter = mdwAddress."${field.additionalFunctionParameter.name}"
						ecFieldValue = field.function(ecFieldValue, additionalParameter)
					} else {
						ecFieldValue = field.function(ecFieldValue)
					}
				}
				mdwAddress."${field.name}" = ecFieldValue
			}
			return mdwAddress
		}
	}
	
	enum MdwAddressField {
		CAREOF('physical_careOf'),
		COUNTRY_CODE('physical_country_code', ValueType.STRING, CountryCodeMapper.&getTwoLetterIsoCode),
		DISTRICT_NAME('physical_district_name'),
		DISTRICT_REF_CODE('physical_district_ref_code'),
		DOOR('physical_door'),
		FLOOR('physical_floor'),
		HOUSE_NUMBER('physical_houseNumber'),
		HOUSE_NUMBER_SUPPLEMENT('physical_houseNumberSupplement'),
		POST_CODE('physical_postCode'),
		PRIMARY_REGION_CODE('physical_primaryRegion_code', ValueType.STRING, StateCodeMapper.&getMappedStateCode, MdwAddressField.COUNTRY_CODE),
		SCRIPT('script_code'),
		SECONDARY_REGION_NAME('physical_secondaryRegion_name'),
		SECONDARY_REGION_REF_CODE('physical_secondaryRegion_ref_code'),
		TERTIARY_REGION_NAME('physical_tertiaryRegion_name'),
		TERTIARY_REGION_REF_CODE('physical_tertiaryRegion_ref_code'),
		THOROUGHFARE_NAME('physical_thoroughfare_name'),
		THOROUGHFARE_PREFIX1('physical_tfPrefix1'),
		THOROUGHFARE_PREFIX2('physical_tfPrefix2'),
		THOROUGHFARE_REF_CODE('physical_thoroughfare_ref_code'),
		THOROUGHFARE_SUFFIX1('physical_tfSuffix1'),
		THOROUGHFARE_SUFFIX2('physical_tfSuffix2'),
		TOWN_NAME('physical_town_name'),
		TOWN_REF_CODE('physical_town_ref_code'),
		USAGE_CODE('usage_code'),
		VALID_FROM('validFrom', ValueType.DATE),
		VALID_TO('validTo', ValueType.DATE, MapSfToMdw.&addOneDay),

		// Alternate fields
		ALTERNATIVE_COUNTRY_CODE('alternative_country_code'),
		ALTERNATIVE_DISTRICT_NAME('alternative_district_name'),
		ALTERNATIVE_DISTRICT_REF_CODE('alternative_district_ref_code'),
		ALTERNATIVE_DELIVERY_SERVICE_IDENTIFIER('alternative_deliveryServiceIdentifier'),
		ALTERNATIVE_DELIVERY_SERVICE_QUALIFIER('alternative_deliveryServiceQualifier'),
		ALTERNATIVE_DELIVERY_SERVICE_TYPE('alternative_deliveryServiceType'),
		ALTERNATIVE_POST_CODE('alternative_postCode'),
		ALTERNATIVE_PRIMARY_REGION_CODE('alternative_primaryRegion_code'),
		ALTERNATIVE_SECONDARY_REGION_NAME('alternative_secondaryRegion_name'),
		ALTERNATIVE_SECONDARY_REGION_REF_CODE('alternative_secondaryRegion_ref_code'),
		ALTERNATIVE_TERTIARY_REGION_NAME('alternative_tertiaryRegion_name'),
		ALTERNATIVE_TERTIARY_REGION_REF_CODE('alternative_tertiaryRegion_ref_code'),
		ALTERNATIVE_TOWN_NAME('alternative_town_name'),
		ALTERNATIVE_TOWN_REF_CODE('alternative_town_ref_code')
		
		def final name
		final Closure function
		final ValueType valueType
		final MdwAddressField additionalFunctionParameter
		
		private MdwAddressField(def name) {
			this(name, ValueType.STRING)
		}
		
		private MdwAddressField(def name, ValueType valueType) {
			this(name, valueType, null)
		}
		
		private MdwAddressField(def name, ValueType valueType, Closure function) {
			this(name, valueType, function, null)
		}
		
		private MdwAddressField(def name, ValueType valueType, Closure function, MdwAddressField additionalFunctionParameter) {
			this.name = name
			this.valueType = valueType
			this.function = function
			this.additionalFunctionParameter = additionalFunctionParameter
		}
	}
}