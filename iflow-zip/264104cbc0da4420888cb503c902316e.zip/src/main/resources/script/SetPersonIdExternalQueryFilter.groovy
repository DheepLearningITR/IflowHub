package src.main.resources.script;

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	def commonFilterString = message.getProperty('QUERY_FILTER_STRING_COMMON')
	def personIdExternal = message.getProperty('PERSON_ID_EXTERNAL')
	def filterString = commonFilterString + " and personIdExternal eq '$personIdExternal'"
    message.setProperty('QUERY_FILTER_STRING', filterString)
	
	def logHelper = new LogHelper(messageLogFactory, message)
	logHelper.logString('Query filter string', filterString)
    return message;
}