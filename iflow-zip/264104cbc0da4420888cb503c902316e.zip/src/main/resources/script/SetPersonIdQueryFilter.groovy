package src.main.resources.script

import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(java.lang.String)
    def xml = new XmlSlurper().parseText(body)
	def personIds = xml.PerPerson.personId.collect()
	if (!personIds.isEmpty()) {
		def commonFilterString = message.getProperty('QUERY_FILTER_STRING_COMMON')
		def filterString = commonFilterString + ' and personId in ' + personIds.join(',')
	    message.setProperty('QUERY_FILTER_STRING', filterString)
	    
		def logHelper = new LogHelper(messageLogFactory, message)
		logHelper.logString('Query filter string', filterString)
	} else {
		// Always set as empty as this gets checked in the router
	    message.setProperty('QUERY_FILTER_STRING', '')
	}
    return message;
}