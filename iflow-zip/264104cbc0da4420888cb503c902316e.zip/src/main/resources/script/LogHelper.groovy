package src.main.resources.script

import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.msglog.MessageLogFactory

class LogHelper {
	final MessageLogFactory messageLogFactory
	final Message message
	
	LogHelper(MessageLogFactory messageLogFactory, Message message) {
		this.messageLogFactory = messageLogFactory
		this.message = message
	}
	
	boolean isLoggingEnabled(String propertyName) {
		return "true".equalsIgnoreCase(message.getProperty(propertyName))
	}
	
	void logString(String name, String value) {
		def messageLog = messageLogFactory.getMessageLog(message)
		if (messageLog != null)	{
			messageLog.setStringProperty(name, value)
		}
	}
	
	void logStringAsAttachment(String description, String contentType, String content) {
		def messageLog = messageLogFactory.getMessageLog(message)
		if (messageLog != null)	{
			messageLog.addAttachmentAsString(description, content, contentType)
		}
	}
	
	void logBodyAsAttachment(String description, String contentType) {
		def body = message.getBody(java.lang.String)
		logStringAsAttachment(description, contentType, body)
	}
}