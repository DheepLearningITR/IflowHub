package src.main.resources.script

import java.text.ParseException
import java.text.SimpleDateFormat

class XmlHelper {
	static getSubObjectOrNull(def object, def String... subPaths) {
		for (int i = 0; i < subPaths.length; i++) {
			object = object."${subPaths[i]}"
			if (object.size() == 0) {
				return null
			}
	
			if (i == (subPaths.length - 1)) {
				return object
			}
		}
	}
	
	static getValue(def entity, String fieldName, def ValueType type = ValueType.STRING) {
		if (entity == null || fieldName == null) {
			return null
		}
		def s = null
		
		def node = entity."${fieldName}Nav"
		if (node.size() > 0) {
			// Found Nav node => Check if PicklistOption is there
			def picklistOption = node.PicklistOption
			if (picklistOption.size() > 0) {
				s = node.PicklistOption.externalCode.text()
			}
		}
		// Value string not yet assigned by external code from picklist option
		if (s == null) {
			node = entity."${fieldName}"
			if (node.size() == 0) {
				return null
			}
			node = node.iterator().next()
			s = node.text()
		}
		if (s == null) {
			return null
		}
		s = s.trim()
		if (s.isEmpty()) {
			return null
		} else if (type == ValueType.DATE || type == ValueType.DATETIME) {
			SimpleDateFormat sdfEc = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")
			try {
				Date date = sdfEc.parse(s)
				SimpleDateFormat sdfMdw;
				if (type == ValueType.DATETIME) {
					sdfMdw = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
				} else {
					sdfMdw = new SimpleDateFormat("yyyy-MM-dd")
				}
				return sdfMdw.format(date)
			} catch (ParseException ex) {
				return null
			}
		} else if (type == ValueType.INTEGER || type == ValueType.DOUBLE) {
			try {
				Double d = Double.parseDouble(s)
				return type == ValueType.INTEGER ? d.intValue() : d.doubleValue()
			} catch (NumberFormatException ex) {
				ex.printStackTrace()
				return null
			}
		} else if (type == ValueType.BOOLEAN) {
			return 'true'.equals(s.toLowerCase())
		}
		
		// Default case
		return s
	}
}