package src.main.resources.script

import com.sap.gateway.ip.core.customdev.util.Message
import org.apache.camel.Exchange

def Message processData(Message message) {
	StringBuilder sb = new StringBuilder()
    sb.append('last modified date: ').append(message.getProperty('LAST_MODIFIED_DATETIME')).append('\n')
    sb.append('user set last modified date: ').append(message.getProperty('USER_SET_LAST_MODIFIED_DATETIME')).append('\n')
    sb.append('enable payload logging: ').append(message.getProperty('ENABLE_PAYLOAD_LOGGING')).append('\n')
    sb.append('person id external: ').append(message.getProperty('PERSON_ID_EXTERNAL')).append('\n')
    sb.append('initial load: ').append(message.getProperty('INITIAL_LOAD'))

    def logHelper = new LogHelper(messageLogFactory, message)
	logHelper.logStringAsAttachment('External parameters', 'text/plain', sb.toString())
    return message;
}