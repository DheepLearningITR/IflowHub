package src.main.resources.script

import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.msglog.MessageLogFactory

class StateCodeMapper {
	static final Map<String, Map<String, String>> statesPerCountry = [
		'US': [
			'AK' : 'US-AK',
			'AL' : 'US-AL',
			'AR' : 'US-AR',
			'AS' : 'US-AS',
			'AZ' : 'US-AZ',
			'CA' : 'US-CA',
			'CO' : 'US-CO',
			'CT' : 'US-CT',
			'DC' : 'US-DC',
			'DE' : 'US-DE',
			'FL' : 'US-FL',
			'GA' : 'US-GA',
			'GU' : 'US-GU',
			'HI' : 'US-HI',
			'IA' : 'US-IA',
			'ID' : 'US-ID',
			'IL' : 'US-IL',
			'IN' : 'US-IN',
			'KS' : 'US-KS',
			'KY' : 'US-KY',
			'LA' : 'US-LA',
			'MA' : 'US-MA',
			'MD' : 'US-MD',
			'ME' : 'US-ME',
			'MI' : 'US-MI',
			'MN' : 'US-MN',
			'MO' : 'US-MO',
			'MP' : 'US-MP',
			'MS' : 'US-MS',
			'MT' : 'US-MT',
			'NC' : 'US-NC',
			'ND' : 'US-ND',
			'NE' : 'US-NE',
			'NH' : 'US-NH',
			'NJ' : 'US-NJ',
			'NM' : 'US-NM',
			'NV' : 'US-NV',
			'NY' : 'US-NY',
			'OH' : 'US-OH',
			'OK' : 'US-OK',
			'OR' : 'US-OR',
			'PA' : 'US-PA',
			'PR' : 'US-PR',
			'RI' : 'US-RI',
			'SC' : 'US-SC',
			'SD' : 'US-SD',
			'TN' : 'US-TN',
			'TX' : 'US-TX',
			'UT' : 'US-UT',
			'VA' : 'US-VA',
			'VI' : 'US-VI',
			'VT' : 'US-VT',
			'WA' : 'US-WA',
			'WI' : 'US-WI',
			'WV' : 'US-WV',
			'WY' : 'US-WY'
		]
	]
	
	def static String getMappedStateCode(String state, String country) {
		def states = statesPerCountry.get(country)
		if (states == null) {
			return null
		}
		return states.get(state)
	}
}