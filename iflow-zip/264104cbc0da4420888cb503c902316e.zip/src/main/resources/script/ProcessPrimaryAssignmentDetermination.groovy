package src.main.resources.script

import java.text.ParseException
import java.text.SimpleDateFormat

import groovy.json.JsonOutput

public class ProcessPrimaryAssignmentDetermination {
	private static final String ASSIGNMENT_TYPE_GA = 'GA'
	private static final String ASSIGNMENT_TYPE_ST = 'ST'
	
	private static final String EMPLOYEE_STATUS_ACTIVE = 'A'
	private static final String EMPLOYEE_STATUS_TERMINATED = 'T'
	
	private static final String EC_HIGH_DATE = '9999-12-31'
	
	private static final SimpleDateFormat formatter = new SimpleDateFormat('yyyy-MM-dd')
	static {
		formatter.setTimeZone(TimeZone.getTimeZone('UTC'))
	}
	
	private List<EmployeeStatusOrSecondaryAssignmentsChange> primaryAssignmentTimeslices = []
	private Map<String, Date> userIdVsEarliestJobDate = [:]
	private List<String> ignoredAssignmentTypeUserIds = []
	
	public void setWorkAssignmentDetails(def person, def mdwWorkAssignments) {
		int count = mdwWorkAssignments.size()
		if (count == 0) {
			return
		} else if (count == 1) {
			// Create one workAssignmentDetail with earliest startDate of jobDetails as startDate and highDate as endDate
			def workAssignment = mdwWorkAssignments[0]
			workAssignment.details = []
			
			def workAssignmentDetail = [:]
			def earliestJobInfoStartDate = null
			workAssignment.jobDetails.each { jobDetail ->
				if (earliestJobInfoStartDate == null || earliestJobInfoStartDate.compareTo(jobDetail.validFrom) > 0) {
					earliestJobInfoStartDate = jobDetail.validFrom
				}
			}
			workAssignmentDetail.validFrom = earliestJobInfoStartDate != null ? earliestJobInfoStartDate : workAssignment.startDate
			workAssignmentDetail.validTo = EC_HIGH_DATE
			workAssignmentDetail.isPrimary = true
			workAssignment.details.add(workAssignmentDetail)
			return
		}
			
		primaryAssignmentTimeslices.clear()
		userIdVsEarliestJobDate.clear()
		ignoredAssignmentTypeUserIds.clear() 
		
		determinePrimaryAssignmentTimeslices(person)
		mdwWorkAssignments.each { workAssignment ->
			String userId = workAssignment.externalID
			Date hireDate = userIdVsEarliestJobDate.get(userId)
			workAssignment.details = []
			
			// TODO assignment types others than GA, ST - e. g. PP etc. 
			if (hireDate == null || ignoredAssignmentTypeUserIds.contains(userId)) {
				// no job info records found, assume assignment is always false
				def workAssignmentDetail = [:]
				hireDate = parseDate('1900-01-01')
				workAssignmentDetail.validFrom = formatDate(hireDate)
				workAssignmentDetail.validTo = EC_HIGH_DATE
				workAssignmentDetail.isPrimary = false
				workAssignment.details.add(workAssignmentDetail)
				return
			}
			
			def previousDetail = null
			primaryAssignmentTimeslices.each { changeDetail ->
				def workAssignmentDetail = [:]
				Date startDate = changeDetail.startDate
				if ((hireDate.getTime() - startDate.getTime()) > 0) {
					return
				}
				workAssignmentDetail.validFrom = formatDate(startDate)
				workAssignmentDetail.validTo = formatDate(changeDetail.endDate)
				if (userId == changeDetail.primaryAssignmentUserId) {
					workAssignmentDetail.isPrimary = true
				} else {
					workAssignmentDetail.isPrimary = false
				}
				// Merge adjacent work assignment details where the isPrimary flag did not change 
				if (previousDetail != null) {
					if (workAssignmentDetail.validFrom == previousDetail.validTo && workAssignmentDetail.isPrimary == previousDetail.isPrimary) {
						previousDetail.validTo = workAssignmentDetail.validTo
						return
					}
				}
				previousDetail = workAssignmentDetail
				workAssignment.details.add(workAssignmentDetail)
			}			
		}		
	}
	
	private void determinePrimaryAssignmentTimeslices(def person) {
		List<String> userIds = []
		List<String> gaUserIds = []
		List<String> stUserIds = []	
					
		List<EmployeeStatusOrSecondaryAssignmentsChange> statusChanges = []
		def employments = XmlHelper.getSubObjectOrNull(person, 'employmentNav', 'EmpEmployment')
		if (employments != null) {
			employments.each { employment ->
				String assignType = XmlHelper.getValue(employment, 'assignmentClass')
				Date earliestJobDate =  null
				Date latestTerminationDate =  null
				String userId = XmlHelper.getValue(employment, 'userId')
				userIds.add(userId)
				boolean ignoreAssignmentType = false
				if (ASSIGNMENT_TYPE_ST == assignType) {
					stUserIds.add(userId)
				} else if (ASSIGNMENT_TYPE_GA == assignType) {
					gaUserIds.add(userId)
				} else {
					// ignore assignment type as it shall always be false, but need earliest job date 
					ignoredAssignmentTypeUserIds.add(userId)
					ignoreAssignmentType = true
				}
				
				List<EmployeeStatusOrSecondaryAssignmentsChange> userStatusChanges = []
				def jobInfos = XmlHelper.getSubObjectOrNull(employment, 'jobInfoNav', 'EmpJob')
				if (jobInfos != null) {
					jobInfos.each { jobInfo ->
						Integer n = XmlHelper.getValue(jobInfo, 'seqNumber', ValueType.INTEGER)
						int seqNumber = n == null ? -1 : n.intValue()
						String eventDateStr = XmlHelper.getValue(jobInfo, 'startDate', ValueType.DATE)
						Date eventDate = parseDate(eventDateStr)
						String employeeStatus = XmlHelper.getValue(jobInfo, 'emplStatus')					
						// TODO check null
						boolean isJobRecValid = true				
						if (!isJobRecValid) {
							return
						}
						if (earliestJobDate == null || (earliestJobDate.getTime() - eventDate.getTime() > 0)) {			
							earliestJobDate = eventDate
						}
						// ignored type never be primary
						if (ignoreAssignmentType) {
							return
						}
						EmployeeStatusOrSecondaryAssignmentsChange statusChange = new EmployeeStatusOrSecondaryAssignmentsChange(userId, employeeStatus, eventDate, seqNumber)
						userStatusChanges.add(statusChange)						
					}
				}
				// all job records added for an employment info 
				userStatusChanges.sort()
				userStatusChanges = filterChangesWithSameEmployeeStatusOrSameDay(userStatusChanges)
				adjustEndDate(userStatusChanges, true)			
				
				userIdVsEarliestJobDate.put(userId, earliestJobDate)
				// ignored type never be primary
				if (!ignoreAssignmentType) {	
					statusChanges.addAll(userStatusChanges)					
				}
			}
		}

		List<EmployeeStatusOrSecondaryAssignmentsChange> allChanges = []
		allChanges.addAll(statusChanges)
		// add time slices for  secondary assignment items
		def secondaryAssignments = XmlHelper.getSubObjectOrNull(person, 'secondaryAssignmentsNav', 'SecondaryAssignments')
		if (secondaryAssignments != null) {			
			secondaryAssignments.each { secondaryAssignment ->
				String eventDateStr = XmlHelper.getValue(secondaryAssignment, 'effectiveStartDate', ValueType.DATE)
				Date eventDate = parseDate(eventDateStr)
				List<String> secondaryUsers = []
				def allSfProcesses = XmlHelper.getSubObjectOrNull(secondaryAssignment, 'allSfProcesses', 'SecondaryAssignmentsItem')
				if (allSfProcesses != null) {
					allSfProcesses.each {
						sfProcess ->
						secondaryUsers.add(XmlHelper.getValue(sfProcess, 'usersSysId'))
					}
				}
				if (!secondaryUsers.isEmpty()) {
					// TODO check behavior empl				
					allChanges.add(new EmployeeStatusOrSecondaryAssignmentsChange(eventDate, secondaryUsers))
				}
			}		
		}		
		
		// sort job info records from multiple assignments which are relevant for employee status change  
		statusChanges.sort()
		allChanges.sort()
		
		/*
		println 'changes from job history'
		statusChanges.each{ job ->
			println formatDate(job.startDate) + ' ' +  job.userId + ' ' + job.secondaryAssignmentUserIds.collect() + ' ' + job.employeeStatus
		}
		println 'after add sec assignments'
		*/ 
		
		// propagate 2nd userIds
		propagateSecondaryAssignmentUserIds(allChanges)
		
		/*
		println 'after  propagate secondary user ids ---------'
		allChanges.each{ job ->
			println formatDate(job.startDate) + ' ' +  job.userId() + ' ' + job.secondaryAssignmentUserIds.collect() + ' ' + job.employeeStatus
		}
		*/
		
		primaryAssignmentTimeslices = filterSameDayStatusOrSecondaryAssignmentsChanges(allChanges)
		adjustEndDate(primaryAssignmentTimeslices, false)
	
		
	//	println 'after set primary assignment user  ---------'			
		
		setPrimaryAssignmentUserId(primaryAssignmentTimeslices, statusChanges, stUserIds, gaUserIds)
		
		/*
		println '*********** primary assignment **************'			
		primaryAssignmentTimeslices.each{ job ->
			println formatDate(job.startDate) + ' ' + formatDate(job.endDate) + ' ' +  job.primaryAssignmentUserId
		}
		*/	
	}
	
	private List<EmployeeStatusOrSecondaryAssignmentsChange> setPrimaryAssignmentUserId(List<EmployeeStatusOrSecondaryAssignmentsChange> allChanges, 
		List<EmployeeStatusOrSecondaryAssignmentsChange> employeeStatusChanges, List<String> stUserIds, List<String> gaUserIds) {
		Set<String> allUserIds = []
		allUserIds.addAll(stUserIds)
		allUserIds.addAll(gaUserIds)
		
		allChanges.each { changeDetail ->
			List<String> possiblePrimaryUserIds = []
			Date startDate = changeDetail.startDate
			List<String> secondaryUserIds = changeDetail.secondaryAssignmentUserIds
			
			for (String userId : allUserIds) {
				// exclude users in secondary assignments time slice
				// does not work
				if (secondaryUserIds.contains(userId)) {
					continue
				}
				
				//  check if employee status is active at start date
				boolean isActive = isEmployeeActiveAsOfDate(userId, startDate, employeeStatusChanges)
				if (isActive) {
					possiblePrimaryUserIds.add(userId)
				}
			}
			
			int count = possiblePrimaryUserIds.size()
			if (count == 1) {
				changeDetail.primaryAssignmentUserId = possiblePrimaryUserIds.get(0)
			} else if (count > 1) {
				// take home assignment with highest hire date			
				List<String> possibleHomeUserIds = []
				possiblePrimaryUserIds.each { userId ->
					if (!gaUserIds.contains(userId)) {
						possibleHomeUserIds.add(userId)
					}
				}
				String activeUser
				if (possibleHomeUserIds.size() == 1) {
					activeUser = possibleHomeUserIds.get(0)
				} else {
					activeUser = findUserIdWithHighestDate(startDate, possibleHomeUserIds, employeeStatusChanges, true)
				}				
				changeDetail.primaryAssignmentUserId = activeUser
			} else if (possiblePrimaryUserIds.isEmpty()) {
				// find inactive home assignment with highest termination date
				String inactiveUser = findUserIdWithHighestDate(startDate, stUserIds, employeeStatusChanges, false)
				changeDetail.primaryAssignmentUserId = inactiveUser
			}
		}
	}
	
	private String findUserIdWithHighestDate(Date date, List<String> stUserIds, List<EmployeeStatusOrSecondaryAssignmentsChange> employeeStatusChanges, boolean active) {
		String userId = null
		Date highestDate = null
		employeeStatusChanges.each { changeDetail ->
			if (!stUserIds.contains(changeDetail.userId)) {
				return
			}
			String status = changeDetail.employeeStatus
			if ((changeDetail.startDate.getTime() - date.getTime()) > 0) {
				return
			}
			
			if ((active && EMPLOYEE_STATUS_ACTIVE == status) || (!active && EMPLOYEE_STATUS_ACTIVE != status)) {
				if (highestDate == null || (changeDetail.startDate.getTime() - highestDate.getTime() > 0)) {
					userId = changeDetail.userId
					highestDate = changeDetail.startDate
				}
			}
		}
		return userId
	}
	
	private boolean isEmployeeActiveAsOfDate(String userId, Date date, List<EmployeeStatusOrSecondaryAssignmentsChange> employeeStatusChanges) {
		boolean isActive = false
		employeeStatusChanges.each { changeDetail ->
			if (userId != changeDetail.userId) {
				return
			}
			long diffToStartDate = date.getTime() - changeDetail.startDate.getTime()
			long diffToEndDate = date.getTime() - changeDetail.employeeStatusValidToDate.getTime()	
		
			if (diffToStartDate >= 0 && diffToEndDate < 0) {
				isActive = changeDetail.employeeStatus == EMPLOYEE_STATUS_ACTIVE
			}
		}
		return isActive
	}
	
	private List<EmployeeStatusOrSecondaryAssignmentsChange> filterChangesWithSameEmployeeStatusOrSameDay(List<EmployeeStatusOrSecondaryAssignmentsChange> statusChanges) {
		// statusChanges must have the same user id
		List<EmployeeStatusOrSecondaryAssignmentsChange> filteredJobEvents = []		
		
		EmployeeStatusOrSecondaryAssignmentsChange previousChange = null	
		statusChanges.each { changeDetail ->
			String employeeStatus = changeDetail.employeeStatus	
			if (employeeStatus == null || (previousChange != null && employeeStatus == previousChange.employeeStatus)) {
				return
			}		
			if (previousChange != null && (changeDetail.seqNumber > previousChange.seqNumber) && (changeDetail.startDate.getTime() - previousChange.startDate.getTime() == 0)) {
				// same day changes
				filteredJobEvents.remove(filteredJobEvents.size() - 1)
			}
			previousChange = changeDetail
			filteredJobEvents.add(changeDetail)
		}
		return filteredJobEvents
	}
	
	private List<EmployeeStatusOrSecondaryAssignmentsChange> filterSameDayStatusOrSecondaryAssignmentsChanges(List<EmployeeStatusOrSecondaryAssignmentsChange> jobEvents) {
		List<EmployeeStatusOrSecondaryAssignmentsChange> filteredChanges = []
		
		String previousDateStr = null
		jobEvents.each { jobEvent ->
			String dateStr = formatDate(jobEvent.startDate)
			if (previousDateStr != null && previousDateStr == dateStr) {
				return
			}
			previousDateStr = dateStr
			filteredChanges.add(jobEvent)
		}
		return filteredChanges
	}
	
	private void adjustEndDate(List<EmployeeStatusOrSecondaryAssignmentsChange> jobEvents, boolean isEmployeeStatusValidToDate) {
		// list contains records of same user
		EmployeeStatusOrSecondaryAssignmentsChange previousEvent = null
		jobEvents.each { changeDetail ->
			if (previousEvent != null) {
				if (isEmployeeStatusValidToDate) {
					previousEvent.employeeStatusValidToDate = changeDetail.startDate
				} else {
					previousEvent.endDate = changeDetail.startDate
				}
			}
			previousEvent = changeDetail
		}
		if (previousEvent != null) {
			if (isEmployeeStatusValidToDate && previousEvent.employeeStatusValidToDate == null) {
				previousEvent.employeeStatusValidToDate = parseDate(EC_HIGH_DATE)
			}
			if (!isEmployeeStatusValidToDate && previousEvent.endDate == null) {
				previousEvent.endDate = parseDate(EC_HIGH_DATE)
			}
		}
	}
	
	private void propagateSecondaryAssignmentUserIds(List<EmployeeStatusOrSecondaryAssignmentsChange> jobEvents) {
		EmployeeStatusOrSecondaryAssignmentsChange previousEvent = null
		jobEvents.each { jobEvent ->
			if (previousEvent != null && !jobEvent.secondaryAssignmentChanged) {
				// take userIds of previous event before next CE time slice is found
				jobEvent.secondaryAssignmentUserIds = previousEvent.secondaryAssignmentUserIds
			}
			previousEvent = jobEvent
		}
	}
	
	private Date parseDate(String dateStr) {
		try {
			return formatter.parse(dateStr)
		} catch (final ParseException e) {
			return null
		}
	}
	
	private String formatDate(Date date) {
		if (date == null) {
			return null
		}
		return formatter.format(date)
	}
	
	/*
	 *  collect changes from Secondary Assignments and Job Info
	 */
	public static class EmployeeStatusOrSecondaryAssignmentsChange implements Comparable<EmployeeStatusOrSecondaryAssignmentsChange> {
		private String primaryAssignmentUserId
		private String userId
		private String employeeStatus
		private int seqNumber
		private boolean secondaryAssignmentChanged
		private Date startDate // end date shall be calculated for work assignment details time slices
		private Date endDate // end date for employee status calculated from job info history
		private Date employeeStatusValidToDate
		private List<String> secondaryAssignmentUserIds = []
		
		public EmployeeStatusOrSecondaryAssignmentsChange(String userId, String employeeStatus, Date startDate, int seqNumber) {
			this.employeeStatus = employeeStatus
			this.userId = userId
			this.startDate = startDate
			this.seqNumber = seqNumber
		}
			 
		public EmployeeStatusOrSecondaryAssignmentsChange(Date startDate, List<String> secondaryAssignmentUserIds) {
			this.startDate = startDate
			this.secondaryAssignmentUserIds = secondaryAssignmentUserIds
			this.secondaryAssignmentChanged = true
		}
		
		@Override
		public int compareTo(EmployeeStatusOrSecondaryAssignmentsChange that) {
			long thisTimeLong = this.startDate.getTime()
			long thatTimeLong = that.startDate.getTime()
			int dateCompareResult = Long.compare(thisTimeLong, thatTimeLong)
	 
			if (dateCompareResult != 0) {
				return dateCompareResult
			}

			// check seq number if start date is same, put CE time slices before employee status change at job info
			if (this.secondaryAssignmentChanged) {
				return -1
			} else if (that.secondaryAssignmentChanged) {
				return 1
			} else {
				return Integer.compare(this.seqNumber, that.seqNumber)
			}
		}
	}
}