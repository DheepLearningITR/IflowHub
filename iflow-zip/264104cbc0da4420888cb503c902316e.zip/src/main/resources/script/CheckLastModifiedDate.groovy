package src.main.resources.script

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def lastModifiedDate = message.getProperty('LAST_MODIFIED_DATETIME')
    def userSetLastModifiedDate = message.getProperty('USER_SET_LAST_MODIFIED_DATETIME')
    def personIdExternal = message.getProperty('PERSON_ID_EXTERNAL')
    def initialLoad = message.getProperty('INITIAL_LOAD')
	
    if ((lastModifiedDate == null || lastModifiedDate.isEmpty())
        && (userSetLastModifiedDate == null ||  userSetLastModifiedDate.isEmpty())
        && (personIdExternal == null || personIdExternal.isEmpty())
        && (initialLoad == null || !'true'.equalsIgnoreCase(initialLoad))) {
        throw new Exception('Please provide either user set last modified date, personIdExternal or initial load flag = true')
    }

    def pageSize = message.getProperty('PAGE_SIZE')
    if (pageSize == null || pageSize.isEmpty()) {
        throw new Exception('Please enter a page size')
    } else {
        pageSize = Integer.parseInt(pageSize)
        if (pageSize < 50 || pageSize > 400) {
            throw new Exception('Please enter a page size between 50 and 400')
        }
    }
	
	if ('true'.equalsIgnoreCase(initialLoad)) {
		// Always set TRUE in uppercase so that the check in the router works correctly
		message.setProperty('INITIAL_LOAD', 'TRUE')
	}

    if (personIdExternal == null || personIdExternal.isEmpty()) {
		LocalDateTime ldt = LocalDateTime.now().minusSeconds(10) // Substract 10 seconds because of possible transaction commit overlap in EC
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")

		def lastModifiedDateNew = ldt.format(dtf)
        message.setProperty('LAST_MODIFIED_DATETIME_NEW', lastModifiedDateNew)
    
		def logHelper = new LogHelper(messageLogFactory, message)
		logHelper.logString('Last modified date new', lastModifiedDateNew)
    }
    return message;
}