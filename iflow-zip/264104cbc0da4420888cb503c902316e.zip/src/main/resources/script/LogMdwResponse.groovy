package src.main.resources.script
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	def logHelper = new LogHelper(messageLogFactory, message)
	int loopCounter = message.getProperty('loopCounter');
	if (logHelper.isLoggingEnabled('ENABLE_PAYLOAD_LOGGING')) {
		logHelper.logBodyAsAttachment("Payload $loopCounter MDW response", 'application/json')
	}
	message.setProperty('loopCounter', loopCounter + 1);
	return message
}