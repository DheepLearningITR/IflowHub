package src.main.resources.script;

enum ValueType {
	STRING, DATE, DATETIME, DOUBLE, INTEGER, BOOLEAN
}