package src.main.resources.script

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def selectString = '$select=' + getSelectFields().join(',')
    def expandString = '$expand=' + getExpandFields().join(',')
	def filterString = '$filter=employmentNav/isECRecord eq true and employmentNav/hiringNotCompleted eq false and employmentNav/isContingentWorker eq false and employmentNav/jobInfoNav/countryOfCompany in \'DEU\',\'USA\''
	def initialLoad = message.getProperty('INITIAL_LOAD')
	if (initialLoad == 'TRUE') {
	    def highestPersonId = message.getProperty('HIGHEST_PERSON_ID')
	    if (highestPersonId != null && highestPersonId != 'null' && !highestPersonId.isEmpty()) {
	        filterString += " and personId gt $highestPersonId"
	    }
	}
    message.setProperty('QUERY_SELECT_STRING', selectString)
    message.setProperty('QUERY_EXPAND_STRING', expandString)
	// We set the filterString in two properties so that following scripts can access the common filter, enhance it and overwrite the actual FILTER_STRING used in the query.
	// In case of initial load no further filters are added, therefore we need to set the FILTER_STRING here as well
    message.setProperty('QUERY_FILTER_STRING_COMMON', filterString)
    message.setProperty('QUERY_FILTER_STRING', filterString)
    
    // Initialize Loop Counter and set property
    int loopCounter = 1;
    message.setProperty('loopCounter', loopCounter);
	
    def logHelper = new LogHelper(messageLogFactory, message)
	logHelper.logString('Query select string', selectString)
	logHelper.logString('Query expand string', expandString)
	logHelper.logString('Query filter string', filterString)

    return message;
}

static getSelectFields() {
	return [
		'personId',
		'perPersonUuid',
		'personIdExternal',
		'dateOfBirth',
		'dateOfDeath',
		'personalInfoNav/birthName',
		'personalInfoNav/birthNameAlt1',
		'personalInfoNav/birthNameAlt2',
		'personalInfoNav/businessFirstName',
		'personalInfoNav/businessFirstNameAlt1',
		'personalInfoNav/businessFirstNameAlt2',
		'personalInfoNav/businessLastName',
		'personalInfoNav/businessLastNameAlt1',
		'personalInfoNav/businessLastNameAlt2',
		'personalInfoNav/displayName',
		'personalInfoNav/displayNameAlt1',
		'personalInfoNav/displayNameAlt2',
		'personalInfoNav/endDate',
		'personalInfoNav/firstName',
		'personalInfoNav/firstNameAlt1',
		'personalInfoNav/firstNameAlt2',
		'personalInfoNav/formalName',
		'personalInfoNav/formalNameAlt1',
		'personalInfoNav/formalNameAlt2',
		'personalInfoNav/gender',
		'personalInfoNav/initials',
		'personalInfoNav/lastName',
		'personalInfoNav/lastNameAlt1',
		'personalInfoNav/lastNameAlt2',
		'personalInfoNav/middleName',
		'personalInfoNav/middleNameAlt1',
		'personalInfoNav/middleNameAlt2',
		'personalInfoNav/namePrefix',
		'personalInfoNav/namePrefixNav/externalCode',
		'personalInfoNav/nationality',
		'personalInfoNav/nativePreferredLang',
		'personalInfoNav/nativePreferredLangNav/externalCode',
		'personalInfoNav/partnerName',
		'personalInfoNav/partnerNamePrefix',
		'personalInfoNav/partnerNamePrefixNav/externalCode',
		'personalInfoNav/preferredName',
		'personalInfoNav/salutation',
		'personalInfoNav/salutationNav/externalCode',
		'personalInfoNav/script',
		'personalInfoNav/scriptAlt1',
		'personalInfoNav/scriptAlt2',
		'personalInfoNav/secondLastName',
		'personalInfoNav/secondNationality',
		'personalInfoNav/secondTitle',
		'personalInfoNav/secondTitleNav/externalCode',
		'personalInfoNav/startDate',
		'personalInfoNav/thirdNationality',
		'personalInfoNav/title',
		'personalInfoNav/titleNav/externalCode',
		'personalInfoNav/suffix',
		'personalInfoNav/suffixNav/externalCode',
		'employmentNav/assignmentIdExternal',
		'employmentNav/assignmentClass',
		'employmentNav/endDate',
		'employmentNav/originalStartDate',
		'employmentNav/startDate',
		'employmentNav/userId',
		'employmentNav/jobInfoNav/company',
		'employmentNav/jobInfoNav/countryOfCompany',
		'employmentNav/jobInfoNav/costCenter',
		'employmentNav/jobInfoNav/emplStatus',
		'employmentNav/jobInfoNav/emplStatusNav/externalCode',
		'employmentNav/jobInfoNav/endDate',
		'employmentNav/jobInfoNav/fte',
		'employmentNav/jobInfoNav/jobCode',
		'employmentNav/jobInfoNav/jobCodeNav/externalCode',
		'employmentNav/jobInfoNav/jobTitle',
		'employmentNav/jobInfoNav/managerUserNav/empInfo/assignmentIdExternal',
		'employmentNav/jobInfoNav/managerUserNav/empInfo/userId',
		'employmentNav/jobInfoNav/seqNumber',
		'employmentNav/jobInfoNav/standardHours',
		'employmentNav/jobInfoNav/startDate',
		'employmentNav/jobInfoNav/workingDaysPerWeek',
		'employmentNav/paymentInformationNav/effectiveEndDate',
		'employmentNav/paymentInformationNav/effectiveStartDate',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3/accountNumber',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3/accountOwner',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3/bankCountry',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3/businessIdentifierCode',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3/currency',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3/iban',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3/paymentMethod',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3/payType',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3/routingNumber',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3/toPaymentInformationDetailV3USA/accountType',
		'emailNav/emailAddress',
		'emailNav/emailType',
		'emailNav/emailTypeNav/externalCode',
		'emailNav/isPrimary',
		'phoneNav/areaCode',
		'phoneNav/countryCode',
		'phoneNav/extension',
		'phoneNav/isPrimary',
		'phoneNav/phoneNumber',
		'phoneNav/phoneType',
		'phoneNav/phoneTypeNav/externalCode',
		'secondaryAssignmentsNav/effectiveEndDate',
		'secondaryAssignmentsNav/effectiveStartDate',
		'secondaryAssignmentsNav/allSfProcesses/usersSysId',
		'userAccountNav/username',
		'homeAddressNavDEFLT/addressType',
		'homeAddressNavDEFLT/startDate',
		'homeAddressNavDEFLT/endDate',
		'homeAddressNavDEFLT/country',
		'homeAddressNavDEFLT/zipCode',
		'homeAddressNavDEFLT/county',
		'homeAddressNavDEFLT/stateNav',
		'homeAddressNavDEFLT/address1',
		'homeAddressNavDEFLT/address2',
		'homeAddressNavDEFLT/address3',
		'homeAddressNavDEFLT/city',
		'homeAddressNavDEFLT/empUsersSysId'
	]
}

static getExpandFields() {
	return [
		'personalInfoNav',
		'personalInfoNav/namePrefixNav',
		'personalInfoNav/nativePreferredLangNav',
		'personalInfoNav/partnerNamePrefixNav',
		'personalInfoNav/salutationNav',
		'personalInfoNav/secondTitleNav',
		'personalInfoNav/suffixNav',
		'personalInfoNav/titleNav',
		'employmentNav',
		'employmentNav/jobInfoNav',
		'employmentNav/jobInfoNav/emplStatusNav',
		'employmentNav/jobInfoNav/managerUserNav/empInfo',
		'employmentNav/jobInfoNav/jobCodeNav',
		'employmentNav/paymentInformationNav',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3/payTypeNav',
		'employmentNav/paymentInformationNav/toPaymentInformationDetailV3/toPaymentInformationDetailV3USA',
		'emailNav',
		'emailNav/emailTypeNav',
		'phoneNav',
		'phoneNav/phoneTypeNav',
		'secondaryAssignmentsNav/allSfProcesses',
		'userAccountNav',
		'homeAddressNavDEFLT',
		'homeAddressNavDEFLT/stateNav'
	]
}