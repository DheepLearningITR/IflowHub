package src.main.resources.script

import java.time.LocalDate
import java.time.format.DateTimeFormatter

import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential

import groovy.json.JsonOutput

def processData(Message message) {
	String credentialName = message.getProperty('EC_Credential_Name')
	SecureStoreService secureStoreService = ITApiFactory.getService(SecureStoreService.class, null)
	UserCredential userCredential = secureStoreService.getUserCredential(credentialName)
	String companyId = userCredential.getCredentialProperties().get('sec:company.id')
	return processData(message, companyId)
}

def processData(Message message, String companyId) {
	def body = message.getBody(java.lang.String)
	def sfDataStructure = new XmlSlurper().parseText(body);
	def workforcePersons = mapSfToMdwDataStructure(sfDataStructure, companyId, message)
	def request = [ 'workforcePersons': workforcePersons ]
	message.setHeader('Content-Type', 'application/json')
	message.setBody(JsonOutput.toJson(request))
	return message
}

def mapSfToMdwDataStructure(def sfDataStructure, def companyId, def message) {
	def mdwWorkforcePersons = []
	
	def persons = XmlHelper.getSubObjectOrNull(sfDataStructure, 'PerPerson')
	def valueErrors = [:]
	Integer highestPersonId = null
	persons.each { person ->
		try {
			def personalInfos = XmlHelper.getSubObjectOrNull(person, 'personalInfoNav', 'PerPersonal')
			def employments = XmlHelper.getSubObjectOrNull(person, 'employmentNav', 'EmpEmployment')
			
			int personId = Integer.parseInt(XmlHelper.getValue(person, 'personId'))
			if (highestPersonId == null || personId > highestPersonId) {
			    highestPersonId = personId
			}
			def personUuid = XmlHelper.getValue(person, 'perPersonUuid')
			if (personUuid != null) {
				try {
					if (!personUuid.contains('-')) {
						// Format EC UUID if no dashes are present
						personUuid = personUuid.replaceAll('(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})', '$1-$2-$3-$4-$5').toLowerCase();
					}
					// Try to parse UUID
					UUID.fromString(personUuid)
				} catch (Exception e) {
					// If anything goes wrong with formatting, set person UUID to null
					personUuid = null
				}
			}
			
			def mdwWorkforcePerson = [:]
			
			mdwWorkforcePersons << mdwWorkforcePerson
			mdwWorkforcePerson.externalID = XmlHelper.getValue(person, 'personIdExternal')

			mdwWorkforcePerson.systemOfRecordKeys = []
			
			mdwWorkforcePerson.biographicalDetail = [:]
			mdwWorkforcePerson.biographicalDetail.dateOfBirth = XmlHelper.getValue(person,'dateOfBirth', ValueType.DATE)
			mdwWorkforcePerson.biographicalDetail.dateOfDeath = XmlHelper.getValue(person,'dateOfDeath', ValueType.DATE)
			
			def userAccount = XmlHelper.getSubObjectOrNull(person, 'userAccountNav', 'UserAccount')
			if (userAccount != null) {
				def username = XmlHelper.getValue(userAccount, 'username')
				if (username != null) {
					mdwWorkforcePerson.userAccount = [:]
					mdwWorkforcePerson.userAccount.ID = personUuid
					mdwWorkforcePerson.userAccount.userName = username
				}
			}
			
			mdwWorkforcePerson.personalDetails = []
			mdwWorkforcePerson.profileDetails = []
			personalInfos.each { personalInfo ->
				def personalDetails = [:]
				personalDetails.formOfAddress_code = XmlHelper.getValue(personalInfo, 'salutation')
				personalDetails.gender_code = XmlHelper.getValue(personalInfo, 'gender')
				personalDetails.nationality_code = CountryCodeMapper.getTwoLetterIsoCode(XmlHelper.getValue(personalInfo, 'nationality'))
				personalDetails.secondNationality_code = CountryCodeMapper.getTwoLetterIsoCode(XmlHelper.getValue(personalInfo, 'secondNationality'))
				personalDetails.thirdNationality_code = CountryCodeMapper.getTwoLetterIsoCode(XmlHelper.getValue(personalInfo, 'thirdNationality'))
				personalDetails.validFrom = XmlHelper.getValue(personalInfo, 'startDate', ValueType.DATE)
				personalDetails.validTo = addOneDay(XmlHelper.getValue(personalInfo, 'endDate', ValueType.DATE))
				mdwWorkforcePerson.personalDetails << personalDetails
				
				['', 'Alt1', 'Alt2'].each { suffix ->
					def profileDetails = [:]
					profileDetails.script_code = XmlHelper.getValue(personalInfo, "script$suffix")
					if (suffix == '') {
						profileDetails.birthName = XmlHelper.getValue(personalInfo, 'birthName')
						profileDetails.businessFirstName = XmlHelper.getValue(personalInfo, 'businessFirstName')
						profileDetails.businessLastName = XmlHelper.getValue(personalInfo, 'businessLastName')
						profileDetails.firstName = XmlHelper.getValue(personalInfo, 'firstName')
						profileDetails.formalName = XmlHelper.getValue(personalInfo, 'formalName')
						profileDetails.lastName = XmlHelper.getValue(personalInfo, 'lastName')
						profileDetails.middleName = XmlHelper.getValue(personalInfo, 'middleName')
						
						profileDetails.academicTitle_code = XmlHelper.getValue(personalInfo, 'title')
						profileDetails.additionalAcademicTitle_code = XmlHelper.getValue(personalInfo, 'secondTitle')
						profileDetails.initials = XmlHelper.getValue(personalInfo, 'initials')
						profileDetails.namePrefix_code = XmlHelper.getValue(personalInfo, 'namePrefix')
						profileDetails.nameSuffix_code = XmlHelper.getValue(personalInfo, 'suffix')
						profileDetails.nativePreferredLanguage_code = XmlHelper.getValue(personalInfo, 'nativePreferredLang')
						profileDetails.partnerName = XmlHelper.getValue(personalInfo, 'partnerName')
						profileDetails.partnerNamePrefix = XmlHelper.getValue(personalInfo, 'partnerNamePrefix')
						profileDetails.preferredName = XmlHelper.getValue(personalInfo, 'preferredName')
						profileDetails.secondLastName = XmlHelper.getValue(personalInfo, 'secondLastName')
					} else {
						if (profileDetails.script_code == null) {
							return
						}
						profileDetails.birthName = XmlHelper.getValue(personalInfo, "birthName$suffix")
						profileDetails.businessFirstName = XmlHelper.getValue(personalInfo, "businessFirstName$suffix")
						profileDetails.businessLastName = XmlHelper.getValue(personalInfo, "businessLastName$suffix")
						profileDetails.firstName = XmlHelper.getValue(personalInfo, "firstName$suffix")
						profileDetails.formalName = XmlHelper.getValue(personalInfo, "formalName$suffix")
						profileDetails.lastName = XmlHelper.getValue(personalInfo, "lastName$suffix")
						profileDetails.middleName = XmlHelper.getValue(personalInfo, "middleName$suffix")
					}
					profileDetails.validFrom = XmlHelper.getValue(personalInfo, 'startDate', ValueType.DATE)
					profileDetails.validTo = addOneDay(XmlHelper.getValue(personalInfo, 'endDate', ValueType.DATE))
					mdwWorkforcePerson.profileDetails << profileDetails
				}
			}
			
			def mdwWorkAssignmentsPerUserId = [:]
			mdwWorkforcePerson.workAssignments = []
			if (employments != null) {
				employments.each { employment ->
					def workAssignment = [:]
					def userId = XmlHelper.getValue(employment, 'userId')
					workAssignment.externalID = XmlHelper.getValue(employment, 'assignmentIdExternal')
					if (workAssignment.externalID == null) {
						workAssignment.externalID = userId
					}
					def originalStartDate = XmlHelper.getValue(employment, 'originalStartDate', ValueType.DATE)
					if (originalStartDate != null) {
					    workAssignment.startDate = originalStartDate
					} else {
					    workAssignment.startDate = XmlHelper.getValue(employment, 'startDate', ValueType.DATE)
					}
					workAssignment.endDate = XmlHelper.getValue(employment, 'endDate', ValueType.DATE)
					
					workAssignment.details = []
					mdwWorkforcePerson.workAssignments << workAssignment
					mdwWorkAssignmentsPerUserId[userId] = workAssignment
					
					def jobInfos = XmlHelper.getSubObjectOrNull(employment, 'jobInfoNav', 'EmpJob')
					if (jobInfos != null) {
						def jobInfoPerDate = [:]
						jobInfos.each { jobInfo ->
							def date = XmlHelper.getValue(jobInfo, 'startDate', ValueType.DATE)
							def seqNumber = XmlHelper.getValue(jobInfo, 'seqNumber', ValueType.INTEGER)
							def jobInfoForDate = jobInfoPerDate.get(date)
							def seqNumberForDate = XmlHelper.getValue(jobInfoForDate, 'seqNumber', ValueType.INTEGER)
							if (seqNumberForDate == null) {
								seqNumberForDate = 0
							} else {
								seqNumberForDate = seqNumberForDate.intValue()
							}
							if (jobInfoForDate == null || (seqNumber > seqNumberForDate)) {
								jobInfoPerDate[date] = jobInfo
							}
						}
						jobInfos = jobInfoPerDate.values()

						workAssignment.jobDetails = []
						jobInfos.each { jobInfo ->
							def manager = XmlHelper.getSubObjectOrNull(jobInfo, 'managerUserNav', 'User', 'empInfo', 'EmpEmployment')
							
							def jobDetail = [:]
							jobDetail.legalEntityExternalID = XmlHelper.getValue(jobInfo, 'company')
							if (jobDetail.legalEntityExternalID == null || jobDetail.legalEntityExternalID.length() > 4) {
								jobDetail.legalEntityExternalID = ''
							}
							jobDetail.country_code = CountryCodeMapper.getTwoLetterIsoCode(XmlHelper.getValue(jobInfo, 'countryOfCompany'))
							String costCenterExternalID = XmlHelper.getValue(jobInfo, 'costCenter')
							if (costCenterExternalID != null && costCenterExternalID.length() > 4) {
								costCenterExternalID = costCenterExternalID.substring(4)
								if (costCenterExternalID.length() > 10) {
									costCenterExternalID = costCenterExternalID.substring(0, 10)
								}
							}
							jobDetail.costCenterExternalID = costCenterExternalID
							jobDetail.jobExternalID = XmlHelper.getValue(jobInfo, 'jobCode')
							jobDetail.jobTitle = XmlHelper.getValue(jobInfo, 'jobTitle')
							if (manager != null) {
								jobDetail.supervisorWorkAssignmentExternalID = XmlHelper.getValue(manager, 'assignmentIdExternal')
								if (jobDetail.supervisorWorkAssignmentExternalID == null) {
									jobDetail.supervisorWorkAssignmentExternalID = XmlHelper.getValue(manager, 'userId')
								}
							}
							jobDetail.status_code = XmlHelper.getValue(jobInfo, 'emplStatus')
							jobDetail.fte = round(XmlHelper.getValue(jobInfo, 'fte', ValueType.DOUBLE))
							jobDetail.workingHoursPerWeek = round(XmlHelper.getValue(jobInfo, 'standardHours', ValueType.DOUBLE))
							jobDetail.workingDaysPerWeek = round(XmlHelper.getValue(jobInfo, 'workingDaysPerWeek', ValueType.DOUBLE))

							// check double fields for correct values, e.g. fte cannot be larger than 9.99
							def valueError = [:]
							valueError.messages = []
							if (jobDetail.fte >= 10) {
								valueError.externalID = mdwWorkforcePerson.externalID
								valueError.messages << "Invalid value for field 'fte': $jobDetail.fte"
								jobDetail.fte = null
							}
							if (jobDetail.workingDaysPerWeek >= 10) {
								valueError.externalID = mdwWorkforcePerson.externalID
								valueError.messages << "Invalid value for field 'workingDaysPerWeek': $jobDetail.workingDaysPerWeek"
								jobDetail.workingDaysPerWeek = null
							}
							if (jobDetail.workingHoursPerWeek >= 1000) {
								valueError.externalID = mdwWorkforcePerson.externalID
								valueError.messages << "Invalid value for field 'workingHoursPerWeek': $jobDetail.workingHoursPerWeek"
								jobDetail.workingHoursPerWeek = null
							}
							if (valueError.externalID != null) {
								valueErrors[personUuid] = valueError
							}
							
							jobDetail.validFrom = XmlHelper.getValue(jobInfo, 'startDate', ValueType.DATE)
							jobDetail.validTo = addOneDay(XmlHelper.getValue(jobInfo, 'endDate', ValueType.DATE))
							workAssignment.jobDetails << jobDetail
						}
					}
					
					def systemOfRecordKey = [:]
					systemOfRecordKey.systemOfRecordID = companyId
					systemOfRecordKey.systemOfRecordWorkforcePersonID = personUuid == null ? mdwWorkforcePerson.externalID : personUuid
					systemOfRecordKey.systemOfRecordWorkAssignmentID = XmlHelper.getValue(employment, 'userId')
					systemOfRecordKey.isCurrentSystemOfRecord = true
					systemOfRecordKey.workAssignmentExternalID = workAssignment.externalID
					mdwWorkforcePerson.systemOfRecordKeys << systemOfRecordKey
					
					workAssignment.paymentDetails = []
					def paymentInfos = XmlHelper.getSubObjectOrNull(employment, 'paymentInformationNav', 'PaymentInformationV3')
					if (paymentInfos != null) {
						paymentInfos.each { paymentInfo ->
							def paymentDetails = XmlHelper.getSubObjectOrNull(paymentInfo, 'toPaymentInformationDetailV3', 'PaymentInformationDetailV3')
							if (paymentDetails != null) {
								paymentDetails.each { paymentDetail ->
									def bankCountry = XmlHelper.getValue(paymentDetail, 'bankCountry')
									def paymentDetailLocal = paymentDetail."toPaymentInformationDetailV3${bankCountry}"
									if (paymentDetailLocal != null) {
										if (paymentDetailLocal."PaymentInformationDetailV3${bankCountry}" != null) {
											paymentDetailLocal = paymentDetail."toPaymentInformationDetailV3${bankCountry}"."PaymentInformationDetailV3${bankCountry}"
										} else {
											paymentDetailLocal = null
										}
									}
									
									def mdwPaymentDetail = [:]
									mdwPaymentDetail.paymentType_code = XmlHelper.getValue(paymentDetail, 'payType')
									mdwPaymentDetail.paymentMethod_code = XmlHelper.getValue(paymentDetail, 'paymentMethod') // Value currently is '05' for example. Is this the correct value?
									mdwPaymentDetail.bankAccountHolderName = XmlHelper.getValue(paymentDetail, 'accountOwner')
									mdwPaymentDetail.IBAN = XmlHelper.getValue(paymentDetail, 'iban')
									mdwPaymentDetail.bankNumber = XmlHelper.getValue(paymentDetail, 'routingNumber')
									mdwPaymentDetail.businessIdentifierCode = XmlHelper.getValue(paymentDetail, 'businessIdentifierCode')
									mdwPaymentDetail.bankAccount = XmlHelper.getValue(paymentDetail, 'accountNumber')
									mdwPaymentDetail.bankAccountType_code = XmlHelper.getValue(paymentDetailLocal, 'accountType') // Country specific
									// mdwPaymentDetail.bankControlKey_code = XmlHelper.getValue(paymentDetailLocal, 'checkDigit') // TODO not applicable for GER/USA
									// mdwPaymentDetail.bankAccountReference = null // TODO not applicable for GER/USA (?)
									mdwPaymentDetail.bankAccountCurrency_code = XmlHelper.getValue(paymentDetail, 'currency')
									mdwPaymentDetail.bankCountry_code = CountryCodeMapper.getTwoLetterIsoCode(bankCountry)
									// mdwPaymentDetail.additionalPaymentReference = XmlHelper.getValue(paymentDetailLocal, 'paymentReference') // TODO not applicable for GER/USA(?)
									mdwPaymentDetail.validFrom = XmlHelper.getValue(paymentInfo, 'effectiveStartDate', ValueType.DATE)
									mdwPaymentDetail.validTo = addOneDay(XmlHelper.getValue(paymentInfo, 'effectiveEndDate', ValueType.DATE))
									workAssignment.paymentDetails << mdwPaymentDetail
								}
							}
						}
					}
				}
				ProcessPrimaryAssignmentDetermination d = new ProcessPrimaryAssignmentDetermination()
				d.setWorkAssignmentDetails(person, mdwWorkforcePerson.workAssignments)
			}
			
			def addresses = XmlHelper.getSubObjectOrNull(person, 'homeAddressNavDEFLT', 'PerAddressDEFLT')
			AddressMapper addressMapper = new AddressMapper(person, addresses)
			addressMapper.setPrivateAddresses(mdwWorkforcePerson, mdwWorkAssignmentsPerUserId)

			mdwWorkforcePerson.emails = []
			def emails = XmlHelper.getSubObjectOrNull(person, 'emailNav', 'PerEmail')
			if (emails != null) {
				emails.each { email ->
					def mdwEmail = [:]
					mdwEmail.usage_code = XmlHelper.getValue(email, 'emailType')
					mdwEmail.address = XmlHelper.getValue(email, 'emailAddress')
					mdwEmail.description = null // Empty when coming from EC
					mdwEmail.isDefault = XmlHelper.getValue(email, 'isPrimary', ValueType.BOOLEAN)
					mdwWorkforcePerson.emails << mdwEmail
				}
			}
			
			mdwWorkforcePerson.phones = []
			def phones = XmlHelper.getSubObjectOrNull(person, 'phoneNav', 'PerPhone')
			if (phones != null) {
				phones.each { phone ->
					def mdwPhone = [:]
					def areaCode = XmlHelper.getValue(phone, 'areaCode')
					def countryCode = XmlHelper.getValue(phone, 'countryCode')
					def extension = XmlHelper.getValue(phone, 'extension')
					def phoneNumber = XmlHelper.getValue(phone, 'phoneNumber')
					if (countryCode != null) {
						// If countryCode contains the German or US country dial code, then we explicitly set 'DE' or 'US'.
						// Otherwise we check if the countryCode contains a three letter ISO code and try to map it to a two letter ISO code.
						def mappedCountryCode = null
						if ('+49'.equals(countryCode) || '0049'.equals(countryCode) || '49'.equals(countryCode)) {
							mappedCountryCode = 'DE'
						} else if ('+1'.equals(countryCode) || '001'.equals(countryCode) || '1'.equals(countryCode)) {
							mappedCountryCode = 'US'
						} else {
							mappedCountryCode = CountryCodeMapper.getTwoLetterIsoCode(countryCode)
						}
						if (mappedCountryCode != null) {
							// If we found a mapping then set the countryCode to null so that it does not get added to the final number
							countryCode = null
						}
						mdwPhone.country_code = mappedCountryCode
					}
					StringBuilder number = new StringBuilder()
					if (countryCode) {
						number.append(countryCode)
					}
					if (areaCode) {
						if (number.length() > 0) {
							number.append('-')
						}
						number.append(areaCode)
					}
					if (phoneNumber) {
						if (number.length() > 0) {
							number.append('-')
						}
						number.append(phoneNumber)
					}
					if (extension) {
						number.append(";ext=$extension")
					}
					mdwPhone.usage_code = XmlHelper.getValue(phone, 'phoneType')
					mdwPhone.number = number.toString()
					mdwPhone.description = null // Empty when coming from EC
					mdwPhone.isDefault = XmlHelper.getValue(phone, 'isPrimary', ValueType.BOOLEAN)
					mdwWorkforcePerson.phones << mdwPhone
				}
			}
		} catch (Throwable t) {
			throw new Exception(JsonOutput.toJson(person), t)
		}
	}
	if (highestPersonId != null) {
	    message.setProperty('HIGHEST_PERSON_ID', highestPersonId.toString())
	}
	// Always set value errors to overwrite old values in message
	message.setProperty('VALUE_ERRORS', valueErrors)
	return mdwWorkforcePersons
}

def static addOneDay(def date) {
	if (date == null || date == '9999-12-31') {
		return date
	}
	def dateFormat = DateTimeFormatter.ofPattern('yyyy-MM-dd')
	LocalDate localDate = LocalDate.parse(date, dateFormat)
	localDate = localDate.plusDays(1)
	return dateFormat.format(localDate)
}

def static round(def d) {
	if (d == null) {
		return null
	}
	return Math.round(d * 100) / 100
}