package src.main.resources.script

import com.sap.gateway.ip.core.customdev.util.Message

import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def processData(Message message) {
	def body = message.getBody(java.lang.String)
	def mdwResponse = new JsonSlurper().parseText(body)
	def mdwErrors = message.getProperty('MDW_ERRORS') // read from variable first
	def valueErrors = message.getProperty('VALUE_ERRORS')
	if (mdwErrors == null || mdwErrors.isEmpty()) {
		mdwErrors = [:]
	} else {
		mdwErrors = new JsonSlurper().parseText(mdwErrors)
	}
	mdwResponse.successes.each { entry ->
		mdwErrors.remove(entry.systemOfRecordWorkforcePersonID)
	}
	mdwResponse.errors.each { entry ->
		mdwErrors[entry.systemOfRecordWorkforcePersonID] = entry
	}
	valueErrors.each { entry -> 
		mdwErrors[entry.key] = entry.value
	}
	message.setProperty('MDW_ERRORS', JsonOutput.toJson(mdwErrors)) // write to variable afterwards
	return message
}