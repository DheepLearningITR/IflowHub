package src.main.resources.script

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def lastModifiedDateTime = message.getProperty('LAST_MODIFIED_DATETIME')
    def userSetLastModifiedDateTime = message.getProperty('USER_SET_LAST_MODIFIED_DATETIME')
	def commonFilterString = message.getProperty('QUERY_FILTER_STRING_COMMON')
    if (userSetLastModifiedDateTime != null && !userSetLastModifiedDateTime.isEmpty()) {
        lastModifiedDateTime = userSetLastModifiedDateTime
    }
    def filterString = commonFilterString + " and (lastModifiedDateTime gt datetimeoffset'$lastModifiedDateTime'" +
		" or userAccountNav/lastModifiedDateTime gt datetimeoffset'$lastModifiedDateTime'" +
		" or personalInfoNav/lastModifiedDateTime gt datetimeoffset'$lastModifiedDateTime'" +
		" or employmentNav/lastModifiedDateTime gt datetimeoffset'$lastModifiedDateTime'" +
		" or employmentNav/jobInfoNav/lastModifiedDateTime gt datetimeoffset'$lastModifiedDateTime'" +
		" or employmentNav/paymentInformationNav/lastModifiedDateTime gt datetimeoffset'$lastModifiedDateTime'" +
		" or homeAddressNavDEFLT/lastModifiedDateTime gt datetimeoffset'$lastModifiedDateTime'" +
		" or emailNav/lastModifiedDateTime gt datetimeoffset'$lastModifiedDateTime'" +
		" or phoneNav/lastModifiedDateTime gt datetimeoffset'$lastModifiedDateTime'" +
		" or secondaryAssignmentsNav/lastModifiedDateTime gt datetimeoffset'$lastModifiedDateTime')"
		.toString()
    message.setProperty('PERSON_IDS_FILTER', filterString)
    
	def logHelper = new LogHelper(messageLogFactory, message)
	logHelper.logString('Query filter string', filterString);
    return message;
}