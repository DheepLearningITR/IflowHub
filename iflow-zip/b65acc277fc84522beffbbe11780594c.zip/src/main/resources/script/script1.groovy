import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    def properties = message.getProperties()
    
    message.setProperty("P_messageHeaderId", java.util.UUID.randomUUID())
    message.setProperty("P_messageRequestHeaderId", java.util.UUID.randomUUID())
    
    
    def salesDocument = properties.get("P_SalesOrder")
    def senderBusinessSystem = properties.get("P_SenderBusinessSystem")
    
   
    // Construct query string
    def relatedObjectFilter = "\$filter=relatedObjectDisplayId eq '${salesDocument}' and relatedObjectType eq '30' and communicationSystemDisplayId eq '${senderBusinessSystem}'"
    
    message.setProperty("P_relatedObjectFilter", relatedObjectFilter)
    return message;
}