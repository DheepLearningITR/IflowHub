import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message)
 {
    def body = message.getBody(String.class);
    
     message.setProperty("isCodelistPresent" , false);
    def codeListResponse = new JsonSlurper().parseText(body);
    codeListResponse.each {
        message.setProperty("codeListID",it.id);
        message.setProperty("isCodelistPresent" , true);
        
    }
    return message;             
 }