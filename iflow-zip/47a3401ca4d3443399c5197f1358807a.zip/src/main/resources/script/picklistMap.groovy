import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    //Body

    def messageLog = messageLogFactory.getMessageLog(message)

    def districtMap = [:]

    def key, value = ["", ""]

    def body = message.getBody(java.io.Reader)

    def PickList = new XmlSlurper().parse(body)

    PickList.Picklist.picklistOptions.PicklistOption.each { eachValue ->

        value = eachValue.localeLabel.toString()
        key = eachValue.externalCode.toString()
        districtMap.put(key, value)

    }

    message.setProperty("districtMap", districtMap)

    return message;

}