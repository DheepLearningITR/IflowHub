import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.nio.charset.StandardCharsets;

//import src.main.resources.script.UltilityClass; // < Common Class if Any>

def Message HIREREHIRE(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    def logMessage = message.getProperty("logging").toString()
    def delayTime = message.getProperty("delayTime")

    def (RECTY, USRID, CLNAM, CNAME, PHONE, EMAIL, FNAME, RUNDT, RUNTM, RUNTY, VERNO, AUTH1, AUTH2, KEY03, CONTYP, CONVAL, AFNAM, PDFLG, PDORG, PDLOADID, FGSCD) = []

    RECTY = USRID = CLNAM = CNAME = PHONE = EMAIL = FNAME = RUNDT = RUNTM = RUNTY = VERNO = AUTH1 = AUTH2 = KEY03 = CONTYP = CONVAL = AFNAM = PDFLG = PDORG = PDLOADID = FGSCD = ''
    RECTY = 'HEADR'
    USRID = ''
    CLNAM = ''
    CNAME = ''
    RUNDT = ''
    RUNTM = ''
    FNAME = ''
    RUNTY = ''

    def payrollFileHeaderLine = RECTY + '|"' + USRID + '|"' + CLNAM + '|"' + CNAME + '|"' + PHONE + '|"' + EMAIL + '|"' + FNAME + '|"' + RUNDT + '|"' + RUNTM + '|"' + RUNTY + '|"' + VERNO + '|"' + AUTH1 + '|"' + AUTH2 + '|"' + KEY03 + '|"' + CONTYP + '|"' + CONVAL + '|"' + AFNAM + '|"' + PDFLG + '|"' + PDORG + '|"' + PDLOADID + '|"' + FGSCD + "\n"

    def fileGenerationParam = message.getProperty("generateFile").toString()

    def storeData = new XmlSlurper().parse(message.getBody(java.io.Reader));
    def finalPayload = ""
    def generateFile = false

    def sortedPayload = ""
    def counterRecords = -1

    storeData.message.each { eachMessage ->
        byte[] decoded = eachMessage.payload.text().decodeBase64()
        finalPayload = finalPayload + new String(decoded, StandardCharsets.UTF_8)
        if (generateFile != true && !finalPayload.toString().isEmpty())
            generateFile = true
        counterRecords++
    }

    String[] lines = finalPayload.split("\r\n|\r|\n");
    
    def recordCount = 0
    
    if(generateFile == false)
        recordCount = lines.length +1
    else
        recordCount = lines.length +2  
    
    sortedPayload = (payrollFileHeaderLine + finalPayload + 'TRAIL' + '|"' + recordCount.toString()).toString().trim()

    message.setProperty("generateFile", generateFile.toString())

    if (fileGenerationParam.equalsIgnoreCase("No"))
        message.setProperty("generateFile", "false")

    message.setBody(sortedPayload)

    if (logMessage.equalsIgnoreCase("Yes") || logMessage.equalsIgnoreCase("High")) {
        messageLog.addAttachmentAsString("#SFTP-PayrollFile(HIREREHIRE)", "generateFile:" + message.getProperty("generateFile").toString() + "\n\n" + sortedPayload, "text/plain");
    }
    
    sleep(Integer.parseInt(delayTime))
    return message;
}

def Message TERMINATION(Message message) {

    //def utilityDecidium = new UltilityADPDecidium()
    def messageLog = messageLogFactory.getMessageLog(message);
    def logMessage = message.getProperty("logging").toString()
    def delayTime = message.getProperty("delayTime")
    //def payrollFileHeaderLine = utilityDecidium.payrollFileEmployeeTemplate() + "\r\n"
    def (RECTY, USRID, CLNAM, CNAME, PHONE, EMAIL, FNAME, RUNDT, RUNTM, RUNTY, VERNO, AUTH1, AUTH2, KEY03, CONTYP, CONVAL, AFNAM, PDFLG, PDORG, PDLOADID, FGSCD) = []

    RECTY = USRID = CLNAM = CNAME = PHONE = EMAIL = FNAME = RUNDT = RUNTM = RUNTY = VERNO = AUTH1 = AUTH2 = KEY03 = CONTYP = CONVAL = AFNAM = PDFLG = PDORG = PDLOADID = FGSCD = ''
    RECTY = 'HEADR'
    USRID = ''
    CLNAM = ''
    CNAME = ''
    RUNDT = ''
    RUNTM = ''
    FNAME = ''
    RUNTY = ''

    def payrollFileHeaderLine = RECTY + '|"' + USRID + '|"' + CLNAM + '|"' + CNAME + '|"' + PHONE + '|"' + EMAIL + '|"' + FNAME + '|"' + RUNDT + '|"' + RUNTM + '|"' + RUNTY + '|"' + VERNO + '|"' + AUTH1 + '|"' + AUTH2 + '|"' + KEY03 + '|"' + CONTYP + '|"' + CONVAL + '|"' + AFNAM + '|"' + PDFLG + '|"' + PDORG + '|"' + PDLOADID + '|"' + FGSCD + "\n"

    def fileGenerationParam = message.getProperty("generateFile").toString()

    def storeData = new XmlSlurper().parse(message.getBody(java.io.Reader));
    def finalPayload = ""
    def generateFile = false

    def sortedPayload = ""
    def counterRecords = -1

    storeData.message.each { eachMessage ->
        byte[] decoded = eachMessage.payload.text().decodeBase64()
        finalPayload = finalPayload + new String(decoded, StandardCharsets.UTF_8)
        if (generateFile != true && !finalPayload.toString().isEmpty())
            generateFile = true
        counterRecords++
    }

    String[] lines = finalPayload.split("\r\n|\r|\n");

    def recordCount = 0
    
    if(generateFile == false)
        recordCount = lines.length +1
    else
        recordCount = lines.length +2  
    
    sortedPayload = (payrollFileHeaderLine + finalPayload + 'TRAIL' + '|"' + recordCount.toString()).toString().trim()

    message.setProperty("generateFile", generateFile.toString())

    if (fileGenerationParam.equalsIgnoreCase("No"))
        message.setProperty("generateFile", "false")

    message.setBody(sortedPayload)

    if (logMessage.equalsIgnoreCase("Yes") || logMessage.equalsIgnoreCase("High")) {
        messageLog.addAttachmentAsString("#SFTP-PayrollFile-(TERMINATION)", sortedPayload, "text/plain");
    }
    
    sleep(Integer.parseInt(delayTime))

    return message;
}

def Message DAILYCHANGES(Message message) {

    //def utilityDecidium = new UltilityADPDecidium()
    def messageLog = messageLogFactory.getMessageLog(message);
    def logMessage = message.getProperty("logging").toString()
    def delayTime = message.getProperty("delayTime")
        
    //def payrollFileHeaderLine = utilityDecidium.payrollFileEmployeeTemplate() + "\r\n"
    def (RECTY, USRID, CLNAM, CNAME, PHONE, EMAIL, FNAME, RUNDT, RUNTM, RUNTY, VERNO, AUTH1, AUTH2, KEY03, CONTYP, CONVAL, AFNAM, PDFLG, PDORG, PDLOADID, FGSCD) = []

    RECTY = USRID = CLNAM = CNAME = PHONE = EMAIL = FNAME = RUNDT = RUNTM = RUNTY = VERNO = AUTH1 = AUTH2 = KEY03 = CONTYP = CONVAL = AFNAM = PDFLG = PDORG = PDLOADID = FGSCD = ''
    RECTY = 'HEADR'
    USRID = ''
    CLNAM = ''
    CNAME = ''
    RUNDT = ''
    RUNTM = ''
    FNAME = ''
    RUNTY = ''

    def payrollFileHeaderLine = RECTY + '|"' + USRID + '|"' + CLNAM + '|"' + CNAME + '|"' + PHONE + '|"' + EMAIL + '|"' + FNAME + '|"' + RUNDT + '|"' + RUNTM + '|"' + RUNTY + '|"' + VERNO + '|"' + AUTH1 + '|"' + AUTH2 + '|"' + KEY03 + '|"' + CONTYP + '|"' + CONVAL + '|"' + AFNAM + '|"' + PDFLG + '|"' + PDORG + '|"' + PDLOADID + '|"' + FGSCD + "\n"

    def fileGenerationParam = message.getProperty("generateFile").toString()

    def storeData = new XmlSlurper().parse(message.getBody(java.io.Reader));
    def finalPayload = ""
    def generateFile = false

    def sortedPayload = ""
    def counterRecords = -1

    storeData.message.each { eachMessage ->
        byte[] decoded = eachMessage.payload.text().decodeBase64()
        finalPayload = finalPayload + new String(decoded, StandardCharsets.UTF_8)
        if (generateFile != true && !finalPayload.toString().isEmpty())
            generateFile = true
        counterRecords++
    }

    String[] lines = finalPayload.split("\r\n|\r|\n");
    def recordCount = 0
    
    if(generateFile == false)
        recordCount = lines.length +1
    else
        recordCount = lines.length +2  
    
    sortedPayload = (payrollFileHeaderLine + finalPayload + 'TRAIL' + '|"' + recordCount.toString()).toString().trim()

    message.setProperty("generateFile", generateFile.toString())

    if (fileGenerationParam.equalsIgnoreCase("No"))
        message.setProperty("generateFile", "false")

    message.setBody(sortedPayload)

    if (logMessage.equalsIgnoreCase("Yes") || logMessage.equalsIgnoreCase("High")) {
        messageLog.addAttachmentAsString("#SFTP-PayrollFile-(DAILYCHANGES)", sortedPayload, "text/plain");
    }
    
    sleep(Integer.parseInt(delayTime))
    return message;
}





