import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	//Body 	
	def logging = message.getProperty("logging")
	def loopIndex = message.getProperty("CamelLoopIndex")
	//Headers 
		if(logging.equalsIgnoreCase("High") && loopIndex.toString().equalsIgnoreCase("0"))
		{
      	def messageLog = messageLogFactory.getMessageLog(message);
		messageLog.addAttachmentAsString("districtMap",message.getProperty("districtMap").toString(),"text/plain");
		messageLog.addAttachmentAsString("Raw-CEExtract",message.getBody(String),"text/xml");
		}

	return message;
}

