    package main.resources.script
    import com.sap.gateway.ip.core.customdev.util.Message;

    import org.jdom.Element;
    import java.util.HashMap;
    import java.text.DateFormat;
    import java.text.SimpleDateFormat;
    import java.util.Date;

    import groovy.xml.StreamingMarkupBuilder

    import java.io.File;
    import java.io.IOException;
    import java.io.PrintWriter;
    import java.text.SimpleDateFormat
    import java.util.HashMap;
    import java.util.List;
    import java.util.Scanner;

    import org.jdom.Content;
    import org.jdom.Document;
    import org.jdom.Element
    import org.jdom.JDOMException;
    import org.jdom.input.SAXBuilder;
    import org.jdom.output.XMLOutputter
    import org.jdom.output.Format
    import org.jaxen.JaxenException;
    import org.jaxen.SimpleNamespaceContext;
    import org.jaxen.XPath;
    import org.jaxen.jdom.JDOMXPath
    import org.jdom.Namespace;

    import org.apache.commons.io.IOUtils;
    import java.nio.charset.StandardCharsets;

    def Message processData(Message message) {

        def dataContext = message.getBody(java.io.InputStream);
        String inputPayload = IOUtils.toString(dataContext, StandardCharsets.UTF_8);

// Build XML Document
        SAXBuilder builder = new SAXBuilder();

//E.O. input xml doc containing 1..n CompoundEmployee entries
        Document inputDoc = builder.build(new StringReader(inputPayload));

//E.O. global document to hold all denormalized CompoundEmployee entries
        Element outputDocRoot = new Element("queryCompoundEmployeeResponse");
        Document outputDoc = new Document(outputDocRoot);

//select all CompoundEmployee nodes in queryCompoundEmployeeResponse
        XPath xPathCompoundEmployees = new JDOMXPath("//CompoundEmployee");
        List compoundEmployeeEntries =  xPathCompoundEmployees.selectNodes(inputDoc);

//E.O. main loop over CompoundEmployee entries
        for (Element compoundEmployeeEntry : compoundEmployeeEntries)
        {
            //E. O.  denormalize CompoundEmployee and add to outputDoc
            outputDocRoot.addContent(processSingleComoundEmp(compoundEmployeeEntry.clone()).clone());

        }

        // When you're finished manipulating the XML data, you'll need to output the Document's data to an InputStream to pass to the next step in your Process work flow.
        ByteArrayOutputStream bo = new ByteArrayOutputStream(); //E.O. moved from top
        Format format = Format.getPrettyFormat();
        format.setEncoding("UTF-8");
        XMLOutputter xmlout = new XMLOutputter(format);
        xmlout.output(outputDoc, bo); //changed to global doc
        message.setBody(bo.toString("UTF-8"))
        return message;
    }

    def Element processSingleComoundEmp(Element compoundEmployeeEntry)
    {
        // List effectiveDatedNames = ["compensation_information", "employment_information", "personal_information", "address_information", "alternative_cost_distribution", "deduction_recurring", "payment_information"];
        // List includeLatest = ["personal_information", "address_information"];

        List effectiveDatedNames = ["personal_information","job_information", "employment_information","dependent_information","dependent_relation_information","address_information"];//"PaymentInformationDetailV3","cust_EmpBen_Parent"
        //List effectiveDatedNames = ["personal_information","job_information", "employment_information","address_information"];//"PaymentInformationDetailV3","cust_EmpBen_Parent"
        List includeLatest = ["dependent_information"];


        // Here's how to grab values from the current data
        // Determine Current Date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date currentDate = new Date();

        //get all nodes with start_date and effectiveStarteDate elements
        XPath xPathAllStartDatesContainingNodes = new JDOMXPath("//effectiveStartDate/.. | //start_date/..");

        //get all children of person element
        XPath xPathPersonChildren = new JDOMXPath("/CompoundEmployee/person/*");

        //E.O. create document holding current CompoundEmployee entry
        Document doc = new Document(compoundEmployeeEntry);//removed clone

        //Target structure
        Element newDocRoot = new Element("CompoundEmployee");
        Element person = new Element("person");
        newDocRoot.addContent(person);

        //add all nodes  without effective date to target structure
        for(Element child: xPathPersonChildren.selectNodes(doc))
        {
            if (!effectiveDatedNames.contains(child.getName()))
                person.addContent(child.clone());

        }


        List employeeNodesContainingStartDates = xPathAllStartDatesContainingNodes.selectNodes(doc);

        //build sorted set for all start dates
        SortedSet sortedStartDates = new TreeSet();

        //collect dates from dated elements and add the dates to sorted set (only collect start date in elements where end date exists either)
        for (Element employeeNode : employeeNodesContainingStartDates)
        {

            if (isEffectiveDatedEntity(employeeNode)){

                sortedStartDates.add(employeeNode?.getChildText("effectiveStartDate", employeeNode.getNamespace()));

            } else if (isStartEndDatedEntity(employeeNode))
            {
                sortedStartDates.add(employeeNode?.getChildText("start_date", employeeNode.getNamespace()));
            }
        }

        int snapshotsAmount = sortedStartDates.size();
        int currentSnapshotNumber = 0;


        if(snapshotsAmount==0)
        {

            Element snapShotElement = new Element("snapshot");
            Element employmentElement = new Element("employment_information");
            person.addContent(snapShotElement);

            Element dateElement = new Element("asOfDate");
            dateElement.setText(new Date().format("yyyy-MM-dd"));
            snapShotElement.addContent(dateElement);
            snapShotElement.addContent(employmentElement)
        
        }

        for (String snapShotDate:sortedStartDates)
        {

            currentSnapshotNumber++;

            Document clonedDoc = doc.clone();

            employeeNodesContainingStartDates = xPathAllStartDatesContainingNodes.selectNodes(clonedDoc);

            //Create snapshot structure
            Element snapShotElement = new Element("snapshot");
            person.addContent(snapShotElement);
            Element dateElement = new Element("asOfDate");
            dateElement.setText(snapShotDate);
            snapShotElement.addContent(dateElement);

            currentDate = dateFormat.parse(snapShotDate);

            //remove data not relevant for snapshot (Note: employment_information is neither isStartEndDatedEntity nor isEffectiveDatedEntity and will be kept anyway)
            for (Element employeeNode : employeeNodesContainingStartDates)
            {
                if(isStartEndDatedEntity(employeeNode)){

                    Date startDate = dateFormat.parse(employeeNode.getChildText("start_date", employeeNode.getNamespace()))
                    Date endDate;

                    if(employeeNode.getChildText("end_date", employeeNode.getNamespace())==null || employeeNode.getChildText("end_date", employeeNode.getNamespace())=="")
                        endDate = dateFormat.parse("9999-12-31")
                    else
                        endDate = dateFormat.parse(employeeNode.getChildText("end_date", employeeNode.getNamespace()))

                    //println "***READ STARTENDDATE"+employeeNode+"StartDate:"+startDate+" > "+"SnapshotDate:"+currentDate+" > "+"EndDate:"+endDate



                    //Date outside current date range  must be removed
                    if (currentDate < startDate || currentDate > endDate)
                    {

                        //println "***REMOVE STARTENDDATE"+employeeNode
                        //Remove node outside the current date range
                        employeeNode.getParent().removeContent(employeeNode);
                    }
                }
                else if(isEffectiveDatedEntity(employeeNode))
                {
                    Date startDate = dateFormat.parse(employeeNode.getChildText("effectiveStartDate", employeeNode.getNamespace()))
                    //Date endDate = dateFormat.parse(employeeNode?.getChildText("effectiveEndDate", employeeNode.getNamespace()))


                    Date endDate;

                    if(employeeNode.getChildText("effectiveEndDate", employeeNode.getNamespace())==null || employeeNode.getChildText("end_date", employeeNode.getNamespace())=="")
                        endDate = dateFormat.parse("9999-12-31")
                    else
                        endDate = dateFormat.parse(employeeNode?.getChildText("effectiveEndDate", employeeNode.getNamespace()))


                    //Date outside current date range  must be removed
                    if ((currentDate < startDate) || currentDate > endDate)
                    {
                        //Remove node outside the current date range
                        employeeNode.getParent().removeContent(employeeNode);
                    }
                }

            }


            for(Element child: xPathPersonChildren.selectNodes(clonedDoc))
            {
                if (effectiveDatedNames.contains(child.getName()))
                {
                    snapShotElement.addContent(child.clone());
                }

                if (includeLatest.contains(child.getName()) && currentSnapshotNumber == snapshotsAmount) //latest snapshot means latest valid period means includelatest!
                {
                    person.addContent(child.clone());
                }
            }
        }

        return newDocRoot;

    }

    //returns true in case element has effectiveStartDate and effectiveEndDate element
    def boolean isEffectiveDatedEntity(Element employeeNode)
    {

        boolean result = false;

        if(employeeNode.name == "deduction_recurring" || employeeNode.name == "alternative_cost_distribution" || employeeNode.name == "PaymentInformationV3" || employeeNode.name =="cust_EmpBen_Parent")
        {
            result =  (employeeNode.getChildText("effectiveStartDate", employeeNode.getNamespace())!=null);
        }

        return result;

    }

    //returns true in case element has start_date and end_date element
    def boolean isStartEndDatedEntity(Element employeeNode)
    {
        boolean result = false;

        if (employeeNode.name != "deduction_recurring" && employeeNode.name != "alternative_cost_distribution" && employeeNode.name != "employment_information")  //&& employeeNode.name != "employment_information"
        {
            result =  (employeeNode.getChildText("start_date", employeeNode.getNamespace())!=null);
        }

        return result;
    }