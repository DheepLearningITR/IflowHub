import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import javax.activation.DataHandler;

def Message processEvent(Message message) {
    //Body 
    def body = message.getBody(String.class);
    JsonSlurper slurper = new JsonSlurper();
    Map parsedJson = slurper.parseText(body);
    def type;
  
    switch(parsedJson.type) {
        case "sap.s4.beh.salesquotation.v1.SalesQuotation.Created.v1":
            type = "Sales Quotation Created";
            break;
        default:
            type = "NA";
    }
   // type = "Sales Quotation Created";
    message.setProperty("eventType", type);
    
    if(type != "NA"){
        message.setProperty("processDefinitionId", "managesalesquotation");
        message.setProperty("processInstanceId", parsedJson.data.SalesQuotation);
        message.setProperty("eventTimestamp", parsedJson.time);
        message.setProperty("orderId", parsedJson.data.SalesQuotation);
    }
      
    return message;
    
}

def Message processSalesQuotation(Message message) {

  def body = message.getBody(String.class);
    def salesQuotation;
    String[] reasonList;
    def salesQuotationApprovalReason;
    def payload = new groovy.json.JsonBuilder()
    def ApprovalRelevance = "Not Relevant";
    
    JsonSlurper slurper = new JsonSlurper();
    Map parsedJson = slurper.parseText(body);
    
    if (parsedJson.d != null) {
        salesQuotation = parsedJson.d.results[0];
        salesQuotation.remove('__metadata');
        salesQuotation.remove('to_Item');
        salesQuotation.remove('to_Partner');
        //salesQuotation.remove('to_PaymentPlanItemDetails');
        salesQuotation.remove('to_PricingElement');
        salesQuotation.remove('to_Text');
        message.setProperty("salesQuotation", salesQuotation);
    
 		
        // check for external approval
        if (salesQuotation.SalesDocApprovalStatus == 'A' && salesQuotation.SalesQuotationApprovalReason != '') {
            // If SalesDocApprovalStatus = A then the order is in approval
            reasonList = message.properties.salesQuotationApprovalReason.split(',');
            if (reasonList.length > 0) {
                // remove spaces before or after the string
                reasonList = reasonList*.trim();
                
                if (reasonList.contains(salesQuotation.SalesQuotationApprovalReason)) {
                    message.setProperty("approvalRequired", 'true');
                } else {
                    message.setProperty("approvalRequired", 'false');
                }
                ApprovalRelevance = "External Workflow";
            } else {
                ApprovalRelevance = "Internal Workflow";
                message.setProperty("approvalRequired", 'false');
            }
            
        } else {
            message.setProperty("approvalRequired", 'false');
        }
        salesQuotation.ApprovalRelevance = ApprovalRelevance;
        
        // prepare sales order created event for process visibility
        def root = payload 
            {
              processDefinitionId "managesalesquotation"
              processInstanceId  message.properties.processInstanceId
              eventType  message.properties.eventType
              timestamp  message.properties.eventTimestamp
              context salesQuotation
            }
        message.setBody(payload.toString());
        message.setHeader("Content-Type","application/json");
        
    } else {
        message.setProperty("approvalRequired", 'false');
        
    }
       return message;
}
def Message prepareWorkflowContext(Message message) {

    def jsonContext = new groovy.json.JsonSlurper().parseText('{"QuotationDetails": {},"History" : [], "Status" : {}}');
    jsonContext.QuotationDetails = message.properties.salesQuotation;
    def payload = new groovy.json.JsonBuilder()
    def root = payload 
            {
              
              definitionId "approvequotation_leadingworkflow"
              context jsonContext
            }
    message.setBody(payload.toString());
    message.setHeader("Content-Type","application/json");
    return message;
}

def Message prepareApprovalStartedEvent(Message message) {
    def payload = new groovy.json.JsonBuilder();
    def now = new Date().format("yyyy-MM-dd'T'HH:mm:ss'Z'", TimeZone.getTimeZone("UTC"));
    
    def root = payload 
            {
              processDefinitionId "managesalesquotation"
              processInstanceId  message.properties.processInstanceId
              eventType  "Sales Quotation Approval Started"
              timestamp now
              context message.properties.salesQuotation
            }
    message.setBody(payload.toString());
    message.setHeader("Content-Type","application/json");
    return message;
}