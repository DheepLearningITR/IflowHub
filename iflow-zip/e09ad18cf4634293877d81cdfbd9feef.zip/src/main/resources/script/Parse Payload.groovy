/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlParser;
import groovy.*
def Message processData(Message message) {
  //Get Body
  def body = message.getBody(String.class)
  def root = new XmlParser().parseText(body)
  def map = [:]
  def BundleItemId = '' as String
  def ServiceItemId = '' as String

  /*Get Children      Then remove them*/
  root.A_ServiceOrderType.to_Item.A_ServiceOrderItemType.each{
      if (it.ServiceOrderItemCategory.text() == "SVB4"){
            BundleItemId = it.ServiceOrderItem.text()
        }
       
// //    replace service item ID using BundleItemId and service item ID
//         if (BundleItemId != '' && it.ServiceOrderItemCategory.text() == "SVP4"){
//             ServiceItemId = BundleItemId + '/' + it.ServiceOrderItem.text()
//             it.ServiceOrderItem.replaceBody(ServiceItemId)
//         }
    
        if (it.ParentServiceOrderItem.text() != '0'){
            if (BundleItemId == '' || (it.ServiceOrderItemCategory.text() != "SVP1" && it.ServiceOrderItemCategory.text() != "SVP2" && it.ServiceOrderItemCategory.text() != "SVP4")){
                map.put(it.ServiceOrderItem.text(),it)
                it.replaceNode {}
                return false;
            }
        }
    
        if (it.ServiceOrderItemCategory.text() != "SVP1" && it.ServiceOrderItemCategory.text() != "SVP2" && it.ServiceOrderItemCategory.text() != "SVP4") {
            map.put(it.ServiceOrderItem.text(),it)
            it.replaceNode {}
        }
    
  }
  
  root.A_ServiceOrderType.each{
         map.each { key, value ->
              if ( value.ServiceOrderItemCategory.text() == "SVS1" || value.ServiceOrderItemCategory.text() == "SVS2" || value.ServiceOrderItemCategory.text() == "SVS4" )
              {
                 it.appendNode ( 'to_ReservedMaterial' , value.collect() )
              }
         }
  }
  String outxml = groovy.xml.XmlUtil.serialize( root )
  message.setBody(outxml);
  return message;
}
