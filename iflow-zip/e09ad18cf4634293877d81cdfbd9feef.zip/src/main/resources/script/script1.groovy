import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper;
import groovy.*
def Message processData(Message message) {
  //Get Body
  def body = message.getBody(String.class)
  def root = new XmlSlurper().parseText(body)
  def BundleItemId = '' as String
  def ServiceItemId = '' as String

  /*Get Children      Then remove them*/
  root.A_ServiceOrderType.to_Item.A_ServiceOrderItemType.each{
       if (it.ServiceOrderItemCategory.text() == "SVB4"){
            BundleItemId = it.ServiceOrderItem.text()
        }
       
//    replace service item ID using BundleItemId and service item ID
        if (BundleItemId != '' && it.ServiceOrderItemCategory.text() == "SVP4"){
            ServiceItemId = BundleItemId + '/' + it.ServiceOrderItem.text()
            it.ServiceOrderItem.replaceBody(ServiceItemId)
        }
    
    
  }
  
  String outxml = groovy.xml.XmlUtil.serialize( root )
  message.setBody(outxml);
  return message;
}