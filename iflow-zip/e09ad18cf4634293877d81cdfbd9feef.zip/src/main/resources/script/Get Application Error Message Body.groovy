/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

     // get a map of iflow properties
     def map = message.getProperties();

     // get an exception java class instance
     def ex = map.get("CamelExceptionCaught");

     if (ex!=null)
     {

   // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
       if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException"))
       {

       // copy the application error to the message body
        message.setBody("MessageLogID:" + map.get("SAP_MessageProcessingLogID") + "\n" + "MessageContent:" + ex.getResponseBody());
       }
       else{
      
      // copy the sysem error to the message body
        message.setBody("MessageLogID:" + map.get("SAP_MessageProcessingLogID") + "\n" + "MessageContent:" + ex.getMessage());
       }
      }
    return message;
}