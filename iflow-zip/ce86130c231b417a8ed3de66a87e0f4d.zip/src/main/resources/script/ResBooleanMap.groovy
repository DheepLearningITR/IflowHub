import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Get the JSON string from the header
    def headers = message.getHeaders()
    def jsonString = headers.get("FormattedHTTPQuery")
    
    // Parse the JSON string
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(jsonString)

    // Initialize the writer for XML
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.setDoubleQuotes(true)

    // Build the XML structure with namespace
    xml.'n0:IsuC4cV2WriteOffGet'('xmlns:n0': 'urn:sap-com:document:sap:soap:functions:mc-style') {
        if (jsonObject?.top) {
            IvTop(jsonObject.top)
        }

        if (jsonObject?.search) {
            IvSearchValue(jsonObject.search)
        }
    
        if (jsonObject?.skip) {
            IvSkip(jsonObject.skip)
        }

        if (jsonObject?.reversedWriteOff) {
            IvReversedWriteOff(jsonObject.reversedWriteOff)
        }

        if (jsonObject?.language) {
            IvLanguage(jsonObject.language)
        }

        if (jsonObject?.premise) {
            ItPremise {
                jsonObject.premise.split(",").each { itemValue ->
                    'item'(itemValue.trim())
                }
            }
        }

        if (jsonObject?.contractAccountId) {
            ItContractAccount {
                jsonObject.contractAccountId.split(",").each { itemValue ->
                    'item'(itemValue.trim())
                }
            }
        }

        if (jsonObject?.dateFrom || jsonObject?.dateTo) {
            ItDateRange {
                'item' {
                    Sign('I')
                    Option('BT')
                    DateFrom(jsonObject.dateFrom ?: '')
                    DateTo(jsonObject.dateTo ?: '')
                }
            }
        }

        if (jsonObject?.processingStatus) {
            ItProcessingStatus {
                jsonObject.processingStatus.split(",").each { status ->
                    'item'(status.trim())
                }
            }
        }

        if (jsonObject?.priority) {
            ItPriority {
                jsonObject.priority.split(",").each { prio ->
                    'item' {
                        Prio(prio.trim())
                        TXT("") // Assuming TXT is empty, adjust accordingly if needed
                    }
                }
            }
        }

        if (jsonObject?.filter) {
            ItFilter {
                jsonObject.filter.each { filter ->
                    'item' {
                        Fieldname(filter.fieldname)
                        FieldValue(filter.fieldValue)
                        Sign(filter.sign)
                        Option(filter.option)
                        Low(filter.low)
                        High(filter.high)
                    }
                }
            }
        }
    }

    // Set the XML output as the message body
    message.setBody(writer.toString())

    return message
}
