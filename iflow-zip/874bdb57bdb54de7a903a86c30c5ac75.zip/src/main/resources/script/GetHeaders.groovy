import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	def headers = message.getHeaders()
	def messageLog = messageLogFactory.getMessageLog(message)
	for (header in headers) {
	   messageLog.setStringProperty("header." + header.getKey().toString(), header.getValue().toString())
	}
    return message;
}