import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import java.util.regex.*;

def Message processData(Message message) {
    
   

    
    def body = message.getBody(java.lang.String) as String;

long payloadSize = body.getBytes().length;
String PayloadSize = payloadSize.toString();
message.setHeader("Content-Length",PayloadSize)
      
   

    
    
    
    return message;
}