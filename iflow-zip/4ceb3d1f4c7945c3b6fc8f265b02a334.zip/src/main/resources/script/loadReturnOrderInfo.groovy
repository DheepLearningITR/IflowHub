import com.sap.it.api.mapping.*;


def String getReturnOrderId(String referenceId, MappingContext context ){
return context.getProperty("ExternalSDDocument");
}

def String getEntryNumber(String referenceId, MappingContext context ){
return context.getProperty("ExternalSDDocumentItem");
}
