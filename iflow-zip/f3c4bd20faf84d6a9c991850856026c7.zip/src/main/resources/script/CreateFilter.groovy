import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String addFilter(String arg1,String arg2,String arg3){
	
	def effectiveUrl = arg1 as String;
	def ratePlanId = arg2 as String;
	def effectiveAt = arg3 as String;
    
     effectiveUrl = effectiveUrl.replace("propCpqRatePlanId","'"+ratePlanId+"'");
    
    if(effectiveAt != null && effectiveAt != ''){
        effectiveUrl = effectiveUrl.concat(" and effectiveAt eq "+"'"+effectiveAt+"'");    
    }


	return effectiveUrl;
}