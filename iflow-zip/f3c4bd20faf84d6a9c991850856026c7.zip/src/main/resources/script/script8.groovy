import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String) as String
    
     def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    
    def root = jsonObject.get("root"); // lazyMap
    def requests = root.get("requests");// lazymap
    def elements = requests.get('element'); //list
    def array = [];
        if(elements instanceof java.util.Map){
        println("inside Map");
        def tbody = elements.get("body");
           if(null != tbody){
                
                def pricingParameters = tbody.get("pricingParameters");
                def codePairs = pricingParameters.get("element");
                tbody.put("pricingParameters",codePairs);
                elements.put("body",tbody);
                array.push(elements);
            
           }
    }
     
     if(elements instanceof java.util.List){
          println("inside List");
           for(int i=0;i<elements.size();i++){
           def item = elements.get(i);
           def tbody = item.get("body");
           if(null != tbody){
           
                def pricingParameters = tbody.get("pricingParameters");
                def codePairs = pricingParameters.get("element");
                tbody.put("pricingParameters",codePairs);
                item.put("body",tbody);
                array.push(item);
            
           }
       }
     }

    jsonObject.remove("root");
    jsonObject.put("requests",array);
    message.setBody(JsonOutput.toJson(jsonObject))

   return message;
}