import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

def String EpochFormatDateTime(String arg1) {
    // Check if the input is null or empty
    if (arg1 == null || arg1.isEmpty()) {
        // Return an empty string or some indication of null input
        return "";
    }

    // Define the date format with milliseconds and timezone
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    df.setTimeZone(TimeZone.getTimeZone("UTC"));  // Ensure the parser interprets the date in UTC
    
    // Parse the date string
    Date date = df.parse(arg1);
    
    // Get the epoch time in milliseconds
    long epochMillis = date.getTime();
    
    // Convert milliseconds to seconds (Unix epoch time)
    long epochSeconds = epochMillis / 1000;
    
    // Return the epoch time as a string
    return String.valueOf(epochSeconds);
}