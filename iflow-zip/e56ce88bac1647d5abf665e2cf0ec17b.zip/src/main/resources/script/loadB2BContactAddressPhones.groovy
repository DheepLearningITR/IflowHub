
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil;

def Message processData(Message message) {
 
   def body = message.getBody(java.lang.String) as String;
   def adr3mas_xml = new XmlSlurper(false,false).parseText(body);
         
   Integer p_type = 0;
   String p_mainNumber = '';
   String p_mobileNumber = '';
   
   
   adr3mas_xml.IDOC.E1ADR3MAS.E1BPADTEL.each{ value-> 
            p_type= value.R_3_USER.toString().isNumber() ? value.R_3_USER.toInteger(): 0;
            switch (p_type) {
                case 1: p_mainNumber = value.TEL_NO.toString(); break; 
                case 2: p_mobileNumber = value.TEL_NO.toString(); break; 
                case 3: p_mobileNumber = value.TEL_NO.toString(); break;
                default: break;
             }
        }  
    
        message.setProperty("B2BCUSTOMER_TELEPHONENUMBER",p_mainNumber);
        message.setProperty("B2BCUSTOMER_MOBILENUMBER",p_mobileNumber);
 
	return message;
}
