import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.mapping.*;

def Message processData(Message message) {
    message.setProperty("useSapPublicKey", isGreatThanSpecificCommerceVersion(message, "2211.14"));
    return message;
}

def boolean isGreatThanSpecificCommerceVersion(Message message, String attributeVersionNumber){
    def commerceVersion = message.getProperty("COMMERCE_VERSION_NUMBER");
    if(commerceVersion == null) {
        return false;
    }
    return commerceVersion.replace(".","").toUpperCase().compareTo(attributeVersionNumber.replace(".","").toUpperCase())>=0;
}
