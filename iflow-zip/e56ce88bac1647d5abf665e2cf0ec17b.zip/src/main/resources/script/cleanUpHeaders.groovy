import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	message.setHeader("doc-out", null);
	message.setHeader("idoc", null);
	return message;
}