import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.String;

def Message processData(Message message) {
    String customer_id = message.getHeader("customer", java.lang.String);
    String idoc_in = message.getHeader("idoc-in", java.lang.String); 

    message.setHeader("ENTRY_ID", customer_id);
    message.setHeader("DATASTORE_NAME", "ERP-B2BCUSTOMER");
    message.setHeader("ACTION", "WRITE");
    // message.setProperty("tagged_idoc_in", tagged_idoc_in);
   
   return message;
}    
