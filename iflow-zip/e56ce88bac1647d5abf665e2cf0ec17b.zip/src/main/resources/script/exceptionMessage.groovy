import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {	
	def header = message.getHeader("Address_ID",java.lang.String); 
	def messageLog = messageLogFactory.getMessageLog(message);
// 	if(messageLog != null){
// 		messageLog.addAttachmentAsString("Excetpion - B2BUnit ("+header+") doesn't exist in data store.", "Load B2BUnit "+header+" from dataStore failed.",
// 		                                                    "text/xml");
// 	}
	return message;
}