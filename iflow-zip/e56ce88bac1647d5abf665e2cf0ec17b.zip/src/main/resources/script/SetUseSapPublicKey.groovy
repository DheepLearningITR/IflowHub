import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil;

def Message processData(Message message) {

  def body = message.getBody(java.lang.String) as String;
  def metadataPayload = new XmlSlurper().parseText(body);
  

  def sapPublicKeyNode = metadataPayload.DataServices.Schema.EntityType.find { it.@Name == 'Address' }.Property.find { it.@Name == 'sapPublicKey' }
   if (sapPublicKeyNode) {
        message.setProperty("sapPublicKeyEnabled","true"); 
    } else {
        message.setProperty("sapPublicKeyEnabled","false"); 
    }

  return message;
}