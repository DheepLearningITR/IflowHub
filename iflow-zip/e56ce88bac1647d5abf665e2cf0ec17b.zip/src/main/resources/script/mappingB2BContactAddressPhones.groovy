import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;


def String getTelephoneNumber(String header,MappingContext context)
{
     def p_mainNumber = context.getProperty("B2BCUSTOMER_TELEPHONENUMBER").toString(); 
    if(p_mainNumber.equals('')){
         return '';
     }else{
         return p_mainNumber;
     }

}

def String getMobilePhoneNumber(String header,MappingContext context){
    def p_mobileNumber = context.getProperty("B2BCUSTOMER_MOBILENUMBER").toString(); 
    if(p_mobileNumber.equals('')){
         return '';
     }else{
         return p_mobileNumber;
     }

}
