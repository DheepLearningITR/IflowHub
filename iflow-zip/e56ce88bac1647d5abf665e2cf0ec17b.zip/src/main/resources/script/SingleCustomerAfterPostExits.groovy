import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

	def body = message.getBody(java.lang.String) as String;
	
	def properties = message.getProperties() as Map<String, Object>;

	def messageLog = messageLogFactory.getMessageLog(message);
	
    if(messageLog != null && properties.get("enableLog") == "true"){
        def b2bCustomers = new XmlSlurper().parseText(body);
		def b2bCustomerUid = b2bCustomers.B2BCustomer.uid.text();
		b2bCustomerUid = b2bCustomerUid == null ? "": b2bCustomerUid;
	    messageLog.addAttachmentAsString("Single Customer " + b2bCustomerUid + " After Post Exits", body, "text/xml");
	}

    return message;
}