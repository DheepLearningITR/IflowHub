import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
 
   def body = message.getBody(java.lang.String) as String;
   def adrmas_root_xml = new XmlSlurper(false,false).parseText(body);
         
   Integer p_type = 0;
   String p_mainNumber = '';
   String p_mobileNumber = '';
   
   adrmas_root_xml.IDOC.E1ADRMAS.E1BPADTEL.each{ value-> 
            p_type= value.R_3_USER.toString().isNumber() ? value.R_3_USER.toInteger(): 0;
            switch (p_type) {
                case 1: p_mainNumber = value.TEL_NO.toString(); break; 
                case 2: p_mobileNumber = value.TEL_NO.toString(); break; 
                case 3: p_mobileNumber = value.TEL_NO.toString(); break;
                default: break;
             }
        }  
    
        
        message.setProperty("SALES_UNIT_TELEPHONENUMBER",p_mainNumber);
        message.setProperty("SALES_UNIT_MOBILENUMBER",p_mobileNumber);
        

	return message;
}