import groovy.xml.StreamingMarkupBuilder;
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
def Message processData(Message message) {
    def b2bUnit_xml = message.getBody(java.lang.String) as String;
    def address_xml = message.getProperty("Unit_Address") as String;
    
	def address = new XmlSlurper().parseText( address_xml ) ;
	def root = new XmlSlurper(false,false).parseText(b2bUnit_xml);

    def ifAddressFound = address.'**'.find{ node ->
            node.name() == 'Address'
        }

    if(ifAddressFound != null)
    	root.B2BUnit.appendNode( address );

	String xmlStr = XmlUtil.serialize( new StreamingMarkupBuilder().bind { mkp.yield root } );

	message.setBody(xmlStr);
	return message;
}