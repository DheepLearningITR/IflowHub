/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput ;

import java.util.HashMap;

def Message processData(Message message) {
	
	//**********************************************
	// Validate mandatory headers
	//**********************************************
	def header = message.getProperty("token") ;
	if( header == null ) {
		throw new Exception("Mandatory header \"accessToken\" is missing") ;
	}
	
	header = message.getProperty("serviceBaseUrl") ;
	if( header == null ) {
		throw new Exception("Mandatory header \"serviceBaseUrl\" is missing") ;
	}
	
	header = message.getProperty("tenant") ;
	if( header == null ) {
		throw new Exception("Mandatory header \"tenant\" is missing") ;
	}
	
	header = message.getProperty("sourceId") ;
	if( header == null ) {
		throw new Exception("Mandatory header \"remoteObjectId\" is missing") ;
	}
	
	header = message.getProperty("targetId") ;
	if( header == null ) {
		throw new Exception("Mandatory header \"c4cObjectId\" is missing") ;
	}
	//**********************************************
	//**********************************************
	
	def body = message.getBody(java.lang.String) as String;
	
	def jsonSlurper = new JsonSlurper();
	def inputPayload = jsonSlurper.parseText(body) ;
	assert inputPayload instanceof Map ;
	
	def productData = inputPayload.get("product");
	if( productData == null ) {
		throw new Exception("Product tag is missing in the input") ;
	}
	
	// Process name field(handling one of schema)
	def nameList = [] ;
	def nameObject;
	def name = productData.get("name") ;
	if( name instanceof String ) {
		nameObject = [languageCode:"en", content:name];
		nameList.push(nameObject) ;
		
	} else if( name instanceof Map ) {
		name.each { key, value -> 
			nameObject = [languageCode:key, content:value];
			nameList.push(nameObject) ;
		} ;
	}
	productData.put("name", nameList) ;
	
	// Get media data
	// Store it separately and remove it from product.
	def media = productData.get("media") ;
	if( media == null ) {
		throw new Exception("Media is missing in the input") ;
	}
	
	message.setProperty("inputMedia", JsonOutput.toJson(media)) ;
	
 	productData.remove("media") ;
	inputPayload.put("product", productData) ;
	message.setBody(JsonOutput.toJson(inputPayload)) ;
	
	return message;
}

