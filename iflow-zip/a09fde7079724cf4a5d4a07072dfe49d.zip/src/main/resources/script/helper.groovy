import com.sap.it.api.mapping.*;

def String getMessageId(String value, MappingContext context) {
  def messageId = UUID.randomUUID().toString()
  context.setHeader("SAP_ApplicationID", messageId)
  return messageId
}
def String readOpportunityId(String propertyName, MappingContext context){
    def propertyValue = context.getProperty("OpportunityId")
    return propertyValue
}

def String SystemID(String _PID, MappingContext context) {
  return context.getProperty(_PID)
}

def String generateMessageRequestUUID(String value, MappingContext context) {
  return UUID.randomUUID()
}