/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
def Message processData(Message message) {
    //Body 
    
    def body = message.getBody(java.lang.String);
    def bodyXML = new XmlSlurper().parseText(body)
    for (def coverage :  bodyXML.coverages) {
        for (def feature : coverage.product.features) {
    
            def entryNumberNode = new XmlSlurper().parseText("<coverage_id>" + coverage.entryNumber + "</coverage_id>") 
             def coverageCodeNode = new XmlSlurper().parseText("<coverage_code>" + coverage.product.code + "</coverage_code>") 
             feature.appendNode(entryNumberNode)
            feature.appendNode( coverageCodeNode)
             System.out.println( coverage.product.code )
            }
    }

  message.setBody(groovy.xml.XmlUtil.serialize(bodyXML));
  return message;
}