import com.sap.it.api.mapping.*
import com.sap.it.api.mapping.MappingContext;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;
import static java.util.UUID.randomUUID;
import java.text.*; 
import java.util.*;

def Message processData(Message message) {
    
    //Body 
    def body = message.getBody(java.lang.String);
    def bodyXML = new XmlSlurper().parseText(body);
    
	// Get Value Mapping Service
	def valueMapService = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    // Get Properties from IFlow
    String valueFSPMVersion    = 'FSPM_'+ message.getProperty("com.sap.commercecloud.fsa.insurance.anonymousquote.FSPM_Version");
    String valueHybrisVersion  = 'FSA_'+ message.getProperty("com.sap.commercecloud.fsa.insurance.anonymousquote.FSA_Version");
    String valueFSAMainProduct = message.getProperty("com.sap.commercecloud.fsa.insurance.anonymousquote.MainProduct");

// def messageLog = messageLogFactory.getMessageLog(message);

    for (def premium :  bodyXML.ET_PREM[0].item) {
       
        for (def keymapping: bodyXML.ET_KEY_MAPPING[0].item) {
            
            if(keymapping.PARAMETER_NAME == 'IT_SVC_PREM'){
               def keylist = keymapping.TRANSFERRED_KEY.text().tokenize('0')
               def finalkeylist = keymapping.FINAL_KEY.text().tokenize('0') 
               if(keylist.size == 3){
                    if((finalkeylist[1] == premium.COVERAGE_ID.text()) &&  (finalkeylist[0] = premium.POLICYPRODUCT_ID.text()) ) {
                        premium.COVERAGE_ID = keylist[1]
                        premium.POLICYPRODUCT_ID = keylist[0]
                    }
                }
            }
        }
    } // Premium loop
    
    for (def supdc :  bodyXML.ET_SUPDC[0].item) {
       
        for (def keymapping: bodyXML.ET_KEY_MAPPING[0].item) {

            if(keymapping.PARAMETER_NAME == 'IT_SVC_SUPDC'){
               def trans_keylist = keymapping.TRANSFERRED_KEY.text().tokenize('0')
               def final_keylist = keymapping.FINAL_KEY.text().tokenize('0') 
               if(trans_keylist.size == 2){
                    if(("0" == supdc.COVERAGE_ID.text()) && (final_keylist[0] == supdc.POLICYPRODUCT_ID.text()) ) {
                        supdc.POLICYPRODUCT_ID = trans_keylist[0];
                    }
                }
            }
        }
        
        // Delete Nodes which are not below contract level
        if(supdc.COVPAC_ID.text()        != "0" || 
           supdc.COVERAGE_ID.text()      != "0" ||
           supdc.COVCP_ID.text()         != "0" ||
           supdc.SUBJECT_ID.text()       != "0" ||
           supdc.UWDCN_ID.text()         != "0") {

            supdc.replaceNode{ };
            continue;
            
        }

        // Filter Coupon Supdc
        String valueMapped = supdc.PM_ID.text();

        // Go for attributes with mapping (first template specific)
        //ValueMap (FSPM_1909, Discount_PM_ID, _MVSDCPD0000, FSA_1907, AUTO_INSURANCE_Type)
        valueMapped = valueMapService.getMappedValue(valueFSPMVersion, 'Discount_PM_ID', supdc.PM_ID.text(), valueHybrisVersion, valueFSAMainProduct + "_Type");

// messageLog.setStringProperty("Mapped_Supdc", valueMapped);

        if (valueMapped != 'couponDiscount') {
            
            supdc.replaceNode{ }; 
            continue;
            
        }
        
    } // Supdc loop

    message.setBody(groovy.xml.XmlUtil.serialize(bodyXML));
    return message;
    
}