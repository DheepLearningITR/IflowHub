import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder
import groovy.util.XmlParser;
def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties() as Map<String, Object>;
    def xmlBody = properties.get("BusinessPartnerOrganizationPayload");
    def RoleCode = properties.get("RoleCode");
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    def organization = object.Organizations.organizations;
    def fieldSet = [];
     def messageLog = messageLogFactory.getMessageLog(message);
    
     def xmlObject = new XmlParser().parseText(xmlBody);
      def bpObject = xmlObject.BusinessPartnerSUITEReplicateRequestMessage;
      if( organization instanceof groovy.json.internal.LazyMap){
          for(def bp : bpObject){
           if(bp.BusinessPartner.Role.RoleCode.text().contains(RoleCode)){
               //println(bp.BusinessPartner.InternalID.text())
               def orgID = organization.get("externalId")
               //println(bp.BusinessPartner.InternalID.text())
               if(bp.BusinessPartner.InternalID.text().equals(orgID))
               {
                     
                   fieldSet.add(organization)
               }
           }
       }
          
      }else{
          for( def org : organization){
            //  println(org)
               for(def bp : bpObject){
           if(bp.BusinessPartner.Role.RoleCode.text().contains(RoleCode)){
               //println(bp.BusinessPartner.InternalID.text())
               def orgID = org.get("externalId")
               //println(bp.BusinessPartner.InternalID.text())
               if(bp.BusinessPartner.InternalID.text().equals(orgID))
               {
                   fieldSet.add(org)
               }
           }
       }
          }
      }
     object.Organizations.organizations = fieldSet
     body = new JsonBuilder(object).toPrettyString();
     def jsonCount = object.Organizations.organizations;
     if(jsonCount.size() == 1){
        message.setProperty("OrganizationCounter", '1');   
     }else{
          message.setProperty("OrganizationCounter", '0'); 
     }
    message.setProperty("BusinessPartnerOrganisation", body);
   
   
    return message;
}