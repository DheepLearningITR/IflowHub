import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
   
    def pmap = message.getProperties();
    
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties() as Map<String, Object>;
    def enableLog = properties.get("Enable Log");
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null && enableLog.equals('true')) {
        messageLog.addAttachmentAsString("Log - Response" , body,
                                                           "text/xml");
    }
    
    return message;
}