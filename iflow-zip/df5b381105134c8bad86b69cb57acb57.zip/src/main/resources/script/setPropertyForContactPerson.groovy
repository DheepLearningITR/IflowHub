
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
       def body = message.getBody(java.lang.String) as String;
       def object = new JsonSlurper().parseText(body);
       //Properties 
       map = message.getProperties();
       def setOrgId = map.get("OrganizationID");
       def contacts = object.Relationships.ContactIDEmail;
       if(contacts instanceof java.util.ArrayList){
        for(def contact : contacts){
          if(contact.OrganizationID.equals(setOrgId)){
            message.setProperty("EmailID", contact.Email)
            message.setProperty("ContactPersonID", contact.ContactPersonID)
            message.setProperty("department", contact.department);
            message.setProperty("jobFunction", contact.jobFunction)
            message.setProperty("phone", contact.phone)
         }
      }
    }else{
        message.setProperty("EmailID", contacts.Email)
      message.setProperty("ContactPersonID", contacts.ContactPersonID)
      message.setProperty("department", contacts.department);
      message.setProperty("jobFunction", contacts.jobFunction)
      message.setProperty("phone", contacts.phone)
    }
       value = map.get("BusinessPartnerPayload");
       message.setBody(value);
       return message;
}