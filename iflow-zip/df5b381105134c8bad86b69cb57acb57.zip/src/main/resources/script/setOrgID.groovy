import com.sap.it.api.mapping.*;


def String setOrgID(String orgID, MappingContext context){
    context.setProperty("DataStoreId", orgID + 'ContactPersonMap')
	return orgID 
}