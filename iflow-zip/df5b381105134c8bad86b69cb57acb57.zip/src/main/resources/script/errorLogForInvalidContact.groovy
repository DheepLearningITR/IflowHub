import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
   
    
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null) {
            messageLog.addAttachmentAsString("Log - Error Message" , "Invalid or Insufficient  Data for Business Partner Contact Person \n \n",
                                                        "text/xml");
        
    }
    return message;
}