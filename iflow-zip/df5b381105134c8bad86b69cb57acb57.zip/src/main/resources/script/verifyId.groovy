import com.sap.it.api.mapping.*;

def String verifyID(String contactPersonID, MappingContext context){
    def externalisedID = context.getProperty('ContactPersonID')
    if(externalisedID.equals(contactPersonID)){
        return contactPersonID;
    }
	return 'false'
}