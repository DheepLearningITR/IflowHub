import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import javax.activation.DataHandler;

def Message processEvent(Message message) {
	//Body 
	def body = message.getBody(String.class);
	JsonSlurper slurper = new JsonSlurper();
	Map parsedJson = slurper.parseText(body);
	def type;

	switch (parsedJson.type) {
		case "sap.s4.beh.salesorder.v1.SalesOrder.Changed.v1":
			type = "Sales Order Changed";
			break;
		default:
			type = "NA";
	}

	message.setProperty("eventType", type);

	if (type != "NA") {
		message.setProperty("processDefinitionId", "managesalesorder");
		message.setProperty("processInstanceId", parsedJson.data.SalesOrder);
		message.setProperty("eventTimestamp", parsedJson.time);
		message.setProperty("orderId", parsedJson.data.SalesOrder);
	}

	return message;

}

def Message processSalesOrder(Message message) {
	def body = message.getBody(String.class);
	def salesOrder;
	String[] reasonList;
	def salesOrderApprovalReason;
	def payload = new groovy.json.JsonBuilder()
	def ApprovalRelevance = "Not Relevant";

	JsonSlurper slurper = new JsonSlurper();
	Map parsedJson = slurper.parseText(body);

	if (parsedJson.d != null) {
		salesOrder = parsedJson.d.results[0];
		salesOrder.remove('__metadata');
		salesOrder.remove('to_Item');
		salesOrder.remove('to_Partner');
		salesOrder.remove('to_PaymentPlanItemDetails');
		salesOrder.remove('to_PricingElement');
		salesOrder.remove('to_Text');

		message.setProperty("salesOrder", salesOrder);
		message.setProperty("creditBlocked", 'false');
		message.setProperty("raiseCreditBlockedEvent", 'false');
		message.setProperty("createCBWorkflow", 'false');
		message.setProperty("cancelCreditBlockWorkflow", 'false');

		// check for the credit block
		if (salesOrder.TotalCreditCheckStatus == 'B' && salesOrder.OverallSDProcessStatus != 'C') {
		    
			message.setProperty("creditBlocked", 'true');
			
			// Raise an Unblock Credit Workflow only if the Sales Order is Approved OR does not require approval
			if (salesOrder.SalesDocApprovalStatus == 'A') {
			    // Sales Order is in approval. Cancel any existing Unblock Credit workflow
				message.setProperty("raiseCreditBlockedEvent", 'true');
				message.setProperty("createCBWorkflow", 'false');
				message.setProperty("cancelCreditBlockWorkflow", 'true');
			} else if (salesOrder.SalesDocApprovalStatus == 'C') {
			    // Sales Order approval rejected. Cancel any existing Unblock Credit workflow
				message.setProperty("raiseCreditBlockedEvent", 'false');
				message.setProperty("createCBWorkflow", 'false');
				message.setProperty("cancelCreditBlockWorkflow", 'true');
			} else if (salesOrder.SalesDocApprovalStatus == 'B' || salesOrder.SalesDocApprovalStatus == '') {
			    // Sales Order Approved OR Approval not required. Create an Unblock Credit workflow
				message.setProperty("raiseCreditBlockedEvent", 'true');
				message.setProperty("createCBWorkflow", 'true');
				message.setProperty("cancelCreditBlockWorkflow", 'true');
			}

		}


		// check for external approval
		if (salesOrder.SalesOrderApprovalReason != '') {
			reasonList = message.properties.salesOrderApprovalReason.split(',');
			if (reasonList.length > 0) {
				// remove spaces before or after the string
				reasonList = reasonList *.trim();
				// If SalesDocApprovalStatus = A then the order is in approval
				if (reasonList.contains(salesOrder.SalesOrderApprovalReason)) {
					switch (salesOrder.SalesDocApprovalStatus) {
						case 'A':
							message.setProperty("approvalRequired", 'true');
							message.setProperty("cancelApprovalWorkflow", 'false');
							break;
						case 'B':
						case 'C':
						default:
							message.setProperty("approvalRequired", 'false');
							message.setProperty("cancelApprovalWorkflow", 'false');
							break;

					}
				}
				ApprovalRelevance = "External Workflow";
			} else {
				ApprovalRelevance = "Internal Workflow";
				message.setProperty("approvalRequired", 'false');
				message.setProperty("cancelApprovalWorkflow", 'false');
			}

		} else {
			message.setProperty("approvalRequired", 'false');
			message.setProperty("cancelApprovalWorkflow", 'true');
		}
		salesOrder.ApprovalRelevance = ApprovalRelevance;

		// prepare sales order created event for process visibility
		def root = payload {
			processDefinitionId "managesalesorder"
			processInstanceId message.properties.processInstanceId
			eventType message.properties.eventType
			timestamp message.properties.eventTimestamp
			context salesOrder
		}
		message.setBody(payload.toString());
		message.setHeader("Content-Type", "application/json");

	} else {
		message.setProperty("approvalRequired", 'false');
		message.setProperty("creditBlocked", 'false');
	}
	return message;
}

def Message prepareCreditblockedEvent(Message message) {
	def payload = new groovy.json.JsonBuilder();
	def now = new Date().format("yyyy-MM-dd'T'HH:mm:ss'Z'", TimeZone.getTimeZone("UTC"));

	def root = payload {
		processDefinitionId "managesalesorder"
		processInstanceId message.properties.processInstanceId
		eventType "Sales Order Credit Blocked"
		timestamp now
		context message.properties.SalesOrder
	}
	message.setBody(payload.toString());
	message.setHeader("Content-Type", "application/json");
	return message;
}

def Message prepareApprovalStartedEvent(Message message) {
	def payload = new groovy.json.JsonBuilder();
	def now = new Date().format("yyyy-MM-dd'T'HH:mm:ss'Z'", TimeZone.getTimeZone("UTC"));

	def root = payload {
		processDefinitionId "managesalesorder"
		processInstanceId message.properties.processInstanceId
		eventType "Sales Order Approval Started"
		timestamp now
		context message.properties.SalesOrder
	}
	message.setBody(payload.toString());
	message.setHeader("Content-Type", "application/json");
	return message;
}

def Message preparePostSOApprovalWorkflowContext(Message message) {
	message.setProperty("workflowCallType", "POST");
	def jsonContext = new groovy.json.JsonSlurper().parseText('{"SalesOrderDetails": {},"History" : [], "Status" : {}}');
	jsonContext.SalesOrderDetails = message.properties.salesOrder;
	def payload = new groovy.json.JsonBuilder()
	def root = payload {
		//definitionId "salesorderapprovaldemo"
		definitionId "approvesalesorder_leadingworkflow"
		context jsonContext
	}
	message.setBody(payload.toString());
	message.setHeader("Content-Type", "application/json");
	return message;
}

def Message preparePostUnblockCreditWorkflowContext(Message message) {
	message.setProperty("workflowCallType", "POST");
	def payload = new groovy.json.JsonBuilder();
	def jsonContext = new groovy.json.JsonSlurper().parseText('{"SalesOrder": {},"History" : [], "Status" : {}}');
	jsonContext.SalesOrder = message.properties.salesOrder;
	def root = payload {
		definitionId "releasecreditblockedsalesorders_leadingworkflow"
		context jsonContext
	}
	message.setBody(payload.toString());
	message.setHeader("Content-Type", "application/json");
	return message;
}

def Message prepareCheckCBApprovalWorkflowExists(Message message) {
	message.setProperty("workflowCallType", "GET");
	def queryParam = "definitionId=com.sap.content.releaseso.creditapprovecreditcheck&businessKey=" + message.properties.orderId;
	message.setProperty("queryParameters", queryParam);
	return message;
}

def Message prepareCheckSOApprovalWorkflowExists(Message message) {
	message.setProperty("workflowCallType", "GET");
	// Look specifically for Approve Sales Order Workflow. We then proceed based on its status.
	def queryParam = "definitionId=com.sap.content.approvesalesorders&businessKey=" + message.properties.orderId;
	message.setProperty("queryParameters", queryParam);
	return message;
}

def Message processApprovalWFCheck(Message message) {
	def body = message.getBody(String.class);
	def parsedJson = new JsonSlurper().parseText(body);
	def approvalWFExists = false;
	def approvalWFIndex = 0;
	if (parsedJson.size() > 0) {
		parsedJson.eachWithIndex {
			it,
			idx ->
			if (it.status == "RUNNING") {
				approvalWFExists = true;
				approvalWFIndex = idx;
			}

		}
	}

	if (approvalWFExists) {
		// We may get more workflows since they could be older completed/cancelled/erronous/suspended.
		// Only look for workflow in Running state.
		// RootInstance ID WILL ALWAYS EXIST IF WORKFLOW EXISTS
		message.setProperty("approvalWFRootInstanceID", parsedJson[approvalWFIndex].rootInstanceId);
		message.setProperty("approvalWFExists", approvalWFExists);
		message.setProperty("workflowCallType", "PATCH");
		def payload = new groovy.json.JsonBuilder()
		def payloads = [];
		def root = payload {
			status "Canceled"
			cascade "true"
		}
		payloads.push(payload);
		message.setBody(payloads.toString());
		message.setHeader("Content-Type", "application/json");

	} else if (parsedJson.size() < 1) {
		message.setProperty("approvalWFExists", "false");
	} 
	return message;
}