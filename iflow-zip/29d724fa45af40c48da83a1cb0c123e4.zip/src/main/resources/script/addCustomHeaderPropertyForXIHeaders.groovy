import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    // fetch headers
    def headers = message.getHeaders();
    
    // add customer header property
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog){
        def qos = headers.get("SapQualityOfService");
        if (qos != null) {
            messageLog.addCustomHeaderProperty("QoS", qos);
        }
        def queueid = headers.get("SapQueueID");
        if (queueid != null) {
            messageLog.addCustomHeaderProperty("Queue", queueid);
        }
    }
    
    return message;
}