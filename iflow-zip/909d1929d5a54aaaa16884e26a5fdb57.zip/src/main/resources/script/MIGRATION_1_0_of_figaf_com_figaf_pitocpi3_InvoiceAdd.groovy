import com.sap.it.api.mapping.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;

def String AddZero(String number, MappingContext context) {
int m=17;
return "000"+number;
}
def void usedTime(String[] var1, Output result, MappingContext context) {
		int i =1;
		for (String string : var1) {
			result.addValue(string+" "+i);
			i++;
			
		}
}
