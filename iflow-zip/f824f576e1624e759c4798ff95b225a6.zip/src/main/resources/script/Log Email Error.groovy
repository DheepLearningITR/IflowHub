import com.sap.gateway.ip.core.customdev.util.Message
// Version 1.0
// save attachments to log and build error email body
def Message processData(Message message) {
    def map = message.getProperties()
    def headers = message.getHeaders()
    def add_to_log_property = message.getProperty("ErrorLogAttachments") ?: 'false'
    def add_to_log = (add_to_log_property ==~ /(?i)(true|x)/)
    def email_body = ''
    def headers_text = ''

    // get an exception java class instance
    def ex = map.get('CamelExceptionCaught')
    
                if (ex!=null) {
                                
                                // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
                                if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
                                                
                                                // save the http error response as a message attachment 
                                                def messageLog = messageLogFactory.getMessageLog(message);
                                                messageLog.addAttachmentAsString("http.ResponseBody", ex.getResponseBody(), "text/plain");

                                                // copy the http error response to an iflow's property
                                                message.setProperty("http.ResponseBody",ex.getResponseBody());

                                                // copy the http error response to the message body
                                                message.setBody(ex.getResponseBody());

                                                // copy the value of http error code (i.e. 500) to a property
                                                message.setProperty("http.StatusCode",ex.getStatusCode());

                                                // copy the value of http error text (i.e. "Internal Server Error") to a property
                                                message.setProperty("http.StatusText",ex.getStatusText());
                                                
                                                // process request header error
                                                message.setHeader("Process Request", "Request was not successful");
                                                
                                }
                }
                return message;
}