import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import java.util.HashMap

def Message processData(Message message) {
    def body = message.getBody(String)
    HashMap<String, String> hmap1 = new HashMap<>()
    
    try {
        def xml = new XmlSlurper().parseText(body)
        
        xml.EmpCompensation.each { empCompensation ->
            def userId = empCompensation.userId.text()
            
            
            // Find Annualized Salary amount
            def amount = empCompensation.empCompensationGroupSumCalculatedNav.EmpCompensationGroupSumCalculated.find { 
                it.payComponentGroupId.text() == "AnnualizedSalary" 
            }?.amount.text() ?: "N/A"
            
            // Find standard hours
            def standardHours = empCompensation.employmentNav.EmpEmployment.jobInfoNav.EmpJob.standardHours.text()
            def startDate = empCompensation.empCompensationGroupSumCalculatedNav.EmpCompensationGroupSumCalculated.find { 
    it.payComponentGroupId.text() == "AnnualizedSalary" 
}?.startDate.text() ?: "N/A"

            def combinedValue = "startDate: ${startDate}, amount: ${amount}, standardHours: ${standardHours}"
            hmap1.put(userId, combinedValue)
        }
        
        message.setHeader("EmpCompensationCache", hmap1)
    } catch (Exception e) {
        message.setHeader("Error", "Invalid XML: ${e.message}")
    }
    
    return message
}