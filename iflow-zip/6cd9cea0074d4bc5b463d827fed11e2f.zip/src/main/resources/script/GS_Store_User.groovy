import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import java.util.HashMap

def Message processData(Message message) {
    // Retrieve the XML body
    def body = message.getBody(String)

    // Parse the XML using XmlSlurper
    def xml = new XmlSlurper(false, false).parseText(body)

    // Initialize HashMap to store data
    HashMap<String, String> hmap1 = new HashMap<String, String>()

    // Iterate over each FO_company element and add data to HashMap
    xml.User.each { company ->
        def externalId=company.externalId.text()
        def buisnessphn = company.businessPhone.text()
        def email = company.email.text()
        def firstname = company.firstName.text()
        def lastname = company.lastName.text()
         def combinedValue = "buisnessphn: ${buisnessphn}, email: ${email},firstname: ${firstname},lastname: ${lastname}"
        hmap1.put(externalId, combinedValue) // Use payComponent as key and concatenated string as value
    }
     

    // Set the HashMap in the header
    message.setHeader("cacheEntityUser", hmap1)

    return message
}
