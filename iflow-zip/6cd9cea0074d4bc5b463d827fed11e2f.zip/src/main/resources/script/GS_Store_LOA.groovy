import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import java.util.HashMap

def processData(Message message) {
    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)
    
    // Create a HashMap to store extracted data
    def extractedData = new HashMap()
    
    // Iterate over CompoundEmployee nodes
    xml.CompoundEmployee.each { employee ->
        def personId = employee.person.person_id_external.text()
        if (personId) { // Check if person_id_external is not null
            def found = false // Flag to track if we found a match
            
            // Use find instead of each to allow early termination
            employee.person.employment_information.job_information.find { jobInfo ->
                def event = jobInfo.event.text()
                def emplStatus = jobInfo.emplStatus.text()
                
                // If conditions match, store the data and return true to stop iteration
                if (event == "10" && (emplStatus == "P" || emplStatus == "U")) {
                    def startDate = jobInfo.start_date.text()
                    def eventReason = jobInfo.event_reason.text()
                    def loaDetails = "LOAStartDate: ${startDate}, LOAStartReason: ${eventReason}"
                    extractedData.put(personId, loaDetails)
                    return true // This breaks the inner loop and moves to next CompoundEmployee
                }
                return false // Continue searching if no match found
            }
        }
    }
    
    // Store the extracted data in the message header with a new name
    message.setHeader("cacheEntityLOA", extractedData)
    return message
}