import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.HashMap

def Message processData(Message message) {
    def body = message.getBody(String)
    def xml = new XmlSlurper().parseText(body)
    
    def extractedData = new HashMap<String, String>()

    // List of termination reasons
    def terminationReasons = [
      'TERERLRT', 'TERIATTD', 'TERIAWOL', 'TERICOMP', 'TERICOND', 'TERIDEAT', 'TERIDISB',
        'TERIDISH', 'TERIDIVS', 'TERIEOC', 'TERIINSB', 'TERIMIL', 'TERINONP', 'TERIPOLI',
        'TERIREDN', 'TERIREDU', 'TERIRSTR', 'TERITWBN', 'TERITWPY', 'TERMSPIN', 'TERNSHOW',
        'TEROTH', 'TERRTMNT', 'TERTVTERM', 'TERVASGN', 'TERVBUS', 'TERVCAR', 'TERVCOMP',
        'TERVCOWKR', 'TERVENV', 'TERVERL', 'TERVHLTH', 'TERVHOME', 'TERVLOCAT', 'TERVMARG',
        'TERVMGT', 'TERVMIL', 'TERVOBUS', 'TERVPERS', 'TERVRELO', 'TERVSCHOL', 'TERVUNK',
        'TERVVSP', 'TERVWLB'
    ]

    // Get currentDate from header and convert it to LocalDate
    def dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    def currentDateStr = message.getProperty("currentDate")
    def currentDate = LocalDate.parse(currentDateStr, dateFormatter)

    xml.CompoundEmployee.each { employee ->
        def personId = employee.person.person_id_external.text()
        def endDateStr = employee.person.employment_information.end_date.text()?.trim()
if (endDateStr && endDateStr.length() > 10) {
    endDateStr = endDateStr.substring(0, 10)
}


        // Convert endDateStr to LocalDate
        if(endDateStr){
        def endDate = LocalDate.parse(endDateStr, dateFormatter)
        
        message.setHeader("date", endDateStr)
        message.setHeader("personId", personId)

        if (endDate.isAfter(currentDate)&&endDate) {  // Correct date comparison
            if (personId) {
                def foundTermination = false
                employee.person.employment_information.job_information.each { employment ->
                    if (!foundTermination) {
                        def eventReason = employment.event_reason.text()?.trim()
                        def startDate = employment.start_date.text()?.trim()

                        if (terminationReasons.contains(eventReason)) {
                            extractedData.put(personId, "EndEffectivedate: ${startDate}, TerminationEvent: ${eventReason}")
                            foundTermination = true  // Stop checking after first match
                        }
                    }
                }
            }
        }
        }
    }

    message.setHeader("cacheEntityTermination", extractedData)
    return message
}
