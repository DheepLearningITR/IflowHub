import com.sap.it.api.mapping.*;
import java.util.Map;

public String fixToLength(String input, int length) {
    // Check if input is null
    if (input == null) {
        input = ""
    }

    // Extract the last 6 characters
    if (input.length() > length) {
        return input.substring(input.length() - length)
    }

    // Pad the input with spaces if shorter than the desired length
    while (input.length() < length) {
        input += " "
    }

    return input
}

