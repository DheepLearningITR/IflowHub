import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import java.util.HashMap

def Message processData(Message message) {
    // Retrieve the XML body
    def body = message.getBody(String)

    // Parse the XML using XmlSlurper
    def xml = new XmlSlurper(false, false).parseText(body)

    // Initialize HashMap to store data
    HashMap<String, String> hmap1 = new HashMap<String, String>()

    // Iterate over each FO_company element and add data to HashMap
    xml.FO_payGroup.each { company ->
        def externalCode = company.externalCode.text()
        def name = company.name.text()
        hmap1.put(externalCode, name) // Store externalCode as key and description as value
    }

    // Set the HashMap in the header
    message.setHeader("cacheEntityFOpayGroup", hmap1)

    return message
}
