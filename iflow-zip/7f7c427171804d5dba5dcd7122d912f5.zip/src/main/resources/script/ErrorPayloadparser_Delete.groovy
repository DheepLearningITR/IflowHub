import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {

	def body = message.getBody(String.class);
	def output;
	message.setProperty("isError", "true");
     
	//Setting the timestamp
	def now = new Date();
	message.setProperty("timestamp", now.format("yyyyMMddHHmmss", TimeZone.getTimeZone('UTC')));
	
	//parsing error message
	output = getErrorResponse(body,message); 
	if(!body.contains('error')) {
		message.setProperty("isError", "false");
	}
	message.setBody(output);
    
	return message;
}

def String getErrorResponse(String response,Message message) {

    def jsonSlurper = new JsonSlurper()
	def sb = new StringBuilder("{\"row\":[");
	def errMsg, errObj, records;
    int seqNumber = 1;
    int counter=0;
	response.split("HTTP/1.1").each { unit ->
	   counter=counter+1;
	   message.setProperty("counter",counter);
	   if("$unit".contains("201 Created") || "$unit".contains("200 OK") ||"$unit".contains("204 No Content"))
	   {
	       seqNumber=seqNumber+1;
	   }
	   else	if(!"$unit".contains("201 Created") && !"$unit".startsWith("--changeset")) {
		   		if(!"$unit".contains("200 OK") && !"$unit".startsWith("--changeset")) {
				errMsg = "$unit".substring("$unit".indexOf("{\"error\""), "$unit".indexOf("--changeset")).trim()
                errObj = jsonSlurper.parseText(errMsg)
				if(errObj.error.details){
				    datas = errObj.error.details;
				    for(def data:datas){
		     
			        	sb.append("{\"SNo\": \""+ seqNumber +"\",");
			        	sb.append("\"Status\": \"Error\",");
			        	sb.append("\"message\": \""+ errObj.error.message +"\",");
			        	sb.append("\"code\": \""+ data.code +"\",");
			        	sb.append("\"errorMessage\": \""+ data.message +"\",");
			        	sb.append("\"target \": \""+ data.target +"\",");
			        	  boolean foundIndex=false;
			        	  def columns;
			        	  def cropVal;
			        	  int i=0;
			        	if(data.target)
			        	{
			        	     cropVal=data.target;
			        	     cropVal=cropVal.drop(3);
			        	     message.setProperty("cropVal",cropVal);
			        	   
			        	  
			        	    columns=message.getProperty("P_ArrayData")[0];
			        	    //get the index of error column
			        	    if(columns.contains(cropVal))
			        	    {
			        	        def splitvalues=columns.split(',')
			        	        for(def eachSplitVal:splitvalues)
			        	        {
			        	            i=i+1;
			        	            if(eachSplitVal.equals(cropVal))
			        	            {
			        	                foundIndex=true;
			        	                break;
			        	            }
			        	        }
			        	    }
			        	      
			        	  
			        	}
			        	//get the inex of error value
			        	      if(foundIndex==true){
			        	        columns=message.getProperty("P_ArrayData")[counter-1];
			        	        message.setProperty("newColumnsNext",columns);
			        	        def splitvalues=columns.split(',')[i-1];
			        	    	sb.append("\""+cropVal+"\": \""+ splitvalues +"\",");
			        	      }
			        	sb.append("},");
				    	}
				    	seqNumber=seqNumber+1;
				}
				else{
				    	sb.append("{\"SNo\": \""+ seqNumber +"\",");
			        	sb.append("\"Status\": \"Error\",");
			        	sb.append("\"message\": \""+ errObj.error.message +"\",");
			        	sb.append("},");
			        	seqNumber=seqNumber+1; 	
				    
				}
			
				
		}    
		}
	
	}
	
	records = sb.toString();
	records = records.substring(0, records.length()-1)+"]}";
	return records;
}