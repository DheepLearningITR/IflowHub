import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def sfsfAttributeType = message.getHeaders().get("sfsfAttributeType");
		if(sfsfAttributeType!=null){
			messageLog.addCustomHeaderProperty("sfsf_AttributeType", sfsfAttributeType);		
        }
	    def operationType = message.getProperties().get("operationType");
	    if(operationType=='enrich'){
	        messageLog.addCustomHeaderProperty("cbr_operation", "enrichWithAttributeTexts");
	    }else{
	        messageLog.addCustomHeaderProperty("cbr_operation", "getAttributeTexts");
	    }
	}
	return message;
}


