import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;
import groovy.json.JsonSlurper;

def Message build_idsFilter(Message message) {
    
    def body = message.getBody(java.lang.String)

    def cbrProficiencyTextsEmbedded = message.getHeaders().get("cbrProficiencyTextsEmbedded");
    def sfsfAttributeType = message.getHeaders().get("sfsfAttributeType");

    def Root = new XmlParser().parseText(body);
    def cbrIds = '';
    Root.file.each{f->
        f.attribute.each{s->
            def sId = s.id[0].text().replaceFirst("cbr_", "")
            if(cbrIds==''){
                cbrIds = '\\\"'+sId+'\\\"';
            }else{
                cbrIds = cbrIds+',\\\"'+sId+'\\\"';
            }
        }
    }
    message.setProperty("cbrIds",cbrIds);   
    message.setProperty("cbrProficiencyTextsEmbedded",cbrProficiencyTextsEmbedded); 
    message.setProperty("sfsfAttributeType",sfsfAttributeType); 
    return message;
}


Message process_payload(Message message) {
    def body = message.getBody(String);
    def map = message.getProperties();
    def cbrProficiencyTextsEmbedded = map.get("cbrProficiencyTextsEmbedded");
    def sfsfAttributeType = map.get("sfsfAttributeType");
    def xml = new XmlParser().parseText(body)
    def valueMapApi = ITApiFactory.getService(ValueMappingApi.class, null);

    def entityType = 'skillsByIds';
    if(sfsfAttributeType=='COMPETENCY'){
        entityType = 'competenciesByIds';
    }

    xml."${entityType}".each { attrib ->
        if(attrib.id[0]){
            // Prefix the ID
            def idNode = attrib.id[0];
            idNode.value = 'cbr_' + idNode.text();
    
            if(cbrProficiencyTextsEmbedded == 'true'){
                //merge proficiency level description to the attribute description
                attrib.translations.each { trans ->
                    def originalDesc = trans.description.text().trim();
                    def language = trans.language.text().trim();
                
                    def mergedDesc = trans.'proficiencyLevelRequirements'.collect { levelNode ->
                        def level = levelNode.level.text();
                        def desc = levelNode.description.text().trim();
                        
                        def levelName = valueMapApi.getMappedValue('Cobrainer', 'ProficiencyLevel', level, 'cbrInt_SuccessFactors_TIH', 'ProficiencyName_'+language);
                        if(!levelName){
                            levelName = level; //use level number if translation is not found 
                        }
                        
                        "${levelName} - ${desc}"
                    }.join("\n\n");
                    
                    // Merge into the <description> text
                    def newDescription = originalDesc + "\n\n" + mergedDesc;
                    trans.description[0].value = newDescription;
        
                    // Remove original nodes
                    trans.'proficiencyLevelRequirements'*.replaceNode {};
                }
            }
        }
    }

    def resultXml = XmlUtil.serialize(xml)
    message.setBody(resultXml)
    return message
}

Message setException_noTextFound(Message message) {
    def map = message.getProperties();
    String sfsfAttributeType = map.get('sfsfAttributeType');
    throw new IllegalArgumentException("No Attribute Texts Found in Cobrainer for Attribute Type: "+sfsfAttributeType);
}

Message setException_apiError(Message message) {
    def bodyStr = message.getBody(String);
    def body = message.getBody(java.io.Reader);
    def errorMsg = '';
    if(bodyStr.contains('errorCode')){
        // Parse the JSON payload
        def json = new JsonSlurper().parse(body)
        
        // Extract values from the first error object
        def error = json.errors[0];
        errorMsg = error.message;
    }else{
        def exception = message.getProperties().get('CamelExceptionCaught');
        errorMsg = exception != null ? exception.toString() : "Unknown error occurred";
    }
    //set exception
    throw new IllegalArgumentException("GET_COBRAINER_ATTRIBTEXTS_ERROR: '"+errorMsg+"'");
}


