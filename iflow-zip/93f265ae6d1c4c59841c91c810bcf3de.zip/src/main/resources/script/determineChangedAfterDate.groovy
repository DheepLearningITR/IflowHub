import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
   //Properties 
   def map = message.getProperties();
   def daysBefore = map.get("DaysBefore");
   def today = new Date();
   def dateFrom = today - daysBefore.toInteger();
   def dateFromFormat = dateFrom.format("yyyy-MM-dd") + "T00:00:00.000Z";
   
   message.setProperty("ChangedAfterDate", dateFromFormat);
   return message;
}