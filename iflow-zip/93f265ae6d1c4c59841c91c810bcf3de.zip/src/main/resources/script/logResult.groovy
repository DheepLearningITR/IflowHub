import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;


def Message logFailedResult(Message message) {
    def props = message.getProperties();
	def property_ENABLE_MPL_LOGGING = props.get("EnableLog");
	if("TRUE".equalsIgnoreCase(property_ENABLE_MPL_LOGGING)){
	    def body = message.getBody(java.lang.String) as String;
        def messageLog = messageLogFactory.getMessageLog(message);
	    if (messageLog != null) {
            messageLog.addAttachmentAsString("Offerings batch creation - failed", body, "text/xml");
	    }
	}
    return message;
}


def Message logAllResult(Message message) {
    def props = message.getProperties();
	def property_ENABLE_MPL_LOGGING = props.get("EnableLog");
	if("TRUE".equalsIgnoreCase(property_ENABLE_MPL_LOGGING)){
	    def body = message.getBody(java.lang.String) as String;
	    def bodyXml = new XmlSlurper().parseText(body);
        def successOfferingIds = bodyXml.data.Response.Success.'**'.findAll{node -> node.name() =='OfferingID'}*.text();
        def failedOfferingIds = bodyXml.data.Response.Failure.'**'.findAll{node -> node.name() =='OfferingID'}*.text();
        def messageLog = messageLogFactory.getMessageLog(message);
	    if (messageLog != null) {
            if(!successOfferingIds.isEmpty()){
                messageLog.addAttachmentAsString("All success offering IDs", successOfferingIds.toString(), "text/xml");

            }
            if(!failedOfferingIds.isEmpty()){
                messageLog.addAttachmentAsString("All failed offering IDs", failedOfferingIds.toString(), "text/xml");

            }
	    }
	     
	   
	}
    return message;
}

def Message logAllFailureResult(Message message) {
    def props = message.getProperties();
	def property_ENABLE_MPL_LOGGING = props.get("EnableLog");
	
	def body = message.getBody(java.lang.String) as String;
    if(body == null || body.length() == 0) {
        message.setBody("empty");
        message.setProperty("FailedIDs","nullData");
    } else {
        if("TRUE".equalsIgnoreCase(property_ENABLE_MPL_LOGGING)) {
            body = '<Failure>' + body + '</Failure>';
            def bodyXml = new XmlSlurper().parseText(body);
            def failureProductNum = bodyXml.OfferingID.size();
            def messageLog = messageLogFactory.getMessageLog(message);
	        if (messageLog != null) {
                messageLog.addAttachmentAsString("All offering IDs (" + failureProductNum + ") - failure", body, "text/xml");
	        }
	    }
    }
	
    return message;
}

def Message logAllSuccessResult(Message message) {
    def props = message.getProperties();
	def property_ENABLE_MPL_LOGGING = props.get("EnableLog");
	if("TRUE".equalsIgnoreCase(property_ENABLE_MPL_LOGGING)){
	    
	    def body = message.getBody(java.lang.String) as String;
        if(body != null && body.length() > 0){
            body = '<Success>' + body + '</Success>';
            def bodyXml = new XmlSlurper().parseText(body);
            def successProductNum = bodyXml.OfferingID.size();
            def messageLog = messageLogFactory.getMessageLog(message);
	        if (messageLog != null) {
                messageLog.addAttachmentAsString("All offering IDs ( " + successProductNum + " ) - success", body, "text/xml");
	        }
        }
	   
	}
    return message;
}