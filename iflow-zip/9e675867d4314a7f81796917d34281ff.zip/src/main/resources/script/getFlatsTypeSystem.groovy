// =============================================================================================
// This groovy script is responsible to set the corresponding Document Standard of the incoming Message
// IDocFlat is considered in the intial release
// Extended to support VDA Automotive flat
//
//History:
//  2025-08-27 SAP [MÖ] - Extended to support VDA Automotive flat
//  2024-10-25 SAP [MÖ] - Initially created
// =============================================================================================
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message){
    
    String body = message.getBody(String);
    String[] lines = body.tokenize("\n");
    if (lines[0].substring(0, 8).trim() == "EDI_DC40" || lines[0].substring(0, 6).trim() == "EDI_DC"){
         message.setHeader("SAP_EDI_Document_Standard", "SAP_IDoc_Flat");
    }
    else if (lines[0].substring(0, 3) ==~ /^\d{3}$/) {
        message.setHeader("SAP_EDI_Document_Standard", "VDA-AUTOMOTIVE");
    }
    else {
        throw new Exception("Error! Document Standard is not yet supported.");
    }
    
    return message;
}