/*
DESCRIPTION
Release version 1.0.0
SAP SE 2020
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Map
import java.util.Iterator
import javax.activation.DataHandler
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import javax.mail.BodyPart;
import org.apache.commons.codec.binary.Base64;
import org.apache.camel.impl.DefaultAttachment;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    //Body 
   def messageLog = messageLogFactory.getMessageLog(message);
   def body = message.getBody(java.lang.String) as String;
   def bodyxml = new XmlSlurper()
   
   bodyxml.setFeature("http://apache.org/xml/features/disallow-doctype-decl", false) 
   bodyxml.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
   
   Map<String, DataHandler> attachments = message.getAttachments()
   HashMap<String,String> Base64Hashmap=new HashMap<String,String>(); 
   Iterator<String> keys;
   def finalcontent;

   int count
   
   if (attachments.isEmpty()) {
      // Handling of missing attachment goes here
        messageLog.setStringProperty("Logging#CheckAttachment", "No attachment")
   } else {
       
        messageLog.setStringProperty("Logging#CheckAttachment", "attachment")
        messageLog.setStringProperty("Logging#No.of Invoices:", String.valueOf(attachments.size()));
         
      Iterator<DataHandler> iterator = attachments.values().iterator()
      
      int cxml = 0;
      while (iterator.hasNext()) 
      {
        DataHandler datahandler = iterator.next()
        
        String contentType = datahandler.getContentType()
        String parentcid = contentType.substring(contentType.indexOf("start=") + "start=".length(), contentType.indexOf("type="))
        parentcid = parentcid.substring(1, parentcid.length()-3);
        
        messageLog.setStringProperty("Logging#Nparentcid:" + 1, String.valueOf(parentcid));
        
        MimeMultipart multipart = (MimeMultipart) datahandler.getContent();
        count = multipart.getCount();
        messageLog.setStringProperty("Logging#No.of Attachment:", String.valueOf(count));
        
        BodyPart bodyPart = multipart.getBodyPart(parentcid); 
        
        // Get Inputstream for each attachment
        ByteArrayInputStream bai = (ByteArrayInputStream)bodyPart.getInputStream();
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];

        for (;;) 
        {
            int nread = bai.read(buf, 0, buf.length);
            if (nread <= 0) {
                break; }

        baos.write(buf, 0, nread);
        }
        
        // Convert data to Base64 String and prepare HashMap
        byte[] bytepayload = baos.toByteArray();
        baos.flush();
        baos.close();
        bai.close();
        
        def xmlcontent = bodyxml.parseText(new String(bytepayload));
        xmlcontent.'**'.findAll { it.name() == 'Attachment' }.each {
           node ->
           
           String cid = String.valueOf(node);
           cid = "<" + cid.substring(contentType.indexOf("cid:") + "cid:".length() + 1) + ">";
           
          bodyPart = multipart.getBodyPart(cid); 
        
        // Get Inputstream for each attachment
        bai = (ByteArrayInputStream)bodyPart.getInputStream();
	    baos = new ByteArrayOutputStream();
        buf = new byte[8192];

        for (;;) 
        {
            int nread = bai.read(buf, 0, buf.length);
            if (nread <= 0) {
                break; }

        baos.write(buf, 0, nread);
        }
        
        // Convert data to Base64 String and prepare HashMap
        bytepayload = baos.toByteArray();
        baos.flush();
        baos.close();
        bai.close();
        
           String encodedBytes = Base64.encodeBase64String(bytepayload);
           //messageLog.addAttachmentAsString(cid, String.valueOf(encodedBytes), "text/plain") 
           
           node.replaceBody(String.valueOf(encodedBytes));
        }
        
        def serializedata = XmlUtil.serialize(xmlcontent);
        String cxmlencoded = String.valueOf(serializedata).bytes.encodeBase64().toString();
         
        def parent;
        if (finalcontent == null)
         {
          finalcontent = bodyxml.parseText("<MultiCxmlMessage>"+cxmlencoded+"</MultiCxmlMessage>")
         }
         else
         {
             parent =  bodyxml.parseText("<MultiCxmlMessage>"+cxmlencoded+"</MultiCxmlMessage>")
             finalcontent.appendNode(parent);
         }
         //finalcontent.appendNode(xmlcontent);
         cxml++;
      }
      
// Seralize replaced data and update message body
       body = XmlUtil.serialize(finalcontent)
       messageLog.addAttachmentAsString("finalcontent:", String.valueOf(body), "text/plain") 
       message.setBody(body)
   }
   return message

}