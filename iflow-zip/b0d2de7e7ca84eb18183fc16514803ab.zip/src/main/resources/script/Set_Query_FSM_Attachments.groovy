import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.util.XmlSlurper;
import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def parsedObj = new XmlSlurper().parseText(body);
    def map = message.getProperties();
    String Attachment_DTO = map.get("Attachment_DTO");
    String BusinessPartner_DTO = map.get("BusinessPartner_DTO");
    String ServiceCall_DTO = map.get("ServiceCall_DTO");
    Set <String> ObjectList = new HashSet <String> ();
    String param = "(";
    String queryContent;
    
    ArrayList CRM_Attachment_IDs = [];
    parsedObj.AttachmentFolderReplicateRequestMessage.AttachmentFolder.Document.each{
        CRM_Attachment_IDs.add(it.VersionID.toString().trim());
    }
    message.setProperty("CRM_Attachment_IDs",CRM_Attachment_IDs);
    
    String objTypeCode = parsedObj.AttachmentFolderReplicateRequestMessage[0].AttachmentFolder.HostObjectReference.ObjectTypeCode.toString().trim();
    
    parsedObj.AttachmentFolderReplicateRequestMessage.each {
        ObjectList.add(it.AttachmentFolder.HostObjectReference.ObjectID.text())
    }
    
    ObjectList.each {param += "\'" + "0000000000".substring(it.length()) + it + "\'" + ","}
    param = param.substring(0, param.length()-1);
    param += ")";
    
    String newJson="{}";
    def jsonSlurper = new JsonSlurper();
    def newJsonObject = jsonSlurper.parseText(newJson);
    
    if (objTypeCode == '117') {
        queryContent = "SELECT at.externalId FROM Attachment at JOIN ServiceCall sc ON at.object.objectId = sc.id WHERE at.externalId IS NOT NULL AND sc.externalId IN" + param;
        message.setProperty("query_dtos", Attachment_DTO + ";" + ServiceCall_DTO);
    } else if (objTypeCode == '441') {
        queryContent = "SELECT at.externalId FROM Attachment at JOIN BusinessPartner bp ON at.object.objectId = bp.id WHERE at.externalId IS NOT NULL AND bp.externalId IN" + param;
        message.setProperty("query_dtos", Attachment_DTO + ";" + BusinessPartner_DTO);
    }
    newJsonObject.put("query", queryContent)
    
    message.setBody(JsonOutput.toJson(newJsonObject));
    return message;
}
