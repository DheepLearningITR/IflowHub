import com.sap.it.api.mapping.*;

def String checkExternalId(String value) {
    def result;
    if (value.matches("^[0-9]*\$")) {
        result = 'true';
    } else {
        result = 'false';
    }

	return result;
}
