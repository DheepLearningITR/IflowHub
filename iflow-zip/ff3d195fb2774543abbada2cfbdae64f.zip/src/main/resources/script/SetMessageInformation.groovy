import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {

    def json = message.getBody(java.io.Reader);
    def input  = new JsonSlurper().parse(json);
    def payLoadHeader = input.header
    message.setBody('[\"' + payLoadHeader.receiverBpn + '\"]')
    
    input.header.senderBpn = message.getProperties().get('senderBpn')
    def payloadJson = new JsonBuilder(input)
    message.setProperty("Send_Notification_Payload",payloadJson.toPrettyString())
    
    return message;
}