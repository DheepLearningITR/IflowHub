import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    def connectorEndpointMap = [:]
    connectorEndpointMap.connectorEndpoinArray = input
   
    message.setProperty('partnerEDCUrlArray', connectorEndpointMap.connectorEndpoinArray[0].connectorEndpoint)
    message.setProperty('partnerEDCUrlArraySize', connectorEndpointMap.connectorEndpoinArray[0].connectorEndpoint.size())
    message.setProperty('connectorIndex', 0)
    message.setProperty('partnerBPN', connectorEndpointMap.connectorEndpoinArray[0].bpn)

    return message
}
