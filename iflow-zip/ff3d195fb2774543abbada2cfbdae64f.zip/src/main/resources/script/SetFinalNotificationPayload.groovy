import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
  
    def send_Notification_Payload = message.getProperty("Send_Notification_Payload")
    message.setBody(send_Notification_Payload.toString())
    return message
}