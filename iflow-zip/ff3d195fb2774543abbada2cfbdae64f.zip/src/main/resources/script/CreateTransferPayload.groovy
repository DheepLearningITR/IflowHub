import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
 	Reader json = message.getBody(java.io.Reader)
    def contract = new JsonSlurper().parse(json)
    def contractOfferMap = [:]
    getContractOfferPayload(contractOfferMap,contract,message)
    def contractOfferJson = new JsonBuilder(contractOfferMap)
    message.setHeader('Content-Type', 'application/json' + '; charset=utf-8')        
    message.setBody(contractOfferJson.toPrettyString())
    return message;
}

def getContractOfferPayload(def contractOfferMap, def contract,def message) {
	def contextMap = [:]
	def querySpecMap = [:]
    def dataDestinationMap = [:]
    def privatePropertiesMap = [:]
    def dataRequestMap = [:]
    def transferTypeMap = [:]
    def propertiesMap = [:]
    def dataSourceMap = [:]
    def dataSourcePropMap = [:]

    def partnerEDCUrl = message.getProperties().get("partnerEDCUrl")
    def providerDsp = message.getProperties().get("providerDsp")
    def partnerBPN = message.getProperties().get("partnerBPN")
    def edrCallbackUrl = message.getProperties().get('Integration_Flow') + '/http/edr_callback_notification'
    def edrAuthKey = message.getProperties().get('EdrAuthKey')
    def edrAuthCode = message.getProperties().get('EdrAuthCode')
    def assetId = contract."edc:assetId"
    def agreementId = contract."@id"

	contextMap."odrl" = "http://www.w3.org/ns/odrl/2/"
	contextMap."edc" = "https://w3id.org/edc/v0.0.1/ns/"
	contextMap."@vocab" = "https://w3id.org/edc/v0.0.1/ns/"
	contractOfferMap."@context" = contextMap
    contractOfferMap."@type" = "TransferRequest"
    dataSourceMap."type" = "DataAddress"
    dataSourcePropMap."type" = "HttpData"
    dataSourceMap."properties" = dataSourcePropMap
    contractOfferMap."edc:dataSource" = dataSourceMap
	contractOfferMap."edc:connectorAddress" = partnerEDCUrl+providerDsp
	contractOfferMap."edc:protocol" = "dataspace-protocol-http"
    contractOfferMap."edc:managedResources" = false
    contractOfferMap."edc:contractId" = agreementId
    contractOfferMap."edc:assetId" = assetId
	contractOfferMap."edc:connectorId" = partnerBPN

    contractOfferMap."edc:dataDestination" = dataDestinationMap
    dataDestinationMap."type" = "DataAddress"
    dataDestinationMap."properties" = propertiesMap
    propertiesMap."type" = "HttpProxy"

    contractOfferMap."edc:privateProperties" = privatePropertiesMap
    privatePropertiesMap.'edc:receiverHttpEndpoint' = edrCallbackUrl
    privatePropertiesMap.'edc:receiverHttpDynamicAuthKey' = edrAuthKey
    privatePropertiesMap.'edc:receiverHttpDynamicAuthCode' = edrAuthCode
    
    contractOfferMap."edc:dataRequest" = dataRequestMap
    dataRequestMap."contractId" = agreementId

    contractOfferMap."edc:transferType" = transferTypeMap
    transferTypeMap."contentType" = "application/octet-stream"
    transferTypeMap."isFinite" = true
}