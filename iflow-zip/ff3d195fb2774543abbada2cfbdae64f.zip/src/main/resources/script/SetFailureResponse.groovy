import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
  
    String errorMsg = message.getBody(java.lang.String) as String
    String mplIdErrorMsg = "(" + message.getHeaders().get('SAP_MessageProcessingLogID') + ").";
    def send_Notification_Payload = message.getProperty("Send_Notification_Payload")
    def input = new JsonSlurper().parseText(send_Notification_Payload)
    
    input.content.remove('listOfAffectedItems')
    input.content.status = "FAILURE"
    input.content.information = 'Integration Flow ran into an error in Enhanced SAP Business Network Material Traceability Send Notification, please check the error log or contact your Integration Suite administrator ' + mplIdErrorMsg
    def payloadJson = new JsonBuilder(input)
    
    message.setBody(payloadJson.toPrettyString())
    message.setHeader("CamelHttpResponseCode", "500");
    message.setHeader("Content-Type", "application/json");
    
    return message
}
