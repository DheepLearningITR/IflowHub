import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder
import java.time.LocalDate
import groovy.time.TimeCategory
import java.util.Date
import java.text.SimpleDateFormat
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message) {

 	def body = message.getBody(java.io.Reader);
	def send_Notification_Payload = message.getProperty("Send_Notification_Payload")
    
    def catalogs = new JsonSlurper().parse(body)
    def payload = new JsonSlurper().parseText(send_Notification_Payload)
    def payLoadHeader = payload.header
    def payLoadContent = payload.content
    def context = payLoadHeader.context
    def status = payLoadContent.status
    def recipientBpn = payLoadHeader.recipientBpn

	def var1 = ''
	def var2 = ''
	
    if(context =="TRACE-QM-Investigation:1.0.0" || context =="Traceability-QualityNotification-Investigation:2.0.0"){
        var1 = "qualityinvestigation"
    }else if(context =="TRACE-QM-Alert:1.0.0" || context =="Traceability-QualityNotification-Alert:2.0.0"){
        var1 = "qualityalert"
    } 
    if( status == "SENT"){
        var2 = "receive"
    }else{
        var2 = "update"
    }
    Closure query1 = { it."edc:notificationtype" == var1 && it."edc:notificationmethod" == var2 }
    def filterlist = []
    try{
        filterlist = catalogs."dcat:dataset".findAll (query1)
    }catch(def e){
        //contract not found, continue
        return message
    }

    if(filterlist.size() > 0) {
        def mtJson = new JsonBuilder(filterlist[0])
        message.setBody(mtJson.toPrettyString())
        message.setProperty('ContractOfferFound', 'Y')
    }

    return message
}