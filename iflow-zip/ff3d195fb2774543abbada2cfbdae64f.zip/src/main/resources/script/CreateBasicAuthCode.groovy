import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.AccessTokenAndUser

def Message processData(Message message) {
    
    def credential_alias = message.getProperty('Integration_Flow_Credential_Alias')
    def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)
    def secureParameter = secureStorageService.getUserCredential(credential_alias)
    def user = secureParameter.getUsername()
    def pas = secureParameter.getPassword().toString()
    def str = user + ':' + pas
    def basicToken =  str.bytes.encodeBase64().toString()
    
    message.setProperty('EdrAuthCode', 'Basic ' + basicToken);
    return message;
}