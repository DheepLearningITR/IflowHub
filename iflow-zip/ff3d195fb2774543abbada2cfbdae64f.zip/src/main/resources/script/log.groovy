import java.util.HashMap;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def map = message.getProperties()
    def messageLog = messageLogFactory.getMessageLog(message);
    def send_Notification_Payload = message.getProperty("Send_Notification_Payload")
    
    String errorMsg = message.getBody(java.lang.String) as String
    String mplIdErrorMsg = " (" + message.getHeaders().get('SAP_MessageProcessingLogID') + ")";
    errorMsg = errorMsg + mplIdErrorMsg
    def ex = map.get("CamelExceptionCaught");
    if (ex != null) {
        errorMsg = errorMsg + ", Exception msg: " + ex.getMessage()
    }
    messageLog.addAttachmentAsString("Exception", errorMsg, "text/plain");
    messageLog.addAttachmentAsString("Request body", send_Notification_Payload, "application/json");
    message.setBody(errorMsg);
        
    return message;
}