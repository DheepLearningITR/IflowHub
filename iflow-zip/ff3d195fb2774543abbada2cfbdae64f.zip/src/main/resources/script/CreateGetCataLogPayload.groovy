import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def connectorIndex = message.getProperties().get('connectorIndex')
    def partnerEDCUrlArraySize = message.getProperties().get('partnerEDCUrlArraySize')
    if(connectorIndex >= partnerEDCUrlArraySize) {
	    String errorMsg = "No asset found";
        throw new Exception(errorMsg);
    }
     
    def catalogMap = [:]
    getCataLogPayload(catalogMap,message)
    def mtJson = new JsonBuilder(catalogMap)
    message.setBody(mtJson.toPrettyString())
    message.getHeaders().remove('CamelHttpPath')
    message.setHeader('Content-Type', 'application/json' + '; charset=utf-8' )
    
    message.setProperty('ContractOfferFound', 'N')
    def nextConnectorIndex = connectorIndex + 1
    message.setProperty('connectorIndex', nextConnectorIndex)
        
    return message;
}

def getCataLogPayload(def catlogMap, def message) {
    def contextMap = [:]
    def querySpecMap = [:]
   
    def providerDsp = message.getProperties().get('providerDsp')
    def connectorIndex = message.getProperties().get('connectorIndex')
    def partnerEDCUrlArray = message.getProperties().get('partnerEDCUrlArray')
    
    def partnerEDCUrl = partnerEDCUrlArray[connectorIndex]
    message.setProperty('partnerEDCUrl', partnerEDCUrl)
    
    contextMap.'edc' = 'https://w3id.org/edc/v0.0.1/ns/'
    contextMap.'@vocab' = 'https://w3id.org/edc/v0.0.1/ns/'
    catlogMap.'@context' = contextMap
    catlogMap.'@type' = 'CatalogRequest'
    catlogMap.'edc:protocol' = 'dataspace-protocol-http'
    catlogMap.'edc:counterPartyAddress' = partnerEDCUrl + providerDsp
    querySpecMap.'@type' = 'QuerySpec'
    querySpecMap.'edc:sortOrder' = 'ASC'
    querySpecMap.'edc:offset' = 0
    querySpecMap.'edc:limit' = 100
    catlogMap.'edc:querySpec' = querySpecMap
}