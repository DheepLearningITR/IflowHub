import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
 	Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    def callbackWaitContinueRetry = 'Y'
    def callbackTimeOut = 'N'
    def callbackConfirmed = 'N'
    def callBackStartTime = message.getProperties().get('callBackStartTime')
    long t1
    long t2
    if(callBackStartTime == null) {
        Date date = new Date()
        message.setProperty('callBackStartTime', date.getTime())
        callbackTimeOut = 'N'
    } else {
        t1 = callBackStartTime
        Date date = new Date()
        t2 = date.getTime()
        if(t2 - t1 > 180000) {
            callbackTimeOut = 'Y'
        } else {
            callbackTimeOut = 'N'
        }
    }
    if(input.size() > 0) {
      callbackConfirmed = 'Y'
    }
    if(callbackTimeOut == 'N' && callbackConfirmed == 'N') {
        callbackWaitContinueRetry = 'Y'
        sleep(12000)
    } else {
        callbackWaitContinueRetry = 'N'
    }
    message.setProperty('callbackWaitContinueRetry', callbackWaitContinueRetry)
    return message
}