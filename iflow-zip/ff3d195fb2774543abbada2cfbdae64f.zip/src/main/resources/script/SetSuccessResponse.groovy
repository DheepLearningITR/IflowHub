import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
  
    def send_Notification_Payload = message.getProperty("Send_Notification_Payload")
    def input = new JsonSlurper().parseText(send_Notification_Payload)
    input.content.remove('listOfAffectedItems')
    input.content.status = "SUCCESS"
    def payloadJson = new JsonBuilder(input)
    
    message.setBody(payloadJson.toPrettyString())
    message.setHeader("CamelHttpResponseCode", "200");
    message.setHeader("Content-Type", "application/json");
    
    return message
}