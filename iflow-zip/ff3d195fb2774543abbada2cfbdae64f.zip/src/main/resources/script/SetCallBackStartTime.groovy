import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    Date date = new Date()
    message.setProperty('callBackStartTime', date.getTime())
    return message
}
