package main.resources.script
import com.sap.gateway.ip.core.customdev.util.Message;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;

def Message processData(Message message) {

	def service = ITApiFactory.getApi(SecureStoreService.class, null);
	def pw;

	//---------------------------------------------------------------------------------------------------------
	//Service Account Id
	credential = service.getUserCredential("GoogleAnalytics_ServiceAccountId");
	if (credential == null){
		pw = new String();
	}else{
	    pw = credential.getPassword().toString();
	}
	message.setProperty("sa_client_id",pw);

	//---------------------------------------------------------------------------------------------------------
	//Service Account Email
	credential = service.getUserCredential("GoogleAnalytics_ServiceAccountEmail");
	if (credential == null){
		pw = new String();
	}else{
	    pw = credential.getPassword().toString();
	}
	message.setProperty("sa_client_email",pw);

	return message;
}
