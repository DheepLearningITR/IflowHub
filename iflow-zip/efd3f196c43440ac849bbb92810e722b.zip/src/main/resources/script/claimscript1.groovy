import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String);
       def jsonSlurper = new JsonSlurper()
       def object = jsonSlurper.parseText(body.toString());
       def id=object.value.ID.join(",")
       message.setProperty("ID",id);
   
       return message;
}