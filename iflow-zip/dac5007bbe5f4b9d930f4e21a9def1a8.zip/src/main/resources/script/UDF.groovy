import com.sap.it.api.mapping.*;
import java.util.Date;
import java.util.TimeZone;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String generateMessageID(String arg1, MappingContext context){	
	
	String messageID = java.util.UUID.randomUUID().toString()
	context.setHeader("SapMessageId", messageID.toUpperCase().replaceAll("-",""))
	context.setHeader("SapMessageIdEx", messageID)	
	return messageID.toUpperCase().replaceAll("-","") 

}
def String getSessionID(String arg1, MappingContext context){	
		return context.getProperty("_pUID"); 
		}
		
def String formatUUID(String uuid){	
	return (uuid.substring(0,8)+"-"+uuid.substring(8, 12)+"-"+uuid.substring(12, 		16)+"-"+uuid.substring(16,20)+"-"+uuid.substring(20));
}
def String SystemID(String _PID, MappingContext context){
	return context.getProperty(_PID);
}
def String CurrentUTC_Time(String arg1){
	TimeZone.setDefault(TimeZone.getTimeZone('UTC'))
	def now = new Date()
	return now.format("yyyy-MM-dd'T'HH:mm:ss'Z'")
}