import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message generateSessionId(Message message) {
 
  String _pUID = java.util.UUID.randomUUID().toString().toUpperCase()
  message.setProperty("_pUID", _pUID)
  return message
}

def Message buildQueryParameter(Message message) {

  def pmap = message.getProperties();
  def messageLog = messageLogFactory.getMessageLog(message);

  String DeltaToken = pmap.get("DeltaToken");
  String Query;

  if (DeltaToken == null || DeltaToken.equals("") || DeltaToken.equals("null")) {
    Query = "";
  } else {
    Query = '$deltatoken=' + DeltaToken
  }
  if (pmap.initialLoad == "true") {
    Query = ""
  };
  message.setProperty("Query", Query);
  return message;
}

def Message setTokens(Message message) {

  def body = message.getBody(java.lang.String) as String;
  def prop = message.getProperties();

  def json = body.replace("@odata.", "odata");

  def root = new JsonSlurper().parseText(json);
  def nextLink = root.odatanextLink
  def deltaLink = root.odatadeltaLink

  def link, hasMoreEvents, tokens, token
  if (nextLink) {
    link = nextLink;
    hasMoreEvents = true;
  } else {
    if (deltaLink) {
      link = deltaLink;
      hasMoreEvents = false;
    }
  }

  if (link) {
    tokens = link.split('=');
    token = tokens[1];
  }

  prop.DeltaToken = token;
  prop.hasMoreEvents = hasMoreEvents;

  def noValue = "false"
  if (root.value.isEmpty()) {
    noValue = "true"
  }
  prop.noValue = noValue;

  return message;
}

def Message removeEvents(Message message) {
  def body = message.getBody(java.lang.String) as String;
  def root = new JsonSlurper().parseText(body);

  if (root.value != '') {
    def values = root.value;
    def validValues = values.findAll {
      it.event != 'rejected' && it.instance != null && it.instance.displayId != null
    }
    root.value = validValues;
    message.setBody(JsonOutput.toJson(root));
  }
  return message;

}

def Message transformMdiProtocol(Message message) {
  def body = message.getBody(java.lang.String) as String;
  def root = new JsonSlurper().parseText(body);

  //get the newest instance
  def map1 = [: ];
  root.value.each() {
    map1[it.instance.id] = it
  };

  // rebuild payload
  def list = [];
  map1.each {
    key,
    val -> list.add(val)
  };
  root.value = list;
  def builder = new JsonBuilder(root);

  //output
  def out = builder.toString();
  message.setBody(out);
  return message;
}