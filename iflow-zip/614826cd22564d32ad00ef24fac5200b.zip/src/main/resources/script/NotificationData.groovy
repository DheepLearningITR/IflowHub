import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {

    //Getting Properties
    def properties = message.getProperties()
    //def p_themeColor = properties.ThemeColor
    def p_imageUrl = properties.ImageURL

    //Getting Body
    def json = new JsonSlurper().parseText(message.getBody(java.lang.String))

    def factsBodyArray = []
    def factsAttachmentArray = []
    def fact = []

    //Capturing body fields to add to 'section' array
    json.each { key, value ->
        if (key != "Add_attachment") {
            fact = [
                name: formatFieldName(key),
                value: value
            ]
            factsBodyArray.add(fact)
        }
    }

    //Capturing array 'Add_attachment' to add to 'section' array
    //json.Add_attachment.each { attachment ->
      //  attachment.each { key, value ->
        //    fact = [
            //    name: formatFieldName(key),
          //      value: value
            //]
            //factsAttachmentArray.add(fact)
      //  }
    //}

    //Creating JSON structure
    def builder = new JsonBuilder()

    builder {
        "@type" "MessageCard"
        "@context" "http://schema.org/extensions"
        //themeColor p_themeColor
        summary "New Task Created"
        sections ([
            //Creating the first 'section' part with Title, subtitle and image
            [
                activityTitle: "Incident Management Notification",
                activitySubtitle: "Service Now",
                activityImage: p_imageUrl
            ],
            //Creating the second 'section' part with all fields and values from the body of the input json
            [
                activityTitle: "Hi Team \
                New user created in Incident Management from SF",
                
         facts: factsBodyArray.collect {[
                name: it.name,
                value: it.value
                ]},
                markdown: true
            ]
            //Creating the third 'section' part with all fields and values from 'Add_attachment' array of the input json
            //[
               // activityTitle: "Attachment",
               // facts: factsAttachmentArray.collect {[
//name: it.name,
               //     value: it.value
              //  ]},
               // markdown: true
          //  ]
        ])
    }

    message.setBody(builder.toPrettyString())
    
    return message
}

//Function to format field name
String formatFieldName(String fieldName) {
    //Split by underscores
    def words = fieldName.split('_')
    
    //Capitalize each word
    def formattedWords = words.collect { it.capitalize() }

    //Join words with spaces
    def formattedFieldName = formattedWords.join(' ')

    return formattedFieldName
}