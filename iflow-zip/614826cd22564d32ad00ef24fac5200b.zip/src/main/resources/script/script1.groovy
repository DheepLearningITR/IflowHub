import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.ZoneId

def Message processData(Message message) {

	 def header = message.getHeaders()
    String HTTPStatus = header.get("CamelHttpResponseCode")

	
    // Getting Body
    String body = message.getBody(java.lang.String)
    json = new JsonSlurper().parseText(body)

 try {
        if (HTTPStatus == "200"){
            message.setProperty("Incident Success", "NO")
            status = "S"
            jsonMessage = "Goods Receipt Reversed"
        } else {
            def json = new JsonSlurper().parseText(body)
            message.setProperty("Incident1", "YES")
            status = "E"
            jsonMessage = json?.error?.innererror?.errordetails?.findAll { it.severity == "error" }?.message
                            ?: json?.error?.message?.value
                            ?: "Unknown error"
        }
    } catch (Exception e) {
        message.setProperty("Incident2", "YES")
        status = "E"
        jsonMessage = "Could not parse JSON in body. Body may be empty or invalid."
    }

    def builder = new JsonBuilder()

    builder {
        "category_Code" json.category_Code
        "priority_Code" json.priority_Code
        "description" json.description
        "Add_attachment" ""
        Add_attachment json.Add_attachment.collect {[
            incident_ID: it.incident_ID
        ]}
    }
	
    message.setBody(builder.toPrettyString())
    return message
}
