import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonOutput;
import java.nio.charset.StandardCharsets;

def Message processData(Message message) {
    //Get Signature
    def signature = message.getBody(java.lang.String);
    
    //Get the reference of JSON Invoice
    def json = message.getProperty("JSON_Invoice");

    //Add Signature to JSON Invoice
    json.documents[0].signatures = [[signatureType: "I", value: signature]];
    
    message.setBody(JsonOutput.toJson(json).getBytes(StandardCharsets.UTF_8));
    
    return message;
}