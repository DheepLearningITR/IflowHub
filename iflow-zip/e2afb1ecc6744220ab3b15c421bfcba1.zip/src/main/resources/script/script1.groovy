/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
def Message processData(Message message) {
  //Signature
       def json_invoice = message.getBody();

       
       //def json = json_invoice.getClass();
       
      //  message.setProperty("Type_JSON", json);
       def json = new JsonSlurper().parseText(json_invoice.getText("UTF-8"));
       
       json.documents.each {
           
           it.invoiceLines.each{
               
             //extract the value of invoiceLines.invoiceLines for later "put" new key-value  
             arr = it.invoiceLine;               
               
               it.invoiceLine.each{

//+ Begin of change Moin Khan  
               if (it.quantity){ 
               it.quantity=it.quantity.toBigDecimal();
               }
               if (it.itemsDiscount){ 
               it.itemsDiscount=it.itemsDiscount.toBigDecimal();
               }
               
//+ End of change Moin Khan
               if (it.salesTotal){ 
               it.salesTotal=it.salesTotal.toBigDecimal();
               }
               
               if (it.salesTotal){ 
               it.salesTotal=it.salesTotal.toBigDecimal();
               }
           
               if (it.total){ 
               it.total=it.total.toBigDecimal();
               }
       
               if (it.valueDifference){ 
               it.valueDifference=it.valueDifference.toBigDecimal();
               }
         
               if (it.totalTaxableFees){ 
               it.totalTaxableFees=it.totalTaxableFees.toBigDecimal();
               }
               
               if (it.netTotal){ 
               it.netTotal=it.netTotal.toBigDecimal();
               }
               
               if (it.unitValue.amountSold){ 
              it.unitValue.amountSold=it.unitValue.amountSold.toBigDecimal();
               }
    
               if (it.unitValue.amountEGP){ 
               it.unitValue.amountEGP=it.unitValue.amountEGP.toBigDecimal();
               }
               
               if (it.unitValue.currencyExchangeRate){ 
               it.unitValue.currencyExchangeRate=it.unitValue.currencyExchangeRate.toBigDecimal();
               }

//+ Begin of change Moin Khan               
               /*if (it.discount){
                   
                   it.discount.each{

                   if (it.rate){ 
                   it.rate=it.rate.toBigDecimal();
                   }
               
                   if (it.amount){ 
                   it.amount=it.amount.toBigDecimal();
                   } 
                   }
               }*/
               
               if (it.discount.amount){ 
               it.discount.amount=it.discount.amount.toBigDecimal();
               }
            
               if (it.discount.rate){ 
               it.discount.rate=it.discount.rate.toBigDecimal();
               }    
//+ End of change Moin Khan                  
                it.taxableItems.each{
                   if (it.amount){ 
                   it.amount=it.amount.toBigDecimal();
                   } 
                //+ Begin of change Moin Khan
                   if (it.rate){ 
                   it.rate=it.rate.toBigDecimal();
                   }
                //+ End of change Moin Khan
                }
              }
           }
           
           if (it.totalDiscountAmount){ 
           it.totalDiscountAmount=it.totalDiscountAmount.toBigDecimal();
           }
     
           if (it.totalSalesAmount){ 
           it.totalSalesAmount=it.totalSalesAmount.toBigDecimal();
           }
           
           if (it.netAmount){ 
           it.netAmount=it.netAmount.toBigDecimal();
           }
           
           it.taxTotals.each{
//+ Begin of change Moin Khan               
           //if (it.taxTotal.amount){ mk
           //it.taxTotal.amount=it.taxTotal.amount.toBigDecimal(); mk
           if (it.amount){ 
               it.amount=it.amount.toBigDecimal();
           }
           if (it.rate){ 
               it.rate=it.rate.toBigDecimal();
           }
//+ End of change Moin Khan           
           }
           
           if (it.totalAmount){ 
           it.totalAmount=it.totalAmount.toBigDecimal();
           }
           
           if (it.extraDiscountAmount){ 
           it.extraDiscountAmount=it.extraDiscountAmount.toBigDecimal();
           }
           
           if (it.totalItemsDiscountAmount){ 
           it.totalItemsDiscountAmount=it.totalItemsDiscountAmount.toBigDecimal();
           }
           
         // substitute the value of 'invoiceLines'  
         it.invoiceLines = arr; 
           
       }

//Convert JSON with Backslash
    jsonOP = JsonOutput.toJson(json);
    
 //	jsonOP = jsonOP.replaceAll("&", /\\u0026/); 
    //jsonOP = jsonOP.replaceAll("\\", /\\u005c/);
 	jsonOP = jsonOP.replaceAll(/\\u00f6/, "oe"); 
 	jsonOP = jsonOP.replaceAll(/\\u00e4/, "ae"); 
 	jsonOP = jsonOP.replaceAll(/\\u00fc/, "ue");
 	jsonOP = jsonOP.replaceAll(/\\u00df/, "ss"); 
 	
        message.setBody(jsonOP);

       return message;
}