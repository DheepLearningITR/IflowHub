import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.ArrayList;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import java.lang.String;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

def JsonOutput.JsonUnescaped jsonUnescaped(String value) {
    return JsonOutput.unescaped('"' + value + '"');
}

def void stringToJSONUnescaped(Map<String, String> details, List<String> keyList) {
    for (String key: keyList) {
        def value = details.get(key);
        if (value) {
            details.putAt(key, jsonUnescaped(value));
        }
    }
}

def void stringToBigDecimal(Map<String, String> details, List<String> keyList) {
    for (String key: keyList) {
        def value = details.get(key);
        if (value) {
            details.putAt(key, value.toBigDecimal());
        }
    }
}

def void processAddressDetails(Map<String, String> details) {
    List<String> toJSONUnescapedList = ["branchID", "country", "governate", "regionCity", "street",
                                      "buildingNumber", "postalCode", "floor", "room", "landmark",
                                      "additionalInformation"];
    if (!details) {
        return;
    }
    
    if (details.branchId) {
        details.branchID = details.branchId;
        details.remove("branchId");
    }
    
    stringToJSONUnescaped(details, toJSONUnescapedList);
}

def void processIssuerDetails(Map<String, Object> details) {
    List<String> toJSONUnescapedList = ["type", "id", "name"];
    if (!details) {
        return;
    }
    stringToJSONUnescaped(details, toJSONUnescapedList);
    
    //Issuer Address
    processAddressDetails(details.address);
}

def void processReceiverDetails(Map<String, Object> details) {
    List<String> toJSONUnescapedList = ["type", "id", "name"];
    if (!details) {
        return;
    }
    stringToJSONUnescaped(details, toJSONUnescapedList);
    
    //Receiver Address
    processAddressDetails(details.address);
}

def void processPaymentDetails(Map<String, String> details) {
    List<String> toJSONUnescapedList = ["bankName", "bankAddress", "bankAccountNo", "bankAccountIBAN",
                                      "swiftCode", "terms"];
    if (!details) {
        return;
    }
    stringToJSONUnescaped(details, toJSONUnescapedList);
}

def void processDeliveryDetails(Map<String, String> details) {
    List<String> toJSONUnescapedList = ["approach", "packaging", "dateValidity", "exportPort",
                                      "countryOfOrigin", "terms"];
    List<String> toBigDecimalList = ["grossWeight", "netWeight"];
    if (!details) {
        return;
    }
    stringToJSONUnescaped(details, toJSONUnescapedList);
    stringToBigDecimal(details, toBigDecimalList);
}

def void processInvoiceLineDetails(Map<String, Object> details) {
    List<String> toJSONUnescapedList = ["description", "itemType", "itemCode", "unitType", "internalCode", "weightUnitType"];
    List<String> toBigDecimalList = ["quantity", "salesTotal", "total", "valueDifference", "totalTaxableFees",
                                   "netTotal", "itemsDiscount", "weightQuantity"];
    if (!details) {
        return;
    }
    
    stringToJSONUnescaped(details, toJSONUnescapedList);
    stringToBigDecimal(details, toBigDecimalList);
    
    //Unit Value Details
    processUnitValueDetails(details.unitValue);
    
    //Discount Details
    processDiscountDetails(details.discount);
    
// Taxable Items Details
if (details.taxableItems && details.taxableItems[0]?.taxableItem) {
    details.taxableItems = details.taxableItems[0].taxableItem;
    details.taxableItems.each {
        processTaxableItemDetails(it);
    }
} else {
    // Add empty taxableItems array if not present
    details.taxableItems = [];
}
}

def void processUnitValueDetails(Map<String, String> details) {
    List<String> toJSONUnescapedList = ["currencySold"];
    List<String> toBigDecimalList = ["amountEGP", "amountSold", "currencyExchangeRate"];
    if (!details) {
        return;
    }
    stringToJSONUnescaped(details, toJSONUnescapedList);
    stringToBigDecimal(details, toBigDecimalList);
}

def void processDiscountDetails(Map<String, String> details) {
    List<String> toBigDecimalList = ["rate", "amount"];
    if (!details) {
        return;
    }
    stringToBigDecimal(details, toBigDecimalList);
}

def void processTaxableItemDetails(Map<String, String> details) {
    List<String> toJSONUnescapedList = ["taxType", "subType"];
    List<String> toBigDecimalList = ["amount", "rate"];
    if (!details) {
        return;
    }
    stringToJSONUnescaped(details, toJSONUnescapedList);
    stringToBigDecimal(details, toBigDecimalList);
}

def void processTaxTotalDetails(Map<String, String> details) {
    List<String> toJSONUnescapedList = ["taxType"];
    List<String> toBigDecimalList = ["amount"];
    if (!details) {
        return;
    }
    stringToJSONUnescaped(details, toJSONUnescapedList);
    stringToBigDecimal(details, toBigDecimalList);
}

def List<JsonOutput.JsonUnescaped> processReferenceDetails(List<String> details) {
    List<JsonOutput.JsonUnescaped> references = new ArrayList<JsonOutput.JsonUnescaped>();
    
    details.each {
        references.add(jsonUnescaped(it));
    }
    
    return references;
}

def void processDocumentDetails(Map<String, Object> details) {
    List<String> toJSONUnescapedList = ["documentType", "documentTypeVersion", "dateTimeIssued", "taxpayerActivityCode",
                                      "internalID", "purchaseOrderReference", "purchaseOrderDescription", "salesOrderReference",
                                      "salesOrderDescription", "proformaInvoiceNumber"];
    List<String> toBigDecimalList = ["totalSalesAmount", "totalDiscountAmount", "netAmount", "extraDiscountAmount",
                                   "totalItemsDiscountAmount", "totalAmount"];
    if (!details) {
        return;
    }
    
    //Issuer Details
    processIssuerDetails(details.issuer);
    
    //Receiver Details
    processReceiverDetails(details.receiver);
    
    //Payment Details
    processPaymentDetails(details.payment);
    
    //Delivery Details
    processDeliveryDetails(details.delivery);
    
    //Invoice Line Details
    //Remove invoiceLine attribute
    details.invoiceLines = details.invoiceLines[0].invoiceLine;
    details.invoiceLines.each {
        processInvoiceLineDetails(it);
    }
    
    //Tax Total Details
    //Remove taxTotal attribute
    details.taxTotals = details.taxTotals[0].taxTotal;
    details.taxTotals.each {
        processTaxTotalDetails(it);
    }
    
    //Process Other Document Details    
    stringToJSONUnescaped(details, toJSONUnescapedList);
    stringToBigDecimal(details, toBigDecimalList);
    
    //Reference for Credit/Debit
    //Remove references
    if (details.references) {
        details.references = processReferenceDetails(details.references[0].reference);
    }
    
    //Process Signature
    details.remove("signatures");
}

def Message processData(Message message) {
    
    def bodyBuffer = message.getBody(java.nio.ByteBuffer);
    byte[] bytes = bodyBuffer.array();
  
    def properties = message.getProperties();
    def docType = properties.get("documentType");

    def json = new JsonSlurper().parse(bytes, "UTF-8");

    //Remove "document" Attribute
    json.documents = json.documents[0].document;

    //Process Each Document
    json.documents.each {
        processDocumentDetails(it);
    }
    
    //Check Whether Digital Signature Is Required
    if (json.documents[0].documentTypeVersion.toString().equals('"1.0"')) {
        message.setProperty("signatureType", "I");
    }
    
    message.setProperty("JSON_Invoice", json);
    
    def jsonOP = JsonOutput.toJson(json);
    
    message.setBody(jsonOP.getBytes(StandardCharsets.UTF_8));
    
    return message;
}