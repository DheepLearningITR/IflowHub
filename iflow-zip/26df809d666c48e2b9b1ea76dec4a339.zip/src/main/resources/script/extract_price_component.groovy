import groovy.xml.StreamingMarkupBuilder;
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
def Message processData(Message message) {
    
    
   def price_xml = message.getBody(java.lang.String) as String;

   def root = new XmlSlurper(false, true).parseText(price_xml);
   
   def tag = "Price_";
   
   // set PriceComponent as property
   root.PricingElement.each(
       
      {
          it -> if(message.getProperty(tag + it.PriceEntryIndicator.text()) != null)
          {
            message.setProperty(tag + it.PriceEntryIndicator.text(), message.getProperty(tag + it.PriceEntryIndicator.text()) + groovy.xml.XmlUtil.serialize(it).replace('''<?xml version="1.0" encoding="UTF-8"?>''',''))
          }else{
            message.setProperty(tag + it.PriceEntryIndicator.text(), groovy.xml.XmlUtil.serialize(it).replace('''<?xml version="1.0" encoding="UTF-8"?>''',''))
          }
          
      }
      
    )
       
	return message;
}