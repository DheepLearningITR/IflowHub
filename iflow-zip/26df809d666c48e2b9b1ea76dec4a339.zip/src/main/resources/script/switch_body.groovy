import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.String;
import javax.xml.xpath.*
import javax.xml.parsers.DocumentBuilderFactory

def Message processData(Message message) {
    	
	def body = message.getBody(java.lang.String) as String;
	String omsOrderPayload = message.getProperty("OMS_ORDER_PAYLOAD");
    
    message.setProperty("MAPPED_OMS_ORDER", body)
    message.setBody(omsOrderPayload)
	
   return message;
}    
