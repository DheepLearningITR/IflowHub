/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
       //Body 
       def body = message.getBody(java.lang.String);
       String url;
       String cloudConnection;
       def map = message.getHeaders();
	   def messageHeader=map.get("Content-Type");
	   
	   if(messageHeader.equals("application/json"))
       {
           def jsonSlurper = new JsonSlurper()
           def object = jsonSlurper.parseText(body.toString());
           url=object.destinationConfiguration.URL;
           cloudConnection=object.destinationConfiguration.CloudConnectorLocationId;
       }else if(messageHeader.equals("application/octet-stream"))
       {
           String [] output = body.split('\n')
                     .drop(1);
                     
          for(String value : output)
          {
               if(value.contains("URL"))
               {
                  String [] urlSplitted = value.split("=");
                  url = urlSplitted.drop(1).join("=");
                  if(url.contains("\\"))
                  {
                      url=url.replaceAll("\\\\","");
                  }
                   
               }else if(value.contains("CloudConnectorLocationId"))
               {
                 println("CloudConnectorLocationId found")
                   String [] valueToSplit = value.split("=");
                   cloudConnection= valueToSplit[1];
               }
          }
       }
       
        message.setProperty("SOAPAddress",url);
        message.setProperty("CloudConnectorLocationId",cloudConnection);

       return message;
}