import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import java.util.*;
import groovy.json.JsonBuilder;
import groovy.lang.*;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String);
       def jsonSlurper = new JsonSlurper()
       def object = jsonSlurper.parseText(body.toString());
	   def list=[];
	   def payload;

       def notificationType=object.qualityNotifications.qnType;
	   def material=object.qualityNotifications.material_ID;
       def plant=object.qualityNotifications.plant_ID;
	   def quantity=object.qualityNotifications.quantity;
       def unit=object.qualityNotifications.unit;
	   def defect=object.qualityNotifications.defect;
	   def supplierDetails=object.supplierDetails;
	   def personDetails=object.personDetails;
       def purchaseOrderNumber=object.qualityNotifications.purchaseOrderNumber;
       def purchaseOrderItem=object.qualityNotifications.purchaseOrderItem;
       def referenceNumber=object.qualityNotifications.referenceNumber; 
       def subjectCode=object.qualityNotifications.subjectCode_code;
	   def subjectCodeGroup=object.qualityNotifications.subjectCode_subjectCodeGroup_code;
	   def processDescription=object.qualityNotifications.processDescription;
		
	   def json = new JsonBuilder();
	    payload= json notificationType:notificationType,material:material,plant:plant,quantity:quantity,unit:unit,defect:defect,supplierDetails:supplierDetails,personDetails:personDetails,
		purchaseOrderNumber:purchaseOrderNumber,purchaseOrderItem:purchaseOrderItem,referenceNumber:referenceNumber,
		subjectCode:subjectCode,subjectCodeGroup:subjectCodeGroup,processDescription:processDescription
	   
// 	   if (bostatuses instanceof ArrayList) {
// 		       payload= json identifier:identifier, qnType:qnType, quantity:quantity, unit:unit, purchaseOrderNumber:purchaseOrderNumber, purchaseOrderItem:purchaseOrderItem, supplierCode:supplierCode, personResponsibleCode:personResponsibleCode, materialCode:materialCode, //createdBy:createdBy,
// 		plantCode:plantCode, purchaseOrganisationCode:purchaseOrganisationCode, referenceNumber:referenceNumber, defect:defect, businessObjectStatuses:bostatuses,
// 		subjectCode_code:subjectCode_code,subjectCode_subjectCodeGroup_code:subjectCode_subjectCodeGroup_code,processDescription:processDescription
// 	   }else{
//         list.add(bostatuses);
//         payload= json identifier:identifier, qnType:qnType, quantity:quantity, unit:unit, purchaseOrderNumber:purchaseOrderNumber, purchaseOrderItem:purchaseOrderItem, supplierCode:supplierCode, personResponsibleCode:personResponsibleCode, materialCode:materialCode, //createdBy:createdBy,
// 		plantCode:plantCode, purchaseOrganisationCode:purchaseOrganisationCode, referenceNumber:referenceNumber, defect:defect, businessObjectStatuses:list,
// 		subjectCode_code:subjectCode_code,subjectCode_subjectCodeGroup_code:subjectCode_subjectCodeGroup_code,processDescription:processDescription
//      }
		
 
      message.setBody(groovy.json.JsonOutput.toJson(payload));
      return message;
}