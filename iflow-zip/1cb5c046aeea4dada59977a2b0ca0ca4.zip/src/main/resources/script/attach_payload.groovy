import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.MessageLog;

def Message processData(Message message) {

    def headers = message.getHeaders();
	MessageLog messageLog = messageLogFactory.getMessageLog(message);

    if(messageLog != null){
        Integer fetchPackageNumber = headers.get("IBPReadFetchPackageNumber") as Integer;
        messageLog.addAttachmentAsString(fetchPackageNumber + '. Package Payload', message.getBody(String), 'text/xml')
        fetchPackageNumber += 1;
        message.setHeader("IBPReadFetchPackageNumber", fetchPackageNumber);
    }
	return message;
}