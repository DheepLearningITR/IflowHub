import com.sap.gateway.ip.core.customdev.util.Message;
import javax.xml.xpath.*
import javax.xml.parsers.DocumentBuilderFactory

def Message processData(Message message) {
    def body = message.getBody();
    def map = message.getProperties();
    def xpath = XPathFactory.newInstance().newXPath()
    def builder = DocumentBuilderFactory.newInstance().newDocumentBuilder()
    def inputStream = new ByteArrayInputStream( body.bytes )
    def records = builder.parse(inputStream).documentElement
	
	readValue(message, "FirstName", "FirstNameFieldName", xpath, records)
	readValue(message, "MiddleName", "MiddleNameFieldName", xpath, records)
	readValue(message, "LastName", "LastNameFieldName", xpath, records)
	readValue(message, "DateOfBirth", "DateOfBirthFieldName", xpath, records)
	readValue(message, "Address", "StreetAddressFieldName", xpath, records)
	readValue(message, "Zip", "ZIPFieldName", xpath, records)
	readValue(message, "CellPhone", "CellPhoneFieldName", xpath, records)
	readValue(message, "HomePhone", "HomePhoneFieldName", xpath, records)
	message.setProperty("ContactEmail", xpath.evaluate('/JobApplication/JobApplication/contactEmail', records ))
	message.setProperty("CandidateId", xpath.evaluate('/JobApplication/JobApplication/candidateId', records ))

    return message;
}

def readValue(Message message, String propertyName, String fieldName, xpath, records) {
	def nodeName = message.getProperty(fieldName);
    message.setProperty(propertyName, nodeName != null && nodeName != "" ? xpath.evaluate('/JobApplication/JobApplication/' + nodeName, records ) : "");
}