import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def map = message.getProperties();
    
    def suffix = map.get("CompanyUrlSuffix");
    if (suffix == null || suffix == "") {
        return invalidConfig(message, "Invalid configuration. Value of parameter 'Company URL Suffix' cannot be blank.");
    }
    
    def days = map.get("NumberOfDaysBetweenAssessments");
    if (days == null || !days.isInteger() || days.toInteger() < 0) {
        return invalidConfig(message, "Invalid configuration. Value of parameter 'Number of Days Between Assessments' must be an non-negative integer.");
    }

    def address = map.get("SuccessFactors Address");
    if (address == null || address == "") {
        return invalidConfig(message, "Invalid configuration. Value of parameter 'Success Factors Address' cannot be blank.");
    }

    def credential = map.get("SuccessFactors Credentials");
    if (credential == null || credential == "") {
        return invalidConfig(message, "Invalid configuration. Value of parameter 'Success Factors Credential Name' cannot be blank.");
    }

    def validUrl = true;
    try {
        def url = new java.net.URL(map.get("RedirectURL"));
    } catch (Exception e) {
        validUrl = false;    
    }
    if (!validUrl) {
        return invalidConfig(message, "Invalid configuration. Value of parameter 'Redirect URL must be a valid URL.");
    }
    message.setProperty("ValidConfig", "yes");
	
	message.setProperty("ListOfFields", 
		addToList(map, "FirstNameFieldName") +
		addToList(map, "MiddleNameFieldName") +
		addToList(map, "LastNameFieldName") +
		addToList(map, "DateOfBirthFieldName") +
		addToList(map, "StreetAddressFieldName") +
		addToList(map, "ZIPFieldName") +
		addToList(map, "CellPhoneFieldName") +
		addToList(map, "HomePhoneFieldName")
	);

    return message;
}

def Message invalidConfig(Message message, String errorMessage) {
    message.setProperty("ValidConfig", "no");
    message.setProperty("ErrorCode", "INVALID_CLOUD_PLATFORM_INTEGRATION_CONFIGURATION");
    message.setProperty("ErrorMessage", errorMessage);
    return message;
}

def String addToList(Map<String, Object> map, String propertyName) {
    def propertyValue = map.get(propertyName);
    if (propertyValue != null && propertyValue != "") {
        return "," + propertyValue;
    }
    return "";
}
