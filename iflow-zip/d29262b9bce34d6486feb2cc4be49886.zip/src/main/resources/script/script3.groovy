import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.SimpleDateFormat;

def Message processData(Message message) {
    def Calendar cal = Calendar.getInstance();
    def map = message.getProperties();
    def NumberOfDaysBetweenAssessments = map.get("NumberOfDaysBetweenAssessments");
    cal.add(Calendar.DATE, -1 * NumberOfDaysBetweenAssessments.toInteger());
    def SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd")
    message.setProperty("dateLimitForAssessments", sdf.format(cal.getTime()));
    return message;
}