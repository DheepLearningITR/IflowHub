import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;

def Message processData(Message message) {
    def map = message.getProperties();
    def latestRecentCompletedAssessmentOrderDate = map.get("latestRecentCompletedAssessmentOrderDate");
    def status = map.get("status");
    def statusDate = map.get("statusDate");
    def currentAssessmentOrderId = map.get("currentAssessmentOrderId");
    if (status == '0') {
        def SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S");
        def Date today = new Date();
        def diff = (today.getTime() - sdf.parse(statusDate).getTime()) / 1000 / 60 / 60 / 24;
        if (diff < 16 && statusDate > latestRecentCompletedAssessmentOrderDate) {
            message.setProperty("latestRecentCompletedAssessmentOrderDate", statusDate);
            message.setProperty("latestRecentCompletedAssessmentOrderId", currentAssessmentOrderId);
        }
    }
    return message;
}