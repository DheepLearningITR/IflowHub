import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;

def Message processData(Message message) {
    def SimpleDateFormat fromFormat = new SimpleDateFormat("YYYY-MM-DD'T'HH:mm:SSZ");
    def SimpleDateFormat toFormat = new SimpleDateFormat("YYYY-MM-DD'T'HH:mm:SSZ");
    def map = message.getProperties();
    def statusDate = map.get("statusDate");
    message.setProperty("statusDateUtc", toFormat.format(fromFormat.parse(statusDate)));
}