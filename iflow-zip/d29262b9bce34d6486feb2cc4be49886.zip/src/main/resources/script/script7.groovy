import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def map = message.getProperties();
    
	def AssessmentOrderId = map.get("AssessmentOrderId");
	if (AssessmentOrderId == null || AssessmentOrderId == "" || !(AssessmentOrderId ==~ ~/\d+/)) {
	    return invalidInput(message, "Invalid Input. Value of parameter 'AssessmentOrderId' cannot be blank and must contain only numbers.");
    }
    
    message.setProperty("ValidInput", "yes");
    return message;
}

def Message invalidInput(Message message, String errorMessage) {
    message.setProperty("ErrorCode", "INVALID_INPUT");
    message.setProperty("ErrorMessage", errorMessage);
    message.setProperty("ValidInput", "no");
    return message;
}