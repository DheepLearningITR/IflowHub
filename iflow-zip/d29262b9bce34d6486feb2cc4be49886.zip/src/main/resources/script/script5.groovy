import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def map = message.getProperties();
    def orderId = map.get("AssessmentOrderId");
    def statusDate = map.get("LatestCompletedAssessmentDate");
    def body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><AssessmentReports><AssessmentReport><orderId>" + orderId + "</orderId><status>0</status><statusDate>" + statusDate + "Z</statusDate>";
    for (int i = 1; i < 20; i++) {
        def FieldKey = map.get("Field" + i + "Key");
        if (FieldKey > "") {
            body += "<Field" + i + "Key>" + FieldKey + "</Field" + i + "Key><Field" + i + "Value>" + map.get("Field" + i + "Value") + "</Field" + i + "Value>";
        }
      }
    body += "</AssessmentReport></AssessmentReports>";
    message.setBody(body);
    return message;
}