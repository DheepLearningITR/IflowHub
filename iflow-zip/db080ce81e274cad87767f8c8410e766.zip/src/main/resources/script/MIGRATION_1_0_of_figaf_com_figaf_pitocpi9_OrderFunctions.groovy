import com.sap.it.api.mapping.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;

def String PartnerName(String partner, MappingContext context) {
return "Hi "+partner;
}
