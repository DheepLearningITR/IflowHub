import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import java.util.ArrayList;

def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
    def body = message.getBody(java.lang.String) as String
    def jsonParser = new JsonSlurper()
    def map = message.getProperties()
    
    
    int sIndex = map.get("index").toInteger()
    def sPayload = map.get("payload")
    def jsonObject = jsonParser.parseText(sPayload)
    def l_antecipate = ''
    
    // messageLog.addAttachmentAsString("PayloadAHGORA", JsonOutput.prettyPrint(body), "text/json");
    
    def operation = jsonObject.request.ferias[sIndex].operation
    def pernr = jsonObject.request.ferias[sIndex].employee
    def l_payday =  (jsonObject.request.ferias[sIndex].payday == null) ? "" : "X"
    message.setProperty("operation",  operation)
    message.setProperty("pernr",  pernr)
    message.setProperty("cod",  jsonObject.request.ferias[sIndex].code)
    message.setProperty("payday",  l_payday)
    
   l_antecipate =  (jsonObject.request.ferias[sIndex].allowance != null && jsonObject.request.ferias[sIndex].allowance != '' && jsonObject.request.ferias[sIndex].allowance != '0') ? 'x' : jsonObject.request.ferias[sIndex].anticipate
    
    message.setProperty("antecipate", l_antecipate)
    
    def arr = []
    def json
    json = {}
    
    if (jsonObject.request.ferias[sIndex].allowance == null) {
        json = JsonOutput.toJson(
            operation : jsonObject.request.ferias[sIndex].operation,
            code : jsonObject.request.ferias[sIndex].code,
            externalcode : jsonObject.request.ferias[sIndex].externalcode,            
            employee : (jsonObject.request.ferias[sIndex].employee == null) ? "" : jsonObject.request.ferias[sIndex].employee,
            start : (jsonObject.request.ferias[sIndex].start == null) ? "" : jsonObject.request.ferias[sIndex].start,
            end : (jsonObject.request.ferias[sIndex].end == null) ? "" : jsonObject.request.ferias[sIndex].end,
            anticipate : (jsonObject.request.ferias[sIndex].anticipate == null ) ? "" : jsonObject.request.ferias[sIndex].anticipate,
            payday : (jsonObject.request.ferias[sIndex].payday == null) ? "" : jsonObject.request.ferias[sIndex].payday,
        )        
    } else {
        json = JsonOutput.toJson(
            operation : jsonObject.request.ferias[sIndex].operation,
            code : jsonObject.request.ferias[sIndex].code,
            externalcode : jsonObject.request.ferias[sIndex].externalcode,            
            employee : (jsonObject.request.ferias[sIndex].employee == null) ? "" : jsonObject.request.ferias[sIndex].employee,
            start : (jsonObject.request.ferias[sIndex].start == null) ? "" : jsonObject.request.ferias[sIndex].start,
            end : (jsonObject.request.ferias[sIndex].end == null) ? "" : jsonObject.request.ferias[sIndex].end,
            anticipate : (jsonObject.request.ferias[sIndex].anticipate == null ) ? "" : jsonObject.request.ferias[sIndex].anticipate,
            payday : (jsonObject.request.ferias[sIndex].payday == null) ? "" : jsonObject.request.ferias[sIndex].payday,
            allowance : (jsonObject.request.ferias[sIndex].allowance == null) ? null : jsonObject.request.ferias[sIndex].allowance,
        )        
    }

    
    arr.push(json)
    
    message.setBody(JsonOutput.prettyPrint(arr.toString().substring(1, arr.toString().toString().length() - 1)))
    
    sIndex = sIndex + 1
    
    message.setProperty("index",  sIndex)  
    
    return message;
    
}