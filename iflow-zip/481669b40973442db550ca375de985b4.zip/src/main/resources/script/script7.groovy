/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    
    def body = message.getBody(java.lang.String) as String
    def jsonParser = new JsonSlurper()
    
    def map = message.getProperties()
    def sResponse = map.get("response")
    def array = []
    def sPernr = map.get("pernr")
    def sCod = map.get("cod")
    def sAttach = sPernr + "-RESP"   
    def jsonObject = jsonParser.parseText(body)
    
    json = {}
    json = JsonOutput.toJson(
        matricula : sPernr,
        code : sCod,
        status : 'E',
        mensagem : 'Erro ao consumir WS',
    )       
    
    if( sResponse != null && sResponse != ''){
        array.push(sResponse)    
    }
    array.push(json)
    
    // messageLog.addAttachmentAsString(sAttach, JsonOutput.prettyPrint(body), "text/json");
    // messageLog.addAttachmentAsString("ResponseAHGORA", JsonOutput.prettyPrint(array.toString()), "text/json");
    
    message.setProperty("response", JsonOutput.prettyPrint(array.toString().substring(1, array.toString().length() - 1)))
    message.setBody(JsonOutput.prettyPrint(array.toString())) 
    
   return message;
}