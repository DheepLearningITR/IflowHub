import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
    def body = message.getBody(java.lang.String) as String
    def map = message.getProperties()
    def sPernr = map.get("pernr")
    def sAttach = sPernr + "-REQ"
    
    // messageLog.addAttachmentAsString(sAttach, body, "text/xml");
    
    return message;
    
}

