import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message prepareQueryFilter(Message message) {

  def properties = message.getProperties()
  def quoteDisplayId = properties.get("P_quoteDisplayId")

  def textFilter = "\$filter=isactiverevision%20eq%20%27true%27%20and%20QuoteNumber%20eq%20%27" + quoteDisplayId + "%27"

  message.setProperty("P_queryFilter", textFilter)

  return message
}

def Message extractQuoteId(Message message) {
  def body = message.getBody(java.io.Reader)
  def pagedRecords = new JsonSlurper().parse(body).PagedRecords

  def quoteId = pagedRecords[0].QuoteId

  message.setProperty("P_quoteId", quoteId)

  return message
}