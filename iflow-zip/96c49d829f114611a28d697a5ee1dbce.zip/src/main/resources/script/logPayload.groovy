import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

CONTENT_TYPE_XML = "text/xml"
CONTENT_TYPE_PLAIN = "text/plain"
LOG_LEVEL_NORMAL = 1
LOG_LEVEL_VERBOSE = 2

def logInput(Message message){
    return _logPayload(message, 1, LOG_LEVEL_NORMAL, "Input payload", CONTENT_TYPE_XML)
}

def logStatementInitiationReq(Message message){
    return _logPayload(message, 2, LOG_LEVEL_VERBOSE, "Statement Initiation Request", CONTENT_TYPE_XML)
}

def logStatementInitiationReqEnc(Message message){
    return _logPayload(message, 2, LOG_LEVEL_VERBOSE, "Statement Initiation Request (Encrypted)", CONTENT_TYPE_XML)
}

def logStatementInitiationRespEnc(Message message){
    return _logPayload(message, 3, LOG_LEVEL_VERBOSE, "Statement Initiation Response (Encrypted)", CONTENT_TYPE_XML)
}

def logStatementInitiationRespDecrypt(Message message){
    return _logPayload(message, 4, LOG_LEVEL_VERBOSE, "Statement Initiation Response (Decrypted)", CONTENT_TYPE_XML)
}

def logStatementRetrieveReq(Message message){
    return _logPayload(message, 5, LOG_LEVEL_VERBOSE, "Statement Retrieve Request", CONTENT_TYPE_XML)
}

def logStatementRetrieveResponseEnc(Message message){
    return _logPayload(message, 6, LOG_LEVEL_VERBOSE, "Statement Retrieve Response (Encrypted)", CONTENT_TYPE_XML)
}

def logStatementRetrieveResponseDecrypted(Message message){
    return _logPayload(message, 7, LOG_LEVEL_VERBOSE, "Statement Retrieve Response (Decrypted)", CONTENT_TYPE_XML)
}

def logStatement(Message message){
    return _logPayload(message, 8, LOG_LEVEL_NORMAL, "Statement (Decrypted)", CONTENT_TYPE_XML)
}

def logOutput(Message message){
    return _logPayload(message, 9, LOG_LEVEL_NORMAL, "Output payload", CONTENT_TYPE_XML)
}

def logAuthRequestPayloadEnc(Message message){
    return _logPayload(message, 80, LOG_LEVEL_VERBOSE, "Auth Request (Encrypted)", CONTENT_TYPE_XML)
}

def logAuthResponsePayloadEnc(Message message){
    return _logPayload(message, 90, LOG_LEVEL_VERBOSE, "Auth Response (Encrypted)", CONTENT_TYPE_XML)
}

def logAuthResponsePayloadDecrypted(Message message){
    return _logPayload(message, 91, LOG_LEVEL_VERBOSE, "Auth Response (Decrypted)", CONTENT_TYPE_XML)
}

def _logPayload(Message message, int stepNo, int logType, String stepName, String contentType){
//    def body = message.getBody(java.lang.String) as String;
//    def messageLog = messageLogFactory.getMessageLog(message);
//    def propertyMap = message.getProperties()
    
//    Integer logLevel = propertyMap.get("logLevel").toInteger();
    
//    if(logLevel >= logType){
//        if(messageLog != null){
//            messageLog.addAttachmentAsString("${stepNo} ${stepName}:", body, contentType);
//        } 
//    }
    return message
}
