import com.sap.it.api.mapping.*;



def String customFunc(String property,MappingContext context){
	return context.getProperty(property)
}