import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
       //Get SessionID from Body
       String sessionid = message.getBody(String);
       //Get MATMAS and Salesforce Tenant URL
       HashMap map = message.getProperties();
       String matmas = map.get("MATMAS");
       String tenantsf = map.get("TenantSF");
       //Concatenate Salesforce Tenant to parameterized Search
       String url = new String("https://"+tenantsf+"/services/data/v51.0/parameterizedSearch")
       message.setHeader("URL", url);
       message.setHeader("Method", "POST");
       //Set Header for Content-Type and Authorization
       message.setHeader("Content-Type", "application/json");
       message.setHeader("Authorization", "Bearer "+ sessionid);
       //Output MATMAS
       message.setBody(matmas);
     return message;
}