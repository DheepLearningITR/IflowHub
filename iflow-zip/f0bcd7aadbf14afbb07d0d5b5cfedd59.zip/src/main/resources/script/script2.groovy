import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
        //Check Salesforce Response for an ProductID and concatenate ProductID to Salesforce Object
        String body = message.getBody(String);
        HashMap map = message.getProperties();
        String tenantsf = map.get("TenantSF");
        message.setHeader("Content-Type", "application/json");
        String url;
        if(body.contains("Id")){
            message.setHeader("Method", "PATCH");
            int i = body.indexOf("Id");
            String sf_id = body.substring(i+5,i+5+18);
            message.setHeader("ProductID", sf_id);
            url = new String("https://"+tenantsf+"/services/data/v51.0/sobjects/Product2/"+sf_id)
        }
        else{
            message.setHeader("Method", "POST");
            url = new String("https://"+tenantsf+"/services/data/v51.0/sobjects/Product2/")
        }
        message.setHeader("URL", url);
        return message;
}