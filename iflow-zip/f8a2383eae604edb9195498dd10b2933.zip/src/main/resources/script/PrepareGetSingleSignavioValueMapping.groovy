import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def valueMappingRequestBody = message.getBody(java.io.Reader)
    def valueMappingRequestBodyJson = new JsonSlurper().parse(valueMappingRequestBody)

    message.setProperty('valueMappingId', valueMappingRequestBodyJson.valueMappingId)
    message.setProperty('valueMappingVersion', valueMappingRequestBodyJson.valueMappingVersion)
    message.setProperty('isSignavioToRam', valueMappingRequestBodyJson.isSignavioToRam)
    return message
}