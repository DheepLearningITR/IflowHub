import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import java.util.zip.ZipInputStream


def Message processData(Message message) {
    def body = message.getBody()
    def isSignavioToRam = message.getProperty('isSignavioToRam')
    def xmlText = getValueMapping(new ByteArrayInputStream(body.bytes))
    def mappings = parseValueMapping(xmlText, isSignavioToRam)
    def mappingsJson = JsonOutput.toJson(mappings)

    message.setBody(mappingsJson)
    return message
}

def getValueMapping(input) {
    def zipInput = new ZipInputStream(input)
    try {
        def entry = zipInput.nextEntry
        while (entry != null) {
            if (entry == null) {
                break
            }
            if (entry.name == 'value_mapping.xml') {
                return zipInput.text
            }
        }
    } finally {
        zipInput.close()
    }
}


def parseValueMapping(xmlText, isSignavioToRam) {
    def xml = new XmlParser().parseText(xmlText)
    def mappings = [:]
    xml.children().each{parseGroupNode(it, mappings, isSignavioToRam)};

    return mappings.values()
}


def parseGroupNode(node, mappings, isSignavioToRam) {
    def source = node.entry[0]
    def target = node.entry[1]
    if (isSignavioToRam == 'false') {
        source = node.entry[1]
        target = node.entry[0]
    }

    def sourceAgency = source.agency.text()
    def sourceIdentifier = source.schema.text()
    def targetAgency = target.agency.text()
    def targetIdentifier = target.schema.text()
    // For export control, source is RAM side and target is Signavio side
    def key = "$sourceAgency $sourceIdentifier $targetAgency $targetIdentifier".toString()
    if (!mappings.containsKey(key)) {
        mappings[key] = createFieldMapping(sourceAgency, sourceIdentifier, targetAgency, targetIdentifier)
    }

    def mapping = mappings[key]
    mapping.valueMappings << createValueMapping(source, target)
}

def createFieldMapping(sourceAgency, sourceIdentifier, targetAgency, targetIdentifier) {
    def mapping = [:]
    mapping["sourceAgency"] = sourceAgency
    mapping["sourceIdentifier"] = sourceIdentifier
    mapping["targetAgency"] = targetAgency
    mapping["targetIdentifier"] = targetIdentifier
    mapping["valueMappings"] = []

    return mapping
}

def createValueMapping(source, target) {
    def valueMapping = [:]
    valueMapping["source"] = source.value.text()
    valueMapping["target"] = target.value.text()
    valueMapping["defaultMapping"] = target.'@isDefault' != null ? true : false

    return valueMapping;
}
