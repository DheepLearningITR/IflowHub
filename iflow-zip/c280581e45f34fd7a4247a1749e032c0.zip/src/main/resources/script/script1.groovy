import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
def Message processData(Message message) {

    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    
	Base64.Decoder decoder = Base64.getUrlDecoder();
    String[] authCodeParts = input.authCode.split("\\.");
    def jwt_body =  new String(decoder.decode(authCodeParts[1]))
	def jwt_body_json = new JsonSlurper().parseText(jwt_body)
	message.setHeader("CID",jwt_body_json.cid)
    return message
}