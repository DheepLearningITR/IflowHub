import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


def String setPricebookCode(String p1, MappingContext context) {
        
        context.setProperty("pricebookCode",p1);
        return p1;
}

def String setPrice(String p1, MappingContext context) {
    
        context.setProperty("price",p1);
        return p1;
}

def String setPriceCode(String p1, MappingContext context) {
    
        context.setProperty("priceCode",p1);
        return p1;
}

def String setPartNumber(String p1, MappingContext context) {
    
        context.setProperty("partNumber",p1);
        return p1;
}

