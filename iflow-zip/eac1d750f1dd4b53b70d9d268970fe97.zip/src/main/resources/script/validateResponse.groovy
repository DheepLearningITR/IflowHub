import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import javax.xml.bind.DatatypeConverter;
def Message processData(Message message) {
  /* Remove xml tag if exist  */
  def messageLog = messageLogFactory.getMessageLog(message);
  String payload = message.getBody(java.lang.String)
  
  String responseMessage= "ERRORS_FOUND_WHEN_IMPORTING";
  String responseStatus="NOK";
  if(payload.contains("ALL_ENTRIES_IMPORTED")){
      responseMessage = "ALL_ENTRIES_IMPORTED";
      responseStatus= "OK";
  }   
  message.setProperty("responseMessage",responseMessage);
  message.setProperty("responseStatus",responseStatus);
  return message;
}