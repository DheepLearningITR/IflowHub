import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    def body = message.getBody(String)

    if (body?.contains("500 - Internal Server Error from Interface")) {
        message.setProperty("IsInternalServerError", true)
    } else {
        message.setProperty("IsInternalServerError", false)
    }

    return message
}