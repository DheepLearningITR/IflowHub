/**
 * Script Name: writeParametersToMsgLog
 * Author: Christian Riesener
 * Date: 2024-05-18
 * Description: This script logs various operational properties of the SAP CI Flow, including connection configurations for LeanIX and SAP CI,
 *              and dynamically records them as custom header properties. It supports conditional detailed logging for debugging purposes based on the trace level.
 *
 * Modifications:
 *
 * Notes:
 * - The script is designed to enhance traceability and ease troubleshooting processes within SAP integrations.
 */

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Retrieve the message log object for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // Retrieve properties from the message and log them with null checks.
    def traceLevel = message.getProperty("TraceLevel");
    def isSimulationModeActive = message.getProperty("isSimulationModeActive");
    def FilterSender = message.getProperty("FilterSender");
    def FilterReceiver = message.getProperty("FilterReceiver");
    def FilterPackage = message.getProperty("FilterPackage");
    def FilterFlow = message.getProperty("FilterFlow");
    def SAPCI_Hostname = message.getProperty("SAPCI_Hostname");
    def SAPCI_Credentials = message.getProperty("SAPCI_Credentials");

    // Log each property as a custom header property in the message log.
    messageLog.addCustomHeaderProperty("Ctrl_TraceLevel", traceLevel ?: "Not specified");
    messageLog.addCustomHeaderProperty("Ctrl_Simulation", isSimulationModeActive ?: "Not specified");
    messageLog.addCustomHeaderProperty("Filter_Sender", FilterSender ?: "Not specified");
    messageLog.addCustomHeaderProperty("Filter_Receiver", FilterReceiver ?: "Not specified");
    messageLog.addCustomHeaderProperty("Filter_Flow", FilterFlow ?: "Not specified");
    messageLog.addCustomHeaderProperty("Filter_Package", FilterPackage ?: "Not specified");
    messageLog.addCustomHeaderProperty("SAPCI_Hostname", SAPCI_Hostname ?: "Not specified");
    messageLog.addCustomHeaderProperty("SAPCI_Credentials", SAPCI_Credentials ?: "Not specified");

    // Debugging logic: if trace level is debug, log all properties in a structured format.
    if (traceLevel == "debug") {
        messageLogFactory.getMessageLog(message)?.with {
            def content = new StringBuilder().with {
                it << "Properties".padRight(60, '-').padLeft(70, '-') + "\n";
                it << map(message.getProperties());
            };
            it.addAttachmentAsString("_Start Properties", content.toString(), "text/plain");
        }
    }

    return message;
}

// Helper function to format and sort message properties for logging.
def String map(Map map) {
    return map
        .sort { a, b -> a.key.toLowerCase() <=> b.key.toLowerCase() }
        .collect { "$it.key (${it.value.getClass().getSimpleName()}): $it.value" }
        .join("\n") + "\n\n";
}