/**
 * Script Name: filterFlows.groovy
 * Author: Christian Riesener
 * Date: 2024-05-14
 * Description: This script processes an XML input, filters flows based on provided regex patterns for Flow, Sender, and Receiver names, and converts the data into a simplified XML format. 
 *              It logs the total number of flows found and the number of flows after filtering as custom header properties. Additionally, it includes trace-level logging if specified.
 *
 * Modifications:
 *
 * Notes:
 * - The script retrieves the message body as an XML string and parses it into a Groovy XML object.
 * - It uses regex patterns from the message properties to filter the flows based on their names, sender, and receiver.
 * - The script constructs a simplified XML structure using MarkupBuilder and sets it as the new message body.
 * - The total number of flows before and after filtering are logged as custom header properties.
 * - Trace level logging is utilized to capture detailed information for debugging purposes.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder
import groovy.xml.XmlUtil
import java.io.StringWriter
import java.util.regex.Pattern

def Message processData(Message message) {
    // Retrieve the message log object for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // Retrieve properties from the message and log them with null checks.
    def traceLevel = message.getProperty("TraceLevel");
    
    // Definiere die Regex-Muster
    def regexPatternFlow = message.getProperty("FilterFlow") ?: ".*";
    def regexPatternSender = message.getProperty("FilterSender") ?: ".*";
    def regexPatternReceiver = message.getProperty("FilterReceiver") ?: ".*";
    
    // Get the input XML as a string
    def body = message.getBody(String);
    
    if (traceLevel == 'debug') {
        messageLog.addAttachmentAsString("SAP CI Flows before Filter", body, "text/plain");    
    }

    // Parse the XML string into a Groovy XML object
    def xmlParser = new XmlParser();
    def xml = xmlParser.parseText(body);
    
    // Prepare the result list
    def totalFlows = 0;
    def passedFlows = 0;
    def resultList = [];

    // Iterate through all <multimap:Message> elements and collect flows
    xml.each { messageElement ->
        messageElement.Response.Flows.Flow.each { flow ->
            totalFlows++
            def name = flow.Name.text()
            def sender = flow.Sender.text()
            def receiver = flow.Receiver.text()

            if (name ==~ regexPatternFlow && 
                //(sender.isEmpty() || sender ==~ regexPatternSender) &&
                //(receiver.isEmpty() || receiver ==~ regexPatternReceiver)) {
                (sender ==~ regexPatternSender) &&
                (receiver ==~ regexPatternReceiver)) {
                resultList << flow
                passedFlows++
            }
        }
    }
    
    // Create the simplified XML structure
    def writer = new StringWriter();
    def xmlBuilder = new MarkupBuilder(writer);
    
    xmlBuilder.Response {
        Flows {
            resultList.each { flow ->
                Flow {
                    Id(flow.Id.text())
                    Name(flow.Name.text())
                    Description(flow.Description.text())
                    Version(flow.Version.text())
                    PackageId(flow.PackageId.text())
                    Sender(flow.Sender.text())
                    Receiver(flow.Receiver.text())
                }
            }
        }
    }
    
    messageLog.addCustomHeaderProperty("__Found Flows in filtered Packages: ", totalFlows.toString());
    messageLog.addCustomHeaderProperty("__Flows after Filter: ", passedFlows.toString());
    
    if (traceLevel == 'debug') {
        messageLog.addAttachmentAsString("SAP CI Flows after Filter", writer.toString(), "text/plain");    
    }
    
    // Set the transformed XML as the message body
    message.setBody(writer.toString());
    
    return message;
}