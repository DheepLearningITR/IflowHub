/**
 * Script Name: buildUrlForVMCreation
 * Author: Christian Riesener
 * Date: 2024-05-14
 * Description: This script processes an incoming message by parsing XML to extract specific values, encoding URL parameters, and constructing a URL for VM creation. It also sets necessary headers and 
 * properties for further processing.
 *
 * Modifications:
 * 2024-11-06 by Jakov Kurakin
 * line 43 - Constat Id is now get from the Property("Value Mapping ID"), which can be configured individually
 *
 * Notes:
 * - Ensure that the incoming message body contains valid XML with the expected structure.
 * - The XML structure should include 'vmType' and 'vmName' within 'item' elements.
 * - This script is designed to be used within a split branch, so only one 'item' is expected per message.
 * - URL encoding is manually handled for 'vmName' and a placeholder value.
 * - Constants such as 'constId', 'constVersion', 'constSrcId', and 'constTgtId' are used to construct the URL parameters.
 * - The body of the message is set to an empty string to meet the requirements of the SAP CI Service for the UpsertVM call.
 * - The script sets 'Cookie' and 'X-CSRF-Token' headers, which are necessary for the update operations and should be fetched earlier in the process.
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import java.net.URLEncoder;

def Message processData(Message message) {

    // Parsing XML
    def xml = new XmlSlurper().parseText(message.getBody(String));
    
    // Extract vmType and vmName - there is only one because script is running in a split branch
    def vmType = xml.item[0].vmType.text();
    def vmName = xml.item[0].vmName.text();
    
    // Add Properties for Concatened Result after Split
    message.setProperty("vmType",vmType);
    message.setProperty("vmName",vmName);
    
    // Manuelle URL-Encoding Funktion
    String vmNameEnc = URLEncoder.encode(vmName, "UTF-8");
    String vmDummy = URLEncoder.encode("...", "UTF-8");

    // Constants for Target URL 
    def constId = message.getProperty("Value Mapping ID");
    def constVersion = "active";
    def constSrcId = "Name";
    def constTgtId = "Label";
    def constIsConfigured = false;
    
    // Depending on Value Mapping Type different Agency is used
    def srcAgency = vmType == "System" ? "SAPCI_Component" : "SAPCI_Interface";
    def tgtAgency = vmType == "System" ? "LeanIX_Application" : "LeanIX_Interface";

    // Create URL Parameters
    String VM_URL_Parameters = "Id='${constId}'&Version='${constVersion}'&SrcAgency='${srcAgency}'&SrcId='${constSrcId}'&TgtAgency='${tgtAgency}'&TgtId='${constTgtId}'&SrcValue='${vmNameEnc}'&TgtValue='${vmDummy}'&IsConfigured=${constIsConfigured}";

    // Add URL Parameters URL Encoded to property
    message.setProperty("VM_URL_Parameters",VM_URL_Parameters);
    
    // The Body needs to be Empty otherwise the SAP CI Service will not accept the UpsertVM Call
    message.setBody("");
    
    // Set Cookie and X-XSRF-Token which is needed for Updates and was fetched before in the process
    def cookie = message.getProperty("cookie");
    message.setHeader("Cookie", cookie.split(";")[0]);
    
    def token = message.getProperty("xCsrfToken");
    message.setHeader("X-CSRF-Token", token);

    return message;
}