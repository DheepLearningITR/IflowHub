/**
 * Script Name: extractandFilterlFlowInformation
 * Author: Christian Riesener
 * Date: 2024-05-14
 * Description: This script processes a JSON input, extracts specific fields, and converts the data into an XML format so it can through a splitte step. 
 *              It logs the message properties and includes trace-level logging if specified. The script is designed to transform the JSON data into a 
 *              structured XML format suitable for further processing in the integration flow.
 *
 * Modifications:
 *
 * Notes:
 * - The script retrieves the message body as a JSON string and parses it into a Groovy map.
 * - It filters and extracts required fields from the JSON and constructs an XML structure using MarkupBuilder.
 * - The resulting XML is set as the new message body for further processing.
 * - Trace level logging is utilized to capture detailed information for debugging purposes.
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import java.io.StringWriter
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Retrieve the message log object for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    // Retrieve properties from the message and log them with null checks.
    def traceLevel = message.getProperty("TraceLevel");

    // Get the input JSON as a string
    def body = message.getBody(String);

    // Parse the JSON string into a Groovy map
    def jsonSlurper = new JsonSlurper();
    def jsonObject = jsonSlurper.parseText(body);
    
    // Prepare the result list
    def resultList = [];

    // Filtere und extrahiere die erforderlichen Felder
    jsonObject.d.results.each { item ->
        def resultItem = [
            Name: item.Name,
            Description: item.Description,
            Id: item.Id,
            Version: item.Version,
            PackageId: item.PackageId,
            Sender: item.Sender,
            Receiver: item.Receiver
        ]
        resultList << resultItem
    }
    
    // Convert the result list to XML
    def writer = new StringWriter();
    def xml = new MarkupBuilder(writer);
    
    xml.Response {
        Flows {
            resultList.each { resultItem ->
                Flow {
                    Id(resultItem.Id)
                    Name(resultItem.Name)
                    Description(resultItem.Description)
                    Version(resultItem.Version)
                    PackageId(resultItem.PackageId)
                    Sender(resultItem.Sender)
                    Receiver(resultItem.Receiver)
                }
            }
        }
    }
    
    // Set the transformed JSON as the message body
    message.setBody(writer.toString());
    
    return message;
}