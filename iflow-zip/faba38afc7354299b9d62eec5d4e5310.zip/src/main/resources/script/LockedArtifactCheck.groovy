/**
 * Script Name: LockedArtifactCheck
 * Author: Jakov Nasri
 * Date: 2025-05-30
 * Description: This script checks whether a value mapping artifact is locked by any users. It parses the input XML body
 *              and filters the "IntegrationDesigntimeLock" elements based on the artifact ID provided in the message properties.
 *              If the artifact is locked, it retrieves and logs the users who have locked the artifact.
 *              In simulation mode, the script logs the lock details and adds the information to the message log.
 * 
 * Notes:
 * - The script extracts the "ArtifactId" from the incoming XML and checks if the provided "Value Mapping ID" matches.
 * - If the artifact is locked, it retrieves the users who have locked the value mapping and logs the information.
 * - The script uses the `messageLogFactory` to log the details in case of a locked artifact.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

Message processData(Message message) {
    // Retrieve the body of the incoming message and the "Value Mapping ID" from message properties
    def body = message.getBody(String)
    def artifactIdFilter = message.getProperty("Value Mapping ID") ?: ""

    // Parse the incoming XML body
    def xml = new XmlParser().parseText(body)

    // Find all "IntegrationDesigntimeLock" elements whose ArtifactId contains the provided Value Mapping ID
    def filteredLocks = xml.IntegrationDesigntimeLock.findAll { lock ->
        lock.ArtifactId.text().contains(artifactIdFilter)
    }

    // Determine if the artifact is locked based on the filtered locks
    def isLocked = !filteredLocks.isEmpty()
    message.setProperty("ValueMappingLocked", isLocked)

    // If the artifact is locked, retrieve the users who have locked it and log the information
    if (isLocked) {
        def lockedByUsers = filteredLocks.collect { it.CreatedBy?.text() ?: "unknown" }.unique().join(", ")

        // Retrieve the message log (if available) to add log entries and attachments
        def messageLog = messageLogFactory?.getMessageLog(message)
        if (messageLog) {
            // Set a warning message in the message log for locked value mappings
            messageLog.setStringProperty("ValueMappingLockWarning", "Value Mapping '${artifactIdFilter}' is locked by: ${lockedByUsers}")
            
            // Add an attachment to the message log with detailed lock information
            messageLog.addAttachmentAsString("Internal Error Locked Info", "Locked Value Mapping: The Value Mapping is locked by \n${lockedByUsers}", "text/plain")
        }
    }

    // Return the updated message
    return message
}
