/**
 * Script Name: extractAndFilterPackageld
 * Author: Christian Riesener
 * Date: 2024-05-18
 * Description: This script processes a JSON input from SAP Cloud Integration, filters the packages based on a provided regex pattern, 
 *              and converts the data into an XML format so it can run trough a Splitter Step. It logs the total number of packages found 
 *              and the number of packages after filtering as custom header properties. Additionally, it includes trace-level logging if specified.
 *
 *
 * Modifications:
 *
 * Notes:
 * - The script retrieves the message body as a JSON string and parses it into a Groovy map.
 * - It uses a regex pattern from the message properties to filter the packages.
 * - The script constructs an XML structure using MarkupBuilder and sets it as the new message body.
 * - The total number of packages before and after filtering are logged as custom header properties.
 * - Trace level logging is utilized to capture detailed information for debugging purposes.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    
     // Retrieve the message log object for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    def traceLevel = message.getProperty("TraceLevel");
    
    // Get the input JSON as a string
    def body = message.getBody(String);
    
    // Get Regex Filter for Package Name
    def regexPattern = message.getProperty("FilterPackage") ?: ".*";
    
    // Parse the JSON string into a Groovy map
    def jsonSlurper = new JsonSlurper();
    def jsonObject = jsonSlurper.parseText(body);
    
    // Gesamtanzahl der Pakete im ursprünglichen JSON
    def totalPackages = jsonObject.d.results.size();
    // Log the number of Packages found in SAP CI as a custom header property.
    messageLog.addCustomHeaderProperty("__Found Packages on SAP CI: ", totalPackages.toString());
    
    // Prepare the result list
    def resultList = [];
    
    // Extract the required fields
    jsonObject.d.results.each { item ->
        if (item.Id ==~ regexPattern) {
            def resultItem = [
                Id: item.Id,
                Name: item.Name,
                IntegrationDesigntimeArtifactsUri: item.IntegrationDesigntimeArtifacts.__deferred.uri
            ]
            resultList << resultItem
        }
    }
    
    // Create the final JSON structure
    def finalJson = [d: [results: resultList]];
    
    // Convert the final JSON structure to a string
    def jsonOutput = JsonOutput.toJson(finalJson);
    
    // Number of Packages after Filter
    def passedPackages = resultList.size();
    
    // Convert Result to XML to run through Splitter step
    def writer = new StringWriter();
    def xml = new MarkupBuilder(writer);
    
    xml.Response {
        TotalPackages(totalPackages)
        PassedPackages(passedPackages)
        Packages {
            resultList.each { item ->
                Package {
                    Id(item.Id)
                    Name(item.Name)
                    IntegrationDesigntimeArtifacts {
                        Uri(item.IntegrationDesigntimeArtifactsUri)
                    }
                }
            }
        }
    }
    
    // Set the transformed XML as the message body
    message.setBody(writer.toString());
    
    // Log the count of Packages after filtering as a custom header property.
    messageLog.addCustomHeaderProperty("__Packages after Filter: ", passedPackages.toString());
    
    if (traceLevel == "debug") {
        messageLog.addAttachmentAsString("SAP CI Packages after Filter", writer.toString(), "text/plain");
    }
    
    return message;
}