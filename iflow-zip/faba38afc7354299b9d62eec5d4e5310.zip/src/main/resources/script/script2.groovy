import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

Message processData(Message message) {
    def body = message.getBody(String)
    def artifactIdFilter = message.getProperty("Value Mapping ID") ?: ""
    def xml = new XmlParser().parseText(body)

    def filteredLocks = xml.IntegrationDesigntimeLock.findAll { lock ->
        lock.ArtifactId.text().contains(artifactIdFilter)
    }

    def isLocked = !filteredLocks.isEmpty()
    message.setProperty("ValueMappingLocked", isLocked)

    if (isLocked) {
        def lockedByUsers = filteredLocks.collect { it.CreatedBy?.text() ?: "unknown" }.unique().join(", ")
        
        // Holen des messageLogs über MessageLogFactory (nur wenn verfügbar)
        def messageLog = messageLogFactory?.getMessageLog(message)
        if (messageLog) {
            messageLog.setStringProperty("ValueMappingLockWarning", "Value Mapping '${artifactIdFilter}' is locked by: ${lockedByUsers}")
            messageLog.addAttachmentAsString("Internal Error Locked Info", "Locked Value Mapping: The Value Mapping is locked by \n${lockedByUsers}", "text/plain")
        }
    }

    return message
}
