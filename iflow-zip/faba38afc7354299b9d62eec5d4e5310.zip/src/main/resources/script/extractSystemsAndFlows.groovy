/**
 * Script Name: extractSystemsAndFlows
 * Author: Christian Riesener
 * Date: 2024-05-15
 * Description: This script extracts systems and Flows from an SAPCI Flows
 *              in SAP and checks if they already exist in LeanIX ValueMappings. 
 *              If not, they are added for further processing. 
 *              The script also generates an XML representation of the ValueMappings 
 *              to be created and supports a simulation mode for testing purposes.
 *
 * Modifications:
 *
 * Notes:
 * - The script uses the SAP PO/PI API for ValueMappings.
 * - Simulation mode can be activated to preview the changes.
 * - Trace level "debug" enables detailed debug output.
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Retrieve the message log object for logging purposes.
    def messageLog = messageLogFactory.getMessageLog(message);
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    // Map - is needed to avoid duplicates in one run 
    def vmDataSystem = [:];
    def vmDataInterface = [:];
    
    // Retrieve properties from the message and log them with null checks.
    def traceLevel = message.getProperty("TraceLevel");
    def isSimulationModeActive = message.getProperty("isSimulationModeActive").toBoolean();
    
    // Create Debug Output
    def debugOutput = new StringBuilder();
    debugOutput << "--------------------------------------------------------------------------------------------------------------------------------------\n";
    debugOutput << message.getProperty("VM_Log") + "\n";
    def simulationOutput = new StringBuilder();

    // Create simulationOutput Header
    if (isSimulationModeActive) {
        simulationOutput << "======================================================================================================================================\n";
        simulationOutput << "                                                           Simulation Output\n";
        simulationOutput << "======================================================================================================================================\n";
        simulationOutput << "This output serves to determine how and which ValueMappings would be created in SAP CI that can be used to define an understandable \n";
        simulationOutput << "labels for applications or interfaces in LeanIX. The flow is checking against existing ValueMappings but also against ValueMappings\n";
        simulationOutput << "that would be created in current flow run\n";
    } else // User needs some Output what was created so we will create this output Anyways but at the end Name it Flow Log if it was not a Simulation
    {
        simulationOutput << "======================================================================================================================================\n";
        simulationOutput << "                                                           Flow Log\n";
        simulationOutput << "======================================================================================================================================\n";
        simulationOutput << "This output shows which ValueMappings doesn't exist and will be created during this Flow run. The flow is checking against existing \n";
        simulationOutput << "ValueMappings but also against ValueMappings that would be created in current flow run\n";
    }       
    
    // Read XML and check Interfaces and System if they are already available in the SAP CI ValueMapping - if not add them to the outgoing VM XML
    def xmlFlow = new XmlSlurper().parseText(message.getBody(String));

    xmlFlow.Flows.Flow.each{ flow ->

        debugOutput << "--------------------------------------------------------------------------------------------------------------------------------------\n";

        debugOutput << "Check Flow:\n";
        
        // Read Sender interface
        def flowName = flow.Name.text();

        def labelFlow = valueMapApi.getMappedValue("SAPCI_Interface", "Name", flowName , "LeanIX_Interface", "Label");
        if (labelFlow != null || vmDataInterface.get(flowName) != null) {
            if (labelFlow == null) labelFlow = "will aready be created in this flow run";
            debugOutput << "Value Mapping Entry found for ${flowName}: ${labelFlow}\n";
        } else {
            vmDataInterface.put(flowName,"");
            debugOutput << "No Value Mapping Entry found for ${flowName}\n";
        }

        def senders = flow.Sender.text();
        def receivers = flow.Receiver.text();
        
        if (senders != "" || receivers != "") {
            debugOutput << "Check Systems:\n";    
        }
        
        // Read Sender
        senders.split(",").each{ sender -> 
            if (sender != "") {
                 // Check if ValueMapping already exists
                def labelSender = valueMapApi.getMappedValue("SAPCI_Component", "Name", sender , "LeanIX_Application", "Label");
                if (labelSender != null || vmDataSystem.get(sender) != null) {
                    if (labelSender == null) labelSender = "will aready be created in this flow run";
                    debugOutput << "Value Mapping Entry found for ${sender}: ${labelSender}\n";
                } else {
                    vmDataSystem.put(sender,"");
                    debugOutput << "No Value Mapping Entry found for ${sender}\n";
                }       
            }
        }
        
        // Read Receiver
        receivers.split(",").each{ receiver -> 
            if (receiver != "") {        
                // Check if ValueMapping already exists        
                def labelReceiver = valueMapApi.getMappedValue("SAPCI_Component", "Name", receiver , "LeanIX_Application", "Label");
                if (labelReceiver  != null || vmDataSystem.get(receiver) != null) {
                    if (labelReceiver == null) labelReceiver = "will aready be created in this flow run";
                    debugOutput << "Value Mapping Entry found for ${receiver}: ${labelReceiver}\n";
                } else {
                    vmDataSystem.put("${receiver}".toString() ,"");
                    debugOutput << "No Value Mapping Entry found for ${receiver}\n";
                }
            }
        }
    }    

    // Write XML for run through Splitter Step
    def writer = new StringWriter();
    def xml = new MarkupBuilder(writer);

    xml.vmCreation {
        // Add sender and receiver data
        vmDataSystem.each { system ->
            item {
                vmType("System");
                vmName(system.key);
            }
        }
        // Interface Data
        vmDataInterface.each { oInterface ->
            item {
                vmType("Interface");
                vmName(oInterface.key);
            }
        }
    }

    // Set XML as message body
    message.setBody(writer.toString());

    // Debugging logic: if trace level is debug, log all properties in a structured format.
    if (traceLevel == "debug") {
        messageLog.addAttachmentAsString("Value Mapping XML", writer.toString(), "text/plain");
        messageLog.addCustomHeaderProperty("__X_CSRF_Token", message.getProperty("xCsrfToken").take(10) + "...");
    }
    
    // Add Simulation Summary
    simulationOutput << debugOutput;
    simulationOutput << "======================================================================================================================================\n";
    simulationOutput << "                                                           Summary\n";
    simulationOutput << "======================================================================================================================================\n";
    simulationOutput << "Number of Systems be added to Value Mapping.  : ${vmDataSystem.size()} \n";
    simulationOutput << "Number of Interfaced be added to Value Mapping: ${vmDataInterface.size()} \n";
    if (isSimulationModeActive) {
        messageLog.addAttachmentAsString("Simulation Output", simulationOutput.toString(), "text/plain");
    } else {
        messageLog.addAttachmentAsString("Flow Log", simulationOutput.toString(), "text/plain");
    }
    
    // Add runtime Value to Message properties
    messageLog.addCustomHeaderProperty("__Systems missing in Value Mapping", vmDataSystem.size().toString());
    messageLog.addCustomHeaderProperty("__Interfaces missing in Value Mapping", vmDataInterface.size().toString());

    return message;
}