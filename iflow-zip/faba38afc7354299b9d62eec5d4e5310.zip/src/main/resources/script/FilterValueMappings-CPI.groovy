/**
 * Script Name: FilterValueMapping-CPI
 * Author: Jakov Nasri
 * Date: 2024-11-06
 * Description: This script filters for the ValueMapping ID to ensure, that the needed Value Mapping
 * for the synchranization between the SAP Cloud Integration and LeanIX FactSheets.
 *
 * Modifications:
 * - 
 * Notes: 
 * - 
 */
 
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlParser;

def Message processData(Message message) {
    // Get the XML payload as a string from the message body
    def body = message.getBody(String);

    // Parse the XML using XmlParser (instead of XmlSlurper)
    def xmlParser = new XmlParser();
    def root = xmlParser.parseText(body);

    // The ID of the value mapping artifact we want to filter (updated as per your mapping)
    def targetValueMappingId = message.getProperty("Value Mapping ID");

    // Find the desired value mapping artifact
    def foundMapping = root.ValueMappingDesigntimeArtifact.find { artifact ->
        artifact.Id.text() == targetValueMappingId
    }

    // Define a boolean variable to track if the value mapping is found
    def mappingFound = false;

    // Log the found result and set boolean
    def messageLog = messageLogFactory.getMessageLog(message);
    if (foundMapping != null) {
        mappingFound = true;  // Set boolean to true if found
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Filtered Value Mapping", groovy.xml.XmlUtil.serialize(foundMapping), "text/xml");
        }
        // Return the filtered value mapping in the message body
        message.setBody(groovy.xml.XmlUtil.serialize(foundMapping));
    } else {
        // Set custom message when no matching value mapping is found
        def noMappingMessage = "No matching Value Mapping could be found";
        
        if (messageLog != null) {
            messageLog.addAttachmentAsString("No Value Mapping Found", noMappingMessage, "text/plain");
        }

        // Set the custom message in the body
        message.setBody(noMappingMessage);
    }

    // Add the boolean result as a property in the message
    message.setProperty("mappingFound", mappingFound);

    return message;
}
