/**
 * Script Name: buildUrlForVMDeploy
 * Author: Christian Riesener
 * Date: 2024-05-14
 * Description: This script sets constants for the target URL, adds URL parameters to the message properties, and sets necessary headers and an empty 
 *              body for further processing in the SAP CI service for Deploying the ValueMapping.
 *
 * Modifications:
 *2024-11-06 by Jakov Kurakin
 * line 28 - Constat Id is now get from the Property("Value Mapping ID"), which can be configured individually
 * line 23 - Delay of 15 seconds added for VM Deploy
 * 
 * Notes:
 * - Constants such as 'constId' and 'constVersion' are used for constructing the URL.
 * - The message body is set to an empty string to comply with the requirements of the SAP CI Service for the Deploy call.
 * - 'Cookie' and 'X-CSRF-Token' headers are set in the message, which are necessary for update operations. These values should be retrieved earlier in the process.
 * - Ensure that 'cookie' and 'xCsrfToken' properties are set in the message before this script is executed.
 */

import com.sap.gateway.ip.core.customdev.util.Message;
import java.net.URLEncoder;

Thread.sleep(15000)

def Message processData(Message message) {

    // Constants for Target URL 
    def constId = message.getProperty("Value Mapping ID");
    def constVersion = "active";

    // Add URL Parameters 
    message.setProperty("constId",constId);
    message.setProperty("constVersion",constVersion);
    
    // The Body needs to be Empty otherwise the SAP CI Service will not accept the UpsertVM Call
    message.setBody("");
    
    // Set Cookie and X-XSRF-Token which is needed for Updates and was fetched before in the process
    def cookie = message.getProperty("cookie");
    message.setHeader("Cookie", cookie.split(";")[0]);
    
    def token = message.getProperty("xCsrfToken");
    message.setHeader("X-CSRF-Token", token);

    return message;
}