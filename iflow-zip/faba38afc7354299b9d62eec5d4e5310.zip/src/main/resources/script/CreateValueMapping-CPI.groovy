/**
 * Script Name: CreatePackage-CPI
 * Author: Jakov Nasri
 * Date: 2024-11-06
 * Description: This script creates the JSON structure to create the Value Mapping of the
 *              SAP Cloud Integration to LeanIX FactSheets synchranization. The Value Mapping Name and Value Mapping ID 
 *              can be configured idividually.
 *
 * Modifications:
 * - 
 * Notes: 
 * - 
 */
 
 import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);

    // Predefine the necessary values directly
    def valueMappingId = message.getProperty("Value Mapping ID");  // Predefined ValueMappingId
    def valueMappingName = message.getProperty("Value Mapping Name");  // Predefined ValueMappingName
    def packageId = message.getProperty("Value Mapping - Package ID");  // Predefined PackageId
    def description = "This Value Mapping contains some tables to exchange technical information with business labels to provide SAP LeanIX Factsheet with an more understandable Result.";  // Predefined Description

    // Validate that the name follows SAP's rules for ValueMappingName
    if (!valueMappingName.matches("[a-zA-Z_][a-zA-Z0-9 _.\\-]*[^.]")) {
        throw new IllegalArgumentException("Invalid ValueMappingName format. It must start with a letter or underscore and should not end with a period.");
    }

    // Base64-encoded ZIP content (replace with the content from your zip file)
    def artifactContentBase64 = "UEsDBBQACAgIAFZFZlkAAAAAAAAAAAAAAAARAAAAdmFsdWVfbWFwcGluZy54bWytj8GqwjAQRX9F+gEmbdpqYQyIq4I8HrhxJ5NkUgNNWmot+PevPLtQpOLC5Z07HO6BwS8G6i6uCZsoWfJIQtU113bhzCbKcuSrVBttKY5zI3IUguwqURnPLFd2fKbQdzcJWFHQN3nY/u7K067xbRPGBth0h4s+k0f5g56ATQEGrK8ky+B6hzWwewQ2IZ/Je8JQHk/btq2dxn6c+wLfo6L6Uzr7t3yUVTHnaZFwTUalArWJ1woLKqxIlch5MSNbhp46i5q+LzuPfqe6nHVlg5d/UEsHCKNKMXbQAAAA8AEAAFBLAwQUAAgICABWRWZZAAAAAAAAAAAAAAAACAAAAC5wcm9qZWN0lZFLa8MwEITv/RXC98rtrQfHoSQUAikU0pbexEbeGAU9Fj1Mf35lWzF9HnrTjGb0Latm/W40G9AH5eyquuU3FUMrXadsv6penh+u76p125B3Z5Rxi0F6RTFn2yvGWGPBYPsKOqF4BKJcEnsEu3sTeziiFifnxeH+SWx2TT1lp5Z0xqCN9azK26HIY1K6OxDKSS7OJnfAdhdzgTvfc5RaUUB+7iKXzucDDDC10H/ilhr4Po34Ahyt+geiWMscGRaTx7BUZv03fr4f6VPuWy1vgAcgrjrk6qR52QEPicj5uOj/vTKANkBf0heRB2/qX37xA1BLBwgLXcND8QAAAAACAABQSwMEFAAICAgAVkVmWQAAAAAAAAAAAAAAABQAAABNRVRBLUlORi9NQU5JRkVTVC5NRoWOzYqDMBRG94LvkBcwzMyyO6dQCKgIDmV24TbeSmj+iFHq2zejTnDX7Xf4DqcGI+84huKKfpTWnMgn/ciz78n0Cot6pwl+JdSAxhO5gpqQ1OCcNAPpypZUCIb9kgpuqMjd+nU8Kzv1hJmAg4cQTUnTLfpmlRQHHd91fFPxVcWjikcVP7P0PSb/RUdcbOhncf+2XbbRxvY7Y5eqLts8Y9pZH4oWxAOGuAur6QiOPiXV25OKmKboDCoO6dChn6WIh1RTiiBnCNa/ldBjWLrlWZ69AFBLBwhzHJVg0gAAAI4BAABQSwMEFAAICAgAVkVmWQAAAAAAAAAAAAAAAA0AAABtZXRhaW5mby5wcm9wJY9NSwNBEETv+ysKcpdlWSQEPIggCCrBxI9r72wn0zDbM0z3Rn++Gb0WvHpVm4PnyljYSfSUUWouXF3Yus0nz3jNF/S36Le7cdiNI96PDxj6YexmtlCluGS9O0YxfFBaGS9UiugZIWtrNFheGE5TYoNn8E+IpOdrxCGqBEpo3rpQa8K3eMS0miibIdHE6Q+7zrrIzDjc7/HMpE9feKTgFpn9HyLF0p6sOnM1J52bE29sa/Kb7hdQSwcIjJuTqLYAAADoAAAAUEsBAhQAFAAICAgAVkVmWaNKMXbQAAAA8AEAABEAAAAAAAAAAAAAAAAAAAAAAHZhbHVlX21hcHBpbmcueG1sUEsBAhQAFAAICAgAVkVmWQtdw0PxAAAAAAIAAAgAAAAAAAAAAAAAAAAADwEAAC5wcm9qZWN0UEsBAhQAFAAICAgAVkVmWXMclWDSAAAAjgEAABQAAAAAAAAAAAAAAAAANgIAAE1FVEEtSU5GL01BTklGRVNULk1GUEsBAhQAFAAICAgAVkVmWYybk6i2AAAA6AAAAA0AAAAAAAAAAAAAAAAASgMAAG1ldGFpbmZvLnByb3BQSwUGAAAAAAQABADyAAAAOwQAAAAA";

    // Create a JSON structure using a map to avoid variable conflicts
    def jsonContent = [
        Name           : valueMappingName,
        Id             : valueMappingId,
        PackageId      : packageId,
        Description    : description,
        ArtifactContent: artifactContentBase64  // Base64-encoded content
    ]
    
    def cookie = message.getProperty("cookie");
    message.setHeader("Cookie", cookie.split(";")[0]);
    
    def token = message.getProperty("xCsrfToken");
    message.setHeader("X-CSRF-Token", token);

    // Convert the map to a JSON structure
    def jsonBuilder = new JsonBuilder(jsonContent);

    // Convert JSON structure to string and set it as the message body
    def jsonPayload = jsonBuilder.toPrettyString();
    message.setBody(jsonPayload);

    message.setHeader("content-type", "application/json");

    // Log the generated payload for debugging
    if (messageLog != null) {
        messageLog.addAttachmentAsString("Generated Value Mapping Payload", jsonPayload, "application/json");
    }

    return message;
}
