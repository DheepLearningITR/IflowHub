import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import groovy.json.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

def Message prepareReceiverPayload(Message message) {

  def body = message.getBody(java.io.Reader)
  def soapResponse = new XmlSlurper().parse(body)

  def responsePayload = convertToJSON(soapResponse, message)
  message.setBody(responsePayload)

  return message

}

def convertToJSON(xml, message) {

  def properties = message.getProperties()
  def senderBusinessSystem = properties.get("SenderBusinessSystem")
  def receiverBusinessSystem = properties.get("ReceiverBusinessSystem")
  def messageEntityName = properties.get("MessageEntityName")
  def initialLoad = properties.get("InitialLoad")

  def jsonBuilder = new JsonBuilder()

  def codeList = []
  xml.ET_CODE_LIST.item.each {
    item ->
      def code = item.CODE.text().substring(0,6)
      def isRelevantForPersons = convertToBoolean(item.CODE.text().toString().substring(6,7))
      def isRelevantForOrganizations = convertToBoolean(item.CODE.text().toString().substring(7))
    def descriptions = item.TEXTS.item.collect {
      [
        languageCode: it.LANGUAGE.text(),
        content: it.TEXT.text()
      ]
    }

    def resultMessage = [
      messageHeader: ["messageEntityName": messageEntityName, "actionCode": "SAVE", "id": generateRandomGUID()],
      body: [code: code, 
      isRelevantForPersons: isRelevantForPersons,
      isRelevantForOrganizations: isRelevantForOrganizations,
      descriptions: descriptions]
    ]

    codeList.add(resultMessage)
  }
  if ('true'.equals(initialLoad)) {
    def receiverCodes = message.getHeader("ReceiverCodes", java.io.Reader)
    def receiverCodeList = new groovy.json.JsonSlurper().parse(receiverCodes)
    def erpCodes = xml.ET_CODE_LIST.item.collect {
      it.CODE.text().substring(0,6)
    }
    def cnsCodes = receiverCodeList.value.collect {
      it.code
    }

    // BUP001 (Dun&Bradsteet) must not be deleted
    erpCodes.add("BUP001")
    
    def codesToDelete = cnsCodes.findAll {
      !erpCodes.contains(it)
    }
    codesToDelete.each {
      code ->
        def deleteMessage = [
          messageHeader: ["messageEntityName": messageEntityName, "actionCode": "DELETE", "id": generateRandomGUID()],
          body: [code: code]
        ]

      codeList.add(deleteMessage)
    }
  }

  def creationDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))
  jsonBuilder {
    messageHeader("id": generateRandomGUID(), receiverCommunicationSystemDisplayId: receiverBusinessSystem, senderCommunicationSystemDisplayId: senderBusinessSystem, "creationDateTime": "$creationDateTime")
    messageRequests(codeList)
  }

  return JsonOutput.toJson(jsonBuilder.content)
}

def generateRandomGUID() {
  return UUID.randomUUID().toString()
}

def Boolean convertToBoolean(String value){
  return value == 'X'
}			