import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;
import groovy.xml.XmlUtil;
import groovy.xml.StreamingMarkupBuilder;

//Below are the mehtods that will create the logs

//log inbound payload data
def Message logInboundData(Message message) {
    def enableLogging = message.getProperties().get("log");
    def body = message.getBody(java.lang.String) as String;
    if(enableLogging && enableLogging.equalsIgnoreCase("true")){
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("InboundData:", body, "text/xml");
     }}
    return message;
}


//log after removing namespace
def Message logRemoveNamespaceData(Message message) {
    def enableLogging = message.getProperties().get("log");
    if(enableLogging && enableLogging.equalsIgnoreCase("true")){
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("Remove Namespace:", body, "text/xml");
     }}
    return message;
} 

//log after removing namespace
def Message logAfterCleanupData(Message message) {
    def enableLogging = message.getProperties().get("log");
    if(enableLogging && enableLogging.equalsIgnoreCase("true")){
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("After Cleanup Mapping:", body, "text/xml");
     }}
    return message;
} 


//log mapping data for pre Survey Set mapping
def Message logMappingBeforeSSData(Message message) {
    def enableLogging = message.getProperties().get("log");
    if(enableLogging && enableLogging.equalsIgnoreCase("true")){
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("Before Survey Set Map:", body, "text/xml");
     }}
    return message;
}    

//log mapping data for post Survey Set mapping
def Message logMappingAfterSSData(Message message) {
    def enableLogging = message.getProperties().get("log");
    if(enableLogging && enableLogging.equalsIgnoreCase("true")){
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("After Survey Set Map:", body, "text/xml");
     }}
    return message;
}

//log mapping data for pre Survey Answer mapping
def Message logMappingBeforeSAData(Message message) {
    def enableLogging = message.getProperties().get("log");
    if(enableLogging && enableLogging.equalsIgnoreCase("true")){
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("Before Survey Answer Map:", body, "text/xml");
     }}
    return message;
}    

//log mapping data for post Survey Answer mapping
def Message logMappingAfterSAData(Message message) {
    def enableLogging = message.getProperties().get("log");
    if(enableLogging && enableLogging.equalsIgnoreCase("true")){
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("After Survey Answer Map:", body, "text/xml");
     }}
    return message;
}

//log response from marketing cloud for SurveySet
def Message logResponseSAData(Message message) {
    def enableLogging = message.getProperties().get("log");
    if(enableLogging && enableLogging.equalsIgnoreCase("true")){
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("Marketing Cloud Response(Survey Answer):", body, "text/xml");
     }}
    return message;
}

//log response from marketing cloud for SurveyAnswer
def Message logResponseSSData(Message message) {
    def enableLogging = message.getProperties().get("log");
    if(enableLogging && enableLogging.equalsIgnoreCase("true")){
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("Marketing Cloud Response(Survey Set):", body, "text/xml");
     }}
    return message;
}


// Below are the method that will create the Hashmaps

// Consume Survey Response Collection data
def Message consumeSurveyResponseCollectionData(Message message) {
    def enableLogging = message.getProperties().get("log");
    def body = message.getBody(java.lang.String) as String;
    def root = new XmlParser().parseText(body);
    def quesCollection = new String(root.SurveyResponse.RepresentationBinaryObject.text().decodeBase64(),"UTF-8");
    
    HashMap<String,String> q2r = new HashMap<String,String>(); 
    
//save values for future use 
    message.setProperty("businessUUID", root.SurveyResponse.BusinessTransactionDocumentUUID.text());
    message.setProperty("surveyId", root.SurveyResponse.ID.text());
    message.setProperty("EntityLastChangedOn", root.SurveyResponse.EntityLastChangedOn.text());
    message.setProperty("questionaire",quesCollection);

    root = new XmlParser().parseText(quesCollection);
    def ques2 = root.sections.section.question[1];

//read data and create hashmap    

    ques2.rating.each{ it->
        q2r.put(it.nodeId.text(), it.ordinalNumberValue.text()); 
    }

//save to hashmap    
    message.setProperty("q2r", q2r);
    
    if(enableLogging && enableLogging.equalsIgnoreCase("true")){
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("Survey Response Collection Data:", body, "text/xml");
        messageLog.addAttachmentAsString("Survey Answer Collection Data:", quesCollection, "text/xml");
        messageLog.addAttachmentAsString("Question 2 Rating Hashmap:", q2r.toString(), "text/text");
     }}
    return message;
}

//Consume Survey Root Collection Data
def Message consumeSurveyRootCollectionData(Message message) {
    def enableLogging = message.getProperties().get("log");
    def body = message.getBody(java.lang.String) as String;
    def root = new XmlParser().parseText(body);
    message.setProperty("Version",root.SurveyRoot.Version.text());
    message.setProperty("ValidToDate",root.SurveyRoot.ValidToDate.text());
    message.setProperty("SurveyCreationDateTime",root.SurveyRoot.SurveyCreationDateTime.text());
    message.setProperty("CategoryCode",root.SurveyRoot.CategoryCodeText.text());
    message.setProperty("ValidFromDate",root.SurveyRoot.ValidFromDate.text());
    if(enableLogging && enableLogging.equalsIgnoreCase("true")){
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("Survey Root Collection Data:", body, "text/xml");
     }}
    return message;
    
}

//Consume Service Request Collection Data
def Message consumeServiceRequestCollectionData(Message message) {
    def enableLogging = message.getProperties().get("log");
    def body = message.getBody(java.lang.String) as String;
    def root = new XmlParser().parseText(body);
    message.setProperty("buyerID",root.ServiceRequest.BuyerPartyID.text());
    message.setProperty("ticketId",root.ServiceRequest.ID.text());
    if(enableLogging && enableLogging.equalsIgnoreCase("true")){
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("Service Request Collection Data:", body, "text/xml");
     }}
    message.setBody('');
    return message;
    
}



/*
def Message collateRouteID(Message message) {
    def body = message.getBody(java.lang.String);
    def root = new XmlParser().parseText(body);
    def routeid = message.getProperties().get("RouteIds");
//initialize hashmap
    HashMap<String,String> route = new HashMap<String,String>(); 
//check if data is there
    if(routeid != null || routeid !='')
    {   
        route = routeid;
    }
    
    //loop for all CC.
    for (def p: root.YY1_FLIGHTSCHEDULEDATAType) {
        //add employee details to the hash map.
    	route.put(p.RouteScheduleID.text(), p.SAP_UUID.text());
    }
    //set hashmap as property
    message.setProperty("RouteIds", route);
    return message;
}
*/
    
