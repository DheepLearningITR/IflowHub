import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

//This method will read a property in the message mapping
def String getProperty(String property_name, MappingContext context) {
    def propValue= context.getProperty(property_name);
    return propValue;
}

//This method will read a header in the message mapping 
def String getheader(String header_name, MappingContext context) {
    def headervalue= context.getHeader(header_name);
    return headervalue;
}

//This method will read dynamically read value mappings
//Purpose is to dynamically set a default value
def String dynamicValueMap(String sAgency, String sSchema, String tAgency, String tSchema, String key){
    def service = ITApiFactory.getApi(ValueMappingApi.class, null);
        if( service != null) {
            String val= service.getMappedValue(sAgency, sSchema, key, tAgency, tSchema);
                if ( val.equals("") || val ==null )
                {
                    return "default";
                }
                else
                    return val;
                }
    return null;
}

//Generate the uuid
def String generateUUID(String input){
	return UUID.randomUUID().toString();
}

//Time Format for update
def String timeFormatupdate(String input){
    def output = 'PT' + input.substring(0,2)  + 'H' + input.substring(2,4) + 'M00S';
	return output;
}

//Time Format for insert
def String timeFormatinsert(String input){
    if(input != '' || input != null){
            def output = input.substring(0,2)  + ':' + input.substring(2,4) + ':00';
            	return output;
    }
    else{
        return '';
    }
}

//Convert to mins
def String convertToMinutes(String input){
    
    def output = (input.substring(0,2).toInteger() * 60) + input.substring(2,4).toInteger();
	return output;
}

def String getHashMapValue(String hashId ,String nodeId, MappingContext context){
    def map = context.getProperty(hashId);
    if(hashId != null && map != null && nodeId != null){
    def output = map.get(nodeId);
    if(output!= null)
        return output;
    else
        return "";
    
    }
    else{
    return "";}
}




