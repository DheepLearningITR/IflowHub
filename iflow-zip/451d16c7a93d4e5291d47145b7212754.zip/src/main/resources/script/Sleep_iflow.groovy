import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    // Convert the message body to a string
    def payload = message.getBody(String.class)
    //Search string and change <CustomTagGeneral xmlns=""> to <CustomTagGeneral>
    def modifiedPayload = payload.replaceAll('<CustomTagGeneral xmlns="">', '<CustomTagGeneral>')
    // Set the modified payload as the new message body
    message.setBody(modifiedPayload)
    // Return the modified message
    return message
}
