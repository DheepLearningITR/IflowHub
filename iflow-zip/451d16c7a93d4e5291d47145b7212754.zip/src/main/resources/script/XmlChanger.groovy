import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*

def Message processData(Message message) {

    map = message.getProperties();

	InitialXML = map.get('InitialXML');
    
    def root = new XmlParser().parseText(InitialXML);
    def TypeCodeNode = root.'**'.find{it.name().localPart == 'InvoiceTypeCode'};
    
    if (TypeCodeNode) {
        TypeCodeNode.value = '04';    
    }
    
    def xmlAsText = XmlUtil.serialize(root);

    message.setBody(xmlAsText);

	return message;
}