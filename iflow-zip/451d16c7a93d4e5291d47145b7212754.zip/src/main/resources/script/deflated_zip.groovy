/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;



import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.util.zip.*;

/**
 * Compresses a file or directory into a Zip archive. Users of the class supply
 * the name of the file or directory as an argument.
 */

/*
	public static void main(String[] args) {
		// User must specify a directory to compress


		// Get the name of the file or directory to compress.

		String fileName = "C:/face_fdvNORT980000449.xml";
		String nombreFichero = "face_fdvNORT980000449";
		// Use the makeZip method to create a Zip archive.

		try {
			zipiar(fileName, nombreFichero);
		}
		// Simply print out any errors we encounter.

		catch (Exception e) {
			System.err.println(e);
		}
	}
*/

def Message processData(Message message) {
	
	def nombreFichero = message.getProperties().get('FILE_NAME');
	byte[] fileContent = message.getBody(byte[].class);

	def ByteArrayOutputStream baos = new ByteArrayOutputStream();
	ZipOutputStream os = null;
//	def  Message zipiar(String fileName, String nombreFichero) throws IOException {

	try {
		os = new ZipOutputStream(baos);

		os.setLevel(Deflater.DEFAULT_COMPRESSION);
		os.setMethod(Deflater.DEFLATED);
		//File infile = new File(fileName);

//		FileInputStream fis = new FileInputStream(infile);
		
//		Read fileContent from input parameter later 						//NEW
		//byte[] fileContent = Files.readAllBytes(infile.toPath());			//NEW
		ByteArrayInputStream bis = new ByteArrayInputStream(fileContent);	//NEW
	
		ZipEntry entrada = new ZipEntry(nombreFichero + ".xml");
		entrada.setMethod(ZipEntry.STORED);
//		precalc(entrada, fis.getChannel());
		precalc(entrada, fileContent);										//NEW
		os.putNextEntry(entrada);

		byte[] buffer = new byte[1024].encodeBase64();
		int leido = 0;
		while (0 < (leido = bis.read(buffer.decodeBase64()))) {
			os.write(buffer.decodeBase64(), 0, leido);
		}
		bis.close();
		os.closeEntry();
	} catch (Exception ex) {
		log.error("processData error", ex);
	} finally {
		if (os != null) {
			os.close();
		}
	}
	//ZipInputStream zis = new ZipInputStream(
	// BufferedInputStream(new FileInputStream(new File(nombreFichero + ".zip"))));

	//ZipEntry entry = zis.getNextEntry();
	//System.out.println("Entry size: " + entry.getSize());
	//zis.closeEntry();
	
	message.setBody(	baos.toByteArray());
	
	return message;
}

//	private static void precalc(ZipEntry entry, FileChannel fch) throws IOException {
//		long uncompressed = fch.size();
//		int method = entry.getMethod();
//		CRC32 crc = new CRC32();
//		Deflater def;
//		byte[] drain;
//		if (method != ZipEntry.STORED) {
//			def = new Deflater(Deflater.DEFAULT_COMPRESSION, true);
//			drain = new byte[1024];
//		} else {
//			def = null;
//			drain = null;
//		}
//		ByteBuffer buf = ByteBuffer.allocate((int) Math.min(uncompressed, 4096));
//		for (int bytesRead; (bytesRead = fch.read(buf)) != -1; buf.clear()) {
//			crc.update(buf.array(), buf.arrayOffset(), bytesRead);
//			if (def != null) {
//				def.setInput(buf.array(), buf.arrayOffset(), bytesRead);
//				while (!def.needsInput())
//					def.deflate(drain, 0, drain.length);
//			}
//		}
//		entry.setSize(uncompressed);
//		if (def != null) {
//			def.finish();
//			while (!def.finished())
//				def.deflate(drain, 0, drain.length);
//			entry.setCompressedSize(def.getBytesWritten());
//		}
//		entry.setCrc(crc.getValue());
//		fch.position(0);
//	}
	
	private static void precalc(ZipEntry entry, byte[] fileContent) throws IOException {
//		long uncompressed = fch.size();
		long uncompressed = fileContent.length; 									//NEW
		int method = entry.getMethod();
		CRC32 crc = new CRC32();
		Deflater deflater;
		byte[] drain;
		if (method != ZipEntry.STORED) {
			deflater = new Deflater(Deflater.DEFAULT_COMPRESSION, true);
			drain = new byte[1024];
		} else {
			deflater = null;
			drain = null;
		}
//		ByteBuffer buf = ByteBuffer.allocate((int) Math.min(uncompressed, 4096));
		ByteBuffer buf = ByteBuffer.wrap(fileContent);								//NEW
		int offset = 0;																//NEW
		while (offset < fileContent.length) {										//NEW
			int bytesRead = (int) Math.min(fileContent.length - offset, 4096);		//NEW
			byte[] bytes = new byte[bytesRead];										//NEW
			buf.get(bytes);															//NEW
			
//			for (int bytesRead; (bytesRead = fch.read(buf)) != -1; buf.clear()) {
//				crc.update(buf.array(), buf.arrayOffset(), bytesRead);
				crc.update(bytes, 0, bytesRead); 									//NEW
				if (deflater != null) {
//					deflater.setInput(buf.array(), buf.arrayOffset(), bytesRead);
					deflater.setInput(bytes, 0, bytesRead); 								//NEW
					while (!deflater.needsInput())
						deflater.deflate(drain, 0, drain.length);
				}
//			}
				
			offset += bytesRead;	 												//NEW
		} 																			//NEW
		
		entry.setSize(uncompressed);
		if (deflater != null) {
			deflater.finish();
			while (!deflater.finished())
				deflater.deflate(drain, 0, drain.length);
			entry.setCompressedSize(deflater.getBytesWritten());
		}
		entry.setCrc(crc.getValue());
//		fch.position(0);
	}


