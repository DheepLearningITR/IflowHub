import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def props = message.getProperties();
    
    def paycompvalue = props.get("paycompvalue");
    def annualizationFactor = props.get("annualizationFactor");
    def annualSalary = 0;

    if (paycompvalue > '' && annualizationFactor > '') {
        float convertedpaycompvalue  = Float.parseFloat(paycompvalue);
        float convertedannualizationFactor   = Float.parseFloat(annualizationFactor );
    
        annualSalary = convertedpaycompvalue  * convertedannualizationFactor;
    }
    message.setProperty("annualSalary", annualSalary.toString());
    return message;
}