import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def map = message.getProperties();
    
	def applicationId = map.get("ApplicationId");
	if (applicationId == null || applicationId == "" || !(applicationId ==~ ~/\d+/)) {
        return invalidInput(message, "Invalid Input. Value of parameter 'ApplicationId' cannot be blank and must contain only numbers.");
    }
    
	def statusName = map.get("HireStatusName");
	if (statusName == null || statusName == "") {
        return invalidInput(message, "Invalid Input. Value of parameter 'Name of Status for Hire' cannot be blank.");
    }
    
    message.setProperty("ValidInput", "yes");
	
	message.setProperty("ListOfFields",
		addToList(map, "HireDateFieldName") +
		addToList(map, "WorkLocationFieldName") +
		addToList(map, "JobOfferDateFieldName") +
		addToList(map, "SocialSecurityNumberFieldName") +
		addToList(map, "StartDateFieldName") +
		addToList(map, "JobTitleFieldName") +
		addToList(map, "BaseSalaryFieldName")
	);

    return message;
}

def Message invalidInput(Message message, String errorMessage) {
    message.setProperty("ValidInput", "no");
    message.setProperty("ErrorCode", "INVALID_INPUT");
    message.setProperty("ErrorMessage", errorMessage);
    return message;
}

def String addToList(Map<String, Object> map, String propertyName) {
    def propertyValue = map.get(propertyName);
    if (propertyValue != null && propertyValue != "") {
        return "," + propertyValue;
    }
    return "";
}