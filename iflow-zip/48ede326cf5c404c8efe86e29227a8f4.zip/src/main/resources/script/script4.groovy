import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def map = message.getProperties();
    
	def userId = map.get("UserId");
	if (userId == null || userId == "" || !(userId ==~ ~/\d+/)) {
        return invalidInput(message, "Invalid Input. Value of parameter 'UserId' cannot be blank and must contain only numbers.");
    }
    
	def effectiveStartDate = map.get("EffectiveStartDate");
	if (effectiveStartDate == null || effectiveStartDate == "" || !(effectiveStartDate ==~ ~/\d{2,4}-\d{1,2}-\d{1,2}(T\d{1,2}:\d{1,2}:\d{1,2}(.\d{1,3})?(Z)?)?/)) {
        return invalidInput(message, "Invalid Input. Value of parameter 'EffectiveStartDate' cannot be blank and must be in the format YYYY-MM-DD");
    }
	
    message.setProperty("ValidInput", "yes");
    return message;
}

def Message invalidInput(Message message, String errorMessage) {
    message.setProperty("ValidInput", "no");
    message.setProperty("ErrorCode", "INVALID_INPUT");
    message.setProperty("ErrorMessage", errorMessage);
    return message;
}