import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def map = message.getProperties();
    
    def address = map.get("SuccessFactorsAddress");
    if (address == null || address == "") {
        return invalidConfig(message, "Invalid configuration. Value of parameter 'Success Factors Address' cannot be blank.");
    }
    
    def credential = map.get("SuccessFactorsCredentialName");
    if (credential == null || credential == "") {
        return invalidConfig(message, "Invalid configuration. Value of parameter 'Success Factors Credential Name' cannot be blank.");
    }
    
    message.setProperty("ValidConfig", "yes");
	
	message.setProperty("ListOfFields",
		addToList(map, "HireDateFieldName") +
		addToList(map, "WorkLocationFieldName") +
		addToList(map, "JobOfferDateFieldName") +
		addToList(map, "SocialSecurityNumberFieldName") +
		addToList(map, "StartDateFieldName") +
		addToList(map, "JobTitleFieldName") +
		addToList(map, "BaseSalaryFieldName")
	);
    
    return message;
}

def Message invalidConfig(Message message, String errorMessage) {
    message.setProperty("ValidConfig", "no");
    message.setProperty("ErrorCode", "INVALID_CLOUD_PLATFORM_INTEGRATION_CONFIGURATION");
    message.setProperty("ErrorMessage", errorMessage);
    return message;
}

def String addToList(Map<String, Object> map, String propertyName) {
    def propertyValue = map.get(propertyName);
    if (propertyValue != null && propertyValue != "") {
        return "," + propertyValue;
    }
    return "";
}