import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import javax.xml.xpath.*
import javax.xml.parsers.DocumentBuilderFactory

def Message processData(Message message) {
    
    def body = message.getBody(String);
    def map = message.getProperties();
    def xpath = XPathFactory.newInstance().newXPath()
    def builder = DocumentBuilderFactory.newInstance().newDocumentBuilder()
    def inputStream = new ByteArrayInputStream( body.bytes )
    def records = builder.parse(inputStream).documentElement

	message.setProperty("CandidateId", xpath.evaluate('/JobApplication/JobApplication/candidateId', records ))
	message.setProperty("CurrencyCode", "USD")
	readValue(message, "HireDate", 'HireDateFieldName', xpath, records)
    readValue(message, "Location", 'WorkLocationFieldName', xpath, records)
    readValue(message, "JobOfferDate", 'JobOfferDateFieldName', xpath, records)
    readValue(message, "Ssn", 'SocialSecurityNumberFieldName', xpath, records)
    readValue(message, "StartDate", 'StartDateFieldName', xpath, records)
    readValue(message, "Title", 'JobTitleFieldName', xpath, records)
    readValue(message, "AnnualSalary", 'BaseSalaryFieldName', xpath, records)
    
    return message;
    
}

def readValue(Message message, String propertyName, String fieldName, xpath, records) {
	def nodeName = message.getProperty(fieldName);
    message.setProperty(propertyName, nodeName != null && nodeName != "" ? xpath.evaluate('/JobApplication/JobApplication/' + nodeName, records ) : "");
}