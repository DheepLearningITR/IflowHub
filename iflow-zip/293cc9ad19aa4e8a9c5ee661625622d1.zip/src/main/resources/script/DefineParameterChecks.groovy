import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {

Map package_parameter_checks = [
   'Assign_Service_Employee_from_SAP_S4HANA_as_Warehouse_Owner_in_SAP_Field_Service_Management': [
      'Account': [
        'description': 'More - account',
        'group': 'Name',
        'alternative' : 'Account ID',
        'default': '<FSM_Account>'
      ],
      'Company': [
        'description': 'More - company',
        'group': 'Name',
        'alternative' : 'Company ID',
        'default': '<FSM_Company>'
      ],
      'Company ID': [
        'description': 'More - FSM Company ID',
        'group': 'ID',
        'type': 'number',      
        'alternative' : 'Company',
        'default': '<FSM_Company_ID>'
      ],
      'Account ID': [
        'description': 'More - FSM Account ID',
        'group': 'ID',
        'type': 'number',      
        'alternative' : 'Account',
        'default': '<FSM_Account_ID>'
      ],
	  'Address_To_Forward_Exception_Payload': [
        'description': 'Receiver - SendEmail Address',
        'mandatoryif': [ 'Email Error Notification', 'true']
	  ],
      'S4_Host': [
        'description': 'Receiver: OData plant storage location service employee - Address',        
        'mandatory': true,
        'default' : '<s4host>:<s4port>'
      ],
	  'S4ServiceURL': [
		'description': 'Receiver: OData plant storage location service employee - Address path',        
        'mandatory': true        
	  ],
      'proxy': [
          'description': 'Receiver: OData plant storage location service employee - Proxy Type'
      ],
	  'locationID': [
        'description': 'Receiver: OData plant storage location service employee - Location ID',
        'mandatoryif': [ 'proxy', 'On-Premise']
	  ],
	  'S4AuthenticationType': [
	    'description': 'Receiver: Odata plant storage location service employee - Authentication'
	  ],
      'S4CredentialName': [
        'description': 'Receiver: Odata plant storage location service employee - Credential Name',
        'mandatoryif': [ 'S4AuthenticationType', 'Basic' ],
        'default' : '<S4HANA_Credentials>'
      ],
      'S4_Timeout': [
        'description': 'Receiver: Odata plant storage location service employee - Timeout (in min)',
        'type': 'number',
        'mandatory': true
      ],
      'Credential Name': [
		'description' : 'FSM Credentials',
		'mandatory': true,
		'default' : '<FSM Credential Name>'
      ],
	  'CustomCompanyFilterQueryGroupSize': [
        'description': 'More - Custom Company Filter Query Group Size',
        'type': 'number',
        'mandatory': true
      ],
	  'Data Records per FSM Bulk Call': [
        'description': 'More - Custom Company Filter Query Group Size',
        'type': 'number',
        'mandatory': true
      ],
	  'DTO': [
        'description': 'FSM Warehouse DTO version',        
        'mandatory': true
      ],
      'Log Attachments on Error': [
        'description': 'More - Error Log Attachments',
        'type': 'boolean',
        'mandatory': true
      ],
      'Email Error Notification': [
        'description': 'More - Error Email Notification',
        'type': 'boolean',
        'mandatory': true
      ],
      'FSM Host': [
        'description': 'Receiver: FSM Host without protocal',
        'mandatory': true,
        'default' : '<FSM Host>'
      ],
      'Enable Post Exit': [
        'description': 'More - Post exit enable',
        'type': 'boolean',
        'mandatory': true
      ],
      'Enable Pre Exit': [
        'description': 'More - Pre exit enable',
        'type': 'boolean',
        'mandatory': true
      ],
      'Enable-pre-exit-MultiCompany': [
        'description': 'More - Pre exit multiple company enable',
        'type': 'boolean',
        'mandatory': true
      ]
	],
  'Notify_Service_Order_Update_from_SAP_Field_Service_Management_to_SAP_S4HANA': [
    'Header Extension Enabled': [
      'description': 'More - Header Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Service Order Note Language': [
      'description': 'More - Service Order Note Language',
      'size' : 2,
      'mandatory': true
    ],
    'Client Id': [
      'description': 'Receiver: Service_Order_Item_Update - Client Id',
      'mandatory': true
    ],
    'Address': [
      'description': 'Receiver: Service_Order_Item_Update - Address',
      'type': 'url',
      'mandatory': true,
      'default' : 'http://<s4host>:<s4port>/sap/opu/odata/sap/API_SERVICE_ORDER_SRV'
    ],
    'Timeout': [
      'description': 'Receiver: Service_Order_Item_Update - Timeout (in min)',
      'type': 'number',
      'mandatory': true
    ],
    'CredentialName': [
      'description': 'Receiver: Service_Order_Item_Update - Credential Name',
      'mandatoryif': [ 'Authentication', 'Basic' ],
      'default' : '<SAP S/4HANA Credential Name>'
    ],
    'LocationID': [
      'description': 'Receiver: Service_Order_Item_Update - Location ID',
      'mandatoryif': [ 'ProxyType', 'On-Premise']
    ],
    'Service Order Header Note Type': [
      'description': 'More - Service Order Header Note Type',
      'mandatory': true,
      'size' : 4
    ],
    'ProcessDirectAddress': [
      'description': 'Sender: SAP_FSM - Address',
      'mandatory': true
    ],
    'Service Order Header Problem Description Type': [
      'description': 'More - Service Order Header Problem Description Type',
      'mandatory': true,
      'size' : 4
    ],
    'Header Extension Address': [
      'description': 'More - Header Extension Address',
      'mandatoryif': [ 'Header Extension Enabled', 'true']
    ],
    'extensionAddress': [
      'description': 'More - extensionAddress',
      'mandatoryif': [ 'extensionEnable', 'true']
    ],
    'Private Key Alias': [
      'description': 'Receiver: Service_Order_Item_Update - Private Key Alias',
      'mandatoryif': [ 'Authentication', 'Client Certificate']
    ],
    'Authentication': [
        'description': 'Receiver: Service_Order_Item_Update - Authentication'
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'extensionEnable': [
      'description': 'More - extensionEnable',
      'type': 'boolean',
      'mandatory': true
    ],
    'User Status for Completed Activity': [
      'description': 'More - User Status for Completed Activity',
      'size': 5
    ],
    'ProxyType': [
        'description': 'Receiver: Service_Order_Item_Update - Proxy Type'
    ],
    'Service Order Item Note Type': [
      'description': 'More - Service Order Item Note Type',
      'mandatory': true,
      'size' : 4
    ],
    'Rejection Reason Code': [
      'description': 'More - Rejection Reason Code',
      'size': 2
    ],
    'Header Batch Extension Enabled': [
      'description': 'More - Header Batch Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Item Batch Extension Enabled': [
      'description': 'More - Item Batch Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],	
	'Item Rejection Reason Extension Enabled': [
      'description': 'More - Item Batch Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Header Batch Extension Address': [
      'description': 'More - Header Batch Extension Address',
      'mandatoryif': [ 'Header Batch Extension Enabled', 'true']
    ],
    'Item Batch Extension Address': [
      'description': 'More - Item Batch Extension Address',
      'mandatoryif': [ 'Item Batch Extension Enabled', 'true']
    ],
    'Item Rejection Reason Extension Address': [
      'description': 'More - Item Rejection Reason Extension Address',
      'mandatoryif': [ 'Item Rejection Reason Extension Enabled', 'true']
    ]
  ],
  'Notify_Plant_Maintenance_Order_Update_from_SAP_Field_Service_Management_to_SAP_S4HANA': [
    'ProcessdirectAddress': [
      'description': 'Sender: SAP_FSM - Address',
      'mandatory': true
    ],
    'Timeout': [
      'description': 'Receiver: Fetch Token S4HANA - Timeout (in min)',
      'type': 'number',
      'mandatory': true
    ],
    'S4HANA Authentication': [
        'description': 'Receiver: Fetch Token S4HANA - Timeout - S4HANA Authentication'
    ],
    'S4HANA Credential': [
      'description': 'Receiver: Fetch Token S4HANA - Timeout- S4HANA Credential',
      'mandatoryif': [ 'S4HANA Authentication', 'Basic' ],
      'default' : '<S4HANA_Credential_Name>'
    ],
    'S4HANA Host': [
      'description': 'Receiver: Fetch Token S4HANA - S4HANA Host',
      'mandatory': true,
      'default' : '<S4HANA_Host_Port>'
    ],
    'LocationID': [
      'description': 'Receiver: Fetch Token S4HANA - Location ID',
	   'mandatory': true,
	   'default': '<locationID>'
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Log Notification': [
      'description': 'More - Error Log Notification',
      'type': 'boolean',
      'mandatory': true
    ],
	'Send Email Notification': [
      'description': 'Receiver - Send Email Notification Address',
      'mandatoryif': [ 'Error Log Notification', 'true']
	],
	'Client ID': [
      'description': 'More - client ID',
      'mandatory': true
    ]
  ],
  'Replicate_Attachments_from_SAP_Field_Service_Management_to_SAP_S4HANA': [
	'Client Id': [
      'description': 'Receiver: S4Hana - Client Id',
      'mandatory': true
    ],
    'S4HANA Proxy Type': [
        'description': 'Receiver: S4Hana - Proxy Type',
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Attachment - FSM Host without https or http protocal',
      'mandatory': true,
      'default' : '<FSM Host>'
    ],
    'S4HANA Host': [
      'description': 'Receiver: S4Hana - S4HANA Host',
      'type': 'hostname',
      'mandatory': true,
      'default' : 'http://<S4Host>:<S4Port>'
    ],
    'User Role': [
      'description': 'Sender: FSM - User Role',
      'mandatory': true
    ],
    'S4HANA Credentials': [
      'description': 'Receiver: S4Hana - Credential Name',
      'mandatoryif': ['S4HANA Authentication', 'Basic'],
      'default' : '<SAP S/4HANA Credential Name>'
    ],
    'FSM Company ID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Company Name',
      'default': '<FSM_Company_ID>'
    ],
    'FSM Account Name': [
      'description': 'More - FSM Account Name',
      'group': 'Name',
      'alternative' : 'FSM Account ID',
      'default': '<FSM Account Name>'
    ],
    'Endpoint': [
      'description': 'Sender: FSM - Address',
      'mandatory': true,
      'description' : 'Address'
    ],
    'Private Key Alias': [
      'description': 'Receiver: S4Hana - Private Key Alias',
      'mandatoryif': [ 'S4HANA Authentication', 'Client Certificate']
    ],
    'FSM Company Name': [
      'description': 'More - FSM Company Name',
      'group': 'Name',
      'alternative' : 'FSM Company ID',
      'default': '<FSM Company Name>'
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'S4HANA Authentication': [
      'description': 'Receiver: S4Hana - Authentication',
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'S4HANA Location ID': [
      'description': 'Receiver: S4Hana - Location ID',
      'mandatoryif': [ 'S4HANA Proxy Type', 'On-Premise']
    ],
    'FSM Account ID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',      
      'alternative' : 'FSM Account Name',
      'default': '<FSM_Account_ID>'
    ],
    'FSM Credentials': [
      'description': 'Receiver: FSM_Attachment - Credential Name',
      'mandatory': true,
      'default' : '<FSM Credentials>'
    ],
    'BusinessObjectType Name for MaintenanceOrder': [
      'description': 'More - BusinessObjectType Name for MaintenanceOrder',      
      'mandatory': true
    ],
    'BusinessObjectTypeName For Maintenance Activity': [
      'description': 'Receiver: BusinessObjectTypeName For Maintenance Activity	',
      'mandatoryif': [ 'BusinessObjectType Name for MaintenanceOrder']
    ],
    'BusinessObjectType Name for ServiceOrder': [
      'description': 'BusinessObjectType Name for ServiceOrder',      
      'mandatory': true
    ],
    'BusinessObjectTypeName For Activity': [
      'description': 'Receiver: BusinessObjectTypeName For Maintenance Activity	',
      'mandatoryif': [ 'BusinessObjectType Name for ServiceOrder']
    ]
  ],
  'Replicate_Confirmed_Service_from_SAP_Field_Service_Management_to_SAP_S4HANA': [
    'Client Id': [
      'description': 'Receiver: ReadServiceOrder - Client Id',
      'mandatory': true
    ],
    'Address': [
      'description' : 'Receiver: Customer_Iflow - Address',
      'mandatoryif': [ 'Post Exit Enable', 'true'],
      'default' : '<customer_iflow_address>'
    ],
    'Address_For_ServiceOrder': [
      'description': 'Receiver: ReadServiceOrder - Address',
      'type': 'url',
      'mandatory': true,
      'default' : 'http://<s4host>:<s4port>/sap/opu/odata/sap/API_SERVICE_ORDER_SRV'
    ],
    'Service Confirmation Note Language': [
      'description': 'More - Service Confirmation Note Language',
      'mandatory': true,
      'size' : 2
    ],
    'Location_ID': [
      'description': 'Receiver: ReadServiceOrder - Location ID',
      'mandatoryif': [ 'Proxy_Type_For_Visiting_S4', 'On-Premise']
    ],
    'Service Confirmation Note Type': [
      'description': 'More - Service Confirmation Note Type',
      'mandatory': true,
      'size' : 4
    ],
    'ProcessDirectAddress': [
      'description': 'Sender - Address',
      'mandatory': true
    ],
    'Private Key Alias': [
      'description': 'Receiver: ReadServiceOrder - Private Key Alias',
      'mandatoryif': [ 'Authentication', 'Client Certificate']
    ],
    'Authentication': [
      'description': 'Receiver: ReadServiceOrder - Authentication',    
    ],
    'Address_For_ServiceConfirmation': [
      'description': 'Receiver: Create_Service_Confirmation - Address',
      'type': 'url',
      'mandatory': true,
      'default' : 'http://<s4host>:<s4port>/sap/opu/odata/sap/API_SERVICE_CONFIRMATION_SRV'
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Proxy_Type_For_Visiting_S4': [
      'description': 'Receiver: ReadServiceOrder - Proxy Type'
    ],
    'Credential_For_ServiceConfirmation': [
      'description': 'Receiver: Create_Service_Confirmation - Credential Name',
      'mandatoryif': [ 'Authentication', 'Basic' ],
      'default' : '<SAP S/4HANA Credential Name>'
    ],
    'Credential_For_ServiceOrder': [
      'description': 'Receiver: ReadServiceOrder - Credential Name',
      'mandatory': [ 'Authentication', 'Basic' ],
      'default' : '<SAP S/4HANA Credential Name>'
    ],
    'Item Category for Mileage': [
      'description': 'More - Item Category for Mileage',
      'size': 4,
      'mandatory': true,
	  'default': '<ItemCategory>'
    ],
    'Post Exit Enable': [ 
      'description': 'More - Post Exit Enable',
      'type': 'boolean',
      'mandatory': true
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Confirm_Time_and_Material - FSM Host without http protocol',
      'default': '<FSM_Host>'
    ],
    'FSM Credentials': [
      'description': 'Receiver: FSM_Confirm_Time_and_Material - Credential Name',
      'default': '<FSM Credentials>',
      'mandatoryif': ['FSM Host']
    ],
    'FSM Timeout': [
      'description': 'Receiver: FSM_Confirm_Time_and_Material - Timeout (in ms)',
      'type': 'number',
      'mandatoryif': ['FSM Host']
    ],
    'S4 SC Timeout': [
      'description': 'Receiver: Create_Service_Confirmation - Timeout (in min)',
      'type': 'number',
      'mandatoryif': ['Address_For_ServiceConfirmation']
    ],
    'S4 SO Timeout': [
      'description': 'Receiver: ReadServiceOrder - Timeout (in min)',
      'type': 'number',
      'mandatoryif': ['Address_For_ServiceOrder']
    ],
    'FSM Account ID': [
      'description': 'More - FSM Account ID',
      'type': 'number',
      'default': '<FSM_Account_ID>',
      'mandatoryif': ['FSM Host']
    ],
    'FSM Company ID': [
      'description': 'More - FSM Company ID',
      'type': 'number',
      'default': '<FSM_Company_ID>',
      'mandatoryif': ['FSM Host']
    ],
	'Efforts In Minutes': [  
      'description': 'More - Configure if efforts are in minutes or not',
      'type': 'boolean',
      'mandatory': true
	]
  ],
  'Replicate_Checklist_Instance_from_SAP_Field_Service_Management_to_SAP_S4HANA': [
    'Authorization': [
      'description': 'Sender: FSM - Authorization',
      'mandatory': true
    ],
    'User_Role': [
      'description': 'Sender: FSM - User_Role',
      'mandatoryif': ['Authorization', 'RoleBased'],
    ],
    'SubjectDN': [
      'description': 'Sender: FSM - SubjectDN',
      'mandatoryif': ['Authorization', 'Client Certificate'],
    ],
    'IssuerDN': [
      'description': 'Sender: FSM - IssuerDN',
      'mandatoryif': ['Authorization', 'Client Certificate'],
    ],	
    'Address': [
      'description': 'Sender: FSM - Address',
      'mandatory': true
    ],
	'SenderPayloadSize': [
      'description': 'Sender: FSM - SenderPayloadSize in mb',
      'type': 'number',
	  'mandatory': true
    ],
	'Enable Post Exit': [
      'description': 'More - Enable Post Exit',
      'type': 'boolean',
      'mandatory': true
    ],
	'Enable Pre-Exit': [
      'description': 'More - Enable Pre-Exit',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorEmailNotification': [
      'description': 'More - ErrorEmailNotification',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorLogAttachments': [
      'description': 'More - ErrorLogAttachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'PostExitEndpoint': [
      'description': 'Receiver: PostExitEndpoint address',
      'mandatoryif': [ 'Enable Post Exit']
    ],
    'PreExitEndpoint': [
      'description': 'Receiver: PreExitEndpoint address',
      'mandatoryif': [ 'Enable Pre-Exit']
    ],
    'ExceptionEmailEndpoint': [
      'description': 'Receiver: ExceptionEmailEndpoint address',
      'mandatoryif': [ 'ErrorEmailNotification']
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Confirmation - FSM Host without https or http protocal',
      'mandatory': true,
      'default' : '<FSM Host>'
    ],
    'FSM_Credentials': [
      'description': 'Receiver: FSM_Confirmation - FSM Host without https or http protocal',
      'mandatory': true,
      'default' : '<FSM_Credentials>'
    ],
	'FSM_Timeout': [
      'description': 'Receiver: FSM_Confirmation - Timeout in ms',
      'mandatory': true,
	  'type': 'number'
    ],	
	'sapClient': [
      'description': 'Receiver: S4Hana - Client Id',
      'mandatory': true,
	  'default': '<Client>'
    ],
    'proxy': [
        'description': 'Receiver: S4Hana - proxy',
    ],
    'locationID': [
      'description': 'Receiver: S4Hana - locationID',
      'mandatoryif': [ 'proxy', 'On-Premise']
    ],
    'AuthenticationMethod': [
      'description': 'Receiver: S4Hana - AuthenticationMethod',
    ],
    'CredentialName': [
      'description': 'Receiver: S4Hana - CredentialName',
      'mandatoryif': ['AuthenticationMethod', 'Basic'],
      'default' : '<Credential_Name>'
    ],
	'timeout': [
	  'description': 'Receiver: S4Hana - CredentialName',
	  'type': 'number',
	  'mandatory': true
	],
    'S4 Address': [
      'description': 'Receiver: S4Hana - Address',
      'type': 'url',
      'mandatory': true,
      'default' : 'http://<Host>:<Port>/sap/opu/odata/sap/API_FSM_CHECKLIST_SRV'
    ]
  ],
  'Replicate_Checklist_Template_from_SAP_Field_Service_Management_to_SAP_S4HANA': [
    'Authorization': [
      'description': 'Sender: FSM - Authorization',
      'mandatory': true
    ],
    'UserRole': [
      'description': 'Sender: FSM - UserRole',
      'mandatoryif': ['Authorization', 'RoleBased'],
    ],
    'subjectDN': [
      'description': 'Sender: FSM - subjectDN',
      'mandatoryif': ['Authorization', 'Client Certificate'],
    ],
    'issuerDN': [
      'description': 'Sender: FSM - issuerDN',
      'mandatoryif': ['Authorization', 'Client Certificate'],
    ],	
    'Address': [
      'description': 'Sender: FSM - Address',
      'mandatory': true
    ],
	'SenderPayloadSize': [
      'description': 'Sender: FSM - SenderPayloadSize in mb',
      'type': 'number',
	  'mandatory': true
    ],
	'post-exit-enabled': [
      'description': 'More - post-exit-enabled',
      'type': 'boolean',
      'mandatory': true
    ],
	'pre-exit-enabled': [
      'description': 'More - pre-exit-enabled',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorEmailNotification': [
      'description': 'More - ErrorEmailNotification',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorLogAttachments': [
      'description': 'More - ErrorLogAttachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'PostExitEndpoint': [
      'description': 'Receiver: PostExitEndpoint address',
      'mandatoryif': [ 'post-exit-enabled']
    ],
    'PreExitEndpoint': [
      'description': 'Receiver: PreExitEndpoint address',
      'mandatoryif': [ 'pre-exit-enabled']
    ],
    'ExceptionEmailEndpoint': [
      'description': 'Receiver: ExceptionEmailEndpoint address',
      'mandatoryif': [ 'ErrorEmailNotification']
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Confirmation - FSM Host without https or http protocal',
      'mandatory': true,
      'default' : '<FSM Host>'
    ],
    'FSM_Credentials': [
      'description': 'Receiver: FSM_Confirmation - FSM Host without https or http protocal',
      'mandatory': true,
      'default' : '<FSM_Credentials>'
    ],
	'FSM_Timeout': [
      'description': 'Receiver: FSM_Confirmation - Timeout in ms',
      'mandatory': true,
	  'type': 'number'
    ],	
	'SAPclient': [
      'description': 'Receiver: S4Hana - Client Id',
      'mandatory': true,
	  'default': '<Client_ID>'
    ],
    'proxy': [
        'description': 'Receiver: S4Hana - proxy',
    ],
    'locationID': [
      'description': 'Receiver: S4Hana - locationID',
      'mandatoryif': [ 'proxy', 'On-Premise']
    ],
    'AuthenticationMethod': [
      'description': 'Receiver: S4Hana - AuthenticationMethod',
    ],
    'CredentialName': [
      'description': 'Receiver: S4Hana - CredentialName',
      'mandatoryif': ['AuthenticationMethod', 'Basic'],
      'default' : '<CredentialName>'
    ],
	'timeout': [
	  'description': 'Receiver: S4Hana - CredentialName',
	  'type': 'number',
	  'mandatory': true
	],
    'S4 Address': [
      'description': 'Receiver: S4Hana - Address',
      'type': 'url',
      'mandatory': true,
      'default' : 'http://<host>:<port>/sap/opu/odata/sap/API_FSM_CHECKLIST_SRV'
    ]
  ],
  'Replicate_Confirmed_Maintenance_Service_from_SAP_Field_Service_Management_to_SAP_S4HANA': [
    'Client ID': [
      'description': 'More: S4HANA Client ID - Client ID',
      'mandatory': true
    ],
    'Error Log Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'ProcessdirectAddress': [
      'description': 'Sender - Address',
      'mandatory': true
    ],
    'S4HANA Host': [
      'description': 'Receiver: S4HANA Fetch Token - S4HANA Host',
      'mandatory': true,
      'default' : '<S4HANA_Host_Port>'
    ],
    'LocationID': [
      'description': 'Receiver: S4HANA Fetch Token - Location ID',
      'mandatory': true
    ],
    'S4HANA Authentication': [
      'description': 'Receiver: S4HANA Fetch Token - S4HANA Authentication',    
    ],
    'S4HANA Credential': [
      'description': 'Receiver: S4HANA Fetch Token - S4HANA Credential',
      'mandatoryif': [ 'S4HANA Authentication', 'Basic' ],
      'default' : '<S4HANA_Credential_Name>'
    ],
    'Timeout': [
      'description': 'Receiver: S4HANA Fetch Token - Timeout (in min)',
      'type': 'number',
      'mandatoryif': ['S4HANA Host']
    ],
	'Send Email Notification': [
      'description': 'Receiver - Send Email Notification Address',
      'mandatoryif': [ 'Error Log Notification', 'true']
	]
  ],
  'Replicate_Service_Call_from_SAP_Field_Service_Management_to_SAP_S4HANA': [
    'Service Order Note Language': [
      'description': 'More - Service Order Note Language',
      'mandatory': true,
      'size' : 2
    ],
    'address': [
      'description': 'Sender - Address',
      'mandatory': true
    ],
    'Client Id': [
      'description': 'Receiver: S4HANA_CreateServiceOrder - Client Id',
      'mandatory': true
    ],
    'Credential Name': [
      'description': 'Receiver: S4HANA_CreateServiceOrder - Credential Name',
      'mandatoryif': [ 'Authentication', 'Basic' ],
      'default' : '<SAP S/4HANA Credential Name>'
    ],
    'S4HANA Host': [
      'description': 'Receiver: S4HANA_CreateServiceOrder - S4HANA Host',
      'type': 'hostname',
      'mandatory': true,
      'default' : 'http://<S4Host>:<S4Port>'
    ],
    'FSM Host': [
      'description': 'Receiver: SAP_FSM_Update - FSM Host without http protocol',
      'mandatory': true,
      'default' : '<FSM Host>'
    ],
    'Service Order Header Note Type': [
      'description': 'More - Service Order Header Note Type',
      'mandatory': true,
      'size' : 4
    ],
    'Proxy Type': [
      'description': 'Receiver: S4HANA_CreateServiceOrder - Proxy Type',
    ],
    'FSM User': [
      'description': 'More - FSM User',
      'default' : '<FSM User>'
    ],
    'FSM HTTP Timeout': [
      'type': 'number',
      'mandatory': true
    ],
    'FSM Company ID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Company Name',
      'default': '<FSM_Company_ID>'
    ],
    'FSM Account Name': [
      'description': 'More - FSM Account Name',
      'group': 'Name',
      'alternative' : 'FSM Account ID',
      'default': '<FSM Account Name>'
    ],
    'Location ID': [
      'description': 'Receiver: S4HANA_CreateServiceOrder - Location ID',
      'mandatoryif': [ 'Proxy Type', 'On-Premise']
    ],
    'Service Order Header Problem Description Type': [
      'description': 'More - Service Order Header Problem Description Type',
      'mandatory': true,
      'size' : 4
    ],
    'FSM Company Name': [
      'description': 'More - FSM Company Name',
      'group': 'Name',
      'alternative' : 'FSM Company ID',
      'default': '<FSM Company Name>'
    ],
    'Private Key Alias': [
      'description': 'Receiver: S4HANA_CreateServiceOrder - Private Key Alias',
      'mandatoryif' : [ 'Authentication', 'Client Certificate']
    ],
    'Authentication': [
      'description': 'Receiver: S4HANA_CreateServiceOrder - Authentication',    
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'FSM Account ID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Account Name',
      'default': '<FSM_Account_ID>'
    ],
    'Post Mapping Extension Address': [
      'description': 'Receiver: Customer_Post_Mapping_Extension - Address',
      'mandatoryif': [ 'Post Mapping Extension Enabled', 'true']
    ],
    'FSM Credentials': [
      'description': 'Receiver: SAP_FSM_Update - Credential Name',
      'mandatory': true,
      'default' : '<FSM Credentials>'
    ],
    'Post Mapping Extension Enabled': [
      'description': 'More - Post Mapping Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ]
  ],
  'Replicate_Service_Order_from_SAP_S4HANA_to_SAP_Field_Service_Management_SOAP': [
    'Post Extension Address': [
      'description': 'Receiver: Customer_Post_Mapping_Extension_iFlow - Address',
      'mandatoryif': [ 'Post Extension Enabled', 'true'],
      'default' : '/'
    ],
    'Pre Extension MultipCompany': [
      'description': 'Receiver: MultiCompanyPreExit - Address',
      'mandatoryif': [ 'Post Extension MultiCompany Enabled', 'true'],
      'default' : '/'
    ],
    'Service Order Note Language': [
      'description': 'More - Service Order Note Language',
      'mandatory': true,
      'size' : 2
    ],
    'S4HANA Proxy Type': [
        'description': 'Receiver: S4HANA_Update - Proxy Type',
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_ServiceCall_with_Activities - FSM Host without protocol',
      'mandatory': true,
      'default' : '<FSM Host>'
    ],
    'Service Order Header Note Type': [
      'description': 'More - Service Order Header Note Type',
      'mandatory': true,
      'size' : 4
    ],
    'User Role': [
      'description': 'Sender - User Role',
      'mandatory': true
    ],
    'SubjectDN': [
      'description': 'Sender: S4SOAP - Subject DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Subject_DN>'
    ],
    'FSM HTTP Timeout': [
      'description': 'Receiver: FSM_Create_ServiceCall_with_Activities - Timeout (in ms)',
      'type': 'number',
      'mandatory': true
    ],
    'Update SO Odata Timeout': [
      'description': 'Receiver: S4HANA_Update - Timeout (in min)',
      'type': 'number',
      'mandatory': true
    ],
    'S4HANA Credentials': [
      'description': 'Receiver: S4HANA_Update - Credential Name',
      'mandatoryif': [ 'S4HANA Authentication', 'Basic' ],
      'default' : '<SAP S/4HANA Credential Name>'
    ],
    'Authorization': [
        'description': 'Sender: S4SOAP - Authentication',    
    ],
    'FSM Company ID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Company Name',
      'default': '<FSM_Company_ID>'
    ],
    'Service Order Header Problem Description Type': [
      'description': 'More - Service Order Header Problem Description Type',
      'mandatory': true,
      'size' : 4
    ],
    'Endpoint': [
      'description' : 'Sender: S4SOAP - Address',
      'mandatory': true
    ],
    'FSM Company Name': [
      'description': 'More - FSM Company Name',
      'group': 'Name',
      'alternative' : 'FSM Company ID',
      'default': '<FSM_Company>'
    ],
    'FSM Account ID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Account Name',
      'default': '<FSM_Account_ID>'
    ],
    'Item Categories For FSM Activities': [
      'description': 'More - Item Categories For FSM Activities',
      'separator': '\\|',
      'size': 4,
      'mandatory': true
    ],
    'Service Order Item Note Type': [
      'description': 'More - Service Order Header Item Note Type',
      'mandatory': true,
      'size' : 4
    ],
    'Client Id': [
      'description': 'Receiver: S4HANA_Update - Client Id',
      'mandatory': true
    ],
    'S4HANA Host': [
      'description': 'Receiver: S4HANA_Update - S4HANA Host',
      'default' : 'http://<S4Host>:<S4Port>',
      'type': 'hostname',
      'mandatory': true
    ],
    'Item Categories For FSM Reserved Materials': [
      'description': 'More - Item Categories For FSM Reserved Materials',
      'separator': '\\|',
      'size': 4,
      'mandatory': true
    ],
    'Post Extension Enabled': [
      'description': 'More - Post Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Post Extension MultiCompany Enabled': [
      'description': 'More - Post Extension MultiCompany Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
	'CustomCompanyFilterQueryGroupSize': [
      'description': 'More - Custom Company Filter Query Group Size',
      'type': 'number',
      'mandatory': true
    ],
    'FSM User': [
      'description': 'More - FSM User',
      'default': '<FSM User>'
    ],
    'FSM autoCreateActivity': [
      'description': 'More - FSM autoCreateActivity',
      'type': 'boolean',
      'mandatory': true
    ],
    'FSM Account Name': [
      'description': 'More - FSM Account Name',
      'group': 'Name',
      'alternative' : 'FSM Account ID',
      'default': '<FSM_Account>'
    ],
    'Issuer_DN': [
      'description': 'Sender: S4SOAP - Issuer DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Issuer_DN>'
    ],
    'Private Key Alias': [
      'description': 'Receiver: S4HANA_Update - Private Key Alias',
      'mandatoryif': [ 'S4HANA Authentication', 'Client Certificate']
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'S4HANA Authentication': [
      'description': 'Receiver: S4HANA_Update - Authentication',
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'S4HANA Location ID': [
      'description': 'Receiver: S4HANA_Update - Location ID',
      'mandatoryif': [ 'S4HANA Proxy Type', 'Internet']
    ],
    'FSM Credentials': [
      'description': 'Receiver: FSM_Create_ServiceCall_with_Activities - Credential Name',
      'mandatory': true,
      'default' : '<FSM Credentials>'
    ],
    'Enable Service Product Replication': [
      'description': 'More - Enable Service Product Replication',
      'type': 'boolean',
      'mandatory': true
    ],
    'EnableMultiCompanyReplication': [
      'description': 'More - Enable Mulitple Company Replication',
      'type': 'boolean',
      'mandatory': true
    ],
  ],
  'Route_Payload_from_SAP_Field_Service_Management_to_SAP_S4HANA': [
    'ProcessDirectSODuplicateAct': [
      'description': 'Receiver: Update_Service_Order_Create_Item - Address',
      'mandatory': true
    ],
    'Address Create Service Order': [
      'description': 'Receiver: Create_Service_Order - Address',
      'mandatory': true
    ],
    'Consider HTTP 409 as Locking Issue': [
      'description': 'More - Consider HTTP 409 as Locking Issue',
      'type': 'boolean',
      'mandatory': true
    ],
    'Address': [
      'description': 'Sender: FSM - Address',
      'mandatory': true
    ],
    'Service Call Status Used in Replication': [
      'description': 'More - Service Call Status Used in Replication',
      'separator': '\\|',
      'mandatory': true
    ],
    'Maintenance Service Call Type Code': [
      'description': 'More - Maintenance Service Call Type Code Used in Replication',
      'separator': '\\|',
      'mandatory': true
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'ProcessDirectServiceOrder': [
      'description': 'Receiver: Update_Service_Order_For_Complete_Service_Item - Address',
      'mandatory': true
    ],
    'User Role': [
      'description': 'Sender: FSM - User Role',
      'mandatory': true
    ],
    'ProcessDirectServiceConfirmation': [
      'description': 'Receiver: Create_Service_Confirmation - Address',
      'mandatory': true
    ],
    'ProcessDirectPlantConfirmation': [
      'description': 'Receiver: Create_Plant_Confirmation - Address',
      'mandatory': true
    ],
    'ProcessDirectPMUpdate': [
      'description': 'Receiver: Update_Plant_MaintenanceOrder - Address',
      'mandatory': true
    ]
  ],
  'Send_Error_Email_for_Integration_SAP_S4HANA_with_SAP_Field_Service_Management': [
    'Email Server Address': [
      'description': 'Receiver: Email_Receiver - Address',
      'mandatory': true,
      'type': 'emailhostname',      
      'default' : '<SMTP_host:port>'
    ],
    'Secret Key Length': [
      'description': 'Receiver: Email_Receiver - Secret Key Length',
      'mandatoryif': [ 'Email Content Encryption Algorithm', 'AEY/CBC/PKCS5Padding']
    ],
    'Email Authentication Method': [
      'description': 'Receiver: Email_Receiver - Authentication',
    ],
    'Email Content Encryption Algorithm': [
      'description': 'Receiver: Email_Receiver - Content Encryption Algorithm',
      'mandatoryif': [ 'Email Signature and Encryption Type', 'S/MIME Encryption', 'S/MIME Signature and Encryption']
    ],
    'Email Credentials for OAuth2': [
      'description': 'Receiver: Email_Receiver - Credential Name',
      'mandatoryif' : [ 'Email Authentication Method', 'OAuth2 Authorization Code']
    ],
    'Email Signature Private Key Alias': [
      'description': 'Receiver: Email_Receiver - Private Key Alias',
      'default' : '<Email Signature Private Key Alias>',
      'mandatoryif': [ 'Email Signature and Encryption Type', 'S/MIME Signature', 'S/MIME Signature and Encryption']
    ],
    'Email Subject': [
      'description': 'Receiver: Email_Receiver - Subject',
      'default' : '<Email Subject>',
      'mandatory': true
    ],
    'Email Sender': [
      'description': 'Receiver: Email_Receiver - From',
      'mandatory': true,
      'default' : '<email_from@email.com>',
      'type': 'email'
    ],
    'Email Protection': [
      'description': 'Receiver: Email_Receiver - Protection',
    ],
    'Email Credentials for User Password': [
      'description': 'Receiver: Email_Receiver - Credential Name',
      'mandatoryif': [ 'Email Authentication Method', 'Encrypted User/Password', 'Plain User/Password'],
      'default' : '<Email Credentials>'
    ],
    'Email Receiver': [
      'description': 'Receiver: Email_Receiver - To',
      'mandatory': true,
      'default' : '<email_to@email.com>',
      'type': 'email'
    ],
    'Email Signature and Encryption Type': [
      'description': 'Receiver: Email_Receiver - Signature and Encryption Type',
    ],
    'Email Connection Location ID': [
      'description': 'Receiver: Email_Receiver - Location ID',
      'mandatoryif': [ 'Email Proxy Type', 'On-Premise']
    ],
    'Email Receiver Bcc': [
      'description': 'Receiver: Email_Receiver - Bcc'
    ],
    'Email Timeout': [
      'description': 'Receiver: Email_Receiver - Timeout (in ms)',
      'type': 'number',
      'mandatory': true
    ],
    'Email Receiver Public Key': [
      'description': 'Receiver: Email_Receiver - Public Key',
      'default' : '<Email Receiver Public Key>',
      'mandatoryif': [ 'Email Signature and Encryption Type', 'S/MIME Encryption', 'S/MIME Signature and Encryption']
    ],
    'Email Send Clear Text Signed Message': [
      'description': 'Receiver: Email_Receiver - Send Clear Text Signed Message'
    ],
    'Email Proxy Type': [
      'description': 'Receiver: Email_Receiver - Proxy Type'
    ],
    'Email Receiver Cc': [
      'description': 'Receiver: Email_Receiver - Cc'
    ]
  ],
  'Update_Service_Order_for_Duplicate_Activity_from_SAP_Field_Service_Management_to_SAP_S4HANA': [
    'Service Order Note Language': [
      'description': 'More - Service Order Note Language',
      'mandatory': true,
      'size' : 2
    ],
    'LocationID': [
      'description': 'Receiver: S4HANA_Create - Location ID',
      'mandatoryif': [ 'ProxyType', 'On-Premise']
    ],
    'Creation Post Mapping Extension Enabled': [
      'description': 'More - Creation Post Mapping Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'Product Id for Service Item': [
      'description': 'More - Product Id for Service Item',
      'mandatory': true
    ],
    'AuthenticationMethod': [
      'description': 'Receiver: S4HANA_Create - Authentication',
    ],
    'Creation Post Mapping Address': [
      'description': 'Receiver: Creation_Post_Mapping_Extension_iFlow - Address',
      'mandatoryif': [ 'Creation Post Mapping Extension Enabled', 'true']
    ],
    'FSM Company ID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',      
      'alternative' : 'company',
      'default': '<FSM_Company_ID>'
    ],
    'ProcessDirectAddress': [
      'description': 'Sender: FSM - Address',
      'mandatory': true
    ],
    'company': [
      'description': 'More - company',
      'group': 'Name',
      'alternative' : 'FSM Company ID',
      'default': '<FSM_Company>'
    ],
    'FSM Account ID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',      
      'alternative' : 'account',
      'default': '<FSM_Account_ID>'
    ],
    'Service Order Item Note Type': [
      'description': 'More - Service Order Item Note Type',
      'mandatory': true,
      'size' : 4
    ],
    'Client Id': [
      'description': 'Receiver: S4HANA_Create - Client Id',
      'mandatory': true
    ],
    'CredentialName': [
      'description': 'Receiver: S4HANA_Create - Credential Name',
      'mandatoryif': [ 'AuthenticationMethod', 'Basic' ],
      'default' : '<SAP S/4HANA Credential Name>'
    ],
    'Credential Name': [
      'description' : 'FSM Credentials',
      'mandatory': true,
      'default' : '<FSM Credential Name>'
    ],
    'ODataServiceAddress': [
      'description': 'Receiver: S4HANA_Create - Address',
      'type': 'url',
      'mandatory': true,
      'default' : 'http://<s4host>:<s4port>/sap/opu/odata/sap/API_SERVICE_ORDER_SRV'
    ],
    'Private Key Alias': [
      'description': 'Receiver: S4HANA_Create - Private Key Alias',
      'mandatoryif': [ 'AuthenticationMethod', 'Client Certificate']
    ],
    'Error Log Attachments': [
      'description': 'More - Error Log Atachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
    'Post Mapping Extension Address': [
      'description': 'Receiver: Duplication_Post_Mapping_Extension_iFlow - Address',
      'mandatoryif': [ 'Post Mapping Extension Enabled', 'true']
    ],
    'ProxyType': [
        'description': 'Receiver: S4HANA_Create - Proxy Type'
    ],
    'FSM Host': [
      'description': 'Receiver: SAP_FSM_Update - Address',      
      'mandatory': true,
      'default' : '<FSM Host>'
    ],
    'Post Mapping Extension Enabled': [
      'description': 'More - Post Mapping Extension Enabled',
      'type': 'boolean',
      'mandatory': true
    ],
    'user': [
      'description': 'More - user',
      'default' : '<FSM_User>'
    ],
    'account': [
      'description': 'More - account',
      'group': 'Name',
      'alternative' : 'FSM Account ID',
      'default': '<FSM_Account>'
    ]
  ],
  'Synchronize_Multiple_Company_Mapping_Configuration_S4HANA': [
    'Timer': [
        'description': 'Sender: Timer Configuration',    
    ],
    'SAP Cloud Integration Host': [
      'description': 'Receiver: SCI - SAP Cloud Integration Host',
      'mandatory': true,
      'default' : '<SCI Host>'
    ],
    'SAP Cloud Integration Host': [
      'description': 'Receiver: SCI - SAP Cloud Integration Host',
      'mandatory': true,
      'default' : '<SCI Host>'
    ],
    'SCI Authentication': [
      'description': 'Receiver: SCI - SCI Authentication',
    ],
    'SCI CredentialName': [
      'description': 'Receiver: SCI - SCI CredentialName',
      'mandatoryif': [ 'SCI Authentication', 'Basic', 'OAuth2 Client Credentials', 'OAuth2 SAML Bearer Assertion' ],
      'default' : '<SCI_Credentials>'
    ],
    'SCI Private Key': [
      'description': 'Receiver: SCI - SCI Private Key',
      'mandatoryif': [ 'SCI Authentication', 'Client Certificate' ],
      'default' : '<SCI_PrivateKey>'
    ],
    's4_host': [
      'description': 'Receiver: S4HANA - s4_host',
      'default' : 'http://<S4H_Host:Port>',
      'type': 'hostname',
      'mandatory': true
    ],
    'ProxyType': [
        'description': 'Receiver: S4HANA - ProxyType',
    ],
    'LocationID': [
      'description': 'Receiver: S4HANA - LocationID',
      'mandatoryif': [ 'ProxyType', 'Internet'],
	  'default': '<Location ID>'
    ],
    'S4HANA Authentication': [
      'description': 'Receiver: S4HANA - S4HANA Authentication',
    ],
    'S4HANA Credential': [
      'description': 'Receiver: S4HANA - S4HANA Credential',
      'mandatoryif': [ 'S4HANA Authentication', 'Basic', 'OAuth2 Client Credentials' ],
      'default' : '<S4HANA Credential>'
    ],
    'S4HANA PrivateKey Alias': [
      'description': 'Receiver: S4HANA - S4HANA PrivateKey Alias',
      'mandatoryif': [ 'S4HANA Authentication', 'Client Certificate' ]      
    ],
	'S4HANA Timeout': [
      'description': 'Receiver: S4HANA - S4HANA Timeout (in min)',
      'type': 'number',
      'mandatory': true
    ],
    'ClientID': [
      'description': 'More - ClientID S4HANA Client',
      'mandatory': true
    ],
    'ClientID': [
      'description': 'More - ClientID S4HANA Client',
      'mandatory': true,
	  'default': '<sap_client>'
    ],
    'Integration Package ID': [
      'description': 'More - Integration Package IDt',
      'mandatory': true,
	  'default': '<Integration Package ID>'
    ]
  ],  
  'Create_Business_Partner_Relationships': [
    'Address': [
      'description' : 'Sender: S4Hana - Address',
      'mandatory': true
    ],
    'Authorization': [
        'description': 'Sender: S4Hana - Authorization',    
    ],
    'User_Role': [
      'description': 'Sender - User_Role',
      'mandatoryif': [ 'Authorization', 'User Role']	  
    ],
    'Issuer_DN': [
      'description': 'Sender: S4Hana - Issuer_DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Issuer_Distinguished_Name>'
    ],
    'Subject_DN': [
      'description': 'Sender: S4Hana - Subject_DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Subject_Distinguished_Name>'
    ],
    'Enable post-exit': [
      'description': 'More - Enable post-exit	',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable pre-exit': [
      'description': 'More - Enable pre-exit',
      'type': 'boolean',
      'mandatory': true
    ],
	'Enable pre-exit MultiCompany': [
      'description': 'More - Enable pre-exit MultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
	'EnableMultiCompanyReplication': [
      'description': 'More - EnableMultiCompanyReplication',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorEmailNotification': [
      'description': 'More - ErrorEmailNotification',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorLogAttachments': [
      'description': 'More - ErrorLogAttachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Post-exit integration flow endpoint': [
      'description': 'Receiver: Post-exit-flow - Post-exit integration flow endpoint',
      'mandatoryif': [ 'Enable post-exit'],
      'default' : '/'
    ],
    'Pre-exit integration flow endpoint': [
      'description': 'Receiver: Pre-exit-flow - Pre-exit integration flow endpoint',
      'mandatoryif': [ 'Enable pre-exit'],
      'default' : '/'
    ],
    'Pre-exit Custom MultiCompany Path': [
      'description': 'Receiver: Pre-exit-MultiCompany - Pre-exit Custom MultiCompany Path',
      'mandatoryif': [ 'Enable pre-exit MultiCompany'],
      'default' : '/'
    ],
    'Exception handling iflow endpoint': [
      'description': 'Receiver: Send_Email - Exception handling iflow endpoint path',
      'mandatoryif': [ 'ErrorEmailNotification'],
      'default' : '/'
    ],
    'Client Id': [
      'description': 'More - S4HANA Client Id',
      'mandatory': true
    ],
	'CustomCompanyFilterQueryGroupSize': [
      'description': 'More - CustomCompanyFilterQueryGroupSize',
      'mandatory': true,
	  'type': 'number'
    ],
    'CompanyID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'Company',
      'default': '<FSM_Company_ID>'
    ],
    'Company': [
      'description': 'More - FSM Company Name',
      'group': 'Name',
      'alternative' : 'CompanyID',
      'default': '<FSM_Company>'
    ],
    'AccountID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'Account',
      'default': '<FSM_Account_ID>'
    ],
    'Account': [
      'description': 'More - FSM Account Name',
      'group': 'Name',
      'alternative' : 'AccountID',
      'default': '<FSM_Account>'
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Business_Partner_Relationship - FSM Host without protocol',
      'mandatory': true,
      'default' : '<FSM Host>'
    ],
    'DTO': [
      'description': 'Receiver: FSM_Create_Business_Partner_Relationship - Contact DTO version',
      'mandatory': true
    ],
    'Credential Name': [
      'description': 'Receiver: FSM_Create_Business_Partner_Relationship - Credential Name',
      'mandatory': true,
	  'default': '<FSM_Credentials>'
    ],
    'Timeout': [
      'description': 'Receiver: FSM_Create_Business_Partner_Relationship - Timeout in ms',
      'mandatory': true
    ],	
    'S4HANA Host Port': [
      'description': 'Receiver: S4HANA - S4HANA Host Port',
      'mandatory': true,
	  'default': '<S4HANA_Host:Port>'
    ],
    'S4HANA_Authentication': [
      'description': 'Receiver: S4HANA - S4HANA Authentication',
      'mandatory': true
    ],
    'S4HANA_CredentialName': [
      'description': 'Receiver: S4HANA - S4HANA_CredentialName',
      'mandatoryif': [ 'S4HANA_Authentication', 'Basic'],
	  'default': '<S4HANA_Credentials>'
    ],
	'ProxyType': [
        'description': 'Receiver: S4HANA - ProxyType',
    ],
    'S4HANA_LocationID': [
      'description': 'Receiver: S4HANA - S4HANA_LocationID',
      'mandatoryif': [ 'ProxyType', 'On-Premise'],
	  'default': '<LocationID>'
    ]
  ],
  'Delete_Business_Partner_Employee': [
	'Retention Period': [
      'description': 'More - Retention Period',
      'mandatory': true,
	  'type': 'number'
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Query - FSM Host without protocol',
      'mandatory': true,
      'default' : '<FSM_Host>'
    ],
    'DTO': [
      'description': 'Receiver: FSM_Query - UnifiedPerson DTO version',
      'mandatory': true
    ],
    'Credential Name': [
      'description': 'Receiver: FSM_Query - Credential Name',
      'mandatory': true,
	  'default': '<FSM_Credentials>'
    ],
    'Timeout': [
      'description': 'Receiver: FSM_Query - Timeout in ms',
      'mandatory': true
    ]
  ],
  'Replicate_Business_Partner_Address_from_SAP_S4HANA_to_SAP_Field_Service_Management': [
    'Address': [
      'description' : 'Sender: S4Hana - Address',
      'mandatory': true
    ],
    'Enable post-exit': [
      'description': 'More - Enable post-exit	',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable pre-exit': [
      'description': 'More - Enable pre-exit',
      'type': 'boolean',
      'mandatory': true
    ],
	'EnableMultiCompany': [
      'description': 'More - EnableMultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorEmailNotification': [
      'description': 'More - ErrorEmailNotification',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorLogAttachments': [
      'description': 'More - ErrorLogAttachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Post-exit integration flow endpoint': [
      'description': 'Receiver: Post-exit-flow - Post-exit integration flow endpoint',
      'mandatoryif': [ 'Enable post-exit'],
      'default' : '/'
    ],
    'Pre-exit integration flow endpoint': [
      'description': 'Receiver: Pre-exit-flow - Pre-exit integration flow endpoint',
      'mandatoryif': [ 'Enable pre-exit'],
      'default' : '/'
    ],
    'Exception handling iflow endpoint': [
      'description': 'Receiver: Send_Email - Exception handling iflow endpoint path',
      'mandatoryif': [ 'ErrorEmailNotification'],
      'default' : '/'
    ],
    'FSM Company ID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Company Name',
      'default': '<FSM_Company_ID>'
    ],
    'FSM Company Name': [
      'description': 'More - FSM Company Name',
      'group': 'Name',
      'alternative' : 'FSM Company ID',
      'default': '<FSM_Company>'
    ],
    'FSM Account ID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Account Name',
      'default': '<FSM_Account_ID>'
    ],
    'FSM Account Name': [
      'description': 'More - FSM Account Name',
      'group': 'Name',
      'alternative' : 'FSM Account ID',
      'default': '<FSM_Account>'
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Business_Partner_Address - FSM Host without protocol',
      'mandatory': true,
      'default' : '<FSM Host>'
    ],
    'DTO': [
      'description': 'Receiver: FSM_Create_Business_Partner_Address - Address DTO version',
      'mandatory': true
    ],
    'Credential Name': [
      'description': 'Receiver: FSM_Create_Business_Partner_Address - Credential Name',
      'mandatory': true,
	  'default': '<FSM_Credentials>'
    ],
    'Timeout': [
      'description': 'Receiver: FSM_Create_Business_Partner_Address - Timeout in ms',
      'mandatory': true
    ]
  ],
  'Replicate_Business_Partner_Contact': [
    'Address': [
      'description' : 'Sender: S4Hana - Address',
      'mandatory': true
    ],
    'Enable post-exit': [
      'description': 'More - Enable post-exit	',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable pre-exit': [
      'description': 'More - Enable pre-exit',
      'type': 'boolean',
      'mandatory': true
    ],
	'Enable_Pre-Exit_MultiCompany': [
      'description': 'More - Enable_Pre-Exit_MultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
	'EnableMultiCompany': [
      'description': 'More - EnableMultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorEmailNotification': [
      'description': 'More - ErrorEmailNotification',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorLogAttachments': [
      'description': 'More - ErrorLogAttachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Post-exit integration flow endpoint': [
      'description': 'Receiver: Post-exit-flow - Post-exit integration flow endpoint',
      'mandatoryif': [ 'Enable post-exit'],
      'default' : '/'
    ],
    'Pre-exit integration iflow endpoint': [
      'description': 'Receiver: Pre-exit-flow - Pre-exit integration flow endpoint',
      'mandatoryif': [ 'Enable pre-exit'],
      'default' : '/'
    ],
    'Pre-exit Custom MultiCompany Path': [
      'description': 'Receiver: ProcessDirectMulticomany - Pre-exit Custom MultiCompany Path',
      'mandatoryif': [ 'Enable_Pre-Exit_MultiCompany'],
      'default' : '/'
    ],
    'Address_of_Exception_Iflow': [
      'description': 'Receiver: Send_Email - Address_of_Exception_Iflow	 path',
      'mandatoryif': [ 'ErrorEmailNotification'],
      'default' : '/'
    ],
    'CompanyID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'Company Name',
      'default': '<FSM_Company_ID>'
    ],
    'Company Name': [
      'description': 'More - FSM Company Name',
      'group': 'Name',
      'alternative' : 'CompanyID',
      'default': '<FSM_Company>'
    ],
    'AccountID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'Account',
      'default': '<FSM_Account_ID>'
    ],
    'Account': [
      'description': 'More - FSM Account Name',
      'group': 'Name',
      'alternative' : 'AccountID',
      'default': '<FSM_Account>'
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Business_Partner_Contact - FSM Host without protocol',
      'mandatory': true,
      'default' : '<FSM Host>'
    ],
    'DTO': [
      'description': 'Receiver: FSM_Create_Business_Partner_Contact - Contact DTO version',
      'mandatory': true
    ],
    'Credential Name': [
      'description': 'Receiver: FSM_Create_Business_Partner_Contact - Credential Name',
      'mandatory': true,
	  'default': '<FSM_Credentials>'
    ],
    'Timeout': [
      'description': 'Receiver: FSM_Create_Business_Partner_Contact - Timeout in ms',
      'mandatory': true
    ]
  ],
  'Replicate_Business_Partners_from_SAP_S4HANA_to_SAP_Field_Service_Management': [
    'Address': [
      'description' : 'Sender: S4Hana - Address',
      'mandatory': true
    ],
    'Authorization': [
        'description': 'Sender: S4Hana - Authorization',    
    ],
    'User_Role': [
      'description': 'Sender - User_Role',
      'mandatoryif': [ 'Authorization', 'User Role']	  
    ],
    'Issuer_DN': [
      'description': 'Sender: S4Hana - Issuer_DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Issuer_Distinguished_Name>'
    ],
    'Subject_DN': [
      'description': 'Sender: S4Hana - Subject_DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Subject_Distinguished_Name>'
    ],
    'Enable post-exit': [
      'description': 'More - Enable post-exit	',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable pre-exit': [
      'description': 'More - Enable pre-exit',
      'type': 'boolean',
      'mandatory': true
    ],
	'Enable-pre-exit-MultiCompany': [
      'description': 'More - Enable-pre-exit-MultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
	'EnableMultiCompanyReplication': [
      'description': 'More - EnableMultiCompanyReplication',
      'type': 'boolean',
      'mandatory': true
    ],
	'EnableOrgAssignment': [
      'description': 'More - EnableOrgAssignment',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorEmailNotification': [
      'description': 'More - ErrorEmailNotification',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorLogAttachments': [
      'description': 'More - ErrorLogAttachments',
      'type': 'boolean',
      'mandatory': true
    ],
	'IgnoreCategory': [
      'description': 'More - IgnoreCategory',
      'type': 'boolean',
      'mandatory': true
    ],
    'Post-ext integration flow endpoint': [
      'description': 'Receiver: Post-exit - Post-ext integration flow endpoint',
      'mandatoryif': [ 'Enable post-exit'],
      'default' : '/'
    ],
    'Pre-ext integration flow endpoint': [
      'description': 'Receiver: Pre-exit - Pre-ext integration flow endpoint',
      'mandatoryif': [ 'Enable pre-exit'],
      'default' : '/'
    ],
    'Pre-ext MultiCompany flow endpoint': [
      'description': 'Receiver: pre-exit-MultiCompany - Pre-ext MultiCompany flow endpoint Path',
      'mandatoryif': [ 'Enable-pre-exit-MultiCompany'],
      'default' : '/'
    ],
    'Exception integration flow endpoint': [
      'description': 'Receiver: Send_Email - Exception integration flow endpoint path',
      'mandatoryif': [ 'ErrorEmailNotification'],
      'default' : '/'
    ],
    'Address_Forward_Business_Partner_Address_Replication': [
      'description': 'Receiver: Address - Address_Forward_Business_Partner_Address_Replication path',
      'mandatory': true,
      'default' : '/'
    ],
    'Address_Forward_Business_Partner_Contact_Replication': [
      'description': 'Receiver: Contact - Address_Forward_Business_Partner_Contact_Replication path',
      'mandatory': true,
      'default' : '/'
    ],
    'Address_Forward_Business_Partner_Employee_Replication': [
      'description': 'Receiver: Employee - Address_Forward_Business_Partner_Employee_Replication path',
      'mandatory': true,
      'default' : '/'
    ],
    'sap-client': [
      'description': 'More - S4HANA sap-client',
      'mandatory': true
    ],
	'CustomCompanyFilterQueryGroupSize': [
      'description': 'More - CustomCompanyFilterQueryGroupSize',
      'mandatory': true,
	  'type': 'number'
    ],
	'FilterQueryGroupSize': [
      'description': 'More - FilterQueryGroupSize',
      'mandatory': true,
	  'type': 'number'
    ],
    'Company ID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'Company',
      'default': '<FSM_Company_ID>'
    ],
    'Company': [
      'description': 'More - FSM Company Name',
      'group': 'Name',
      'alternative' : 'Company ID',
      'default': '<FSM_Company>'
    ],
    'Account ID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'Account',
      'default': '<FSM_Account_ID>'
    ],
    'Account': [
      'description': 'More - FSM Account Name',
      'group': 'Name',
      'alternative' : 'Account ID',
      'default': '<FSM_Account>'
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Business_Partner - FSM Host without protocol',
      'mandatory': true,
      'default' : '<FSM_Host>'
    ],
    'BusinessPartnerDTO': [
      'description': 'Receiver: FSM_Create_Business_Partner - Contact DTO version',
      'mandatory': true
    ],
    'Credential Name': [
      'description': 'Receiver: FSM_Create_Business_Partner - Credential Name',
      'mandatory': true,
	  'default': '<FSM_Credentials>'
    ],
    'Timeout': [
      'description': 'Receiver: FSM_Create_Business_Partner - Timeout in ms',
      'mandatory': true
    ],	
    'S4HANAHost': [
      'description': 'Receiver: S4HANA_OrgLevel - S4HANA Host Port',
      'mandatory': true,
	  'default': '<S4HANA_Host:Port>'
    ],
    'Authentication': [
      'description': 'Receiver: S4HANA_OrgLevel - S4HANA Authentication',
      'mandatory': true
    ],
    'S4HANA Credentials': [
      'description': 'Receiver: S4HANA_OrgLevel - S4HANA Credentials',
      'mandatoryif': [ 'Authentication', 'Basic'],
	  'default': '<S4H_Credentials>'
    ],
	'Proxy Type': [
        'description': 'Receiver: S4HANA_OrgLevel - Proxy Type',
    ],
    'S4HANA Location ID': [
      'description': 'Receiver: S4HANA_OrgLevel - S4HANA Location ID',
      'mandatoryif': [ 'Proxy Type', 'On-Premise'],
	  'default': '<LocationID>'
    ],
    'S4HANA Timeout': [
      'description': 'Receiver: S4HANA_OrgLevel - S4HANA Timeout in mins',
      'mandatory': true,
	  'type': 'number'
    ]
  ],
  'Replicate_Item_Group': [
    'Address': [
      'description' : 'Sender: S4Hana - Address',
      'mandatory': true
    ],
    'Authorization': [
        'description': 'Sender: S4Hana - Authorization',    
    ],
    'User_Role': [
      'description': 'Sender - User_Role',
      'mandatoryif': [ 'Authorization', 'User Role']	  
    ],
    'Issuer_DN': [
      'description': 'Sender: S4Hana - Issuer_DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Issuer_Distinguished_Name>'
    ],
    'Subject_DN': [
      'description': 'Sender: S4Hana - Subject_DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Subject_Distinguished_Name>'
    ],
    'Enable_Post_Exit': [
      'description': 'More - Enable_Post_Exit',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable_Pre_Exit': [
      'description': 'More - Enable_Pre_Exit',
      'type': 'boolean',
      'mandatory': true
    ],
	'EnableMultiCompany': [
      'description': 'More - EnableMultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorEmailNotification': [
      'description': 'More - ErrorEmailNotification',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorLogAttachments': [
      'description': 'More - ErrorLogAttachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Post-exit integration flow endpoint': [
      'description': 'Receiver: Post-exit - Post-exit integration flow endpoint',
      'mandatoryif': [ 'Enable_Post_Exit'],
      'default' : '/'
    ],
    'Pre-exit integration flow endpoint': [
      'description': 'Receiver: Pre-exit - Pre-exit integration flow endpoint',
      'mandatoryif': [ 'Enable_Pre_Exit'],
      'default' : '/'
    ],
    'Exception handling iflow endpoint': [
      'description': 'Receiver: Send_Email - Exception handling iflow endpoint path',
      'mandatoryif': [ 'ErrorEmailNotification'],
      'default' : '/'
    ],
    'CompanyID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'Company Name',
      'default': '<FSM_Company_ID>'
    ],
    'Company Name': [
      'description': 'More - FSM Company Name',
      'group': 'Name',
      'alternative' : 'CompanyID',
      'default': '<FSM_Company>'
    ],
    'AccountID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'Account Name',
      'default': '<FSM_Account_ID>'
    ],
    'Account Name': [
      'description': 'More - FSM Account Name',
      'group': 'Name',
      'alternative' : 'AccountID',
      'default': '<FSM_Account>'
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Item_Group - FSM Host without protocol',
      'mandatory': true,
      'default' : '<FSM_Host>'
    ],
    'DTO': [
      'description': 'Receiver: FSM_Create_Item_Group - ItemGroup DTO version',
      'mandatory': true
    ],
    'Credential Name': [
      'description': 'Receiver: FSM_Create_Item_Group - Credential Name',
      'mandatory': true,
	  'default': '<FSM_Credentials>'
    ],
	'ProductDescriptionLanguage': [
      'description': 'More: ProductDescriptionLanguage parameter',
      'mandatory': true      
    ]
  ],
  'Replicate_Item_Pricelist': [
    'Address': [
      'description' : 'Sender: S4Hana - Address',
      'mandatory': true
    ],
    'Authorization': [
        'description': 'Sender: S4Hana - Authorization',    
    ],
    'User_Role': [
      'description': 'Sender - User_Role',
      'mandatoryif': [ 'Authorization', 'User Role']	  
    ],
    'Issuer_DN': [
      'description': 'Sender: S4Hana - Issuer_DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Issuer_DN>'
    ],
    'Subject_DN': [
      'description': 'Sender: S4Hana - Subject_DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Subject_DN>'
    ],
    'Source Body Size': [
      'description': 'Sender - Source Body Size',
      'mandatory': true,
	  'type': 'number'
    ],
    'Enable Post-exit Material': [
      'description': 'More - Enable Post-exit Material',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable Post-exit Price List': [
      'description': 'More - Enable Post-exit Price List',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable Pre-exit Material': [
      'description': 'More - Enable Pre-exit Material',
      'type': 'boolean',
      'mandatory': true
    ],	
    'Enable Pre-exit Price List': [
      'description': 'More - Enable Pre-exit Price List',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable Pre-exit Price List Deletion': [
      'description': 'More - Enable Pre-exit Price List',
      'type': 'boolean',
      'mandatory': true
    ],
	'Enable pre-exit MultiCompany': [
      'description': 'More - Enable pre-exit MultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
	'EnableMultiCompanyReplication': [
      'description': 'More - EnableMultiCompanyReplication',
      'type': 'boolean',
      'mandatory': true
    ],
	'Error Email Notification': [
      'description': 'More - Error Email Notification',
      'type': 'boolean',
      'mandatory': true
    ],
	'Error Log Attachments': [
      'description': 'More - Error Log Attachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Post-exit integration flow endpoint for Material': [
      'description': 'Receiver: Post-exit_Material - Post-exit integration flow endpoint for Material',
      'mandatoryif': [ 'Enable Post-exit Material'],
      'default' : '/'
    ],
    'Post-exit integration flow endpoint for PriceList': [
      'description': 'Receiver: Post-exit_Price_List - Post-exit integration flow endpoint for PriceList',
      'mandatoryif': [ 'Enable Post-exit Price List'],
      'default' : '/'
    ],
    'Pre-exit integration flow endpoint for Material': [
      'description': 'Receiver: Pre-exit_Material - Pre-exit integration flow endpoint for Material',
      'mandatoryif': [ 'Enable Pre-exit Material'],
      'default' : '/'
    ],
    'Pre-exit integration flow endpoint for MultiCompany': [
      'description': 'Receiver: Pre-exit_Price_MultiCompany - Pre-exit integration flow endpoint for MultiCompany path',
      'mandatoryif': [ 'Enable pre-exit MultiCompany'],
      'default' : '/'
    ],
    'Pre-exit integration flow endpoint for PriceList': [
      'description': 'Receiver: Pre-exit_Price_List_Creation - Pre-exit integration flow endpoint for PriceList path',
      'mandatoryif': [ 'Enable Pre-exit Price List'],
      'default' : '/'
    ],
    'Pre-exit integration flow endpoint for PriceList Deletion': [
      'description': 'Receiver: Pre-exit_Price_List_Deletion - Pre-exit integration flow endpoint for PriceList Deletion path',
      'mandatoryif': [ 'Enable Pre-exit Price List Deletion'],
      'default' : '/'
    ],
    'Exception integration flow endpoint': [
      'description': 'Receiver: Send_Email - Exception integration flow endpoint',
      'mandatoryif': [ 'Error Email Notification'],
      'default' : '/'
    ],
    'ClientID': [
      'description': 'More - S4HANA ClientID',
      'mandatory': true,
	  'default': '<ClientID>'
    ],
	'CustomCompanyFilterQueryGroupSize': [
      'description': 'More - CustomCompanyFilterQueryGroupSize',
      'mandatory': true,
	  'type': 'number'
    ],
	'ConditionType': [
      'description': 'More - ConditionType',
      'mandatory': true
    ],
    'CompanyID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'Company',
      'default': '<FSM_Company_ID>'
    ],
    'Company': [
      'description': 'More - FSM Company Name',
      'group': 'Name',
      'alternative' : 'CompanyID',
      'default': '<FSM_Company>'
    ],
    'AccountID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'Account',
      'default': '<FSM_Account_ID>'
    ],
    'Account': [
      'description': 'More - FSM Account Name',
      'group': 'Name',
      'alternative' : 'AccountID',
      'default': '<FSM_Account>'
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Price_List - FSM Host without protocol',
      'mandatory': true,
      'default' : '<FSM_Host>'
    ],
    'PriceListDTO': [
      'description': 'Receiver: FSM_Create_Price_List - PriceList PriceListDTO version',
      'mandatory': true
    ],
    'Credential Name': [
      'description': 'Receiver: FSM_Create_Price_List - Credential Name',
      'mandatory': true,
	  'default': '<FSM_Credentials>'
    ],
    'HTTP_Timeout': [
      'description': 'Receiver: FSM_Create_Price_List - HTTP_Timeout in min',
      'mandatory': true
    ],	
    'S4HANA Host': [
      'description': 'Receiver: S4HANACustomCompany - S4HANA Host',
      'mandatory': true,
	  'default': 'S4HANA_Host:Port'
    ],
    'S4HANA AuthenticationType': [
      'description': 'Receiver: S4HANACustomCompany - S4HANA Authentication',
      'mandatory': true
    ],
    'S4HANA Credentials': [
      'description': 'Receiver: S4HANACustomCompany - S4HANA_CredentialName',
      'mandatoryif': [ 'S4HANA AuthenticationType', 'Basic'],
	  'default': '<S4HANA Credential Name>'
    ],
	'ProxyType': [
        'description': 'Receiver: S4HANACustomCompany - ProxyType',
    ],
    'LocationID': [
      'description': 'Receiver: S4HANACustomCompany - LocationID',
      'mandatoryif': [ 'ProxyType', 'On-Premise'],
	  'default': '<LocationID>'
    ]
  ],
  'Replicate_Product_Stock_from_SAP_S4HANA_to_SAP_Field_Service_Management': [
    'Address': [
      'description' : 'Sender: S4Hana - Address',
      'mandatory': true
    ],
    'Authorization': [
        'description': 'Sender: S4Hana - Authorization',    
    ],
    'User Role': [
      'description': 'Sender - User Role',
      'mandatoryif': [ 'Authorization', 'User Role']	  
    ],
    'Issuer_DN': [
      'description': 'Sender: S4Hana - Issuer_DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Issuer_Distinguished_Name>'
    ],
    'Subject_DN': [
      'description': 'Sender: S4Hana - Subject_DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Subject_Distinguished_Name>'
    ],
    'Enable_Post_Exit1': [
      'description': 'More - Enable_Post_Exit1',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable_Post_Exit2': [
      'description': 'More - Enable_Post_Exit2',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable_Pre-Exit': [
      'description': 'More - Enable_Pre-Exit',
      'type': 'boolean',
      'mandatory': true
    ],	
	'Enable_MultiCompany_Pre-Exit': [
      'description': 'More - Enable_MultiCompany_Pre-Exit',
      'type': 'boolean',
      'mandatory': true
    ],
	'EnableMultiCompany': [
      'description': 'More - EnableMultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorEmailNotification': [
      'description': 'More - ErrorEmailNotification',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorLogAttachments': [
      'description': 'More - ErrorLogAttachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Post_Exit_Integration_Flow_1': [
      'description': 'Receiver: Post-Exit_Item_Warehouse - Post_Exit_Integration_Flow_1',
      'mandatoryif': [ 'Enable_Post_Exit1'],
      'default' : '/'
    ],
    'Post_Exit_Integration_Flow_2': [
      'description': 'Receiver: Post-Exit_Item_Warehouse_Level - Post_Exit_Integration_Flow_2',
      'mandatoryif': [ 'Enable_Post_Exit2'],
      'default' : '/'
    ],
    'Pre_Exit_Integration_Flow': [
      'description': 'Receiver: Pre-Exit_Item_Warehouse - Pre_Exit_Integration_Flow',
      'mandatoryif': [ 'Enable_Pre-Exit'],
      'default' : '/'
    ],
    'Pre_Exit_CustomMultiCompanyPath': [
      'description': 'Receiver: Pre-exit_Price_MultiCompany - Pre_Exit_CustomMultiCompanyPath path',
      'mandatoryif': [ 'Enable_MultiCompany_Pre-Exit'],
      'default' : '/'
    ],
    'Address_To_Forward_Exception_Payload': [
      'description': 'Receiver: Send_Email - Address_To_Forward_Exception_Payload',
      'mandatoryif': [ 'ErrorEmailNotification'],
      'default' : '/'
    ],
	'Warehouse_Delimiter':[
      'description': 'More - S4HANA ClientID',
      'mandatory': true
	],
	'Warehouse_Delimiter_Name':[
      'description': 'More - S4HANA ClientID',
      'mandatory': true
	],
    'ClientID': [
      'description': 'More - S4HANA ClientID',
      'mandatory': true,
	  'default': '<ClientID>'
    ],
	'CustomCompanyFilterQueryGroupSize': [
      'description': 'More - CustomCompanyFilterQueryGroupSize',
      'mandatory': true,
	  'type': 'number'
    ],
	'DelayMilliSeconds': [
      'description': 'More - DelayMilliSeconds',
      'mandatory': true,
	  'type': 'number'
    ],
    'CompanyID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Company',
      'default': '<FSM_Company_ID>'
    ],
    'FSM Company': [
      'description': 'More - FSM Company Name',
      'group': 'Name',
      'alternative' : 'CompanyID',
      'default': '<FSM_Company>'
    ],
    'AccountID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'alternative' : 'FSM Account',
      'default': '<FSM_Account_ID>'
    ],
    'FSM Account': [
      'description': 'More - FSM Account Name',
      'group': 'Name',
      'alternative' : 'AccountID',
      'default': '<FSM_Account>'
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Update_Warehouse - FSM Host without protocol',
      'mandatory': true,
      'default' : '<FSM_Host>'
    ],
    'Warehouse DTO': [
      'description': 'Receiver: FSM_Create_Update_Warehouse - Warehouse DTO version',
      'mandatory': true
    ],
    'Credential Name': [
      'description': 'Receiver: FSM_Create_Update_Warehouse - Credential Name',
      'mandatory': true,
	  'default': '<FSM_Credentials>'
    ],
    'FSM Timeout': [
      'description': 'Receiver: FSM_Create_Update_Warehouse - FSM Timeout in ms',
      'mandatory': true,
	  'type': 'number'
    ],	
    'S4HANA Host': [
      'description': 'Receiver: S4HANACustomCompany - S4HANA Host',
      'mandatory': true,
	  'default': 'S4HANA_Host:Port'
    ],
    'S4HANA AuthenticationType': [
      'description': 'Receiver: S4HANACustomCompany - S4HANA Authentication',
      'mandatory': true
    ],
    'S4HANA Credentials': [
      'description': 'Receiver: S4HANACustomCompany - S4HANA_CredentialName',
      'mandatoryif': [ 'S4HANA AuthenticationType', 'Basic'],
	  'default': 'S4HANA_Credentials'
    ],
	'S4HANA_ProxyType': [
        'description': 'Receiver: S4HANACustomCompany - S4HANA_ProxyType',
    ],
    'S4HANA Timeout': [
      'description': 'Receiver: S4HANACustomCompany - S4HANA Timeout in ms',
      'mandatory': true,
	  'type': 'number'
    ],
    'LocationID': [
      'description': 'Receiver: S4HANACustomCompany - LocationID',
      'mandatoryif': [ 'S4HANA_ProxyType', 'On-Premise'],
	  'default': '<locationID>'
    ]
  ],
  'Replicate_Products_from_SAP_S4HANA_to_SAP_Field_Service_Management': [
    'Address': [
      'description' : 'Sender: S4Hana - Address',
      'mandatory': true
    ],
    'Authorization': [
        'description': 'Sender: S4Hana - Authorization',    
    ],
    'User_Role': [
      'description': 'Sender - User_Role',
      'mandatoryif': [ 'Authorization', 'User Role']	  
    ],
    'Issuer_DN': [
      'description': 'Sender: S4Hana - Issuer_DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Issuer_Distinguished_Name>'
    ],
    'Subject_DN': [
      'description': 'Sender: S4Hana - Subject_DN',
      'mandatoryif': [ 'Authorization', 'Client Certificate'],
      'default' : '<Subject_Distinguished_Name>'
    ],
	'Source Body Size':[
      'description': 'Sender: S4Hana - Source Body Size',
      'mandatory': true,
      'type': 'number'
    ],
    'Enable post-exit': [
      'description': 'More - Enable post-exit	',
      'type': 'boolean',
      'mandatory': true
    ],
    'Enable pre-exit': [
      'description': 'More - Enable pre-exit',
      'type': 'boolean',
      'mandatory': true
    ],
	'Enable-pre-exit-MultiCompany': [
      'description': 'More - Enable-pre-exit-MultiCompany',
      'type': 'boolean',
      'mandatory': true
    ],
	'EnableMultiCompanyReplication': [
      'description': 'More - EnableMultiCompanyReplication',
      'type': 'boolean',
      'mandatory': true
    ],
	'EnableOrgAssignment': [
      'description': 'More - EnableOrgAssignment',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorEmailNotification': [
      'description': 'More - ErrorEmailNotification',
      'type': 'boolean',
      'mandatory': true
    ],
	'ErrorLogAttachments': [
      'description': 'More - ErrorLogAttachments',
      'type': 'boolean',
      'mandatory': true
    ],
    'Post-ext integration flow endpoint': [
      'description': 'Receiver: Post-exit- Post-ext integration flow endpoint',
      'mandatoryif': [ 'Enable post-exit'],
      'default' : '/'
    ],
    'Pre-ext integration flow endpoint': [
      'description': 'Receiver: Pre-exit - Pre-ext integration flow endpoint',
      'mandatoryif': [ 'Enable pre-exit'],
      'default' : '/'
    ],
    'MultiCompany_Pre_Exit': [
      'description': 'Receiver: Pre-exit-MultiCompany - MultiCompany_Pre_Exit Path',
      'mandatoryif': [ 'Enable-pre-exit-MultiCompany'],
      'default' : '/'
    ],
    'Exception integration flow endpoint': [
      'description': 'Receiver: Send_Email - Exception integration flow endpoint path',
      'mandatoryif': [ 'ErrorEmailNotification'],
      'default' : '/'
    ],
    'sap-client': [
      'description': 'More - S4HANA Client Id',
      'mandatory': true,
	  'default': '<clientID>'
    ],
	'CustomCompanyFilterQueryGroupSize': [
      'description': 'More - CustomCompanyFilterQueryGroupSize',
      'mandatory': true,
	  'type': 'number'
    ],
	'FilterQuerySplitterGrouping': [
      'description': 'More - FilterQuerySplitterGrouping',
      'mandatory': true,
	  'type': 'number'
    ],
	'Remarks Type Code': [
      'description': 'More - Remarks Type Code',
      'mandatory': true
    ],
	'ProductDescriptionLanguage': [
      'description': 'More - ProductDescriptionLanguage',
      'mandatory': true
    ],
    'Company ID': [
      'description': 'More - FSM Company ID',
      'group': 'ID',
      'type': 'number',
      'default': '<FSM_Company_ID>'
    ],
    'Account ID': [
      'description': 'More - FSM Account ID',
      'group': 'ID',
      'type': 'number',
      'default': '<FSM_Account_ID>'
    ],
    'FSM Host': [
      'description': 'Receiver: FSM_Create_Product - FSM Host without protocol',
      'mandatory': true,
      'default' : '<FSM_Host>'
    ],
    'ItemDTO': [
      'description': 'Receiver: FSM_Create_Product - Item ItemDTO version',
      'mandatory': true
    ],
    'Credential Name': [
      'description': 'Receiver: FSM_Create_Product - Credential Name',
      'mandatory': true,
	  'default': '<FSM_Credential>'
    ],
    'FSM_Timeout': [
      'description': 'Receiver: FSM_Create_Product - FSM_Timeout in ms',
      'mandatory': true
    ],	
    'S4HANAHost': [
      'description': 'Receiver: S4HANA_OrgLevel - S4HANAHost',
      'mandatory': true,
	  'default': 'http://<S4HANA_Host:Port>'
    ],
    'ODataAuthentication': [
      'description': 'Receiver: S4HANA_OrgLevel - S4HANA Authentication',
      'mandatory': true
    ],
    'S4HANA Credentials': [
      'description': 'Receiver: S4HANA_OrgLevel - S4HANA Credentials',
      'mandatoryif': [ 'ODataAuthentication', 'Basic'],
	  'default': '<S4HANA_Credentials>'
    ],
	'S4HANA Timeout':[
      'description': 'Receiver: S4HANA_OrgLevel - S4HANA Timeout',
      'mandatory': true,
	  'type': 'number'
    ],
	'Proxy Type': [
        'description': 'Receiver: S4HANA_OrgLevel - Proxy Type',
    ],
    'S4HANA Location ID': [
      'description': 'Receiver: S4HANA_OrgLevel - S4HANA Location ID',
      'mandatoryif': [ 'Proxy Type', 'On-Premise'],
	  'default': '<LocationID>'
    ]
  ]




]

    message.setProperty('PackageParameterChecks', package_parameter_checks)
    return message
}