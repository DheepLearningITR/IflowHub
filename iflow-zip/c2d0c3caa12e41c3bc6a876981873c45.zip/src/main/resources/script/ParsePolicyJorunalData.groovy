import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;
import static java.util.UUID.randomUUID

/*
This script will reduce the result of FS-PM Jouranl Read 
It will also call the value mapping for certain attributes, if needed.
*/
def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);
    
    //parse the incoming XML into an object
	def rfcSet = new XmlSlurper().parseText(body);

    // Get CPI-Session Properties
    def properties = message.getProperties()
    applicationKey = properties.get("com.sap.insurance.xm.application_key")
    bizProcess = properties.get("com.sap.insurance.xm.biz_process")
    endorsement_tt = properties.get("com.sap.insurance.xm.endorsement_tt")
    cancellation_tt = properties.get("com.sap.insurance.xm.cancellation_tt")
    reneawl_tt =  properties.get("com.sap.insurance.xm.renewal_tt")
    reneawlprolong_proc_id =  properties.get("com.sap.insurance.xm.renewalprolong_proc_id")
    prolong_proc_id =  properties.get("com.sap.insurance.xm.prolong_proc_id")
    contract_cancel_proc_id = properties.get("com.sap.insurance.xm.contract_cancel_proc_id") //Use standard default -  A_PT_EXREVERSPPD_CF
    policy_cancel_proc_id = properties.get("com.sap.insurance.xm.policy_cancel_proc_id") //Use standard default -  A_CANCELFLAG
      
    //Create new temp XML Body
    def stringPolicyJournalSet = '<PolicyJournal></PolicyJournal>'
    def PolicyJournalSet = new XmlParser().parseText(stringPolicyJournalSet)

    def InPolicyJournal = rfcSet.breadthFirst().find { node-> node.name() == 'ET_POLICY_JOURNAL' }
  
  
  // For response, Consider only the Note relevant business Transaction 
  //and A_PT_EXREVERSPPD_CF this is to cater Delete contract scenario from Reversal Business process
    InPolicyJournal.item.each{ Journal ->
    if ( Journal.APPLICATION_ID.text() == applicationKey && Journal.REDO_FG.text() == '' ) { 
        if ( ( Journal.NOTEREQ_FG.text() == 'X' && Journal.BTX_ID.text() != '' ) || Journal.PROC_ID.text() == contract_cancel_proc_id ) {   
          def JournalSetitem = PolicyJournalSet.appendNode(new QName('item') )
          JournalSetitem.appendNode(new QName('Transaction'), Journal.PROCESSING_TT.text()  )
    }  } } 
    
  
    def isPolicyCancellation 
    def isPolicyRenewal
    //Determine application transaction type
    InPolicyJournal.item.each{ Journal ->
        if ( Journal.APPLICATION_ID.text() == applicationKey && Journal.REDO_FG.text() == ''  ){
         if (  bizProcess == 'C'  &&  Journal.PROC_ID.text() == policy_cancel_proc_id ) { 
             message.setProperty("com.sap.insurance.xm.transaction_type" , cancellation_tt )  
             isPolicyCancellation = 'X'
          }
         // Auto Renewal & manual renewal
          if( Journal.PROC_ID.text() == prolong_proc_id || Journal.PROC_ID.text() == reneawlprolong_proc_id ){  
            message.setProperty("com.sap.insurance.xm.transaction_type" , reneawl_tt ) 
            isPolicyRenewal = 'X'
          }
        
        }
    }
    
    if ( bizProcess != 'N' && bizProcess != 'C' && isPolicyRenewal != 'X' ){
       message.setProperty("com.sap.insurance.xm.transaction_type" , endorsement_tt ) 
    }
    
    //Contract Deletion  - Reversal business process
    if (  isPolicyCancellation != 'X' &&  bizProcess == 'C'  ) {
       message.setProperty("com.sap.insurance.xm.transaction_type" , endorsement_tt )  
       
    }
    

  //  def unique=[]
    //PolicyJournalSet.item.each {
    //if(unique.contains(it)){
    
    //}
    //else{
    //    unique.add(it)
    //} }


    //Set PolicyJournalSet as messageBody
    message.setBody(XmlUtil.serialize(PolicyJournalSet))
    //message.setBody(unique)
    return message;
}
      
