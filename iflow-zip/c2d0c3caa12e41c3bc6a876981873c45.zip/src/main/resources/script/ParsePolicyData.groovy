import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;
import static java.util.UUID.randomUUID

/*
This script will reduce the result of FS-PM Read Policy Call
It will also call the value mapping for certain attributes, if needed.
*/
def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);
    
    //parse the incoming XML into an object
	def rfcSet = new XmlSlurper().parseText(body);

    // Get CPI-Session Properties
    def properties = message.getProperties()
    bizProcess = properties.get("com.sap.insurance.xm.biz_process")
   
    //Create new temp XML Body
    def stringInsurancePolicySet = '<Policy></Policy>'
    def insurancePolicySet = new XmlParser().parseText(stringInsurancePolicySet)


    def InPolicy      = rfcSet.breadthFirst().find { node-> node.name() == 'ES_POLICY' }
        insurancePolicySet.appendNode(new QName('PolicyNumber'),  InPolicy.POLICYNR_TT.text( ))
        insurancePolicySet.appendNode(new QName('ProductName'),  InPolicy.SALESPROD_TT.text( ))
        insurancePolicySet.appendNode(new QName('SalesChannel'),  InPolicy.SALECH_TT.text( ))
        insurancePolicySet.appendNode(new QName('PolicyBeginDate'),  InPolicy.POLBEG_DT.text( ))
        insurancePolicySet.appendNode(new QName('PolicyEndDate'),  InPolicy.POLEND_DT.text( ))
        insurancePolicySet.appendNode(new QName('CompanyName'),  InPolicy.FULLNAME_TT.text( ))
        insurancePolicySet.appendNode(new QName('PreviousPolicy'), InPolicy.POLICYNRPRDCSSR_TT.text( ))
// Cater for new renewal process - To be used to determine the Transaction type for the application
   //if ( bizProcess == 'N' && InPolicy.POLICYNRPRDCSSR_TT.text( ) != '' ) {
   //      message.setProperty("com.sap.insurance.xm.isRenewal" , 'X' ) 
 //   } 
        
    // Add main policyholder
    def InPolicyHolder   = rfcSet.breadthFirst().find { node-> node.name() == 'ET_POLHLDR' }
    
	InPolicyHolder.item.each{ policyHolder ->
        if (policyHolder.MAINPOLHLDR_FG.text() == 'X'){
            insurancePolicySet.appendNode(new QName('PolicyHolder'), policyHolder.PARTNERNAME_TT.text()  )
            insurancePolicySet.appendNode(new QName('PolicyHolderType'), policyHolder.PARTNERTYPE_TT.text()  )
        }
    }  
   
    //Add active contracts    
    def InContract = rfcSet.breadthFirst().find { node-> node.name() == 'ET_POLPR' }
    def ContractSet = insurancePolicySet.appendNode(new QName('ActiveContracts') )
    
	InContract.item.each{ Contract ->
	if (  Contract.ACTINACTST_CD.text() == '001' ) {
    def ContractSetitem = ContractSet.appendNode(new QName('item') )
    ContractSetitem.appendNode(new QName('ContractName'), Contract.PRODUCT_TT.text() )
    ContractSetitem.appendNode(new QName('ContractNumber'), Contract.APPLNR_TT.text()  )
    ContractSetitem.appendNode(new QName('ContractBeginDate'), Contract.POLPRODBEG_DT.text()  )
    ContractSetitem.appendNode(new QName('ContractEndDate'), Contract.POLPRODEND_DT.text()  )
    } }
    
    
     //Set InsurancePolicySet as messageBody
    message.setBody(XmlUtil.serialize(insurancePolicySet))

    return message;
    
}
      
