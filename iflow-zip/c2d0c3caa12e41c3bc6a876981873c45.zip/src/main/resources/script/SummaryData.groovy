import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;
import static java.util.UUID.randomUUID


/*
This script will add derived fields to the Response and also streamline the XML tag by removing the MULTIMAP tag (added due to Join-Gather node in iflow) 
*/
def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);
    
    //parse the incoming XML into an object
    def rfcSet = new XmlSlurper().parseText(body);
 

    // Get CPI-Session Properties
    def properties = message.getProperties()
    bizProcess = properties.get("com.sap.insurance.xm.biz_process")
    transacation_Type = properties.get("com.sap.insurance.xm.transaction_type")
    nb_tt = properties.get("com.sap.insurance.xm.newbusiness_tt")
    renewal_tt = properties.get("com.sap.insurance.xm.renewal_tt")
  
    // property from Policy Read groovy script
   // isRenewal = properties.get("com.sap.insurance.xm.isRenewal")

    
    //streamline the XML Tags
    def ClaimNode = rfcSet.'**'.find{it.name() == 'Claim'}
    def PolicyNode = rfcSet.'**'.find{it.name() == 'Policy'}
    def PolicyJournalNode = rfcSet.'**'.find{it.name() == 'PolicyJournal'}   
    PolicyJournalNode.collect{ PolicyNode.appendNode(it)}
    ClaimNode.collect{ PolicyNode.appendNode(it)}

    // Determine if it is Renewal process via New business
    //otherwise use the same as derived under Journal read script
    //if ( isRenewal == 'X' && bizProcess == 'N'   ){
    if ( PolicyNode.PreviousPolicy != '' && bizProcess == 'N'   ){
        transacation_Type = renewal_tt // 'RNW'
    }
    else if ( bizProcess == 'N' ){
      transacation_Type =  nb_tt //'NB' 
    }
    
    //Add the Transaction type tag
    def trans_type = "<TransactionType>"+transacation_Type+"</TransactionType>"
    def transNode = new XmlSlurper().parseText( trans_type )     
    PolicyNode.appendNode( transNode )


   //Set Final response PolicyNode  as messageBody
    message.setBody(XmlUtil.serialize(PolicyNode))
    return message;
   
}
      
