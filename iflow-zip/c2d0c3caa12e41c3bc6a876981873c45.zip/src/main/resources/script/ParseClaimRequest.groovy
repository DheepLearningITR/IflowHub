import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;
import static java.util.UUID.randomUUID

/*
This script will read the active contract node to get the Cliam information 
*/
def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);
    
    //parse the incoming XML into an object
	def rfcSet = new XmlSlurper().parseText(body);

    // Get CPI-Session Properties
    def properties = message.getProperties()
   
    //Create new temp XML Body
    def stringPolprSet = '<IT_POLPR_NR></IT_POLPR_NR>'
    def PolprSet = new XmlParser().parseText(stringPolprSet)

    //Read active contract node
    def InPolprSet = rfcSet.breadthFirst().find { node-> node.name() == 'ActiveContracts' }
    InPolprSet.item.each{ Contract ->
    def PolprSetitem = PolprSet.appendNode(new QName('item') )
    PolprSetitem.appendNode(new QName('APPLNR_TT'), Contract.ContractNumber.text()  )
    }
    
       //Set PolprSet as messageBody
    message.setBody(XmlUtil.serialize(PolprSet))
    return message;
    
}
      
