import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;
import static java.util.UUID.randomUUID

/*
This script will reduce the result of Claim data
It will also call the value mapping for certain attributes, if needed.
*/
def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);
    
    //parse the incoming XML into an object
	def rfcSet = new XmlSlurper().parseText(body);

    // Get CPI-Session Properties
  //  def properties = message.getProperties()
   
    //Create new temp XML Body
    def stringClaimSet = '<Claim></Claim>'
    def ClaimSet = new XmlParser().parseText(stringClaimSet)
    OpenClaimCount = 0

    def InClaim = rfcSet.breadthFirst().find { node-> node.name() == 'ET_CLAIMINFO' }

        InClaim.item.each{ Claim ->
        def ClaimSetitem = ClaimSet.appendNode(new QName('item') )
    	ClaimSetitem.appendNode(new QName('ClaimNumber'), Claim.CLAIMNUMBER_VL.text()  )
        ClaimSetitem.appendNode(new QName('LossDate'), Claim.LOSSDATE_DT.text()  )
    	ClaimSetitem.appendNode(new QName('LossType'), Claim.LOSSTYPE_TT.text()  )
        ClaimSetitem.appendNode(new QName('ClaimStatus'), Claim.CLSTATUS_TT.text()  )
    	ClaimSetitem.appendNode(new QName('isClaimOpen'), Claim.CLAIMOPEN_TT.text()  )
    	ClaimSetitem.appendNode(new QName('ContractNumber'), Claim.POLPR_NR.text()  )	
        	if ( Claim.CLAIMOPEN_TT.text() == 'X' ){
        	    OpenClaimCount = OpenClaimCount + 1
        	}
    	
        }
    	    
    	//message.setProperty("com.sap.insurance.xm.ActiveClaimCount" , OpenClaimCount ) 
        
         //Add the Active claim count type tag
        ClaimSet.appendNode( new QName('OpenClaimsCount'), OpenClaimCount )


        
           //Set InsurancePolicySet as messageBody
        message.setBody(XmlUtil.serialize(ClaimSet))

        return message;

}
      
