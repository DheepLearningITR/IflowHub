import com.sap.gateway.ip.core.customdev.util.Message
import javax.activation.DataHandler
import javax.mail.internet.ContentType
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMultipart
import javax.mail.util.ByteArrayDataSource
import java.nio.charset.StandardCharsets
import java.util.Base64;
import java.net.URL;
import java.net.URLConnection;

def Message postZipContentToAriba(Message message){
    
   
    // Prepare URL to connect
    def messageLog = messageLogFactory.getMessageLog(message)
    def propertiesMap = message.getProperties()
    def headersMap = message.getHeaders()
    
    String aribaAddress = propertiesMap.get("aribaAddress")
    String queryParameters = propertiesMap.get("queryParameters")
    
    // We prepare a URLConnection 
    URL url = new URL(aribaAddress + "?" + queryParameters);
    URLConnection urlConnection = url.openConnection();
   
    // POST
    def zipContent = message.getBody(byte[])
    urlConnection.setRequestMethod("POST")
    urlConnection.setDoOutput(true)
    urlConnection.setRequestProperty("Content-Type", headersMap.get("Content-Type") as String)
    urlConnection.getOutputStream().write(zipContent);
    
    def postRC = urlConnection.getResponseCode();
    if(postRC.equals(200)) {
        messageLog.addAttachmentAsString("Post result:", urlConnection.getInputStream().getText() as String, "text/plain")
    }else{
        def exceptionMsg = "HTTP" + postRC.toString() + ", " + urlConnection.getInputStream().getText()
        throw new Exception(exceptionMsg as String)
    }
    
    return message
}


Message processData(Message message) {


    return postZipContentToAriba(message)
}