import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.IOException;
import java.util.Arrays;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import org.apache.camel.impl.DefaultAttachment;
import javax.mail.util.ByteArrayDataSource;

def Message processData(Message message) {
	//Read the filename and attachment name
	def FileName = message.getProperties().get("FileName");
	def Attachment = message.getProperties().get("Attachment");

    def dataSource = new ByteArrayDataSource(message.getBody(byte[]),'application/zip') //  Construct a DefaultAttachment object
    def attachment = new DefaultAttachment(dataSource) //    Add the attachment to the message
    message.addAttachmentObject(Attachment, attachment) // give zipfile name as per naming convention
    return message;
}