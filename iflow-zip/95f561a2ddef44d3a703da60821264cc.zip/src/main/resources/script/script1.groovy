import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.*;
import java.util.Map.Entry;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.spi.ITApiHandler;
import com.sap.xi.mapping.camel.valmap.VMStore;
import com.sap.xi.mapping.camel.valmap.VMValidationException;
import com.sap.xi.mapping.camel.valmap.ValueMappingApiHandler;
import com.sap.it.api.exception.InvalidContextException;

def Message processData(Message message) {
	
	
	def map = message.getHeaders();
	def messageLog = messageLogFactory.getMessageLog(message);
	
	String postURL=null;
	def aribaAddress;
	def datacenterin = map.get("datacenter");
	
	
	 try{  
	
            def service = ITApiFactory.getApi(ValueMappingApi.class, null);
      
            if( service != null)
            {
             if (datacenterin == 'an'|| datacenterin == 'us'|| datacenterin == 'eu'||datacenterin == 'us3'||datacenterin == 'au'||datacenterin == 'cn'||datacenterin == 'jp'||datacenterin == 'ru'){
			 aribaAddress = service.getMappedValue("Input", "datacenterin", datacenterin, "Output", "datacenter");
		
			 }
			 else {
			 aribaAddress = service.getMappedValue("Input", "datacenterin", "other", "Output", "datacenter");
			
			 }
	   		}
      		
      		postURL = aribaAddress;
      		
      		
      }
      catch(Exception e)
      {
        messageLog.setStringProperty("Exception",e.toString())
        return null;
      }
      
      message.setHeader("postURL",postURL);

	 //addCustomHeader(message,"postURL",postURL);
     
            
	return message;
}

