import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*
    
    def Message processData(Message message) {
        def jsonBody = message.getBody(String)
        def jsonSlurper = new JsonSlurper()
        def parsedJson = jsonSlurper.parseText(jsonBody)
        
        parsedJson.data.each{
            def reqData = it 
            if(reqData.equipments){
                if (reqData.equipments.equipment instanceof List) {
                    reqData.equipments = reqData.equipments.equipment
                }
            }
    
            
        }
        def prettyJson = JsonOutput.prettyPrint(JsonOutput.toJson(parsedJson))
        message.setBody(prettyJson)
        return message;
    }
    