import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.util.XmlParser;

def Message processData(Message message){
    
    //parsing the data 
    def QueryResponse = new JsonSlurper().parseText(message.getBody(String.class));
    def InputStreamPayload = new ByteArrayInputStream(message.getProperty("P_OriginalPayload"))
	def Payload_root = new XmlParser().parse(InputStreamPayload);
	def rec_party = Payload_root.MessageHeader.RecipientParty.InternalID.text()
	StringWriter stringWriter = new StringWriter()
    XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
    nodePrinter.setPreserveWhitespace(true)
        
	def each_id,XML_Node
	Node Ref2_Node
	
	if (QueryResponse.data != [] ){
	    //mapping id with the code 
	    def FSM_ID_Map = [:]
	    QueryResponse.data.each{
        	FSM_ID_Map.put(it.sc.externalId,it.sc.code);
    	}
	
        //creating a bTDReference node for the service tickets
	    Payload_root.ServiceRequestReplicationRequestMessage.ServiceRequest.each{
    		each_id=it.ID.text()
    		if(FSM_ID_Map.keySet().contains(each_id)){
    		    
    		    //creating a node containing external id of the FSM service call 
        		Node Ref_Node= new NodeBuilder().BTDReference{
               			BusinessTransactionDocumentRelationshipRoleCode("6")
               			BusinessSystemID(rec_party)
               			BTDReference{
                   			ID(FSM_ID_Map[each_id])
                   			TypeCode("118")
               			}
            		};
        		
        		//creating the btdreference node where there is none in payload initially 
            	it.BTDReference[0].append(Ref_Node)

    		}
	    }
	}
    //updating payload and the body 
    nodePrinter.print(Payload_root)
    message.setBody(stringWriter.toString())
    def BytePayload = stringWriter.toString().getBytes('UTF-8')
    message.setProperty("P_OriginalPayload",BytePayload)
	
	return message;
}

