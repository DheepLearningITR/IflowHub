/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

// Below is the format in which business logic error is raised from FSM for bulk messages.
// def body ='{"hasErrors":true,"results":[{"status":404,"error":{"type":"error://resource-not-found","title":"Not Found","detail":"Resource [CONTACT] with externalId [1073050-1073374] was not found."}},{"status":404,"error":{"type":"error://resource-not-found","title":"Not Found","detail":"Resource [CONTACT] with externalId [1073050-1073374] was not found."}}]}';

def Message processData(Message message) {
     //Get Body and parse it.
       def body = message.getBody(String.class);
     //Input response body of bulk API from FSM is always an array, [{},{}]  
       def parsedObj = new JsonSlurper().parseText(body);
       def error_msg;
       
       if(parsedObj.hasErrors == true)
        {
            for(n in parsedObj.results)
            {
                if (!(n.status == 201 || n.status == 200)) // 201 is created, which is sent by FSM on success create/update , 200 for successfull delete
                {
                    if (error_msg == null)
                    {
                        error_msg = 'C4C ID ' + n.externalId + ':- ' + n.error.detail;
                    }
                    else
                    {
                        error_msg = error_msg + ' C4C ID ' + n.externalId + ':- ' + n.error.detail;
                    }
                }
            }
         
            if ( error_msg != null)
            {
                throw new Exception(error_msg);
            }
       
        }
        else
        {
            return message;
        }
    }