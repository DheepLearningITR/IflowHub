import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {

    def C4C_Activity_IDs = message.getProperty('C4C_Activity_IDs');
    ArrayList FSM_Activity_IDs = []
    def FSM_Activity_ID_Map = [:]
    def parsedObj = new JsonSlurper().parseText(message.getBody(String.class));
    def act_external_ID;
    
    //Form ArrayList of FSM Activity IDs retrived from FSM Query API
    parsedObj.data.each{
        act_external_ID=it.act.externalId;
        FSM_Activity_IDs.add(act_external_ID);
        FSM_Activity_ID_Map.put(act_external_ID,it.act.id);
    }
    //Find activity IDs which are in FSM but not present in C4C payload, so that they can be deleted.
	
    C4C_Activity_IDs.intersect(FSM_Activity_IDs).each{FSM_Activity_IDs.remove(it)}

    String Delete_JSON_str = "";
    //Form JSON string to send to FSM for deletion
    FSM_Activity_IDs.each{
        // to get id from externalid 
        def internal_id= FSM_Activity_ID_Map.get(it)
        if (Delete_JSON_str == ""){
            Delete_JSON_str = '{\"id\" : ' + '\"'+internal_id+'\"}]';
        }
        else
        {
            Delete_JSON_str = '{\"id\" : ' + '\"'+internal_id+'\"}, ' + Delete_JSON_str; 
        }
    }
    
    if (Delete_JSON_str == "")
    {
        message.setProperty('C4C_Activity_IDs','DELETE_NOTHING');
    }
    else
    {
        Delete_JSON_str = '[' + Delete_JSON_str;
    //Convert string to JSON
      //  def Delete_JSON = JsonOutput.toJson(Delete_JSON_str);
      // def msg_body = JsonOutput.prettyPrint(Delete_JSON);
        message.setBody(Delete_JSON_str);
    }

    return message;
}