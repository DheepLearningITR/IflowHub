import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;


def Message processData(Message message) {
    def parsedObj = new XmlSlurper().parseText(message.getBody(String.class));
    String obj=""; 
       
    parsedObj.ServiceRequestReplicationRequestMessage.ServiceRequest.each{
        if(it.BTDReference.BTDReference.BusinessSystemID.isEmpty()){
            obj =obj+ "\'"+ it.ID.toString().trim() + "\',"
        }
    }
    obj= obj[0..-2]
    
    if(obj.length()){
        String finalQuery = "";
        String sc = "{\"query\": \"SELECT sc.id,sc.code FROM ServiceCall sc WHERE sc.externalId IN  (" ;
        finalQuery = sc + obj+ ")" +'\"}';
    }
    else{
        message.setProperty("BTDRef","NOTHING")
    }
    message.setBody(finalQuery);
       
    return message;
}