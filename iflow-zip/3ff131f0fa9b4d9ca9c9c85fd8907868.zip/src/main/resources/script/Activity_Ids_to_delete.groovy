import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
//Dictionary class 
class Dictionary
{
    def key
    def value
    def mainkey
    def dict = [:]
    Dictionary() {}
    Dictionary(key){
        get(key)
    }
    Dictionary(key, value) {
      put2(key,value)
    }
    Dictionary(mainkey,key,value){
        put(mainkey,key,value)
    }
    def get(key){// method is used to get the value when given key as argument 
        try {
            if (this.dict[key]!=null)
                return this.dict[key];
            else
                println("error");
                return 0;
        } catch(Exception exception) {
            println "  #### ERROR #### --> " + exception.getMessage()
            println " "
        }
    }
    def validate(key, value)//validating few exceptions in a dictionary 
    {
        if(key==null)
            throw new RuntimeException("Null key is not permitted")
         
        if(value==null)
            throw new RuntimeException("Null value is not permitted")
    }
    def put2(key,value){//method to insert a key value pair in the dictionary 
        try{
            validate(key,value)
            this.dict[key]=value
        }
        catch(Exception exception){
            println(exception.getMessage())
        }
    }
    def put(key, value) {
        try {
            validate(key,value)
            if (this.dict[key]!=null){
                this.dict[key].add(value);
            }
            else{
                this.dict[key]=[]
                this.dict[key].add(value)
            }
        } catch(Exception exception) {
            println "  #### ERROR #### --> " + exception.getMessage()
            println " "
        }
    }
    
    String toString() {
        "${dict}"
    }
    
}
def Message processData(Message message) {

    def C4C_Activity_IDs = message.getProperty('C4C_Activity_IDs');
    def FSM_Activity_IDs = new Dictionary()
    def FSM_Activity_ID_Map = new Dictionary()
    def ID_map = new Dictionary()
    //parsing to get the data 
    def parsedObj = new JsonSlurper().parseText(message.getBody(String.class));
    def extra_act_externalID;
    def extra_act_ID;
    def extra_ticket_ID;
    def extra_ticket_external_ID;
    Set Ticket_IDs = []

    //getting parsed data and mapping them to dictionary 
    parsedObj.data.each{
        extra_act_externalID=it.act.externalId;
        extra_act_ID=it.act.id;
        extra_ticket_ID=it.act."object.objectId";
        extra_ticket_external_ID=it.sc.externalId;
        ID_map.put2(extra_ticket_ID,extra_ticket_external_ID);
        FSM_Activity_IDs.put(extra_ticket_ID,extra_act_externalID);
        FSM_Activity_ID_Map.put2(extra_act_externalID,extra_act_ID);
		Ticket_IDs.add(extra_ticket_ID);
    }

    //Find activity IDs which are in FSM but not present in C4C payload, so that they can be deleted.
	ArrayList Final_IDs=[]
	for (i=0;i<Ticket_IDs.size();i++){
        def extra_get_ID = ID_map.get(Ticket_IDs[0])
		def C4C_list=C4C_Activity_IDs.get(extra_get_ID);
		def FSM_list = FSM_Activity_IDs.get(Ticket_IDs[0]);
		if(C4C_list== null){
            Final_IDs=Final_IDs+FSM_list
        }
        else{
        C4C_list.intersect(FSM_list).each{FSM_list.remove(it)}
		Final_IDs= Final_IDs+FSM_list;
        }
	}

    //preparing string for the body of api query. 
    String Delete_JSON_str = "";
    //Form JSON string to send to FSM for deletion
    Final_IDs.each{
        // to get id from externalid 
        def internal_id= FSM_Activity_ID_Map.get(it)
        if (Delete_JSON_str == ""){
            Delete_JSON_str = '{\"id\" : ' + '\"'+internal_id+'\"}]';
        }
        else
        {
            Delete_JSON_str = '{\"id\" : ' + '\"'+internal_id+'\"}, ' + Delete_JSON_str; 
        }
    }
    
    if (Delete_JSON_str == "")
    {
        message.setProperty('C4C_Activity_IDs','DELETE_NOTHING');
    }
    else
    {
        Delete_JSON_str = '[' + Delete_JSON_str;
        message.setBody(Delete_JSON_str);
    }

    return message;
}