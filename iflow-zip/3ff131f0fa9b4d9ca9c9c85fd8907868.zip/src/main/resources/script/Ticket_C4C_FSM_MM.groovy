import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi


def Message processData(Message message) {
    def body = message.getBody(String.class);
    def root = new XmlParser().parseText(body);
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    
    def action, prob_type, team_role, sr;
    Node sc_data, sc_item, var_node
    
    def root_output = new NodeBuilder().Service_Requests{}
    boolean recon_ind = root?.MessageHeader?.ReconciliationIndicator?.text()?.equals("true") ? true : false
    
    root.ServiceRequestReplicationRequestMessage.each {
	sr = it.ServiceRequest
	action = sr.BTDReference.BTDReference.find({node -> node.BusinessSystemID.text().equals(root.MessageHeader.RecipientParty.text())}) == null ? 'CREATE' : 'UPDATE'

	if(sr[0].@ServiceSupportTeamIndicator.equals('true')) {
		team_role = "28"
	}else {
		team_role = "42"
	}
	var_node = sr.Party.find({node -> node.RoleCode.text().equals(team_role)})
	team_role = var_node == null ? null : var_node.PartyID.text()
    team_role = valueMapApi.getMappedValue('C4C', 'Service_technician_team', team_role, 'FSM', 'REGION')
    
	if(message.getProperty("serv_categ_val_map").toLowerCase().trim().equals('true')) {
		prob_type = valueMapApi.getMappedValue('C4C', 'Catalog#Version#CategoryID',
		sr.ServiceCategory.CatalogueID.text() + '#' + sr.ServiceCategory.VersionID.text() + '#' + sr.ServiceCategory.ID.text(),'FSM', 'Problem_Type')
		prob_type = prob_type == null ? "" : prob_type
	}else {
		prob_type = sr.ServiceTerms.ServiceCategoryText.text()
	}

	sc_data = new NodeBuilder().data(action: action){
		externalId(sr.ID.text())
		subject(sr.Name.text())
		origin(sr.ReceiverDataOriginTypeText.text())
		status(sr.ServiceTerms.ReceiverUserStatusText.text())
		priority(sr.ServiceTerms.ReceiverPriorityText.text())
		problemType(prob_type)
		type(sr.ReceiverProcessingTypeText.text())
		earliestStartDateTime(sr.TicketTimeline.RequestedStart.text())
		dueDateTime(sr.TicketTimeline.ResolutionDueDate.text())
		equipments()				//Filled below
		durationInMinutes(sr.TicketTimeline.Duration.text().equals("")? 0: Math.round(Math.floor(sr.TicketTimeline.Duration.text().toDouble())))
		resolution(sr.TextCollection.Text.find({node -> node.TypeCode.text().equals("10022")})?.ContentText?.text() ?: "")
		remarks(sr.TextCollection.Text.find({node -> node.TypeCode.text().equals("10004")})?.ContentText?.text() ?: "")
		address{
			building(sr.Location.BuildingID.text())
			city(sr.Location.CityName.text())
			country(sr.Location.CountryCode.text())
			floor(sr.Location.FloorID.text())
			room(sr.Location.RoomID.text())
			state(sr.Location.RegionCode.text())
			street(sr.Location.StreetName.text())
			streetNumber(sr.Location.HouseID.text())
			zipCode(sr.Location.StreetPostalCode.text())
		}

	}

	// Business Partner role code 1001 with Main indicator and that BP's main contact
	var_node = sr.Party.find({node -> node.RoleCode.text().equals('1001') && node.MainIndicator.text().equals('true')})
	if(var_node != null) {
		sc_data.append(new NodeBuilder().businessPartner{externalId(var_node.PartyID.text())})
		var_node = var_node.ContactParty.find({node -> node.MainIndicator.text().equals('true')})
		if(var_node.equals(null)) {
			sc_data.append(new NodeBuilder().contact{})
		}else {
			sc_data.append(new NodeBuilder().contact{externalId(var_node.PartyID.text() + '~ID-JOIN~' + sc_data.businessPartner[0].externalId.text())})
		}
	}

	// Responsible role code 40 with Main indicator
	var_node = sr.Party.find({node -> node.RoleCode.text().equals('40') && node.MainIndicator.text().equals('true')})
	if(var_node != null) {
		sc_data.append(new NodeBuilder().responsibles{externalId(var_node.PartyID.text())})
	}

    def equipmentMode = message.getProperty("equipmentMode")
    if(equipmentMode=="3"){
        //Replicate Main ipoint of RP or Func loc(if param is true)
    	var_node = sr.ServiceReferenceObjects.find({node -> node.MainIndicator.text().equals('true')})
    	if(var_node != null) {
    		if((var_node.InstallationPointTypeCode.text().equals('6')
    		&& message.getProperty("func_loc_enabled").toLowerCase().trim().equals('true')) ||
    		var_node.InstallationPointTypeCode.text().equals('2')) {
    			sc_data.equipments[0].append(new NodeBuilder().externalId(var_node.InstallationPointID.text()))
    		}
    	}
    }
    if(equipmentMode == "1"){
        //Replicate all equipments
        sr.ServiceReferenceObjects.each{object ->
            if((object.InstallationPointTypeCode.text().equals('6')
    		&& message.getProperty("func_loc_enabled").toLowerCase().trim().equals('true')) ||
    		object.InstallationPointTypeCode.text().equals('2')) {
    		    sc_data.equipments[0].append(new NodeBuilder().equipment{externalId(object.InstallationPointID.text())}
    		    )
    		}
        }
    }

	sr.TicketSkill.findAll({node -> node.SkillSource.text().equals('07') || node.SkillSource.text().equals('06')}).each{
		// 07-Manual, 06-IBase
		var_node = it
		sc_data.append(new NodeBuilder().requirements{
			mandatory(var_node?.Mandatory?.text())
			skill{
				externalId(var_node?.SkillID?.text())
			}
		})
	}
	//If RP skill is not determined then only check for Products' skills
	if(sr.TicketSkill.find({node -> node.SkillSource.text().equals('01')}) == null) {
		sr.TicketSkill.findAll({node -> node.SkillSource.text().equals('02')}).each{
			// 02-Product
			var_node = it
			sc_data.append(new NodeBuilder().requirements{
				mandatory(var_node.Mandatory.text())
				skill{
					externalId(var_node.SkillID.text())
				}
			})
		}
	}

	for(item in sr.Item) {
		if(item.FSMRelevanceCode.text().equals('1')) {
			sc_item = new NodeBuilder().activities(){
				externalId(item.UUID.text())
				subject(item.Description.text())
				remarks(item.ItemtextCollection.Text.find({node -> node.TypeCode.text().equals("10011")})?.ContentText?.text() ?: "")
			}

			var_node = item.ItemScheduleLines.find({node -> node.TypeCode.text().equals('1')})
			if(var_node != null) {
				sc_item.append(new NodeBuilder().earliestStartDateTime(var_node.DateTimePeriod.StartDateTime.text()))
				sc_item.append(new NodeBuilder().dueDateTime(var_node.DateTimePeriod.EndDateTime.text()))
				if(!var_node.Quantity.text().equals("")) {
				    sc_item.append(new NodeBuilder().durationInMinutes(Math.round(Math.floor(var_node.Quantity.text().toDouble()))))
				}
			}

			if((item.ItemServiceReferenceObjects.InstallationPointTypeCode.text().equals('6')
			&& message.getProperty("func_loc_enabled").toLowerCase().trim().equals('true')) ||
			item.ItemServiceReferenceObjects.InstallationPointTypeCode.text().equals('2')) {
				sc_item.append(new NodeBuilder().equipment{externalId(item.ItemServiceReferenceObjects.InstallationPointID.text())})
			}

			item.TicketItemSkill.findAll({node -> node.SkillSource.text().equals('07') || node.SkillSource.text().equals('06')}).each{
				// 07-Manual, 06-IBase
				var_node = it
				sc_item.append(new NodeBuilder().requirements{
					mandatory(var_node?.Mandatory?.text())
					skill{
						externalId(var_node?.SkillID?.text())
					}
				})
			}
			//If RP skill is not determined then only check for Products' skills
			if(item.TicketItemSkill.find({node -> node.SkillSource.text().equals('01')}) == null) {
				item.TicketItemSkill.findAll({node -> node.SkillSource.text().equals('02')}).each{
					// 02-Product
					var_node = it
					sc_item.append(new NodeBuilder().requirements{
						mandatory(var_node.Mandatory.text())
						skill{
							externalId(var_node.SkillID.text())
						}
					})
				}
			}

			if ((!team_role.equals(null)) && (item?.ServiceItemAdditionalInfo?.ServiceItemUpdated?.text()?.equals("false") || recon_ind.equals(true)
			|| sr[0]?.@TeamChangeIndicator?.equals("true") || sr[0]?.@ReleaseToFSMIndicator?.equals("true") || action.equals("CREATE"))) {
				sc_item.append(new NodeBuilder().region{code(team_role)})
			}
			sc_data.append(sc_item)
		}
	}

	// Reserved Materials mapping
	for(item in sr.Item) {
		if(item.FSMRelevanceCode.text().equals('2')) {
			var_node = item.ItemScheduleLines.find({node -> node.TypeCode.text().equals('1')})
			sc_item = new NodeBuilder().reservedMaterials(){
				externalId(item.UUID.text())
				warehouse{
					code(message.getProperty("FSM_Default_Warehouse_Code"))
				}
				quantity(item.ServiceTransactionProcessingTypeCode.text().equals('0004') && sr?.ReadATPConfirmedQtyIndicator?.text().equals('true')? item.ConfirmedQuantity.text() : var_node.Quantity.text())
			}

			if(!item.ItemProduct.ProductInternalID.text().equals("")) {
				sc_item.append(new NodeBuilder().item{externalId(item.ItemProduct.ProductInternalID.text())})
			}

			sc_data.append(sc_item)
		}
	}

	root_output.append(sc_data)
}

        StringWriter stringWriter = new StringWriter()
        XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
        nodePrinter.setPreserveWhitespace(true)
        nodePrinter.print(root_output)
        message.setBody(stringWriter.toString())
        return message;

}