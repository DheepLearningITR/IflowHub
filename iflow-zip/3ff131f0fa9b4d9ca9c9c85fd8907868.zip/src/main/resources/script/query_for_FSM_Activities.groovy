import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
       //Get Body and parse it.
       def parsedObj = new XmlSlurper().parseText(message.getBody(String.class));
       String obj="";// contains all the ticket ids of different service requests 
       ArrayList C4C_Activity_IDs = [];
       parsedObj.data.each{
           obj =obj+ "\'"+ it.externalId.toString().trim() + "\',"
           it.activities.each{
               C4C_Activity_IDs.add(it.externalId.toString().trim());//Adding all the c4c activities 
           }  
       }
       obj= obj[0..-2]
       message.setProperty("C4C_Activity_IDs",C4C_Activity_IDs);
       //getting all the ticket IDs 
      
       //query to fsm api 
       String finalQuery = "";
       String sc = "{\"query\": \"SELECT act.id,act.externalId FROM Activity act JOIN ServiceCall sc ON act.object.objectId = sc.id WHERE act.externalId IS NOT NULL AND act.executionStage !='CANCELLED' AND  sc.externalId IN  (" ;
       finalQuery = sc + obj+ ")" +'\"}';
       
       message.setBody(finalQuery);//setting the body 
       
       return message;
}