
import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) {

    def root = new XmlParser().parseText(message.getBody(String.class));
    
    Node sr_node, res_node, var_node
    def root_output = new NodeBuilder()."n0:ServiceRequestReplicationConfirmation"('xmlns:n0': 'http://sap.com/xi/SAPGlobal20/Global'){
    	MessageHeader{
    		ID(UUID.randomUUID().toString().replaceAll("-", "").toUpperCase())
    		ReferenceID(root.header.C4C_message_id.text())
    		CreationDateTime(new Date().format("yyyy-MM-dd'T'HH:mm:ss'Z'"))
    		SenderParty{
    			InternalID(schemeID:'CommunicationSystemID',schemeAgencyID:'310',root.header.Sender.text())
    		}
    		RecipientParty{
    			InternalID(schemeID:'CommunicationSystemID',schemeAgencyID:'310',root.header.Receiver.text())
    		}
    		BusinessScope{
    			TypeCode(listID:'25201',listAgencyID:'310',"3")
    			ID(schemeID:'10555',schemeAgencyID:'310',"106")
    		}
    	}
    }
    
    root.fsm_body.results.each{
    	if(it.status.text().equals('201') || it.status.text().equals('200')) {
    		res_node = it.resource[0]
    		sr_node = new NodeBuilder().ServiceRequestReplicationConfirmation{
    			BasicMessageHeader()
    			ServiceRequestReplicationConfirmation(actionCode: "04"){
    				ID(res_node.externalId.text())
    				ServiceRequestConfirmation(actionCode: "04"){
    					BusinessTransactionDocumentRelationshipRoleCode("6")
    					BusinessSystemID(root.header.Sender.text())
    					BTDReference{
    						ID(res_node.code.text().equals("") ? res_node.id.text() : res_node.code.text())
    						TypeCode('118')
    					}
    					FormattedUUID(res_node.id.text())
    				}
    			}
    		}
    
    		res_node.activities.each {
    			if(it.id.text().length() > 0) {
    				var_node = it
    				sr_node.ServiceRequestReplicationConfirmation[0].append(new NodeBuilder().ItemConfirmation(actionCode: "04"){
    					UUID(var_node.externalId.text())
    					BTDReference(actionCode:'04'){
    						BusinessTransactionDocumentRelationshipRoleCode('6')
    						BusinessSystemID(root.header.Sender.text())
    						FormattedUUID(var_node.id.text())
    						BTDReference{
    							ID(var_node.code.text().equals("") ? var_node.id.text() : var_node.code.text())
    							TypeCode('118')
    							ItemTypeCode('271')
    						}
    					}
    				})
    			}
    		}
    
    		res_node.reservedMaterials.each {
    			if(it.id.text().length() > 0) {
    				var_node = it
    				sr_node.ServiceRequestReplicationConfirmation[0].append(new NodeBuilder().ItemConfirmation(actionCode: "04"){
    					UUID(var_node.externalId.text())
    					BTDReference(actionCode:'04'){
    						BusinessTransactionDocumentRelationshipRoleCode('6')
    						BusinessSystemID(root.header.Sender.text())
    						FormattedUUID(var_node.id.text())
    						BTDReference{
    							ID(var_node.id.text())  //reservedMaterials do not have code field
    							TypeCode('118')
    							ItemTypeCode('271')
    						}
    					}
    				})
    			}
    		}
    
    		root_output.append(sr_node)
    	}
    }
    
    StringWriter stringWriter = new StringWriter()
    XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
    nodePrinter.setPreserveWhitespace(true)
    nodePrinter.print(root_output)
    message.setBody(stringWriter.toString())
    return message;    
}