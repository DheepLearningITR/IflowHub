import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    //body1 = message.getProperty('P_OriginalPayload')
    def parsedObj = message.getProperty("Payload")//new XmlSlurper().parseText(body1.getBody(String.class));
    String recon_ind = parsedObj.MessageHeader.Recon
    def parsedObj1 = new JsonSlurper().parseText(message.getBody(String.class));
    def each_id
    Node Ref_Node;
    def XML_Node

    def FSM_Activity_ID_Map = [:]
    parsedObj1.data.each{
        FSM_Activity_ID_Map.put(it.sc.id,it.sc.code);
    }

    parsedObj.ServiceRequestReplicationRequestMessage.ServiceRequest.each{
        each_id=it.ID.toString().trim()
        if(FSM_Activity_ID_Map.keySet().contains(each_id)){
            if(! it.BTDReference.isEmpty()){
                Ref_Node= new NodeBuilder().BTDReference{
                BusinessTransactionDocumentRelationshipRoleCode("6")
                BusinessSystemID(recon_ind)
                BTDReference{
                   ID(FSM_Activity_ID_Map[each_id])
                   TypeCode("118")
                }
                }
                XML_Node= groovy.xml.XmlUtil.serialize(Ref_Node)
                def parsedObj2 = new XmlSlurper().parseText(XML_Node);
                it.BTDReference.appendNode(parsedObj2)
            }
            else{
                Ref_Node= new NodeBuilder().BTDReference{
                ID(each_id)
                BTDReference{
                    BusinessTransactionDocumentRelationshipRoleCode("6")
                    BusinessSystemID(recon_ind)
                    BTDReference{
                        ID(FSM_Activity_ID_Map[each_id])
                        TypeCode("118")
                    }
                }
            }
            XML_Node= groovy.xml.XmlUtil.serialize(Ref_Node)
            def parsedObj2 = new XmlSlurper().parseText(XML_Node);
            it.appendNode(parsedObj2)
        }
    }
    }
    message.setProperty("P_OriginalPayload",parsedObj)
    message.setBody(parsedObj)
}