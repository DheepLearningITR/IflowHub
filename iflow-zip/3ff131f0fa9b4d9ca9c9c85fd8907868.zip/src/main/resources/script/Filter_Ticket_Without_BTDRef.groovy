import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
	//parsing the data
	def parsedObj = new XmlSlurper().parseText(message.getBody(String.class));

	String obj=""
	def rec_party=parsedObj.MessageHeader.RecipientParty.InternalID.text()

	//Filtering tickets with no BTDReference
	parsedObj.ServiceRequestReplicationRequestMessage.ServiceRequest.each{
	    def action = it.BTDReference.BTDReference.findAll({node -> node.BusinessSystemID.text().equals(rec_party)}).isEmpty()
		if(action){
    			obj =obj+ "\'"+ it.ID.toString().trim() + "\',"
		}
	}
	if(!obj.isEmpty()){
	    obj= obj[0..-2]
	    //Querying to FSM to get BTDReferences of the tickets captured 
		String sc = "{\"query\": \"SELECT sc.externalId,sc.code FROM ServiceCall sc WHERE sc.externalId IN  (" ;
		String finalQuery = sc + obj+ ")" +'\"}';
		message.setBody(finalQuery);
	}

	else{
		//If all the tickets have BTDReference
		message.setProperty("BTDRef","NOTHING")
	}
	
	return message;
}
	
