/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.json.JsonOutput ;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
	
	//**********************************************
	// Validate mandatory headers
	//**********************************************
	def header = message.getProperty("token") ;
	if( header == null ) {
		throw new Exception("Mandatory header \"accessToken\" is missing") ;
	}
	
	header = message.getProperty("serviceBaseUrl") ;
	if( header == null ) {
		throw new Exception("Mandatory header \"serviceBaseUrl\" is missing") ;
	}
	
	header = message.getProperty("tenant") ;
	if( header == null ) {
		throw new Exception("Mandatory header \"tenant\" is missing") ;
	}
	
	header = message.getProperty("sourceId") ;
	if( header == null ) {
		throw new Exception("Mandatory header \"c4cObjectId\" is missing") ;
	}
	
	header = message.getProperty("sourceInternalId") ;
	if( header == null ) {
		throw new Exception("Mandatory header \"c4cFormattedId\" is missing") ;
	}
	
	header = message.getProperty("targetId") ;
	if( header == null ) {
		throw new Exception("Mandatory header \"remoteObjectId\" is missing") ;
	}
	//**********************************************
	//**********************************************
	
	 
	def body = message.getBody(java.lang.String) as String;
	
	def jsonSlurper = new JsonSlurper();
	def inputPayload = jsonSlurper.parseText(body) ;
	assert inputPayload instanceof Map ;
	
	def productData = inputPayload.get("Product");
	if( productData == null ) {
		throw new Exception("Product tag is missing in the input") ;
	}
	
	def defaultLanguage = "E" ;
	def productId = productData.get("ID") ;
	if( productId == null ) {
		throw new Exception("ID is missing in input payload") ;
	}
	
	// Set product id as product description if not present
	def productField = productData.get("Description") ;
	if( productField == null || productField.isEmpty() ) {
		productData.put("Description", productId) ;
	}
	
	// Set default language code if not present in input
	productField = productData.get("languageCode") ;
	if( productField == null || productField.isEmpty() ) {
		productData.put("languageCode", defaultLanguage) ;
	}
		
	// Get attachment data
	// Store it separately and remove it from product. 
	def attachments = productData.get("ProductAttachment") ;
	if( attachments == null || !( attachments instanceof List)) {
		throw new Exception("Product attachment is missing in the input") ;
	}
	
	if( attachments.size() > 0 ) {
		message.setProperty("inputAttachmentLength", "1") ;
	} else {
		message.setProperty("inputAttachmentLength", "0") ;
	}
	
	message.setProperty("inputAttachment", JsonOutput.toJson(attachments)) ;
	
 	productData.remove("ProductAttachment") ;
	inputPayload.put("Product", productData) ;
	message.setBody(JsonOutput.toJson(inputPayload)) ;
	
	return message;
}

