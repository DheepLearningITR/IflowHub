importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  message.setProperty('customerJSON', body);
  message.setHeader('Content-Type', 'application/json');
  var clientCode = String(message.getProperty('clientCode'));
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  var clientListJson = getListServiceExpression(clientCode);
  message.setBody(JSON.stringify(clientListJson));
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('clientListGetJson:', JSON.stringify(clientListJson), 'text/json');
  }
  var headers = message.getHeaders();
  headers.remove('RepliconToken');
  headers.remove('Transfer-Encoding');
  return message;
}

function getListServiceExpression(clientCode) {
  return {
    page: '1',
    pagesize: '10',
    columnUris: [ 'urn:replicon:client-list-column:client', 'urn:replicon:client-list-column:name', 'urn:replicon:client-list-column:code' ],
    sort: [],
    filterExpression: {
      leftExpression: {
        leftExpression: null,
        operatorUri: null,
        rightExpression: null,
        value: null,
        filterDefinitionUri: 'urn:replicon:client-list-filter:code'
      },
      operatorUri: 'urn:replicon:filter-operator:text-search',
      rightExpression: {
        leftExpression: null,
        operatorUri: null,
        rightExpression: null,
        value: {
          uri: null,
          uris: [],
          bool: null,
          date: null,
          money: null,
          number: null,
          text: clientCode,
          time: null,
          calendarDayDurationValue: null,
          workdayDurationValue: null,
          dateRange: null,
          dateTimeUtc: null
        },
        filterDefinitionUri: null
      },
      value: null,
      filterDefinitionUri: null
    }
  };
}
