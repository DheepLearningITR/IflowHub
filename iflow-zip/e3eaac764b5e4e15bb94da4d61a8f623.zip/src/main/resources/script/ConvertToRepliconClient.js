importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var jsonBody = JSON.parse(body);
  var messageLog = messageLogFactory.getMessageLog(message);
  var logBody = message.getProperty('LogMessageBody');
  var lastSyncDateLocal = String(message.getProperty('lastClientSyncDate'));
  var clientName = jsonBody.entry.content.properties.CustomerName;
  var clientCode = jsonBody.entry.content.properties.Customer;
  message.setProperty('clientName', clientName);
  message.setProperty('clientCode', clientCode);
  var creationDate = jsonBody.entry.content.properties.CreationDate;
  var regex = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/;
  var dateArray = regex.exec(lastSyncDateLocal);
  var lastSyncDate = new Date(
    (Number(dateArray[1])),
    (Number(dateArray[2])) - 1,
    (Number(dateArray[3])),
    0,
    0,
    0
  );
  dateArray = regex.exec(creationDate);
  var createdDate = new Date(
    (Number(dateArray[1])),
    (Number(dateArray[2])) - 1,
    (Number(dateArray[3])),
    (Number(dateArray[4])),
    (Number(dateArray[5])),
    (Number(dateArray[6]))
  );
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('HanaCustomer: ' + clientName + ' with code: ' + clientCode, body, 'text/json');
  }
  if (createdDate >= lastSyncDate) {
    message.setHeader('ProcessRequest', 'Yes');
  } else {
    message.setHeader('ProcessRequest', 'No');
  }
  return message;
}