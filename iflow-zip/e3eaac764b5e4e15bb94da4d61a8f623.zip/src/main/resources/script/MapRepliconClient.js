importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  var customerJSON = String(message.getProperty('customerJSON'));
  var customer = JSON.parse(customerJSON);
  var clientName = customer.entry.content.properties.CustomerName;
  var clientCode = customer.entry.content.properties.Customer;
  var clientDescription = customer.entry.content.properties.CustomerFullName;
  var isActive = true;
  var clientListJson = JSON.parse(body);
  var logBody = message.getProperty('LogMessageBody');
  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('clientListJson:', body, 'text/json');
  }

  var clientJson = getClientJson(clientListJson, clientName, clientCode, clientDescription, isActive);
  message.setHeader('Content-Type', 'application/json');
  message.setBody(JSON.stringify(clientJson));

  if (messageLog && logBody && logBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('clientJson:', JSON.stringify(clientJson), 'text/json');
  }
  return message;
}

function getClientJson(clientListJson, clientName, clientCode, clientDescription, isActive) {
  var target = null;
  if (clientListJson.d && clientListJson.d.rows && clientListJson.d.rows.length) {
    for (var i = 0; i < clientListJson.d.rows.length; i++) {
      var code = clientListJson.d.rows[i].cells[2].textValue;
      if (code === clientCode) {
        target = {
          uri: null,
          name: null,
          code: code,
          parameterCorrelationId: null
        };
      }
    }
  }
  var clientJson = {
    target: target,
    modifications: {
      nameToApply: {
        value: clientName
      },
      codeToApply: {
        value: clientCode
      },
      descriptionToApply: {
        value: clientDescription
      },
      statusToApply: isActive,
      clientContactToApply: null,
      clientAddressToApply: null,
      billingAddressToApply: null,
      billingRatesToApply: null,
      clientManagerToApply: null,
      clientSharingToApply: null,
      expenseCodesToApply: null,
      customFieldsToApply: []
    },
    clientModificationOptionUri: 'urn:replicon:client-modification-option:save',
    unitOfWorkId: makeid(8)
  };
  return clientJson;
}

function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}