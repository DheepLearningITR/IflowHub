/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var messageLog = messageLogFactory.getMessageLog(message);
  updateLastSyncDate(message, messageLog);
  var lastSyncDate = String(message.getProperty('lastClientSyncDate'));
  var offset = String(message.getProperty('OffsetTimeInMM'));
  lastSyncDate = getDateValue(lastSyncDate);
  lastSyncDate = addMinutes(lastSyncDate, offset * -1);
  lastSyncDate = lastSyncDate.toISOString().split('.')[0];
  message.setProperty('lastClientSyncDate', lastSyncDate);
  return message;
}

function addMinutes(dt, minutes) {
  return new Date(dt.getTime() + (minutes * 60000));
}

function getDateValue(dateVariable) {
  var regex = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/;
  var dateArray = regex.exec(dateVariable);
  var syncDate = new Date(
    (Number(dateArray[1])),
    (Number(dateArray[2])) - 1,
    (Number(dateArray[3])),
    (Number(dateArray[4])),
    (Number(dateArray[5])),
    (Number(dateArray[6]))
  );
  return syncDate;
}

function updateLastSyncDate(message, messageLog) {
  var lastSuccessSyncDate = String(message.getProperty('LastSuccessfulClientSyncTime'));
  if (lastSuccessSyncDate) {
    lastSuccessSyncDate = getDateValue(lastSuccessSyncDate);
  } else {
    lastSuccessSyncDate = getUTCDate();
  }
  var resetTimeThreshold = message.getProperty('resetTimeThresholdInMins');
  var utcDate = getUTCDate();
  if ((utcDate.getTime() - lastSuccessSyncDate.getTime()) > resetTimeThreshold * 60000) {
    var logMessageBody = message.getProperty('LogMessageBody');

    var lastSyncDate = addMinutes(utcDate, -1 * resetTimeThreshold);
    lastSyncDate = lastSyncDate.toISOString().split('.')[0];
    message.setProperty('lastClientSyncDate', lastSyncDate);
    if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
      messageLog.addAttachmentAsString('Reset Time', lastSyncDate, 'text/json');
    }
  }
}

function getUTCDate() {
  var utcDate = new Date(new Date().toUTCString().slice(0, -4));
  return utcDate;
}