import com.sap.it.api.mapping.*;

def String customFunc(String sourceType) {
  def STORE = "STORE";
  def DC = "DC";
  def result;
  
  
  if ( sourceType.equals("") || sourceType == null ) {
    result = DC;
  }
  
  switch (sourceType) {
    case "A":
      result = STORE;
      break;
    case "B":
      result = DC;
      break;
    default:
      result = DC;
      break;
    } 
    
  return result;
}