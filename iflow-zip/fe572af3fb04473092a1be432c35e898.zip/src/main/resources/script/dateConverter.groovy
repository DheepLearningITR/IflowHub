import com.sap.it.api.mapping.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


def String convertDate(String date){

    Date inputDate = new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH).parse(date);
    String outputDate = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(inputDate);

    return outputDate;
}
