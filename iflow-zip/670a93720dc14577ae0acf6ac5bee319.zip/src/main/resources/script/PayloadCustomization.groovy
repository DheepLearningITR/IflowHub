/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import groovy.xml.XmlUtil
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.security.MessageDigest;
def Message processData(Message message) {
    //Body
    def body = message.getBody(java.io.Reader);
    def xs = new XmlSlurper();
    def conditionContract = xs.parse(body);
    def endDate = conditionContract.HEADDATAIN.VALIDITY_DATE_TO.text();
    def saleorgId = conditionContract.HEADDATAIN.SALESORG.text();
    def customer = conditionContract.HEADDATAIN.CUSTOMER_OWNER.text();
    def externalCat = conditionContract.HEADDATAIN.CONDITION_CONTRACT_EXTERNALCAT.text();
    def promotionId = conditionContract.HEADDATAIN.CONDITION_CONTRACT_EXTERNALREF.text();
    def referenceItem = conditionContract.HEADDATAIN.CONDITION_CONTRACT_EXTREFITEM.text();
    def headHashValue = externalCat + ";" + promotionId + ";" + referenceItem;
    
    //build the  BVB data
    buildCriteriaNode(conditionContract, headHashValue, saleorgId, customer)

    //addsettlmtcal
    def finalCal = conditionContract.CALENDARDATAIN.item;
    finalCal.ORDER_KEY.replaceBody(1)
    finalCal.EXTERNAL_GUID.replaceBody(getMD5(endDate+headHashValue))

    //build the condition data
    buildContractConditionRecord(conditionContract, headHashValue);
    conditionContract.declareNamespace(ns1: conditionContract.namespaceURI())
    message.setBody(XmlUtil.serialize(conditionContract));
    return message;
}

//build BVB data
def buildCriteriaNode(conditionContract, headHashValue, saleorgId, customer) {
    def criteria = conditionContract.BVBDATAIN;
    def xs = new XmlSlurper();
    def orderKey = 0;
    criteria.item.each { data ->
        data.ORDER_KEY.replaceBody(++orderKey)
        data.EXTERNAL_GUID.replaceBody(getMD5(data.MATERIAL_NEW.text() + headHashValue))
    }
    criteria.appendNode {
        item {
            ORDER_KEY(++orderKey)
            FIELDCOMBINATION("0003")
            INCLUDE_EXCLUDE("I")
            SALESORG_NEW(saleorgId)
            EXTERNAL_GUID(getMD5(saleorgId + headHashValue))
        }
        item {
            ORDER_KEY(++orderKey)
            FIELDCOMBINATION("0006")
            INCLUDE_EXCLUDE("I")
            CUST_HIER_NEW(customer)
            EXTERNAL_GUID(getMD5(customer + headHashValue))
        }
    }
}

//get md5 value
def String getMD5(inputStr) {
    def instanceCode = "MD5"
    MessageDigest md = MessageDigest.getInstance(instanceCode)
    md.update(inputStr.getBytes())
    byte[] digest = md.digest()
    return digest.collect { String.format("%02X", it) }.join()
}
//add accrual record
def buildContractConditionRecord(record, headHashValue) {
    def orderKey = 0
    def conditionKeyItems = record.CONDITIONKEYDATAIN;
    def keyData = [];
    def accuralNodes = [];
    def xs = new XmlSlurper();
    conditionKeyItems.item.each { keyItem ->
        keyItem.ORDER_KEY.replaceBody(++orderKey)
        def accuralType = keyItem.ACCRUAL_COND_TYPE.text();
        def material = keyItem.MATERIAL.text();
        def condType = keyItem.COND_TYPE.text();
        def itemData = xs.parseText(XmlUtil.serialize(keyItem.item));
        keyItem.ACCRUAL_COND_TYPE.replaceNode {};
        keyItem.EXTERNAL_GUID.replaceBody(getMD5(condType + material + headHashValue));
        keyItem.item.replaceNode {};
        itemData.ORDER_KEY.replaceBody(orderKey);
        keyData.add(xs.parseText(XmlUtil.serialize(itemData)))
        def accuralnode = xs.parseText(XmlUtil.serialize(keyItem));
        accuralnode.ORDER_KEY.replaceBody(++orderKey);
        accuralnode.COND_TYPE.replaceBody(accuralType);
        accuralnode.EXTERNAL_GUID.replaceBody(getMD5(accuralType + material + headHashValue))
        accuralNodes.add(accuralnode);
        itemData.ORDER_KEY.replaceBody(orderKey);
        keyData.add(xs.parseText(XmlUtil.serialize(itemData)))
    }
    keyData.each { data ->
        record.CONDITIONITEMDATAIN.appendNode(data)
    }
    accuralNodes.each { data -> record.CONDITIONKEYDATAIN.appendNode(data)}
}






