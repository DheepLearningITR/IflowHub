import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
def Message processData(Message message) {
      def body = message.getBody();
      map = message.getProperties();
      
      String Fieldglass_Credential = new String (map.get("Fieldglass_Credential"));
      
      def service =  ITApiFactory.getApi(SecureStoreService.class, null)
      
      def credential_Secret = service.getUserCredential(Fieldglass_Credential)
      
      String username_Secret = new String(credential_Secret.getUsername())
      
      String password_Secret = new String(credential_Secret.getPassword())
      
      message.setProperty("Fieldglass_Username",username_Secret)
      
      message.setProperty("Fieldglass_Password",password_Secret)
      
      return message;
}


