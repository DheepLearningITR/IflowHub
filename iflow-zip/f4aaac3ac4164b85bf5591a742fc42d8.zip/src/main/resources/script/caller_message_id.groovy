import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService

def Message processData(Message message) {
	def callerId = message.getHeaders().get("DME_CallerMessageID");
	def msgId = message.getHeaders().get("SAP_MessageProcessingLogID");
	message.setHeader("SAP_Sender", callerId );
	message.setHeader("DME_CallerMessageID", msgId );
	message.setHeader("Content-Type", "application/x-www-form-urlencoded" );

	def dmcCredential = message.getProperties().get("DMC_CREDENTIAL");

	def service = ITApiFactory.getApi(SecureStoreService.class, null);
	
	def credential = service.getUserCredential(dmcCredential);
	
	if (credential == null){
		throw new IllegalStateException("No credential found for alias 'CF_AUTH'");
	}

	String clientID = credential.getUsername();
	String clientSecret = new String(credential.getPassword());
	Map<String, String> prop = credential.getCredentialProperties();

	String credentialKind = prop.get("sec:credential.kind")
	//the prop contains "sec:credential.kind" with value "default" or "oauth2:default" for basic and OAuth2 Client Credentials
	if (credentialKind != null && "oauth2:default".equalsIgnoreCase(credentialKind)) {
		message.setProperty("ClientCredentialGrantType", "true");
	} else {
		message.setBody("client_id=" + encode(clientID) + "&client_secret=" + encode(clientSecret) + "&grant_type=client_credentials");
	}
	return message;
}

def String encode(String input){
	return java.net.URLEncoder.encode(input, "UTF-8");
}
