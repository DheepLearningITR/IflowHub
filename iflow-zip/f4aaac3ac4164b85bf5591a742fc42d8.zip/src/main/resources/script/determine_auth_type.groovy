import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

	String dmc_private_key_alias = message.getProperties().get("dmc_private_key_alias");

	if(dmc_private_key_alias != null && dmc_private_key_alias.trim()){
		message.setProperty("AuthType","CERTIFICATE");
	}
	return message;
}
