import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService

def Message processData(Message message) {
	def callerId = message.getHeaders().get("DME_CallerMessageID");
	def msgId = message.getHeaders().get("SAP_MessageProcessingLogID");
	message.setHeader("SAP_Sender", callerId );
	message.setHeader("DME_CallerMessageID", msgId );
	message.setHeader("Content-Type", "application/x-www-form-urlencoded" );

	def service = ITApiFactory.getApi(SecureStoreService.class, null);
	
	def dmcCredential = message.getProperties().get("DMC_CREDENTIAL");
	def credential = service.getUserCredential(dmcCredential);
	if (credential == null){
		throw new IllegalStateException("No credential found for alias 'CF_AUTH'");
	}
	
	String clientID = credential.getUsername();
	message.setBody("client_id=" + encode(clientID) + "&grant_type=client_credentials");
	
	return message;
}

def String encode(String input){
	return java.net.URLEncoder.encode(input, "UTF-8");
}
