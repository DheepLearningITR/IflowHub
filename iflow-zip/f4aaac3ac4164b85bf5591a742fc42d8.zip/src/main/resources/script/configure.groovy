import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.pd.PartnerDirectoryService
import groovy.transform.Field


@Field static final String SERVICE_MODE_DM_SYNC = "DM_SYNC";
@Field static final String SERVICE_MODE_DM_ASYNC = "DM_ASYNC";


def Message processData(Message message) {
    def unique_id = message.getProperty('ENDPOINT_ID');
    def PD_NAMESPACE = "DME_Generic_Processing_$unique_id";
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null);

    setMessageRequestPath(service, PD_NAMESPACE, unique_id, message);

    def callerId = message.getHeaders().get("DME_CallerMessageID");
    def msgId = message.getHeaders().get("SAP_MessageProcessingLogID");
    message.setHeader("SAP_Sender", callerId);
    message.setHeader("DME_CallerMessageID", msgId);
    return message;
}

def void setMessageRequestPath(PartnerDirectoryService service, String pid, String unique_id, Message message) {
    if (service == null) {
        throw new IllegalStateException("Partner Directory Service not found");
    }

    def root_name = message.getHeaders().get("SAP_MessageType");
    if (root_name != null) {
        def requestPath = service.getParameter("${root_name}_REQUEST_PATH", pid, String.class);
        def methodAction = service.getParameter("${root_name}_METHOD_ACTION", pid, String.class);
        if (requestPath != null && methodAction != null) {
            message.setHeader("REQUEST_PATH", requestPath);
            message.setHeader("METHOD_ACTION", methodAction);
        }
    }
    def requestPath = message.getHeaders().get("REQUEST_PATH");
    //below is to add service async call query
    copy_pd_parameter('SERVICE_MODE', "${root_name}_CUSTOM_SERVICE_MODE", "${root_name}_STD_SERVICE_MODE", pid, unique_id, message, service);
    def serviceMode = message.getProperty('SERVICE_MODE');
    if (requestPath && serviceMode && SERVICE_MODE_DM_ASYNC.equalsIgnoreCase(serviceMode)) {
        def requestPathAppendQuery = requestPath + "?async=true";
        message.setHeader("REQUEST_PATH", requestPathAppendQuery);
    }
}


def void copy_pd_parameter(String propname, String pdname1, String pdname2, String pid, def unique_id, def message, def service) {
    def VALUE1 = service.getParameter(pdname1, pid, String.class);
    def VALUE2 = service.getParameter(pdname2, pid, String.class);
    if (VALUE1 && !VALUE1.equalsIgnoreCase("{{NULL}}")) {
        message.setProperty(propname, VALUE1.replaceAll("\\{\\{ENDPOINT_ID\\}\\}", "$unique_id"));
    } else if (VALUE2 && !VALUE2.equalsIgnoreCase("{{NULL}}")) {
        message.setProperty(propname, VALUE2.replaceAll("\\{\\{ENDPOINT_ID\\}\\}", "$unique_id"));
    }
}
