import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import groovy.transform.Field
import groovy.xml.XmlUtil

import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

@Field static final String VM_AGENCY_DM = 'DM'
@Field static final String VM_IDENTIFIER_Plant = 'Plant'
@Field static final String VM_AGENCY_ERP = 'ERP'
@Field static final String VM_IDENTIFIER_Time_Zone = 'Time Zone'
@Field static final Map FIELDS_CONFIGURATION = [
        'IORDER01': [
                'plantNode': 'plant',
                'timeNodes': [
                        'plannedStart',
                        'plannedEnd',
                        'scheduledStart',
                        'scheduledEnd',
                        'schedules.schedule.earliestSetupStartDate',
                        'schedules.schedule.earliestProcessingStartDate',
                        'schedules.schedule.earliestTeardownStartDate',
                        'schedules.schedule.earliestTeardownEndDate',
                        'schedules.schedule.latestSetupStartDate',
                        'schedules.schedule.latestProcessingStartDate',
                        'schedules.schedule.latestTeardownStartDate',
                        'schedules.schedule.latestTeardownEndDate'
                ]
        ]
]

Message processData(Message message) {
    String root_name = message.getHeaders().get('SAP_MessageType')
    def config = FIELDS_CONFIGURATION[root_name]
    if (!config) {
        return message;
    }
    def xmlPayload = message.getBody(String)
    def xml = new XmlSlurper(false, true).parseText(xmlPayload)

    // Get plantNode
    def plantNode = config.plantNode
    def plantValue = xml."${plantNode}".text()
    def timeZone = getTimeZone(plantValue)

    if (!timeZone) {
        return message;
    }
    message.setProperty('timeZoneConversion', true)
    // Process timeNodes
    config.timeNodes.each { timeNode ->
        def nodes = getNode(xml, timeNode);
        if (nodes instanceof groovy.util.slurpersupport.GPathResult && nodes.size() > 1) {
            nodes.each { node ->
                def timeValue = node.text()
                if (timeValue != null && !timeValue.isEmpty()) {
                    def convertedTime = convertERPTimeToUTC(timeValue, timeZone)
                    node.replaceBody(convertedTime)
                }
            }
        } else {
            def timeValue = nodes.text()
            if (timeValue != null && !timeValue.isEmpty()) {
                def convertedTime = convertERPTimeToUTC(timeValue, timeZone)
                nodes.replaceBody(convertedTime)
            }
        }
    }
    message.setBody(XmlUtil.serialize(xml))
    return message
    
}

private String getTimeZone(String plant) {
    def vm = ITApiFactory.getService(ValueMappingApi.class, null)
    def timeZone = vm.getMappedValue(VM_AGENCY_DM, VM_IDENTIFIER_Plant, plant, VM_AGENCY_ERP, VM_IDENTIFIER_Time_Zone)
    return timeZone
}

private String convertERPTimeToUTC(String time, String timeZone) {
    LocalDateTime localDateTime
    //the time is in the format of "2019-09-25T10:15:30Z", however the Z is incorrect(not UTC but manually appened) and should be removed
    time = time.replaceAll('Z', '')
    if (time.contains('T24:00:00.000')) {
        //erp can have 24:00:00.000 as a time value, we replace it with one day after
        time = time.replace('T24:00:00.000', 'T00:00:00.000')
        localDateTime = LocalDateTime.parse(time, DateTimeFormatter.ISO_LOCAL_DATE_TIME).plusDays(1)
    } else {
        localDateTime = LocalDateTime.parse(time, DateTimeFormatter.ISO_LOCAL_DATE_TIME)
    }
    ZonedDateTime utcTime = localDateTime.atZone(ZoneId.of(timeZone)).withZoneSameInstant(ZoneId.of('UTC'))
    return utcTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))
}

private getNode(def xml, String path) {
    def parts = path.split('\\.')
    def node = xml
    parts.each { part ->
        node = node."${part}"
    }
    return node
}