import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	    // Get the messageLogFactory and the FetchMessages property 
    def properties = message.getProperties();
	String inithMessages = properties.get("InitMessages") ?: '';

    // Log and format the ERPReadFetchMessages attachment
    if(inithMessages != ''){
        def messageLog = messageLogFactory.getMessageLog(message);
        if(messageLog != null){      
                messageLog.addAttachmentAsString('ERPReadInithMessages', "<Messages>" + inithMessages + "</Messages>", 'text/XML')     
        }
    }
    
	return message;
}



