import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	    // Get the messageLogFactory and the FetchMessages property 
	def messageLog = messageLogFactory.getMessageLog(message);
    def properties = message.getProperties();
    String initMessages = properties.get("InitMessages") ?: '';
	
    if(messageLog != null){
        
        try{
            def ex = properties.get("CamelExceptionCaught");
            String exMessage = "<Message Type=\"Error\" Origin=\"SAP IBP Add-On Read - Initialize\">" + ex.getMessage() + "</Message>";
            messageLog.addAttachmentAsString('ERPReadInitMessages', "<Messages>" + exMessage + initMessages + "</Messages>", 'text/XML')
            message.setProperty("InitMessages", exMessage + initMessages);
        }catch(Exception e){
            if(initMessages != ''){
                messageLog.addAttachmentAsString('ERPReadInitMessages', "<Messages>" + initMessages + "</Messages>", 'text/XML')
            }  
        }
        
        
        //Set the body so that the next XSLT step will always have a valid body
        message.setBody("<Root/>");
    }
    
	return message;
}




