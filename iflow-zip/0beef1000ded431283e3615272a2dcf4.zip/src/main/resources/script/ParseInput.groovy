import com.sap.gateway.ip.core.customdev.util.Message;
import java.io.StringWriter
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    String body = message.getBody(String);

    try {
        xml = new XmlParser().parseText(body)
    } catch (Exception e) {
        throw new IllegalArgumentException("Invalid XML format", e)
    }

    if (xml.name() != 'IBPRead') {
        throw new IllegalArgumentException("Root element must be IBPRead")
    }

    // Validate RequestedFields Items
    if (xml.RequestedFields.item.any { it.FIELDNAME.text().isEmpty() }) {
        throw new IllegalArgumentException("Each RequestedFields item must have FIELDNAME")
    }
    
    def fieldNames = xml.RequestedFields.item.FIELDNAME.collect { it.text() }
    if (fieldNames.size() != fieldNames.toSet().size()) {
        throw new IllegalArgumentException("RequestedFields table cannot contain duplicate Field values")
    }

    if (!xml.'@SourceFieldsfromAddon'.isEmpty()) {
        def attributeFieldNames = xml.'@SourceFieldsfromAddon'.split(',').collect { it.trim() }
        if (attributeFieldNames.size() != attributeFieldNames.toSet().size()) {
            throw new IllegalArgumentException("SourceFieldsfromAddon attribute cannot contain duplicate Field values")
        }
    }

    // Validate Filters
    if (xml.Filters.item.any {
        it.FIELDNAME.text().isEmpty()
    }) {
        throw new IllegalArgumentException("Each Filters item must have FIELDNAME")
    }

    message.setProperty("DataSource", xml.'@DataSource')
    message.setProperty("DestinationforAddon", xml.'@DestinationforAddon')
    message.setProperty("MaxPackageSize", xml.'@MaxPackageSize')


    if(xml.Filters.isEmpty()) {
        if(xml.'@FilterForTheDataSource'.isEmpty()) {
            message.setProperty("FiltersTable", '')
        } else {
            message.setProperty("FiltersTable", evaluateFilter(xml.'@FilterForTheDataSource') )
        }
    }
    else {
        message.setProperty("FiltersTable",removeXmlDeclaration(xml.Filters.item.collect { XmlUtil.serialize(it).replaceAll('\n', '').replaceAll('\r', '') }.join()))
    }

    if(xml.RequestedFields.isEmpty()) {
        if(xml.'@SourceFieldsfromAddon'.isEmpty()) {
            throw new IllegalArgumentException("SourceFieldsfromAddon table cannot be empty")
        } else {
            //Set property Req fields property
            message.setProperty("RequestedFields", convertReqFieldsToXML(xml.'@SourceFieldsfromAddon'))
            message.setProperty("RequestedFieldsString",xml.'@SourceFieldsfromAddon')
        }
    } else {
        message.setProperty("RequestedFields",removeXmlDeclaration(xml.RequestedFields.item.collect { XmlUtil.serialize(it).replaceAll('\n', '').replaceAll('\r', '') }.join()))
        message.setProperty("RequestedFieldsString",convertReqFieldsXMLToString(xml.RequestedFields))

    }
    return message;
}

def removeXmlDeclaration(xml) {
    xml.replaceAll(/\<\?xml.*?\?\>/, '').trim()
}

def convertReqFieldsToXML(String fieldlist) {
    def fields = fieldlist.split(',')
    def xmlOutput = ""

    fields.each { field ->
        xmlOutput = xmlOutput.concat("<item><FIELDNAME>${field.trim()}</FIELDNAME></item>")
    }

    return xmlOutput
}

def convertReqFieldsXMLToString(reqFieldsXML) {

    def fieldList = reqFieldsXML.item.FIELDNAME.collect { it.text() }
    def fieldNames = fieldList.join(',')

    return fieldNames
}

def String evaluateFilter(String filter) {
    
    //Support for additional operators might be required
    // Operator	Description	                Implemented
    //
    // EQ	    Equal To	                +
    // BT	    Between	                    +
    // CP	    Pattern	4                   +
    // GT	    Greater Than	            +
    // GE   	Greater Than or Equal To	+
    // LT	    Less Than	                +
    // LE   	Less Than or Equal To	    +
    // NE   	Not Equal To	            +
    // NB   	Not Between	                +
    // NP   	Exclude Pattern	            +
    
def writer = new StringWriter()
            def xml = new groovy.xml.MarkupBuilder(writer)
            xml.setDoubleQuotes(true)
            def multiValueOps = ['BT', 'NB'] // Operators requiring two values
            def validOps = ['EQ', 'NE', 'LT', 'LE', 'GT', 'GE', '=', '<>', '<=', '>=', '<', '>', 'BT', 'CP', 'NB', 'NP']
            def opMap = ['=': 'EQ', '<>': 'NE', '<=': 'LE', '>=': 'GE', '<': 'LT', '>': 'GT']

            filter.split(',').each { f ->
                def trimmed = f.trim()
                if (trimmed.isEmpty()) {
                    throw new IllegalArgumentException("Filter part is empty.")
                }
                def parts = splitOutsideQuotes(trimmed)
                if (parts.size() < 3 || parts.size() > 4) {
                    throw new IllegalArgumentException("Filter part '${trimmed}' has an invalid number of components. Expected 3 or 4, got ${parts.size()}.")
                }
                if (!multiValueOps.contains(parts[1].toUpperCase()) && (parts.size() != 3)) {
                    throw new IllegalArgumentException("Filter part '${trimmed}' has an invalid number of components for the operand ${parts[1].toUpperCase()}.")
                }
                if (multiValueOps.contains(parts[1].toUpperCase()) && parts.size() != 4) {
                    throw new IllegalArgumentException("Filter part '${trimmed}' has an invalid number of components for the operand ${parts[1].toUpperCase()}.")
                }
                def field = parts[0]
                def op = parts[1]
                def value = parts[2]
                def highValue = multiValueOps.contains(op.toUpperCase()) ? parts[3] : "" // Initialize highValue for multi-value operators

                if (!field) {
                    throw new IllegalArgumentException("Field name missing in filter part '${trimmed}'.")
                }

                if (!op) {
                    throw new IllegalArgumentException("Operator missing in filter part '${trimmed}'.")
                } else {
                    if (!validOps.contains(op.toUpperCase())) {
                        throw new IllegalArgumentException("Invalid operator '${op}' in filter part '${trimmed}'. Valid operators are: ${validOps.join(', ')}.")
                    } else {
                        if (opMap.containsKey(op)) {
                            op = opMap[op] // Map to canonical form
                        } else {
                            op = op.toUpperCase() // Ensure it's in uppercase
                        }
                    }
                }

                if (!value || (multiValueOps.contains(op.toUpperCase()) && !highValue)) {
                    throw new IllegalArgumentException("Value(s) missing in filter part '${trimmed}'.")
                }

                if (value) {
                    if (value.startsWith("'") && value.endsWith("'")) {
                        value = value.substring(1, value.length() - 1) // Remove surrounding quotes
                    } else {
                        throw new IllegalArgumentException("Value '${value}' in filter part '${trimmed}' must be enclosed in single quotes.")
                    }
                }

                if (multiValueOps.contains(op.toUpperCase())) {
                    if (highValue.startsWith("'") && highValue.endsWith("'")) {
                        highValue = highValue.substring(1, highValue.length() - 1) // Remove surrounding quotes
                    } else {
                        throw new IllegalArgumentException("High value '${highValue}' in filter part '${trimmed}' must be enclosed in single quotes.")
                    }
                }

                xml.item {
                    FIELDNAME(field)
                    SIGN("") // Assuming SIGN is not used, set to empty
                    OPT(op)
                    LOW(value)
                    HIGH(highValue)
                }
            }
            return writer.toString()
}

// Splits the input string by spaces, but ignores spaces inside single quotes
def splitOutsideQuotes(String input) {
    def result = []
    def current = new StringBuilder()
    boolean inQuotes = false

    for (int i = 0; i < input.length(); i++) {
        char c = input.charAt(i)
        if (c == '\'') {
            // Toggle inQuotes flag when encountering a single quote
            inQuotes = !inQuotes
            current.append(c)
        } else if (c == ' ' && !inQuotes) {
            // If not inside quotes, split at space
            if (current.length() > 0) {
                result << current.toString()
                current.setLength(0)
            }
        } else {
            // Append character to current token
            current.append(c)
        }
    }
    // Add the last token if present
    if (current.length() > 0) {
        result << current.toString()
    }
    return result
}
