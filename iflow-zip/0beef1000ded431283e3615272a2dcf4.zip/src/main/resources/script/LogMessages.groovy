import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	// Get the messageLogFactory and the FetchMessages property 
    def properties = message.getProperties();
	String initMessages = properties.get("InitMessages") ?: '';
    // Log and format the ERPReadInitMessages attachment
    if(initMessages != ''){
        def messageLog = messageLogFactory.getMessageLog(message);
        if(messageLog != null){      
                messageLog.addAttachmentAsString('ERPReadInitMessages', "<Messages>" + initMessages + "</Messages>", 'text/XML')     
        }
    }
    
	return message;
}



