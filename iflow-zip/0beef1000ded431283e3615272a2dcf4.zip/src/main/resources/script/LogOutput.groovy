import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    String QueryInitOutput = message.getBody(String);
	    messageLog.addAttachmentAsString('InitOutput', QueryInitOutput, 'text/xml');
	}
	
	return message;
}