import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    String QueryInitInput = message.getBody(String);
	    messageLog.addAttachmentAsString('InitInput', QueryInitInput, 'text/xml');
	}
	
	return message;
}