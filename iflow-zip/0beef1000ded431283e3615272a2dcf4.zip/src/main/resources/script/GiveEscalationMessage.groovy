import com.sap.gateway.ip.core.customdev.util.Message;

def Message giveEscalationMessage(Message message) {
    //Throw a custom exception and set an escalation message based on status and the existence of Init messages
    def messageLog = messageLogFactory.getMessageLog(message);
    String InitMessages = message.getProperty('InitMessages') ?: '';

    if (messageLog != null) {
        String status = getStatus(message)
        String escalationMessage = "There was a error during the read process check the logs"
        if (InitMessages != '') {
            try {
                //Expectation is that the status is the worst one so we rethrow the worst message type
                escalationMessage = getFirstInitMessageWithTypeMatchingStatus(message, status)
            }
            catch (Exception e) {
                throw new Exception(e.getMessage());
            }
            throw new InitException(escalationMessage);
        } else {
            
            messageLog.addCustomHeaderProperty("Escalation message", escalationMessage);
            throw new InitException(escalationMessage);
        }

    }

    return message;
}

def String getStatus(Message message) {
    //Returns the status of the iflow property has a higher priority compared to body
    String status = message.getProperty('Status') ?: ''
    if (status != '') {
        return status
    } else {
        def parsedBody = new XmlSlurper().parse(message.getBody(java.io.Reader));
        return parsedBody?.@Status?.text()
    }
}

def String getFirstInitMessageWithTypeMatchingStatus(Message message, String status) {
    //Get the first message with the given type
    def parsedInitMessages = new XmlSlurper().parseText("<Messages>" + (message.getProperty('InitMessages') as String)  + "</Messages>")
    def firstInitMessageWithTypeMatchingStatus = parsedInitMessages?.'**'?.find { it -> it.name() == 'Message' && it.@Type.text() == status && it.text() != "" }

    return firstInitMessageWithTypeMatchingStatus.text()
}

public class InitException extends Exception {
    //Custom exception for Init
    public InitException(String message) {
        super(message);
    }
}