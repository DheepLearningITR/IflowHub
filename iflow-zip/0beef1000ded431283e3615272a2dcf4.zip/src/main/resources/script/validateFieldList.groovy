import groovy.util.XmlSlurper;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message validateFieldList(Message message) {
    // Get the message body as a string
    def xml = message.getBody().toString()

    // Parse the XML
    def parsedXml = new XmlSlurper().parseText(xml)
    
    // Create lists to store field names, lengths, types and supported operators
    def fieldNamesList = []
    def fieldLengthsList = []
    def fieldTypesList = []
    def equalSupportedList = []
    def betweenSupportedList = []
    def patternSupportedList = []
    
    parsedXml.'**'.findAll { it.name() == 'item' }.each { item ->
        def fieldName = item.NAME.text()
        def fieldLength = item.OUTPUTLENG.text()
        def fieldType = item.TYPE.text()
        def equalSupported = item.SEL_EQUAL.text()
        def betweenSupported = item.SEL_BETWEEN.text()
        def patternSupported = item.SEL_PATTERN.text()
        
        if (fieldName && fieldLength) {
            fieldLengthsList << "${fieldName}:${fieldLength}"
        }
        if (fieldName && fieldType) {
            fieldTypesList << "${fieldName}:${fieldType}"
        }
        
        if (fieldName) {
            fieldNamesList << fieldName
        }
        
        if (fieldName && equalSupported) {
            equalSupportedList << fieldName
        }
        
        if (fieldName && betweenSupported) {
            betweenSupportedList << fieldName
        }
        
        if (fieldName && patternSupported) {
            patternSupportedList << fieldName
        }
    }
    
    // Join the lists into strings
    def fieldLengths = fieldLengthsList.join(';')
    def fieldTypes = fieldTypesList.join(';')
    def fieldNames = fieldNamesList.join(';')
    
    // Get the requested fields and filters
    def requestedFields = message.getProperty('RequestedFieldsString')
    def filtersTable = message.getProperty('FiltersTable')
    
    if (requestedFields) {
        def requestedFieldsMap = requestedFields.split(',').collectEntries() { it -> [it.trim(), ""]  }

        List<String> requestedFieldsList = []

        fieldNames.split(";").each {it ->
            if(requestedFieldsMap.containsKey(it)){
                requestedFieldsList.add(it)
            }
        }
        
        // Convert the field maps to lists for easier manipulation
        def fieldLengthsMap = fieldLengths.split(';').collectEntries { entry ->
            def parts = entry.split(':')
            [(parts[0]) : parts[1]]
        }
        def fieldTypesMap = fieldTypes.split(';').collectEntries { entry ->
            def parts = entry.split(':')
            [(parts[0]) : parts[1]]
        }
        
        // Check if all requested fields are present in both maps
        def missingFields = []
        requestedFieldsList.each { field ->
            if (!fieldLengthsMap.containsKey(field)) {
                missingFields << " Couldn't find Field Lenght information for Requested Field: ${field}"
            }
            if (!fieldTypesMap.containsKey(field)) {
                missingFields << " Couldn't find Field Type information for Requested Field: ${field}"
            }
        }
        if (missingFields) {
            throw new Exception(missingFields.join('; '))
        }
        
        // Reduce the field maps to include only the requested fields
        fieldLengths = requestedFieldsList.collect { field -> "${field}:${fieldLengthsMap[field]}" }.join(';')
        fieldTypes = requestedFieldsList.collect { field -> "${field}:${fieldTypesMap[field]}" }.join(';')
        fieldNames = requestedFieldsList.join(';')
    }
    
    if (filtersTable) {
        def notSupportedList = []
        def wrappedFiltersTable = "<items>\n${filtersTable}\n</items>"
        def filterXml = new XmlParser().parseText(wrappedFiltersTable)
        def filterList = filterXml.item.collect { item ->
            [
                FIELDNAME: item.FIELDNAME.text(),
                OPT: item.OPT.text()
            ]
        }
        filterList.each { item ->
            if (item.OPT == 'EQ' || item.OPT == 'NE') {
                if (!equalSupportedList.contains(item.FIELDNAME)) {
                    notSupportedList << " Operator ${item.OPT} is not supported for ${item.FIELDNAME} field."
                }
            }
            else if (item.OPT == 'BT' || item.OPT == 'NB') {
                if (!betweenSupportedList.contains(item.FIELDNAME)) {
                    notSupportedList << " Operator ${item.OPT} is not supported for ${item.FIELDNAME} field."
                }
            }
            else if (item.OPT == 'CP' || item.OPT == 'NP') {
                if (!patternSupportedList.contains(item.FIELDNAME)) {
                    notSupportedList << " Operator ${item.OPT} is not supported for ${item.FIELDNAME} field."
                }
            }
            else {
                throw new Exception("Operator '${item.OPT}' is not supported.")
            }
        }
        if (notSupportedList) {
            throw new Exception(notSupportedList.join('; '))
        }
    }
    
    // Set the field strings as properties
    message.setProperty('FieldLengths', fieldLengths)
    message.setProperty('FieldTypes', fieldTypes)
    message.setProperty('RequestedFieldsString', fieldNames)
    message.setProperty('EqualSupported', equalSupportedList)
    
    return message
}