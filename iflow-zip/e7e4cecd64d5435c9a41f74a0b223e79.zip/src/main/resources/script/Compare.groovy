import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
def Message processData(Message message) {
 def body = message.getBody(java.lang.String) as String;
 def query = new XmlSlurper().parseText(body);
 String newJson="[ ]";
 def jsonParser = new JsonSlurper();
 def newJsonObjectDelete = jsonParser.parseText(newJson);
 def newJsonObjectUpdate = jsonParser.parseText(newJson);
 query.IDOC.E101CRMXIF_IBASE.E101MXIF_IBASE_COMPONENT_XT.E101CRMXIF_IBASE_COMPONENT.each{
   if(it.OBJECT_TASK.text()=="U")
    {     
        if(it.OBJECT_TYPE.text()=="0030") 
          {
            String nullString="null";
            String object='{ '+'''"externalId" : "'''+it.PRODUCT_ID.text()+'''","parentId" : '''+nullString+'}'; 
            def jsonObject= jsonParser.parseText(object);
            newJsonObjectUpdate.add(jsonObject);
          }
         String object='{ '+'''"externalId" : "'''+it.INSTANCE.text()+'''"}'''; 
         def jsonObject=jsonParser.parseText(object);
         newJsonObjectDelete.add(jsonObject); 
    }
 }
        message.setProperty("DeleteData",newJsonObjectDelete );
        message.setBody(JsonOutput.toJson(newJsonObjectUpdate));
 return message;
}