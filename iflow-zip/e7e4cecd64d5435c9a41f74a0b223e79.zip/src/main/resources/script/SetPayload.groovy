import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
def Message processData(Message message) {
 map=message.getProperties();
 def payload=map.get("DeleteData");
 message.setBody(JsonOutput.toJson( payload));
 return message;
}