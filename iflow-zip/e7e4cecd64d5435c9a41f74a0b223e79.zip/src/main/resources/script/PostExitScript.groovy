import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.ArrayList;
def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String);
    body='''{ "EQUIPMENT" :'''+body+'''}''';
    message.setBody(body);
    return message;
}