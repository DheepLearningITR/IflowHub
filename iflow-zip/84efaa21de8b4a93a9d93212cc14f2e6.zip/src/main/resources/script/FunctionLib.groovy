import com.sap.it.api.mapping.*;


def String getIntValue(String value){
	return Integer.parseInt(value)
}


def String getProperty(String p1, MappingContext context){
	return context.getProperty(p1);
}

def String generateUUID(String value){
	return UUID.randomUUID().toString()
}

def String generateMessageHeaderUUID(String value, MappingContext context){
    def messageId = UUID.randomUUID().toString()
    context.setProperty ("p_msg_header_id", messageId)
	return messageId
}
