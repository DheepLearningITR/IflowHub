import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput


def Message enrichJsonPayload(Message message) {
  //Body 
  def body = message.getBody(String);

  JsonSlurper slurper = new JsonSlurper()
  Map parsedJson = slurper.parseText(body)

  parsedJson.messageRequests.each { request ->
        def requestBody = request.body
        requestBody.parties.each { party ->
            if (party.isMain) {
                party.isMain = Boolean.parseBoolean(party.isMain)
            }
        }
        requestBody.priceElements.each { element ->
           processPriceElement(element)
        }
        requestBody.items.each { item ->
            item.lineNumber = Integer.parseInt(item.lineNumber)
            item.priceElements.each { element ->
                processPriceElement(element)
            }
        }
    }
  def respbody = JsonOutput.toJson(parsedJson)
  message.setBody(respbody)
  return message;
}

def Object processPriceElement(Object priceElement ){
	priceElement.isManuallyChanged = convertToBoolean(priceElement.isManuallyChanged)
	priceElement.isDeleteEnabled = convertToBoolean(priceElement.isDeleteEnabled)
	priceElement.isEffective = !convertToBoolean(priceElement.isEffective)
	priceElement.isGroupedIndicator = convertToBoolean(priceElement.isGroupedIndicator)
	priceElement.isRateDenominatorUpdateEnabled = convertToBoolean(priceElement.isRateDenominatorUpdateEnabled)
	priceElement.isRateNumeratorUpdateEnabled = convertToBoolean(priceElement.isRateNumeratorUpdateEnabled)
	priceElement.isViewAuthorizationSufficient = convertToBoolean(priceElement.isViewAuthorizationSufficient)
	priceElement.isEditAuthorizationSufficient = convertToBoolean(priceElement.isEditAuthorizationSufficient)
}

def Boolean convertToBoolean(String value){
  return value == 'X'
}

def Message setMonitoringIdentifiers(Message message) {
    
    message.setHeader("SAP_ApplicationID", message.getHeaders().get("SapMessageIdEx").toLowerCase())
    
	def messageLog = messageLogFactory.getMessageLog(message)
	if(messageLog != null){

		def idocNo = message.getHeaders().get("SapIDocTransferId");		
		if(idocNo!=null){
			messageLog.addCustomHeaderProperty("IDoc Number", idocNo)		
        }
	}
	return message
}