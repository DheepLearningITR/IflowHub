import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def cbrAttributeType = message.getProperties().get("cbrAttributeType");
		if(cbrAttributeType){
			messageLog.addCustomHeaderProperty("cbr_AttributeType", cbrAttributeType);		
        }
	}
	return message;
}

