import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext

def String generateGuid(String arg1){
	return UUID.randomUUID().toString()
}

def String generateUuid(String arg1){
	return UUID.randomUUID().toString()
}


def String getCompanyDisplayIdPrefix(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty("CompanyCodePrefix");
    return propertyValue;
}

def String getDisplayIdPrefix(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty(propertyName);
    return propertyValue;
}



def String getSalesGroupIdPrefix(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty("SalesGroupPrefix");
    return propertyValue;
}

def String getSalesOfficeDisplayIdPrefix(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty("SalesOfficePrefix");
    return propertyValue;
}

