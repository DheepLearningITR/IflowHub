import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext



def String generateGuid(String arg1){
	return UUID.randomUUID().toString()
}

def String generateUuid(String arg1){
	return UUID.randomUUID().toString()
}


def String getCompanyDisplayIdPrefix(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty("CompanyCodePrefix");
    return propertyValue;
}

def String getDisplayIdPrefix(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty(propertyName);
    return propertyValue;
}

def String getLanguageCode(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty("LanguageCode");
    return propertyValue;
}

def String getMessageId(String p1, MappingContext context){
    String messageId = context.getHeader("SapMessageIdEx")
    return messageId
}

def String getSalesGroupIdPrefix(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty("SalesGroupPrefix");
    return propertyValue;
}

def String getSalesOfficeDisplayIdPrefix(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty("SalesOfficePrefix");
    return propertyValue;
}
    
