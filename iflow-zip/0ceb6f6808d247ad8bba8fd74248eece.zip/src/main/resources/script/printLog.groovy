package share.odata

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;


def Message processData(Message message) {
    //Body

    //Headers
    def headers = message.getHeaders() as String
    def body = message.getBody(java.lang.String) as String

    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null)
    {
        def properties = message.getProperties()
        logTitle = properties.getOrDefault('logTitle', '')
        messageLog.addAttachmentAsString("Log ${logTitle + ' '}payload:", body, "text/plain");
        messageLog.addAttachmentAsString("Log ${logTitle + ' '}headers:", headers, "text/plain");
    }

    return message;
}
