import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    // Parse the incoming JSON payload
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def jsonData = jsonSlurper.parseText(body)

    // Initialize a list to hold the collected data
    def collectedData = []

    // Iterate through the "data" array
    jsonData.data.each { entry ->
        def id = entry.id
        entry.items.each { item ->
            def itemData = [
                    id: id,
                    item_id: item.item_id,
                    quantity: item.quantity
            ]
            collectedData.add(itemData)
        }
    }

    // Wrap the collected data in an object
    def wrappedJson = [ items: collectedData ]

    // Convert to JSON string
    def collectedJson = JsonOutput.toJson(wrappedJson)

    // Set the result as a property
    message.setProperty("CollectedData", collectedJson)

    return message
}
