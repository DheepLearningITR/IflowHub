import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser
import groovy.util.XmlNodePrinter
import groovy.json.JsonSlurper
import java.io.StringWriter

def Message processData(Message message) {
    def reader = message.getBody(java.io.Reader)
    def xml = new XmlParser().parse(reader)

    // Get replicated returns property
    def replicatedRaw = message.getProperty("bigCommerceOrderAlreadyReplicatedReturns") ?: "{}"

    // Parse the property to extract replicated BigCommerceReturnIDs
    def replicatedIds = [] as Set
    try {
        def parsed = new JsonSlurper().parseText(replicatedRaw)
        if (parsed instanceof Map && parsed.returns instanceof List) {
            replicatedIds = parsed.returns*.bigCommerceReturnID as Set
        }
    } catch (ignored) {
        // Leave replicatedIds as empty
    }

    // Filter out <Return> nodes with matching BigCommerceReturnID
    xml.Return.findAll { returnNode ->
        def id = returnNode.BigCommerceReturnID?.text()
        replicatedIds.contains(id)
    }.each {
        xml.remove(it)
    }

    // Convert back to string
    def writer = new StringWriter()
    def printer = new XmlNodePrinter(new PrintWriter(writer))
    printer.preserveWhitespace = true
    printer.print(xml)

    message.setBody(writer.toString())
    return message
}
