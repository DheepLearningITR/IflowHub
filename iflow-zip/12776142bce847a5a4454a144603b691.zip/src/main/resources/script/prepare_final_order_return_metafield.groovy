import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def slurper = new JsonSlurper()

    // Default to empty JSON objects if properties are not set
    def replicatedRaw = message.getProperty("bigCommerceOrderAlreadyReplicatedReturns") ?: "{}"
    def linkedRaw = message.getProperty("linkedReturns") ?: "{}"

    def replicatedReturns = []
    def linkedReturns = []

    // Parse replicated returns
    try {
        def parsedReplicated = slurper.parseText(replicatedRaw)
        if (parsedReplicated instanceof Map && parsedReplicated.returns instanceof List) {
            replicatedReturns = parsedReplicated.returns
        }
    } catch (ignored) {}

    // Parse linked returns
    try {
        def parsedLinked = slurper.parseText(linkedRaw)
        if (parsedLinked instanceof Map && parsedLinked.returns instanceof List) {
            linkedReturns = parsedLinked.returns
        }
    } catch (ignored) {}

    // Merge both lists
    def combinedReturns = []
    combinedReturns.addAll(linkedReturns)
    combinedReturns.addAll(replicatedReturns)

    // Build final value structure
    def finalValueObject = [returns: combinedReturns]
    def finalValueString = JsonOutput.toJson(finalValueObject)

    // Build result
    def result = [
            permission_set: "read",
            namespace: "bigCommerce_accelerator",
            key: "s_4hana_cloud_order_returns",
            value: finalValueString
    ]

    // Set body
    message.setBody(JsonOutput.toJson(result))
    return message
}
