import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def json = new JsonSlurper().parse(body)

    json.data.each { metafieldsNode ->
        def key = metafieldsNode.key
        def value = metafieldsNode.value

        if (key == "s_4hana_cloud_order_id") {
            message.setProperty("S4HanaCloudOrderID", value)
        }

        if (key == "s_4hana_cloud_order_returns") {
            message.setProperty("orderReturnsMetafield", value)
            message.setProperty("order_return_metafield_id", metafieldsNode.id)

            try {
                // Parse the stringified array
                def parsedArray = new JsonSlurper().parseText(value)
                message.setProperty("bigCommerceOrderAlreadyReplicatedReturns", value)

                if (parsedArray && parsedArray[0]) {
                    def mapString = parsedArray[0].replaceAll(/[{}]/, "") // remove braces
                    def returnMap = mapString.split(',').collectEntries {
                        def (k, v) = it.split('=').collect { s -> s.trim() }
                        [(k): v]
                    }

                    def bigCommerceReturnID = returnMap["bigCommerceReturnID"]
                    def s4HanaCloudReturnID = returnMap["s4HanaCloudReturnID"]

                    message.setProperty("BigCommerceReturnID", bigCommerceReturnID)
                    message.setProperty("S4HanaCloudReturnID", s4HanaCloudReturnID)
                }
            } catch (Exception e) {
                message.setProperty("orderReturnsParseError", e.getMessage())
            }
        }
    }

    return message
}
