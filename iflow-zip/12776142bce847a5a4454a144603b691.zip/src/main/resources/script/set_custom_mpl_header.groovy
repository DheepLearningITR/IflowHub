import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {

        def bigCommerceOrderId = message.getProperty("bigCommerce_order_id") as String;
        if (bigCommerceOrderId != null && !bigCommerceOrderId.isEmpty()) {
            messageLog.addCustomHeaderProperty("Replicated Order Return for Order with ID ", bigCommerceOrderId);
        }
    }
    return message;
}