import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Parse the JSON payload for products
    def productPayload = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def products = jsonSlurper.parseText(productPayload)

    // Get the existing CollectedData property (JSON format)
    def collectedDataJson = message.getProperty("CollectedData")
    def collectedWrapper = jsonSlurper.parseText(collectedDataJson)
    def collectedData = collectedWrapper.items // Access the wrapped items array

    // Iterate over all products in the JSON payload
    products.each { product ->
        def productId = product.id.toString()
        def productSku = product.sku.toString()

        // Find the matching item and add SKU
        collectedData.each { item ->
            if (item.item_id.toString() == productId) {
                item.sku = productSku
            }
        }
    }

    // Wrap the updated list again
    def updatedWrapper = [ items: collectedData ]
    def updatedCollectedDataJson = JsonOutput.toJson(updatedWrapper)

    // Update both the property and the body
    message.setProperty("CollectedData", updatedCollectedDataJson)
    message.setBody(updatedCollectedDataJson)

    return message
}
