import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

Message processData(Message message) {
    // Parse XML payload
    def reader = message.getBody(java.io.Reader)
    println(reader)
    def xml = new XmlParser().parse(reader)

    // Initialize current linkedReturns from property
    def currentJson = message.getProperty("linkedReturns") ?: "{}"
    def currentLinkedReturns = [returns: []]

    try {
        def parsed = new JsonSlurper().parseText(currentJson)
        if (parsed instanceof Map && parsed.returns instanceof List) {
            currentLinkedReturns.returns.addAll(parsed.returns)
        }
    } catch (ignored) {
        // Use default empty structure
    }

    // Extract new Return entries from XML and append
    xml.Return.each { returnNode ->
        def bigID = returnNode.BigCommerceReturnID?.text()
        def s4ID = returnNode.S4HanaCloudReturnID?.text()
        if (bigID && s4ID) {
            currentLinkedReturns.returns << [
                    bigCommerceReturnID : bigID,
                    s4HanaCloudReturnID : s4ID
            ]
        }
    }

    // Set updated linkedReturns back to property
    message.setProperty("linkedReturns", JsonOutput.toJson(currentLinkedReturns))

    return message
}
