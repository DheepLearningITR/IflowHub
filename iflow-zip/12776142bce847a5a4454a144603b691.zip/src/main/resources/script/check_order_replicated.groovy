import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def json = new JsonSlurper().parse(body)

    def found = json.data.any { it.key == 's_4hana_cloud_order_id' }
    message.setProperty("hasOrderIdKey", found)

    return message
}
