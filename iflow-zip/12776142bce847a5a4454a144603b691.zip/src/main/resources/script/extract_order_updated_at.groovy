import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def root = new XmlSlurper().parseText(body)
    def orderNode = root.order

    def currentProcessedBigCommerceOrderUpdatedAtTimestamp = orderNode.date_modified;

    if (currentProcessedBigCommerceOrderUpdatedAtTimestamp && currentProcessedBigCommerceOrderUpdatedAtTimestamp.text()) {
        message.setProperty("currentProcessedBigCommerceOrderUpdatedAtTimestamp", currentProcessedBigCommerceOrderUpdatedAtTimestamp)
    }

    return message
}