import com.sap.gateway.ip.core.customdev.util.Message
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def currentExecutionLastProcessedBigCommerceOrderUpdatedAtTimestamp = message.getProperty("current_execution_last_processed_bigCommerce_order_updated_at_timestamp")

    def body = message.getBody(java.io.Reader)
    if (body == null) {
        return message
    }

    def xml = new XmlSlurper().parse(body)
    if (xml == null || xml.order == null || xml.order.size() == 0) {
        return message
    }

    ZonedDateTime latestProcessedBigCommerceOrderUpdatedAt = null
    xml.order.each { order ->
        def updatedAtString = order.updatedAt.text().replace("\n", " ")
        if (updatedAtString != null && !updatedAtString.trim().isEmpty()) {
            def customFormatter = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy HH:mm:ss Z")
            ZonedDateTime currentIteratedBigCommerceOrderUpdatedAt = ZonedDateTime.parse(updatedAtString, customFormatter)
            if (latestProcessedBigCommerceOrderUpdatedAt == null || currentIteratedBigCommerceOrderUpdatedAt.isAfter(latestProcessedBigCommerceOrderUpdatedAt)) {
                latestProcessedBigCommerceOrderUpdatedAt = currentIteratedBigCommerceOrderUpdatedAt
            }
        }
    }

    if (latestProcessedBigCommerceOrderUpdatedAt != null) {
        if (currentExecutionLastProcessedBigCommerceOrderUpdatedAtTimestamp != null && !currentExecutionLastProcessedBigCommerceOrderUpdatedAtTimestamp.trim().isEmpty()) {
            ZonedDateTime currentExecutionLastProcessedBigCommerceOrderUpdatedAtTime = ZonedDateTime.parse(currentExecutionLastProcessedBigCommerceOrderUpdatedAtTimestamp, DateTimeFormatter.ISO_ZONED_DATE_TIME)
            if (latestProcessedBigCommerceOrderUpdatedAt.isAfter(currentExecutionLastProcessedBigCommerceOrderUpdatedAtTime)) {
                message.setProperty("current_execution_last_processed_bigCommerce_order_updated_at_timestamp", latestProcessedBigCommerceOrderUpdatedAt.toString())
            }
        } else {
            message.setProperty("current_execution_last_processed_bigCommerce_order_updated_at_timestamp", latestProcessedBigCommerceOrderUpdatedAt.toString())
        }
    }

    return message
}