import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Retrieve properties
    def map = message.getProperties();
    def TotalPages = map.get("TotalPages") as Integer;  // Explicitly cast to Integer
    def PageNumber = map.get("PageNumber") as Integer;  // Explicitly cast to Integer
    
    // Increment PageNumber
    def pgnr = PageNumber + 1;
    message.setProperty("PageNumber", pgnr);
    
    // Check if pgnr exceeds totalpages
    if (pgnr>TotalPages) 
    {
        message.setProperty("Loop", "STOP");
    } else 
    {
        message.setProperty("Loop", "NEXT");
    }
    
    return message;
}