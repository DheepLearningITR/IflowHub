/*
 * =============================================================================
 * Logic Details 
 * =============================================================================
 * This script prepares CSV data for integration in SAP Cloud Platform Integration (CPI) by modifying the schema, formatting the body, and setting additional parameters. It takes a message containing CSV data, modifies the schema by replacing "dateTime" with "long", formats the body to conform to CPI requirements, and sets parameters such as primary keys.
 * The main function, processData, retrieves properties such as the schema and primary keys from the message. It then modifies the schema by replacing "dateTime" with "long" and formats the body by replacing newline characters with carriage return + newline (\r\n). It constructs a multipart form-data payload with the modified schema, CSV data, and primary keys, and sets it as the new body of the message.
 * ==============================================================================
*/


import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) {
    //Body 
        def map = message.getProperties();
	   def schema = map.get("schema");
	   def filename = map.get("filename");
	   

	   
	   def primarykeys = map.get("primarykeys");
    //Body 
       def body = message.getBody(String);
      // body = body.replaceAll("\n", "\r\n");
      body = body.replaceAll("\r\n", "\n").replaceAll("\n", "\r\n");
       body = """--cpi\r\nContent-Disposition: form-data; name="schema"\r\n\r\n""" + schema + """\r\n--cpi\r\n""" + """Content-Disposition: form-data; name="files"; filename=\""""+ filename +"""\"\r\nContent-Type: text/csv\r\n\r\n""" + body +"""\r\n--cpi\r\nContent-Disposition: form-data; name="primaryKeys"\r\n\r\n""" + primarykeys + """\r\n--cpi--"""

       message.setBody(body);
       return message;
}