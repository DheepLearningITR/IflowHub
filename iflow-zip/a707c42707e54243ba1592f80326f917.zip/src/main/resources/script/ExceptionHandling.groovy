import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def map = message.getProperties()
    def MSDObject = map.get("MSDObject")
    def logException = map.get("ExceptionLogging")
    def ErrorType = map.get("ErrorType")
    def attachID = ""
    def log = ""

    def ex = map.get("CamelExceptionCaught")

    if (messageLog != null) {
        if (ex != null) {
            log = "The MS Dynamics CRM Object '" + MSDObject + "' replication failed due to the following error:" + "\n"
            log = log + "=============================================" + "\n"
            log = log + "Exception Message : " + ex.toString() + "\n"
            log = log + "\n"

            if (ErrorType == "SignavioAPIError") {
                // Check if ex has the method getResponseBody
                if (ex.metaClass.respondsTo(ex, "getResponseBody")) {
                    log = log + "Exception Details: " + ex.getResponseBody()
                } else {
                    log = log + "Exception Details: Unable to retrieve response body. Exception type: " + ex.getClass().getName()
                }
            }

            attachID = "Error Details for MS Dynamics CRM Object '" + MSDObject + "'"

            if (logException != null && logException.equalsIgnoreCase("TRUE")) {
                messageLog.addAttachmentAsString(attachID, log, "text/plain");
            }
        }
    }

    return message;
}