import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) 
{
    def messageLog = messageLogFactory.getMessageLog(message);
    def LogSummary = message.getProperties().get("LogSummary")
    def ExecuteFullLoad = message.getProperties().get("ExecuteFullLoad")
    def AdhocEntity = message.getProperties().get("AdhocService")
    def Entity = message.getProperties().get("Object")

    
    
    def Mode
    def Data
    
    if(ExecuteFullLoad != null && ExecuteFullLoad.equalsIgnoreCase("TRUE"))
    {
        Mode = "Full Load"
    }
    else
    {
        Mode = "Delta Load"
    }
    
    if(AdhocEntity == null || AdhocEntity.equals(""))
    {
        Data = Entity
    }
    else 
    {
        Data = AdhocEntity 
    }
    
    if(messageLog != null)
	{
	     if(LogSummary != null && LogSummary.equalsIgnoreCase("TRUE"))
        {
                def log = "----Summary Report----"+"\n";
                log = log+"========================================="+"\n";
                log = log+"Workday Services configured : "+Data+"\n";
                log = log+"========================================="+"\n"
                log = log+"Execution Mode : "+Mode+"\n"
                log = log+"========================================="

            messageLog.addAttachmentAsString("WorkdayToSignavio_Logs.txt",log, "text/plain");
        }
	}
	return message;
}