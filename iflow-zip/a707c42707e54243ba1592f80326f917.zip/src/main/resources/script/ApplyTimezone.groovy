import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone

def Message processData(Message message) 
{   
    def inputTimezone = TimeZone.getTimeZone("SAPCI_Timezone")  // Source: IST
    def targetTimezoneId = message.getProperty("Workday_Timezone") ?: "UTC"
    def targetTimezone = TimeZone.getTimeZone(targetTimezoneId)

    def last_successful_run = message.getProperty("last_successful_run")
    def adhocStartDate = message.getProperty("Adhoc_StartDate")

    SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    inputFormat.setTimeZone(inputTimezone)

    SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    outputFormat.setTimeZone(targetTimezone)

    // Convert last_successful_run
    if (last_successful_run) {
        Date parsedLastRun = inputFormat.parse(last_successful_run)
        def convertedLastRun = outputFormat.format(parsedLastRun)
        message.setProperty("last_successful_run", convertedLastRun)
    }

    // Convert Adhoc_StartDate
    if (adhocStartDate) {
        Date parsedAdhoc = inputFormat.parse(adhocStartDate)
        def convertedAdhoc = outputFormat.format(parsedAdhoc)
        message.setProperty("Adhoc_StartDate", convertedAdhoc)
    }

    // Add current datetime in target timezone
    def currDateTime = new Date().format("yyyy-MM-dd'T'HH:mm:ss", targetTimezone)
    message.setProperty("CurrentDateTime", currDateTime)

    return message
}