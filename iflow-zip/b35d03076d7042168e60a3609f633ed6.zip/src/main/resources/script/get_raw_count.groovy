import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new groovy.json.JsonSlurper()
    def result = jsonSlurper.parseText(body)
    message.setHeader("Rowcount", result.value.size());
    message.setHeader("Datasource", message.getProperty("data_source"));
    message.setHeader("Objectname", message.getProperty("object_name"));
    message.setHeader("Content-Type", "application/json");
    return message;
}