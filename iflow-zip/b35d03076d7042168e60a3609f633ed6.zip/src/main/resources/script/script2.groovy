import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def body = message.getBody(String.class);
    def headers = message.getHeaders() as String
    def settlementUUID = message.getProperty("settlementUUID");
    def httpMethod = message.getHeader("CamelHttpMethod", String.class);
    def httpStatusCode = message.getHeader("CamelHttpResponseCode", String.class);
    def httpStatusText = message.getHeader("CamelHttpResponseText", String.class);
    def httpUrl = message.getHeader("CamelHttpUrl", String.class);
    
     if (messageLog != null) {
        messageLog.addAttachmentAsString("Response log", httpMethod + " " + httpUrl + " \nStatus: " + httpStatusCode + " " + httpStatusText +
        "\nResponse body: " + body + "\nResponse headers: " + headers, "text/plain");
    }
    return message;
}