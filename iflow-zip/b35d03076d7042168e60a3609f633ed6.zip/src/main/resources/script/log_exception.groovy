import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.msglog.MessageLog

def Message processData(Message message) {
    def map = message.getProperties()
    def ex = map.get('CamelExceptionCaught')
    def retryResponseStatus = '202';
    MessageLog messageLog = messageLogFactory.getMessageLog(message)
    message.setBody(message.getBody())

    if (ex != null) {
        String exName = ex.getClass().getCanonicalName()
        if ('org.apache.camel.component.ahc.AhcOperationFailedException' == exName
                || 'com.sap.it.rt.adapter.http.api.exception.HttpResponseException' == exName) {
            if (ex.getResponseBody() == '503') {
                message.setProperty("SAP_MessageProcessingLogCustomStatus", "RETRY")
                message.setHeader('CamelHttpResponseCode', retryResponseStatus)
            }
        } else {
            if ("java.util.concurrent.TimeoutException" == ex.getClass().getCanonicalName()) {
                message.setProperty("SAP_MessageProcessingLogCustomStatus", "RETRY")
                message.setHeader('CamelHttpResponseCode', retryResponseStatus)
            }
        }
    }

    return message
}
