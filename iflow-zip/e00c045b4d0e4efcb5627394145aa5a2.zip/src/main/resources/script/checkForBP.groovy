import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message){
    
    def body = message.getBody(java.lang.String) as String;
    def map = message.getProperties();
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    
   if(jsonObject.data[0])
   {

   boolean isKeyPresent_BP = jsonObject.get("data").get(0).keySet().contains("businessPartner");
    
    
    if(isKeyPresent_BP){
        message.setProperty("resource","BusinessPartner");
        message.setProperty("dto","BusinessPartner.22");
    }
    else
    {
    message.setProperty("checkContact","true");
    }
    return message;
    
   }
   else
   
   message.setProperty("checkContact","true");
   return message;
}
