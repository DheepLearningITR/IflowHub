import com.sap.it.api.mapping.*;

def String checkLeadingSystem(String LeadingSystem, MappingContext context){
   String value = context.getProperty(LeadingSystem);
    if(value)
    return true;
    else
    return false;

}