import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.*;

def Message processData(Message message) {
//get Body
	def body = message.getBody(java.lang.String) as String; 
//replaceMultimap tag

	body = body.replaceAll('<error xmlns="http://schemas.microsoft.com/ado/2007/08/dataservices/metadata">', "<error>");
	
//set body
	message.setBody(body); 
	
	return message;
}