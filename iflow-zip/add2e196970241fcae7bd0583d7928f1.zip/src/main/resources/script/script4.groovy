import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.transform.Synchronized
import com.sap.it.api.asdk.datastore.*
import com.sap.it.api.asdk.runtime.*

    @Synchronized
	def Message processData(Message message) {
		//Body 
		def body = message.getBody() as String;
		map = message.getProperties();
		def orderId = map.get("orderId");


		def order = new XmlSlurper().parseText(body);

		order.orderLines.each {line ->
				def i = line.lineNumber;

			def service = new Factory(DataStoreService.class).getService()

			if (service != null) {
				def dsEntry = service.get("upscale", orderId + '_' + i);
				if (dsEntry == null) {
					def payload = "<?xml version='1.0' encoding='UTF-8'?><orderline><id>" + orderId + '_' + i + "</id><status>received</status></orderline>"

					def dBean = new DataBean()
					dBean.setDataAsArray(payload.getBytes("UTF-8"))

					//Define datatore name and entry id
					def dConfig = new DataConfig()
					dConfig.setStoreName("upscale")
					dConfig.setId(orderId + '_' + i)

					//Write to data store
					result = service.put(dBean, dConfig)
					
					firstEntry = message.getProperty("firstEntry");
					if(!firstEntry.equals("false"))
					{
					    message.setProperty("firstEntry", "true");
					}
					return message;
				} else {
					def result = new String(dsEntry.getDataAsArray())
					if (result == null || result.isEmpty()) {
						def payload = "<?xml version='1.0' encoding='UTF-8'?><orderline><id>" + orderId + '_' + i + "</id><status>received</status></orderline>"

						def dBean = new DataBean()
						dBean.setDataAsArray(payload.getBytes("UTF-8"))

						//Define datatore name and entry id
						def dConfig = new DataConfig()
						dConfig.setStoreName("upscale")
						dConfig.setId(orderId + '_' + i)

						//Write to data store
						result = service.put(dBean, dConfig)
						firstEntry = message.getProperty("firstEntry");
					if(!firstEntry.equals("false"))
					{
					    message.setProperty("firstEntry", "true");
					}
						return message;

					} else {
						message.setProperty("firstEntry", "false");
						line.replaceNode {};
					}

				}

			}

		}

		message.setBody(XmlUtil.serialize(order));
		return message;


	}