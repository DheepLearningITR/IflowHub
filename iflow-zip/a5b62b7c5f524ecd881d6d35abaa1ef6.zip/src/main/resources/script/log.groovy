import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.transform.Field;
import groovy.json.JsonOutput;
import groovy.xml.XmlUtil;

@Field String TRANSLATED_XML_PAYLOAD = 'Inbound POST Exit XML';
@Field String IFLOW_JSON_EXCEPTION_RESPONSE = 'iFlow Error Response JSON';

def Message logXmlPayload(Message message) {
    return log(TRANSLATED_XML_PAYLOAD, true, message);
}

def Message log(String title, boolean isXML, Message message) {

    def body = message.getBody(java.lang.String) as String;
    def headers = message.getHeaders() as Map<String, Object>;
    def properties = message.getProperties() as Map<String, Object>;

    def propertiesAsString ="\n";
    properties.each{ iterator -> propertiesAsString = propertiesAsString + "${iterator}" + "\n" };

    def headersAsString ="\n";
    headers.each{ iterator -> headersAsString = headersAsString + "${iterator}" + "\n" };

    def messageLog = messageLogFactory.getMessageLog(message);
    def prettyPrintedBodyString = "\n";

    if((messageLog != null) && (body != "")) {
        if (isXML) {
            prettyPrintedBodyString = XmlUtil.serialize(body);
        }
        else {
            prettyPrintedBodyString = JsonOutput.prettyPrint(body);
        }
    }

    messageLog.addAttachmentAsString(title , "\n Properties \n ----------   \n" + propertiesAsString +
            "\n Headers \n ----------   \n" + headersAsString +
            "\n Body \n ----------  \n\n" + prettyPrintedBodyString, "text/plain");

    return message;
}

def Message logExceptionDetails(Message message) {
    def properties = message.getProperties();

    String errorMessage = "";
    def exceptionProperty = properties.get("CamelExceptionCaught");

    // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
    if (exceptionProperty.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
        errorMessage = exceptionProperty.getResponseBody();
    }

    if (!errorMessage.trim()) {
        errorMessage = exceptionProperty.message;
    }

    def headers = message.getHeaders() as Map<String, Object>;

    def propertiesAsString ="\n";
    properties.each{ iterator -> propertiesAsString = propertiesAsString + "${iterator}" + "\n" };
    def headersAsString ="\n";
    headers.each{ iterator -> headersAsString = headersAsString + "${iterator}" + "\n" };

    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.addAttachmentAsString(IFLOW_JSON_EXCEPTION_RESPONSE ,
            "\n Properties \n ----------   \n" + propertiesAsString +
            "\n Headers \n ----------   \n" + headersAsString +
            "\n Exception \n ----------  \n\n" + errorMessage, "text/plain");

    return message;
}