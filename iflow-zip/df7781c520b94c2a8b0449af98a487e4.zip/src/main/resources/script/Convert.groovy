import com.sap.it.api.mapping.*;

def String addzeroes(String val, String stringLen){

if(val != ""){
    

def strLen = val.toString().size()
expectedLen = stringLen.toInteger() - strLen.toInteger()
for(i = 0; i<=expectedLen-1;i++)
{
	val = "0" + val; 
}
}

	return val; 
}



def String convertDate(String d){

if(d.size() == 10){
    def values = d.tokenize( '.' );
    d = values[2] + values[1] + values[0];
}


return d;

}


