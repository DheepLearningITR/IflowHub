/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.util.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message) {

        String timestamp = (new Date().time / 1000).intValue().toString();
        message.setProperty("timestamp", timestamp);
        
        String content = message.getBody(java.lang.String) as String;
        def messageLog = messageLogFactory.getMessageLog(message);   
        messageLog.addAttachmentAsString("content", content, "text/plain");
        //Properties 
        map = message.getProperties();
        companyTaxNo = map.get("buyerTaxNo");
        def rootNode = new XmlParser().parseText(content);
        //Put your final update payload here in the end  
        def finalResult;
        switch(companyTaxNo){
              // Define your company case with your company tax ID
              case 'MockCompanyID':
                   //For fixed value, there should be a value mapping with key '{company tax ID}_{attribute name}, for example, AJ100222017117_note maintained in value mapping 'Baiwang Customized Properties Mapping'.
                   //As the first step to fetch value, you should generate key by companyName + '-' + attribute name
                   def mapkey = companyTaxNo + '_' + 'note';
                   //Then, you can find the value with key by method dynamicValueMap 
                   def noteValue = dynamicValueMap("CustomizedProp", "name", "CustomizedValue","value", mapkey);
                   //Finally, you can update the fix customizated value to the payload
                   def updatedNote = changeHeaderContentWithFixdValue("note", noteValue, rootNode, message);
                   
                   def buyerNameKey = companyTaxNo + '_' + 'buyername';
                   def buyerNameValue = dynamicValueMap("CustomizedProp", "name", "CustomizedValue","value", buyerNameKey);
                   def updatedHeader = changeHeaderContentWithFixdValue("buyername", buyerNameValue, updatedNote, message);
                   
                   def buyerAddressKey = companyTaxNo + '_' + 'buyeraddrtel';
                   def buyerAddressValue = dynamicValueMap("CustomizedProp", "name", "CustomizedValue","value", buyerAddressKey);
                   def updatedHeader1 = changeHeaderContentWithFixdValue("buyeraddrtel", buyerAddressValue, rootNode, message);
                   
                   def matldescKey = companyTaxNo + '_' + 'matldesc';
                   def matldescValue = dynamicValueMap("CustomizedProp", "name", "CustomizedValue","value", matldescKey);
                   finalResult = changeItemContentWithFixdValue("matldesc", matldescValue, updatedHeader1, message);
                  break;
           	default: 
			    break;
        }
        if(finalResult != null){
             calculateItemNumber(finalResult, message);
        }else{
            calculateItemNumber(rootNode, message);
        }
       
        return message;
    
}

//You can update fixed value in VATInvoice.Invoices.Header by following the below logic
//Paramter "attribute" stands for the attribute which will be update while value stands for customized value.
def Node changeHeaderContentWithFixdValue(String attribute, String value, Node rootNode, Message message){
    def originalHeaders = rootNode.Invoices.Header;
	def newHeaders = new NodeList();
		for (Node node : originalHeaders) {
		        switch(attribute){
		             case 'buyername':
		                node.buyername.get(0).setValue(value);
		                newHeaders.add(node);
		                break;
		              case 'buyeraddrtel':
		                node.buyeraddrtel.get(0).setValue(value);
		                newHeaders.add(node);
		                break;
		              case 'note':
		                node.note.get(0).setValue(value);
		                newHeaders.add(node);
		                break;
		        }
		}
	return rootNode;
}

//You can update fixed value in VATInvoice.Invoices.Header.Item by following the below logic
//Paramter "attribute" stands for the attribute which will be update while value stands for customized value.
def Node changeItemContentWithFixdValue(String attribute, String value, Node rootNode, Message message){
    def originalItems = rootNode.Invoices.Header.Item;
	def newItems = new NodeList();
		for (Node node : originalItems) {
		        switch(attribute){
		             case 'matldesc':
		                node.matldesc.get(0).setValue(value);
		                newItems.add(node);
		                break;
		        }
		 }
	return rootNode;
}

//Calculate Item No., which is mandatory for the next step
def calculateItemNumber(Node rootNode, Message message){
    def items = rootNode.Invoices.Header.Item;
    for(int i = 0; i< items.size(); i++){
    def lineNo = i + 1
    def noInfo = '<GTD_ITEM_NMBR>'<<lineNo.toString()<<'</GTD_ITEM_NMBR>\n</Item>'
    def nodeContextWithoutLineNo = XmlUtil.serialize(items.get(i))
    def nodeContextWithLineNo = nodeContextWithoutLineNo.replaceAll('</Item>', noInfo.toString());
    def nodeWithLineNo = new XmlParser().parseText(nodeContextWithLineNo)
    items.set(i, nodeWithLineNo)
    }
    def newRootNode = XmlUtil.serialize(rootNode);
    def messageLog = messageLogFactory.getMessageLog(message);   
    messageLog.addAttachmentAsString("newRootNode result after calculate item number", newRootNode, "text/plain");
    message.setBody(newRootNode);
}


//Fetch value defined in value mapping
def String dynamicValueMap(String sAgency, String sSchema, String tAgency, String tSchema, String key){
    def service = ITApiFactory.getApi(ValueMappingApi.class, null);
    if( service != null) {
    return service.getMappedValue(sAgency, sSchema, key, tAgency, tSchema);
    }
    throw new Exception("Service is null");
    return null;
}


