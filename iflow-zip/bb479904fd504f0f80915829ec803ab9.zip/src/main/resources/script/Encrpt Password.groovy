/*
 The integration developer needs to create the method processData
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties)
    public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.text.SimpleDateFormat

def Message processData(Message message)
{
    def map = message.getProperties();
    String password = map.get("password");
    String salt = map.get("salt");
    String testMode = map.get("testMode");
    
    String encryptedPassword = encrypt(encrypt(password + salt, "md5"), "sha-1");
    String timestamp = (new Date().time / 1000).intValue().toString();
    
    message.setProperty("password", encryptedPassword);
    message.setProperty("timestamp", timestamp);
    
    return message;
}

def String encrypt(String inputText, String algorithmName)
{
    String encryptText = null;
    try {
        MessageDigest m = MessageDigest.getInstance(algorithmName);
        m.update(inputText.getBytes("UTF8"));
        byte[] s = m.digest();
        return hex(s);
    } catch (NoSuchAlgorithmException e) {
        e.printStackTrace();
    } catch (UnsupportedEncodingException e) {
        e.printStackTrace();
    }
    return encryptText;
}

def String hex(byte[] arr) 
{
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < arr.length; ++i) 
    {
        sb.append(Integer.toHexString((arr[i] & 0xFF) | 0x100).substring(1, 3));
    }
        return sb.toString();
}