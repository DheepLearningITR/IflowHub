import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def headers = message.getHeaders() as String;
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties() as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null)
    {
        messageLog.addAttachmentAsString("Log init Payload:", body, "text/plain");
        messageLog.addAttachmentAsString("Log init headers:", headers, "text/plain");
        messageLog.addAttachmentAsString("Log init properties:", properties, "text/plain");
    }
    message.setProperty("payloadBody",body)
    def slurper = new JsonSlurper()
    def text = slurper.parseText(body)
    assert text.settlementId != null
    assert text.items.size() != 0
    return message;
}


def Message logError(Message message) {
    def headers = message.getHeaders() as String;
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties() as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def caught = message.getProperty("CamelExceptionCaught") as String
    if (caught.contains("DuplicateEntryException"))
    {
        message.setHeader("SettlementDuplicateEntryException","true")
    }
    if(messageLog != null)
    {
        messageLog.addAttachmentAsString("Error init Payload:", body, "text/plain");
        messageLog.addAttachmentAsString("Error init headers:", message.getHeaders() as String, "text/plain");
        messageLog.addAttachmentAsString("Error init properties:", properties, "text/plain");
        messageLog.addAttachmentAsString("Error init exception caught:", caught, "text/plain");
    }
    return message;
}
