import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonOutput;
import groovy.xml.XmlUtil;

def Message validate(Message message) {

    def headers = message.getHeaders();
    def properties = message.getProperties();
    
    // Extract specific headers with defaults if necessary
    def cbrJobArchitecture = headers.get("cbrJobArchitecture") ?: "";
    def cbrJobProfileIds = headers.get("cbrJobProfileIds");
    def cbrJobProfileType = headers.get("cbrJobProfileType");
    def sfsfDeactivateAttributes = headers.get("sfsfDeactivateAttributes") ?: "false";
    def sfsfUpdateAttributeTags = headers.get("sfsfUpdateAttributeTags") ?: "true"; //true by default    
    def testRun = headers.get("testRun") ?: "false";
    def sfsfCompanyId = headers.get("sfsfCompanyId");
    def mapCBRCompetency2SFSFTag = headers.get("mapCBRCompetency2SFSFTag") ?: "false";
    def cbrProficiencyTextsEmbedded = headers.get("cbrProficiencyTextsEmbedded") ?: "false";
    def sfsfSkillTypeTags = message.getProperties().get("sfsfSkillTypeTags");
    def sfsfAttributeTag = properties.get("sfsfAttributeTag");
    def sfsfUpdateAttributeTexts = properties.get("sfsfUpdateAttributeTexts") ?: "false";
    
    def cbrLearningOppIds = headers.get("cbrLearningOppIds");
    def cbrLearningOppCourseProvider = headers.get("cbrLearningOppCourseProvider") ?: "";
    def cbrLearningOppState = headers.get("cbrLearningOppState");   
    
    def cbrConfigurationId = headers.get("cbrConfigurationId") ?: ""; //for the curated Skills list
    
    def errors = []; // Unified error list
    
    // Validate IFLOW PARAMETERS --------------------
    def mandatoryParams = [
        "sfsfCompanyId"
    ]
    mandatoryParams.each { key ->
        if (!headers[key]?.trim()) {
            errors.add(["errorCode": "[SAP-IS] MISSING_IFLOW_PARAM", "errorMessage": key]);
        }
    }
    
    def mandatoryHeaders = [];
    if(cbrJobArchitecture==''){
        //job architecture is null: do not fetch jobProfiles, set the related properties to null
        cbrJobProfileType = null;
        cbrJobProfileIds = null;
    }else{
        //mandatory if cbrArchitectureId is filled
        mandatoryHeaders.add('cbrJobProfileType');
    }
    
    if(cbrLearningOppCourseProvider==''){
        //cbrCourse Provider is null: Do not fetch Learning Opps, set the rest of LearningOpp properties to null
	    cbrLearningOppIds = null;
	    cbrLearningOppState = null;
    }else{
        //Learning Opp State is mandatory if Learning Opp Course Provider is filled
	    mandatoryHeaders.add('cbrLearningOppState');
	}
    
    mandatoryHeaders.each { key ->
        if (!headers[key]?.trim()) {
            errors.add(["errorCode": "[SAP-IS] MISSING_HDR", "errorMessage": key]);
        }
    }    

    // Validate VM CONFIG ---------------------
    if(sfsfCompanyId){
        def configMappings = [
            "SFTP_Address"                              : "cbrInt_SuccessFactors_SFTP:Address",
            "SAP_FtpAuthMethod"                         : "cbrInt_SuccessFactors_SFTP:Authentication",        
            "SFTP_Source_Directory"                     : "cbrInt_SuccessFactors_SFTP_TIH:SourceDirectory", 
            "SFTP_Source_Fname_Attributes"              : "cbrInt_SuccessFactors_SFTP_TIH:SourceFile_Attributes", 
            "SFTP_Source_Fname_AttributeTexts"          : "cbrInt_SuccessFactors_SFTP_TIH:SourceFile_AttributeTexts", 
            "SFTP_Source_Fname_AttributeTags"           : "cbrInt_SuccessFactors_SFTP_TIH:SourceFile_AttributeTags", 
            "SFTP_Target_Directory"                     : "cbrInt_SuccessFactors_SFTP_TIH:TargetDirectory", 
            "SFTP_Target_FnamePrefix_Attributes"        : "cbrInt_SuccessFactors_SFTP_TIH:TargetFilePrefix_Attributes", 
            "SFTP_Target_FnamePrefix_AttributeTexts"    : "cbrInt_SuccessFactors_SFTP_TIH:TargetFilePrefix_AttributeTexts", 
            "SFTP_Target_FnamePrefix_AttributeTags"     : "cbrInt_SuccessFactors_SFTP_TIH:TargetFilePrefix_AttributeTags", 
            "SFTP_Target_FileSize"                      : "cbrInt_SuccessFactors_SFTP_TIH:TargetFileSize"        
        ];
        
        if(properties["SAP_FtpAuthMethod"]=='user' || properties["SAP_FtpAuthMethod"]=='dual'){
            configMappings.put("SFTP_Credential","cbrInt_SuccessFactors_SFTP:Credential");
        }
        if(properties["SAP_FtpAuthMethod"]=='key'){
            configMappings.put("SFTP_UserName","cbrInt_SuccessFactors_SFTP:UserName");
            configMappings.put("SFTP_PrivateKeyAlias","cbrInt_SuccessFactors_SFTP:PrivateKeyAlias");
        }        
        
        configMappings.each { property, vmconfig ->
            if (!properties[property]?.trim()) {
                errors.add(["errorCode": "[SAP-IS] MISSING_VMCONFIG", "errorMessage": "${vmconfig}"]);
            }
        }
    }
    
    // If there are any errors, set the error response and return
    if (!errors.isEmpty()) {
        def errorJson = JsonOutput.toJson(["errors": errors]);
        message.setProperty("errorJson", errorJson);
        throw new IllegalArgumentException(errorJson); // Exit with all errors
    }

    //Validation passed -------------------------

    //set get sfsf Tags only if Competency2Tag mapping is set OR if SkillTypeTags are configured in VM
    def get_sfsfTags = false; 
    if(sfsfUpdateAttributeTexts == 'false'){
    	if(mapCBRCompetency2SFSFTag == 'true'){
    	    get_sfsfTags = true;
    	}else if(sfsfSkillTypeTags){
    	    get_sfsfTags = true;
    	}else if(sfsfAttributeTag){
    	    get_sfsfTags = true;  //universal tag needs to exist if configured
    	}
    }
	message.setProperty("get_sfsfTags", get_sfsfTags);
	
    // Set properties for further processing
    message.setProperty("cbrJobArchitecture", cbrJobArchitecture);
    message.setProperty("cbrJobProfileIds", cbrJobProfileIds);
    message.setProperty("cbrJobProfileType", cbrJobProfileType);
    message.setProperty("sfsfAttributeType", 'SKILL');
    message.setProperty("sfsfDeactivateAttributes", sfsfDeactivateAttributes);
    message.setProperty("sfsfUpdateAttributeTags", sfsfUpdateAttributeTags);    
    message.setProperty("mapCBRCompetency2SFSFTag", mapCBRCompetency2SFSFTag);
    message.setProperty("testRun", testRun);
    message.setProperty("cbrProficiencyTextsEmbedded",cbrProficiencyTextsEmbedded);

    message.setProperty("cbrLearningOppIds", cbrLearningOppIds);
    message.setProperty("cbrLearningOppState", cbrLearningOppState);
    message.setProperty("cbrLearningOppCourseProvider", cbrLearningOppCourseProvider); 

    message.setProperty("cbrConfigurationId", cbrConfigurationId); 

    //used to clear hashmap global variables
	def emptyHmap = new HashMap<String, String>();
	emptyHmap.put('null','');
	message.setProperty("emptyHmap", emptyHmap);

    return message;
}

def Message build_listJobProf(Message message) {
    
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
    def cbrJobProfIds = map.get("cbrJobProfileIds");
	def Root = new XmlSlurper().parse(body);    
    
    // Find and count the number of Job Profiles
    def sumJobProf = Root.data.id.size();
    message.setProperty("sumJobProfile", sumJobProf); 
    
    //create list only if sycnhing for specific jobs!
    if(cbrJobProfIds){
	    def jobProfList = ''; 
	
        Root.data.each{
            if(jobProfList == ''){
                jobProfList = it.id.toString();
            }else{
                jobProfList = jobProfList + ',' + it.id.toString();
            }
        }
        //list of Roles being synched!
        message.setProperty("cbrJobProfileIdList", jobProfList); 
    }
	return message;
}

def Message get_curatedSkillsSum(Message message) {
    
	def body = message.getBody(java.io.Reader);
	def Root = new XmlSlurper().parse(body);    
    // Find and count the number of curated skills
    def sumCuratedSkills = Root.skills.id.size();
    message.setProperty("sumCuratedSkills", sumCuratedSkills); 
	return message;
}

def Message build_listLearnOpp(Message message) {
    
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
    def cbrLearnOppIds = map.get("cbrLearningOppIds");
    
    def Root = new XmlSlurper().parse(body);
    def learnOppList = ''; 
    
    //create list only if sycnhing for specific jobs!
    if(cbrLearnOppIds != null && cbrLearnOppIds != ''){
        Root.data.each{
            if(learnOppList == ''){
                learnOppList = it.id.toString();
            }else{
                learnOppList = learnOppList + ',' + it.id.toString();
            }
        }
    }
    //list of LearningOpp being synched!
    def sumLearnOpp = Root.data?.size() ?: 0;
    message.setProperty("sumLearningOpp", sumLearnOpp); 
    message.setProperty("cbrLearningOppIdList", learnOppList); 
    
	return message;
}

def Message build_hmapSkills(Message message) {
	
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
	HashMap<String, String> hmapSkills = map.get("hmap_cbrSkills"); 
	if( hmapSkills == null ){
	    hmapSkills = new HashMap<String, String>();	
	}
	
	def Root = new XmlSlurper().parse(body);
    def sumSkills = 0;
    Root.attribute.each{
        if(!it.skillType.toString()){
            //remove those without SkillTypes, must be bad id
            it.replaceNode {};
        }else{
            //jobProfIds not required for skills replication
            hmapSkills.put(it.id.toString(),'');
            sumSkills++;
        }
    }
    
    if(!hmapSkills.isEmpty()){
	    message.setProperty("hmap_cbrSkills", hmapSkills);
    }
    
    message.setBody(XmlUtil.serialize(Root));
    message.setProperty("sumSkills",sumSkills);
	return message;
}
