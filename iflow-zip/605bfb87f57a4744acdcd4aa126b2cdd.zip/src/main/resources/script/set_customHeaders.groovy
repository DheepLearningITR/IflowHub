import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
	    def testRun = message.getProperties().get("testRun");
		if(testRun!=null && testRun!='' && testRun!='false'){
			messageLog.addCustomHeaderProperty("cbr_testRun", testRun);		
        }
        
        def cbrJobArchitecture = message.getProperties().get("cbrJobArchitecture");
		if(cbrJobArchitecture!=null && cbrJobArchitecture!=''){
			messageLog.addCustomHeaderProperty("cbrJobArchitecture", cbrJobArchitecture);		
        }
        def cbrJobProfileType = message.getProperties().get("cbrJobProfileType");
		if(cbrJobProfileType!=null){
			messageLog.addCustomHeaderProperty("cbrJobProfileType", cbrJobProfileType);		
        }
        
        def cbrProvider = message.getProperties().get("cbrLearningOppCourseProvider");
		if(cbrProvider!=''){
			messageLog.addCustomHeaderProperty("cbr_LearningOppCourseProvider", cbrProvider);		
        }
        def cbrLearningOppState = message.getProperties().get("cbrLearningOppState");
		if(cbrLearningOppState!=null){
			messageLog.addCustomHeaderProperty("cbr_LearningOppState", cbrLearningOppState);		
        }        
        
        def sfsfAttributeTag = message.getProperties().get("sfsfAttributeTag");
		if(sfsfAttributeTag!=null){
			messageLog.addCustomHeaderProperty("sfsf_AttributeTag", sfsfAttributeTag);		
        }
        def sfsfAttributeType = message.getProperties().get("sfsfAttributeType");
		if(sfsfAttributeType!=null){
			messageLog.addCustomHeaderProperty("sfsf_AttributeType", sfsfAttributeType);		
        }
        def mapCBRCompetency2SFSFTag = message.getProperties().get("mapCBRCompetency2SFSFTag");
		if(mapCBRCompetency2SFSFTag!=null){
			messageLog.addCustomHeaderProperty("mapCBRCompetency2SFSFTag", mapCBRCompetency2SFSFTag);		
        }        
        
	}
	return message;
}

def Message cbrJobProfIdList(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def cbrJobProfIdList = message.getProperties().get("cbrJobProfIdList");
		if(cbrJobProfIdList!=null && cbrJobProfIdList!=''){
			messageLog.addCustomHeaderProperty("cbr_jobProfExtIds", cbrJobProfIdList);		
        }
	}
	return message;
}

def Message cbrLearningOppIdList(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def cbrLearningOppIdList = message.getProperties().get("cbrLearningOppIdList");
		if(cbrLearningOppIdList!=null && cbrLearningOppIdList!=''){
			messageLog.addCustomHeaderProperty("cbr_learningOppIdList", cbrLearningOppIdList);		
        }
	}
	return message;
}