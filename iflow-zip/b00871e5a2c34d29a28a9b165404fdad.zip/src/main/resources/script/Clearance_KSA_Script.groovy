import com.sap.gateway.ip.core.customdev.util.Message;
import java.nio.charset.StandardCharsets;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;

def Message prepareURLforClearance(Message message) {
    def properties = message.getProperties();
    def headers = message.getHeaders();
    
    def op_mode = properties.get("Mode");
    def testURL = properties.get("Test_URL");
    def prodURL = properties.get("Prod_URL");
    def process = headers.get("Process");
    def solutionUnitId = headers.get("SolutionUnitId");
    def csidSeqNo = headers.get("CSIDSequenceNo");
    String path, alias;
    
    if(op_mode == "TEST"){
        receiver_endpoint = testURL;
    }
    else if(op_mode == "PROD"){
        receiver_endpoint = prodURL;
    }
    else{
        def errorMsg = "Communication Mode: " + op_mode + " is incorrect; Only 'TEST' or 'PROD' are allowed";
        message.setHeader("ErrorCode", "SCI Error");
        message.setHeader("ErrorText", errorMsg);
        throw new Exception(errorMsg);
    }

    if(process == "compliance"){
        path = "/compliance/invoices";
        def ccsid = headers.get("CCSID");
        ccsid = ccsid.replaceAll("\\s","");
        alias = solutionUnitId + "_" + csidSeqNo + "_c";
        message = addAuthHeader(message, alias, ccsid);
    }
    else{
        path = "/invoices/clearance/single";
        message.setHeader("Clearance-Status", "1");
        
        def csid = headers.get("CSID");
        csid = csid.replaceAll("\\s","");
        alias = solutionUnitId + "_" + csidSeqNo + "_p";
        message = addAuthHeader(message, alias, csid);
    }
    
    message.setHeader("urlClearance" , receiver_endpoint + path);
    return message;
}

def Message updatePIH(Message message) {
    def headers = message.getHeaders();
    def pih = headers.get("PIH");
    def hash = headers.get("hash");
    
    String hash_hex = hash.decodeBase64().encodeHex().toString();
    String pih_updated = hash_hex.getBytes(StandardCharsets.UTF_8).encodeBase64().toString();
    
    message.setHeader("PIH", pih_updated);
    return message;
}

def Message trimEncodedBody(Message message){
     def body = message.getBody(String.class);
     message.setBody(body.replaceAll("\\s",""));
     return message;
}

def Message addAuthHeader(Message message, String alias, String userId) {
    SecureStoreService sss = ITApiFactory.getService(SecureStoreService.class, null);
    if (sss != null)
    {   
        //Getting User Credentials from Secure Store Service
        def userCred = sss.getUserCredential(alias);
        if (userCred != null)
        {
            //Setting Basic Authorization Header
            message.setHeader("Authorization", "Basic " + (userId + ":" + userCred.getPassword()).getBytes(StandardCharsets.UTF_8).encodeBase64().toString());
        }
        else
        { 
            def errorMsg = "Error while getting User Credentials from Security Material; Check if User Credential '" + alias + "' is present in Security Material";
            message.setHeader("ErrorCode", "SCI Error");
            message.setHeader("ErrorText", errorMsg);
            throw new Exception(errorMsg);
        }
    }
    else{
        def errorMsg = "Error while creating object for Class SecureStoreService";
        message.setHeader("ErrorCode", "SCI Error");
        message.setHeader("ErrorText", errorMsg);
        throw new Exception(errorMsg);
    }
    
    return message;
}

def Message storeErrorDataAsHeader(Message message) {
    def headers = message.getHeaders();
    def properties = message.getProperties();
    
    //Timeout Error
    def ex = properties.get("CamelExceptionCaught");
    if (ex != null) {
        if (ex.getClass().getCanonicalName().equals("java.util.concurrent.TimeoutException")) {
            message.setHeader("ErrorCode", "408");
            message.setHeader("ErrorText", "Request Timeout");
        }
    }
    
    def errorMsg;
    if(headers.get("CamelHttpResponseCode") == 401 || properties.get("exceptionMessage") == null) {
        errorMsg = "HTTP Status " + headers.get("CamelHttpResponseCode") + " - " + headers.get("CamelHttpResponseText");
    }
    else {
        errorMsg = properties.get("exceptionMessage");   
    }
    
    if( headers.get("ErrorCode") == null ) {
        message.setHeader("ErrorCode", "SCI Error");
    }
    if( headers.get("ErrorText") == null ) {
        message.setHeader("ErrorText", errorMsg);
    }
    
    return message;
}