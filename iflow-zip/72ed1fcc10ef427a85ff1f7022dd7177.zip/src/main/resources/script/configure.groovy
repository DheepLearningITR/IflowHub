import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.pd.BinaryData;

def Message processData(Message message) {

	def unique_id = message.getProperty('ENDPOINT_ID');

	def PD_NAMESPACE = "DME_Generic_Processing_$unique_id";

	def service = ITApiFactory.getApi(PartnerDirectoryService.class, null);

	if (service == null){
		throw new IllegalStateException("Partner Directory Service not found");
	}
	return message;
}

