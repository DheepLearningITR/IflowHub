import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    //Body 
     //def body = message.getBody();
     def map = message.getProperties();
     def offset = map.get("offset");
     def size = map.get("size")
     def Qccount = map.get("QuotacellCount");
     offset = offset+size;
     message.setProperty("offset",offset);
     
     if (offset.toInteger() >= Qccount.toInteger())
     {
         message.setProperty("exitTerritoryLoop","true");
     }
     else
     {
         message.setProperty("exitTerritoryLoop","false");
     }

     return message;
}