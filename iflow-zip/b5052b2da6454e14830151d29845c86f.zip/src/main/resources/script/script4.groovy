import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.xml.XmlUtil;

def Message processData(Message message) {   

    def body = message.getBody(java.lang.String) as String;
    def root = new XmlParser().parseText(body);
    def mesgproperties=message.getProperties();
    def extXmltqprogram = mesgproperties.get("p_tqprogramdetails") as String;
    def extXmltqprogramDoc = new XmlParser().parseText(extXmltqprogram);
    def extXmltqposition = mesgproperties.get("p_tqpositionsdata") as String;
    def extXmltqpositionDoc = new XmlParser().parseText(extXmltqposition);
    def extXmltqtarget = mesgproperties.get("p_tqtargetdetails") as String;
    def extXmltqtargetDoc = new XmlParser().parseText(extXmltqtarget);
    
    def orderseq = mesgproperties.get("tqpreferencevalue") as String;
    
    /*
    terquotadata=root.territoryQuotas;
    tqProgramstartdate=terquotadata.territoryProgramStartDate.text();
    println terquotadata.size();
    tqprgstartdate=Date.parse('YYYY-MM-DD',tqProgramstartdate.substring(0,10))
    String newlinenumber = tqprgstartdate.format('YYYYMMDD')
    */
     def tp_quotacellData = root.element;  
     def tp_programdata = extXmltqprogramDoc.beans;
     def tp_posdata=extXmltqpositionDoc.element;
     def tp_targetdata=extXmltqtargetDoc.element;
     //count = 100000;
     //println tp_quotacellData.size();
     //println tp_programdata.size();
     //println tp_posdata.size();
     //println tp_targetdata.size();

     // TQProgramData

       def tqProgramname=tp_programdata.name.text();
       def tqProgramseq=tp_programdata.territoryProgramSeq.text();
       def tqProgramstartdate=tp_programdata.effectiveStartDate.text();
       def tqProgramenddate=tp_programdata.effectiveEndDate.text();
       def tqProgramquotaCellPeriodType=tp_programdata.quotaCellPeriodType.name.text();
       def tqProgramgeographyHierarchyname=tp_programdata.geographyHierarchy.name.text();
       def tqProgramperiodname=tp_programdata.period.name.text();

       def tqprgstartdate=Date.parse('yyyy-mm-dd',tqProgramstartdate.substring(0,10))
       String newlinenumber = tqprgstartdate.format('YYYYMMDD')
       println newlinenumber
       println tqProgramname

        for (int i=0; i<tp_quotacellData.size() ; i++)
        {
            def quotacellData = root.element[i];
            def terseq = quotacellData.territoryseq.text();
            def tgtseq = quotacellData.targetTypeseq.text();
            //println terseq

            root.element[i].territoryprogramData.each { row ->
                row.appendNode("tqProgramname", tqProgramname)
                }
            root.element[i].territoryprogramData.each { row ->
                row.appendNode("tqProgramseq", tqProgramseq)
                }
       root.element[i].territoryprogramData.each { row ->
                row.appendNode("StartDate", tqProgramstartdate)
                }
       root.element[i].territoryprogramData.each { row ->
                row.appendNode("EndDate", tqProgramenddate)
                }
       root.element[i].territoryprogramData.each { row ->
                row.appendNode("linenumber", newlinenumber)
                }
       /*root.element[i].territoryprogramData.each { row ->
                row.appendNode("sublinenumber", count)
                }*/
        root.element[i].territoryprogramData.each { row ->
                row.appendNode("quotaCellPeriodType", tqProgramquotaCellPeriodType)
                }
        root.element[i].territoryprogramData.each { row ->
                row.appendNode("geographyHierarchyname", tqProgramgeographyHierarchyname)
                }
        root.element[i].territoryprogramData.each { row ->
                row.appendNode("periodname", tqProgramperiodname)
                }
        root.element[i].territoryprogramData.each { row ->
                row.appendNode("OrderIDSeq", orderseq)
                }
            
        for (int k=0; k<tp_posdata.size() ; k++)
           {
              def tqposData = extXmltqpositionDoc.element[k];
              def tqseq = tqposData.territorySeq.text();
              //println "posdata"
              //println tqseq

              if (terseq == tqseq)
               {
                   def posname = tqposData.tqposition
                   def tername = tqposData.territoryname.text();
                   def terstartdate = tqposData.territoryStartDate.text();
                   def terenddate = tqposData.territoryEndDate.text();
                   def isexplicit=tqposData.isExplicit.text();
                   //count++;

                root.element[i].PositionsData.each { row ->
                row.appendNode("posname", posname)
                }
                root.element[i].territoryData.each { row ->
                row.appendNode("Territoryname", tername)
                }
                root.element[i].territoryData.each { row ->
                row.appendNode("territoryStartDate", terstartdate)
                }
                root.element[i].territoryData.each { row ->
                row.appendNode("territoryEndDate", terenddate)
                }
                root.element[i].territoryData.each { row ->
                row.appendNode("isExplicit", isexplicit)
                }

               }
           }
        
        for (int z=0; z<tp_targetdata.size() ; z++)
        {
            def tqtgtdata = extXmltqtargetDoc.element[z];
            def targtseq = tqtgtdata.targetType.dataTypeSeq.text();

            if (tgtseq == targtseq)
            {
                def tgtname = tqtgtdata.targetType.targetTypeId.text();
                root.element[i].territoryData.each { row ->
                row.appendNode("TargetTypeName", tgtname)
                }

            }

        }

        //count++;
        }
   

  // message.setProperty("linenumber", count);
    message.setBody(XmlUtil.serialize(root));
    return message;
}