import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.xml.XmlUtil;
def Message processData(Message message) {   
    def body = message.getBody(java.lang.String) as String;
    def root = new XmlParser().parseText(body);
    def mesgproperties=message.getProperties();
    def extXmlbudetails = mesgproperties.get("p_budetails") as String;
    def extXmlbuDoc = new XmlParser().parseText(extXmlbudetails);

    def tp_posdate=root.element;
    def budetails=extXmlbuDoc.businessUnits;
    
    println tp_posdate.size();
    println budetails.size();

    for (int i=0; i<tp_posdate.size() ; i++)
    {
        def posdata = root.element[i];
        def pos_bumask=posdata.tqposition.mask.text();
        //println pos_bumask

        for (int k=0; k<budetails.size() ; k++)
        {
           def bunamedetails = extXmlbuDoc.businessUnits[k];
           def buname_mask=bunamedetails.mask.text();
           def buname_name=bunamedetails.name.text();
           //println buname_mask
           //println buname_name

           if (pos_bumask == buname_mask)
           {
               root.element[i].tqposition.each { row ->
                row.appendNode("buname", buname_name)
                }

           }
           if (pos_bumask == '0')
           {
               root.element[i].tqposition.mask[0].value='';

           }
        }
    }


    message.setBody(XmlUtil.serialize(root));
    return message;
}
