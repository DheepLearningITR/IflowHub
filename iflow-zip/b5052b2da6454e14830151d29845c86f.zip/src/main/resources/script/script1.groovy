import com.sap.gateway.ip.core.customdev.util.Message;
//import groovy.json.*;

def Message processData(Message message) {
 //Body 
def body = message.getBody(java.lang.String) as String;
def root = new XmlParser().parseText(body);
def i=0;
def errors="";
def finalmessage='"';
def allmessage=[];
root.'**'.findAll { it.name() == 'TargetType'}.each { a ->allmessage << a.text()};
int len = allmessage.size();
//println len
while(i<len)
{
//errors=errors+","+'"'+allmessage[i=0,i=1,i=2]+'"';
errors=errors+","+allmessage[i=i]
//errors=errors+","+'"'+allmessage[i=i]+'"'
i++;
}
//println errors
errors=errors.substring(1);
finalmessage=errors
message.setProperty("TargetTypeList", finalmessage);
//message.setBody(finalmessage);
return message;
}