import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.xml.XmlUtil;

def Message processData(Message message) {   

    def body = message.getBody(java.lang.String) as String;
    def root = new XmlParser().parseText(body);
    def mesgproperties=message.getProperties();

    def extXmltquarter = mesgproperties.get("p_quarterdetails") as String;
    def extXmltquarterDoc = new XmlParser().parseText(extXmltquarter);

     def tp_quotacellData = root.element;
     def tp_quarterdetails=extXmltquarterDoc.periods
     //println tp_quarterdetails.size()

     def count = 100000;
     //println tp_quotacellData.size();

        for (int i=0; i<tp_quotacellData.size() ; i++)
        {
            def quotacellData = root.element[i];
            def periodtype = quotacellData.territoryprogramData.quotaCellPeriodType.text();
            def periodname = quotacellData.period.text();
            def terstartdate=quotacellData.territoryData.territoryStartDate.text();
            //println periodtype
            //println periodname

            if (periodtype == 'month' && periodname!='')
            {
              def v_date=Date.parse('MMMM yyyy',periodname);
              def compensationdate=v_date.format('yyyyMMdd');

              root.element[i].territoryprogramData.each { row ->
                row.appendNode("compensationdate", compensationdate)
                }
            }
            else if (periodtype == 'quarter' && periodname!='')
            {
                //def quarter = periodname.substring(1,2);
                //def year = periodname.substring(3,7);
                //println quarter
                //println year

                 for (int k=0;k<tp_quarterdetails.size();k++)
                 {
                   def tp_quarterdetails2=extXmltquarterDoc.periods[k];
                   def quartername=tp_quarterdetails2.name.text();
                   def quarterstartdate=tp_quarterdetails2.startDate.text();
                   def qstartdate=Date.parse('yyyy-MM-dd',quarterstartdate.substring(0,10))
                   String compensationdate = qstartdate.format('yyyyMMdd')
                   //println qstartdate

                   if (periodname == quartername)
                   {
                    root.element[i].territoryprogramData.each { row ->
                    row.appendNode("compensationdate", compensationdate)
                     }
                   }
                 }
            }
            else
            {
              def trstartdate=Date.parse('yyyy-mm-dd',terstartdate.substring(0,10))
              String compensationdate = trstartdate.format('YYYYMMDD')
              //println compensationdate
              root.element[i].territoryprogramData.each { row ->
                row.appendNode("compensationdate", compensationdate)
                }
            }

            root.element[i].territoryprogramData.each { row ->
                row.appendNode("sublinenumber", count)
                }
          count++;
        }
            
    message.setBody(XmlUtil.serialize(root));
    return message;
}