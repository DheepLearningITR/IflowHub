import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
def body = message.getBody(java.lang.String) as String;    
body = body.replaceAll("\\{\"Element\":", "");
body = body.replaceAll("\"Element\":", ""); 
body = body.substring(0, body.length() - 1);     
message.setBody(body);
return message;
}


