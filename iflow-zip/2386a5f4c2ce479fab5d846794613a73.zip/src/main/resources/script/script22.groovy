/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {



    // get a map of properties
    def map = message.getProperties();

    // get an exception java class instance
 /*   def ex = map.get("CamelExceptionCaught");
    if (ex != null) {

        // an odata v2 adapter throws an instance of com.sap.gateway.core.ip.component.odata.exception.OsciException
        if (ex.getClass().getCanonicalName().equals("com.sap.gateway.core.ip.component.odata.exception.OsciException")) {

            // save the http error request uri as a message attachment 
            def messageLog = messageLogFactory.getMessageLog(message);
            messageLog.addAttachmentAsString("http.requestUri", ex.getRequestUri(), "text/plain");
            // copy the http error request uri to an exchange property
            message.setProperty("http.requestUri", ex.getRequestUri());

            // copy the http error response body as an attachment 
            messageLog.addAttachmentAsString("http.response", message.getBody(), "text/plain");
            // copy the http error response body as a propert 
            message.setProperty("http.response", message.getBody());

            // copy the http error response body as an attachment 
            messageLog.addAttachmentAsString("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString(), "text/plain");

            // copy the http error response body as a property 
            message.setProperty("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());

        }
    } else { */
        def body = message.getBody(String.class);
        def lv_glaccount, lv_companycode, lv_ledger;
        def api_lineitem = new groovy.json.JsonBuilder();
        def localarray = [];
        JsonSlurper slurper = new JsonSlurper();
        Map parsedJson = slurper.parseText(body);
        localarray = parsedJson.d.results[];
        //parsedJson.d.results = [];
        if (parsedJson.d != null) {
            //trialbalance = parsedJson.d.results;
            for (int i = 0; i < parsedJson.d.results.size(); i++) {
                if (parsedJson.d.results[i] != null) {
                    parsedJson.d.results[i].remove('__metadata');
                    
/*                    if (lv_glaccount == null && lv_companycode == null && lv_ledger == null) {
                        lv_glaccount = localarray[i].GLAccount;
                        lv_companycode = localarray[i].CompanyCode;
                        lv_ledger = localarray[i].Ledger;
                        api_lineitem = localarray[i];
                    } else if (localarray[i].GLAccount == lv_glaccount &&
                        localarray[i].CompanyCode == lv_companycode &&
                        localarray[i].Ledger == lv_ledger) {
                        //keep adding amount values in the api_lineitem 
                    } else {
                        lv_glaccount = localarray[i].GLAccount;
                        lv_companycode = localarray[i].CompanyCode;
                        lv_ledger = localarray[i].Ledger;
                        api_lineitem = localarray[i];
                        parsedJson.d.results.push(api_lineitem);
                    }*/

                }
            }
        }
        //output.d.results = localarray[];
        //message.setBody(trialbalance.toString());
        def jsonOP = JsonOutput.toJson(parsedJson.d.results)
        message.setBody(jsonOP);
    //}

return message;

}
