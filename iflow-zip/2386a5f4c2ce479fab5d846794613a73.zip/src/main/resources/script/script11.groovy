import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.String;

def Message processData(Message message) {
  
   //Headers 
       def map = message.getProperties();
       def credentials_alias = map.get("Credential");
     
       def service = ITApiFactory.getApi(SecureStoreService.class, null);
	   def credential = null;
	   def errorMsg;
	   
       	credential = service.getUserCredential( credentials_alias );
        if(credential == null) {
            errorMsg = "No credentials found for alias " + credentials_alias;
            message.setHeader("Error", errorMsg);
	        throw new IllegalStateException(errorMsg);
        }

    	//Get credential from keystore
       message.setProperty("client_id", credential.getUsername());
       message.setProperty("client_secret", (new String(credential.getPassword())));
       return message;
}