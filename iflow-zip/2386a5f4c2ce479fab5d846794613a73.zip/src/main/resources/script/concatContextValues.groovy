import com.sap.it.api.mapping.*;

def void concatContextValues(String[] var1, Output output1, MappingContext context) { 
   
  String output = "";
  boolean first = true;
  for (int i = 0; i < var1.length; i++) {
    if (first) {
      output = "GLAccount eq '" + var1[i] +"' or ";
      first = false;
    } else {
      output = output + "GLAccount eq '" + var1[i] + "' or ";
          }
  }
  output=(output.substring(0, output.length() - 3));
  output1.addValue(output);

}