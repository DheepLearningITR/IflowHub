import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Set;

def Message processData(Message message) {
org.apache.camel.Message camelMessage=message.exchange.getOut();
camelMessage.removeHeaders("Camel*");
camelMessage.removeHeaders("SAP*");
camelMessage.removeHeaders("sap*");
camelMessage.removeHeaders("Sap*");
camelMessage.removeHeaders("org.apache*");
camelMessage.removeHeaders("ResponseContext*");
Set<String> keys= camelMessage.getHeaders().entrySet();
println "The Remain key is :: "+keys;
return message;
}