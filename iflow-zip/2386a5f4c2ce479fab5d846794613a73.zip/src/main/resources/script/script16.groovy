import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
      //Body remove the first and last BRACKETS
       def body = message.getBody(java.lang.String) as String;
       def body_m=body.substring(1,body.length()-1);
       message.setBody(body_m);
       return message;
}