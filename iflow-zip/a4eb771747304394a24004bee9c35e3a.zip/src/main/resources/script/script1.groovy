import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    // remove the <xml> tags as this will give error while mapping
    def body = message.getBody();
    body = body.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim(); 
    message.setBody(body);
    return message;
}