importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
    var body = String(message.getBody(new java.lang.String().getClass()));
    //create json object from string object
    body = JSON.parse(body);
    
    var source = body.result;
    // var surveyLanguage = "E"; //to take from property
    var surveyLanguage = String(message.getProperties().get('SurveyLanguage').substring(0, 2));
    var target = getTargetMessageTemplate(surveyLanguage);
    
    if(source){
        target.SurveyId = source.id;
        target.Name = source.name;
        target.NickName = source.name;
        target.AccountId = ""; //To be mapped to account ID of organization
        target.CreatedOn = formatDateField(String(source.creationDate));
        target.ModifiedOn = formatDateField(String(source.lastModifiedDate));
        target.ValidFrom = formatDateField(String(source.expiration && source.expiration.startDate ? source.expiration.startDate : source.creationDate));
        target.ValidTo = formatDateField(String(source.expiration && source.expiration.endDate ? source.expiration.endDate : "9999-12-31T11:59:59Z"));
        target.SurveyQuestionSet = processQuestionSet(source.questions,target.Language, target.Version, target.SurveyId);
    }
    
    for ( var i = 0; i < target.SurveyQuestionSet.length; i++ ) {
        if( !target.SurveyQuestionSet[i].QuestionAnswerSet.length) {
            delete target.SurveyQuestionSet[i].QuestionAnswerSet
        }
        if( !target.SurveyQuestionSet[i].QuestionChoiceSet.length) {
            delete target.SurveyQuestionSet[i].QuestionChoiceSet
        }
    }
    
    message.setBody(JSON.stringify(target));
    
    return message;
}

function getTargetMessageTemplate(surveyLanguage){
   var targetMessage = { 
        "SurveyId":"",
        "Provider":"Qualtrics", //To be replaced with the survey provider name 
        "Version":1,
        "IsMultipleRespAllowed":true,
        "Name":"",
        "NickName":"",
        "AccountId":"",
        "Category":"",
        "Url":"", //To be replaced with survey provider URL
        "MarketingAreaId":"", //This field should be mapped with organization
        "Language":surveyLanguage,
        "IsSurveyAnonymous":false,
        "CreatedOn":"",
        "ModifiedOn":"",
        "ValidFrom":"",
        "ValidTo":"",
        "SurveyQuestionSet":[]
   };
   
   return targetMessage;
}

function getSurveyQuestionSetTemplate(surveyLanguage, surveyVersion, surveyId){
   var surveyQuestionSet = {
        "SurveyId": surveyId,
        "Provider":"Qualtrics",
        "QuestionId":"",
        "Text":"",
        "Type":"",
        "SubType":"",
        "TypeName":"Single", //To be checked.
        "Language":surveyLanguage,
        "Version": surveyVersion,
        "IsMandatory":false,
        "QuestionAnswerSet":[],
        "QuestionChoiceSet":[]
   };
   
   return surveyQuestionSet;
}

function getQuestionAnswerSetTemplate(surveyLanguage, surveyVersion){
   var questionAnswerSet = { 
        "RowId":"",
        "Language":surveyLanguage,
        "RowText":"",
        "Version": surveyVersion
   };
   
   return questionAnswerSet;
}

function getQuestionChoiceSetTemplate(surveyLanguage){
   var questionChoiceSet = { 
        "ChoiceId":"",
        "Language":surveyLanguage,
        "ChoiceText":""
   };
   
   return questionChoiceSet;
}

function processQuestionSet(questionsObj, surveyLanguage, surveyVersion, surveyId){
    var targetQuestionsSet = [];
    for (var key in questionsObj) {
      if (questionsObj.hasOwnProperty(key)) {
        var targetQuestion = processQuestion(key, questionsObj[key], surveyLanguage, surveyVersion, surveyId);
        targetQuestionsSet.push(targetQuestion);
      }
    }
    return targetQuestionsSet;
}

function processQuestion(questionId, questionObj, surveyLanguage, surveyVersion, surveyId){
    var targetQuestion = getSurveyQuestionSetTemplate(surveyLanguage, surveyVersion, surveyId);
    targetQuestion.QuestionId = questionId;
    targetQuestion.IsMandatory = questionObj.validation.doesForceResponse;
    for (var key in questionObj) {
      if (questionObj.hasOwnProperty(key)) {
        if(key === "questionText"){
            targetQuestion.Text = questionObj[key].replace(/<\/?span[^>]*>/g,"");
        }else if(key === "questionType"){
            switch(questionObj[key].type){
                case "MC":
                    switch(questionObj[key].selector){
                        case "MAVR":
                        case "MAHR":
                          targetQuestion.Type = "CB";
                          targetQuestion.SubType = questionObj[key].selector === "MAHR" ? "HZ" : "VT";
                          break;
                        case "SAVR":
                        case "SAHR":
                          targetQuestion.Type = "RB";
                          targetQuestion.SubType = questionObj[key].selector === "SAHR" ? "HZ" : "VT";
                          break;
                        case "DL":
                          targetQuestion.Type = "DL";
                          targetQuestion.SubType = "MU";
                          break;
                        case "SB":
                          targetQuestion.Type = "RB";
                          targetQuestion.SubType = "VT";
                          break;
                        case "MSB":
                          targetQuestion.Type = "CB";
                          targetQuestion.SubType = "VT";
                          break;
                        case "NPS":
                          targetQuestion.Type = "PS";
                          targetQuestion.SubType = "HZ";
                          break;
                    }
                    break;
                case "TE":
                    targetQuestion.Type = "FT";
                    if(questionObj[key].selector === "SL" || questionObj[key].selector === "ML")
                     targetQuestion.SubType = questionObj[key].selector;
                    if (questionObj[key].selector === "ESTB")
                     targetQuestion.SubType = "ES";
                    break;
                case "Slider":
                    targetQuestion.Type = "RB";
                    targetQuestion.SubType = "RT";
                    break;
                case "RO":
                    targetQuestion.Type = "RO";
                    targetQuestion.SubType = "RK";
                    break;
                case "Matrix":
                    targetQuestion.Type = "MX";
                    targetQuestion.SubType = "SL";
                    break;
            }
            if(targetQuestion.Type === ""){
                targetQuestion.Type = "RB";
                targetQuestion.SubType = "VT";
            }
            if(targetQuestion.SubType === ""){
                targetQuestion.SubType = "VT";
            }
        }
        else if(key === "choices"){
            if(targetQuestion.Type === "MX"){
                targetQuestion.QuestionChoiceSet = processQuestionChoiceSet(questionObj[key],surveyLanguage);
            }else{
                targetQuestion.QuestionAnswerSet = processQuestionAnswerSet(questionObj[key], surveyLanguage, surveyVersion);
            }
        }
        else if(key === "subQuestions"){
            if(targetQuestion.Type === "MX"){
                targetQuestion.QuestionAnswerSet = processQuestionAnswerSet(questionObj[key], surveyLanguage, surveyVersion);
            }
        }
      }
    }
    return targetQuestion;
}

// Choice Obj is used in most of the question types
function processQuestionAnswerSet(choicesObj, surveyLanguage, surveyVersion){
    var targetQuestionAnswerSet = [];
    for (var key in choicesObj) {
      if (choicesObj.hasOwnProperty(key)) {
        var targetQuestionAnswer = processQuestionAnswer(key, choicesObj[key], surveyLanguage, surveyVersion);
        targetQuestionAnswerSet.push(targetQuestionAnswer);
      }
    }
    return targetQuestionAnswerSet;
}

function processQuestionAnswer(choiceId, choiceObj, surveyLanguage, surveyVersion){
    var targetQuestionAnswer =  getQuestionAnswerSetTemplate(surveyLanguage, surveyVersion);
    targetQuestionAnswer.RowId = choiceId;
    for (var key in choiceObj) {
      if (choiceObj.hasOwnProperty(key)) {
        if(key === "choiceText"){
            targetQuestionAnswer.RowText = choiceObj[key];
        }
      }
    }
    return targetQuestionAnswer;
}
// subQuestions is used only in case of Matrix Question types
function processQuestionChoiceSet(subQuestionObj, surveyLanguage){
    var targetQuestionChoiceSet = [];
    for (var key in subQuestionObj) {
      if (subQuestionObj.hasOwnProperty(key)) {
        var targetQuestionChoice = processQuestionChoice(key,subQuestionObj[key],surveyLanguage);
        targetQuestionChoiceSet.push(targetQuestionChoice);
      }
    }
    return targetQuestionChoiceSet;
}

function processQuestionChoice(subQuestionId,subQuestionObj,surveyLanguage){
    var targetQuestionChoice =  getQuestionChoiceSetTemplate(surveyLanguage);
    targetQuestionChoice.ChoiceId = subQuestionId;
    for (var key in subQuestionObj) {
      if (subQuestionObj.hasOwnProperty(key)) {
        if(key === "choiceText"){
            targetQuestionChoice.ChoiceText = subQuestionObj[key];
        }
      }
    }
    return targetQuestionChoice;
}

function traverse(obj) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) {
      var val = obj[key];
      console.log(val);
      traverse(val);
    }
  }
}

function formatDateField(sDate) {
    if(sDate){
      sDate = sDate.substring(0,sDate.length - 1);
    }
    return sDate;
}