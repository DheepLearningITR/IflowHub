import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import java.util.*;
import java.text.SimpleDateFormat;

def Message processData(Message message) {
    def properties = message.getProperties();
    def idOrigin = properties.get('P_Id_Origin');
    def body = message.getBody(String.class);
    def result = map(body, idOrigin);
    message.setBody(result);
    return message;
}

def String map(String message, String idOrigin) {
    def SourceMessage = new XmlParser().parseText(message);
    def surveyResponse = new XmlParser().parseText(getTargetMessageSurveyResponseTemplate());

    SourceMessage.result.values.each {

        def recordDate = it.recordedDate.text();
        def sapOutboundId = it.
        'sap-outbound-id'.text();

        surveyResponse.RespondedOn[0].value = recordDate;
        surveyResponse.OutboundKey[0].value = sapOutboundId;
        surveyResponse.IdOrigin[0].value = idOrigin;

        if (sapOutboundId) { //Clear dummy ID and IdOrigin values if outbound key is already captured
            surveyResponse.Id[0].value = "";
            surveyResponse.IdOrigin[0].value = "";
        }

        it.each {
            def groovy.util.Node nit = it;
            String nodeName = nit.name();

            def DetailSet = new XmlParser().parseText(getTargetMessageDetailSetTemplate());

            if (SourceMessage.result.displayedFields.find { ls -> ls.text() == nit.name() }) {
                // For Matrix Question Type
                if (nodeName.matches("(.*_\\d+)")) {
                    def index = nit.name().indexOf("_");
                    DetailSet.QuestionId[0].value = nit.name().substring(0, index);
                    DetailSet.ResponseIdRow[0].value = nit.name().substring(index + 1);
                    DetailSet.ResponseIdCol[0].value = nit.value();
                    surveyResponse.SurveyResponseSurveyResponseDetailSet[0].append(DetailSet);
                }
                // For Free Text Question Type
                else if (nodeName.matches("(.*_TEXT)")) {
                    index = nit.name().indexOf("_");
                    DetailSet.QuestionId[0].value = nit.name().substring(0, index);
                    DetailSet.ResponseText[0].value = nit.value();
                    surveyResponse.SurveyResponseSurveyResponseDetailSet[0].append(DetailSet);
                }
                // For Remaining Question Types
                else if (!nodeName.matches("(.*_NPS_GROUP)")) {
                    DetailSet.QuestionId[0].value = nit.name();
                    DetailSet.ResponseIdRow[0].value = nit.value();
                    surveyResponse.SurveyResponseSurveyResponseDetailSet[0].append(DetailSet);
                }
            }
        }
    }

    def result = XmlUtil.serialize(surveyResponse);
    return result;
}

///----------------------------------------------------------------------------------
/// XML Templates
def getTargetMessageSurveyResponseTemplate() {
  return '''
    <SurveyResponseSet>
        <ResponseId></ResponseId>
        <Id></Id>
        <IdOrigin></IdOrigin>
        <RespondedOn></RespondedOn>
        <OutboundKey></OutboundKey>
        <SurveyResponseSurveyResponseDetailSet></SurveyResponseSurveyResponseDetailSet>
    </SurveyResponseSet>
'''.stripMargin();
}

def getTargetMessageDetailSetTemplate() {
  return '''
    <SurveyResponseDetail>
        <QuestionId></QuestionId>
        <ResponseIdRow></ResponseIdRow>
        <ResponseIdCol></ResponseIdCol>
        <ResponseText></ResponseText>
    </SurveyResponseDetail>
'''.stripMargin();
}