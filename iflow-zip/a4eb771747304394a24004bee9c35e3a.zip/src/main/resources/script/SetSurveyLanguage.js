importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {

    var body = String(message.getBody(new java.lang.String().getClass()));
    body = JSON.parse(body);
    if(body && body.result && body.result.AvailableLanguages && body.result.AvailableLanguages.length){
       message.setProperty("SurveyLanguage",body.result.AvailableLanguages[0]);
   }
     
     return message;
}