importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
	
	var map = message.getProperties();
    var iDocMapped = JSON.parse(message.getBody().toString());
    if(!iDocMapped){
    	return message;
    }
    
    var customerDataJson = JSON.parse(map.get("customerDataJson"));
    if(!customerDataJson || !customerDataJson.addresses){
    	return message;
    }
    var defaultAddress = null;
    for(var i in customerDataJson.addresses){
    	if(customerDataJson.addresses[i].isDefault){
    		defaultAddress = customerDataJson.addresses[i];
    		break;
    	}
    }
    if(!defaultAddress || !defaultAddress.mixins || !defaultAddress.mixins.iDoc_ADRMAS){
    	return message;
    }
    
    copy(iDocMapped["ns2:ADRMAS03"]["ns2:IDOC"]["ns2:E1ADRMAS"], defaultAddress.mixins.iDoc_ADRMAS.E1ADRMAS);

	message.setBody(JSON.stringify(iDocMapped));
	return message;
}

function copy(json1, json2){
	var json = json1;
	var ns = "ns2:";

	for(var i in json2){
		if(typeof json2[i] === "string"){
			if(!json1[ns+i.toUpperCase()]){
				json1[ns+i.toUpperCase()] = json2[i];
			}
		}
	}
	return json;
}