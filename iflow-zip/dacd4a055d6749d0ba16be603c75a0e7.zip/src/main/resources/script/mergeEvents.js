importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
	
	var map = message.getProperties();
    var mergedBody = map.get("mergedBody");
    if(!mergedBody){
    	mergedBody = {events:[]};
    }
    
	var body = null;
	try{
		body = JSON.parse(message.getBody().toString());
	}
	catch(e){
		message.setProperty("mergedBody", mergedBody);
		if(mergedBody.events.length){
			message.setBody(JSON.stringify(mergedBody));
		}
		return message;
	}
    
	for(var i in body.events){
		var customerExists = false;
		var eventContent = JSON.parse(body.events[i].payload);
		var customerNumber = eventContent.customerNumber;
		var mergedBodyIndex = 0;
		for(var z in mergedBody.events){
			if(mergedBody.events[z].customerNumber == customerNumber){
				customerExists = true;
				mergedBodyIndex = z;
				
			}
		}
		if(!customerExists){
			body.events[i].customerNumber = customerNumber;
			mergedBody.events.push(body.events[i]);
		}
		else if(customerExists && body.events[i].createdAt > mergedBody.events[mergedBodyIndex].createdAt){
			body.events[i].customerNumber = customerNumber;
			mergedBody.events[mergedBodyIndex] = body.events[i];
		}
	}
	
	message.setProperty("mergedBody", mergedBody);
	if(mergedBody.events.length){
		message.setBody(JSON.stringify(mergedBody));
	}
	return message;
}