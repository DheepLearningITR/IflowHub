import com.ning.http.client.AsyncHttpClient;
import com.ning.http.client.Response;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	map = message.getProperties();
	String tokenType = map.get("token_type");
	String accessToken = map.get("access_token");
	String yaasTenant = map.get("yaasTenant");
	String yaasCustomerID = map.get("yaasCustomerID");
	String customerAPI = map.get("customerAPI");
	
	
	String url = customerAPI + "/" + yaasTenant + "/customers/" + yaasCustomerID;
	String query = "expand=mixin:sdcustomer,mixin:iDoc_DEBMAS,mixin:iDoc_ADRMAS,addresses";

	AsyncHttpClient httpClient = new AsyncHttpClient();

	Response responseGetCustomer = httpClient.prepareGet(url + "?" + query)
		.addHeader("Content-Type", "application/json")
	    .addHeader("Authorization", tokenType + " " + accessToken)
	    .execute().get();
	    
	int statusCode = responseGetCustomer.getStatusCode();
	        
	if(statusCode == 200){
		// Response from HTTP request is in UTF-8 but Groovy works with ISO-8859-1. --> Response is wrongly saved in ISO-8859-1 and therefore it is encoded to UTF-8.
	    // If it is not encoded to UTF-8, characters besides Latin characters might not be correctly displayed in the target Business Suite system. 
	    String customer = new String(responseGetCustomer.getResponseBody().getBytes("ISO-8859-1"), "UTF-8");
	     
		message.setBody(customer);
		message.setProperty("customerFound", true);
		
	} else if(statusCode == 404){ // 404 --> Customer not found on YaaS --> Event for customer which has been deleted --> Event/Customer is ignored
		String customerNotFound = "Customer " + yaasCustomerID + " has been deleted. Event is ignored."
	
		message.setBody(customerNotFound);
		message.setProperty("customerFound", false);
		
    } else{
    	throw new Exception(responseGetCustomer.getResponseBody());
    	
    }
	   	
	return message;
}