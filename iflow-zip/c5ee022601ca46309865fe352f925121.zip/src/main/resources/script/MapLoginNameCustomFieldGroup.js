importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var customFieldGroupBody = JSON.parse(body);
  var customFieldGroupUri = customFieldGroupBody.d ? customFieldGroupBody.d.uri : null;
  var userJson = message.getProperty('userJSON');
  userJson = JSON.parse(userJson);
  var userName = userJson.User.username;
  var logMessageProperty = message.getProperty('LogMessageProperty');
  if (messageLog && logMessageProperty && logMessageProperty.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('customFieldGroupUri', customFieldGroupUri, 'text/json');
  }
  message.setProperty('loginName', userName);
  message.setProperty('customFieldGroupUri', customFieldGroupUri);
  return message;
}
