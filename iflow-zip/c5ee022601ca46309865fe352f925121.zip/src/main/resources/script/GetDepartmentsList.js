importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var nullParameters = [ 'N/A', 'null', 'undefined', '' ];
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var departmentName = String(message.getProperty('departmentName'));
  departmentName = checkIfTagValueIsNull(nullParameters, departmentName) ? departmentName : null;
  var departmentId = String(message.getProperty('departmentId'));
  departmentId = checkIfTagValueIsNull(nullParameters, departmentId) ? departmentId : null;
  var departmentListData = getDepartmentListData(departmentName, departmentId);
  departmentListData = JSON.stringify(departmentListData);
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('departmentListData request for department name: ' + departmentName, departmentListData, 'text/json');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(departmentListData);
  return message;
}

function getDepartmentListData(departmentName, departmentId) {
  return {
    page: 1,
    pagesize: 1000,
    columnUris: [ 'urn:replicon:department-group-list-column:department-group', 'urn:replicon:department-group-list-column:name', 'urn:replicon:department-group-list-column:code' ],
    sort: [],
    filterExpression: {
      leftExpression: {
        leftExpression: {
          filterDefinitionUri: 'urn:replicon:department-group-list-filter:text'
        },
        operatorUri: 'urn:replicon:filter-operator:text-search',
        rightExpression: {
          value: {
            text: departmentName
          }
        }
      },
      operatorUri: 'urn:replicon:filter-operator:or',
      rightExpression: {
        leftExpression: {
          filterDefinitionUri: 'urn:replicon:department-group-list-filter:text'
        },
        operatorUri: 'urn:replicon:filter-operator:text-search',
        rightExpression: {
          value: {
            text: departmentId
          }
        }
      }
    }
  };
}

function checkIfTagValueIsNull(array, element) {
  var index = array.indexOf(element);
  return (index > -1) ? null : index;
}