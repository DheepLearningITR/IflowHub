/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageProperty = message.getProperty('LogMessageProperty');
  var userDate = message.getProperty('lastUserSyncDate');
  updateLastSyncDate(message, messageLog);
  var messageString = 'Last User Sync Date ' + userDate;
  if (messageLog && logMessageProperty && logMessageProperty.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Last User Sync Date: ', messageString, 'text/json');
  }
  var offset = message.getProperty('OffsetTimeInMinutes');
  userDate = getDateValue(userDate);
  userDate = addMinutes(userDate, offset * -1);
  userDate = userDate.toISOString().split('.')[0];
  message.setProperty('lastUserSyncDate', userDate);
  return message;
}

function addMinutes(date, minutes) {
  return new Date(date.getTime() + (minutes * 60000));
}

function updateLastSyncDate(message, messageLog) {
  var lastSuccessSyncDate = String(message.getProperty('LastSuccessfulUserSyncTime'));
  lastSuccessSyncDate = (lastSuccessSyncDate) ? getDateValue(lastSuccessSyncDate) : getUTCDate();
  var resetTimeThreshold = message.getProperty('resetTimeThresholdInMins');
  var utcDate = getUTCDate();
  if ((utcDate.getTime() - lastSuccessSyncDate.getTime()) > resetTimeThreshold * 60000) {
    var logMessageBody = message.getProperty('LogMessageBody');
    var lastSyncDate = addMinutes(utcDate, -1 * resetTimeThreshold);
    lastSyncDate = lastSyncDate.toISOString().split('.')[0];
    message.setProperty('lastUserSyncDate', lastSyncDate);
    if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
      messageLog.addAttachmentAsString('Reset Time', lastSyncDate, 'text/json');
    }
  }
}

function getUTCDate() {
  var utcDate = new Date(new Date().toUTCString().slice(0, -4));
  return utcDate;
}

function getDateValue(dateValue) {
  try {
    var regex = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/;
    var dateArray = regex.exec(dateValue);
    var syncDate = new Date(
      (Number(dateArray[1])),
      (Number(dateArray[2])) - 1,
      (Number(dateArray[3])),
      (Number(dateArray[4])),
      (Number(dateArray[5])),
      (Number(dateArray[6]))
    );
    return syncDate;
  } catch (e) {
    return null;
  }
}