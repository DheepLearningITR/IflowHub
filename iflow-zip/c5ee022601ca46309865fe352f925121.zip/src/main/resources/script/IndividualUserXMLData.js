importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  if ((!body.startsWith('<User/>')) && (body.lastIndexOf('<User>') !== 0)) {
    body = body.substring(6);
    message.setBody(body);
  }
  return message;
}