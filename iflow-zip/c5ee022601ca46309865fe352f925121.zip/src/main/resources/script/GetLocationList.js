importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var nullParameters = [ 'N/A', 'null', 'undefined', '' ];
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var locationName = String(message.getProperty('locationName'));
  locationName = checkIfTagValueIsNull(nullParameters, locationName) ? locationName : null;
  var locationId = String(message.getProperty('locationId'));
  locationId = checkIfTagValueIsNull(nullParameters, locationId) ? locationId : null;
  var locationListData = getLocationListData(locationName, locationId);
  locationListData = JSON.stringify(locationListData);
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('locationListData request for location name: ' + locationName, locationListData, 'text/json');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(locationListData);
  return message;
}

function getLocationListData(locationName, locationId) {
  return {
    page: 1,
    pagesize: 1000,
    columnUris: [ 'urn:replicon:location-list-column:location', 'urn:replicon:location-list-column:name', 'urn:replicon:location-list-column:code' ],
    sort: [],
    filterExpression: {
      leftExpression: {
        leftExpression: {
          filterDefinitionUri: 'urn:replicon:location-list-filter:text'
        },
        operatorUri: 'urn:replicon:filter-operator:text-search',
        rightExpression: {
          value: {
            text: locationName
          }
        }
      },
      operatorUri: 'urn:replicon:filter-operator:or',
      rightExpression: {
        leftExpression: {
          filterDefinitionUri: 'urn:replicon:location-list-filter:text'
        },
        operatorUri: 'urn:replicon:filter-operator:text-search',
        rightExpression: {
          value: {
            text: locationId
          }
        }
      }
    }
  };
}

function checkIfTagValueIsNull(array, element) {
  var index = array.indexOf(element);
  return (index > -1) ? null : index;
}