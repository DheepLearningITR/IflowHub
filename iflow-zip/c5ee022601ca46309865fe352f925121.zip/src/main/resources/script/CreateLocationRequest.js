/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var nullParameters = [ 'N/A', 'null', 'undefined', '' ];
  var messageLog = messageLogFactory.getMessageLog(message);
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var locationName = String(message.getProperty('locationName'));
  var locationCode = String(message.getProperty('locationId'));
  var locationGroupUri = String(message.getProperty('locationGroupUri'));
  locationGroupUri = checkIfTagValueIsNull(nullParameters, locationGroupUri) ? locationGroupUri : null;
  var locationGroupJson = {
    location: locationGroupUri ? {
      name: null,
      uri: locationGroupUri
    } : null,
    modifications: {
      name: locationName,
      codeToApply: locationCode ? {
        value: locationCode
      } : null,
      isEnabled: true
    },
    unitOfWorkId: makeid(8)
  };
  var logMessageBody = message.getProperty('LogMessageBody');
  locationGroupJson = JSON.stringify(locationGroupJson);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Create Location ' + locationName + ' Request:', locationGroupJson, 'text/json');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(locationGroupJson);
  return message;
}

function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

function checkIfTagValueIsNull(array, element) {
  var index = array.indexOf(element);
  return (index > -1) ? null : index;
}