/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
  var nullParameters = [ 'N/A', 'null', 'undefined', '' ];
  var token = String(message.getProperty('RepliconToken'));
  var rootDepartment = String(message.getProperty('Root_Department'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var departmentName = String(message.getProperty('departmentName'));
  var departmentCode = String(message.getProperty('departmentId'));
  var departmentGroupUri = String(message.getProperty('departmentGroupUri'));
  departmentGroupUri = checkIfTagValueIsNull(nullParameters, departmentGroupUri) ? departmentGroupUri : null;
  var departmentGroupJson = {
    departmentGroup: {
      parent: departmentGroupUri ? null : {
        name: rootDepartment
      },
      uri: departmentGroupUri ? departmentGroupUri : null
    },
    modifications: {
      name: departmentName,
      codeToApply: departmentCode ? {
        value: departmentCode
      } : null,
      isEnabled: true
    },
    unitOfWorkId: makeid(8)
  };
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  departmentGroupJson = JSON.stringify(departmentGroupJson);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Create Department ' + departmentName + ' Request:', departmentGroupJson, 'text/json');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(departmentGroupJson);
  return message;
}

function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

function checkIfTagValueIsNull(array, element) {
  var index = array.indexOf(element);
  return (index > -1) ? null : index;
}