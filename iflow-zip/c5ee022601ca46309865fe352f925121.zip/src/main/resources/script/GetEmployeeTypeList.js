importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var nullParameters = [ 'N/A', 'null', 'undefined', '' ];
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var employeeTypeLabel = String(message.getProperty('employeeTypeLabel'));
  employeeTypeLabel = checkIfTagValueIsNull(nullParameters, employeeTypeLabel) ? employeeTypeLabel : null;
  var employeeTypeId = String(message.getProperty('employeeTypeId'));
  employeeTypeId = checkIfTagValueIsNull(nullParameters, employeeTypeId) ? employeeTypeId : null;
  var employeeTypeListData = getEmployeeTypeListData(employeeTypeLabel, employeeTypeId);
  employeeTypeListData = JSON.stringify(employeeTypeListData);
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('employeeTypeListData request for division name: ' + employeeTypeLabel, employeeTypeListData, 'text/json');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(employeeTypeListData);
  return message;
}

function getEmployeeTypeListData(employeeTypeLabel, employeeTypeId) {
  return {
    page: 1,
    pagesize: 1000,
    columnUris: [ 'urn:replicon:employee-type-group-list-column:employee-type-group', 'urn:replicon:employee-type-group-list-column:name', 'urn:replicon:employee-type-group-list-column:code' ],
    sort: [],
    filterExpression: {
      leftExpression: {
        leftExpression: {
          filterDefinitionUri: 'urn:replicon:employee-type-group-list-filter:text'
        },
        operatorUri: 'urn:replicon:filter-operator:text-search',
        rightExpression: {
          value: {
            text: employeeTypeLabel
          }
        }
      },
      operatorUri: 'urn:replicon:filter-operator:or',
      rightExpression: {
        leftExpression: {
          filterDefinitionUri: 'urn:replicon:employee-type-group-list-filter:text'
        },
        operatorUri: 'urn:replicon:filter-operator:text-search',
        rightExpression: {
          value: {
            text: employeeTypeId
          }
        }
      }
    }
  };
}

function checkIfTagValueIsNull(array, element) {
  var index = array.indexOf(element);
  return (index > -1) ? null : index;
}