importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var messageLog = messageLogFactory.getMessageLog(message);
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var objectTypeUriJson = {
    objectTypeUri: 'urn:replicon:object-type:user'
  };
  var logMessageBody = message.getProperty('LogMessageBody');
  objectTypeUriJson = JSON.stringify(objectTypeUriJson);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('User Custom Field Group Request:', objectTypeUriJson, 'text/json');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(objectTypeUriJson);
  return message;
}