/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var nullParameters = [ 'N/A', 'null', 'undefined', '' ];
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var divisionName = String(message.getProperty('divisionName'));
  var divisionCode = String(message.getProperty('divisionId'));
  var divisionGroupUri = String(message.getProperty('divisionGroupUri'));
  divisionGroupUri = checkIfTagValueIsNull(nullParameters, divisionGroupUri) ? divisionGroupUri : null;
  var divisionGroupJson = {
    division: divisionGroupUri ? {
      uri: divisionGroupUri
    } : null,
    modifications: {
      name: divisionName,
      codeToApply: divisionCode ? {
        value: divisionCode
      } : null,
      isEnabled: true
    },
    unitOfWorkId: makeid(8)
  };
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  divisionGroupJson = JSON.stringify(divisionGroupJson);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Create Division ' + divisionName + ' Request:', divisionGroupJson, 'text/xml');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(divisionGroupJson);
  return message;
}

function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

function checkIfTagValueIsNull(array, element) {
  var index = array.indexOf(element);
  return (index > -1) ? null : index;
}