importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var nullParameters = [ 'N/A', 'null', 'undefined', '' ];
  var messageLog = messageLogFactory.getMessageLog(message);
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var costCenterName = String(message.getProperty('costCenterName'));
  var costCenterId = String(message.getProperty('costCenterId'));
  var costCenterGroupUri = String(message.getProperty('CostCenterGroupUri'));
  costCenterGroupUri = checkIfTagValueIsNull(nullParameters, costCenterGroupUri) ? costCenterGroupUri : null;
  var costCenterGroupJson = {
    costCenter: costCenterGroupUri ? {
      uri: costCenterGroupUri
    } : null,
    modifications: {
      name: costCenterName,
      codeToApply: {
        value: costCenterId
      },
      isEnabled: true
    },
    unitOfWorkId: makeid(8)
  };
  var logMessageBody = message.getProperty('LogMessageBody');
  costCenterGroupJson = JSON.stringify(costCenterGroupJson);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Create CostCenter ' + costCenterName + ' Request:', costCenterGroupJson, 'text/json');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(costCenterGroupJson);
  return message;
}

function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

function checkIfTagValueIsNull(array, element) {
  var index = array.indexOf(element);
  return (index > -1) ? null : index;
}