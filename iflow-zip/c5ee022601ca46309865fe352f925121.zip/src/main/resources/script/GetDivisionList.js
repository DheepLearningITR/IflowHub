importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var nullParameters = [ 'N/A', 'null', 'undefined', '' ];
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var divisionName = String(message.getProperty('divisionName'));
  divisionName = checkIfTagValueIsNull(nullParameters, divisionName) ? divisionName : null;
  var divisionId = String(message.getProperty('divisionId'));
  divisionId = checkIfTagValueIsNull(nullParameters, divisionId) ? divisionId : null;
  var divisionListData = getDivisionListData(divisionName, divisionId);
  divisionListData = JSON.stringify(divisionListData);
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('divisionListData request for division name: ' + divisionName, divisionListData, 'text/json');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(divisionListData);
  return message;
}

function getDivisionListData(divisionName, divisionId) {
  return {
    page: 1,
    pagesize: 1000,
    columnUris: [ 'urn:replicon:division-list-column:division', 'urn:replicon:division-list-column:name', 'urn:replicon:division-list-column:code' ],
    sort: [],
    filterExpression: {
      leftExpression: {
        leftExpression: {
          filterDefinitionUri: 'urn:replicon:division-list-filter:text'
        },
        operatorUri: 'urn:replicon:filter-operator:text-search',
        rightExpression: {
          value: {
            text: divisionName
          }
        }
      },
      operatorUri: 'urn:replicon:filter-operator:or',
      rightExpression: {
        leftExpression: {
          filterDefinitionUri: 'urn:replicon:division-list-filter:text'
        },
        operatorUri: 'urn:replicon:filter-operator:text-search',
        rightExpression: {
          value: {
            text: divisionId
          }
        }
      }
    }
  };
}

function checkIfTagValueIsNull(array, element) {
  var index = array.indexOf(element);
  return (index > -1) ? null : index;
}