/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var userJson = message.getProperty('userJSON');
  userJson = JSON.parse(userJson);
  var timeZone = userJson.User.timeZone;
  body = JSON.parse(body);
  var timeZoneUri = filterTimeZone(timeZone, body.d);
  var logMessageProperty = message.getProperty('LogMessageProperty');
  if (messageLog && logMessageProperty && logMessageProperty.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('timeZoneUri:', timeZoneUri, 'text/json');
  }
  if (timeZoneUri) {
    message.setProperty('timeZoneUri', timeZoneUri);
  }
  return message;
}

function filterTimeZone(ianaName, responseBody) {
  var timeZoneUri = null;
  var timeZoneEntry = responseBody.filter(function(t) {
    return compareString(t.ianaName, ianaName);
  });
  if (timeZoneEntry && timeZoneEntry[0] && timeZoneEntry[0].uri) {
    timeZoneUri = timeZoneEntry[0].uri;
  }
  return timeZoneUri;
}

function compareString(str1, str2) {
  return (str1 && str2) ? (str1 === str2) : false;
}