importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var messageLog = messageLogFactory.getMessageLog(message);
  var loginName = String(message.getProperty('loginName'));
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var userListJson = {
    users: [
      {
        loginName: loginName
      }
    ]
  };
  var logMessageBody = message.getProperty('LogMessageBody');
  userListJson = JSON.stringify(userListJson);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Get User Request:', userListJson, 'text/json');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(userListJson);
  return message;
}