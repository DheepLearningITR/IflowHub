/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('effectiveGroupMembership Response', body, 'text/json');
  }
  body = JSON.parse(body);
  var department = String(message.getProperty('departmentName'));
  var division = String(message.getProperty('divisionName'));
  var location = String(message.getProperty('locationName'));
  var costCenterName = String(message.getProperty('costCenterName'));
  var employeeTypeLabel = String(message.getProperty('employeeTypeLabel'));
  var isDepartmentChanged = isGroupChanged(department, body.d, 'department', 'departments');
  var isDivisionChanged = isGroupChanged(division, body.d, 'division', 'divisions');
  var islocationChanged = isGroupChanged(location, body.d, 'location', 'locations');
  var isCostCenterChanged = isGroupChanged(costCenterName, body.d, 'costCenter', 'costCenters');
  var isEmployeeTypeChanged = isGroupChanged(employeeTypeLabel, body.d, 'employeeType', 'employeeTypes');
  var logMessageProperty = message.getProperty('LogMessageProperty');
  if (messageLog && logMessageProperty && logMessageProperty.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('isGroupsChanged', 'Department = ' + isDepartmentChanged + ' Division = ' + isDivisionChanged + ' Location = ' + islocationChanged + ' Cost Center = ' + isCostCenterChanged + ' Employee Type = ' + isEmployeeTypeChanged, 'text/json');
  }
  message.setProperty('isDepartmentChanged', isDepartmentChanged);
  message.setProperty('isDivisionChanged', isDivisionChanged);
  message.setProperty('islocationChanged', islocationChanged);
  message.setProperty('isCostCenterChanged', isCostCenterChanged);
  message.setProperty('isEmployeeTypeChanged', isEmployeeTypeChanged);
  return message;
}

function isGroupChanged(groupValue, responseBody, groupSingular, groupPlural) {
  var isGroupChangedBoolean = true;
  var groupEntry = [];
  if (responseBody[groupPlural]) {
    groupEntry = responseBody[groupPlural].filter(function(g) {
      return (g[groupSingular]) ? compareString(g[groupSingular][groupSingular].displayText, groupValue) : false;
    });
  }
  if (groupEntry.length) {
    isGroupChangedBoolean = false;
  }
  return isGroupChangedBoolean;
}

function compareString(str1, str2) {
  return (str1 && str2) ? (str1 === str2) : false;
}