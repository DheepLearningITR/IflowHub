/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  processUserEntityPerUser(message, body, messageLog);
  return message;
}

function processUserEntityPerUser(message, body, messageLog) {
  var jsonBody = JSON.parse(body);
  if (jsonBody.User.userId) {
    var userId = jsonBody.User.userId;
    message.setHeader('processUser', 'Yes');
    message.setProperty('userJSON', body);
    message.setProperty('userId', userId);
    var logMessageBody = message.getProperty('LogMessageBody');
    if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
      messageLog.addAttachmentAsString('Active User:', body, 'text/xml');
    }
  } else {
    message.setHeader('processUser', 'No');
  }
}