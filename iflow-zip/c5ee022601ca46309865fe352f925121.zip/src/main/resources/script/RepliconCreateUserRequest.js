/* eslint-disable prefer-destructuring, no-useless-escape*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var nullParameters = [ 'N/A', 'null', 'undefined', '', null ];
  var messageLog = messageLogFactory.getMessageLog(message);
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var userJson = String(message.getProperty('userJSON'));
  var user = JSON.parse(userJson);
  var rootDepartment = String(message.getProperty('Root_Department'));
  var firstName = user.User.firstName;
  var lastName = user.User.lastName;
  var emailAddress = user.User.email;
  var loginName = user.User.username;
  var personIdExternal = null;
  if (user.User.personKeyNav && user.User.personKeyNav.PersonKey && user.User.personKeyNav.PersonKey.personIdExternal) {
    personIdExternal = user.User.personKeyNav.PersonKey.personIdExternal;
  }
  var employeeId = personIdExternal;
  var password = null;
  password = checkIfTagValueIsNull(nullParameters, personIdExternal) ? generatePassword('Replicon', personIdExternal) : null;
  var employeeStartDate = null;
  if (user.User.empInfo && user.User.empInfo.EmpEmployment && user.User.empInfo.EmpEmployment.startDate) {
    employeeStartDate = user.User.empInfo.EmpEmployment.startDate;
  }
  employeeStartDate = checkIfTagValueIsNull(nullParameters, employeeStartDate) ? employeeStartDate : null;
  employeeStartDate = employeeStartDate ? getRepliconDateObject(getDateValue(employeeStartDate)) : null;
  var employeeEndDate = null;
  if (user.User.empInfo && user.User.empInfo.EmpEmployment && user.User.empInfo.EmpEmployment.endDate) {
    employeeEndDate = user.User.empInfo.EmpEmployment.endDate;
  }
  employeeEndDate = checkIfTagValueIsNull(nullParameters, employeeEndDate) ? employeeEndDate : null;
  employeeEndDate = employeeEndDate ? getRepliconDateObject(getDateValue(employeeEndDate)) : null;
  var customFieldGroupUri = String(message.getProperty('customFieldGroupUri'));
  var dateOfBirth = null;
  if (user.User.empInfo && user.User.empInfo.EmpEmployment && user.User.empInfo.EmpEmployment.personNav.PerPerson && user.User.empInfo.EmpEmployment.personNav.PerPerson.dateOfBirth) {
    dateOfBirth = user.User.empInfo.EmpEmployment.personNav.PerPerson.dateOfBirth;
  }
  dateOfBirth = checkIfTagValueIsNull(nullParameters, dateOfBirth) ? dateOfBirth : null;
  dateOfBirth = dateOfBirth ? getRepliconDateObject(getDateValue(dateOfBirth)) : null;

  var departmentName = String(message.getProperty('departmentName'));
  departmentName = checkIfTagValueIsNull(nullParameters, departmentName) ? departmentName : null;

  var divisionName = String(message.getProperty('divisionName'));
  divisionName = checkIfTagValueIsNull(nullParameters, divisionName) ? divisionName : null;
  var locationName = String(message.getProperty('locationName'));
  locationName = checkIfTagValueIsNull(nullParameters, locationName) ? locationName : null;
  var costCenterName = String(message.getProperty('costCenterName'));
  costCenterName = checkIfTagValueIsNull(nullParameters, costCenterName) ? costCenterName : null;
  var employeeTypeLabel = String(message.getProperty('employeeTypeLabel'));
  employeeTypeLabel = checkIfTagValueIsNull(nullParameters, employeeTypeLabel) ? employeeTypeLabel : null;

  var timeZoneUri = String(message.getProperty('timeZoneUri'));
  timeZoneUri = checkIfTagValueIsNull(nullParameters, timeZoneUri) ? timeZoneUri : null;

  var policySetUris = String(message.getProperty('UserTemplatesAssigned'));
  policySetUris = policySetUris ? policySetUris.split(',') : null;
  var permissionSetUris = String(message.getProperty('UserPermissionSetsAssigned'));
  permissionSetUris = permissionSetUris ? permissionSetUris.split(',') : null;
  var approvalPath = String(message.getProperty('timesheetApprovalPath'));
  var userRequest = createUserRequest(loginName, password, timeZoneUri, costCenterName, employeeTypeLabel, locationName, divisionName, rootDepartment, departmentName, customFieldGroupUri, dateOfBirth, policySetUris, permissionSetUris, firstName, lastName, emailAddress, employeeStartDate, employeeEndDate, employeeId, approvalPath);
  var logMessageBody = message.getProperty('LogMessageBody');
  userRequest = JSON.stringify(userRequest);
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(userRequest);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('addUserJson with name ' + firstName + ',' + lastName + ' Request:', userRequest, 'text/json');
  }
  return message;
}

function createUserRequest(loginName, password, timeZoneUri, costCenterName, employeeTypeLabel, locationName, divisionName, rootDepartment, departmentName, customFieldGroupUri, dateOfBirth, policySetUris, permissionSetUris, firstName, lastName, emailAddress, employeeStartDate, employeeEndDate, employeeId, approvalPath) {
  return {
    user: {
      loginName: loginName,
      firstname: truncateString(firstName, 50),
      lastname: truncateString(lastName, 50),
      customFieldValues: customFieldGroupUri && dateOfBirth ? [
        {
          customField: {
            name: 'Date of Birth',
            groupUri: customFieldGroupUri
          },
          date: dateOfBirth
        }
      ] : null
    },
    modifications: {
      timezoneToApply: timeZoneUri ? {
        userTimeZoneModificationOptionUri: 'urn:replicon:user-time-zone-modication-option:use-specified-time-zone',
        timezone: {
          uri: timeZoneUri
        }
      } : {
        userTimeZoneModificationOptionUri: 'urn:replicon:user-time-zone-modication-option:use-company-time-zone'
      },
      locationScheduleToApply: locationName ? {
        userLocationScheduleModificationOptionUri: 'urn:replicon:schedule-modification-option:replace-entire-schedule',
        replacementLocationSchedule: [
          {
            location: {
              name: locationName
            }
          }
        ]
      } : null,
      divisionScheduleToApply: divisionName ? {
        userDivisionScheduleModificationOptionUri: 'urn:replicon:schedule-modification-option:replace-entire-schedule',
        replacementDivisionSchedule: [
          {
            division: {
              name: divisionName
            }
          }
        ]
      } : null,
      costCenterScheduleToApply: costCenterName ? {
        userCostCenterScheduleModificationOptionUri: 'urn:replicon:schedule-modification-option:replace-entire-schedule',
        replacementCostCenterSchedule: [
          {
            costCenter: {
              name: costCenterName
            }
          }
        ]
      } : null,
      departmentGroupScheduleToApply: departmentName ? {
        userDepartmentGroupScheduleModificationOptionUri: 'urn:replicon:schedule-modification-option:replace-entire-schedule',
        replacementDepartmentGroupSchedule: [
          {
            departmentGroup: {
              parent: {
                name: rootDepartment
              },
              name: departmentName
            }
          }
        ]
      } : null,
      employeeTypeGroupScheduleToApply: employeeTypeLabel ? {
        userEmployeeTypeGroupScheduleModificationOptionUri: 'urn:replicon:schedule-modification-option:replace-entire-schedule',
        replacementEmployeeTypeGroupSchedule: [
          {
            employeeTypeGroup: {
              name: employeeTypeLabel
            }
          }
        ]
      } : null,
      policySetsToApply: policySetUris ? {
        policySetUrisToAssign: policySetUris
      } : null,
      permissionSetsToApply: permissionSetUris ? {
        permissionSetUrisToAssign: permissionSetUris
      } : null,
      timesheetApprovalPathToApply: approvalPath ? {
        uri: approvalPath
      } : null,
      userDetailsToApply: {
        firstName: truncateString(firstName, 50),
        lastName: truncateString(lastName, 50),
        emailAddress: validateEmail(emailAddress) ? {
          emailAddress: emailAddress
        } : null,
        employmentStartDate: employeeStartDate ? {
          date: employeeStartDate
        } : null,
        employmentEndDate: employeeEndDate ? {
          date: employeeEndDate
        } : null,
        employeeId: employeeId ? {
          employeeId: employeeId
        } : null
      },
      securitySettingsToApply: password ? {
        loginEnabled: true,
        forcePasswordChange: true,
        loginName: loginName,
        password: password,
        enabledAuthenticationTypeUris: [ 'urn:replicon:user-authentication-type:replicon' ]
      } : null
    },
    userModificationOptionUri: 'urn:replicon:user-modification-option:save',
    unitOfWorkId: makeid(8)
  };
}

function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

function getRepliconDateObject(dateValue) {
  var repliconDate = null;
  if (dateValue) {
    repliconDate = {
      year: dateValue.getFullYear(),
      month: dateValue.getMonth() + 1,
      day: dateValue.getDate()
    };
  }
  return repliconDate;
}

function getDateValue(dateValue) {
  try {
    var regex = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/;
    var dateArray = regex.exec(dateValue);
    var syncDate = new Date(
      (Number(dateArray[1])),
      (Number(dateArray[2])) - 1,
      (Number(dateArray[3])),
      (Number(dateArray[4])),
      (Number(dateArray[5])),
      (Number(dateArray[6]))
    );
    return syncDate;
  } catch (e) {
    return null;
  }
}

function truncateString(str, limit) {
  return (str && str.length > limit) ? str.substring(0, limit) : str;
}

function checkIfTagValueIsNull(array, element) {
  var index = array.indexOf(element);
  return (index > -1) ? null : index;
}

function generatePassword(prefix, id) {
  return prefix + '@' + id;
}

function validateEmail(email) {
  const re = /^([a-z0-9\+\-]+)(\.[a-z0-9\+\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/gi;
  return (re.test(email)) ? email : null;
}