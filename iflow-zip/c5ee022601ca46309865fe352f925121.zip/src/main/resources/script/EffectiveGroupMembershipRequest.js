importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  var token = message.getProperty('RepliconToken');
  var applicationName = message.getProperty('ApplicationName');
  var userUri = String(message.getProperty('userUri'));
  var effectiveGroupMembership = {
    userUri: userUri,
    dateRange: {
      startDate: getUTCDate()
    }
  };
  effectiveGroupMembership = JSON.stringify(effectiveGroupMembership);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('effectiveGroupMembership Request', effectiveGroupMembership, 'text/json');
  }
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setHeader('Content-Type', 'application/json');
  message.setBody(effectiveGroupMembership);
  return message;
}

function getUTCDate() {
  const dateObj = new Date();
  const month = dateObj.getUTCMonth() + 1;
  const day = dateObj.getUTCDate();
  const year = dateObj.getUTCFullYear();
  return { year: year, month: month, day: day };
}