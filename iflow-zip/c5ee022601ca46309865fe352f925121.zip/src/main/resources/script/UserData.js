
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  var userListJson = JSON.parse(body);
  if (userListJson.d && userListJson.d.length && userListJson.d[0] !== null) {
    message.setHeader('userExist', 'Yes');
    message.setProperty('userUri', userListJson.d[0].uri);
    if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
      messageLog.addAttachmentAsString('User: ' + userListJson.d[0].displayText + ' exists with body response', body, 'text/json');
    }
  } else {
    message.setHeader('userExist', 'No');
  }
  return message;
}