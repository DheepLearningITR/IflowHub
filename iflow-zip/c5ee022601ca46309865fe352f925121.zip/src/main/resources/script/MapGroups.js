importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  setPropertiesBasedOnResponseBody(body, message);
  var logMessageBody = message.getProperty('LogMessageBody');
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Employee Job JSON Response:', body, 'text/json');
  }
  return message;
}

function setPropertiesBasedOnResponseBody(body, message) {
  body = JSON.parse(body);
  var employeeTypeLabel = 'null';
  var employeeTypeId = 'null';
  var divisionName = 'null';
  var divisionId = 'null';
  var locationName = 'null';
  var locationId = 'null';
  var departmentName = 'null';
  var departmentId = 'null';
  var costCenterName = 'null';
  var costCenterId = 'null';
  if (body.EmpJob) {
    if (body.EmpJob.employmentTypeNav && body.EmpJob.employmentTypeNav.PicklistOption && body.EmpJob.employmentTypeNav.PicklistOption.localeLabel && body.EmpJob.employmentTypeNav.PicklistOption.id) {
      employeeTypeLabel = truncateString(body.EmpJob.employmentTypeNav.PicklistOption.localeLabel, 100);
      employeeTypeId = truncateString(body.EmpJob.employmentTypeNav.PicklistOption.id, 50);
    }
    if (body.EmpJob.divisionNav && body.EmpJob.divisionNav.FODivision && body.EmpJob.divisionNav.FODivision.name && body.EmpJob.divisionNav.FODivision.externalCode) {
      divisionName = body.EmpJob.divisionNav.FODivision.name;
      divisionId = body.EmpJob.divisionNav.FODivision.externalCode;
    }
    if (body.EmpJob.locationNav && body.EmpJob.locationNav.FOLocation && body.EmpJob.locationNav.FOLocation.name && body.EmpJob.locationNav.FOLocation.externalCode) {
      locationName = body.EmpJob.locationNav.FOLocation.name;
      locationId = body.EmpJob.locationNav.FOLocation.externalCode;
    }
    if (body.EmpJob.departmentNav && body.EmpJob.departmentNav.FODepartment && body.EmpJob.departmentNav.FODepartment.name && body.EmpJob.departmentNav.FODepartment.externalCode) {
      departmentName = body.EmpJob.departmentNav.FODepartment.name;
      departmentId = body.EmpJob.departmentNav.FODepartment.externalCode;
    }
    if (body.EmpJob.costCenterNav && body.EmpJob.costCenterNav.FOCostCenter && body.EmpJob.costCenterNav.FOCostCenter.name && body.EmpJob.costCenterNav.FOCostCenter.externalCode) {
      costCenterName = body.EmpJob.costCenterNav.FOCostCenter.name;
      costCenterId = body.EmpJob.costCenterNav.FOCostCenter.externalCode;
    }
  }
  message.setProperty('employeeTypeLabel', employeeTypeLabel);
  message.setProperty('employeeTypeId', employeeTypeId);
  message.setProperty('costCenterName', costCenterName);
  message.setProperty('costCenterId', costCenterId);
  message.setProperty('divisionName', divisionName);
  message.setProperty('divisionId', divisionId);
  message.setProperty('locationName', locationName);
  message.setProperty('locationId', locationId);
  message.setProperty('departmentName', departmentName);
  message.setProperty('departmentId', departmentId);
}

function truncateString(str, limit) {
  return (str && str.length > limit) ? str.substring(0, limit) : str;
}