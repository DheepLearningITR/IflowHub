/* eslint-disable prefer-destructuring, no-useless-escape*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var nullParameters = [ 'N/A', 'null', 'undefined', '', 'false', null ];
  var messageLog = messageLogFactory.getMessageLog(message);
  var token = String(message.getProperty('RepliconToken'));
  var applicationName = String(message.getProperty('ApplicationName'));
  var userJson = String(message.getProperty('userJSON'));
  var user = JSON.parse(userJson);
  var rootDepartment = String(message.getProperty('Root_Department'));
  var firstName = user.User.firstName;
  var lastName = user.User.lastName;
  var emailAddress = user.User.email;
  var employeeId = null;
  if (user.User.personKeyNav && user.User.personKeyNav.PersonKey && user.User.personKeyNav.PersonKey.personIdExternal) {
    employeeId = user.User.personKeyNav.PersonKey.personIdExternal;
  }
  var userUri = String(message.getProperty('userUri'));
  var employeeStartDate = null;
  if (user.User.empInfo && user.User.empInfo.EmpEmployment && user.User.empInfo.EmpEmployment.startDate) {
    employeeStartDate = user.User.empInfo.EmpEmployment.startDate;
  }
  employeeStartDate = checkIfTagValueIsNull(nullParameters, employeeStartDate) ? employeeStartDate : null;
  employeeStartDate = employeeStartDate ? getRepliconDateObject(getDateValue(employeeStartDate)) : null;
  var employeeEndDate = null;
  if (user.User.empInfo && user.User.empInfo.EmpEmployment && user.User.empInfo.EmpEmployment.endDate) {
    employeeEndDate = user.User.empInfo.EmpEmployment.endDate;
  }
  employeeEndDate = checkIfTagValueIsNull(nullParameters, employeeEndDate) ? employeeEndDate : null;
  employeeEndDate = employeeEndDate ? getRepliconDateObject(getDateValue(employeeEndDate)) : null;
  var customFieldGroupUri = String(message.getProperty('customFieldGroupUri'));
  var dateOfBirth = null;
  if (user.User.empInfo && user.User.empInfo.EmpEmployment && user.User.empInfo.EmpEmployment.personNav.PerPerson && user.User.empInfo.EmpEmployment.personNav.PerPerson.dateOfBirth) {
    dateOfBirth = user.User.empInfo.EmpEmployment.personNav.PerPerson.dateOfBirth;
  }
  dateOfBirth = checkIfTagValueIsNull(nullParameters, dateOfBirth) ? dateOfBirth : null;
  dateOfBirth = dateOfBirth ? getRepliconDateObject(getDateValue(dateOfBirth)) : null;

  var departmentName = String(message.getProperty('departmentName'));
  departmentName = checkIfTagValueIsNull(nullParameters, departmentName) ? departmentName : null;
  var isDepartmentChanged = String(message.getProperty('isDepartmentChanged'));
  isDepartmentChanged = checkIfTagValueIsNull(nullParameters, isDepartmentChanged) ? isDepartmentChanged : null;
  var divisionName = String(message.getProperty('divisionName'));
  divisionName = checkIfTagValueIsNull(nullParameters, divisionName) ? divisionName : null;
  var isDivisionChanged = String(message.getProperty('isDivisionChanged'));
  isDivisionChanged = checkIfTagValueIsNull(nullParameters, isDivisionChanged) ? isDivisionChanged : null;
  var locationName = String(message.getProperty('locationName'));
  locationName = checkIfTagValueIsNull(nullParameters, locationName) ? locationName : null;
  var islocationChanged = String(message.getProperty('islocationChanged'));
  islocationChanged = checkIfTagValueIsNull(nullParameters, islocationChanged) ? islocationChanged : null;
  var costCenterName = String(message.getProperty('costCenterName'));
  costCenterName = checkIfTagValueIsNull(nullParameters, costCenterName) ? costCenterName : null;
  var isCostCenterChanged = String(message.getProperty('isCostCenterChanged'));
  isCostCenterChanged = checkIfTagValueIsNull(nullParameters, isCostCenterChanged) ? isCostCenterChanged : null;
  var employeeTypeLabel = String(message.getProperty('employeeTypeLabel'));
  employeeTypeLabel = checkIfTagValueIsNull(nullParameters, employeeTypeLabel) ? employeeTypeLabel : null;
  var isEmployeeTypeChanged = String(message.getProperty('isEmployeeTypeChanged'));
  isEmployeeTypeChanged = checkIfTagValueIsNull(nullParameters, isEmployeeTypeChanged) ? isEmployeeTypeChanged : null;

  var timeZoneUri = String(message.getProperty('timeZoneUri'));
  timeZoneUri = checkIfTagValueIsNull(nullParameters, timeZoneUri) ? timeZoneUri : null;

  var userRequest = updateUserRequest(userUri, timeZoneUri, isEmployeeTypeChanged, employeeTypeLabel, isCostCenterChanged, costCenterName, islocationChanged, locationName, isDivisionChanged, divisionName, rootDepartment, isDepartmentChanged, departmentName, customFieldGroupUri, dateOfBirth, firstName, lastName, emailAddress, employeeStartDate, employeeEndDate, employeeId);
  var logMessageBody = message.getProperty('LogMessageBody');
  userRequest = JSON.stringify(userRequest);
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('updateUserJson with name ' + firstName + ',' + lastName + ' Request:', userRequest, 'text/json');
  }
  message.setHeader('Content-Type', 'application/json');
  message.setHeader('Authorization', token);
  message.setHeader('X-Replicon-Application', applicationName);
  message.setBody(userRequest);
  return message;
}

function updateUserRequest(userUri, timeZoneUri, isEmployeeTypeChanged, employeeTypeLabel, isCostCenterChanged, costCenterName, islocationChanged, locationName, isDivisionChanged, divisionName, rootDepartment, isDepartmentChanged, departmentName, customFieldGroupUri, dateOfBirth, firstName, lastName, emailAddress, employeeStartDate, employeeEndDate, employeeId) {
  return {
    user: {
      uri: userUri
    },
    modifications: {
      timezoneToApply: timeZoneUri ? {
        userTimeZoneModificationOptionUri: 'urn:replicon:user-time-zone-modication-option:use-specified-time-zone',
        timezone: {
          uri: timeZoneUri
        }
      } : {
        userTimeZoneModificationOptionUri: 'urn:replicon:user-time-zone-modication-option:use-company-time-zone'
      },
      locationScheduleToApply: locationName && islocationChanged ? {
        userLocationScheduleModificationOptionUri: 'urn:replicon:schedule-modification-option:update-schedule-over-date-range',
        updateLocationScheduleOverDateRange: {
          replacementLocationScheduleEntries: [
            {
              location: {
                name: locationName
              },
              effectiveDate: getUTCDate()
            }
          ]
        }
      } : null,
      divisionScheduleToApply: divisionName && isDivisionChanged ? {
        userDivisionScheduleModificationOptionUri: 'urn:replicon:schedule-modification-option:update-schedule-over-date-range',
        updateDivisionScheduleOverDateRange: {
          replacementDivisionScheduleEntries: [
            {
              division: {
                name: divisionName
              },
              effectiveDate: getUTCDate()
            }
          ]
        }
      } : null,
      costCenterScheduleToApply: costCenterName && isCostCenterChanged ? {
        userCostCenterScheduleModificationOptionUri: 'urn:replicon:schedule-modification-option:update-schedule-over-date-range',
        replacementCostCenterSchedule: [],
        updateCostCenterScheduleOverDateRange: {
          replacementCostCenterScheduleEntries: [
            {
              costCenter: {
                name: costCenterName
              },
              effectiveDate: getUTCDate()
            }
          ]
        }
      } : null,
      departmentGroupScheduleToApply: departmentName && isDepartmentChanged ? {
        userDepartmentGroupScheduleModificationOptionUri: 'urn:replicon:schedule-modification-option:update-schedule-over-date-range',
        updateDepartmentGroupScheduleOverDateRange: {
          replacementDepartmentGroupScheduleEntries: [
            {
              departmentGroup: {
                parent: {
                  name: rootDepartment
                },
                name: departmentName
              },
              effectiveDate: getUTCDate()
            }
          ]
        }
      } : null,
      employeeTypeGroupScheduleToApply: employeeTypeLabel && isEmployeeTypeChanged ? {
        userEmployeeTypeGroupScheduleModificationOptionUri: 'urn:replicon:schedule-modification-option:update-schedule-over-date-range',
        updateEmployeeTypeGroupScheduleOverDateRange: {
          replacementEmployeeTypeGroupScheduleEntries: [
            {
              employeeTypeGroup: {
                name: employeeTypeLabel
              },
              effectiveDate: getUTCDate()
            }
          ]
        }
      } : null,
      customFieldValuesToApply: customFieldGroupUri && dateOfBirth ? [
        {
          customField: {
            name: 'Date of Birth',
            groupUri: customFieldGroupUri
          },
          date: dateOfBirth
        }
      ] : null,
      userDetailsToApply: {
        firstName: truncateString(firstName, 50),
        lastName: truncateString(lastName, 50),
        emailAddress: validateEmail(emailAddress) ? {
          emailAddress: emailAddress
        } : null,
        employmentStartDate: employeeStartDate ? {
          date: employeeStartDate
        } : null,
        employmentEndDate: employeeEndDate ? {
          date: employeeEndDate
        } : null,
        employeeId: employeeId ? {
          employeeId: employeeId
        } : null
      }
    },
    userModificationOptionUri: 'urn:replicon:user-modification-option:save'
  };
}

function getRepliconDateObject(dateValue) {
  var repliconDate = null;
  if (dateValue) {
    repliconDate = {
      year: dateValue.getFullYear(),
      month: dateValue.getMonth() + 1,
      day: dateValue.getDate()
    };
  }
  return repliconDate;
}

function getDateValue(dateValue) {
  try {
    var regex = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/;
    var dateArray = regex.exec(dateValue);
    var syncDate = new Date(
      (Number(dateArray[1])),
      (Number(dateArray[2])) - 1,
      (Number(dateArray[3])),
      (Number(dateArray[4])),
      (Number(dateArray[5])),
      (Number(dateArray[6]))
    );
    return syncDate;
  } catch (e) {
    return null;
  }
}

function getUTCDate() {
  const dateObj = new Date();
  const month = dateObj.getUTCMonth() + 1;
  const day = dateObj.getUTCDate();
  const year = dateObj.getUTCFullYear();
  return { year: year, month: month, day: day };
}

function truncateString(str, limit) {
  return (str && str.length > limit) ? str.substring(0, limit) : str;
}

function checkIfTagValueIsNull(array, element) {
  var index = array.indexOf(element);
  return (index > -1) ? null : index;
}

function validateEmail(email) {
  const re = /^([a-z0-9\+\-]+)(\.[a-z0-9\+\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/gi;
  return (re.test(email)) ? email : null;
}