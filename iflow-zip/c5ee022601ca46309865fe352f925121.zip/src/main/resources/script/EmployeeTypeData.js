/* eslint-disable prefer-destructuring*/
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var nullParameters = [ 'N/A', 'null', 'undefined' ];
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  body = JSON.parse(body);
  var employeeTypeLabel = String(message.getProperty('employeeTypeLabel'));
  employeeTypeLabel = checkIfTagValueIsNull(nullParameters, employeeTypeLabel) ? employeeTypeLabel : null;
  var employeeTypeId = String(message.getProperty('employeeTypeId'));
  employeeTypeId = checkIfTagValueIsNull(nullParameters, employeeTypeId) ? employeeTypeId : null;
  var employeeTypeGroupValues = filterGroupsByListData(employeeTypeLabel, employeeTypeId, body.d.rows);
  var employeeTypeGroupUri = employeeTypeGroupValues[0];
  message.setProperty('employeeTypeLabel', employeeTypeLabel);
  var logMessageProperty = message.getProperty('LogMessageProperty');
  if (messageLog && logMessageProperty && logMessageProperty.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('EmployeeTypeGroupUri:', employeeTypeGroupUri, 'text/json');
  }
  if (!employeeTypeGroupValues[2] || !employeeTypeLabel || !employeeTypeId) {
    message.setHeader('isCreateEmployeeType', 'No');
  } else {
    message.setProperty('employeeTypeGroupUri', employeeTypeGroupUri);
    message.setHeader('isCreateEmployeeType', 'Yes');
  }
  return message;
}

function filterGroupsByListData(groupName, groupId, responseBody) {
  var groupNameIdCombined = groupName + ' (' + groupId + ')';
  if (responseBody.length > 0) {
    for (var index = 0; index < responseBody.length; index++) {
      if (responseBody[index].cells && responseBody[index].cells.length && responseBody[index].cells[2] !== null) {
        if (responseBody[index].cells[2].textValue === groupId) {
          // if groupId matches code
          if ((responseBody[index].cells[1].textValue === groupName) || (responseBody[index].cells[1].textValue === groupNameIdCombined)) {
            // if replicon group name matches SFSF groupName or SFSF name + id. match and assign
            return [ responseBody[index].cells[0].uri, responseBody[index].cells[1].textValue, false ];
          }
          // else update group name
          return [ responseBody[index].cells[0].uri, groupName, true ];
        }
      }
    }
    // Create group with code inside parenthesis
    return [ 'null', groupNameIdCombined, true ];
  }
  // if rows are not present, create cost center directly with name
  return [ 'null', groupName, true ];
}

function checkIfTagValueIsNull(array, element) {
  var index = array.indexOf(element);
  return (index > -1) ? null : index;
}
