importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  var logMessageBody = message.getProperty('LogMessageBody');
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Success Factors XML Response:', body, 'text/xml');
  }
  return message;
}
