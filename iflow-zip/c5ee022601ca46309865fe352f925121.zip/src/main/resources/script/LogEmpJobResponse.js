importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = message.getBody(new java.lang.String().getClass());
  var messageLog = messageLogFactory.getMessageLog(message);
  setMessageHeaderBasedOnResponseBody(body, message);
  var logMessageBody = message.getProperty('LogMessageBody');
  if (messageLog && logMessageBody && logMessageBody.equalsIgnoreCase('yes')) {
    messageLog.addAttachmentAsString('Employee Job XML Response:', body, 'text/xml');
  }
  return message;
}

function setMessageHeaderBasedOnResponseBody(body, message) {
  if (body.startsWith('<EmpJob/>')) {
    message.setHeader('ProcessEmpJobResponse', 'No');
    message.setProperty('employeeTypeLabel', 'null');
    message.setProperty('employeeTypeId', 'null');
    message.setProperty('costCenterName', 'null');
    message.setProperty('costCenterId', 'null');
  } else {
    message.setHeader('ProcessEmpJobResponse', 'Yes');
  }
}
