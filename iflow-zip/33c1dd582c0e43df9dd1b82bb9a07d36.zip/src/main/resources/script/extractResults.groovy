import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def String getFilter(conditionRecords){

    def filter = ""
    if (conditionRecords instanceof List){

        conditionRecords?.each {
            it ->
                if (filter) filter = filter + " or ConditionRecord eq '" + it + "'"
                else filter = "ConditionRecord eq '" + it + "'"
        }
    } else {
        filter = "ConditionRecord eq '" + conditionRecords + "'"
    }

    return filter

}

def Message buildFilter(Message message) {


    def body = message.getBody(String.class)

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)

    def filter = getFilter(json?.conditionRecord)

    message.setProperty("filter", filter)

    return message
}

def Message buildFilterFromPfxResponse(Message message) {


    def body = message.getBody(String.class)

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)

    def filter = getFilter(json?.attribute16)


    message.setProperty("filter", filter)

    return message
}

def Message extractDataWithCleansing(Message message) {


    def body = message.getBody(String.class)

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)

    def finalBody

    if (json.record instanceof List){

        finalBody = json

    } else {
        finalBody = [json]

    }
    finalBody = finalBody?.findAll{it}
    message.setBody(JsonOutput.toJson(finalBody))

    return message
}


Message countProcessedFinal(Message message){
    def body = message.getBody(String.class)

    if (body?.isNumber()){
        message.setProperty("totalProcessedFinal",""+(Integer.parseInt(message.getProperty("totalProcessedFinal"))+ Integer.parseInt(body)))
    }

    return message
}
