import com.sap.gateway.ip.core.customdev.util.Message; 

def Message processData(Message message) {

def body = message.getBody(String);
body = body.replaceAll("\\n", "");
body = body.replaceAll("\\r", "");
message.setBody(body);
return message;

}