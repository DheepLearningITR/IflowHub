import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap; 

def Message processData(Message message) {

def body = message.getBody(byte[].class)
String encoded = body.encodeBase64().toString();
message.setBody(encoded);
return message;

}