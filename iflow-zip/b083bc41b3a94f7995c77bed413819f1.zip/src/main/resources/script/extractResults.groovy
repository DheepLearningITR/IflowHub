import com.sap.gateway.ip.core.customdev.util.Message

Message countProcessedFinal(Message message){
    def body = message.getBody(String.class)
    
    if (body?.isNumber()){
        message.setProperty("totalProcessedFinal",""+(Integer.parseInt(message.getProperty("totalProcessedFinal"))+ Integer.parseInt(body)))
        message.setProperty("isError","false")
    }else{
        message.setProperty("isError","true")
    }
    
    return message
}
