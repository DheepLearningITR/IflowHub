import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message)

{

def removal=message.getBody(java.lang.String) as String;

removal=removal.replace(/m:,""/)

message.setBody(removal);

return message;

}
