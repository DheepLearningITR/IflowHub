/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def getRedirectedURL(originalUrl, httpMethod, currentHop, maxHops) {
	if (currentHop == maxHops) {
		throw new RuntimeException('Ops! Too many hops');
	}
	currentHop += 1;
	HttpURLConnection conn = new URL(originalUrl).openConnection();
	conn.setInstanceFollowRedirects(false); //We want to "explore" the redirections, so we can check them one-by-one
	conn.requestMethod = httpMethod; //Consider checking only "Safe-Methods"
	//Here you may validate whether the target URL is a "Safe" URL: Host, HTTPS, etc. (ValueMapping?)
		if(conn.responseCode in [301,302,307,308]) { //some redirections may changes the Http Method! (301,302)
		if (conn.headerFields.'Location') {
		  def targetUrl = conn.headerFields.Location.first();
		  DirtyLog.jumpList += targetUrl + "\n";
		  return getRedirectedURL(targetUrl,httpMethod,currentHop, maxHops);
		}
		else {
			throw new RuntimeException('Failed to retrive target URL');
		}
	}
	return originalUrl;
}