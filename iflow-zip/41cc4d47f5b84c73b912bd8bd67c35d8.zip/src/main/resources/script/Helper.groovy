import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput



def Message prepareCustomQueryForODATACall(Message message) {

  //Properties
  def properties = message.getProperties();
  def client = properties.get("P_Client")
  def lang = properties.get("P_Language")

  if (lang.length() == 0) {
    lang = "EN"
    message.setProperty("P_Language", lang)
  }
  if (client.length() == 0)
    message.setProperty("P_CustomQuery", "sap-language=" + lang)
  else
    message.setProperty("P_CustomQuery", "sap-client=" + client + "&" + "sap-language=" + lang)
  return message
}



def Message prepareFilterQuery(Message message) {
   
       def map = message.getProperties()
      
       def LastChangeDateTimeFrom = map.get("p_LastChangeDateTimeFrom")
       def LastChangeDateTimeTo = map.get("p_LastChangeDateTimeTo")
       def query = "LastChangeDateTime ge datetimeoffset" + "'" + LastChangeDateTimeFrom + "' and LastChangeDateTime le datetimeoffset"+ "'" + LastChangeDateTimeTo + "'"
       
       def additionalFilterCondition = map.get("P_OptionalFilter")
       if (additionalFilterCondition.length() > 0){
           query = query + ' and ' + additionalFilterCondition
       }
            
       if (map.get("p_skiprecords")){
            Integer skiprecords = map.get("p_skiprecords").toInteger()
            if (skiprecords > 0) {
                query = query + "&" + "\$" + "skip=" + skiprecords.toString()
            }
       }
        
       message.setProperty("filterQuery", query)
       
       return message
}





def Message enrichJsonOutput(Message message) {
  //Body 
  def body = message.getBody(java.io.Reader);

  JsonSlurper slurper = new JsonSlurper()
  Map parsedJson = slurper.parse(body)

  parsedJson.messageRequests.each {

    if (it.body.isBlocked) {
      it.body.isBlocked = Boolean.parseBoolean(it.body.isBlocked)
    }

    if (it.body.isDeleted) {
      it.body.isDeleted = Boolean.parseBoolean(it.body.isDeleted)
    }
    if (it.body.country?.length() == 0) 
      it.body.country = null
    
    if (it.body.postalCode?.length() == 0) 
      it.body.postalCode = null
    
    if (it.body.house?.length() == 0) 
      it.body.house = null    

    if (it.body.room?.length() == 0) 
      it.body.room = null
    
    if (it.body.building?.length() == 0) 
      it.body.building = null    

    if (it.body.streetName?.length() == 0) 
      it.body.streetName = null    

    if (it.body.cityName?.length() == 0) 
      it.body.cityName = null    

    if (it.body.floor?.length() == 0) 
      it.body.floor = null    

    if (it.body.region?.length() == 0)
        it.body.region = null

    it.body.customerInformation?.each{
        if (it.languageCode?.length() == 0)
            it.languageCode = null
        if (it.content?.length() == 0)
            it.content = null    
    }

  }

  def respbody = JsonOutput.toJson(parsedJson)
  message.setBody(respbody)
  
  //Set the C4C message ID as customer monitoring header
   def messageLog = messageLogFactory.getMessageLog(message);
  	if(messageLog != null){
       
  		def messageHeaderId = message.getProperties().get("P_MessageHeaderId")		
  		if(messageHeaderId != null){
  			messageLog.addCustomHeaderProperty("Replication Message ID", messageHeaderId)
          }
  	}

  return message;
}

def Message calculateSkipIndex(Message message) {
    
     Integer  lastSkipCount = 0;
     Integer  currentSkipCount = 0;
     Integer  pageSize = 0;
  
       def map = message.getProperties();
       
       if (map.get("p_skiprecords")){
           lastSkipCount = map.get("p_skiprecords").toInteger();
        }
        if (map.get("SkipRecords_S4.FunctionalLocation_R")){
            currentSkipCount = map.get("SkipRecords_S4.FunctionalLocation_R").toInteger();
        }
        if (map.get("p_pageSize")){
            pageSize = map.get("p_pageSize").toInteger();
        }
       
       Integer  skipIndex = (lastSkipCount + currentSkipCount) - pageSize;
       if (skipIndex < 101){
            skipIndex = 0;
       }
       message.setProperty("skipIndexNew" , skipIndex.toString());
       return message;
}

def Message generateException(Message message) {
   
       def map = message.getProperties();
       def loopIndex = map.get("CamelLoopIndex");
       if (loopIndex >= 3)
        throw new Exception ("Explicit Exception");
       
       return message;
}