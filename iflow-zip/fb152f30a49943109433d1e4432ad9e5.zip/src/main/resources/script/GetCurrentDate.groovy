import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String current_Date_Format( ){
	return new Date().format( 'yyyyMMdd' );
}

// import com.sap.it.api.mapping.*;
// def String Matcode_Validation(String input){
//     if(input.isNumber()){
//       input = ("000000000000000000" + input).substring(input.length())
//  }
//     return input;
// }
// def String Vendor_Validation(String input){
//     if(input.isNumber()){
//       input = ("0000000000" + input).substring(input.length())
//  }
//     return input;
// }