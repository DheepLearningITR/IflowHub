
import com.sap.gateway.ip.core.customdev.util.Message

import java.text.SimpleDateFormat
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonSlurper;
import groovy.util.XmlParser;
import groovy.util.XmlSlurper;

def Message getDates(Message message) {
    def mpl = messageLogFactory.getMessageLog(message)
    def rfcResponse = new XmlSlurper().parseText(message.getBody(String));
    message.properties.ValidityStartDate = '';
    message.properties.ValidityEndDate = '';

    if (!rfcResponse.DATA.item.isEmpty()) {
        String fullText = rfcResponse.DATA.item[0].WA as String;
        if (fullText.length() >= 10) {
            message.properties.CondRecNum = fullText.substring(0, 10);
            Date startDate, endDate;
            SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
            if (fullText.length() >= 18) {
                startDate = format.parse(fullText.substring(10, 18));
                message.properties.ValidityStartDate = new SimpleDateFormat("yyyyMMdd").format(startDate);
            }
            if (fullText.length() >= 26) {
                endDate = format.parse(fullText.substring(18));
                message.properties.ValidityEndDate = new SimpleDateFormat("yyyyMMdd").format(endDate);
            }
        } else {
            message.properties.NoData = 'X';
        }
    } else {
        message.properties.NoData = 'X';
    }


    mpl.addAttachmentAsString('message.properties.ValidityStartDate ' + message.properties.ValidityStartDate, message.properties.ValidityStartDate, "text/plain");
    mpl.addAttachmentAsString('message.properties.ValidityEndDate ' + message.properties.ValidityEndDate, message.properties.ValidityEndDate, "text/plain");
    mpl.addAttachmentAsString('message.properties.CondRecNum ' + message.properties.CondRecNum, message.properties.CondRecNum, "text/plain");
    mpl.addAttachmentAsString('message.properties.NoData ' + message.properties.NoData, message.properties.NoData, "text/plain");

    return message;
}