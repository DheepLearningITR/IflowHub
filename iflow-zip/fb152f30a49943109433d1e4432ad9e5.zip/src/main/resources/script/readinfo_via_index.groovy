import com.sap.it.api.mapping.*;
def String customFunc(String input, String index){
    int i = Integer.parseInt(index)
    input = input.replaceAll("\\s+"," ");
    
    String[] value = input.split('\\s');
    if(i < value.length && value.length ==5){
    return value[i];
    
    }
    else{
        return "";
    }
}