import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.asdk.datastore.DataStoreService
import com.sap.it.api.asdk.runtime.Factory

def Message processData(Message message) {
    def body = message.getBody(java.lang.String)
    def query = new XmlParser().parseText(body)
    
    def valueMappingApi = ITApiFactory.getApi(ValueMappingApi.class, null)

    /*START: Logic to handle all & custom FSM Company mapping*/
    def allCompanies = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', 'PS', 'FSM', 'AccountCompany');
    if (allCompanies == 'ALLCOMPANIES') {
		def fsmCompanyList;
        def DSservice = new Factory(DataStoreService.class).getService()
        // get the FSM Company List from data store
        def dsEntry = DSservice.get("FSMCompanyList", 'FSMCompanyList')?DSservice.get("FSMCompanyList", 'FSMCompanyList'):'NA'
        message.setProperty("dsEntry",dsEntry);
		if (dsEntry != 'NA'){
			def result = new String(dsEntry.getDataAsArray())
			fsmCompanyList = new XmlParser().parseText(result)
			message.setProperty("fsmCompanyList",fsmCompanyList);

		}else{
		    fsmCompanyList = new XmlParser().parseText("<FSMMultiCompany><FSMCompany>NA|NA</FSMCompany></FSMMultiCompany>")
		}
		
        query.MaterialStock.each { stockMessage ->
            stockMessage.append(fsmCompanyList)
        }
    }else if (allCompanies == 'CUSTOM') {	
		def customCompany = new XmlParser().parseText("<FSMMultiCompany><FSMCompany>CUSTOM</FSMCompany></FSMMultiCompany>")

        query.MaterialStock.each { stockMessage ->
            stockMessage.append(customCompany)
            
        }
	/*END: Logic to handle all & custom Company logic*/
    }else{

        query.MaterialStock.each { stockMessage ->
                def mcXML = new XmlParser().parseText("<FSMMultiCompany></FSMMultiCompany>")
                def fsmFromValueMap = null;  
                
                //function to append account and company to incoming message
                def appendAccountCompany = { AcctComp ->
                    def entries = AcctComp.tokenize(":")
                    entries.each { entry ->
                        def (account, companies) = entry.split("\\|")
                        def companyList = companies.split(",")
                        
                        companyList.each { company ->
	    			        def fsmXml = new XmlParser().parseText("<FSMCompany>${account}|${company}</FSMCompany>")
	    			        mcXML.append(fsmXml)
                        }
                    }
                }
                
                def plant = stockMessage.'n1:Plant'.text();
                def pStockKeyMap = "PS|||PLANT|${plant}"
                fsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', pStockKeyMap, 'FSM', 'AccountCompany')
                if(fsmFromValueMap){
	    				appendAccountCompany(fsmFromValueMap);
	    		}
                
                
                /****Handle Specific Field mapping scenaiors -- START ****/
                def PSspecfieldsize = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', 'PSSPECSIZE', 'FSM', 'AccountCompany')
                if (PSspecfieldsize){
				    def fieldmap = [:]
                    (1..PSspecfieldsize).each { i ->
                        //get xpath value of each specific field
				    	def fieldnum = "PSFIELD"+i
				    	fieldmap[fieldnum] = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', fieldnum, 'FSM', 'AccountCompany')					
				    	if (fieldmap[fieldnum]){
				    		// Search specific XPath expression
				    		def searchxpath = '/MaterialStock' + fieldmap[fieldnum].replaceAll("/","/n1:")
				    		
				    		// Define a function to find nodes based on XPath
				    		def findNodes = { node, path ->
				    			def parts = path.tokenize('/')
				    			parts.inject([node]) { list, part ->
				    				list.findAll { it.name() == part }.collect { it.children() }.flatten()
				    			}
				    		}
				    		
				    		// Find nodes based on XPath
				    		def nodes = findNodes(stockMessage, searchxpath)
    
				    		// get the Value Mappings based on the specific fields and append the FSM companies
				    		nodes.each { node ->
	    		    	        def psspecKeyMap = "PS|||${fieldnum}|${node}"
                                def specfsmFromValueMap = valueMappingApi.getMappedValue('S4HANA', 'AccessSequence', psspecKeyMap, 'FSM', 'AccountCompany')
                                if(specfsmFromValueMap){
	    		    		        appendAccountCompany(specfsmFromValueMap);
	    		    	        }
				    		}
				    	}				
				    }
                }
                /****Handle Specific Field mapping scenaiors -- END ****/
                
	    		if (!mcXML.FSMCompany)
	    		{
	    			def fsmXml = new XmlParser().parseText("<FSMCompany>NA|NA</FSMCompany>")
	    			mcXML.append(fsmXml)
	    		}
                stockMessage.append(mcXML)
            
        }
    }

    def FSMCompanyData = XmlUtil.serialize(query)
    message.setBody(FSMCompanyData)
    return message
}
