import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.util.XmlParser
import groovy.util.XmlSlurper

def Message processData(Message message) {
    /* This script gets Warehouse details for custom company determination */
    
    def body = message.getBody(String)
    def parsedXml = new XmlSlurper().parseText(body)    
    def customObjects = new XmlParser().parseText("<CustomObjects></CustomObjects>")
    def properties  = message.getProperties();    
    def Warehouse_Delimiter = properties.get("Warehouse_Delimiter");

    parsedXml.MaterialStockReplicateMsg.each { whRequest ->
        //get the Warehouse details where Custom rule type is set at the object level
        if (whRequest.@MultiCompanyGroup.text() in ['CUSTOM']) {            
            whRequest.MaterialStock.each { wh ->
                def customObjectXml = buildCustomObjectXml(wh, wh.FSMMultiCompany.FSMCompany.text(), whRequest.@MultiCompanyGroup.text(), Warehouse_Delimiter)
                def customObjectNode = new XmlParser().parseText(customObjectXml)
                customObjects.append(customObjectNode)
            }
        }
    }

    message.setBody(XmlUtil.serialize(customObjects))
    return message
}

def String buildCustomObjectXml(wh, type, ruleType, delimiter) {
    def builder = new StringBuilder()    
    def warehouseid = wh.Plant.text() + delimiter + wh.StorageLocation.text()    
    builder.append("<customObject>")
    builder.append("<SrvcMgmtFSMRplctnObjID>").append(warehouseid).append("</SrvcMgmtFSMRplctnObjID>")
    builder.append("<SrvcMgmtFSMReplicationObject>PS</SrvcMgmtFSMReplicationObject>")
    builder.append("<SrvcMgmtFSMRplctnObjAttribute></SrvcMgmtFSMRplctnObjAttribute><SrvcMgmtFSMRplctnObjAttribVal></SrvcMgmtFSMRplctnObjAttribVal>")
    
    builder.append("</customObject>")
    return builder.toString()
}
