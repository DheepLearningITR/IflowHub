import com.sap.it.api.mapping.*;

//This method forms the Contact Origin Data URI
def String customFunc(String arg1, String arg2){
	return arg1+" "+arg2;
}