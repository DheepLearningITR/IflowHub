import com.sap.it.api.mapping.*;

//This method forms the AdditionalID's Data URI
def String customFunc(String arg1, String arg2, String arg3, String arg4){
	return "AdditionalIDs(ContactID='"+arg1+"',ContactOrigin='"+arg2+"',ContactAdditionalOrigin='"+arg3+"',ContactAdditionalID='"+arg4+"')";
}