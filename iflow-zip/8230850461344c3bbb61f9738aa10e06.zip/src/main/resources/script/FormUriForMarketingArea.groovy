import com.sap.it.api.mapping.*;

//This method forms the MarketingAreas Data URI
def String customFunc(String arg1, String arg2, String arg3){
	return "MarketingAreas(ContactID='"+arg1+"',ContactOrigin='"+arg2+"',InteractionContactMktgArea='"+arg3+"')"; 
}