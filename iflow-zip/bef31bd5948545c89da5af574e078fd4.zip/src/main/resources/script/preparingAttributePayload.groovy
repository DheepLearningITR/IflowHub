import com.sap.gateway.ip.core.customdev.util.Message;
import org.json.JSONObject;
import org.json.XML;
import java.net.URLEncoder;
import groovy.json.*

def List addJsonObjToArr(Object object) {
  def arr = []
  for (obj in object) {
    arr.add(obj)
  }
  return arr
}

def ArrayList getItems(Object items) {
  def itemsArr = []
  for (item in items) {
    def builder = new JsonBuilder()
    def obj = builder {
      code item.opt("code").toString()
      descriptions addJsonObjToArr(item.opt("descriptions"))
    }
    if (obj.descriptions == "[]") {
      obj.remove("descriptions")
    }
    itemsArr.add(obj)
  }
  return itemsArr
}

def Object getCodeListPayload(Object codeList) {
  if (codeList.has("descriptions")) {
    codeList = codeList.put("descriptions", addJsonObjToArr(codeList.opt("descriptions")))
  }
  if (codeList.has("items")) {
    codeList = codeList.put("items", getItems(codeList.opt("items")))
  }
  if (codeList.has('industryStandards')) {
    codeList = codeList.put("industryStandards", addJsonObjToArr(codeList.opt("industryStandards")))
  }
  return codeList.toString(4)
}

def Message processData(Message message) {
  def requestBody = message.getBody(String.class);

  JSONObject attributeJSONObject = XML.toJSONObject(requestBody).root.attribute;
  JsonBuilder builder = new JsonBuilder();

  if (attributeJSONObject.opt("descriptions")) {
    attributeJSONObject.put("descriptions", addJsonObjToArr(attributeJSONObject.descriptions))
  }
  
  if (attributeJSONObject.opt("precision") == "null") {
    attributeJSONObject.put("precision", null)
  }

  if (attributeJSONObject.opt("scale") == "null") {
    attributeJSONObject.put("scale", null)
  }
  
  if (attributeJSONObject.opt("dimension1") == "") {
    attributeJSONObject.put("dimension1", null)
  }
  
  if (attributeJSONObject.opt('codeList')) {
    message.setProperty("codeListIDExists", false)
    def codeList = attributeJSONObject.codeList
    message.setProperty("codeListExternalID", attributeJSONObject.codeList.internalId)
    message.setProperty("createCodeListPayload", getCodeListPayload(attributeJSONObject.codeList));
    attributeJSONObject.remove("codeList")
  } 
  
  message.setProperty("attributeExternalID", attributeJSONObject.internalId);
  message.setProperty("createAttributePayload", attributeJSONObject.toString(4));

  return message
}