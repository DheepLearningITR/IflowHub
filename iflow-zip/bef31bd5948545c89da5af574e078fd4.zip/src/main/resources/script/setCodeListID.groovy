import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {

  def body = message.getBody(String.class);
  def codeListResponse = new JsonSlurper().parseText(body);
  message.setProperty("codeListID", codeListResponse.id);
  def attribute = new JsonSlurper().parseText(message.getProperty("createAttributePayload"))
  attribute.put("codeListID", codeListResponse.id)
  message.setProperty("createAttributePayload", new JsonBuilder(attribute).toPrettyString())

  return message;
}