import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {
  def body = message.getBody(String.class);

  message.setProperty("isCodeListPresent", false);
  def codeListResponse = new JsonSlurper().parseText(body);
  message.setProperty("codeListResponse", codeListResponse)
  codeListResponse.each {
    message.setProperty("codeListID", it.id);
    def attribute = new JsonSlurper().parseText(message.getProperty("createAttributePayload"))
    attribute.put("codeListID", it.id)
    message.setProperty("createAttributePayload", new JsonBuilder(attribute).toPrettyString());
    message.setProperty("isCodeListPresent", true);
  }
  return message;
}