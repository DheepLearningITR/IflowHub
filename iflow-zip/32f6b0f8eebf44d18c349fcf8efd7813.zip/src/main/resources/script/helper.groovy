import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import groovy.json.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

def Message reduceCNSRegionCodes(Message message) {

  def body = message.getBody(java.io.Reader)
  def input = new JsonSlurper().parse(body)

  def reducedRegionCodeList = input.value.collect {
    item -> [
      ["code": "${item.regionCode}\$XDP\$${item.countryCode}"]
    ]
  }

  def outputJson = ["value": reducedRegionCodeList.flatten()]

  def output = JsonOutput.toJson(outputJson);

  message.setProperty("ReceiverCodes", outputJson)
  message.setBody(output)
  return message
}

def Message prepareReceiverPayload(Message message) {

  def body = message.getBody(java.io.Reader)
  def soapResponse = new XmlSlurper().parse(body)

  def responsePayload = convertToJSON(soapResponse, message)
  
  
  def messageRequests = responsePayload.messageRequests
  def chunkSize = 100
  def chunks = messageRequests.collate(chunkSize)

  // Wrap chunks inside a new JSON array
  def outputJsonArray = []
  chunks.each {
    chunk ->

      def chunkJson = [
        messageHeader: responsePayload.messageHeader,
        messageRequests: chunk
      ]

    outputJsonArray << chunkJson
  }

  // Convert to JSON
  def bundledJson = [bundledJson: outputJsonArray]
  def outputJson = JsonOutput.toJson(bundledJson)

  message.setBody(outputJson)

  return message

}


def Message removeRootNodeAndEnrichMessageHeader(Message message) {

  def body = message.getBody(java.io.Reader)
  def responsePayload = new JsonSlurper().parse(body).bundledJson

  responsePayload.messageHeader.id = UUID.randomUUID().toString()
  responsePayload.messageHeader.creationDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))

  def enrichedResponsePayload = JsonOutput.toJson(responsePayload)

  message.setBody(enrichedResponsePayload)
  return message
}

def convertToJSON(xml, message) {

  def properties = message.getProperties()
  def senderBusinessSystem = properties?.get("SenderBusinessSystem")
  def receiverBusinessSystem = properties?.get("ReceiverBusinessSystem")
  def messageEntityName = properties?.get("MessageEntityName")
  def initialLoad = properties?.get("InitialLoad")

  def jsonBuilder = new JsonBuilder()

  def codeList = []
  xml.ET_CODE_LIST.item.each {
    item ->
      def code = item.CODE.text()
    def descriptions = item.TEXTS.item.collect {
      [
        languageCode: it.LANGUAGE.text(),
        content: it.TEXT.text()
      ]
    }

    def resultMessage = [
      messageHeader: ["messageEntityName": messageEntityName, "actionCode": "CREATE", "id": generateRandomGUID()],
      body: [code: code, "isActive": true, descriptions: descriptions]
    ]

    codeList.add(resultMessage)
  }
  if ('true' == initialLoad) {
    def receiverCodeList = properties.get("ReceiverCodes")
    def erpCodes = xml.ET_CODE_LIST.item.collect {
      it.CODE.text()
    }

    message.setProperty("erpCodes", erpCodes)

    def cnsCodes = receiverCodeList.value.collect {
      it.code
    }

    message.setProperty("cnsCodes", cnsCodes)
    def codesToDelete = cnsCodes - erpCodes

    message.setProperty("codesToDelete", codesToDelete)

      
    codesToDelete.each {
      code ->
        def deleteMessage = [
          messageHeader: ["messageEntityName": messageEntityName, "actionCode": "CREATE", "id": generateRandomGUID()],
          body: [code: code,"isActive": false, descriptions: [ languageCode: "EN", content: "Obsolete" ]]
        ]

      codeList.add(deleteMessage)
    }
  }

  jsonBuilder {
    messageHeader(receiverCommunicationSystemDisplayId: receiverBusinessSystem, senderCommunicationSystemDisplayId: senderBusinessSystem)
    messageRequests(codeList)
  }

  return jsonBuilder.content
}

def generateRandomGUID() {
  return UUID.randomUUID().toString()
}