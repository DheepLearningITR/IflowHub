import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def map = message.getProperties();
    def itemID = map.get("ItemID");
    throw new Exception("No service confirmation found for activity: " + itemID + " in CRM");
}
