import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.ArrayList;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def map = message.getProperties();
    def query = new XmlSlurper().parseText(body);
    def delay = map.get("DelayInMilliSec");
    long timeDelay = Long.parseLong(delay);
    List<String> list = new ArrayList<String>();
    HashMap<String, String> hmap = new HashMap<String, String>();
    
    message.setProperty("ProcessingTypeCode",query.fsm_body.data.type.text());
    boolean flag=false;
    def act= query.fsm_body.data.activities.find{it.eventType.text()=="activity.completed"};
    
    act.attachments.each{
        if(it.category.text()=="ServiceCheckout")
        { 
            flag=true;
            list.add(it.id.text());
        }
    }
    
    def exp = query.fsm_body.data.activities.expenses;
    exp.attachments.each{
        if(it.id.size() > 0) {
            list.add(it.id.text());
        }
    }
    
    if(flag==false)
        message.setProperty("attachment_id","none");
    
    sleep(timeDelay);
    
    message.setProperty("Attachment_List", list);
    message.setProperty("Attachment_Size", list.size());
    message.setProperty("Content_Map", hmap);
    return message;
}
