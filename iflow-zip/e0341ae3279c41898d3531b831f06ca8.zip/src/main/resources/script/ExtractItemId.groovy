import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def query = new XmlSlurper().parseText(body);
    
    def act= query.fsm_body.data.activities.find{it.eventType.text()=="activity.completed"};
    message.setProperty("ItemID", act.externalId.text());
    
    return message;
}
