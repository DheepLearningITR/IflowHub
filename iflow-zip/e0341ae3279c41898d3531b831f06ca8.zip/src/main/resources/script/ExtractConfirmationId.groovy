import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
  def body = message.getBody(java.lang.String);
  def query = new XmlSlurper().parseText(body);
  def document = '';
  map = message.getProperties();
  
  def typeCode = map.get("Object_Type_Code_Service_Confirmation");
  
  def itemID = map.get("ItemID");
  String[] str;
  
  message.setProperty("DocumentID", document);
  str = itemID.split('/');
  itemID = str[1];
  
  node = query.ServiceOrder.Item.find {
    it.ID.toInteger() == itemID.toInteger()
  }
  
  if(typeCode) {
    def result = node.BusinessTransactionDocumentReference.find { docu -> docu.TypeCode == typeCode } ///check if this works
    typeCodeDocumentId = result?.ID.text();
  }
  
  if(!typeCodeDocumentId){
      typeCodeDocumentId = node.BusinessTransactionDocumentReference[0]?.ID.text()
  }
  
  message.setProperty("DocumentID", typeCodeDocumentId);

  return message;
}