import com.sap.it.api.mapping.*;
import java.util.HashMap;

def String getAttachmentContent(String id, MappingContext context){
    Map<String,String> hmap = context.getProperty("Content_Map");
	String value = hmap.get(id);
	
	return value;
}
