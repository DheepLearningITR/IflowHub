import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.StringBuffer;

def Message processData(Message message) {
    //Body
    def messageLog = messageLogFactory.getMessageLog(message);
    
    def log_property = message.getProperty("log_property") as String;
    def log_header = message.getProperty("log_header") as String;
    def log_body = message.getProperty("log_body") as String;
    String content = "";
    
    if(messageLog != null) {
        messageLog.setStringProperty("Logging#1", "Payload");
        
        if (log_property != null && log_property.equalsIgnoreCase("yes")) {
            def propertyMap = message.getProperties();
            StringBuffer buffer = new StringBuffer();
            for (Map.Entry<String, String> entry : propertyMap.entrySet()) {
                buffer.append("<").append(entry.getKey()).append(">");
                buffer.append(entry.getValue());
                buffer.append("</").append(entry.getKey()).append(">\n");
            }
            content = content + "\n" + buffer.toString();
        }
        
        if (log_header != null && log_header.equalsIgnoreCase("yes")) {
            def header = message.getHeaders() as String;
            content = content + "\n" + header;
        }
        
        if (log_body == null || log_body.equalsIgnoreCase("yes")) {
            def body = message.getBody(java.lang.String) as String;
            content = content + "\n" + body;
        }
        
        if (content.length() > 0) {
            messageLog.addAttachmentAsString("MessageLog", content, "text/plain");    
        }
    }

    return message;
}