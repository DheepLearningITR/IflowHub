import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field;

@Field static final String HEADER_SRV_CHAIN_XSLT_ID_LIST = "ServiceChainXsltIdList";
@Field static final String HEADER_SRV_CHAIN_XSLT_ID = "ServiceChainXsltId";
@Field static final String HEADER_SRV_CHAIN_STEP_INDEX = "ServiceChainStepIndex";
@Field static final String PROPERTY_SRV_CHAIN_CONTINUE = "ServiceChainContinue";
@Field static final String CONST_TRUE = "true";
@Field static final String CONST_FALSE = "false";

Message setXsltId(Message message) {
	
	ArrayList<String> xsltIdList = message.getHeaders().get(HEADER_SRV_CHAIN_XSLT_ID_LIST);
	int index = message.getHeaders().get(HEADER_SRV_CHAIN_STEP_INDEX) ?: 0;
	String xsltId = xsltIdList.get(index);
	message.setHeader(HEADER_SRV_CHAIN_XSLT_ID, xsltId);
	
	message.setHeader(HEADER_SRV_CHAIN_STEP_INDEX, ++index);
	if (index < xsltIdList.size){
		message.setHeader(PROPERTY_SRV_CHAIN_CONTINUE, CONST_TRUE);
	} else {
		message.setHeader(PROPERTY_SRV_CHAIN_CONTINUE, CONST_FALSE);
	} 
	return message; 
}

