import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

	def erpDestination = message.getHeaders().get("ErpDestination");
	def ewmDestination = message.getHeaders().get("EwmDestination");
	
	if (erpDestination) {
		message.setHeader("RemoteSystemDestination", erpDestination );
	}
	
	if (ewmDestination) {
		message.setHeader("RemoteSystemDestination", ewmDestination );
	}
	return message;
}