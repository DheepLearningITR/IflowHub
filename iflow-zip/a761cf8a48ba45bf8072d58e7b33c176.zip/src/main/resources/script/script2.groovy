import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import java.util.Date
import java.text.SimpleDateFormat

def Message processData(Message message) {

    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    def catenaXid = message.getHeaders().get('catenaXId')
    def childIds  
    try {
        childIds = getChildIds(input,catenaXid);
    } catch (Exception e) {
        	message.setHeader('Content-Type', 'application/json' + '; charset=utf-8' )
	        message.setBody(' item (' + catenaXid + ') does not exist  ')
	        return message
    }
	def resultMap = [:]
    def childPartsArray = []
    input.ctxObjects.each {
        if (childIds.contains(it.ctxId)) {
            def childMap = null
            if (it.ProductBatch) {
                childMap = it.ProductBatch
            } else if (it.ProductSerialNumber) {
                childMap = it.ProductSerialNumber
            } else if (it.ReceivedProductBatch) {
                childMap = it.ReceivedProductBatch
            } else if (it.ProductSerialNumber) {
                childMap = it.ProductSerialNumber
            }
            if (childMap != null) {
                def childPartsMap = [:]
                def quantityMap = [:] 
                //childPartsMap.lifecycleContext = 'AsBuilt'
                def lexicalValue
                def quantityNumber
                if (childMap.quantities[0].qualifier.equals('DISCRETE')) {
                    quantityNumber = childMap.quantities[0].value
                    if (childMap.quantities[0].unit.equals('PCE') || childMap.quantities[0].unit.equals('PC')) {
                        lexicalValue = 'piece'
                    }
                }
                else if (childMap.quantities[0].qualifier.equals('BASE_UNIT')) {
                    quantityNumber = childMap.quantities[0].value
                    if (childMap.quantities[0].unit.equals('KGM')) {
                        lexicalValue = 'kilogram'
                    } else if (childMap.quantities[0].unit.equals('MTR')) {
                        lexicalValue = 'meter'
                    } else if (childMap.quantities[0].unit.equals('LTR')) {
                        lexicalValue = 'litre'
                    } else if (childMap.quantities[0].unit.equals('ST')) {
                        lexicalValue = 'piece'
                    }
                }
                quantityMap.quantityNumber = quantityNumber
                quantityMap.measurementUnit = lexicalValue
                childPartsMap.catenaXId = 'urn:uuid:' + it.ctxId
                childPartsMap.quantity = quantityMap
                childPartsMap.hasAlternatives = false
                def formatedCreatedOn = getFormatedDate(childMap.creationDate)
                childPartsMap.createdOn = formatedCreatedOn
                childPartsMap.businessPartner = childMap.ctxBPId
                childPartsMap.lastModifiedOn = formatedCreatedOn
                childPartsArray << childPartsMap
            }
        }
    }

    if(childPartsArray && childPartsArray.size() > 0){
        resultMap.catenaXId = 'urn:uuid:'+catenaXid
        resultMap.childItems = childPartsArray
    	def mtJson = new JsonBuilder(resultMap)
    	message.setHeader('Content-Type', 'application/json' + '; charset=utf-8' )
    	message.setBody(mtJson.toPrettyString())
    } else {
        message.setBody(' item (' + catenaXid + ') does not exist  ')
    }
	return message
}

def getChildIds (def input, def catenaXid) {
    def childIdList = []
    input.ctxProductEdges.each { 
        if (it.toCtxId == catenaXid && it.fromCtxId ) {
            childIdList << it.fromCtxId
        }
    }
    return childIdList
}

def getFormatedDate(def inDate) {
    if(inDate == null ) return ''
    Date date1 = new SimpleDateFormat("yyyyMMdd").parse(inDate)
    def delta = Math.abs(new Random().nextInt() % 9000000) +1000000
    date1 = new Date(date1.getTime() + delta)
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    return sdf.format(date1.getTime())
}
