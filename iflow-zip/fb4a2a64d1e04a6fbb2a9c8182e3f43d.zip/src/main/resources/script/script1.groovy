import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
  //Body 
  def body = message.getBody(java.io.Reader)
  Map parsedJson = new JsonSlurper().parse(body)

  parsedJson.messageRequests.each {

    //body/currentFunctions/isSalesOrganization
      if (it.body.exchangeRate) {
        it.body.exchangeRate = Double.parseDouble(it.body.exchangeRate)
      }

  }
  def respbody = JsonOutput.toJson(parsedJson)
  message.setBody(respbody)
  return message;
}