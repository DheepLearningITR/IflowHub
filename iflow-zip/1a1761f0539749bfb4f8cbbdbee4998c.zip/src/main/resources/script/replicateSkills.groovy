import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;

def Message parseHeaders(Message message) {

	def map = message.getHeaders();

	def sfsfAttributeType = map.get("sfsfAttributeType");
	message.setProperty("sfsfAttributeType", sfsfAttributeType);
	
    def getTexts = map.get("getTexts");
	message.setProperty("getTexts", getTexts);
	
    def getTags = map.get("getTags");
	message.setProperty("getTags", getTags);	
	
    //used to default hashmap global variables
	def emptyHmap = new HashMap<String, String>();
	emptyHmap.put('null','');
	message.setProperty("emptyHmap", emptyHmap);
	
	return message;
}

def Message filter_Attributes(Message message) {
	
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
	def sfsfAttributeType = map.get("sfsfAttributeType");
	//HashMap<String, String> hmapAttrib = map.get("hmap_sfsfAttributes"); 
	HashMap<String, String> hmapAttrib = new HashMap<String, String>();	
    //HashMap<String, String> hmapTexts = map.get("hmap_sfsfAttributeTexts"); 
    HashMap<String, String> hmapTypes = new HashMap<String, String>(); //JIRA INT-326

    def sfsfAttributeFound = 'false';
	def Root = new XmlSlurper().parse(body);
    	Root.AttributeEntity.each{
    	    hmapTypes.put(it.externalId.toString(),it.type.toString());  //JIRA INT-326 TYPE to be merged in hmapTexts
    	    //if(hmapAttrib.containsKey(it.externalId.toString())){

    	    //attribute is cobrainer if prefixed with cbr_
    	    if(it.externalId.toString().startsWith('cbr_')){  
    	        //found in Cobrainer library
    	        if(sfsfAttributeType==null){
    	            //include all attributes (prefix with attribute type). Lookup for JobProfile replication
        	        hmapAttrib.put(it.type.toString()+'|'+it.externalId.toString(),it.wsmId.toString());
        	        hmapAttrib.remove(it.externalId.toString()); //remove in hmap
        	        sfsfAttributeFound = 'true';
    	        }else{
        	        if(it.type.toString() != sfsfAttributeType){
        	            it.replaceNode{};                          //remove in payload, not same type
        	            hmapAttrib.remove(it.externalId.toString()); //remove in hmap, not same type
        	        }else{
        	            //same type, fill WSMID mapping
        	            hmapAttrib.put(it.externalId.toString(),it.wsmId.toString());
        	            sfsfAttributeFound = 'true';
        	        }
    	        }
    	    }else{
    	        it.replaceNode{}; //remove, not found in cobrainer library
    	    }
    	}
    message.setBody(XmlUtil.serialize(Root));
    message.setProperty("sfsfAttributeFound", sfsfAttributeFound); //update flag
	message.setProperty("hmap_sfsfAttributes", hmapAttrib);            //update hmap
	message.setProperty("hmap_sfsfAttributeTypes", hmapTypes);       //JIRA INT-326 store hmap
	return message;
}

def Message build_hmapAttributeTexts(Message message) {
	
	def map = message.getProperties();
	def body = message.getBody(java.io.Reader);
	HashMap<String, String> hmapTexts = new HashMap<String, String>();
	HashMap<String, String> hmapTypes = map.get("hmap_sfsfAttributeTypes");  //JIRA INT-326
	if( hmapTypes == null ){
	    hmapTypes = new HashMap<String, String>();	
	}	

	def Root = new XmlSlurper().parse(body);
    Root.data.each{
        def attrType = hmapTypes.get(it.libraryExternalId.toString());
        String name = '';
	    
	    //JIRA INT-326 include attribute type if english as same name is allowed for different Types
	    //JIRA INT-363 same name translations now allowed for different types
	    name = attrType+'-'+it.language.toString()+'-'+it.name.toString().trim().toLowerCase();
        hmapTexts.put(name,it.libraryExternalId.toString()); 
    }
	message.setProperty("hmap_sfsfAttributeTexts", hmapTexts);
	return message;
}

def Message filter_AttributeTypes(Message message) {
	
    //JIRA INT-326 
	def sfsfAttributeType = message.getProperties().get("sfsfAttributeType");
    HashMap<String, String> hmapTypes = message.getProperties().get("hmap_sfsfAttributeTypes"); 
    if( hmapTypes == null ){
        hmapTypes = new HashMap<String, String>();	
	    hmapTypes.put('null',''); //empty hmap if not found (attributes file not found)
	}else{
        //remove same types in hmap. As this will be used later to find duplicate Attributes with different types
        hmapTypes = hmapTypes.findAll { key, value -> value != sfsfAttributeType };
        if(hmapTypes.size()==0){
            hmapTypes.put('null',''); //no attributes found with different type
        }
	}
    
	message.setProperty("hmap_sfsfAttributeTypes", hmapTypes);       
	return message;
}

def Message filter_AttributeTags(Message message) {
	
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
	HashMap<String, String> hmapAttrib = map.get("hmap_sfsfAttributes"); 
	Set<String> hsetTags = new HashSet<>();	

    //remove Attribute Tags which are not found in filtered attributes hmap (filtered by Tags AND attributeType)
    def Root = new XmlSlurper().parse(body);
    Root.data.findAll { !hmapAttrib.containsKey(it.libraryExternalId.toString()) }
        .each { it.replaceNode {} }
    
    // Collect IDs before modifying the XML
    def filteredData = Root.data.findAll { hmapAttrib.containsKey(it.libraryExternalId.toString()) }

    // Populate hsetTags directly with the retained nodes
    filteredData.each { hsetTags.add(it.libraryExternalId.toString()) }
    
    //find all Attributes that are not in the AttributeTags File, they need to be added so that missing tags can be added    
    hmapAttrib.each{cbrId, wsmId->
        if(!hsetTags.contains(cbrId.toString())){
            //add in Attribute in Tags payload so that they can be filled with missing Tags if required
            def newNode = new XmlSlurper().parseText("""
                <data>
                    <libraryExternalId>${cbrId}</libraryExternalId>
                    <tagExternalIds/>
                </data>
            """);
            Root.appendNode(newNode); // Append new node
        }
    }

    message.setBody(XmlUtil.serialize(Root));
    message.setProperty("hsetTags", hsetTags);
    message.setProperty("attributeTags_payload",null); //done processing
	return message;
}