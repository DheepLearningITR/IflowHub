import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    body=message.getProperty("csvPayload")
    def x="PR_Creation_List,PR_PO_Status,Created_By,Request_ID,PR_Number,Unique_Key,Request_Name,Contract_Reference,Anaplan_Line_Number,PR_Line_Number,Quantity,Price,Supplier_Code,SKU,Deliver_To_Code,Need_By_Date"
    body=body.replaceAll("\n","")
    if (body.trim() == "[]" || body.trim() == "[ ]" || body.trim()==x) {
        message.setBody("")
        message.setProperty("payload","")
    } else {
       
        message.setBody(body)
        message.setProperty("payload",body)
    }
    return message
}
