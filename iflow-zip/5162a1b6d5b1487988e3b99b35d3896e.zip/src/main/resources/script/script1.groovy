import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder
import groovy.util.XmlSlurper

Message processData(Message message) {
    def body = message.getBody(String)
    def parser = new XmlSlurper().parseText(body)

    def prMap = [:]

    parser.PR.each { pr ->
        def requestId = pr.Request_ID.text()
        if (!prMap.containsKey(requestId)) {
            prMap[requestId] = []
        }
        prMap[requestId] << pr
    }

    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    
    prMap.each { requestId, prList ->
        xml.Purchase_Requisition {
            prList.each { pr ->
                xml.PR {
                    pr.children().each { child ->
                        "${child.name()}"(child.text())
                    }
                }
            }
        }
    }
    
    def resultXml = writer.toString()
    message.setBody("<root>"+resultXml+"</root>")
    
    return message
}
