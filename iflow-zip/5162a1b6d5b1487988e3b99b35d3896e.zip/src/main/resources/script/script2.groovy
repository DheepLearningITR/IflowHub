
import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    //Body
    def input = message.getBody(String);

    input=input.replaceAll("</multimap:Message1>","");
    input=input.replaceAll("</multimap:Messages>","</root>");
    input=input.replaceAll('<multimap:Messages xmlns:multimap="http://sap.com/xi/XI/SplitAndMerge">',"<root>")
    input=input.replaceAll("<multimap:Message1>","")
    message.setBody(input)
    return message;
}