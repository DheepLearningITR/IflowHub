import com.sap.gateway.ip.core.customdev.util.Message;

def Message extractUrlGetParameters(Message message) {

       //get url 
       def map = message.getHeaders();
       def queryString = map.get("CamelHttpQuery");

       //split url
       String[] vQuery;
       vQuery = queryString.split('&');

       //set properties
       for( String pair : vQuery ) {
           String[] vPairs = pair.split('=')
           message.setProperty(vPairs[0].replace("\$",""), vPairs[1]);
       }
       
       return message;
    }