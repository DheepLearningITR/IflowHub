import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processResponses(Message message) {
  map = message.getProperties()

  def body = message.getBody(java.lang.String) as String
  if (body) {
    def errors = map.get("errorText") ?: ""
    def root = new XmlSlurper().parseText(body)
    root.batchChangeSetResponse.batchChangeSetPartResponse.each {
      b ->
      errors = errors ? errors + "," + b.body.text() : b.body.text()
    }
    message.setProperty("errorText", errors.toString())
  }

  def recordsInBatch = map.get("recordsInBatch").toInteger()
  def recordsProcessed = map.get("recordsProcessed").toInteger() + recordsInBatch
  message.setProperty("recordsProcessed", recordsProcessed.toString())

  return message;
}

def Message addErrorMessage(Message message) {
  messageLogFactory.getMessageLog(message)?.addAttachmentAsString('Error Message', message.getProperties().get('errorText'), 'text/plain')
  return message
}

// Catch the exception and set it as body
def Message logException(Message message) {
    // get a map of iflow properties
    def map = message.getProperties();
    
    // Get SAPJMSRetries of the artifact
    def headers = message.getHeaders()
    def retryNumber = headers.get("SAPJMSRetries");;
    
    // get an exception java class instance
    def ex = map.get("CamelExceptionCaught");
    if (ex!=null) {
        
        if (retryNumber == 0 || retryNumber == null) {

            def exceptionBody = ex.toString();
            
            // save the error response as a message attachment 
            def messageLog = messageLogFactory.getMessageLog(message);
            messageLog.addAttachmentAsString(ex.getClass().getCanonicalName(), exceptionBody, "text/plain");

            // copy the error response to the message body
            message.setBody(exceptionBody);
        }     
    }

    return message;
}

def Message processFilterScope(Message message) {
 
  map = message.getProperties()
 
  def filterValue = ""
  def workAssignmentIdsProp = map.get("workAssignmentId")
  def availabilityDatesProp = map.get("availabilityDate")
 
  workAssignmentIds = reformatLists(workAssignmentIdsProp)
  filterValue = "(workAssignmentId eq " + workAssignmentIds

  if (availabilityDatesProp) {
    availabilityDates = reformatLists(availabilityDatesProp)
    filterValue += " and availabilityDate eq " + availabilityDates + ")"
  }
  message.setProperty("filterValue", filterValue)
 
  return message
}

def Message processFilterDelta(Message message) {

  map = message.getProperties()

  def filterValue = "( lastModifiedDateTime ge '" + map.get("recentSuccessfulExecutionTimestamp") + "' )"

  def companyCodesProp = map.get("companyCodes")
  def jobCodesProp = map.get("jobCodes")
  def employeeClassesProp = map.get("employeeClasses")
  def employmentTypesProp = map.get("employmentTypes")

  if (companyCodesProp) {
    companyCodes = reformatLists(companyCodesProp)
    filterValue += " and ( jobDetailNav/companyCode in " + companyCodes + " )"
  }

  if (jobCodesProp) {
    jobCodes = reformatLists(jobCodesProp)
    filterValue += " and ( jobDetailNav/jobCode in " + jobCodes + " )"
  }

  if (employeeClassesProp) {
    employeeClasses = reformatLists(employeeClassesProp)
    filterValue += " and ( jobDetailNav/employeeClass in " + employeeClasses + " )"
  }

  if (employmentTypesProp) {
    employmentTypes = reformatLists(employmentTypesProp)
    filterValue += " and ( jobDetailNav/employmentType in " + employmentTypes + " )"
  }

  message.setProperty("filterValue", filterValue)
  return message
}

def String reformatLists(String list) {
  result = ""
  list.split(",").each {
    i ->
      if (i.trim())
        result = result ? result + ",'" + i.trim() + "'" : "'" + i.trim() + "'"
  }
  return result
}