import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
                
// get a map of iflow properties
    def map = message.getProperties();
                
// get an exception java class instance
    def ex = map.get("CamelExceptionCaught");
    if (ex!=null) {
	
	     //Evaluating the expression value 
      switch(ex.getClass().getCanonicalName()) {            
         // Each case statement section has a break condition to exit the loop 		
// HTTP Adapter errors		 
         case "org.apache.camel.component.ahc.AhcOperationFailedException": 
            // save the http error response as a message attachment 
            def messageLog = messageLogFactory.getMessageLog(message);
            messageLog.addAttachmentAsString("http.ResponseBody", ex.getResponseBody(), "text/plain");

            // copy the http error response to an iflow's property
            message.setProperty("http.ResponseBody",ex.getResponseBody());

            // copy the http error response to the message body
            message.setBody(ex.getResponseBody());

            // copy the value of http error code (i.e. 500) to a property
            message.setProperty("http.StatusCode",ex.getStatusCode());

            // copy the value of http error text (i.e. "Internal Server Error") to a property
            message.setProperty("http.StatusText",ex.getStatusText());
            // trial 
            message.setBody(ex.getMessage());
                map.put("http.StatusCode",500);                                                
             
            break; 
// ODATA Errors			
         case "com.sap.gateway.core.ip.component.odata.exception.OsciException": 
			// save the http error request uri as a message attachment 
            def messageLog = messageLogFactory.getMessageLog(message);
            messageLog.addAttachmentAsString("http.requestUri", ex.getRequestUri(), "text/plain");
            // copy the http error request uri to an exchange property
            message.setProperty("http.requestUri",ex.getRequestUri());
            // copy the http error response body as an attachment 
            messageLog.addAttachmentAsString("http.response", message.getBody(), "text/plain");
            // copy the http error response body as a propert 
            message.setProperty("http.response", message.getBody());            
            // copy the http error response body as an attachment 
            messageLog.addAttachmentAsString("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString(), "text/plain");            
             // copy the http error response body as a property 
            message.setProperty("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
            message.setHeader("http.reason", message.getBody());
            break; 
// Script Errors			
		 case "org.apache.camel.javax.script.ScriptException":
		    map.put("http.StatusCode",501);
            message.setBody(ex.getMessage());
            message.setHeader("http.reason", message.getBody());    
            break;
        case "com.sap.it.rt.adapter.http.api.exception.HttpResponseException":
		    map.put("http.StatusCode",495);
            message.setBody(ex.getMessage());
            message.setHeader("http.reason", message.getBody());
            break;
        case "com.sap.xi.mapping.camel.XiMappingException":
		    map.put("http.StatusCode",200);
		    def NoRecordsFound = 'No records found';
            message.setBody(NoRecordsFound);
            message.setHeader("http.reason", NoRecordsFound);            
            break;
// Any other error			
         default: 
			// save the http error request uri as a message attachment 
            def messageLog = messageLogFactory.getMessageLog(message);
            messageLog.addAttachmentAsString("http.requestUri", ex.getRequestUri(), "text/plain");
            // copy the http error request uri to an exchange property
            message.setProperty("http.requestUri",ex.getRequestUri());
            // copy the http error response body as an attachment 
            messageLog.addAttachmentAsString("http.response", message.getBody(), "text/plain");
            // copy the http error response body as a property 
            message.setProperty("http.response", message.getBody());            
            // copy the http error response body as an attachment 
            messageLog.addAttachmentAsString("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString(), "text/plain");            
             // copy the http error response body as a property 
            message.setProperty("http.statusCode", message.getHeaders().get("CamelHttpResponseCode").toString());
            message.setHeader("http.reason", message.getBody());
            break; 
      }
                                 
        }

                return message;
}