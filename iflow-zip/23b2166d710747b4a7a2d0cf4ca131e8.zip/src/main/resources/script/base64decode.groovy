import groovy.json.*
import java.nio.charset.StandardCharsets;
import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String deCodeField(String arg1){
    
//  String decodeCname = new String(arg1.decodeBase64(), StandardCharsets.UTF_8);
    String decodeCname = new String(arg1.substring(6).decodeHex(), StandardCharsets.UTF_8);

    arg1 = decodeCname;
	return arg1 
	
}

