import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
import java.nio.charset.StandardCharsets;
import com.sap.it.api.mapping.*;


def Message PreparePDData(Message message) {
    def ebody = message.getBody(String);
// unescape the JSON body    
    def body=StringEscapeUtils.unescapeJava(ebody)
    map = message.getProperties();
    
// Define JSON extracter
    def jsonSlurper = new JsonSlurper()
    def rpn = jsonSlurper.parseText(body as String);

// Store required values into properties    
       message.setProperty("EmployerRegistrationNumber", rpn.employerRegistrationNumber);
       message.setProperty("CertificateName", rpn.certificateName);

// ERN
    def empRegNumber = map.get("EmployerRegistrationNumber");
    def encodedERN = 'HIEERN' + empRegNumber.getBytes("UTF-8").encodeHex().toString()    
    message.setProperty("encodedERN", encodedERN );

// CName
    def ernCName = map.get("CertificateName");
    def encodedCname = 'HIEERN' + ernCName.getBytes("UTF-8").encodeHex().toString()
    message.setProperty("encodedCname", encodedCname );     
       if (empRegNumber == null){
          throw new IllegalStateException("Employee Registration number could not be read from body'")      
       }
       if (ernCName == null){
          throw new IllegalStateException("Certificate alias  could not be read from body'")      
       }
   return message;
}  

def Message getDeleteData(Message message) {
    def ebody = message.getBody(String);
// unescape the JSON body    
    def body=StringEscapeUtils.unescapeJava(ebody)
    map = message.getProperties();
    
// Define JSON extracter
    def jsonSlurper = new JsonSlurper()
    def rpn = jsonSlurper.parseText(body as String);
// Store required values into properties    
       message.setProperty("EmployerRegistrationNumber", rpn.employerRegistrationNumber);
       message.setProperty("CertificateName", rpn.certificateName);
    def map = message.getProperties();
    def empRegNumber = map.get("EmployerRegistrationNumber");
    def ernCName = map.get("CertificateName");
    def encodedERN = empRegNumber.getBytes("UTF-8").encodeHex().toString()        
    message.setProperty("encodedERN", encodedERN );
    def encodedCname = ernCName.getBytes("UTF-8").encodeHex().toString()
    message.setProperty("encodedCname", encodedCname );     
       if (empRegNumber == null){
          throw new IllegalStateException("Employee Registration number could not be read from body'")      
       }
       if (ernCName == null){
          throw new IllegalStateException("Certificate alias  could not be read from body'")      
       }
   return message;
}  

//  Encode ERN and Cnames
def String enCodeParameter(Byte arg1){
  String encodeParam = new String(arg1.endcodeHex(), StandardCharsets.UTF_8);
    arg1 = encodeParam;
	return arg1 
	
}    

// Decode ERN and Cnames
def String deCodeParameter(Byte arg1){
    
  String decodeParam = new String(arg1.encodeHex(), StandardCharsets.UTF_8);

    arg1 = decodeParam;
	return arg1 
	
}    
    
