/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import java.util.HashMap;
import groovy.util.Node;
import groovy.xml.*


    def Message processData(Message message) {
        //println "You can print and see the result in the console!"
        //Body 
        def success_message='''<status>200</status>'''
        def failed_message='''<status>409</status>'''
        def body = message.getBody(String);
        def map = message.getProperties();
        def parsedXML = new XmlSlurper().parseText(body);
        def attachments_created = parsedXML.'**'.findAll { it.name() == 'status' }.size()
        
        message.setProperty("pattachments_created", attachments_created);
        attachments_counter=map.get("pattachments_counter").toString();

        if(attachments_counter.equals(attachments_created.toString())){
            message.setBody(success_message)

        }else{
            message.setBody(failed_message)
        }
        return message
    }