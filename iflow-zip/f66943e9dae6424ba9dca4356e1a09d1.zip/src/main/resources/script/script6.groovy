import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import java.util.HashMap;
import groovy.util.Node;
import groovy.xml.*

def Message processData(Message message) { 
    
    //Body 
    def body = message.getBody(String);
    def parsedXML = new XmlSlurper().parseText(body);
    def counter = parsedXML.'**'.findAll { it.name() == 'ServiceRequestAttachmentFolder' }.size()
    def attachment_counter=counter-1;
    
    message.setProperty("pattachments_counter", attachment_counter);

    return message;
}