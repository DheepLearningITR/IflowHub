import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body
       def idFromRefDoc=message.getProperty("C4CID") as String;
	   def idFromBTDref=message.getProperty("C4CserviceRequestID") as String;
       if(idFromRefDoc==""){
           message.setProperty("C4CID",idFromBTDref);
       }
    def messageLog = messageLogFactory.getMessageLog(message);
	if (messageLog != null) {
		messageLog.addAttachmentAsString("C4CID", idFromBTDref, "application/json");
	}
       return message;
}