
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
        def bodyString = message.getBody(java.lang.String) as String;
      
        def headers = message.getHeaders();
        
        def IDOC_Sender = headers.get("IDOC_Sender");
        def IDOC_Receiver = headers.get("IDOC_Receiver");
        def IDOC_MesType = headers.get("IDOC_MesType");
        def SAP_ApplicationID = headers.get("SAP_ApplicationID");
        
        def output = "No Receiver Found:" + "\n" + "IDOC_Sender: "+IDOC_Sender+"\n"+ "IDOC_Receiver: "+IDOC_Receiver+"\n"+ "IDOC_MesType: "+IDOC_MesType+"\n"+ "SAP_ApplicationID: "+SAP_ApplicationID;
        
        def log = messageLogFactory.getMessageLog(message);
    
        log.addAttachmentAsString("No Receiver Error", output, "text/xml");

        return message;
}