
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message) {
    //get Headers
    def headers = message.getHeaders();
    def MesType_value = headers.get("IDOC_MesType");
    def SourceAgencyValue = headers.get("IDOC_Sender");
    def TargetAgencyValue = headers.get("IDOC_Receiver");
    
    
    //find Receiver
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    def VM_value = valueMapApi.getMappedValue(SourceAgencyValue, 'REC_MESTYP', TargetAgencyValue + "_" + MesType_value, 'Receiver', 'ProcessDirect');
    
    
    if (VM_value != null) {
        //Set Property
        message.setProperty("ProcessDirect_URL", VM_value);
    } else {
        message.setProperty("ProcessDirect_URL", "NoReceiverConfigured");
    }
    
    return message;
}