import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    def map = message.getProperties();
    
    def ex = map.get("CamelExceptionCaught");
    def headers = message.getHeaders();
	def httpResponseCode = headers.get("CamelHttpResponseCode");
    
    if( httpResponseCode == 401 || httpResponseCode == 400 ){
        message.setBody(ex.getResponseBody());
        return message;
    }
    
    if ( ex != null ) {
        // To handle wrong tracking url
        
        if ( ex.getClass().getCanonicalName().equals("java.net.UnknownHostException") ) {
            message.setBody(ex.getMessage());
            message.setHeader("CamelHttpResponseCode", 404);
        }
        if ( ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException") ) {
            message.setBody(ex.getResponseBody());
        }
        // Checks if we are trying to access invalid properties
        if( ex.getClass().getCanonicalName().equals("javax.script.ScriptException") ){
            message.setBody("Invalid payload");
            message.setHeader("CamelHttpResponseCode", 400);
        }
    }
    return message;
}