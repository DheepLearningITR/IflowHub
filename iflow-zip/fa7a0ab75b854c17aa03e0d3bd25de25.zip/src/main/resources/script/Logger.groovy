import com.sap.gateway.ip.core.customdev.util.Message;	//Default
import org.slf4j.Logger;								//For LoggerFactory
import org.slf4j.LoggerFactory;							//For LoggerFactory
import groovy.transform.Field;							//For using the @Field notation

// John Humma
// Vertex Inc.
// Vertex Integration Flow Logging Script
// 08.09.2017 - Initial Version
// Updated 11/16/2018 for 1902 release changes. See  "//New for build 1902" tags for details
// Updated 02/14/2019 for 1905 release changes. See  "//New for build 1905" tags for details
// Updated 09/11/2019 for 1908 release changes. See  "//New for build 1908" tags for details


@Field String LOG_NAME               	= "VtxLog";
@Field String PROPERTY_LOGGING_LEVEL	= "SAP_MessageProcessingLogConfiguration";  //Used for getting logging level
@Field String TXJCD_SEND				= "TAX_JURISDICTION_SEND";
@Field String TXJCD_RECEIVE				= "TAX_JURISDICTION_RECEIVE";
@Field String CALC_REQ_ITEM				= "CALCULATION_ITEM";
@Field String GETCHANGED_SEND    	= "TAX_JUR_GETCHANGELIST_SEND";  //New for build 1902
@Field String GETCHANGED_RECEIVE	= "TAX_JUR_GETCHANGELIST_RECEIVE";  //New for build 1902
@Field String REDEFINE_SEND      	= "TAX_JUR_REDEFINE_SEND";  //New for build 1902
@Field String REDEFINE_RECEIVE   	= "TAX_JUR_REDEFINE_RECEIVE";  //New for build 1902
@Field String QUOTE						= "QuotationRequest";
@Field String CUST						= "Customer>";
@Field String VEND						= "Vendor>";
@Field String LINEITEM					= "<LineItem";
@Field String VERIFICATION				= "InvoiceVerification";  //New for build 1908
@Field String CALC_RES_ITEM 			= "CALCULATION_RESULT_ITEM";
@Field String FRC_SEND					= "TAX_FORCE_SEND";
@Field String FRC_RECV					= "TAX_FORCE_RECEIVE";
@Field String UPD_SEND					= "TAX_UPDATE_SEND";
@Field String LOG_DEBUG					= "logLevel=DEBUG";
@Field String LOG_TRACE					= "logLevel=TRACE";
@Field String logLvl;					//Logging level
@Field Logger log 						= LoggerFactory.getLogger("com.sap.hci.metviewer."+LOG_NAME);

/*Definitions*/
//VCT = Vertex Call Type
//VBD = Vertex Body
//RQ* = Request Value #
//RS* = Response Value #

// Script functions
def Message log_010(Message message) {
	processFunction("010", message);
	return message;
}
def Message log_020(Message message) {
	processFunction("020", message);
	return message;
}
def Message log_030(Message message) {
	processFunction("030", message);
	return message;
}
def Message log_040(Message message) {
	processFunction("040", message);
	return message;
}
def Message log_050(Message message) {
	processFunction("050", message);
	return message;
}
def Message log_060(Message message) {
	processFunction("060", message);
	return message;
}
def Message log_070(Message message) {
	processFunction("070", message);
	return message;
}
def Message log_080(Message message) {
	processFunction("080", message);
	return message;
}
def Message log_090(Message message) {
	processFunction("090", message);
	return message;
}

// Process script functions
def processFunction(String step, Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	messageLog.setStringProperty(LOG_NAME+'0', "Step "+step+", Init");

	checkLoggingLevel(message);

	if (logLvl != 'OTHER') {
		try {
			def body = message.getBody(java.lang.String) as String;
			if (body?.trim()) {
				//TXJCD Lookup
				if(body.toString().contains(TXJCD_SEND)) {
					logJurRequest(message, body);
				}
				if(body.toString().contains(TXJCD_RECEIVE)) {
					logJurResponse(message, body);
					//messageLog.setStringProperty(LOG_NAME, body.toString());
				}
				//Get Changed Lookup  //New for build 1902
				if(body.toString().contains(GETCHANGED_SEND)) {
					logGetChangedRequest(message, body);
				}
				if(body.toString().contains(GETCHANGED_RECEIVE)) {
					logGetChangedResponse(message, body);
					//messageLog.setStringProperty(LOG_NAME, body.toString());
				}
				//Jur Redefine Lookup  //New for build 1902
				if(body.toString().contains(REDEFINE_SEND)) {
					logJurRedefineRequest(message, body);
				}
				if(body.toString().contains(REDEFINE_RECEIVE)) {
					logJurRedefineResponse(message, body);
					//messageLog.setStringProperty(LOG_NAME, body.toString());
				}	
				//Tax Calculation
				if (body.contains(CALC_REQ_ITEM)) {
					logCalcRequest(message, body);
				}
				if (body.contains(QUOTE)) {
					def int i1 = (body.lastIndexOf(CUST).toInteger()) + 9;
					messageLog.setStringProperty(LOG_NAME+'VCT', "Quotation");
				}
				if (body.contains(VERIFICATION)) {
					def int i1 = (body.lastIndexOf(VEND).toInteger()) + 7;
					messageLog.setStringProperty(LOG_NAME+'VCT', "Verification");
				}
				if (body.contains("postToJournal") && body.contains("Accrual")) { //New for build 1908
					def int i1 = (body.lastIndexOf(VEND).toInteger()) + 7;
					messageLog.setStringProperty(LOG_NAME+'VCT', "Accrual No-Post");
				}
				if (body.contains("AccrualResponse") || body.contains("InvoiceVerificationResponse") || body.contains("QuotationResponse")) {
					logCalcXMLResponse(message, body);
				}
				if (body.contains(CALC_RES_ITEM)) {
					logCalcResponse(message, body);
				}
				//Force Posting
				if (body.contains(FRC_SEND)) {
					//Parse request body to MPL
					def request  = new XmlParser().parseText(body);
					if(request.FORCE_HEADER.DOC_NUMBER.text()!="") {
						messageLog.setStringProperty(LOG_NAME+'RQ1', "Document #: "  + request.FORCE_HEADER.DOC_NUMBER.text());
					}
					if(request.FORCE_HEADER.TID.text()!="") {
						messageLog.setStringProperty(LOG_NAME+'RQ2', "TID: "         + request.FORCE_HEADER.TID.text());
					}
					if(request.FORCE_ITEM[0].APAR_IND.text()!="") {
						messageLog.setStringProperty(LOG_NAME+'RQ3', "APAR: "        + request.FORCE_ITEM[0].APAR_IND.text());
					}
					if(request.FORCE_ITEM[0].TAX_TYPE.text()!="") {
						messageLog.setStringProperty(LOG_NAME+'RQ4', "TAX_TYPE: "    + request.FORCE_ITEM0[0].TAX_TYPE.text());
					}
				}
				if (body.contains("DistributeTaxProcurementRequest")) {
					messageLog.setStringProperty(LOG_NAME+'VCT', "Distribute Purch.");
				}
				if (body.contains("DistributeTaxRequest")) {
					messageLog.setStringProperty(LOG_NAME+'VCT', "Distribute Sales");
				}
				//Update Posting
				if (body.contains(UPD_SEND)) {
					//Parse request body to MPL
					def request  = new XmlParser().parseText(body);
					if(request.UPDATE_HEADER.DOC_NUMBER.text()!="") {
						messageLog.setStringProperty(LOG_NAME+'RQ1', "Document #: " + request.UPDATE_HEADER.DOC_NUMBER.text());
					}
					if(request.UPDATE_HEADER.TID.text()!="") {
						messageLog.setStringProperty(LOG_NAME+'RQ2', "TID: "        + request.UPDATE_HEADER.TID.text());
					}
					if(request.UPDATE_ITEM[0].APAR_IND.text()!="") {
						messageLog.setStringProperty(LOG_NAME+'RQ3', "APAR: "       + request.UPDATE_ITEM[0].APAR_IND.text());
					}
					if(request.UPDATE_ITEM[0].TAX_TYPE.text()!="") {
						messageLog.setStringProperty(LOG_NAME+'RQ4', "TAX_TYPE: "   + request.UPDATE_ITEM[0].TAX_TYPE.text());
					}
				}
				if (body.contains("InvoiceRequest")) {
					messageLog.setStringProperty(LOG_NAME+'VCT', "Invoice");
				}
				if (body.contains("AccrualRequest") && !body.contains("postToJournal")) {
					messageLog.setStringProperty(LOG_NAME+'VCT', "Accrual Posting");
				}
			}
		} catch (Exception ex) {
			log.error("processData error",ex);
		}
	}
	messageLog.setStringProperty(LOG_NAME+'7', "Return Message");
	return message;
}

//Logging Level
def checkLoggingLevel(Message message) {
	def props = message.getProperties();
	def map   = props.get(PROPERTY_LOGGING_LEVEL);

	if (map != null) {
		if (map.toString().contains(LOG_DEBUG)) {
			logLvl = "DEBUG";
		}	else if (map.toString().contains(LOG_TRACE)) {
			logLvl = "TRACE";
		}	else {
			logLvl = "OTHER";
		}
	} else {
		logLvl = "OTHER";
	}
	return logLvl;
}

//Jurisdiction lookup request - Send to MPL
def logJurRequest(Message message, String body) {
	def messageLog = messageLogFactory.getMessageLog(message);
	//Parse request body to MPL
	def request  = new XmlParser().parseText(body);

	if(request.LOCATION_DATA.COUNTRY.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RQ1', "Country: "  + request.LOCATION_DATA.COUNTRY.text());
	}
	if(request.LOCATION_DATA.STATE.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RQ2', "State: "    + request.LOCATION_DATA.STATE.text());
	}
	if(request.LOCATION_DATA.COUNTY.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RQ3', "County: "   + request.LOCATION_DATA.COUNTY.text());
	}
	if (request.LOCATION_DATA.CITY.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RQ4', "City: "     + request.LOCATION_DATA.CITY.text());
	}
	if (request.LOCATION_DATA.ZIPCODE.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RQ5', "Zip: "      + request.LOCATION_DATA.ZIPCODE.text());
	}
	if (request.LOCATION_DATA.STREET_ADDRESS.STREET.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RQ6', "Street: "   + request.LOCATION_DATA.STREET_ADDRESS.STREET.text());
	}  //New for build 1902
	if (request.LOCATION_DATA.STREET_ADDRESS.STREET1.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RQ7', "Street1: "  + request.LOCATION_DATA.STREET_ADDRESS.STREET1.text());
	}  //New for build 1902
	return message;
}

//Jurisdiction lookup response - Send to MPL, gets 1st response
def logJurResponse(Message message, String body) {
	def messageLog = messageLogFactory.getMessageLog(message);
	//Parse response body to MPL
	def response  = new XmlParser().parseText(body);
	def count = response.LOCATION_RESULTS.size();
	messageLog.setStringProperty(LOG_NAME+'8', "Responses: "+count);

	if(response.LOCATION_RESULTS[0].COUNTRY.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RS1', "Country: "  + response.LOCATION_RESULTS[0].COUNTRY.text());
	}
	if(response.LOCATION_RESULTS[0].STATE.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RS2', "State: "    + response.LOCATION_RESULTS[0].STATE.text());
	}
	if(response.LOCATION_RESULTS[0].COUNTY.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RS3', "County: "   + response.LOCATION_RESULTS[0].COUNTY.text());
	}
	if (response.LOCATION_RESULTS[0].CITY.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RS4', "City: "     + response.LOCATION_RESULTS[0].CITY.text());
	}
	if (response.LOCATION_RESULTS[0].ZIPCODE.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RS5', "Zip: "      + response.LOCATION_RESULTS[0].ZIPCODE.text());
	}
	if (response.LOCATION_RESULTS[0].TXJCD.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RS6', "TXJCD: "    + response.LOCATION_RESULTS[0].TXJCD.text());
	}  //New for build 1902
	if (response.LOCATION_RESULTS[0].STREET_ADDRESS.STREET.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RS7', "Street: "   + response.LOCATION_RESULTS[0].STREET_ADDRESS.STREET.text());
	}  //New for build 1902
	if (response.LOCATION_RESULTS[0].STREET_ADDRESS.STREET1.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RS8', "Street1: "  + response.LOCATION_RESULTS[0].STREET_ADDRESS.STREET1.text());
	}  
	return message;
}

//Calculation request - Send to MPL
def logCalcRequest(Message message, String body) {
	def messageLog = messageLogFactory.getMessageLog(message);
	//Parse request body to MPL
	def request  = new XmlParser().parseText(body);
	def int iter = 0;
	messageLog.setStringProperty(LOG_NAME+"2", "Comp. Code: "    +request.CALCULATION_HEADER.COMP_CODE.text().toString());
	messageLog.setStringProperty(LOG_NAME+"3", "APAR: " 		+request.CALCULATION_ITEM[0].APAR_IND.text().toString());
	messageLog.setStringProperty(LOG_NAME+"4", "Tax Type: " 	+request.CALCULATION_ITEM[0].TAX_TYPE.text().toString());

	request.CALCULATION_ITEM.each() {
		iter = iter + 1;
		messageLog.setStringProperty(LOG_NAME+"5_Line"+iter+"_A",  "Item #: " 		+it.ITEM_NO.text().toString());
		messageLog.setStringProperty(LOG_NAME+"5_Line"+iter+"_B",  "Ship-To: " 		+it.TXJCD_ST.text().toString());
		messageLog.setStringProperty(LOG_NAME+"5_Line"+iter+"_C",  "Ship-From: "	+it.TXJCD_SF.text().toString());
		messageLog.setStringProperty(LOG_NAME+"5_Line"+iter+"_D",  "Amount: " 		+it.AMOUNT.text().toString());
		messageLog.setStringProperty(LOG_NAME+"5_Line"+iter+"_E",  "Gross Amt: " 	+it.GROSS_AMOUNT.text().toString());
		messageLog.setStringProperty(LOG_NAME+"5_Line"+iter+"_F",  "Freight Amt: " 	+it.FREIGHT_AM.text().toString());
		messageLog.setStringProperty(LOG_NAME+"5_Line"+iter+"_G_", "Sales Doc Number: "   +it.POPUP_FIELDS.TAX_POPUP_FIELDS_S.SALES_DOC.text().toString()); //New for build 1905
		messageLog.setStringProperty(LOG_NAME+"5_Line"+iter+"_H_", "Purch Doc Number: "   +it.POPUP_FIELDS.TAX_POPUP_FIELDS_S.PURCHASE_DOC.text().toString());  //New for build 1905
		messageLog.setStringProperty(LOG_NAME+"5_Line"+iter+"_I_", "--------------------");  //New for build 1905
	}
	return message;
}

//Calculation response - Send to MPL
def logCalcXMLResponse(Message message, String body) {
	def messageLog = messageLogFactory.getMessageLog(message);
	//Parse response body to MPL
	def response  = new XmlParser().parseText(body);
	def String totTax;
	if (body.contains("AccrualResponse")) {
		totTax = response.AccrualResponse.TotalTax.text().toString();
	} else if (body.contains("InvoiceVerificationResponse")) {
		totTax = response.InvoiceVerificationResponse.TotalTax.text().toString();
	} else if (body.contains("QuotationResponse")) {
		totTax = response.QuotationResponse.TotalTax.text().toString();
	}

	messageLog.setStringProperty(LOG_NAME+"2", "Total Tax: " +totTax);

	def int iter = 0;
	response.children().LineItem.each() {
		iter = iter + 1;
		messageLog.setStringProperty(LOG_NAME+"3_Line"+iter+"_A", "Taxable Amt: "       +it.ExtendedPrice.text().toString());
		messageLog.setStringProperty(LOG_NAME+"3_Line"+iter+"_B", "Tax Amt: "            +it.TotalTax.text().toString());
		messageLog.setStringProperty(LOG_NAME+"3_Line"+iter+"_C", "--------------------");
		//New for build 1905
		if(it.lineitem[0]!=null) {
			if(it.LineItem[0].attribute("lineItemId").toString() == "Vertex freight sub line item identifier") {
			messageLog.setStringProperty(LOG_NAME+"3_Line"+iter+"_C", "Freight Amt: "    +it.LineItem[0].ExtendedPrice.text().toString());
			messageLog.setStringProperty(LOG_NAME+"3_Line"+iter+"_D", "Freight Tax: "    +it.LineItem[0].TotalTax.text().toString());
			messageLog.setStringProperty(LOG_NAME+"3_Line"+iter+"_E_", "--------------------");
			}
		}
	}
	return message;
}

//Calculation response - Send to MPL
def logCalcResponse(Message message, String body) {
	def messageLog = messageLogFactory.getMessageLog(message);
	//Parse response body to MPL
	def response  = new XmlParser().parseText(body);
	def int iter = 0;

	response.CALCULATION_RESULT_ITEM.each() {
		iter = iter + 1;
		messageLog.setStringProperty(LOG_NAME+"2_Line"+iter+"_A",  "Item #: " 	+it.ITEM_NO.text().toString());
		messageLog.setStringProperty(LOG_NAME+"2_Line"+iter+"_B",  "Tax Pct: " 	+it.TAXPCOV.text().toString());
		messageLog.setStringProperty(LOG_NAME+"2_Line"+iter+"_C",  "Tax Amt: " 	+it.TAXAMOV.text().toString());
		messageLog.setStringProperty(LOG_NAME+"2_Line"+iter+"_D_", "--------------------");
	}
	return message;
}

//Get changed jurisdictions request - Send to MPL  //New for build 1902
def logGetChangedRequest(Message message, String body) {
	def messageLog = messageLogFactory.getMessageLog(message);
	//Parse request body to MPL
	def request  = new XmlParser().parseText(body);

	if(request.LAST_UPDATED_DATE.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RQ1', "Start Date: "  + request.LAST_UPDATED_DATE.text());
	}
	if(request.SEND_DATE.text()!="") {
		messageLog.setStringProperty(LOG_NAME+'RQ2', "End Date: "    + request.SEND_DATE.text());
	}
	return message;
}

//Get changed jurisdictions response - Send to MPL  //New for build 1902
def logGetChangedResponse(Message message, String body) {
	def messageLog = messageLogFactory.getMessageLog(message);
	//Parse response body to MPL
	def response  = new XmlParser().parseText(body);
	def count = response.TAX_JURI_CODE.TXJCD.size();
	messageLog.setStringProperty(LOG_NAME+'1', "Responses: "+count);
	messageLog.setStringProperty(LOG_NAME+'RS1', "Result 1: "  + response.TAX_JURI_CODE.TXJCD[0].text());

	return message;
}

//Jurisdiction redefine request - Send to MPL  //New for build 1902
def logJurRedefineRequest(Message message, String body) {
	def messageLog = messageLogFactory.getMessageLog(message);
	//Parse request body to MPL
	def request  = new XmlParser().parseText(body);
  def count = request.LOCATION_SIMPLE.size();
	messageLog.setStringProperty(LOG_NAME+'1', "Requests: "+count);
	return message;
}

//Jurisdiction redefine response - Send to MPL  //New for build 1902
def logJurRedefineResponse(Message message, String body) {
	def messageLog = messageLogFactory.getMessageLog(message);
	//Parse response body to MPL
	def response  = new XmlParser().parseText(body);
	def countok = response.TAX_JURI_CODE_NUM.size();
	messageLog.setStringProperty(LOG_NAME+'1', "Responses: "+countok);
	def counterr = response.TAX_JURI_CODE_NUM.MSG_RETURN.ERRCODE.size();  //Testing to see if this works
	messageLog.setStringProperty(LOG_NAME+'2', "Errors: "+counterr);      //Testing to see if this works

	return message;
}