/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
//Properties 
	//get Properties 
    map = message.getProperties();
    // def Integer intValue = Integer.parseInt(map.get("start_Count"));
    //def String strStartCount = String.valueOf(map.get("start_Count"));
    def Integer intLoopCount = map.get("loop_Count");

    
    def Integer newLoopCount = intLoopCount + 1;
    message.setProperty("loop_Count", newLoopCount);
    
    
       if (newLoopCount == 3 ){
        
        message.setProperty("new_Start", "N");
    } else {
        message.setProperty("new_Start", "Y");
    }
    
    return message;
}