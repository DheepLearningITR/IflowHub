import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.util.XmlParser;

def Message processData(Message message) {
    
    use (groovy.time.TimeCategory) {
        
    def map = message.getProperties();
    def deliveryRequest = new XmlParser().parse(message.getBody())
    
    deliveryRequest.MessageHeader[0].appendNode("ReplicationTime", [:], 1.minutes.from.now)
    
    message.setBody(XmlUtil.serialize(deliveryRequest))
    }
    
    return message

}