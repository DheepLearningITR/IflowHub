import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

      use (groovy.time.TimeCategory) {
         def map = message.getProperties();
         def replicationTimeString = map.get("ReplicationTime");
         def replicationTime = Date.parse("E MMM dd H:m:s z yyyy", replicationTimeString);
         def now = new Date();
        if(now.compareTo(replicationTime)  >= 0 ){
             message.setHeader("ProcessGoodsIssue", 'true');
        }else{
             message.setHeader("ProcessGoodsIssue", 'false');
        }
      }
       
      return message;
    
}
