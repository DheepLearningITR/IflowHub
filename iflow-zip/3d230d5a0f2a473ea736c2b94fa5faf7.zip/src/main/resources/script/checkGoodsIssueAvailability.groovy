import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
     if(message.getBody()){
        message.setHeader("GoodsIssueAvailable", 'true');   
      }else{
        message.setHeader("GoodsIssueAvailable", 'false');   
      }

     return message;
}