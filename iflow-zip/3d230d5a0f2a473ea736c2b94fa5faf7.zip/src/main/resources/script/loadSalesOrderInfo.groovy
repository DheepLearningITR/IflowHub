import com.sap.it.api.mapping.*;


def String getSalesOrderId(String referenceId, MappingContext context ){
    return context.getProperty("ExternalDocumentID");
}

def String getEntryNumber(String referenceId, MappingContext context ){
    return context.getProperty("ExternalItemID");
}