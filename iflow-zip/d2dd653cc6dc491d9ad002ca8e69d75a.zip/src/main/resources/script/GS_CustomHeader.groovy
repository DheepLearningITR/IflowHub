import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	def properties = message.getProperties();
	
	if(messageLog != null) {
	    
        def bioInitials = properties.get("bioInitials");		
	    if(bioInitials != null) {
		    messageLog.addCustomHeaderProperty("OldInitials", bioInitials);		
        }
        
        def mdfInitials = properties.get("mdfInitials");		
	    if(mdfInitials != null) {
		    messageLog.addCustomHeaderProperty("NewInitials", mdfInitials);		
        }
        
        def bioUserId = properties.get("bioUserId");		
	    if(bioUserId != null) {
		    messageLog.addCustomHeaderProperty("ActiveUserID", bioUserId);	
	    }
	    
	    def mdfPersonID = properties.get("mdfPersonID");		
	    if(mdfPersonID != null) {
		    messageLog.addCustomHeaderProperty("PersonID", mdfPersonID);	
	    }
	    
	    def hireDate = properties.get("hireDate");		
	    if(hireDate != null) {
		    messageLog.addCustomHeaderProperty("HireDate", hireDate);	
	    }
	    
	    message.setHeader("SAP_ApplicationID", "Initials_".concat(properties.get("mdfPersonID")));
    
	}
	return message;
}