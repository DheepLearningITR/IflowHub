import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*
import groovy.json.*

def Message processData(Message message) {
   
   def reader = message.getBody(java.io.Reader)
   def array = []
   
   reader.eachLine {String line -> array.add(line.replaceAll("[\\t\\n\\r]+"," "))}
   message.setBody(array.join(" "))

    return message 
}

def Message getHttpResponseBody(Message message) {
   
    def map = message.getProperties();
    def ex = map.get("CamelExceptionCaught");
    
    if (ex!=null){
        message.setBody(ex.getResponseBody());
    }

    return message;
}

def Message removeEmptyObjects (Message message){
    
    def xml = new XmlParser().parseText(message.getBody(String.class))
    def nodes = xml.'**'.findAll{it.name() && !it.text()}
    
    def removeNode = { node ->
        def parent = node.parent()
            parent.remove(node)
    }

    nodes.each{removeNode(it)}

    message.setBody(groovy.xml.XmlUtil.serialize(xml))
    
    return message
}

def Message prepareMail (Message message){
    def json = new JsonSlurper().parseText(message.getBody(String.class))
    assert json instanceof Map
    
    def htmlString = ""

    if (json.root.data.result){
        json.root.data.result.each{key, value -> htmlString +='<tr>'+'<td>'+ key +'</td>'+'<td>'+ value.value+'</td>'+'<td>'+value.confidence + '</td>'+'</tr>'}
        
        message.setProperty("EntitiesFound", true)
        message.setBody(htmlString)

    } else {
     message.setProperty("EntitiesFound", false)
    }
    
return message
}