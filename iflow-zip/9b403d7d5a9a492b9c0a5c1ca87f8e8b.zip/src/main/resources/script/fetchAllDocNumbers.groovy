import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def payload = message.getBody(String.class);
    def xml = new XmlSlurper().parseText(payload);

    message.setHeader("SAPIdocIdList", xml.IDOC.collect { it.EDI_DC40.DOCNUM.text() });

    return message;
}