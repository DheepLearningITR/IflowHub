import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String resolveMultiLineComment(String text, MappingContext context){
    String xml = context.getProperty("inbound_ticket_body");
    Set textTypeSet = ["Problem Description", "Solution Description", "Reply", "Note", "Problem Similarlity Text"];
    String commentDelimeter = "____________________";
    int maxAllowedOccurenceOfTextType = 1;
    Map<String, String> hashmap = new HashMap<String, String>();
    
    def locale = new XmlSlurper()
      .parseText(xml)
      .IDOC
      .E101CRMXIF_BUSTRANS
      .E101CRMXIF_TEXT_XT
      .E101CRMXIF_TEXT.LANGUAGE_ISO
    
    
    def textList = new XmlSlurper()
      .parseText(xml)
      .IDOC
      .E101CRMXIF_BUSTRANS
      .E101CRMXIF_TEXT_XT
      .E101CRMXIF_TEXT
      .E101CRMXIF_TLINE.TEXT_LINE*.text()
    
    def comment;
    
    for(value in textList){ 
        if (value != null && (locale != null) && (!locale.isEmpty())) {
                    if (textTypeSet.contains(value)) {
                        --maxAllowedOccurenceOfTextType;
                    }
                    if (maxAllowedOccurenceOfTextType == 0 && !value.equals(commentDelimeter)) {
                            if (hashmap.containsKey(locale)) {
                                    hashmap.put(locale, hashmap.get(locale).concat(value.toString()).concat("\r\n"));
                                } else {
                                    hashmap.put(locale, value.toString().concat("\r\n"));
                                }
                        comment = hashmap.get(locale);
                    } else if (maxAllowedOccurenceOfTextType < 0) {
                        break;
                    }
                }
    }
    
    return comment;
    
}

    
    