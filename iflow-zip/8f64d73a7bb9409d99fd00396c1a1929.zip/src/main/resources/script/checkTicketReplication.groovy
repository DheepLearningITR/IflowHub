import com.sap.it.api.mapping.*;

def String isTicketReplicated(String input, MappingContext context ){
    
    String ticketReplicated = context.getProperty("ticketReplicated");
    if("".equals(ticketReplicated)) {
        return "false";
    }
	return ticketReplicated; 
}