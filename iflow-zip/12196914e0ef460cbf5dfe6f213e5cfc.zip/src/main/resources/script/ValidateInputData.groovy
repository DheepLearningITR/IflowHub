import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.commons.lang3.StringUtils;

def Message processData(Message message) {
	String body = message.getBody(java.lang.String.class); 
	if(body == null || body.length() == 0) {
		message.setProperty("InvalidInputData","True");
	} else{
		try{
			def bodyXml = new XmlSlurper().parseText(body);
			def failedIDs = bodyXml.'**'.findAll{node -> node.name() == 'OfferingID'}*.text();
		    if(failedIDs.isEmpty()) {
			    message.setProperty("InvalidInputData","True");
		    }
		}catch(Exception e){
			message.setProperty("InvalidInputData","True");
		}

	}
	
	return message;
}