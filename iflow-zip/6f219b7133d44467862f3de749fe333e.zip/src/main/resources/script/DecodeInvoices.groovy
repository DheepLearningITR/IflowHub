import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.xml.*
import java.text.SimpleDateFormat;
import java.util.*;

def Message processData(Message message) {

    String body = message.getBody(java.lang.String) as String;
    
    def n1 = new groovy.xml.Namespace("http://www.sap.com/eDocument/Switzerland/ReceiveInvoice/v1.0");


    def root = new XmlParser().parseText(body);
	


    
   
      root[n1.InvoiceEnvelope][n1.Invoice].findAll{
      it.text( ) != null
	   
	   }.each{
		   def encoded = it.text()		
		   byte[] decoded = encoded.decodeBase64()
		   def s = new String(decoded, "UTF-8")
		   it.value = s
	   };
		
    def nodeAsText =XmlUtil.serialize(root)

    byte[] Bytes = nodeAsText.getBytes("UTF-8");

    String encodedString = new String(Bytes, "UTF-8");

    encodedString = encodedString.replaceAll("&lt;","<");
    encodedString = encodedString.replaceAll("&gt;",">");
    encodedString = encodedString.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
    encodedString = encodedString.replaceAll("n0:InvoiceEnvelope", "InvoiceEnvelope").trim();
    encodedString = encodedString.replaceAll("n0:Invoice", "Invoice").trim();
   
    message.setBody(encodedString);
	return message;
}