import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData( Message message ) throws Exception {

	def keepGoing = true;
	int count = 1;
	def PayerIdList = [];
	
	while( keepGoing ){
	     String PayerId = dynamicValueMap("Id","name", "PayerId", "name", count.toString());

		if (PayerId == null) {
           keepGoing = false;
        } else {
		 PayerIdList.add(PayerId)
		}
		
		count++;
	}
	
	int countPayerId = PayerIdList.size;
    
    if (countPayerId == 0){
        throw new IllegalStateException("Payer Id could not be determined");
    } 
	
	//build xml based on Payer list
	def writer = new StringWriter()
    def xml = new groovy.xml.MarkupBuilder(writer)

    xml.PayerIds {
    setOmitEmptyAttributes(true)
    setOmitNullAttributes(true)
    
    for(item in PayerIdList){
    PayerId{
            Id(item)
        }
    }
    
}
	
	
	message.setBody(writer.toString());

	return message;
}

def String dynamicValueMap(String sAgency, String sSchema, String tAgency, String tSchema, String key){
	def service = ITApiFactory.getApi(ValueMappingApi.class, null);
	if( service != null) {
		return service.getMappedValue(sAgency, sSchema, key, tAgency, tSchema);
	}
	throw new Exception("Service is null");
	return null;
}


def Message GetBiller(Message message) throws Exception {

  def keepGoing = true;
  int count = 1;
  def BillerIdList = [];
  String BillerId;

  while (keepGoing) {
    BillerId = dynamicValueMap("Id", "name", "BillerId", "name", count.toString());

    if (BillerId == null) {
      keepGoing = false;
    } else {
      message.setHeader('BillerID', BillerId );
    }

    count++;
  }


  if (BillerId == null && count == 2 ) {
    throw new IllegalStateException("Biller Id could not be determined");
  }

  return message;
}

def Message GetBillerForPayer(Message message) throws Exception {
  
  def map = message.getProperties();
  def PayerId = map.get("PayerId");
  def CertAuth = map.get("CertificateAuth");
  String BillerId;

  BillerId = dynamicValueMap("PayerId", "name", "BillerId", "name", PayerId);

  if (BillerId == null ) {
    throw new IllegalStateException("Biller Id could not be determined for Payer " + PayerId);
  } else {
      CredentialName = 'edoc_switzerland_' + BillerId;
      if(CertAuth.toUpperCase() == 'TRUE'){
          message.setHeader('ClientCert', CredentialName );
          
      } else {
          message.setHeader('CredentialName', CredentialName );
      }
      
  }

  return message;
}

def Message GetPayerForBiller(Message message) throws Exception {
  
  def map = message.getProperties();
  def BillerId = map.get("BillerId");
  def CertAuth = map.get("CertificateAuth");

  
  def keepGoing = true;
  int count = 1;
  def PayerIdList = [];
	
  while( keepGoing ){
	    String PayerId = dynamicValueMap("Id","name", "PayerId", "name", count.toString());
		if (PayerId == null) {
           keepGoing = false;
        } else {
		 PayerIdList.add(PayerId)
		}
		count++;
	}
  
  for(item in PayerIdList){
    CorrelatedBillerId = dynamicValueMap("PayerId", "name", "BillerId", "name", item);
    if ( CorrelatedBillerId == BillerId) {
       message.setProperty('PayerId', item );
       }
    }

  return message;
}