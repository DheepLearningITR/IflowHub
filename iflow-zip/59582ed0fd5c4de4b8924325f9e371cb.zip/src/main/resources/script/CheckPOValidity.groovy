import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    
    
   	message.setProperty("isPoCreate", 'false');
   	
   	def headers = message.getHeaders();
    def totalactBalance=headers.totalAccountBalance
	def reorderPt=headers.reorderPoint
	
	def createPurchaseOrderFlag=headers.createPurchaseOrderFlag;
	def orderQty=headers.orderQuantity
	
	def totalPurchaseOrderQty=message.getProperty("TotalPurchaseOrderQuantity");
	def qtyBaseUnit=message.getProperty("totalQtyBaseUnit");
	message.setProperty("remarks", "Reorder point is less than the total account balance  ");
	
	
	int totalQtyBaseUnit=0
	int totalPurchaseOrderQuantity=0
	int lotSize=1
	int orderQuantity=1
	
    int totalAccountBalance = totalactBalance.toInteger()
	
    int reorderPointQuanity = reorderPt.toInteger()
    
    if(orderQty!=null && !orderQty.isEmpty()){
       if(orderQty.isInteger()){
            orderQuantity=orderQty.toInteger()
            orderQuantity=orderQuantity>0?orderQuantity:1
       }
 
   }
   
	
	if(totalPurchaseOrderQty!=null){
	    totalPurchaseOrderQuantity = totalPurchaseOrderQty.toInteger()
	}
	
	
	if(qtyBaseUnit!=null){
	 	totalQtyBaseUnit = qtyBaseUnit.toInteger()   
	}
	
      
	
	
	int validCount=totalAccountBalance + (totalPurchaseOrderQuantity - totalQtyBaseUnit)
	
	int orderValue=reorderPointQuanity-validCount
	
    lotSize=Math.ceil(orderValue/orderQuantity)*orderQuantity
	
	
	message.setProperty("validCount", validCount);
	
	
	if(validCount < reorderPointQuanity){
	    
	    	if(createPurchaseOrderFlag=='N'){
	             message.setProperty("remarks", "Purchase Order should be Created");
	          }else{
	              message.setProperty("lotSize", lotSize);
	              message.setProperty("isPoCreate", 'true');
	          }	
	}else{
	    message.setProperty("PO_Created", true)
	    message.setProperty("remarks", "Enough PO Quanity is there");
	}
	
	return message
 }
 
 


