import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;
import java.io.*;
import groovy.json.JsonOutput;
import java.time.*



def Message processData(Message message) { 
    
    def date = new Date().format('yyyy-MM-dd')
    def headers = message.getHeaders();
   
  def remarks=message.getProperty("remarks");
  if(!remarks){
      remarks='Failed to create Purchase Order'
  }
  
  def returnableAccount=headers.returnableAccount;
  //def dateTime = headers.currentTimeDate;
  
  def poNum=message.getProperty("poNum");
  def po_created=message.getProperty("PO_Created");
  //def LastDateTime=message.getProperty("LastChangeDateTime");
  def timestamp=date;
  
 
 def output
 
// def sucessOutput = JsonOutput.toJson(new FailureRecord(status: 'Success',currentDate:timestamp,poNumber:poNum));
 if(poNum){
     output=JsonOutput.toJson(new SuccessRecord(returnableAccount:returnableAccount,status: 'Success',currentDate:date,poNumber:poNum));
   }else{
       if(po_created){
            output = JsonOutput.toJson(new FailureRecord(returnableAccount:returnableAccount,status: 'PO_Already_Created',remarks:remarks,currentDate:date));       
       }else{
            output = JsonOutput.toJson(new FailureRecord(returnableAccount:returnableAccount,status: 'Failure',remarks:remarks,currentDate:''));       
       }
    
 }
 
  message.setBody(output)
  
  def messageLog = messageLogFactory.getMessageLog(message);
  
   if(messageLog != null ){
        messageLog.setStringProperty("responseLog", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("POResponse_responseLog: ", output , "text/plain");
    }
 
	return message
}



class FailureRecord{
   String returnableAccount,status, remarks, currentDate
}
class SuccessRecord{
   String returnableAccount,status, currentDate, poNumber
}
