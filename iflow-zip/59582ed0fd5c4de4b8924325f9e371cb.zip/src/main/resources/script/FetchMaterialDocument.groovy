import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);

	def purchaseOrder=object.A_PurchaseOrderItem;
	def headers = message.getHeaders();
	def goodsMovementType = headers.GoodsMovementType
	
	
    String materialDocFilter;
    
    String codeFilter="(";
    String purchaseOrderFilter=" and ("
    
    String movementTypeFiler=" and ( GoodsMovementType eq '".concat(goodsMovementType.toString()).concat("' )")
    message.setProperty("isError", 'false');
    int totalPurchaseOrderQuantity=0
    if(purchaseOrder){
    def itemList=purchaseOrder.A_PurchaseOrderItemType;
    
    int count=0
    int orderQuantity=0;
    String recordMaterial=null;
    String tempPayload="Material eq '"
    if(itemList.size>0){
        
        itemList.each{record ->
          //String tempPayload
          String tempPOPayload
              if(count==0){
                  //tempPayload = "Material eq '"
                  tempPOPayload = "PurchaseOrder eq '"
              }else{
                  //tempPayload = " or Material eq '"
                  tempPOPayload = "or PurchaseOrder eq '"
              }
              recordMaterial=record.Material
              //tempPayload = tempPayload+record.Material +"'"
              tempPOPayload= tempPOPayload + record.PurchaseOrder + "'"
               println(record.Material)
               println(record.PurchaseOrder)
               //codeFilter=codeFilter.concat(tempPayload)
               purchaseOrderFilter=purchaseOrderFilter.concat(tempPOPayload)
               
               orderQuantity=orderQuantity + Integer.parseInt(record.OrderQuantity)
               
               count++
               
      }
      
        
    }else{
        
        //String tempPayload="Material eq '"+itemList.Material +"'"
        recordMaterial = itemList.Material
        String tempPOPayload="PurchaseOrder eq '"+itemList.PurchaseOrder +"'"
        //codeFilter=codeFilter.concat(tempPayload)
        purchaseOrderFilter=purchaseOrderFilter.concat(tempPOPayload)
        
        if(itemList.OrderQuantity!=null){
           orderQuantity=orderQuantity + Integer.parseInt(itemList.OrderQuantity)  
        }
       
        
    }
    tempPayload="Material eq '"+recordMaterial +"'"
    codeFilter = codeFilter.concat(tempPayload)
    totalPurchaseOrderQuantity=orderQuantity;
    
    	//message.setProperty("TotalPurchaseOrderQuantity", totalPurchaseOrderQuantity);
}else{
    
    message.setProperty("isError", 'true');
}

      codeFilter=codeFilter+")"
      purchaseOrderFilter=purchaseOrderFilter+")"
      if(materialDocFilter != null) {
				materialDocFilter=materialDocFilter.concat(codeFilter).concat(purchaseOrderFilter).concat(movementTypeFiler)
			} else {
				materialDocFilter = codeFilter.concat(purchaseOrderFilter).concat(movementTypeFiler)
			}
	
	
	
	
	// Prepare Message Body
//	message.setBody(completePayload)

	message.setProperty("materialDocFilter", materialDocFilter);
	message.setProperty("TotalPurchaseOrderQuantity", totalPurchaseOrderQuantity);
	
	return message
}

