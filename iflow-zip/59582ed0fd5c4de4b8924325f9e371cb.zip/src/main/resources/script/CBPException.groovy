import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper;
import groovy.util.XmlParser;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    message.setProperty("remarks",'Exception Occured while creationg a PO' )
    
    return message;
}