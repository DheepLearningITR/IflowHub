import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	
	message.setProperty("contractPresent",'false')
	
	def purchaseContractItem=object.A_PurchaseContractItem
    
    
  if(purchaseContractItem){
        def purchaseContractItemType=purchaseContractItem.A_PurchaseContractItemType;
      	
      	if(purchaseContractItemType){
      	    message.setProperty("contractCompanyCode", purchaseContractItemType.CompanyCode);
      	    def contractPlant=purchaseContractItemType.Plant
      	    
      	    if(contractPlant){
      	         message.setProperty("contractPlant", contractPlant);
      	    }else{
      	        message.setProperty("remarks",'Plant not found for given Material Code')
      	        return message;
      	        
      	    }
      	   
      	    message.setProperty("contractPurchaseItem", purchaseContractItemType.PurchaseContractItem);
      	    
      	   
      	    def purchaseContract=purchaseContractItemType.to_PurchaseContract;
      	    if(purchaseContract){
      	        def purchaseContractType=purchaseContract.A_PurchaseContractType;
      	        message.setProperty("contractSupllier", purchaseContractType.Supplier);
      	        message.setProperty("contractPurchasingOrg",purchaseContractType.PurchasingOrganization)
      	    }
       	}
       	message.setProperty("contractPresent",'true')
      
  }else{
      message.setProperty("remarks",'Contract not found for given Material Code')
      
  }
    
	return message
}

