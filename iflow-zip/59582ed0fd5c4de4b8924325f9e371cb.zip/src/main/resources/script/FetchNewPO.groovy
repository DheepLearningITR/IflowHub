import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.*


def Message processData(Message message) {
    
    def body = message.getBody(String.class);
    def xmlSlupper = new XmlParser();
    def object = xmlSlupper.parseText(body);
    def content=object.content;
    
    def poNum="${object.content[0].properties.PurchaseOrder.text()}";
    
    def lastChangeDateTime="${object.content[0].properties.LastChangeDateTime}";
    
    if(!lastChangeDateTime){
         message.setProperty("lastChangeDateTime",lastChangeDateTime.text());
    }
    
    message.setProperty("poNum",poNum);
    
    
   
	return message
 }


