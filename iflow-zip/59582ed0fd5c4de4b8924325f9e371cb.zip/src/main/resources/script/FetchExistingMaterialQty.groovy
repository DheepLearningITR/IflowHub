import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
	//def lastSyncDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss",message.getProperty("lastSyncDate"))
	
	def materialDocumentItem = object.A_MaterialDocumentItem
	

    
    
    message.setProperty("isError", 'false');
      
      
      int totalQtyBaseUnit=0
      
      if(materialDocumentItem){
          	def itemList=materialDocumentItem.A_MaterialDocumentItemType;
          	if(itemList.size>0){
          	    itemList.each{record ->
          	    int tempCount=Integer.parseInt(record.QuantityInBaseUnit)
          	    totalQtyBaseUnit = totalQtyBaseUnit + tempCount
          	    
          	    }
          	    
          	}
          	else{
          	    int tempCount=Integer.parseInt(itemList.QuantityInBaseUnit)
          	     totalQtyBaseUnit = tempCount
          	}
          	message.setProperty("totalQtyBaseUnit", totalQtyBaseUnit);
      }
      else{
    
         message.setProperty("isError", 'true');
    }
      
      
	
	
	return message
}

