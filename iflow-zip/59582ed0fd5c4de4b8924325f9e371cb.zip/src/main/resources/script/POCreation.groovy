import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;
import java.io.*;
import groovy.json.JsonOutput;

def Message processData(Message message) { 
    
    
    def headers = message.getHeaders();
    def cookie = headers.get("Set-Cookie");
    
   
 
 
  def companyCode=message.getProperty("contractCompanyCode")
  //def lotSizemessage.setProperty("lotSize", lotSize);
  
  def purchaseOrderType='NB'
         
  def supplier=message.getProperty("contractSupllier")
         
  def plant=message.getProperty("contractPlant")
  
  def contractPurchasingOrg=message.getProperty("contractPurchasingOrg")
  
  def orderQuantity=headers.orderQuantity
  
  def purchaseContractNumber=headers.purchaseContractNumber
  
  def purchaseContractItem=headers.purchaseContractItemNumber
  
   def material=headers.materialCode;


	
	
	StringBuffer bufferedCookie = new StringBuffer();
	for (Object item : cookie) 
    {
        bufferedCookie.append(item + "; ");      
    }
    
    message.setHeader("Cookie", bufferedCookie.toString());
    message.setHeader("Content-Type", "application/json");
    
    
    String jsonString="{\"CompanyCode\":\""+companyCode.toString()+"\",\"PurchaseOrderType\":\"NB\",\"Supplier\":\""+supplier.toString()+"\",\"PurchasingOrganization\":\""+contractPurchasingOrg.toString()+"\",\"to_PurchaseOrderItem\":[{\"Plant\":\""+plant.toString()+"\",\"OrderQuantity\":\""+orderQuantity.toString()+"\",\"PurchaseContract\":\""+purchaseContractNumber.toString()+"\",\"PurchaseContractItem\":\""+purchaseContractItem.toString()+"\",\"Material\":\""+material.toString()+"\"}]}"

    
    
    String output = JsonOutput.toJson(new PurchaseOrder(CompanyCode: companyCode.toString(),PurchaseOrderType:"NB",Supplier:supplier.toString(),PurchasingOrganization:contractPurchasingOrg.toString(),to_PurchaseOrderItem: [new PurchaseOrderItem(Plant:plant.toString(),OrderQuantity:orderQuantity.toString().toString(),PurchaseContract:purchaseContractNumber.toString(),PurchaseContractItem:purchaseContractItem.toString(),Material:material.toString())]));
     
    
    message.setBody(jsonString)
  
	return message
}



class PurchaseOrder{
   String CompanyCode, PurchaseOrderType, Supplier, PurchasingOrganization
   PurchaseOrderItem[] to_PurchaseOrderItem
}

class PurchaseOrderItem{
    String Plant,OrderQuantity,PurchaseContract,PurchaseContractItem,Material
}