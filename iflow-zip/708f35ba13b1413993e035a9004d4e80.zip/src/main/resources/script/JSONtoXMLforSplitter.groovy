import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    def inputBody = new JsonSlurper().parseText(message.getProperty("CalmResponse"))

    def xmlString = new StringWriter()
    def xmlBuilder = new MarkupBuilder(xmlString)

    xmlBuilder.Projects {
        inputBody.collect { project ->
            Project {
                ID(project.id)
                Name(project.name)
            }
        }
    }

    message.setBody(xmlString.toString())

    return message
}