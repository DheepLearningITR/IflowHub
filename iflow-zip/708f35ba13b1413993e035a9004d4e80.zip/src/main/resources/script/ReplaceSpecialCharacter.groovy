import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def xmlString = message.getBody(java.lang.String)
    xmlString = xmlString.replace("&amp;amp;", "%26")
                                     .replace("&amp;", "%26")

    message.setBody(xmlString)

    return message
}