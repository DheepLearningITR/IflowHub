import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.ITApiFactory
import groovy.json.JsonBuilder

def Message processData(Message message) {

    def srcAgency = message.getProperty("SrcAgency")
    def srcId = message.getProperty("SrcId")
    def ProjectIDs = message.getProperty("ProjectIDs")
    def tgtAgency = message.getProperty("TgtAgency")
    def tgtId = message.getProperty("TgtId")

    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def jsonOutput = []

    def projectIDArray = ProjectIDs.split(',')

    projectIDArray.each { projectID ->
        def tgtValue = valueMapApi.getMappedValue(srcAgency, srcId, projectID, tgtAgency, tgtId)

        if (tgtValue) {
            def jsonEntry = [
                id: projectID,
                name: tgtValue,
                status: ""
            ]
            jsonOutput.add(jsonEntry)
        } else {
            message.setProperty("NotFound", "X")
            return message
        }
    }

    def jsonString = new JsonBuilder(jsonOutput).toString()

    message.setBody(jsonString)

    return message
}