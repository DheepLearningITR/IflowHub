import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	map = message.getProperties();
	property_fromDate = map.get("fromDate");
	property_toDate = map.get("toDate");
	property_LastRunUntil = map.get("LastRunUntil");
	property_ERD = map.get("ERD");
	property_error_occured = map.get("error_occured");
	property_lastRunDateTime = map.get("maxDateFromLastRun");
	property_ENABLE_LOGGING = map.get("ENABLE_LOGGING");
	
	if (property_ENABLE_LOGGING.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String) as String;
		def messageLog = messageLogFactory.getMessageLog(message);
		messageLog.addAttachmentAsString("[Branch 3] Timesheet Payload for All Employees:"+" fromDate="+property_fromDate+ " toDate="+property_toDate+ " LRU="+property_LastRunUntil+ " ERD="+property_ERD + " lastRunDateTime="+property_lastRunDateTime, body, "text/plain");
		
	}
	return message;
}

