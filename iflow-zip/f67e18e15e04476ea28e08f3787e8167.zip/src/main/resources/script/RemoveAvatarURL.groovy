import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;

def Message processData(Message message)
 {
     
	def body = message.getBody(String.class);
	
	def jsonSlurper = new JsonSlurper();
	def json = jsonSlurper.parseText(body);
	
	def index=0;
	def returnMessage = "{"
	
	json.each {
	    returnMessage+= '"id":"' + it.key+ '",';
	    index=index+1;
	}
	
	returnMessage=returnMessage.substring(0, returnMessage.length() - 1)
	returnMessage+='}'
	
    message.setBody(returnMessage);
    return message;

}