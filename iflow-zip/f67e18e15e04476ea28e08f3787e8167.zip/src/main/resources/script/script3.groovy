import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.setStringProperty("Logging#2", "Pre Request")
        messageLog.addAttachmentAsString("Pre Request:", body, "text/plain");
     }
    message.setHeader("Content-Type", "application/json" + "; charset=utf-8" );
    return message;
}