import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message)
 {
     
	def body = message.getBody(String.class);
	
	body=body.substring(0, body.length() - 1)
	body='[' + body + ']'
    message.setBody(body);
    return message;

}