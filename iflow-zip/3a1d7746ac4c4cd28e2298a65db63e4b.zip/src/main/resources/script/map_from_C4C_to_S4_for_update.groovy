import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import java.lang.String

def Message processData(Message message){
    //c4c payload
    def body = new JsonSlurper().parse(message.getProperty("Payload_In")).messageRequests[0].body
    def serviceOrderId = message.getProperty("serviceOrderExternalId")
    Node batch_payload = new NodeBuilder().batchParts{}
    def tempNode
    def itemsMap =[:]
    def batchNodeCount =0
    def itemCreateNodes = []
    
    //C4C SubNodes Data
    def registeredProductIdListC4C = [:]
    if(body.registeredProducts){
        body.registeredProducts.each{
            registeredProductIdListC4C[it.receiverDisplayId] = it
        }
    }
    
    def itemMapC4C = [:]
    if(body.items){
        body.items.each{
            itemMapC4C[it.lineNumber] = it
        }
    }
    
    //notes changes
    def notesMapC4C = [:]
    if(body.notes){
        body.notes.each{
            notesMapC4C[it.noteType] = it
        }
    }
    
    //S4 SubNodes Data
    def root_s4 = new XmlSlurper().parse(message.getBody(java.io.Reader.class))
    
    def itemMapS4 =[:]
    def itemsNode =  root_s4.'**'.findAll { it.name() == 'A_ServiceOrderItemType' }
    itemsNode.each{
        if(it.ReferenceServiceOrderItem && it.ReferenceServiceOrderItem != ""){
            itemMapS4[Integer.parseInt(it.ReferenceServiceOrderItem.text())] = it.ServiceOrderItem.text()
        }
    }
    
    //notes changes
    def notesMapS4 =[:]
    def notesNode =  root_s4.'**'.findAll { it.name() == 'A_ServiceOrderTextType' }
    notesNode.each{
        if(it.LongTextID && it.LongTextID != "") {
            notesMapS4[it.LongTextID.text()] = it.ServiceOrderText.text()
        }
    }
    
    def registeredProductIdListS4 = []
    def relatedObjectsNode = root_s4.'**'.findAll { it.name() == 'A_ServiceOrderRefObjectType' }
    relatedObjectsNode.each{
        registeredProductIdListS4.add(it.ServiceReferenceEquipment.text())
    }
    
    //Batch header update
    def completed = ""
    def rejected = ""
    def rejectionCode = ""
    if(body.isRejected){
        if(itemMapC4C.size()>0){
            rejected ="X"
            rejectionCode = body.rejectionCode
        }
        completed="X"
    }else if(body.lifeCycleStatus.equals("COMPLETED")){
        completed ="X"
    }
    
    Node headerNode = new NodeBuilder().A_ServiceOrder{
        A_ServiceOrderType{
            ServiceOrderType(body.serviceOrderType)
            ServiceOrderDescription(body.description)
            ServiceOrderIsCompleted(completed)
            ServiceOrderIsRejected(rejected)
            ServiceDocumentPriority(body.priority)
            ServiceOrderRejectionReason(rejectionCode)
            TransactionCurrency(message.getProperty("currency"))
        }
    }
    
    tempNode = new NodeBuilder().batchChangeSet{
        batchChangeSetPart{
            method("PATCH")
            uri("A_ServiceOrder('" + serviceOrderId + "')")
            A_ServiceOrder{
            }
        }
    }
    
    def checkNode = headerNode.'**'.find{it.name() == 'A_ServiceOrderType'}
    
    final String useEnterpriseOrg = message.getProperty("useEnterpriseOrg")?.toLowerCase()
    //Adding business area related nodes
    if(body.businessArea){
        checkNode.append(new NodeBuilder().DistributionChannel(body.businessArea.distributionChannel))
        checkNode.append(new NodeBuilder().Division(body.businessArea.division))
        
        if("true".equals(useEnterpriseOrg)){
            //Use Enterprise Organizational Model
            checkNode.append(new NodeBuilder().SalesOrganization(body.businessArea.receiverSalesOrganisationId))
            checkNode.append(new NodeBuilder().SalesOffice(body.businessArea.receiverSalesOfficeId))
            checkNode.append(new NodeBuilder().SalesGroup(body.businessArea.receiverSalesGroupId))
        }else{
            checkNode.append(new NodeBuilder().SalesOrganizationOrgUnitID(body.businessArea.receiverSalesOrganisationCenterId))
            checkNode.append(new NodeBuilder().SalesOfficeOrgUnitID(body.businessArea.receiverSalesOfficeOrganisationCenterId))
            checkNode.append(new NodeBuilder().SalesGroupOrgUnitID(body.businessArea.receiverSalesGroupOrganisationCenterId))
        }
    }
    
     //Adding totalValues nodes 
    if(body.totalValues){
        checkNode.append(new NodeBuilder().ServiceDocGrossAmount(body.totalValues.grossAmount.content))
        checkNode.append(new NodeBuilder().ServiceDocTaxAmount(body.totalValues.taxAmount.content))
        checkNode.append(new NodeBuilder().ServiceDocNetAmount(body.totalValues.netAmount.content))
    }
    
    
    //Adding involved parties
    if(body.account){
        checkNode.append(new NodeBuilder().SoldToParty(body.account.receiverDisplayId))
    }
    if(body.contact){
        checkNode.append(new NodeBuilder().ContactPerson(body.contact.receiverDisplayId))
    }
    if(body.individualCustomer){
        checkNode.append(new NodeBuilder().SoldToParty(body.individualCustomer.receiverDisplayId))
    }
    if(body.shipToAccount){
        checkNode.append(new NodeBuilder().ShipToParty(body.shipToAccount.receiverDisplayId))
    }
    if(body.billToAccount){
        checkNode.append(new NodeBuilder().BillToParty(body.billToAccount.receiverDisplayId))
    }
    if(body.billToIndividualCustomer){
        checkNode.append(new NodeBuilder().BillToParty(body.billToIndividualCustomer.receiverDisplayId))
    }
    if(body.shipToIndividualCustomer){
        checkNode.append(new NodeBuilder().ShipToParty(body.shipToIndividualCustomer.receiverDisplayId))
    }
    if(body.payerAccount){
        checkNode.append(new NodeBuilder().PayerParty(body.payerAccount.receiverDisplayId))
    }
    if(body.payerIndividualCustomer){
        checkNode.append(new NodeBuilder().PayerParty(body.payerIndividualCustomer.receiverDisplayId))
    }
    if(body.serviceOrganisation){
        if("true".equals(useEnterpriseOrg)){
            tempNode.append(new NodeBuilder().EnterpriseServiceOrganization(body.serviceOrganisation.receiverDisplayId))
        } else {
            tempNode.append(new NodeBuilder().ServiceOrganization(body.serviceOrganisation.receiverDisplayId))
        }
    }
    
    
    tempNode.batchChangeSetPart.A_ServiceOrder[0].children().add(0,checkNode)
    batch_payload.append(tempNode)
    batchNodeCount+=1
    
    if(body.owner){
        tempNode = new NodeBuilder().batchChangeSet{
            batchChangeSetPart{
                method("POST")
                uri("A_ServiceOrder('" + serviceOrderId + "')/to_Partner")
                A_SrvcOrdPartner{
                    A_SrvcOrdPartnerType{
                        ServiceOrder(serviceOrderId)
                        CustMgmtPartnerFunction("00000014")
                        CustMgmtBusinessPartner(body.owner.receiverDisplayId)
                        CustMgmtPartnerIsMainPartner(true)
                    }
                }
            }
        }
        batch_payload.append(tempNode)
        batchNodeCount+=1
    }
    
    if(body.serviceTechnician){
        tempNode = new NodeBuilder().batchChangeSet{
            batchChangeSetPart{
                method("POST")
                uri("A_ServiceOrder('" + serviceOrderId + "')/to_Partner")
                A_SrvcOrdPartner{
                    A_SrvcOrdPartnerType{
                        ServiceOrder(serviceOrderId)
                        CustMgmtPartnerFunction("00000052")
                        CustMgmtBusinessPartner(body.serviceTechnician.receiverDisplayId)
                        CustMgmtPartnerIsMainPartner(true)
                    }
                }
            }
        }
        batch_payload.append(tempNode)
        batchNodeCount+=1
    }
    
    //updating header timePoints
    if(body.timePoints){
        tempNode = new NodeBuilder().batchChangeSet{
            batchChangeSetPart{
                method("PATCH")
                uri("A_SrvcOrdAppointment(ServiceOrder='" + serviceOrderId + "',SrvcDocAppointmentType='SRV_CUST_END')")
                A_SrvcOrdAppointment{
                    A_SrvcOrdAppointmentType{
                        ServiceOrder(serviceOrderId)
                        SrvcDocAppointmentType("SRV_CUST_END")
                        SrvcDocApptStartDateTime(Date.parse("yyyy-MM-dd'T'HH:mm:ss", body.timePoints.requestedEndOn).format('yyyy-MM-dd HH:mm:ss', TimeZone.getTimeZone('UTC')))
                        SrvcDocApptEndDateTime()
                    }
                }
            }
        }
        batch_payload.append(tempNode)
        batchNodeCount+=1
    
        tempNode = new NodeBuilder().batchChangeSet{
            batchChangeSetPart{
                method("PATCH")
                uri("A_SrvcOrdAppointment(ServiceOrder='" + serviceOrderId + "',SrvcDocAppointmentType='SRV_CUST_BEG')")
                A_SrvcOrdAppointment{
                    A_SrvcOrdAppointmentType{
                        ServiceOrder(serviceOrderId)
                        SrvcDocAppointmentType("SRV_CUST_BEG")
                        SrvcDocApptStartDateTime(Date.parse("yyyy-MM-dd'T'HH:mm:ss", body.timePoints.requestedStartOn).format('yyyy-MM-dd HH:mm:ss', TimeZone.getTimeZone('UTC')))
                        SrvcDocApptEndDateTime()
                    }
                }
            }
        }
        batch_payload.append(tempNode)
        batchNodeCount+=1
    }

    //Compare S4 with C4C for delete and create of registered products
    def registeredProductsToDelete = []
    for(id in registeredProductIdListS4){
        if(!registeredProductIdListC4C.keySet().contains(id) && id != ''){
            registeredProductsToDelete.add(id)
            tempNode = new NodeBuilder().batchChangeSet{
                batchChangeSetPart{
                    method('DELETE')
                    uri("A_ServiceOrderRefObject(ServiceOrder='" + serviceOrderId + "',ServiceReferenceEquipment='" + id + "',ServiceReferenceEquipment='')")
                }
            }
            batch_payload.append(tempNode)
            batchNodeCount+=1
        }
    }
    message.setProperty("registeredProductsToDelete", registeredProductsToDelete)
    
    def isMain
    def registeredProductsToCreate = []
    for(key in registeredProductIdListC4C.keySet()){
        def registeredProduct = registeredProductIdListC4C[key]
        if(registeredProduct.isMain){
            isMain= "X"
        }else{
            isMain = null
        }
        if(key in registeredProductIdListS4){
            //update of registered product only when isMain is true
            if(isMain == "X"){
                tempNode = new NodeBuilder().batchChangeSet{
                    batchChangeSetPart{
                        method('POST')
                        uri("A_ServiceOrder('" + serviceOrderId + "')/to_ReferenceObject")
                        A_ServiceOrderRefObject{
                            A_ServiceOrderRefObjectType{
                                ServiceOrder(serviceOrderId)
                                ServiceReferenceEquipment(key)
                                SrvcRefObjIsMainObject(isMain)
                            }
                        }
                    }
                }
                batch_payload.append(tempNode)
                batchNodeCount+=1
            }
        }else{
            //create case
            registeredProductsToCreate.add(key)
            tempNode = new NodeBuilder().batchChangeSet{
                batchChangeSetPart{
                    method('POST')
                    uri("A_ServiceOrder('" + serviceOrderId + "')/to_ReferenceObject")
                    A_ServiceOrderRefObject{
                        A_ServiceOrderRefObjectType{
                            ServiceOrder(serviceOrderId)
                            ServiceReferenceEquipment(key)
                            SrvcRefObjIsMainObject(isMain)
                        }
                    }
                }
            }
            batch_payload.append(tempNode)
            batchNodeCount+=1
        }
    }
    message.setProperty("registeredProductsToCreate", registeredProductsToCreate)
    
    //Item update/create and delete batch payload creation
    String parentS4LineNumber
    for(id in itemMapC4C.keySet()){
        def item = itemMapC4C[id]
        
        // If 000000 is provided as the initial item number, the item has no parent item.
        parentS4LineNumber = "000000"
        if(item.parentLineNumber){
            // from itemMapC4C, get the item information of the parent Item and then map it's S4 (receiver) id.
            parentS4LineNumber = itemMapC4C[item.parentLineNumber].receiverId
        }
        
        if(!itemMapS4.keySet().contains(id) && item.receiverId == null){
            //create item
            tempNode = new NodeBuilder().batchChangeSet{
                batchChangeSetPart{
                    method('POST')
                    uri("A_ServiceOrder('" + serviceOrderId + "')/to_Item")
                    A_ServiceOrderItem{
                        A_ServiceOrderItemType{
                            ServiceOrder(serviceOrderId)
                            ServiceOrderItemDescription(item.description)
                            ServiceOrderItemCategory(item.itemCategory)
                            ReferenceServiceOrderItem(id)
                            ParentServiceOrderItem(parentS4LineNumber)
                        }
                    }
                }
            }
            if(item.timePoints){
                tempNode.batchChangeSetPart.A_ServiceOrderItem.A_ServiceOrderItemType[0].children().add(new NodeBuilder().RequestedServiceStartDateTime(Date.parse("yyyy-MM-dd'T'HH:mm:ss", item.timePoints.requestedStartOn).format('yyyy-MM-dd HH:mm:ss', TimeZone.getTimeZone('UTC'))))
                tempNode.batchChangeSetPart.A_ServiceOrderItem.A_ServiceOrderItemType[0].children().add(new NodeBuilder().RequestedServiceEndDateTime(
                    Date.parse("yyyy-MM-dd'T'HH:mm:ss", item.timePoints.requestedEndOn).format('yyyy-MM-dd HH:mm:ss', TimeZone.getTimeZone('UTC'))))
            }
            if(item.quantity){
                tempNode.batchChangeSetPart.A_ServiceOrderItem.A_ServiceOrderItemType[0].children().add(new NodeBuilder().Quantity(item.quantity.content))
                tempNode.batchChangeSetPart.A_ServiceOrderItem.A_ServiceOrderItemType[0].children().add(new NodeBuilder().QuantityUnit(item.quantity.uomCode))
            }
            if(item.serviceDuration){
                tempNode.batchChangeSetPart.A_ServiceOrderItem.A_ServiceOrderItemType[0].children().add(new NodeBuilder().ServiceDuration(item.serviceDuration.content))
                tempNode.batchChangeSetPart.A_ServiceOrderItem.A_ServiceOrderItemType[0].children().add(new NodeBuilder().ServiceDurationUnit(item.serviceDuration.uomCode))
            }
            if(item.product){
                tempNode.batchChangeSetPart.A_ServiceOrderItem.A_ServiceOrderItemType[0].children().add(new NodeBuilder().Product(item.product.receiverDisplayId))
            }
            if(item.registeredProduct){
                tempNode.append(new NodeBuilder().to_ReferenceObject{A_ServiceOrderItemRefObjectType{
                    ServiceReferenceEquipment(item.registeredProduct.receiverDisplayId)
                    SrvcRefObjIsMainObject("X")
                }})
            }
            batch_payload.append(tempNode)
            batchNodeCount+=1
            itemCreateNodes.add(batchNodeCount)
        }else{
            //update of item
            itemsMap[itemMapS4[id]] = id
            def serviceOrderItemId = itemMapS4[id]? itemMapS4[id] : item.receiverId
            tempNode = new NodeBuilder().batchChangeSet{
                batchChangeSetPart{
                    method('PATCH')
                    uri("A_ServiceOrderItem(ServiceOrder='" + serviceOrderId + "',ServiceOrderItem='" + serviceOrderItemId + "')")
                    A_ServiceOrderItem{
                        A_ServiceOrderItemType{
                            ServiceOrder(serviceOrderId)
                            ServiceOrderItem(serviceOrderItemId)
                            ServiceOrderItemDescription(item.description)
                            ServiceOrderItemCategory(item.itemCategory)
                            ReferenceServiceOrderItem(item.lineNumber)
                            ParentServiceOrderItem(parentS4LineNumber)
                        }
                    }
                }
            }
            if(item.quantity){
                tempNode.batchChangeSetPart.A_ServiceOrderItem.A_ServiceOrderItemType[0].children().add(new NodeBuilder().Quantity(item.quantity.content))
                tempNode.batchChangeSetPart.A_ServiceOrderItem.A_ServiceOrderItemType[0].children().add(new NodeBuilder().QuantityUnit(item.quantity.uomCode))
            }
            if(item.serviceDuration){
                tempNode.batchChangeSetPart.A_ServiceOrderItem.A_ServiceOrderItemType[0].children().add(new NodeBuilder().ServiceDuration(item.serviceDuration.content))
                tempNode.batchChangeSetPart.A_ServiceOrderItem.A_ServiceOrderItemType[0].children().add(new NodeBuilder().ServiceDurationUnit(item.serviceDuration.uomCode))
            }
            if(item.product){
                tempNode.batchChangeSetPart.A_ServiceOrderItem.A_ServiceOrderItemType[0].children().add(new NodeBuilder().Product(item.product.receiverDisplayId))
            }
            if(item.registeredProduct){
                tempNode.append(new NodeBuilder().to_ReferenceObject{A_ServiceOrderItemRefObjectType{
                    ServiceReferenceEquipment(item.registeredProduct.receiverDisplayId)
                    SrvcRefObjIsMainObject("X")
                }})
            }
            batch_payload.append(tempNode)
            batchNodeCount+=1
            //update of item's timePoints
            if(item.timePoints){
                if(item.timePoints.requestedEndOn){
                tempNode = new NodeBuilder().batchChangeSet{
                    batchChangeSetPart{
                        method("PATCH")
                        uri("A_SrvcOrdItemAppointment(ServiceOrder='" + serviceOrderId + "',ServiceOrderItem='" + serviceOrderItemId + "',SrvcDocAppointmentType='SRV_CUST_END')")
                        A_SrvcOrdItemAppointment{
                            A_SrvcOrdItemAppointmentType{
                                ServiceOrder(serviceOrderId)
                                ServiceOrderItem(serviceOrderItemId)
                                SrvcDocAppointmentType("SRV_CUST_END")
                                SrvcDocApptStartDateTime(Date.parse("yyyy-MM-dd'T'HH:mm:ss", item.timePoints.requestedEndOn).format('yyyy-MM-dd HH:mm:ss', TimeZone.getTimeZone('UTC')))
                                SrvcDocApptEndDateTime()
                            }
                        }
                    }
                }
                batch_payload.append(tempNode)
                batchNodeCount+=1
                }
                if(item.timePoints.requestedStartOn){
                tempNode = new NodeBuilder().batchChangeSet{
                    batchChangeSetPart{
                        method("PATCH")
                        uri("A_SrvcOrdItemAppointment(ServiceOrder='" + serviceOrderId + "',ServiceOrderItem='" +  serviceOrderItemId + "',SrvcDocAppointmentType='SRV_CUST_BEG')")
                        A_SrvcOrdItemAppointment{
                            A_SrvcOrdItemAppointmentType{
                                ServiceOrder(serviceOrderId)
                                ServiceOrderItem( serviceOrderItemId)
                                SrvcDocAppointmentType("SRV_CUST_BEG")
                                SrvcDocApptStartDateTime(Date.parse("yyyy-MM-dd'T'HH:mm:ss", item.timePoints.requestedStartOn).format('yyyy-MM-dd HH:mm:ss', TimeZone.getTimeZone('UTC')))
                                SrvcDocApptEndDateTime()
                            }
                        }
                    }
                }
                batch_payload.append(tempNode)
                batchNodeCount+=1
                }
            }
        }
    }
    
    for(id in itemMapS4.keySet()){
        if(!itemMapC4C.keySet().contains(id)){
            tempNode = new NodeBuilder().batchChangeSet{
                batchChangeSetPart{
                    method('DELETE')
                    uri("A_ServiceOrderItem(ServiceOrder='" + serviceOrderId + "',ServiceOrderItem='" + itemMapS4[id] + "')")
                }
            }
            batch_payload.append(tempNode)
            batchNodeCount+=1
        }
    }
    
    //notes changes
    for(id in notesMapC4C.keySet()) {
        def note = notesMapC4C[id]
        if(!notesMapS4.keySet().contains(id)) {
            tempNode = new NodeBuilder().batchChangeSet{
                batchChangeSetPart{
                    method('POST')
                    uri("A_ServiceOrder('" + serviceOrderId + "')/to_Text")
                    A_ServiceOrderText{
                        A_ServiceOrderTextType{
                            ServiceOrder(serviceOrderId)
                            Language(message.getProperty('language_code'))
                            LongTextID(note.noteType)
                            LongText(note.content)
                        }
                    }
                }
            }
            batch_payload.append(tempNode)
            batchNodeCount+=1
        } else {
            tempNode = new NodeBuilder().batchChangeSet{
                batchChangeSetPart{
                    method('PATCH')
                    uri("A_ServiceOrderText(ServiceOrder='" + serviceOrderId + "',Language='" + message.getProperty('language_code') + "',LongTextID='" + note.noteType + "')")
                    A_ServiceOrderText{
                        A_ServiceOrderTextType{
                            ServiceOrder(serviceOrderId)
                            LongText(note.content)
                        }
                    }
                }
            }
            batch_payload.append(tempNode)
            batchNodeCount+=1
        }
    }
    
    //notes changes
    for(id in notesMapS4.keySet()) {
        if(!notesMapC4C.keySet().contains(id)) {
            tempNode = new NodeBuilder().batchChangeSet{
                batchChangeSetPart{
                    method('DELETE')
                    uri("A_ServiceOrderText(ServiceOrder='" + serviceOrderId + "',Language='" + message.getProperty('language_code') + "',LongTextID='" + id + "')")
                }
            }
            batch_payload.append(tempNode)
            batchNodeCount+=1
        }
    }
    
    //Removing nodes containing null value
    def xml = new XmlParser().parseText(groovy.xml.XmlUtil.serialize(batch_payload))
    def emptyNodes = xml.'**'.findAll{it.name() && it.text()=='null'}
    def removeNode = {
        node ->
        def parent = node.parent()
        parent.remove(node)
    }
    emptyNodes.each{removeNode(it)}
    
    //Saving the final xml
    String outxml = groovy.xml.XmlUtil.serialize(xml)
    message.setProperty("items",itemsMap)
    message.setProperty("itemCreateNodes",itemCreateNodes)
     message.setProperty("mappedS4Body",outxml)
    message.setBody(outxml)
    return message
}