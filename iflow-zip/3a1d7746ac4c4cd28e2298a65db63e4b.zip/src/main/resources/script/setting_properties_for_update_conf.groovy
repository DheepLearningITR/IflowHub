import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.transform.Field

@Field List<String> messages = [];
@Field List errorList = [];

def detailMessage(String s4_severity, String s4_description){
    JsonBuilder messageBuilder = new JsonBuilder()
    if(!messages.contains(s4_description) && s4_severity.toUpperCase() != "SUCCESS"){
        messages.add(s4_description)
        messageBuilder = new JsonBuilder()
        messageBuilder{
            severity s4_severity.toUpperCase()
            description s4_description
        }
        errorList.add(messageBuilder)
    }
}

def Message processData(Message message){
    def body = new XmlParser().parseText(message.getBody(String.class))
    def batchNodes =  body.'**'.findAll { it.name() == 'batchChangeSetPartResponse' }
    def itemCreateNodes = message.getProperty("itemCreateNodes")
    def items = message.getProperty("items")
    def itemNode
    
    itemCreateNodes.each{
        int itemBatchnumber = it-1
        if(batchNodes[itemBatchnumber].statusCode.text().startsWith("2")){
            itemNode = batchNodes[itemBatchnumber].body
            items[itemNode.ServiceOrderItem.text()] = itemNode.ReferenceServiceOrderItem.text()
        }
    }
    message.setProperty("items", items)
    
    def statusCode
    def details
    batchNodes.each{
        statusCode = it.statusCode.text()
        if(statusCode.startsWith("4")){
            details = new XmlParser().parseText(it.body.text())
           detailMessage("error",details.message.text())
            details.innererror.errordetails.errordetail.each{
                detailMessage(it.severity.text(),it.message.text())
            }
        }
        else if(statusCode.equals("204")) {
            if(it.headers.'sap-message'){
                details =new XmlParser().parseText(it.headers.'sap-message'.text())
                detailMessage(details.severity.text(),details.message.text())
                details.details.detail.each{
                    detailMessage(it.severity.text(),it.message.text())
                }
            }
        }
    }
    message.setProperty("errorList", errorList)
    return message
}