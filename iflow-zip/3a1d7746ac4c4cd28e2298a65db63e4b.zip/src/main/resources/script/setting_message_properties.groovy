import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message){
    def root = new JsonSlurper().parse(message.getBody(java.io.Reader))
    boolean externalIdPresent
    boolean isCreate
    def externalId
    def sapClient = message.getProperty('SAP client')
    
    externalId = root.messageHeader.senderCommunicationSystemDisplayId + "%23" + root.messageRequests[0].body.displayId
    
    message.setHeader("SAP_ApplicationID", root.messageHeader.id)
    
    message.setProperty("Conf_Sender", root.messageHeader.senderCommunicationSystemDisplayId)
    message.setProperty("Conf_Receiver", root.messageHeader.receiverCommunicationSystemDisplayId)
    message.setProperty("ServiceOrderId", root.messageRequests[0].body.id)
    message.setProperty("ServiceOrderDisplayId", root.messageRequests[0].body.displayId)
    message.setProperty("externalId", externalId)
    message.setProperty("Payload_In", message.getBody(java.io.Reader))
    
    if(root.messageRequests[0].body.receiverDisplayId){//externalId.hasProperty("id")
        externalIdPresent = true
        isCreate=false
        message.setProperty("serviceOrderExternalId",root.messageRequests[0].body.receiverDisplayId)
    }else{
        externalIdPresent = false
        isCreate=true
        message.setProperty("custom_query", "\$" + "filter=ReferenceServiceOrder eq '$externalId' & sap-client=$sapClient")
    }
    
    message.setProperty("externalIdPresent", externalIdPresent)
    message.setProperty("isCreate",isCreate)
    
    return message;
}