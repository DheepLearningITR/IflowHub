import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder

def Message processData(Message message){
    def body = new XmlParser().parseText(message.getBody(String.class))
    String errorHeader = message.getHeaders().get('sap-message').toString()
    if(errorHeader != null && errorHeader != '' && errorHeader !=  'null'){
        def errorList = []
        def parsedHeader = new XmlParser().parseText(errorHeader)
        JsonBuilder messageBuilder = new JsonBuilder()
        def s4_description = parsedHeader.message.text()
        def s4_severity = "error"
        messageBuilder = new JsonBuilder()
        messageBuilder{
            severity s4_severity.toUpperCase()
            description s4_description
        }
        errorList.add(messageBuilder)
        
        parsedHeader.details.detail.each{
            s4_description = it.message.text()
            s4_severity = it.severity.text()
            
            messageBuilder = new JsonBuilder()
            messageBuilder{
                severity s4_severity.toUpperCase()
                description s4_description
            }
            if(s4_severity.toUpperCase() != "SUCCESS"){
                errorList.add(messageBuilder)
            }
        }
        message.setProperty("errorList", errorList)
    }
    
    def serviceOrderId = body.A_ServiceOrderType.ServiceOrder.text()
    def itemsNode = body.A_ServiceOrderType.to_Item
    def items = [:]
    
    itemsNode.A_ServiceOrderItemType.each{
         items[it.ServiceOrderItem.text()] = it.ReferenceServiceOrderItem.text()
    }
    
    message.setProperty("serviceOrderExternalId", serviceOrderId)
    message.setProperty("items", items)
    return message
}