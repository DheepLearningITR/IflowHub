import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message){
    def serviceOrderId = message.getProperty("serviceOrderExternalId")
    def items = message.getProperty("items")
    def outputNode = new NodeBuilder().batchParts{}
    def tempNode
    
    //batch get definition for header 
    tempNode = new NodeBuilder().batchQueryPart{
        uri('A_ServiceOrder?$filter=ServiceOrder%20eq%20' + "'" + serviceOrderId + "'")
    }
    outputNode.append(tempNode)
    
    //batch get definition for timePoints 
    tempNode = new NodeBuilder().batchQueryPart{
        uri("A_ServiceOrder('" + serviceOrderId + "')/to_Appointment")
    }
    outputNode.append(tempNode)
    
    //batch get definition for userStatus
    tempNode = new NodeBuilder().batchQueryPart{
        uri("A_ServiceOrder('" + serviceOrderId + "')/to_ServiceOrdUserStatus")
    }
    outputNode.append(tempNode)
    
    //batch get definition for items
    for(item in items.keySet()){
        tempNode = new NodeBuilder().batchQueryPart{
            uri("A_ServiceOrderItem(ServiceOrder='" + serviceOrderId + "',ServiceOrderItem='" + item + "')")
        }
        outputNode.append(tempNode)
        tempNode = new NodeBuilder().batchQueryPart{
            uri("A_ServiceOrderItem(ServiceOrder='" + serviceOrderId + "',ServiceOrderItem='" +  item + "')/to_SrvcOrdItemUserStatus")
        }
        outputNode.append(tempNode)
        tempNode = new NodeBuilder().batchQueryPart{
            uri("A_ServiceOrderItem(ServiceOrder='" + serviceOrderId + "',ServiceOrderItem='" +  item + "')/to_Appointment")
        }
        outputNode.append(tempNode)
     }
    
    String outxml = groovy.xml.XmlUtil.serialize(outputNode)
    message.setProperty("SAP_BatchLineSeparator","CRLF")
    message.setBody(outxml)
    return message
}