import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message){
    def serviceOrderId = message.getProperty("serviceOrderExternalId")
    def outputNode = new NodeBuilder().batchParts{}
    def tempNode
    
    tempNode = new NodeBuilder().batchQueryPart{
        uri("A_ServiceOrder('" + serviceOrderId + "')/to_ReferenceObject")
    }
    outputNode.append(tempNode)
    
    tempNode = new NodeBuilder().batchQueryPart{
        uri("A_ServiceOrder('" + serviceOrderId + "')/to_Item")
    }
    outputNode.append(tempNode)
    
    //Get notes for service order
    tempNode = new NodeBuilder().batchQueryPart{
        uri("A_ServiceOrder('" + serviceOrderId + "')/to_Text")
    }
    outputNode.append(tempNode)
    
    String outXml = groovy.xml.XmlUtil.serialize(outputNode)
    message.setBody(outXml)
    message.setProperty("SAP_BatchLineSeparator","CRLF")
    return message
}