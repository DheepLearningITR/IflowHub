import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message){
    def root = new XmlSlurper().parse(message.getBody(java.io.Reader.class))
    def isCreate = true
    
    if(root.breadthFirst().any { it.name() == "A_ServiceOrderType" }){
        isCreate = false
    }
    
    message.setProperty("isCreate", isCreate)
    
    return message
}