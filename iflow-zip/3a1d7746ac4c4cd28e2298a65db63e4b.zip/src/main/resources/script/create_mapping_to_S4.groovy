import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message){
    //Getting data and parsing it
    def payloadIn = message.getProperty("Payload_In")
    def root = new JsonSlurper().parse(payloadIn)
    def body = root.messageRequests[0].body
    def sender = message.getProperty("Conf_Sender")
    
    def referenceServiceOrder = sender + "#" + body.displayId
    def isMain
    
    
    //Creating header xml node
    Node output_node = new NodeBuilder().A_ServiceOrder{
        A_ServiceOrderType{
            ServiceOrder()
            ServiceOrderType(body.serviceOrderType)
            ServiceOrderDescription(body.description)
            ReferenceServiceOrder(referenceServiceOrder)
            TransactionCurrency(message.getProperty("currency"))
        }
    }
    
    def tempNode = output_node.'**'.find{it.name() == 'A_ServiceOrderType'}
    
    //Adding priority node
    if(body.priority){
        tempNode.append(new NodeBuilder().ServiceDocumentPriority(body.priority))
    }
    
    //Adding totalValues nodes 
    
    if(body.totalValues){
        tempNode.append(new NodeBuilder().ServiceDocGrossAmount(body.totalValues.grossAmount.content))
        tempNode.append(new NodeBuilder().ServiceDocTaxAmount(body.totalValues.taxAmount.content))
        tempNode.append(new NodeBuilder().ServiceDocNetAmount(body.totalValues.netAmount.content))
    }
    
    final String useEnterpriseOrg = message.getProperty("useEnterpriseOrg")?.toLowerCase()
    //Adding business area related nodes
    if(body.businessArea){
        tempNode.append(new NodeBuilder().DistributionChannel(body.businessArea.distributionChannel))
        tempNode.append(new NodeBuilder().Division(body.businessArea.division))
        if("true".equals(useEnterpriseOrg)){
            //Use Enterprise Organizational Model
            tempNode.append(new NodeBuilder().SalesOrganization(body.businessArea.receiverSalesOrganisationId))
            tempNode.append(new NodeBuilder().SalesOffice(body.businessArea.receiverSalesOfficeId))
            tempNode.append(new NodeBuilder().SalesGroup(body.businessArea.receiverSalesGroupId))
        } else{
            tempNode.append(new NodeBuilder().SalesOrganizationOrgUnitID(body.businessArea.receiverSalesOrganisationCenterId))
            tempNode.append(new NodeBuilder().SalesOfficeOrgUnitID(body.businessArea.receiverSalesOfficeOrganisationCenterId))
            tempNode.append(new NodeBuilder().SalesGroupOrgUnitID(body.businessArea.receiverSalesGroupOrganisationCenterId))
        }
    }
    
    //Adding involved parties
    if(body.account){
        tempNode.append(new NodeBuilder().SoldToParty(body.account.receiverDisplayId))
    }
    if(body.contact){
        tempNode.append(new NodeBuilder().ContactPerson(body.contact.receiverDisplayId))
    }
    if(body.individualCustomer){
        tempNode.append(new NodeBuilder().SoldToParty(body.individualCustomer.receiverDisplayId))
    }
    if(body.shipToAccount){
        tempNode.append(new NodeBuilder().ShipToParty(body.shipToAccount.receiverDisplayId))
    }
    if(body.billToAccount){
        tempNode.append(new NodeBuilder().BillToParty(body.billToAccount.receiverDisplayId))
    }
    if(body.billToIndividualCustomer){
        tempNode.append(new NodeBuilder().BillToParty(body.billToIndividualCustomer.receiverDisplayId))
    }
    if(body.shipToIndividualCustomer){
        tempNode.append(new NodeBuilder().ShipToParty(body.shipToIndividualCustomer.receiverDisplayId))
    }
    if(body.payerAccount){
        tempNode.append(new NodeBuilder().PayerParty(body.payerAccount.receiverDisplayId))
    }
    if(body.payerIndividualCustomer){
        tempNode.append(new NodeBuilder().PayerParty(body.payerIndividualCustomer.receiverDisplayId))
    }
    if(body.serviceOrganisation){
        if("true".equals(useEnterpriseOrg)){
            tempNode.append(new NodeBuilder().EnterpriseServiceOrganization(body.serviceOrganisation.receiverDisplayId))
        } else {
            tempNode.append(new NodeBuilder().ServiceOrganization(body.serviceOrganisation.receiverDisplayId))
        }
    }
    
    def partnerNode = new NodeBuilder().to_Partner{}
    if(body.owner){
        partnerNode.append(new NodeBuilder().A_SrvcOrdPartnerType{
            ServiceOrder()
            CustMgmtPartnerFunction("00000014")
            CustMgmtBusinessPartner(body.owner.receiverDisplayId)
            CustMgmtPartnerIsMainPartner(true)
        })
    }
    
    if(body.serviceTechnician){
        partnerNode.append(new NodeBuilder().A_SrvcOrdPartnerType{
            ServiceOrder()
            CustMgmtPartnerFunction("00000052")
            CustMgmtBusinessPartner(body.serviceTechnician.receiverDisplayId)
            CustMgmtPartnerIsMainPartner(true)
        })
    }
    output_node.find { it.name() == 'A_ServiceOrderType' }.children().add( 0, partnerNode )
    
    //Adding timePoints subnode
    if(body.timePoints){
        def timePointsNode = new NodeBuilder().to_Appointment{}
        //Adding requested start on
        if(body.timePoints.requestedStartOn){
            timePointsNode.append(new NodeBuilder().A_SrvcOrdAppointmentType{
                ServiceOrder()
                SrvcDocAppointmentType("SRV_CUST_BEG")
                SrvcDocApptStartDateTime(body.timePoints.requestedStartOn)
            })
        }
        //Adding requested end on
        if(body.timePoints.requestedEndOn){
            timePointsNode.append(new NodeBuilder().A_SrvcOrdAppointmentType{
                ServiceOrder()
                SrvcDocAppointmentType("SRV_CUST_END")
                SrvcDocApptStartDateTime(body.timePoints.requestedEndOn)
            })
        }
        output_node.find { it.name() == 'A_ServiceOrderType' }.children().add( 0, timePointsNode )
    }
    
    //Adding registered products subnode
    if(body.registeredProducts){
        def referenceProductNode = new NodeBuilder().to_ReferenceObject{
            for(registeredProduct in body.registeredProducts){
                if(registeredProduct.isMain){
                    isMain= "X"
                }else{
                    isMain = null
                }
                A_ServiceOrderRefObjectType{
                    ServiceOrder()
                    ServiceReferenceEquipment(registeredProduct.receiverDisplayId)
                    SrvcRefObjIsMainObject(isMain)
                }
            }
        }
        output_node.find { it.name() == 'A_ServiceOrderType' }.children().add( 0, referenceProductNode )
    }
    
    //Adding items subnode
    if(body.items){
        def itemsNode = new NodeBuilder().to_Item{}
            for(item in body.items){
                def itemNode = new NodeBuilder().A_ServiceOrderItemType{
                    ServiceOrder()
                    ServiceOrderItem()
                    ServiceOrderItemDescription(item.description)
                    ServiceOrderItemCategory(item.itemCategory)
                    ReferenceServiceOrderItem(item.lineNumber)
                }
                def tempItemNode = itemNode.'**'.find{it.name() == 'A_ServiceOrderItemType'}
                if(item.timePoints){
                    tempItemNode.append(new NodeBuilder().RequestedServiceStartDateTime(Date.parse("yyyy-MM-dd'T'HH:mm:ss", item.timePoints.requestedStartOn).format('yyyy-MM-dd HH:mm:ss', TimeZone.getTimeZone('UTC'))))
                    tempItemNode.append(new NodeBuilder().RequestedServiceEndDateTime(Date.parse("yyyy-MM-dd'T'HH:mm:ss", item.timePoints.requestedEndOn).format('yyyy-MM-dd HH:mm:ss', TimeZone.getTimeZone('UTC'))))
                }
                if(item.quantity){
                    tempItemNode.append(new NodeBuilder().Quantity(item.quantity.content))
                    tempItemNode.append(new NodeBuilder().QuantityUnit(item.quantity.uomCode))
                }
                if(item.serviceDuration){
                    tempItemNode.append(new NodeBuilder().ServiceDuration(item.serviceDuration.content))
                    tempItemNode.append(new NodeBuilder().ServiceDurationUnit(item.serviceDuration.uomCode))
                }
                if(item.product){
                    tempItemNode.append(new NodeBuilder().Product(item.product.receiverDisplayId))
                }
                if(item.registeredProduct){
                    tempItemNode.append(new NodeBuilder().to_ReferenceObject{
                        A_ServiceOrderItemRefObjectType{
                            ServiceOrder()
                            ServiceOrderItem()
                            ServiceReferenceEquipment(item.registeredProduct.receiverDisplayId)
                            SrvcRefObjIsMainObject("X")
                        }
                    })
                }
                itemsNode.append(itemNode)
            }
        output_node.find { it.name() == 'A_ServiceOrderType' }.children().add( 0, itemsNode )
    }
    
    //Adding Notes
    if(body.notes){
        def notesNode = new NodeBuilder().to_Text{}
            for(note in body.notes){
                def noteNode = new NodeBuilder().A_ServiceOrderTextType{
                    ServiceOrder()
                }
                def tempNotesNode = noteNode.'**'.find{it.name() == 'A_ServiceOrderTextType'}
                if(note.content){
                    tempNotesNode.append(new NodeBuilder().LongText(note.content))
                    tempNotesNode.append(new NodeBuilder().LongTextID(note.noteType))
                    tempNotesNode.append(new NodeBuilder().Language(message.getProperty('language_code')))
                }
                notesNode.append(tempNotesNode)
            }
        output_node.find { it.name() == 'A_ServiceOrderType' }.children().add(0, notesNode )
    }

    
    //Removing nodes containing null value
    def xml = new XmlParser().parseText(groovy.xml.XmlUtil.serialize(output_node))
    def emptyNodes = xml.'**'.findAll{it.name() && it.text()=='null'}
    def removeNode = {
        node ->
        def parent = node.parent()
        parent.remove(node)
    }
    emptyNodes.each{removeNode(it)}
    
    //Saving the final xml
    String outxml = groovy.xml.XmlUtil.serialize(xml)
    message.setProperty("mappedS4Body",outxml)
    message.setBody(outxml)
    return message
}