import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def String getTimePointsData(groovy.util.NodeList timePointsResponse){
    //TimePoints node for confirmation
    def timePointNodeBuilder =  new JsonBuilder()
    timePointNodeBuilder{
        timePoints{
        }
    }
    for(timePoint in timePointsResponse){
        if(timePoint.SrvcDocAppointmentType.text() == 'SPLA_PLANFR'){
            def date = timePoint.SrvcDocApptStartDateTime.text()+"Z"
            def tempBuilder = new JsonBuilder()
            tempBuilder{
                timePoints{
                    plannedFrom date
                }
            }
            timePointNodeBuilder.getContent().timePoints = timePointNodeBuilder.getContent().timePoints << tempBuilder.getContent().timePoints
        }
        if(timePoint.SrvcDocAppointmentType.text() == 'SRV_CUST_BEG'){
            def tempBuilder = new JsonBuilder()
            def date = timePoint.SrvcDocApptStartDateTime.text()+"Z"
            tempBuilder{
                timePoints{
                    requestedStartOn date
                }
            }
            timePointNodeBuilder.getContent().timePoints = timePointNodeBuilder.getContent().timePoints << tempBuilder.getContent().timePoints
        }
        if(timePoint.SrvcDocAppointmentType.text() == 'SRV_CUST_END'){
            def date = timePoint.SrvcDocApptStartDateTime.text()+"Z"
            def tempBuilder = new JsonBuilder()
            tempBuilder{
                timePoints{
                    requestedEndOn date
                }
            }
            timePointNodeBuilder.getContent().timePoints = timePointNodeBuilder.getContent().timePoints << tempBuilder.getContent().timePoints
        }
        if(timePoint.SrvcDocAppointmentType.text() == 'SPLA_PLANTO'){
            def tempBuilder = new JsonBuilder()
            def date = timePoint.SrvcDocApptStartDateTime.text()+"Z"
            tempBuilder{
                timePoints{
                    plannedTo  date
                }
            }
            timePointNodeBuilder.getContent().timePoints = timePointNodeBuilder.getContent().timePoints << tempBuilder.getContent().timePoints
        }
        if(timePoint.SrvcDocAppointmentType.text() == 'BILL_DATE'){
            def tempBuilder = new JsonBuilder()
            def date = timePoint.SrvcDocApptStartDateTime.text()+"Z"
            tempBuilder{
                timePoints{
                    billingOn  date
                }
            }
            timePointNodeBuilder.getContent().timePoints = timePointNodeBuilder.getContent().timePoints << tempBuilder.getContent().timePoints
        }
        if(timePoint.SrvcDocAppointmentType.text() == 'INVCR_DATE'){
            def tempBuilder = new JsonBuilder()
            def date = timePoint.SrvcDocApptStartDateTime.text()+"Z"
            tempBuilder{
                timePoints{
                    billingDocumentCreatedOn  date
                }
            }
            timePointNodeBuilder.getContent().timePoints = timePointNodeBuilder.getContent().timePoints << tempBuilder.getContent().timePoints
        }
        if(timePoint.SrvcDocAppointmentType.text() == 'SRV_INST'){
            def tempBuilder = new JsonBuilder()
            def date = timePoint.SrvcDocApptStartDateTime.text()+"Z"
            tempBuilder{
                timePoints{
                    installedOn  date
                }
            }
            timePointNodeBuilder.getContent().timePoints = timePointNodeBuilder.getContent().timePoints << tempBuilder.getContent().timePoints
        }
        if(timePoint.SrvcDocAppointmentType.text() == 'SRV_START'){
            def tempBuilder = new JsonBuilder()
            def date = timePoint.SrvcDocApptStartDateTime.text()+"Z"
            tempBuilder{
                timePoints{
                    receiptNotificationOn  date
                }
            }
            timePointNodeBuilder.getContent().timePoints = timePointNodeBuilder.getContent().timePoints << tempBuilder.getContent().timePoints
        }
    }
    return timePointNodeBuilder.toString()
}

def recursivelyRemoveEmpties(item) {
  switch(item) {
    case Map:
      return item.collectEntries { k, v ->
        [k, recursivelyRemoveEmpties(v)]
      }.findAll { k, v -> v }

    case List:
      return item.collect { 
        recursivelyRemoveEmpties(it) 
      }.findAll { v -> v }

    default: 
      return item
  }
}

def Message processData(Message message){
    def root = new XmlParser().parse(message.getBody(java.io.Reader.class))
    
    //Header confirmation builder 
    def headerResponse = root.batchQueryPartResponse[0].body.A_ServiceOrder
    String timePointsResponse = getTimePointsData(root.batchQueryPartResponse[1].body.A_SrvcOrdAppointment.A_SrvcOrdAppointmentType)
    def userStatusResponse = root.batchQueryPartResponse[2].body.A_ServiceOrdUserStatus
    def date = new Date()
    JsonBuilder builder = new JsonBuilder()
    def timePointsJson = new JsonSlurper().parseText(timePointsResponse).timePoints
    
    builder{
        messageHeader{
            id java.util.UUID.randomUUID()
            senderCommunicationSystemDisplayId message.getProperty("Conf_Receiver")
            receiverCommunicationSystemDisplayId message.getProperty("Conf_Sender")
            creationDateTime date.format("yyyy-MM-dd'T'HH:mm:ss'Z'")
        } 
        messageRequests ([{
            messageHeader{
                messageEntityName "sap.crm.serviceorderservice.entity.serviceOrderConfirmationMessageIn"
                actionCode "CONFIRM"
                id java.util.UUID.randomUUID()
            }
            body{
                isMainExternalIntegration true
                receiverId message.getProperty("ServiceOrderId")
                receiverDisplayId message.getProperty("ServiceOrderDisplayId")
                id headerResponse.A_ServiceOrderType.ServiceOrderUUID.text()
                displayId headerResponse.A_ServiceOrderType.ServiceOrder.text()
                userStatus userStatusResponse.A_ServiceOrdUserStatusType.SrvcOrdUserStatus.text()
                timePoints timePointsJson
                items([])
                messages([])
            }
        }])
    }
    
    def json = new JsonSlurper().parseText(builder.toString())
    if(headerResponse.A_ServiceOrderType.ServiceOrderIsCompleted.text() == "X" || headerResponse.A_ServiceOrderType.ServiceOrderIsRejected.text() == "X"){
        def lifeCycleBuilder = new JsonBuilder()
        lifeCycleBuilder{
            lifecycleStatus "COMPLETED"
        }
        json.messageRequests[0].body << new JsonSlurper().parseText(lifeCycleBuilder.toString())
    }
    
    
    Map<String,String> items_property = message.getProperty("items")
    def count = 3
    def itemResponse 
    String itemTimePointsResponse
    def itemUserStatusResponse
    JsonBuilder itemBuilder = new JsonBuilder()
    for(item in items_property){
        itemResponse = root.batchQueryPartResponse[count].body.A_ServiceOrderItem
        count +=1 
        itemUserStatusResponse = root.batchQueryPartResponse[count].body.A_ServiceOrdItemUserStatus
        count +=1
        itemTimePointsResponse = getTimePointsData(root.batchQueryPartResponse[count].body.A_SrvcOrdItemAppointment.A_SrvcOrdItemAppointmentType)
        timePointsJson = new JsonSlurper().parseText(itemTimePointsResponse).timePoints
        count+=1
        def itemReceiverId = itemResponse.A_ServiceOrderItemType.ReferenceServiceOrderItem.text()? itemResponse.A_ServiceOrderItemType.ReferenceServiceOrderItem.text().toInteger() : null
        itemBuilder {
            id itemResponse.A_ServiceOrderItemType.ServiceOrderItem.text()
            receiverLineNumber itemReceiverId
            userStatus itemUserStatusResponse.A_ServiceOrdItemUserStatusType.SrvcOrdItemUserStatus.text()
            timePoints timePointsJson
        }
        json.messageRequests[0].body.items << new JsonSlurper().parseText(itemBuilder.toString())
    }
    
    def errorList = message.getProperty("errorList")
    errorList.each{
        json.messageRequests[0].body.messages << new JsonSlurper().parseText(it.toString())
    }
    
    json = recursivelyRemoveEmpties(json)
    def outPayload = JsonOutput.prettyPrint(JsonOutput.toJson(json))
    message.setHeader("isConfirmationMessage",true)
    message.setHeader("referenceMessageRequestId",message.getProperty("SAP_ApplicationID"))
    message.setBody(outPayload)
    return message
}