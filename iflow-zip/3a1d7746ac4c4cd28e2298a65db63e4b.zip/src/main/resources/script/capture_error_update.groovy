import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*
import groovy.xml.*

def Message processData(Message message){
    def date = new Date()
    JsonBuilder builder = new JsonBuilder()
    builder{
        messageHeader{
            id java.util.UUID.randomUUID()
            senderCommunicationSystemDisplayId message.getProperty("Conf_Receiver")
            receiverCommunicationSystemDisplayId message.getProperty("Conf_Sender")
            creationDateTime date.format("yyyy-MM-dd'T'HH:mm:ss'Z'")
        } 
        messageRequests ([{
            messageHeader{
                messageEntityName "sap.crm.serviceorderservice.entity.serviceOrderConfirmationMessageIn"
                actionCode "CONFIRM"
                id java.util.UUID.randomUUID()
            }
            body{
                receiverId message.getProperty("ServiceOrderId")
                receiverDisplayId message.getProperty("ServiceOrderDisplayId")
                messages([])
            }
        }])
    }
        
    def json = new JsonSlurper().parseText(builder.toString())
    JsonBuilder messageBuilder = new JsonBuilder()
    String s4_severity
    String s4_description
        
    String exception = message.getProperty("CamelExceptionCaught").toString();
    if(exception!=null){
        messageBuilder{
            severity "error"
            description exception.split(":")[3]
        }
        json.messageRequests[0].body.messages << new JsonSlurper().parseText(messageBuilder.toString())
    }
    
    def outPayload = JsonOutput.prettyPrint(JsonOutput.toJson(json))
    message.setHeader("isConfirmationMessage","true")
    message.setHeader("referenceMessageRequestId",message.getProperty("SAP_ApplicationID"))
    message.setBody(outPayload)
    return message
}