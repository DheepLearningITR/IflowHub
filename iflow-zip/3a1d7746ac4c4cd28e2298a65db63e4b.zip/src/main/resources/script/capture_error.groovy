import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonOutput

def Message processData(Message message){
    def date = new Date()
    JsonBuilder builder = new JsonBuilder()
    builder{
        messageHeader{
            id java.util.UUID.randomUUID()
            senderCommunicationSystemDisplayId message.getProperty("Conf_Receiver")
            receiverCommunicationSystemDisplayId message.getProperty("Conf_Sender")
            creationDateTime date.format("yyyy-MM-dd'T'HH:mm:ss'Z'")
        } 
        messageRequests ([{
            messageHeader{
                messageEntityName "sap.crm.serviceorderservice.entity.serviceOrderConfirmationMessageIn"
                actionCode "CONFIRM"
                id java.util.UUID.randomUUID()
            }
            body{
                receiverId message.getProperty("ServiceOrderId")
                receiverDisplayId message.getProperty("ServiceOrderDisplayId")
                messages([])
            }
        }])
    }
        
    def json = new JsonSlurper().parseText(builder.toString())
    JsonBuilder messageBuilder = new JsonBuilder()
    String s4_severity
    String s4_description
        
    String exception = message.getProperty("CamelExceptionCaught").toString();
    
    if(exception!=null){
        messageBuilder{
            severity "ERROR"
            description exception
        }
        json.messageRequests[0].body.messages << new JsonSlurper().parseText(messageBuilder.toString())
        // def errorBody = message.getBody(String.class)
        // if(errorBody){
           def body = new XmlParser().parse(message.getBody(java.io.Reader.class))
            body.innererror.errordetails.errordetail.each{
                s4_severity = it.severity.text().toUpperCase()
                s4_description = it.message.text()
                if(s4_severity != "SUCCESS"){
                    if(s4_description != "MESSAGE"){
                        messageBuilder{
                            severity s4_severity
                            description s4_description
                        }
                    } 
                    json.messageRequests[0].body.messages << new JsonSlurper().parseText(messageBuilder.toString())
                }
            } 
        // }
        
    }
    else{
        def body = new XmlParser().parseText(message.getBody(String.class))
        body.innererror.errordetails.errordetail.each{
            s4_severity = it.severity.toUpperCase()
            s4_description = it.messageDetail
            messageBuilder{
                severity s4_severity
                description s4_description
            }
            json.messageRequests[0].body.messages << new JsonSlurper().parseText(messageBuilder.toString())
        }
    }
    
    def outPayload = JsonOutput.prettyPrint(JsonOutput.toJson(json))
    message.setHeader("isConfirmationMessage","true")
    message.setHeader("referenceMessageRequestId",message.getProperty("SAP_ApplicationID"))
    message.setBody(outPayload)
    return message
}