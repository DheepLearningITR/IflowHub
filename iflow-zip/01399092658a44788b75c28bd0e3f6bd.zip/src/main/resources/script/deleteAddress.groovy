import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def query = new XmlSlurper().parseText(body);
    List<String> list = new ArrayList<String>();
    
    query.IDOC.E101CRMXIF_PARTNER_COMPLEX.E101BUS_EI_CENTRAL_DATA.E101BUS_EI_ADDRESS.E101BUS_EI_BUPA_ADDRESS.each {
        if(it.TASK.text() == "D")
        {
            list.add(it.E101BUS_EI_BUPA_ADDRESS_KEY.GUID.text());
        }
    }
    
    message.setProperty("Deleted_Address_GUID", list);
    message.setProperty("Delete_Address_Count", list.size());
    return message;
}