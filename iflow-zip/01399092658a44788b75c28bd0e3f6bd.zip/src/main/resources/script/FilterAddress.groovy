import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message){
    def body = message.getBody(java.lang.String);
    def query = new XmlSlurper().parseText(body);
    
    query.IDOC.each {
        if(it.E101CRMXIF_PARTNER_COMPLEX.E101BUS_EI_CENTRAL_DATA.E101BUS_EI_ADDRESS.E101BUS_EI_BUPA_ADDRESS.text() == "")
        it.replaceNode {};
    }
    
    def valid_data = XmlUtil.serialize(query);
    message.setBody(valid_data);
    
    return message;
}
