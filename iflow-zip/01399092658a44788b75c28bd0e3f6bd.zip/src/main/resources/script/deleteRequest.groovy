import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def map = message.getProperties();
    def mssg = '[{';
    def addList = map.get("Deleted_Address_GUID");
    def i;
    
    for(i=0; i<addList.size()-1; i++) {
        mssg = """${mssg}"externalId": "${addList[i]}"}, {""";
    }
    mssg = """${mssg}"externalId": "${addList[i]}"}]""";

    message.setBody(JsonOutput.toJson(new JsonSlurper().parseText(mssg)));
    return message;
}