import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();
       //String msgBody = body;
       
       //Properties 
       map = message.getProperties();
       value = map.get("rfcName");
       mBody = map.get("rfcBody");
       
       mBody = mBody.replaceAll("RFCNAME",value);
       
       message.setBody(mBody);
       
       //map.set("rfcBodyNew", mBody);

       return message;
}