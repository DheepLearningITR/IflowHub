//package src.main.resources.script
  //  <CREATED_ON>2016-05-03</CREATED_ON> 20160503 -> internal DATS format YYYYMMDD
  def String abap_date(String source_date) {
    Date date = Date.parse( 'yyyy-MM-dd', source_date)
    String newDate = date.format( 'yyyyMMdd' )
    return newDate;
  }

//<INELIGIBLE_STATUTORY_MIN_WAGE>false</INELIGIBLE_STATUTORY_MIN_WAGE> -> internal ABAP bool expected: false -> space; true -> X
  def String abap_bool(String source_bool) {
    String result = ' ';
    if (!source_bool?.trim()) return ' ';
    
    if ('false'.equalsIgnoreCase(source_bool)) return ' ';
    if ('true'.equalsIgnoreCase(source_bool)) return 'X';
    return '';
    //throw new IllegalArgumentException(String.format('Cannot convert %s to bool', source_bool));
  }