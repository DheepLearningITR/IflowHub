import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def properties = message.getProperties();
    def odataResponse = properties.get("odata_data");
    if(messageLog != null){
        def body = message.getBody(java.lang.String) as String
        messageLog.addAttachmentAsString("Error Message", body, "text/plain");
        messageLog.addAttachmentAsString("OData Response", odataResponse, "text/plain");
    }
    return message;
}
