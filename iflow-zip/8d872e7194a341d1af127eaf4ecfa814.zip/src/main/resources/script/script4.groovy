import com.sap.gateway.ip.core.customdev.util.Message;
import java.security.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;



def Message processData(Message message) {
     // X-WSSE: UsernameToken Username="name", PasswordDigest="digest", Created="timestamp", Nonce="nonce"
    //
    //  * Username- The username that the user enters (the TypePad username).
    //  * Nonce. A secure token generated anew for each HTTP request.
    //  * Created. The ISO-8601 timestamp marking when Nonce was created.
    //  * PasswordDigest. A SHA-1 digest of the Nonce, Created timestamp, and the password
    //    that the user supplies, base64-encoded. In other words, this should be calculated
    //    as: base64(sha1(Nonce . Created . Password))

    //nonce - Generate a random 16-byte nonce in the 32-character hexadecimal format.
    byte[] nonceBytes = new byte[16];
    new Random().nextBytes(nonceBytes);
    def nonceHex = nonceBytes.encodeHex().toString();
    println nonceBytes.encodeHex().toString();

    //Timestamp - Get the current timestamp in ISO 8601 format.
   // SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
    //sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
    //def timestamp = sdf.format(new Date())
    //println timestamp

    //Secret - Get Secret from Security Artifact
    //Properties
       map = message.getProperties();
       
       timestamp = map.get("timestamp");
       
       artifactAlias = map.get("securityArtifact");
    //Get the Service Instance of the SecureStoreService API
    def service = ITApiFactory.getService(SecureStoreService.class, null);
    //Read the credential of a given alias
    def credential = service.getUserCredential(artifactAlias);
    //Read the User Name or password
    def APIUser = credential.getUsername();
    def secret = credential.getPassword();

    //Password Digest
    def passwordDigest = nonceHex + timestamp + secret;
    
    MessageDigest passwordDigestAlg = MessageDigest.getInstance("SHA-1");
    byte[] passwordDigestSHA1  = passwordDigestAlg.digest(passwordDigest.getBytes("UTF-8"));
    def passwordDigestSHA1Res = new  BigInteger(1, passwordDigestSHA1).toString(16);
    def passwordDigestsha1Base64 = passwordDigestSHA1Res.bytes.encodeBase64().toString();
    
    //passwordDigest.getBytes("UTF-8"); 
    //def passwordDigestsha1 = passwordDigest.digest("SHA-1");
    //def passwordDigestsha1Base64 = passwordDigestsha1.bytes.encodeBase64().toString();
    
    message.setProperty("passwordDigest", passwordDigestsha1Base64);  
    
    //X-WSSE Header
    def headerValue = "UsernameToken Username=\"" + APIUser + "\",PasswordDigest=\"" + passwordDigestsha1Base64 + "\",Created=\"" + timestamp + "\",Nonce=\"" + nonceHex + "\""
    //def headerValue = "UsernameToken Username=\"" + APIUser + "\",PasswordDigest=\"" + passwordDigestsha1Base64 + "\",Nonce=\"" + nonceHex + "\",Created=\"" + timestamp + "\""
    def map = message.getHeaders();
    message.setHeader("X-WSSE", headerValue);

return message
}