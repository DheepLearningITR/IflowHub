import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonSlurper;
import static java.util.Calendar.*


def Message processData(Message message) {
    
    //Get Properties  
    def map = message.getProperties();

    def surveyIdText = map.get("SurveyID");  
    def mailingListOwner = map.get("mailingListOwner");  
    
    def mailingListString = "ML_Emarsys"
    
    
    // Create message body
    def Builder = new JsonBuilder()
    
    def json = Builder {
	"name" mailingListString
	"ownerId" mailingListOwner
    }


    def outputJson = JsonOutput.toJson(json)
    message.setBody(outputJson)
    message.setHeader("Content-Type", "application/json");
    return message;

}


