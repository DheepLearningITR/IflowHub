import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import groovy.json.*;

Message processData(Message message) {
    
    // Get Message body
    def body = message.getBody(java.lang.String) as String;
    def map = message.getProperties();

    def mailinglistPayload = new JsonSlurper().parseText(body);
    def mailingListName = 'ML_Emarsys';
    def mailinglistID = '';
    def name = "";
        
    mailinglistPayload.result.elements.each{
        name = "${it.name}";
        if(name == mailingListName){
            mailinglistID = "${it.mailingListId}"
            message.setProperty("MailingListName", mailingListName);
        }
    }

    message.setProperty("MailingListID", mailinglistID);
   
	
    return message;
}