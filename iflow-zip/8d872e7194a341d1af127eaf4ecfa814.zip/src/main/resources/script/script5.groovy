import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import static java.util.Calendar.*


def Message processData(Message message) {
    
    //Get Properties  
    def map = message.getProperties();

 //   def surveyIdText = map.get("SurveyID");  
    def link = map.get("surveyLink")
    
     def email = map.get("contactEmail")
    
    // Create message body
    def Builder = new JsonBuilder()
    
    def json = Builder {
	"key_id" 3
	"external_id" email
	"trigger_id" "100003736"
	"data"(
	    surveyLink: link
	    )
    }


    def outputJson = JsonOutput.toJson(json)
    message.setBody(outputJson)
    message.setHeader("Content-Type", "application/json");
    return message;

}