import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonSlurper;
import static java.util.Calendar.*


def Message processData(Message message) {
    
    //Get Properties  
    def map = message.getProperties();

    def surveyIdText = map.get("SurveyID");  
    def mailingListIdText = map.get("MailingListID")
    
    // Get current Time
    DateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    TimeZone timeZone = TimeZone.getTimeZone("UTC"); dateFormat.setTimeZone(timeZone);
    Date date = new Date();
    def nextMonth = date[MONTH] + 1
    def oneMonthFromNow = date.copyWith(month: nextMonth)
    def formattedDate = dateFormat.format(oneMonthFromNow)

    
    // Create message body
    def Builder = new JsonBuilder()
    
    def json = Builder {
	"action" "CreateDistribution"
	"surveyId" surveyIdText
	"description" "General survey distribution"
	"expirationDate" formattedDate
	"linkType" "Individual"
	"mailingListId" mailingListIdText
    }


    def outputJson = JsonOutput.toJson(json)
    message.setBody(outputJson)
    message.setHeader("Content-Type", "application/json");
    return message;

}