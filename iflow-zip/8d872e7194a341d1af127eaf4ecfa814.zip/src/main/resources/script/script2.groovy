import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import groovy.json.*;

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

def String body = message.getBody(java.lang.String) as String;
    //create json object from string object
        json = new JsonSlurper().parseText(body);
      
        if(json && json.result){
        var contactId = json.result.id;
        message.getProperties().put("ContactID", contactId);
    }

    
    
   //message.setBody(OutboundIDValue.toString());
    return message;
}
