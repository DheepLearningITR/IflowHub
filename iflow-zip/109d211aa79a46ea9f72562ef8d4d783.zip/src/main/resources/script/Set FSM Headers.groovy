import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) {

    //Get properties 
    def map = message.getProperties();
  
    // If the IDs are coming as part of incoming request use them else use the configured IDs.
    def headers = message.getHeaders();
    def accountID = headers.get("X-Account-ID") 
    accountID = accountID ? accountID : map.get('X-Account-ID');
    def companyID = headers.get("X-Company-ID")
    companyID = companyID ? companyID : map.get('X-Company-ID');

    message.setHeader('X-Account-ID', accountID);
    message.setHeader('X-Company-ID', companyID);
        
    return message;
}
