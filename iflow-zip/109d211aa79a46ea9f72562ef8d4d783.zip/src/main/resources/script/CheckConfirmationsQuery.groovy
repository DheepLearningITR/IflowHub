import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser

def Message processData(Message message) {
//this script is to frame the service confirmations filter to A_ServiceConfirmationItem
    def body = message.getBody(java.lang.String) as String
    def parsedBody = new XmlParser().parseText(body)

    def confirmationQuery = """\$select=ServiceConfirmation,ServiceConfirmationItem,FSMServiceConfirmationItem,ReferenceServiceOrder"""

    def itemConditions = []

    parsedBody.A_ServiceConfirmationType?.to_Item?.A_ServiceConfirmationItemType?.each { item -> 
        def fsmConfirmationItemID = item?.FSMServiceConfirmationItem?.text()
        if (fsmConfirmationItemID && !fsmConfirmationItemID.contains("_TRAVELTIME")) {
            itemConditions << """FSMServiceConfirmationItem eq '${fsmConfirmationItemID}'"""
        }
    }

    // Append conditions correctly with 'or'
    if (!itemConditions.isEmpty()) {
        confirmationQuery += """&\$filter=(""" + itemConditions.join(" or ") + ")"
    }

    message.setProperty("confirmationQuery",confirmationQuery)

    return message
}
