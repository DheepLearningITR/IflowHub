import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlParser;
import groovy.xml.XmlUtil;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    //this script is to create the FSM payload for the existing confirmations in S4HANA. 
    //Also, removes the existing confirmations from the incoming Source message.
    def body = message.getBody(String.class)
    def serviceConfirmation = new XmlParser().parseText(body)
    def map = message.getProperties()
    def sourceMsg = map.get("RequestPayload") as String;
    def parseSrcMsg = new XmlParser().parseText(sourceMsg)

    //construct FSM payload for the existing confirmations
    def FSMPayload = []   

    serviceConfirmation?.A_ServiceConfirmationItemType.each{ it ->
        def fsmConfId = it.FSMServiceConfirmationItem.text()
        def confirmationId = it.ServiceConfirmation.text()
        
        //for old Service Confirmation API, FSMServiceConfirmation does not exist -> do not add to payload
        if (fsmConfId != ""){
            def s4ConfId = confirmationId + "/" + it.ServiceConfirmationItem.text()
            def object = new JsonBuilder()
            object { "id" (fsmConfId)
                     "confirmationitem" (s4ConfId) }

            FSMPayload.add(object)
        }

        //remove the exisitng FSM confirmations from incoming message
        parseSrcMsg.A_ServiceConfirmationType?.to_Item?.A_ServiceConfirmationItemType?.each() { item ->
            if(item.FSMServiceConfirmationItem.text() == fsmConfId){
                item.replaceNode {};
            }
        }
    }

    
    message.setProperty("NewConfirmationsExists","false")
    if (parseSrcMsg.A_ServiceConfirmationType?.to_Item?.A_ServiceConfirmationItemType.size() > 0)
        message.setProperty("NewConfirmationsExists","true")
    message.setProperty("RequestPayload",XmlUtil.serialize(parseSrcMsg));   
    message.setProperty("FSMRequestPayload", new JsonBuilder(FSMPayload).content.toString())
    
    return message;
        
}
