import com.sap.it.api.mapping.*;
import org.apache.commons.lang.StringUtils


def String removeLeadingZeros(String id){
    if (StringUtils.isNumeric(id)) {
    return StringUtils.stripStart(id,"0");}
    else {
    return id;}
}


def String truncateRoleString(String role) {
    if (role.length() <= 2) {
        return role
    } else {
        return role[0..1]
    }
}