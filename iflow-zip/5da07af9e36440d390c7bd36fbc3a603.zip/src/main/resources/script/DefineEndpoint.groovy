import com.sap.gateway.ip.core.customdev.util.Message

def Message processData( Message message ) throws Exception {


       map = message.getProperties();
       String  UsageMode = map.get("UsageMode");

if(UsageMode == "PROD") { 


message.setProperty("EndpointAddress", "https://vpfe.dian.gov.co/WcfDianCustomerServices.svc");

} else{ 

message.setProperty("EndpointAddress", "https://vpfe-hab.dian.gov.co/WcfDianCustomerServices.svc");

}


	return message;
}
