import com.sap.it.api.mapping.*;
import org.apache.commons.lang.StringUtils
import com.sap.it.api.mapping.MappingContext


def String removeLeadingZeros(String id){
    if (StringUtils.isNumeric(id)) {
    return StringUtils.stripStart(id,"0");}
    else {
    return id;}
}


def String truncateRoleString(String role) {
    if (role.length() <= 2) {
        return role
    } else {
        return role[0..1]
    }
}


def String adjustAbapNumber(String str) {
    def parts = str.split("\\.")
    return str.isEmpty() ? "" : parts[0]
}


def String getLanguage(String header_name, MappingContext context ) {
    def headerValue = context.getHeader("language");
    return headerValue ?: "en";
}


def void processScheduleLine(String[] item_key, String[] scheduleLine_key, String[] value, Output output, MappingContext context) {
    for (int i = 0; i < item_key.length; i++) {
        boolean found = false
        for (int j = 0; j < scheduleLine_key.length; j++) {
            if (item_key[i].equals(scheduleLine_key[j])) {
                output.addValue(value[i])
                found = true
                break
            }
        }
        if (!found) {
            output.addValue(item_key[i] + "#"+ scheduleLine_key[i] + "#" + item_key.length)
        }
    }
}