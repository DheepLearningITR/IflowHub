import groovy.json.JsonSlurper
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput

def Message setMessageProperties(Message message) {

    def json = message.getBody(java.io.Reader)
    def data = new JsonSlurper().parse(json)

    message.setHeader("SAP_ApplicationID", data.displayId)
    
    
    return message
}

def Message filterNullValues(Message message) {

    def json = message.getBody(java.io.Reader)
    def data = new JsonSlurper().parse(json)

    data = data.findAll { key, value -> value != null }
    message.setBody(JsonOutput.toJson(data))
    
    return message
}