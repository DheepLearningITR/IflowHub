import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
	    def testRun = message.getHeaders().get("testRun");
		if(testRun != null && testRun != 'false' && testRun != ''){
			messageLog.addCustomHeaderProperty("cbr_testRun", testRun);		
        }
		def cbrJobFamilyId = message.getProperties().get("cbrJobFamilyId");
		if(cbrJobFamilyId!=null){
			messageLog.addCustomHeaderProperty("cbr_JobFamilyId", cbrJobFamilyId);		
        }
		def sfsfJobProfileTemplate = message.getProperties().get("sfsfJobProfileTemplate");
		if(sfsfJobProfileTemplate!=null){
			messageLog.addCustomHeaderProperty("sfsf_JobProfileTemplate", sfsfJobProfileTemplate);		
        }        
	}
	return message;
}
def Message jobFamilyCode(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def familyCode = message.getProperties().get("sfsfJobFamilyCode");
		if(familyCode != null){
			messageLog.addCustomHeaderProperty("sfsf_jobFamilyCode", familyCode);		
        }
	}
	return message;
}