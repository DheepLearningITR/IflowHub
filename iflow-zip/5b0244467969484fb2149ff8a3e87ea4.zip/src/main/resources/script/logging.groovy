/*
Script from https://blogs.sap.com/2020/09/13/sap-cpi-a-guide-to-mpl-search/
*/

import java.util.HashMap;
import com.sap.gateway.ip.core.customdev.util.Message;


// Start of Processing

def Message logStart(Message message) {
    logCustomHdrProp(message, "CustomLog", "Request triggered from PAS-X");
    message.setProperty("ProcessingMode", "Sync");
    return message;
}

// Processing

def Message log_ERPRequestStart(Message message) {
    logCustomHdrProp(message, "CustomLog", "Sending request to S95 started")
    return message;
}


def Message log_ERPRequestEnd(Message message) {
    logCustomHdrProp(message, "CustomLog", "Request to S95 completed successfully")
    return message;
}

// End of Processing

def Message logEnd(Message message) {
    logCustomHdrProp(message, "CustomLog", "Request sent to S95 successfully");
    return message;
}


// Log Errors

def Message logErr_DetMapping(Message message) {
    logCustomHdrProp(message, "CustomLog", "Error encountered while determining the mapping to use.")
    logCustomHdrProp(message, "CustomLog", "A mapping for Idoc type " + message.getProperty("IdocType") + " cannot be found")
    logException(message, message.getProperty("exception_msg"))
    return message;
}

def Message logErr_Mapping(Message message) {
    logCustomHdrProp(message, "CustomLog", "Error encountered while performing mapping program - " + message.getHeader("MappingProgramName", java.lang.String))
    logException(message, message.getProperty("exception_msg"))
    return message;
}

def Message logErr_ERPReq(Message message) {
    logCustomHdrProp(message, "CustomLog", "Error encountered while connecting with S95 or S95 ran into an error processing the request.")
    logException(message, message.getProperty("exception_msg"))
    return message;
}

// Add Exception in Headers

def Message logException(Message message, String exception) {
    message.setHeader("exception_msg", message.getProperty("ProcessingMode")+ " Response: " + exception)
    logCustomHdrProp(message, "CustomLog", "Exception Message: " + exception)
    logCustomHdrProp(message, "CustomLog", "Stopping interface due to error")
    return message
}

// Custom Log Writer

def Message logCustomHdrProp(Message message, String propName, String propValue) {
    def messageLog = messageLogFactory.getMessageLog(message)
    
    if (propName.equals('CustomLog')) {
        if (message.getProperty("customLogCounter") >= 0) {
            def counter = message.getProperty("customLogCounter") + 1
            messageLog.addCustomHeaderProperty(propName + "_" + counter.toString().padLeft(3, '0'), propValue)
            message.setProperty("customLogCounter", counter)
        }
        // for first custom log entry
        else {
            message.setProperty('customLogCounter', 0)
            messageLog.addCustomHeaderProperty(propName + "_000", propValue)
        }
    }
    else {
        messageLog.addCustomHeaderProperty(propName, propValue)
    }
    return message
} 