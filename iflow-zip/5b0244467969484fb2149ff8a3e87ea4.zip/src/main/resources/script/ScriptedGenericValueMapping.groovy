import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.w3c.dom.Node;
import groovy.xml.MarkupBuilder;
import groovy.xml.XmlUtil;

def Message processData(Message message) {

    def service = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    def _sourceAgency = message.getProperty("SourceAgency");
    def _sourceSchema = message.getProperty("SourceSchema");
    def _targetAgency = message.getProperty("TargetAgency");
    def _targetSchema = message.getProperty("TargetSchema");
    def _sourceValue = message.getProperty("SourceValue");
    def _targetValue = "";

    // Ensure service and all necessary values are non-null
    if (service != null && _sourceAgency && _sourceSchema && _sourceValue && _targetAgency && _targetSchema) {

        _targetValue = service.getMappedValue(_sourceAgency, _sourceSchema, _sourceValue, _targetAgency, _targetSchema);
        
        if (_targetValue == null || _targetValue.equals("")) {
            _targetValue = "default";
            throw new Exception("Value Mapping failed");
        }
        
        message.setProperty("TargetValue", _targetValue);
    } else {
        throw new IllegalArgumentException("One or more required values are null or empty.");
    }

    return message;
}
