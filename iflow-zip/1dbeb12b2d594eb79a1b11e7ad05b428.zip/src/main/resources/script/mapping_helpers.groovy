import com.sap.it.api.mapping.*;

def String getEntryNumber(String input){
	return input.substring(input.indexOf("/") + 1); 
}

def String getServiceOrderId(String input){
	return input.substring(0, input.indexOf("/")); 
}