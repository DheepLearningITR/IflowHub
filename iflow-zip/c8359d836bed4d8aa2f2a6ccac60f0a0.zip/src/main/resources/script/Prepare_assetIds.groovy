/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/de/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/de/index.html */
import com.sap.gateway.ip.core.customdev.util.Message
import org.apache.commons.codec.binary.Base64
import groovy.json.JsonSlurper
import groovy.json.JsonException

Message processData(Message message) {
    String[] assetIds = message.getHeaders().get('CamelHttpQuery').split('assetIds=')
    jsonSlurper = new JsonSlurper()
    String error

    //Headers
    mapH = message.getHeaders()
    systemid_enrich = mapH.get('SystemID_enrich')

    batchID = 'BatchID'   //partInstanceId
    serialID = 'SerialID' //partInstanceId
    productID = 'ProductID' //manufacturerPartId

    systemID = 'SystemID'
    invalidError = 'URL Parameter assetIds is invalid'
    notSetError = ' not set'
    invalidErrorFound = 'Found:'
    invalidErrorExpected = 'Expected was: partInstanceId, manufacturerPartId and systemID'

    for (int i = 1; i < assetIds.length; i++) {
        try {
            byte[] decodedBytes = Base64.decodeBase64(assetIds[i])
            if (decodedBytes.length) {
                json = jsonSlurper.parseText(new String(decodedBytes))

                /*    if (json.name == batchID || json.name == serialID || json.name == productID || json.name == systemID) {
                    message.setProperty(json.name, json.value)
                }*/
                if (json.name.toString().toLowerCase() == "partInstanceId".toLowerCase()) {
                    message.setProperty(batchID, json.value)
                    message.setProperty(serialID, json.value)
                } else if (json.name.toString().toLowerCase() == "manufacturerPartId".toLowerCase()) {
                    message.setProperty(productID, json.value)
                } else if (json.name.toString().toLowerCase() == systemID.toLowerCase()) {
                    message.setProperty(json.name, json.value)
                } else {
                    error = invalidError
                    invalidErrorFound += ' -' + json.name
                }
            }
        } catch (JsonException e) {
            error = invalidError + ". " + invalidErrorFound + ". " + invalidErrorExpected + "."
        }
    }

    if(error){
        //enhance with information for invalid case
        error += ". " + invalidErrorFound + ' inside base64urlEncoded AssetIDs parameter. ' + invalidErrorExpected + "."
    }

    if (!error) {
        if (!message.getProperty(batchID) && !message.getProperty(serialID)) {
            error = "partInstanceId" + notSetError
        } else if (!message.getProperty(productID)) {
            error = "manufacturerPartId" + notSetError
        } else if (!message.getProperty(systemID)) {
            if(systemid_enrich != null && systemid_enrich != '' ){
                message.setProperty(systemID, systemid_enrich)
            }
            else{
                error = systemID + notSetError
            }
        }
    }

    if (error) {
        message.setProperty('error', error)
    }
    return message
}