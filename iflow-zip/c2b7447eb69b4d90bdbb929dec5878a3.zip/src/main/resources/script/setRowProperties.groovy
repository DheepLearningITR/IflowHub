import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.json.JsonOutput
import groovy.json.JsonSlurper




def Message setRowsProperties(Message message) {


    def body = message.getBody(String.class)
    def startRow
    def endRow
    
    def startRowProp = message.getProperty("startRow")
    if (startRowProp instanceof String){
        startRow = Integer.parseInt(startRowProp) 
    } else {
        startRow = startRowProp
    }
    
    def endRowProp = message.getProperty("endRow")
    if (endRowProp instanceof String){
        endRow = Integer.parseInt(endRowProp) 
    } else {
        endRow = endRowProp
    }
    
   
    
    if (endRow > 0){
        startRow = startRow + Integer.parseInt(message.getProperty("executePageSize")) 
    }
    
    endRow = endRow + Integer.parseInt(message.getProperty("executePageSize")) 
    
    
    def numberOfItems = Integer.parseInt(message.getProperty("numberOfItems")) 
    
    if (numberOfItems <= endRow){
        endRow = numberOfItems 
        message.setProperty("hasMoreRecords", "false")
    }
    
    message.setProperty("startRow", startRow)
    message.setProperty("endRow", endRow)

    return message
}
