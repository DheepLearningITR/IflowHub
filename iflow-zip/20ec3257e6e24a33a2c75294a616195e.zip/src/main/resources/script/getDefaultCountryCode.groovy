import com.sap.it.api.mapping.*;

def String getDefaultCountryCode(String arg1, MappingContext context){
	return context.getProperty("defaultCountryIsoCode") ;
}