import com.sap.it.api.mapping.*;

// import javax.xml.xpath.*
// import javax.xml.parsers.DocumentBuilderFactory

def String getFaxSubscirberId(String pFaxNumber) {
    // def body = message.getBody(java.lang.String) as String;
    // def root = new XmlSlurper().parseText(body);
    // def FaxNumber = root.SAPCpiOutboundCustomers.SAPCpiOutboundCustomer.sapCpiOutboundAddress.SAPCpiOutboundAddress.faxNumber;
     
    return pFaxNumber.split('-').size() > 0 ? pFaxNumber.split('-')[0] : "";
    
}

def String getFaxExtensionId(String pFaxNumber) {
    // def body = message.getBody(java.lang.String) as String;
    // def root = new XmlSlurper().parseText(body);
    // def FaxNumber = root.SAPCpiOutboundCustomers.SAPCpiOutboundCustomer.sapCpiOutboundAddress.SAPCpiOutboundAddress.faxNumber;
     
    return pFaxNumber.split('-').size() > 1 ? pFaxNumber.split('-')[1] : "";

    
}
