import com.sap.it.api.mapping.*;

// Script to get UUID
def String getUUID(String UID){
	return UUID.randomUUID().toString(); 
}