import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def inputOrig = message.getProperties().get('receiveEvents')
    Reader json = message.getBody(java.io.Reader)
    def origEvent = new JsonSlurper().parseText(inputOrig)
    def globalAssetId

    try {
        def input = new JsonSlurper().parse(json)
        if (input.globalAssetId) {
            globalAssetId = input.globalAssetId.replace('urn:uuid:', '')
        }else if(input.result[0].globalAssetId){
            globalAssetId = input.result[0].globalAssetId.replace('urn:uuid:', '')
        }
    } catch(Exception e) {
        globalAssetId = UUID.randomUUID().toString()
    }
    
    // Handle Receive Events
    if (origEvent.ReceiveEvents) {
        if (globalAssetId) {
            appendKeyAssignment(origEvent.ReceiveEvents, 'CATENA_X_BATCH', globalAssetId)
        }
    }
    if (origEvent.ReceiveSerialNumberEvents) {
        if (globalAssetId) {
            appendKeyAssignment(origEvent.ReceiveSerialNumberEvents.SerialNumbers, 'CATENA_X_VENDOR_PART', globalAssetId)
        }
    }

    def aasJson = new JsonBuilder(origEvent)
    message.setBody(aasJson.toPrettyString())
    return message
}

def appendKeyAssignment(def event, def qualifier, def value) {
    if (event.KeyAssignments instanceof List) {
        event.KeyAssignments << createKeyAssignmentMap(qualifier, value)
    } else {
        event.KeyAssignments = createKeyAssignmentMap(qualifier, value)
    }
}

def createKeyAssignmentMap(def qualifier, def value) {
    def keyAssignmentMap = [:]
    keyAssignmentMap.Qualifier = qualifier
    keyAssignmentMap.Value = value
    return keyAssignmentMap
}

