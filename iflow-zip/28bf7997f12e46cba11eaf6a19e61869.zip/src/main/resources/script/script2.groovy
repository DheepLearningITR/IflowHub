import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import java.util.Base64
import java.util.Base64.Encoder
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def body = message.getBody(String.class)
    message.setProperty('receiveEvents',body)
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    message.setHeader('Catenax_Vendor', '')
    def urlExtend 
    urlExtend = getDefaultQueryParamData(message,input )
    message.setHeader('urlFilter', urlExtend)
    return message
}

def getDefaultQueryParamData (Message message, def input) {
    // Base64 encoding
    Encoder encoder = Base64.getUrlEncoder()
	def urlExtend = new StringBuilder()
	def assetIdValue = new StringBuilder()
	String aasidEncoded
	if (input.ReceiveEvents) {
		def catenax_Batch = getKeyAssignments(input.ReceiveEvents.KeyAssignments, 'CATENA_X_BATCH')
		def catenax_Vendor
		if (input.ReceiveEvents.DeliveryItemKeys instanceof List) {
			catenax_Vendor = getKeyAssignments(input.ReceiveEvents.DeliveryItemKeys[0].KeyAssignments, 'CATENA_X_VENDOR')
		} else if(input.ReceiveEvents.DeliveryItemKeys.KeyAssignments) {
			catenax_Vendor = getKeyAssignments(input.ReceiveEvents.DeliveryItemKeys.KeyAssignments, 'CATENA_X_VENDOR')
		}
		if (!catenax_Batch && catenax_Vendor) {
            message.setHeader('Catenax_Vendor', catenax_Vendor)
            if (input.ReceiveEvents.BatchID) {
                assetIdValue .append('{\"name\":\"partInstanceId\",\"value\":\"').append(input.ReceiveEvents.BatchID).append('\"}')
                aasidEncoded = encoder.encodeToString(assetIdValue.toString().bytes) // Use .bytes to get byte array
                urlExtend.append('assetIds=').append(aasidEncoded)
				if (input.ReceiveEvents.ProductID) {
				    assetIdValue = new StringBuilder()
					assetIdValue.append('{\"name\":\"customerPartId\",\"value\":\"').append(input.ReceiveEvents.ProductID).append('\"}')
                    aasidEncoded = encoder.encodeToString(assetIdValue.toString().bytes) // Use .bytes to get byte array
					urlExtend.append('&assetIds=').append(aasidEncoded)
				}
			}
		}else {
            message.setHeader('Catenax_Vendor', '')
        }
	} else if (input.ReceiveSerialNumberEvents) {
		def catenax_Serial = getKeyAssignments(input.ReceiveSerialNumberEvents.SerialNumbers.KeyAssignments, 'CATENA_X_VENDOR_PART')
		def catenax_Vendor = getKeyAssignments(input.ReceiveSerialNumberEvents.KeyAssignments,'CATENA_X_VENDOR')
		if(!catenax_Serial && catenax_Vendor) {
            message.setHeader('Catenax_Vendor', catenax_Vendor)
			if (input.ReceiveSerialNumberEvents.SerialNumbers.SerialID) {
                assetIdValue .append('{\"name\":\"partInstanceId\",\"value\":\"').append(input.ReceiveSerialNumberEvents.SerialNumbers.SerialID).append('\"}')
                aasidEncoded = encoder.encodeToString(assetIdValue.toString().bytes) // Use .bytes to get byte array
                urlExtend.append('assetIds=').append(aasidEncoded)
				if (input.ReceiveSerialNumberEvents.ProductID) {
				    assetIdValue = new StringBuilder()
					assetIdValue.append('{\"name\":\"customerPartId\",\"value\":\"').append(input.ReceiveSerialNumberEvents.ProductID).append('\"}')
                    aasidEncoded = encoder.encodeToString(assetIdValue.toString().bytes) // Use .bytes to get byte array
					urlExtend.append('&assetIds=').append(aasidEncoded)
				}
			}
		}else {
            message.setHeader('Catenax_Vendor', '')
        } 
	}
	return urlExtend.toString() 
}

def getKeyAssignments(def keyAssignments, def qualifier) {
	def  res = ""
	if (keyAssignments) {
		if (keyAssignments instanceof List) {
			keyAssignments.each{
				if (it.Qualifier == qualifier) {
					res = it.Value
				}
			}
		}else if (keyAssignments.Qualifier == qualifier) {
			res = keyAssignments.Value
		} else {
			res = ''
		}
	} else {
		res = ''
	}
	return res
}
