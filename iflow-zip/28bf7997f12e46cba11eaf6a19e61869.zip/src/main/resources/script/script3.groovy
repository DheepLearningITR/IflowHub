import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)

    def uuid = input[0]
    message.setHeader('identification', uuid)
    return message
}
