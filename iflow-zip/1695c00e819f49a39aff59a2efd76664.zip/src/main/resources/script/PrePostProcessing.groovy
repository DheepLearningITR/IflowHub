import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processXmlInput(Message message) {

  def body = message.getBody(java.io.Reader)
  def xml = new XmlParser().parse(body)

  //find tags with null value
  def results = xml.
  '**'.findAll {
    !it.value()
  }

  results.each {
    def newNode = new Node(null, it.name(), 'xsi.nil')
    // replace node    
    it.replaceNode(newNode)
  }
  // write to body
  StringWriter stringWriter = new StringWriter()
  XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter))
  nodePrinter.setPreserveWhitespace(true)
  nodePrinter.print xml

  message.setBody(stringWriter.toString())
  return message;

}

def Message enrichJsonOutput(Message message) {
  //Body 
  def body = message.getBody(java.io.Reader);

  JsonSlurper slurper = new JsonSlurper()
  Map parsedJson = slurper.parse(body)

  parsedJson.messageRequests.each {


if (it.body.isDeleted) {
 it.body.isDeleted = Boolean.parseBoolean(it.body.isDeleted)
}

if (it.body.isNaturalPerson) {
 it.body.isNaturalPerson = Boolean.parseBoolean(it.body.isNaturalPerson)
}
if (it.body.blockingReasons.isSalesSupportBlocked) {
      it.body.blockingReasons.isSalesSupportBlocked = Boolean.parseBoolean(it.body.blockingReasons.isSalesSupportBlocked)
}
    
 it.body.salesArrangements.each {
    if (it.isDeleted) {
      it.isDeleted = Boolean.parseBoolean(it.isDeleted)
    }
    if (it.isCompleteDeliveryRequested) {
      it.isCompleteDeliveryRequested = Boolean.parseBoolean(it.isCompleteDeliveryRequested)
    }
    if (it.blockingReasons.isSalesSupportBlocked) {
      it.blockingReasons.isSalesSupportBlocked = Boolean.parseBoolean(it.blockingReasons.isSalesSupportBlocked)
     }
    it.partnerFunctionRelationships.each {
            if (it.isDefault){
                it.isDefault = Boolean.parseBoolean(it.isDefault)
            }
        }
    }
      
  }

 def openAPISchemaStream = this.getClass().getResourceAsStream("/src/main/resources/json/customerERPReplicationIn.json")
 def iDOCReplicationHelper = message.getProperty('iDOCReplicationHelper')
 
   try {

    def schema = new JsonSlurper().parse(openAPISchemaStream)
      .components.schemas.CustomerReplicationIncreaterequest.properties.messageRequests.items.properties.body

    parsedJson.messageRequests.each {
      request ->
        iDOCReplicationHelper.setMissingAttributesToNull(request.body, schema)
    }

    def modifiedJson = JsonOutput.toJson(parsedJson)
    message.setBody(modifiedJson)

  } finally {
    if (openAPISchemaStream != null) {
      openAPISchemaStream.close()
    }
  }

  return message
}

def Message enrichJsonOutputCustomerContact(Message message) {
    
    def body = message.getBody(java.io.Reader)
    def parsedJson = new JsonSlurper().parse(body)

    parsedJson.messageRequests.each { request ->
        ['functionalTitle', 'department', 'vipReason', 'dateOfBirth'].each { field ->
            if (!request.body[field]) {
                request.body[field] = null
            }
        }
    }

    message.setBody(JsonOutput.toJson(parsedJson))

    return message
}

def Message enrichJsonOutputCustomerPartnerFunction(Message message) {
    
    def body = message.getBody(java.io.Reader)
    def parsedJson = new JsonSlurper().parse(body)

    parsedJson.messageRequests.each { request ->
    request.body?.salesArrangements?.each { arrangement ->
        arrangement.partnerFunctions?.each { partnerFunction ->
            partnerFunction.isDefault = Boolean.parseBoolean(partnerFunction.isDefault)
        }
    }
}

    message.setBody(JsonOutput.toJson(parsedJson))

    return message
}
