import com.sap.it.api.mapping.*;

def String getIntValue(String value){
	return Integer.parseInt(value)
}

def String generateUUID(String value){
	return UUID.randomUUID().toString()
}
def String getDefaultS4Id(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty("P_DefaultS4ID")
    return propertyValue
}
def String getDefaultS4ContactId(String propertyName, MappingContext context) {
    def propertyValue = context.getProperty("P_DefaultS4ContactID")
    return propertyValue
}
def String generateMessageHeaderUUID(String value, MappingContext context){
    def messageId = UUID.randomUUID().toString()
    context.setProperty ("p_msg_header_id", messageId)
	return messageId
}