import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
		def body = message.getBody(java.lang.String);
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString("Payload", body, "text/plain");
		}
	}
	return message;
}


def Message FinalCall(Message message) {
	def map = message.getProperties();
	def pEnableLog = map.get("P_EnableLogging");
	if (pEnableLog.toUpperCase().equals("TRUE")) {
	String output = "";
	output = "Payload:" + map.get("P_payload") + "\n" + "Signature:" + map.get("P_SIGNATURE") + "\n" + "EntityName" + map.get("Entity");
		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString("FinalPayloadToAmazon", output, "text/plain");
		}
	}
	return message;
}