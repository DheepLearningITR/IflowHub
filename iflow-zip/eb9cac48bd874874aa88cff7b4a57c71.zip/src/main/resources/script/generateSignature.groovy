import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;

def Message processData(Message message) {
    //Body 
       String body = message.getBody(java.lang.String);
       String secretKey = message.getProperty("P_SECRET_KEY");
       String algorithm = message.getProperty("P_AWS_SIGN_METHOD");
       String signature = "";
       try {
           Mac mac = Mac.getInstance(algorithm);
           SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(), algorithm);
           mac.init(secretKeySpec);
           byte[] digest = mac.doFinal(body.getBytes());
           signature = digest.encodeBase64().toString()
           
       }catch(InvalidKeyException e){
           throw new RuntimeException("Invalid key exception while converting to HMac SHA256")
       }
   //    signature = signature.replaceAll("=","%3D");
    //   signature = signature.replaceAll("/","%2F");
    //   signature = signature.replaceAll('+',"%2B");
    
    
       
       
       message.setProperty("P_SIGNATURE",URLEncoder.encode(signature, java.nio.charset.StandardCharsets.UTF_8.toString()));
 //      message.setBody(URLEncoder.encode(signature, java.nio.charset.StandardCharsets.UTF_8.toString()));
       
       return message;
}