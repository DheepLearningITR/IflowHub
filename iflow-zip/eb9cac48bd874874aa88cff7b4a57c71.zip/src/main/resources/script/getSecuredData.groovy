import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;

def Message processData(Message message) {
    //Body 
    
    String pStoredDate = message.getProperty("P_STOREDDATE");
    String pUserDate = message.getProperty("P_USERDATE");
    
    if(pStoredDate!='X'){
        message.setProperty("P_CALCULATEDDATE",pStoredDate);
    }
    else{
        message.setProperty("P_CALCULATEDDATE",pUserDate);
    }
    
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    if( service != null){
        String pSecretKey = message.getProperty("P_AWS_SECRET_KEY");
        String pAccessKey = message.getProperty("P_AWS_ACCESSKEY");
        String pMerchant = message.getProperty("P_AWS_MERCHANT");
        String pAuthToken = message.getProperty("P_AWS_AUTH_TOKEN");
       
       //Get UserCredential containing user credential details deployed on the node with the given alias.
        String secretKey  = service.getUserCredential(pSecretKey).getPassword().toString();
        String accessKey = service.getUserCredential(pAccessKey).getPassword().toString();
        String merchant = service.getUserCredential(pMerchant).getPassword().toString();
        String authToken = service.getUserCredential(pAuthToken).getPassword().toString();
        
        message.setProperty("P_SECRET_KEY",secretKey );
        message.setProperty("P_ACCESSKEY",accessKey );
        message.setProperty("P_MERCHANT",merchant );
        message.setProperty("P_AUTH_TOKEN",authToken );
       
    }
    
       
       return message;
}