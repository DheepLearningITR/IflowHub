import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.io.Reader);
    def root = new XmlSlurper().parse(body);
    
 //   String pStoredDate = message.getProperty("P_STOREDDATE");
    String calculatedDate = message.getProperty("P_CALCULATEDDATE");
    
    String submittedDate = root.GetReportRequestListResult.ReportRequestInfo.SubmittedDate.toString();
    String reportID = root.GetReportRequestListResult.ReportRequestInfo.GeneratedReportId.toString();
    
    if(submittedDate.substring(0,19) > calculatedDate){
        message.setProperty("P_REPORTID",reportID);
        message.setProperty("P_REPORTFLAG", "TRUE");
        message.setProperty("P_SUBMITTEDDATE",submittedDate.substring(0,19));
    }
    else
        message.setProperty("P_REPORTFLAG", "FALSE");
    return message;
}