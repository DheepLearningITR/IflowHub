import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    
    //def splitCount = message.getProperty("");
    
     String splitIndex = message.getProperty("CamelSplitIndex");
      if(!(splitIndex.equals("0")))
      {
        sleep(60000)
      }
    
    def body = message.getBody(java.io.Reader);
    def root = new XmlSlurper().parse(body);
    int count = 1;
    
    String param_AmazonId = "";
    root.AmazonOrderID.each { order->
        param_AmazonId = param_AmazonId + "&AmazonOrderId.Id.${count}=" + order;
        count++;
    }
    
    message.setBody(param_AmazonId);
    message.setProperty("P_AMAZONID",param_AmazonId);
    return message;
}