import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Get the JSON string from the header
    def headers = message.getHeaders()
    def jsonString = headers.get("FormattedHTTPQuery")

    // Parse the JSON string
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(jsonString)

    // Initialize the writer for XML
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.setDoubleQuotes(true)

    // Build the XML structure with namespace
    xml.'n0:IsuC4cV2TransferSecGet'('xmlns:n0': 'urn:sap-com:document:sap:soap:functions:mc-style') {
        // Separate handling for dueDateFrom and dueDateTo
        if (jsonObject.dueDateFrom || jsonObject.dueDateTo) {
            ItDueDate {
                'item' {
                    Sign('I')
                    Option('BT')
                    DateFrom(jsonObject.dueDateFrom?.get(0)?.value ?: '')
                    DateTo(jsonObject.dueDateTo?.get(0)?.value ?: '')
                }
            }
        }

        jsonObject.each { key, value ->
            switch (key) {
                case 'top':
                    if (value) IvTop(value.toString())
                    break
                case 'search':
                    if (value) IvSearchValue(value.toString())
                    break
                case 'skip':
                    if (value) IvSkip(value.toString())
                    break
                case 'contractAccountId':
                    if (value && value[0]?.value) IvContractAccount(value[0].value)
                    break

                case 'moveOutService':
                    ItMoveOutService {
                        value.each { entry ->
                            'item' {
                                Installation(entry?.value?.trim() ?: "")
                            }
                        }
                    }
                    break
                case 'moveInService':
                    ItMoveInService {
                        value.each { entry ->
                            'item' {
                                Installation(entry?.value?.trim() ?: "")
                                }
                        }
                    }
                    break

                case 'businessPartnerId':
                    if (value && value[0]?.value) IvBusinessPartner(value[0].value)
                    break
                case 'language':
                    if (value && value[0]?.value) IvLanguage(value[0].value)
                    break
                default:
                    // Handle any additional dynamic fields if necessary
                    break
            }
        }

        // Always include ItAdditionalFilter with constant values
        ItAdditionalFilter {
            'item' {
                Fieldname('QueryFilter')
                FieldValue(headers.get("QueryFilter") ?: "")
                Sign('I')
                Option('')
                Low("")
                High("")
            }
        }
    }

    // Set the XML output as the message body
    message.setBody(writer.toString())

    return message
}
