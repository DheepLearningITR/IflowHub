import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.slurpersupport.GPathResult;

def Message processData(Message message) {

    //Body
    def body = message.getBody(java.lang.String);
    GPathResult rootGPath = new XmlSlurper().parseText(body);
    Node rootNode = new XmlParser().parseText(body);
    
    String systemId = "";
    String customerReturnId = "";
    //String primaryEmail = "";

    customerReturnId = rootGPath.CustomerReturn.CustomerReturnID;
    systemId = rootGPath.MessageHeader.SenderBusinessSystemID;
    /*primaryEmail = rootGPath.CustomerReturn.Partner.find {it.PartnerFunction == "WE"}
            .Address.Communication.EmailAddress.text(); */

    if(!customerReturnId.isEmpty() && !systemId.isEmpty()){
        String oid = "<CustomerReturnOID>SystemId:CustomerReturnID</CustomerReturnOID>";
        oid = oid.replace("SystemId", systemId);
        oid = oid.replace("CustomerReturnID", customerReturnId);
        
            
        message.setProperty("customerReturnOid",oid); 
    
        Node oidNode = new XmlParser().parseText(oid);
        for(int i=0; i<rootNode.children().size(); i++){
            if(rootNode.children().get(i).name().equals("CustomerReturn")){
              rootNode.children().get(i).append(oidNode);
            }
        }
        
    }


    /*if(!primaryEmail.isEmpty()){
        String email = "<PrimaryEmail>email</PrimaryEmail>";
        email = email.replace("email", primaryEmail);

        Node emailNode = new XmlParser().parseText(email);
        for(int i=0; i<rootNode.children().size(); i++){
            if(rootNode.children().get(i).name().equals("SalesOrder")){
                rootNode.children().get(i).append(emailNode);
            }
        }
    }*/

    StringWriter stringWriter = new StringWriter();
    XmlNodePrinter nodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter));
    nodePrinter.setPreserveWhitespace(true);
    nodePrinter.print(rootNode);
    
    String result = stringWriter.toString();
    result = result.replace("n0:",""); //remove namspace prefix
    result = result.replace('"$"','"value"'); //replace "$" with "value"
    message.setBody(result);
    message.setHeader("content-type", "application/json");
    
    return message;
    
}
