import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

        def body = message.getBody(java.lang.String);

        body = body.replaceAll("\"\\@","\"");
        body = body.replaceAll("\"\\\$","\"value");
        
        message.setBody(body);
        return message;
}
