import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    
    //Body
    def body = message.getBody(java.lang.String);

    def jsonSlurper = new JsonSlurper();
    def cfg = jsonSlurper.parseText(body);
    
    ///ns4:CustomerReturnBulkReplication/MessageHeader/ReconciliationIndicator
    if(cfg.CustomerReturnBulkReplication.MessageHeader.ReconciliationIndicator != null)
    cfg.CustomerReturnBulkReplication.MessageHeader.ReconciliationIndicator = Boolean.parseBoolean(cfg.CustomerReturnBulkReplication.MessageHeader.ReconciliationIndicator);
    // if(cfg.CustomerReturn){
    cfg.CustomerReturnBulkReplication.CustomerReturn.each{
        
        //TotalNetAmount
        if (it.TotalNetAmount != null) {
            it.TotalNetAmount.value = Double.parseDouble(it.TotalNetAmount.value);
        }
        //Item
        if (it.Item != null) {
            it.Item.each {
                if (it.NetAmount != null) {
                    it.NetAmount.value = Double.parseDouble(it.NetAmount.value);
                }
                if (it.RequestedQuantity != null) {
                    it.RequestedQuantity.value = Double.parseDouble(it.RequestedQuantity.value);
                }
                if (it.RequestedQuantityInBaseUnit != null) {
                    it.RequestedQuantityInBaseUnit.value = Double.parseDouble(it.RequestedQuantityInBaseUnit.value);
                }
            }
        }
        //deletionIndicator
        if(it.deletionIndicator != null){
            it.deletionIndicator = Boolean.parseBoolean(it.deletionIndicator);
        }
        //archivingIndicator
        if(it.archivingIndicator != null){
            it.archivingIndicator = Boolean.parseBoolean(it.archivingIndicator);
        }
    }
// }
    def builder = new groovy.json.JsonBuilder(cfg);
    //println(builder.toPrettyString());

    message.setBody(builder.toPrettyString());
    return message;

}