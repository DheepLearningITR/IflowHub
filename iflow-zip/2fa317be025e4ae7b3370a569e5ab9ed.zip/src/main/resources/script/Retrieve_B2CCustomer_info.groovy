import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import javax.xml.xpath.*
import javax.xml.parsers.DocumentBuilderFactory

// set customerId, uid, email, groups, language (BP_PAYLOAD) as properties for B2BCustomer mapping and phone1, fax, cellPhone for Contact Person Address mapping
def Message processData(Message message) {
    	
	def messageLog = messageLogFactory.getMessageLog(message);
	def body = message.getBody(java.lang.String) as String;
	def properties = message.getProperties() as Map<String, Object>;
    
    // Contact Person Address mapping
    // set telephone number and cellphone number as properties
    def root = new XmlSlurper().parseText(body);
    
    def phoneNumList = root.BusinessPartnerSUITEReplicateRequestMessage.BusinessPartner.AddressInformation.Address.Telephone.collect{ it.MobilePhoneNumberIndicator.text()  + "|" + it.Number.SubscriberID.text() };
    message.setProperty("PhoneNumList", phoneNumList.join(","));
    
    def firstName = root.BusinessPartnerSUITEReplicateRequestMessage.BusinessPartner.Common.Person.Name.GivenName.text();
    message.setProperty("firstName", firstName);
    
    def lastName = root.BusinessPartnerSUITEReplicateRequestMessage.BusinessPartner.Common.Person.Name.FamilyName.text();
    message.setProperty("lastName", lastName);
    
   return message;
}    