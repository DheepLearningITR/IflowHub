import com.sap.it.api.mapping.*;
import java.util.UUID; 
import java.util.Arrays;
import java.util.Set;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;


// Script to get number range group code of business partner
def String getfirstName(String arg1, MappingContext context){
    
    def getfirstName = context.getProperty("firstName");
    
    return getfirstName;
	
}

// Script to get number range group code of business partner
def String getlastName(String arg1, MappingContext context){
    
    def getlastName = context.getProperty("lastName");
    
    return getlastName;
	
}


