import com.sap.it.api.mapping.*;


def String getReturnOrderId(String referenceId, MappingContext context ){
return context.getProperty("ExternalDocumentID");
}

def String getEntryNumber(String referenceId, MappingContext context ){
return context.getProperty("ExternalItemID");
}
