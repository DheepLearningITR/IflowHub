import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	def header = message.getHeaders();
	String property_backgroundElementId = header.get("backgroundElementId");
	String property_StatusText = header.get("HttpStatusCodes");
	String property_StatusCode = header.get("CamelHttpResponseCode");
    //Body 
	def body = message.getBody(java.io.Reader);
	def responseBody='''<Background_VarPayEmpHistData>
							<Background_VarPayEmpHistData>
								<backgroundElementId>''' + property_backgroundElementId + '''</backgroundElementId>
								<statusText>''' + property_StatusText + '''</statusText>
								<statusCode>''' + property_StatusCode + '''</statusCode>
							</Background_VarPayEmpHistData>
						</Background_VarPayEmpHistData>''';
    message.setBody(responseBody);
	return message;
}