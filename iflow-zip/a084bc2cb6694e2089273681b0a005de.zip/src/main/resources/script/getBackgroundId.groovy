
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
      
      //Body 
      //def body = message.getBody();
      //message.setBody(body + "Body is modified");
      
      def header = message.getHeaders();
      
      def body = message.getBody(java.io.Reader);
      def xml = new XmlSlurper().parse(body);
      //def elementId = xml.delete.sfobject.backgroundElementId.text();
      def elementId = xml.Background_VarPayEmpHistData.backgroundElementId.text();
      
      //message.setProperty("BackgroundElementId", elementId);
      
      //String elemenConcat = "backgroundElementId=" + elementId;
      
      header.put("backgroundElementId", elementId);  
      return message;
}


