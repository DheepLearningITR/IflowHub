import com.sap.it.api.mapping.MappingContext
def String getHeader(String input, MappingContext context) {
    def headerValue = context.getHeader(input);
    return headerValue;
}