
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Map

import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message appendStartDate(Message message){
    def body = message.getBody(String.class)?:""
    if (body){
        def jsonSlurper = new JsonSlurper()
        def json = jsonSlurper.parseText(body)
        json?.hierarchyInfo?.startDate = message.getProperty("startDate")
        message.setBody(JsonOutput.toJson(json))
    }
    
    return message
}

def Map formatMap(Map inputMap, String key){
    def map = inputMap?.findAll{it?.value?.size() > 0}
        
    if (map){
        map = map?.collectEntries{[(it?.key) : it.value?.reverse()]}
        map = [(key) : map]
    
    } else {
        map = [(key) : [:]]
    }
    
    return map
}

def Message formatMetadata(Message message) {
    //Body
    def body = message.getBody(String.class)?:""
    def parents = [:]
    
    if (!body){
        parents = [metadata : [:]]
    } else {

        def jsonSlurper = new JsonSlurper()
        def json = jsonSlurper.parseText(body)

        //def rootNode = json.ProdUnivHierNormalNodeType?.find{it.NodeType == 'R'}?.HierarchyNode
        def startDate = json.ProdUnivHierNormalNodeType?.find{it.NodeType == 'R'}?.ProdHierarchyValidityStartDate
        
        message.setProperty("startDate", startDate)
        
        json.ProdUnivHierNormalNodeType?.findAll{it.NodeType == 'N'}?.each {
            currentNode -> 
                if (!parents.containsKey(currentNode?.HierarchyNode)){
        
                    parents.put(currentNode?.HierarchyNode, [currentNode?.HierarchyNode])
                    def isRoot = false
                    def nextHierarchyNode = currentNode
                    while (!isRoot){
                        nextHierarchyNode = json.ProdUnivHierNormalNodeType?.find{it?.HierarchyNode == nextHierarchyNode?.ParentNode}
        
                        isRoot = isRootNode(nextHierarchyNode)
                        parents.get(currentNode?.HierarchyNode).add(nextHierarchyNode?.HierarchyNode)
                        
        
                    }
        
                }
        
            
        }
        
        
        parents = formatMap(parents, "metadata")
    }
    
    def result = JsonOutput.prettyPrint(JsonOutput.toJson(parents))?.trim()
    message.setBody(result[0..result.size()-2])
        
    return message
}

def Message formatName(Message message) {
    def body = message.getBody(String.class)?:""
    
    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)
    
    
    def names = [:]
    
    json.ProdUnivHierNodeByHierIDType?.each {
        currentNode ->
            
            
            names.put(currentNode?.HierarchyNode,currentNode?.ProdUnivHierarchyNode)
    
    
           
            
    
        
    }
    
    def result = [names: names]

    result = JsonOutput.prettyPrint(JsonOutput.toJson(result))?.trim()
    
    message.setBody(result[1..result.size()-2])
    return message
    
}

def boolean isRootNode(Map node){
    if (node == null){
        return true
    }else{
        return node?.NodeType == 'R'
    }
    
}


def Message formatDescription(Message message) {
    //Body
    def body = message.getBody(String.class)?:""
    def parents = [:]
    
    if (!body){
        parents = [desc : [:]]
    } else {

        def jsonSlurper = new JsonSlurper()
        def json = jsonSlurper.parseText(body)
        
        //def rootNode = json.ProdUnivHierNormalNodeType?.find{it.NodeType == 'R'}?.HierarchyNode
        
        json.ProdUnivHierNormalNodeType?.findAll{it.NodeType == 'N'}?.each {
            currentNode -> 
                if (!parents.containsKey(currentNode?.HierarchyNode)){
        
                    parents.put(currentNode?.HierarchyNode, [currentNode?.HierarchyNode_Text])
                    def isRoot = false
                    def nextHierarchyNode = currentNode
                    while (!isRoot){
                        nextHierarchyNode = json.ProdUnivHierNormalNodeType?.find{it?.HierarchyNode == nextHierarchyNode?.ParentNode}
                        isRoot = isRootNode(nextHierarchyNode)
                    
        
                        parents.get(currentNode?.HierarchyNode).add(nextHierarchyNode?.HierarchyNode_Text)
                       
        
                    }
        
                }
        
            
        }
        
        parents = formatMap(parents, "desc")
    }
    
    def result = JsonOutput.prettyPrint(JsonOutput.toJson(parents))?.trim()
    message.setBody(result[1..result.size()-1])
        
    return message
}


