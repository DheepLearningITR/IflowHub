import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // get a map of properties
    def map = message.getProperties();

    // get an exception java class instance
    def ex = map.get("CamelExceptionCaught");
   
    //Headers
    def headers = message.getHeaders() as String;
    def body = message.getBody(java.lang.String) as String;
  
    if(messageLog != null)
    {
        messageLog.addAttachmentAsString("Log RFC call exception details:", ex.toString(), "text/plain");
        messageLog.addAttachmentAsString("Log RFC call payload:", body, "text/plain");
        messageLog.addAttachmentAsString("Log RFC call headers:", headers, "text/plain");
    }

    return message;
}