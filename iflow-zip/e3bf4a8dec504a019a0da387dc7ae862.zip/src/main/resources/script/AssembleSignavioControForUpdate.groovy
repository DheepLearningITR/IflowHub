import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.transform.Field

@Field static final String SIGNAVIO_CONTROL_UPDATE_BODY_FORMAT = 'title=%s&category=%s&description=%s&force=true&attachments=%s&metaDataValues=%s&formats=%s'

def Message processData(Message message) {
    def signavioUpdateControl = message.getProperty('signavioControl')

    def attachments = JsonOutput.toJson(signavioUpdateControl.attachments)
    def metaDataValues = JsonOutput.toJson(signavioUpdateControl.metaDataValues)
    def formats = JsonOutput.toJson(signavioUpdateControl.formats)
    def signavioUpdateBody = String.format(SIGNAVIO_CONTROL_UPDATE_BODY_FORMAT, signavioUpdateControl.title, signavioUpdateControl.category, signavioUpdateControl.description?.replace("&", "%26"), attachments, metaDataValues, formats)
    message.setBody(signavioUpdateBody)

    return message
}