import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.transform.Field

import java.text.SimpleDateFormat

@Field static final String GRC_DATE_FORMATTER = "yyyy-MM-dd'T'HH:mm:ss'Z'"
@Field static final String CONTROL_UPSERT_MESSAGE_TOPIC = 'sap.grc.ctrl.ComplianceControl.Update'
@Field static final String CONTROL_UPSERT_MESSAGE_VERSION = 'v1'
@Field static final String SEPERATOR = '/'
@Field static final String TOPIC_FORMAT = 'topic:%s/ce/%s'
@Field static final String TYPE_FORMAT = '%s.%s'
@Field static final String SUBJECT_FORMAT = 'ComplianceControl:%s'
@Field static final String SIGNAVIO_CONTROL_FORMAT = '%s/p/hub/dictionary/entry/%s'

def Message processData(Message message) {
    def signavioCreateControls = message.getProperty('signavioCreateControls')
    def size = signavioCreateControls.size()
    def currentControl = signavioCreateControls.get(size - 1)
    def responseBody = message.getBody(java.io.Reader)
    def jsonResponseBody = new JsonSlurper().parse(responseBody)
    def emNamespace = message.getProperty('emNamespace')
    def SAPMplCorrelationId = message.getHeader('SAP_MplCorrelationId', String.class)

    Map control = new HashMap()
    def signavioControlId = jsonResponseBody.rep.id
    control.id = currentControl.fcmControlID
    control.externalId = signavioControlId

    // generate Signavio control detail URL
    def signavioHost = message.getProperty('signavioHost')
    def signavioControlURL = String.format(SIGNAVIO_CONTROL_FORMAT, signavioHost, signavioControlId)
    control.externalUrl = signavioControlURL
    control.sourceSystem = 'SIGNAVIO'
    def body = new EventMessageBody(control)
    body.time = new SimpleDateFormat(GRC_DATE_FORMATTER).format(new Date())
    body.source = SEPERATOR + emNamespace
    body.subject = String.format(SUBJECT_FORMAT, currentControl.fcmControlID)
    body.type = String.format(TYPE_FORMAT, CONTROL_UPSERT_MESSAGE_TOPIC, CONTROL_UPSERT_MESSAGE_VERSION)
    body.xsapcorrelationid = SAPMplCorrelationId

    def payload = [:]
    payload.body = JsonOutput.toJson(body)
    payload.topic = String.format(TOPIC_FORMAT, emNamespace, CONTROL_UPSERT_MESSAGE_TOPIC.replace('.', SEPERATOR))
    message.setBody(JsonOutput.toJson(payload))

    signavioCreateControls.remove(size - 1)
    return message
}

class EventMessageBody {
    String xsapcorrelationid
    String id
    String specversion = '1.0'
    String datacontenttype = 'application/json'
    String contentType = 'application/json'
    String time
    String type
    String source
    String subject
    Object data

    EventMessageBody(data) {
        this.id = UUID.randomUUID().toString()
        this.data = data
    }
}