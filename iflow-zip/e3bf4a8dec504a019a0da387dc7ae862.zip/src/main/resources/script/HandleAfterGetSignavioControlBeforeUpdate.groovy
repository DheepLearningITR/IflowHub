import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    int statusCode =  ((Integer) message.getHeaders().get("camelhttpresponsecode")).intValue();
    def ramControl = message.getProperty("signavioUpdateControl")
    
    if (statusCode == 200) {
        def body = message.getBody(java.io.Reader)
        def jsonBody = new JsonSlurper().parse(body)
        def ramControlAttachmentsMap = new JsonSlurper().parseText(ramControl.attachments)
        
        for (def jsonBodyAttachment : jsonBody.attachments) {
            def tempAttachment = ramControlAttachmentsMap.find { it['label'] ==  jsonBodyAttachment.label }
            if ( tempAttachment == null) {
                ramControlAttachmentsMap << jsonBodyAttachment
            }
        }

        ramControl.attachments = ramControlAttachmentsMap
        def ramControlMetaDataValuesMap = new JsonSlurper().parseText(ramControl.metaDataValues)
        ramControl.metaDataValues = jsonBody.metaDataValues << ramControlMetaDataValuesMap
        
        encodeUrlInSignavioControl(ramControl)
        ramControl.formats = jsonBody.formats
    }
    
    message.setProperty("signavioControl", ramControl)
    return message
}


static void encodeUrlInSignavioControl(signavioUpdateControl) {
    for (def attachment : signavioUpdateControl.attachments) {
        encodeUrl(attachment)
    }
    
    for (def metaData : signavioUpdateControl.metaDataValues) {
        if (metaData.value instanceof List) {
            for (def metaDataValueItem : metaData.value) {
                encodeUrl(metaDataValueItem)
            }
        }
    }
}

static void encodeUrl(object) {
    if (object instanceof Map) {
        if (object.url != null && object.label != 'RAM Control') {
            object.url = URLEncoder.encode(object.url, 'UTF-8')
        }
    }
}