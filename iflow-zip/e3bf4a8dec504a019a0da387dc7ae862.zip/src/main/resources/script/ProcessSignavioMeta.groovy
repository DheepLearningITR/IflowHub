import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.transform.Field

@Field static final String META_RAM_CONTROL_ID = 'meta-ramcontrolid'
@Field static final String META_RAM_CONTROL_STATUS = 'meta-ramcontrolstatus'
@Field static final String META_RAM_CONTROL_TECHNICAL_ID = 'meta-ramcontroltechnicalid'
@Field static final List SUPPORT_TYPES = ["MetaDataBoolean", "MetaDataEnum", "MetaDataNumberInfo", "MetaDataStringInfo"]


def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def metadatas = parseMetadatas(new JsonSlurper().parse(body))
    validateMandatoryFieldsExist(metadatas)
    message.setProperty("metadatas", metadatas)

    return message
}

def validateMandatoryFieldsExist(signavioMetadatas) {
    if (!signavioMetadatas.find{it.id.equals(META_RAM_CONTROL_ID)}) {
        throw new Exception("Attribute 'RAM Control ID' is not configured in SAP Signavio.")
    }
    if (!signavioMetadatas.find{it.id.equals(META_RAM_CONTROL_TECHNICAL_ID)}) {
        throw new Exception("Attribute 'RAM Control Technical ID' is not configured in SAP Signavio.")
    }
    if (!signavioMetadatas.find{it.id.equals(META_RAM_CONTROL_STATUS)}) {
        throw new Exception("Attribute 'RAM Control Status' is not configured in SAP Signavio.")
    }
}


def parseMetadatas(metadatas) {
    def metadataMap = [:]
    metadatas.each{parseMetadata(it.rep, metadataMap)}

    return metadataMap.values()
}

def parseMetadata(metadata, metadataMap) {
    def type = metadata.type
    if (!SUPPORT_TYPES.contains(metadata.type)) {
        return
    }

    def id = metadata.id
    def definition = [:]
    definition["id"] = id
    definition["name"] = metadata.name
    definition["type"] = type

    definition["items"] = []
    metadata.items?.each{definition["items"] << parseMetadataItems(it)}

    definition["glossaryBindings"] = []
    metadata.glossaryBindings?.each{definition["glossaryBindings"] << it.category}

    metadataMap[id] = definition
}

def parseMetadataItems(item) {
    def itemDef = [:]
    itemDef["title"] = item.title
    itemDef["value"] = item.value

    return itemDef
}