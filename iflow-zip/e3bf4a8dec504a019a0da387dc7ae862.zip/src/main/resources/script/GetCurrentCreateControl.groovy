import com.sap.gateway.ip.core.customdev.util.Message
import groovy.transform.Field

@Field static final String SIGNAVIO_CONTROL_BODY_FORMAT = 'title=%s&category=%s&description=%s&force=true&attachments=%s&metaDataValues=%s'

def Message processData(Message message) {
    def signavioCreateControls = message.getProperty('signavioCreateControls')
    def signavioCreateControl = signavioCreateControls[signavioCreateControls.size() - 1]

    def attachments = signavioCreateControl.attachments
    def metaDataValues = signavioCreateControl.metaDataValues
    def signavioCreateBody = String.format(SIGNAVIO_CONTROL_BODY_FORMAT, signavioCreateControl.title, signavioCreateControl.category, signavioCreateControl.description?.replace("&", "%26"), attachments, metaDataValues)
    message.setBody(signavioCreateBody)

    return message
}
