import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def properties = message.getProperties()

    if (!properties.get("signavioHost")) {
        throw new Exception("'Signavio Host' is not configured.")
    }

    if (!properties.get("emNamespace")) {
        throw new Exception("'Event Mesh Namespace' is not configured.")
    }
    
    if (!properties.get("FCMHost") || properties.get("FCMHost").equals('https://')) {
        throw new Exception("'SAP Risk and Assurance Management Host' is not configured.")
    }
    
    if (!properties.get("retiredCategoryId")) {
        throw new Exception("'Dictionary Category for Retired Risks' is not configured.")
    }
    
    if (!properties.get("defaultCategoryId")) {
        throw new Exception("'Fallback Dictionary Category' is not configured.")
    }

    return message
}