import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import groovy.transform.Field

@Field static final String ATTACHMENTS_FORMAT = '[{"url": "%s","label": "RAM Control"}]'
@Field static final String ADDRESS_FORMAT = '%s/cp.portal/site#Control-display?ControlGUID=%s&sap-app-origin-hint=&/Controls(%s)'
@Field static final String META_CONTROL_GROUP = 'meta-ramcontrolgroup'
@Field static final String META_CONTROL_OWNER = 'meta-ramcontrolowner'
@Field static final String META_CONTROL_STATUS = 'meta-ramcontrolstatus'
@Field static final String META_LATEST_CONTROL_PERFORMANCE_RESULT = 'meta-ramlatestcontrolperformance'
@Field static final String META_LATEST_CONTROL_EFFECTIVENESS_TEST_RESULT = 'meta-ramlatesteffectivenesstestr'
@Field static final String META_LATEST_CONTROL_ASSESSMENT_RESULT = 'meta-ramlatestcontrolassessmentr'
@Field static final String META_CONTROL_TECHNICAL_ID = 'meta-ramcontroltechnicalid'
@Field static final String META_CONTROL_ID = 'meta-ramcontrolid'
@Field static final List SUPPORT_TYPES = ["MetaDataBoolean", "MetaDataDate", "MetaDataEnum", "MetaDataNumberInfo", "MetaDataStringInfo"]

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def controls = new JsonSlurper().parse(body).value
    def signavioMetadatas = message.getProperty('metadatas')
    def ramFieldsToSignavioAttributesMaps = message.getProperty('categoryValueMappingMap')
    def extensionFieldNameForSignavioCategory = message.getProperty('extensionFieldNameForSignavioCategory')
    def defaultActiveControlCategoryId =  message.getProperty("defaultCategoryId")
    def retiredControlCategoryId =  message.getProperty("retiredCategoryId")
    def signavioCategoryIds = message.getProperty('signavioCategoryIds')

    def signavioCreateControls = []
    def signavioUpdateControls = []
    def controlCount = controls.size()
    def topControl = Integer.valueOf(message.getProperty('topControl'))
    def skipControl = Integer.valueOf(message.getProperty('skipControl'))
    message.setProperty('skipControl', skipControl + topControl)
    message.setProperty('moreControls', topControl == controlCount)
    for (def control : controls) {
        def signavioControl = [:]
        def categoryIdInControl
        
        if (control.status == 'RETIRED') {
            if (null == control.externalId || control.externalId.length() == 0) {
                continue
            } else {
                signavioControl["category"] = retiredControlCategoryId
            }
        } else if (control.status == 'ACTIVE') {
            def categoryField = control.extensionFieldValues?.find{ it.fieldName == extensionFieldNameForSignavioCategory }
            if (categoryField != null && categoryField["fieldValue"] != null) {
                categoryIdInControl = categoryField["fieldValue"]
            } 
            
            if (categoryIdInControl != null && categoryIdInControl != 'null' && signavioCategoryIds != null && signavioCategoryIds.contains(categoryIdInControl)) {
                signavioControl["category"] = categoryIdInControl
            } else {
                signavioControl["category"] = defaultActiveControlCategoryId
            }
        }


        signavioControl["title"] = control.name
        signavioControl["description"] = control.description
        signavioControl["force"] = true
        signavioControl["fcmControlID"] = control.complianceControlId
        //set custom attribute

        def customAttribute = new HashMap()
        def fieldMappingsByCurrentCategory = ramFieldsToSignavioAttributesMaps.find{ it.key == "$signavioControl.category" }?.value    
        if (fieldMappingsByCurrentCategory != null && fieldMappingsByCurrentCategory.size() > 0) {
            control.extensionFieldValues?.each{mapRAMCustomDefineFieldToSignavioCusotmAttribute(it, fieldMappingsByCurrentCategory, signavioMetadatas, customAttribute)}
        }
        
        def standardFieldsForMapping = [[fieldName: 'controlRiskLevel', fieldValue: control.controlRiskLevel], [fieldName: 'significance', fieldValue: control.significance], [fieldName: 'operationFrequency', fieldValue: control.operationFrequency]]
        standardFieldsForMapping.each {
            mapRAMCustomDefineFieldToSignavioCusotmAttribute(it, fieldMappingsByCurrentCategory, signavioMetadatas, customAttribute)
        }
        
        setControlGroup(control, customAttribute)
        setOwner(control, customAttribute)
        setControlStatus(control, customAttribute)
        setLatestControlPerformanceResult(control, customAttribute)
        setLatestControlEffectivenessTestResult(control, customAttribute)
        setLatestControlAssessmentResult(control, customAttribute)
        
        customAttribute[META_CONTROL_ID] = control.displayId
        customAttribute[META_CONTROL_TECHNICAL_ID] = control.complianceControlId

        def customAttributeJson = new JsonBuilder(customAttribute)
        signavioControl["metaDataValues"] = customAttributeJson.toString()
        
        //set attachment URL
        setAttachmentURL(message, control, signavioControl)
        if (null == control.externalId || control.externalId.length() == 0) {
            // create
            signavioCreateControls.add(signavioControl)
        } else {
            //update
            signavioControl.id = control.externalId
            signavioUpdateControls.add(signavioControl)
        }
    }
    
    message.setProperty('signavioCreateControls', signavioCreateControls)
    message.setProperty('signavioUpdateControls', signavioUpdateControls)
    
    return message
}


def mapRAMCustomDefineFieldToSignavioCusotmAttribute(customRAMField, fieldMappings, signavioMetadatas, customAttribute) {
    def fieldMapping = fieldMappings.find{it.sourceIdentifier.equals(customRAMField.fieldName)}
    def targetIdentifier = fieldMapping?.targetIdentifier
    def metadata
    if (targetIdentifier != null) {
        metadata = signavioMetadatas.find{it.id.equals(targetIdentifier)}
    }
    
    if (metadata!= null && metadata.type != null) {
        // check type supported
        if (SUPPORT_TYPES.contains(metadata.type) == false) {
            return
        }
    }
    
    if (metadata != null && targetIdentifier != null) {
        def handler = getRAMCustomFieldValueHandler(metadata, fieldMapping, targetIdentifier)
        def signavioCustomAttributeValue = handler.convertRAMValueToSignavioValue(customRAMField)
        if (signavioCustomAttributeValue != null) {
            customAttribute."$targetIdentifier" = signavioCustomAttributeValue
        }
    }
}


interface RAMCustomFieldValueHandler {
  void setMetadata(metadata)

  Object convertRAMValueToSignavioValue(ramField)
}

def getRAMCustomFieldValueHandler(metadata, fieldMapping, targetIdentifier) {
  def handler;
  switch (metadata.type) {
    case "MetaDataBoolean":
      handler = new SignavioMetaBooleanValueHandler()
      break
    case "MetaDataEnum":
      handler = new SignavioMetaDataEnumHandler()
      break
    case "MetaDataNumberInfo":
      handler = new SignavioMetaNumberValueHandler()
      break
    case "MetaDataStringInfo":
      handler = new SignavioMetaStringValueHandler()
      break
    default:
      break
  }

  handler?.metadata = metadata
  handler?.fieldMapping = fieldMapping
  handler?.targetIdentifier = targetIdentifier

  return handler
}

abstract class SignavioMetadataSupportedValueHandler implements RAMCustomFieldValueHandler {
  Map metadata
  Map fieldMapping
  String targetIdentifier

  void setMetadata(metadata) {
    this.metadata = metadata
  }

  protected boolean onlyWildcards(List items) {
    return items.size() == 1 && items.find {"*".equals(it.source)} != null && items.find {"*".equals(it.target)} != null
  }
}

class SignavioMetaBooleanValueHandler extends SignavioMetadataSupportedValueHandler {
  Object convertRAMValueToSignavioValue(ramField) {
    def signavioBooleanValue = null
    if (ramField.fieldName?.startsWith("Z_") && ramField.fieldName?.endsWith("_code")) {
      String valuePrefix = ramField.fieldName.substring(2, ramField.fieldName.length() - 5)
      // _1- true _2-false
      if (ramField.fieldValue?.equals(valuePrefix + "_1")) {
        signavioBooleanValue = true
      } else {
        signavioBooleanValue = false
      }
    }

    return signavioBooleanValue
  }
}

class SignavioMetaNumberValueHandler extends SignavioMetadataSupportedValueHandler {
  Object convertRAMValueToSignavioValue(ramField) {
    return ramField.fieldValue
  }
}


class SignavioMetaDataEnumHandler extends SignavioMetadataSupportedValueHandler {
  Object convertRAMValueToSignavioValue(ramField) {
    List metadataItems = metadata["items"]
    List valueMappings = fieldMapping.valueMappings
   
    def potentialValueMappings = valueMappings.findAll { it.source == ramField.fieldValue }
    if (potentialValueMappings.isEmpty()) {
        return
    }
    def signavioAttributeValueInFieldMapping
    if (potentialValueMappings.size() > 1) {
      signavioAttributeValueInFieldMapping = potentialValueMappings.find { it.defaultMapping == true }.target
    } else {
      signavioAttributeValueInFieldMapping = potentialValueMappings[0].target
    }
    
    def signavioValue = metadataItems?.find{it["title"].equals(signavioAttributeValueInFieldMapping)}.value
    return signavioValue
  }
}

class SignavioMetaStringValueHandler extends SignavioMetadataSupportedValueHandler {
  Object convertRAMValueToSignavioValue(ramField) {
    return ramField.fieldValue
  }
}

private void setAttachmentURL(message, control, signavioControl) {
    def FCMControlAddress = message.getProperty('FCMHost')
    def ramUrl = URLEncoder.encode(String.format(ADDRESS_FORMAT, FCMControlAddress, control.complianceControlId, control.complianceControlId))
    def attachments = String.format(ATTACHMENTS_FORMAT, ramUrl)
    signavioControl["attachments"] = attachments
}

private void setOwner(control, customAttribute) {
    def ownerAndIdentify = ''
    def owners = control.owner
    if (owners) {
        for (def owner : owners) {
            ownerAndIdentify = ownerAndIdentify + owner.userName + ' (' + owner.userMail + ') · '
        }
        customAttribute[META_CONTROL_OWNER] = ownerAndIdentify.substring(0, ownerAndIdentify.length() - 2)
    }
}

private void setControlGroup(control, customAttribute) {
    def controlGroups = control.controlGroup
    if (controlGroups) {
        def controlGroupName = ''
        for (def controlGroup : controlGroups) {
            controlGroupName = controlGroupName + controlGroup.name + ' · '
        }
        customAttribute[META_CONTROL_GROUP] = controlGroupName.substring(0, controlGroupName.length() - 2)
    }
}

private void setControlStatus(control, customAttribute) {
    // RETIRED -> Retired ACTIVE -> Active
    def controlStatus = control.status
    if (controlStatus) {
        customAttribute[META_CONTROL_STATUS] = controlStatus.toLowerCase().capitalize()
    }
}
        
private void setLatestControlPerformanceResult(control, customAttribute) {
    def latestControlPerformanceResult = control.latestControlPerformanceResult
    if (latestControlPerformanceResult) {
        customAttribute[META_LATEST_CONTROL_PERFORMANCE_RESULT] = latestControlPerformanceResult.resultName
    }
}

private void setLatestControlEffectivenessTestResult(control, customAttribute) {
    def latestControlEffectivenessTestResult = control.latestControlEffectivenessTestResult
    if (latestControlEffectivenessTestResult) {
        customAttribute[META_LATEST_CONTROL_EFFECTIVENESS_TEST_RESULT] = latestControlEffectivenessTestResult.resultName
    }
}

private void setLatestControlAssessmentResult(control, customAttribute) {
    def latestControlAssessmentResult = control.latestControlAssessmentResult
    if (latestControlAssessmentResult) {
        customAttribute[META_LATEST_CONTROL_ASSESSMENT_RESULT] = latestControlAssessmentResult.resultName
    }
}