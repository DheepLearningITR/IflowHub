import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    int statusCode =  ((Integer) message.getHeaders().get("camelhttpresponsecode")).intValue();
    def NOT_FOUND = 'platform.dispatcher.sboNotFound'
    def signavioUpdateControls = message.getProperty('signavioUpdateControls')
    def ramControl = message.getProperty('signavioUpdateControl')
    
    if (statusCode != 200) {
        def exceptions = new JsonSlurper().parse(body)
        def errors = exceptions.errors
        def metaDataValues = ramControl?.metaDataValues
        def metaDataValuesMap = new JsonSlurper().parseText(metaDataValues)
        def controlStatus = metaDataValuesMap['meta-ramcontrolstatus']
        if (null != errors && NOT_FOUND.equals(errors[0]) && controlStatus != null && controlStatus != 'Retired') {
            def signavioCreateControls = message.getProperty('signavioCreateControls')
            def signavioControl = signavioUpdateControls[signavioUpdateControls.size() - 1]
            signavioControl.isEncoded = 'true'
            signavioCreateControls.add(signavioControl)
            message.setProperty('signavioCreateControls', signavioCreateControls)
        }
           
    }
    
    signavioUpdateControls.remove(signavioUpdateControls.size() - 1)
    return message
}