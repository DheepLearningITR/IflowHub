import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def categories = new JsonSlurper().parse(body)
    def defaultActiveControlCategoryId =  message.getProperty("defaultCategoryId")
    def retiredControlCategoryId =  message.getProperty("retiredCategoryId")
    def signavioControlCategoriesMappings = message.getProperty("signavioControlCategoriesMappings")
    def signavioCategoryIds = []
    categories?.each{extractCategoryIds(it, signavioCategoryIds)}

    checkCategoryExists(signavioCategoryIds, defaultActiveControlCategoryId)
    checkCategoryExists(signavioCategoryIds, retiredControlCategoryId)

    def valueMappingMetaMapList = []
    
    if (signavioControlCategoriesMappings.isEmpty()) {
        return message
    } else {
        def categoryValueMappingIdVersionStrings = signavioControlCategoriesMappings.split(';')
        if (categoryValueMappingIdVersionStrings && categoryValueMappingIdVersionStrings.size() > 0) {
            for( String categoryValueMappingIdVersionString : categoryValueMappingIdVersionStrings ) {
                def configItems =  categoryValueMappingIdVersionString.split(':')
                if (configItems && configItems.size() == 3) {
                    checkCategoryExists(signavioCategoryIds, configItems[0])
                    def valueMappingMetaMap = [:]
                    valueMappingMetaMap.put("categoryId", configItems[0])
                    valueMappingMetaMap.put("valueMappingId", configItems[1])
                    valueMappingMetaMap.put("valueMappingVersion", configItems[2])
                    valueMappingMetaMapList.add(valueMappingMetaMap)
               
                }
            }
        }
    }
    
    
    message.setProperty('signavioCategoryIds', signavioCategoryIds)
    message.setProperty("valueMappingMetaMapListSize", valueMappingMetaMapList.size())
    message.setProperty("valueMappingMetaMapList", valueMappingMetaMapList)
   
    return message
}

def extractCategoryIds(glossaryCategory, signavioCategoryIds) {
    signavioCategoryIds.add(extractCategoryId(glossaryCategory?.rep?.id))
    glossaryCategory?.rep?.childCategories?.each{signavioCategoryIds.add(extractCategoryId(it))}
    return signavioCategoryIds
}


def extractCategoryId(category) {
    if (category != null) {
        return category.split('/')[2]
    }

}

def checkCategoryExists(signavioCategoryIds, categoryId) {
    if (!signavioCategoryIds.contains(categoryId)) {
        throw new Exception("Configured dictionary category " + categoryId +" doesn't exist.")
    }
}