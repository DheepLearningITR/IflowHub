import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def signavioUpdateControls = message.getProperty('signavioUpdateControls')
    def signavioUpdateControl = signavioUpdateControls[signavioUpdateControls.size() - 1]
    message.setProperty('signavioControlId', signavioUpdateControl.id)
    message.setProperty('signavioUpdateControl', signavioUpdateControl)
    return message
}
