import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil

def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String);
       
    def rootNode = new XmlSlurper().parseText(body)
    def bpAddressCount = 0;
    
    //Removing Business Partner of type Contact Person from the payload and summing up the number of addresses for Business Partner
    rootNode.BusinessPartnerSUITEReplicateRequestMessage.each { it ->  
        if(it.BusinessPartner.CategoryCode.text() != '2'){
            it.replaceNode {}
        } else {
            bpAddressCount += it.BusinessPartner.AddressInformation.size()
        }
    }

    //Removing the deleted addresses and modifying the address count
    rootNode.BusinessPartnerSUITEReplicateRequestMessage[0].BusinessPartner.AddressInformation.each{
        if(it.@actionCode == '05'){
            it.replaceNode{}
            bpAddressCount -= 1
        }
    }
    message.setProperty("numberOfAddresses", bpAddressCount)
    message.setBody(XmlUtil.serialize(rootNode))
     
    return message;
}