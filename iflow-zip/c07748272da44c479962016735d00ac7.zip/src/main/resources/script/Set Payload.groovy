import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    
    def map = message.getProperties();
    message.setBody(map.Payload);
       
    return message;
}