import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
      
      def header = message.getHeaders();
      
      def body = message.getBody(java.io.Reader);
      def xml = new XmlSlurper().parse(body);
      def elementId = xml.describeSFObjectsEx.type.text();

	  if (elementId == "Background_varPayEmpHistData"){
	  //Special check for VarPay since the entity name has slightly changed in Odata
	  	elementId = "Background_VarPayEmpHistData";
	  };    
      
      
      header.put("elementId", elementId);  
      return message;
}