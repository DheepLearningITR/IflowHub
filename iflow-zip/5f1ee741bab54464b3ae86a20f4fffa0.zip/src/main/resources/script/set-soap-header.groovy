import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.cxf.binding.soap.SoapHeader;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

def Message processData(Message message){
    def cmlcSessionId = message.getProperty("cmlc-session-id") as String;
    def cmlcSessionPassword = message.getProperty("cmlc-session-password") as String;
    def cmlcOperation = message.getProperty("cmlc-operation") as String;
    def cmlcUsername = message.getProperty("username") as String;
    // def cmlcMessageID = message.getProperty("cmlc-message-id") as String;
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    dbf.setNamespaceAware(true);
    dbf.setIgnoringElementContentWhitespace(true);
    dbf.setValidating(false);
    DocumentBuilder db = dbf.newDocumentBuilder();

    Document docIpAddress = db.newDocument();
    Element ipAddress = docIpAddress.createElementNS("http://wibu.com/", "IPAddress");
    ipAddress.setTextContent("127.0.0.1")
    docIpAddress.appendChild(ipAddress);

    Document docReplyTo = db.newDocument();
    Element replyTo = docReplyTo.createElementNS("http://schemas.xmlsoap.org/ws/2004/08/addressing", "ReplyTo");
    Element replyToAddress = docReplyTo.createElementNS("http://schemas.xmlsoap.org/ws/2004/08/addressing", "Address");
    replyToAddress.setTextContent("http://www.w3.org/2005/08/addressing/anonymous");
    replyTo.appendChild(replyToAddress);
    Element replyToReferenceParameters = docReplyTo.createElementNS("http://schemas.xmlsoap.org/ws/2004/08/addressing", "ReferenceParameters");
    replyTo.appendChild(replyToReferenceParameters);
    Element serviceGroupId = docReplyTo.createElementNS("http://schemas.xmlsoap.org/ws/2004/08/addressing", "ServiceGroupId");
    serviceGroupId.setTextContent(cmlcSessionId);
    replyToReferenceParameters.appendChild(serviceGroupId)
    docReplyTo.appendChild(replyTo);


    Document docTo = db.newDocument();
    Element to = docTo.createElementNS("http://schemas.xmlsoap.org/ws/2004/08/addressing", "To");
    to.setTextContent("1");
    docTo.appendChild(to);

    Document docAction = db.newDocument();
    Element action = docAction.createElementNS("http://schemas.xmlsoap.org/ws/2004/08/addressing", "Action");
    action.setTextContent(cmlcOperation);
    docAction.appendChild(action);

    Document docMessageId = db.newDocument();
    Element messageId = docMessageId.createElementNS("http://schemas.xmlsoap.org/ws/2004/08/addressing", "MessageID");
    messageId.setTextContent("1");
    docMessageId.appendChild(messageId);

    Document docSecurity = db.newDocument();
    Element security = docSecurity.createElementNS("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd", "Security");
    security.setAttribute("mustUnderstand", "1");
    docSecurity.appendChild(security);
    Element usernameToken = docSecurity.createElementNS("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd", "UsernameToken");
    security.appendChild(usernameToken);
    Element username = docSecurity.createElementNS("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd", "Username");
    username.setTextContent(cmlcUsername);
    usernameToken.appendChild(username);
    Element password = docSecurity.createElementNS("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd", "Password");
    password.setAttribute("Type", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText");
    password.setTextContent(cmlcSessionPassword)
    usernameToken.appendChild(password);

    List headerList = new ArrayList<SoapHeader>();
    SoapHeader headerIpAddress = new SoapHeader(new QName(ipAddress.getNamespaceURI(), ipAddress.getLocalName()), ipAddress);
    headerList.add(headerIpAddress);

    SoapHeader headerReplyTo = new SoapHeader(new QName(replyTo.getNamespaceURI(), replyTo.getLocalName()), replyTo);
    headerList.add(headerReplyTo);

    SoapHeader headerTo = new SoapHeader(new QName(to.getNamespaceURI(), to.getLocalName()), to);
    headerList.add(headerTo);

    SoapHeader headerAction = new SoapHeader(new QName(action.getNamespaceURI(), action.getLocalName()), action);
    headerList.add(headerAction);

    SoapHeader headerMessageId = new SoapHeader(new QName(messageId.getNamespaceURI(), messageId.getLocalName()), messageId);
    headerList.add(headerMessageId);

    SoapHeader headerSecurity = new SoapHeader(new QName(security.getNamespaceURI(), security.getLocalName()), security);
    headerList.add(headerSecurity);

    message.setHeader("org.apache.cxf.headers.Header.list", headerList);
    return message;
}
