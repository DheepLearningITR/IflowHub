import com.sap.gateway.ip.core.customdev.util.Message;

def Message addAttachment(Message message) {
    def body = message.getBody(java.lang.String);
    def attachmentName = message.getProperty("attachmentName") as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        messageLog.addAttachmentAsString(attachmentName, body, "text/plain");
    }
    return message;
}

def Message addStringProperty(Message message) {
    def logName = message.getProperty("logName") as String;
    def logValue = message.getProperty("logValue") as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null && logValue != null) {
        messageLog.setStringProperty(logName, logValue);
    }
    return message;
}

def Message addCustomHeader(Message message) {
    def customHeaderID = message.getProperty("customHeaderID") as String;
    def customHeaderValue = message.getProperty("customHeaderValue") as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null && customHeaderValue != null) {
        messageLog.addCustomHeaderProperty(customHeaderID, customHeaderValue);
    }
    return message;
}
