import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.ITApiFactory;

def Message processData(Message message){
    def CredentialAlias = message.getProperty("CMLC-Basic-Credential")
    def secureStoreService = ITApiFactory.getService(SecureStoreService.class, null)
    def credential = secureStoreService.getUserCredential(CredentialAlias)
    def credentialProperties = credential.getCredentialProperties()
    message.setProperty("username", credential.getUsername())
    message.setProperty("password", credential.getPassword())
    return message;
}
