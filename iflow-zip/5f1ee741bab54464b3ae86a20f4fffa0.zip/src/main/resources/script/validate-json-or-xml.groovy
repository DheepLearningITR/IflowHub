import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message validateJSON(Message message) {
    try{
        def body = message.getBody(java.lang.String);
        new JsonSlurper().parseText(body);
        message.setProperty("validJSON", "true");
    } catch (groovy.json.JsonException e){
        message.setProperty("validJSON", "false");
    }
    return message;
}

def Message processData(Message message) {
    validateJSON(message)
}
