/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

    def properties = message.getProperties();
    def ex = properties.get("CamelExceptionCaught");

    if (ex!=null) {
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
            message.setBody(ex.getResponseBody());
            message.setProperty("http.ResponseBody", ex.getResponseBody());
            message.setProperty("http.StatusCode", ex.getStatusCode());
            message.setProperty("http.StatusText", ex.getStatusText());
        } else if (ex.getClass().getCanonicalName().equals("java.net.UnknownHostException")) {
            message.setBody("{ \"status\": 400, \"type\": \"unable_to_determine_tax_engine\", \"message\": \"The SAP tax partner configured in iFlow does not exist, is unavailable, or cannot process the payload request due to a high load. Review the configurations for Cloud Platform Integration iFlow and if the error persists, contact your SAP tax partner.\" }");
            message.setProperty("http.StatusCode", "400");
            message.setHeader("CamelHttpResponseCode", "400")
        } else {
            message.setBody("{ \"status\": 400, \"type\": \"bad_request\", \"message\": \"${ex.message}\" }");
            message.setProperty("http.StatusCode", "400");
            message.setHeader("CamelHttpResponseCode", "400")
        }
    } else {
        message.setBody("{ \"status\": 500, \"type\": \"server_exception\", \"message\": \"${ex.message}\"  }");
        message.setProperty("http.StatusCode", "500");
        message.setHeader("CamelHttpResponseCode", "500")
    }
    

    return message;
        
}