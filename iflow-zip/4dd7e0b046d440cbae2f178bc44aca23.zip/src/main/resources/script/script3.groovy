/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
import java.lang.String;


def Message processData(Message message) {
    
    def properties = message.getProperties();
    def cException = properties.get("CamelExceptionCaught");
    def headers     = message.getHeaders();
    def excmsg     = properties.get("exceptionMessage");
    String errorMessage;
    String cExceptionMessage;
    String errorCode;
    String substr;
    
   
 if (cException.getClass().getCanonicalName().equals("com.google.common.util.concurrent.UncheckedExecutionException")) {        
        String exceptionBody = properties.get("exceptionBody")
        if(exceptionBody != null) {
          message.setBody(exceptionBody)
        }  
      
        errorCode = "02";
       cExceptionMessage = cException.getMessage();
       if (cExceptionMessage.substring(cExceptionMessage.indexOf("code",1)+5, 51) == "504")
       {
         errorCode = "02";
         errorMessage = "Gateway Time-out. The ETA server did not response in time";
         
       } else
       {
       errorMessage = "Refer the Message Id " + headers.get("SAP_MessageProcessingLogID"); 
       }
     
    } else{
        errorCode = '03';
        errorMessage = "Refer the Message Id " + headers.get("SAP_MessageProcessingLogID"); 
     
    }
     message.setProperty("exceptionMessage", errorMessage);
     message.setProperty("HTTPError", errorCode);
     
    return message;
}