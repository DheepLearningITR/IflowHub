/*
 * =============================================================================
 * Logic Details 
 * =============================================================================
 *   1. Retrieves message properties such as `Adhoc_StartDate(3)`, `ExecuteFullLoad(1)`, `LastRun`, `PreDefinedStartDate(2)`, and `MSDObject`.
     2. Determines the `LoadType` (either "FullLoad" or "DeltaLoad") based on the `ExecuteFullLoad` flag.
     3. Constructs a dynamic filter (`WhereClause`) based on the `LastModified` date, which is derived from `Adhoc_StartDate`, `PreDefinedStartDate`, or `LastRun(4)`. This filter is applied to either `createdon` or `modifiedon` fields, depending on whether the `MSDObject` contains "audits".
     4. Builds an `ExtendedQuery` to add an additional filter for the `objecttypecode` when the `MSDObject` involves "audits", using different object types such as "lead", "opportunity", or "quote".
     5. Creates an `ExpandQuery` to handle entity-specific expansions for `quotes`, `opportunities`, `systemusers`, `leads`, and `activitypointers`.
     6. Sets the dynamically generated queries (`WhereClause`, `ExtendedQuery`, `ExpandQuery`) and `LoadType` as message properties.
     7. Returns the modified message with the updated properties.
 * Priorities of the if statements is mentioned beside the property names.
 * ==============================================================================
*/

import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    			
        def properties = message.getProperties();
		def Adhoc_StartDate = properties.get("Adhoc_StartDate");
		def ExecuteFullLoad = properties.get("ExecuteFullLoad");
		def LastRun = properties.get("last_run");
		def PreDefinedStartDate = properties.get("PreDefinedStartDate");
		def MSDObject = properties.get("MSDObject");
		def LoadType = "";
		def LastModified = "";
		
        
		StringBuffer str1 = new StringBuffer();
	
		if(ExecuteFullLoad != null && ExecuteFullLoad.equalsIgnoreCase("TRUE"))
		{
		    str1.append();         // 1
		    LoadType = "FullLoad"
		}
		else
		{   
		    LoadType = "DeltaLoad"
		    if(PreDefinedStartDate == null || PreDefinedStartDate.equals(""))
		        {

                    if(Adhoc_StartDate == '')
                        {
                            //Assign last_run Date from variable
                            LastModified = LastRun;
                            if(MSDObject.toString().contains("audits"))
                            {
                                str1.append('&$filter=createdon%20ge%20'+LastModified+"");
                            }
                            else
                            {
                                str1.append('&$filter=modifiedon%20ge%20'+LastModified+"");
                            }
                        }
                    else
                        {
                            //Assign last_run Date from Externalized variable
                            LastModified = Adhoc_StartDate;
                            if(MSDObject.toString().contains("audits"))
                            {
                                str1.append('&$filter=createdon%20ge%20'+LastModified+"");
                            }
                            else
                            {
                                str1.append('&$filter=modifiedon%20ge%20'+LastModified+"");
                            }
                        }
		        }
		    else
		        {
		            //Assign last_run Date from Value Mapping
		                    LastModified = PreDefinedStartDate;
		                    if(MSDObject.toString().contains("audits"))
                            {
                                str1.append('&$filter=createdon%20ge%20'+LastModified+"");
                            }
                            else
                            {
		                        str1.append('&$filter=modifiedon%20ge%20'+LastModified+"");
                            }
		        }
        
		}
		

		def whereClause = str1.toString()
		

	    if(!str1.toString().isEmpty())
	    {
			message.setProperty("WhereClause",""+whereClause);
		}
		else
		{
			message.setProperty("WhereClause",""+whereClause);
		}
		
		StringBuffer str2 = new StringBuffer();
		
        if (MSDObject.toString().contains("audits")) 
        {
            def objectTypeCode = null

        if (MSDObject.toString().contains("leads")) 
        {
            objectTypeCode = "lead"
        } 
        else if (MSDObject.toString().contains("opportunities")) 
        {
            objectTypeCode = "opportunity"
        } 
        else 
        {
            objectTypeCode = "quote"
        }

        if (objectTypeCode != null) 
        {
            if (LoadType == "FullLoad") 
            {
                str2.append("&\$filter=objecttypecode%20eq%20%27${objectTypeCode}%27")
            } 
            else 
            {
                str2.append("%20and%20objecttypecode%20eq%20%27${objectTypeCode}%27")
            }
        }

        message.setProperty("MSDObject", "audits")
    }
    

		def ExtendedQuery = str2.toString()
		
		if(!str2.toString().isEmpty())
	    {
			message.setProperty("ExtendedQuery","  "+ExtendedQuery);
		}
		else
		{
			message.setProperty("ExtendedQuery","  "+ExtendedQuery);
		}
		
	    
	    StringBuffer str3 = new StringBuffer();
		
        if (MSDObject == 'quotes')
        {
            str3.append('&$expand=transactioncurrencyid%28$select=currencyname%29') 
        }
        else if (MSDObject =='opportunities')
        {
            str3.append('&$expand=transactioncurrencyid%28$select=currencyname%29%2Coriginatingleadid%28$select=leadsourcecode%29')
        }
        else if (MSDObject =='systemusers')
        {
            str3.append('&$expand=organizationid_organization%28$select=name%29%2Cbusinessunitid%28$select=name%2Cdivisionname%29')
        }
        else if (MSDObject =='leads')
        {
            str3.append('&$expand=owningbusinessunit%28$select=name%29')  
        }
        else if (MSDObject =='activitypointers')
        {
            str3.append('&$expand=regardingobjectid_opportunity%28$select=opportunityid%2C_parentaccountid_value%29%2Cregardingobjectid_lead%28$select=leadid%2C_parentaccountid_value%29')  
        }
        
		
		def ExpandQuery = str3.toString()
		
		if(!str3.toString().isEmpty())
	    {
			message.setProperty("ExpandQuery","  "+ExpandQuery);
		}
		else
		{
			message.setProperty("ExpandQuery","  "+ExpandQuery);
		}
		
	message.setProperty("LoadType", LoadType)
	
    return message;
}
