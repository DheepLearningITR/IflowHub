/*
 * =============================================================================
 * Logic Details 
 * =============================================================================
 *  This groovy converts the payloaf from JSON to XML format
 * ==============================================================================
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) 
{
    // Body
    def body = message.getBody(java.lang.String)
    def json = new JsonSlurper().parseText(body)

    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)

    xml.response {
        entry {
            // Add odata.context and odata.nextLink as separate elements
            'odata.context'(json.response.entry.'@odata.context')
            'odata.nextLink'(json.response.entry.'@odata.nextLink')
            
            // Process each value in the list
            json.response.entry.value.each { val ->
                value {
                    'odata.etag'(val.'@odata.etag')
                    val.each { key, value ->
                        if (!key.startsWith('@')) {
                            "$key"(value ?: '')
                        }
                    }
                }
            }
        }
    }
    
    // Set the XML string as the message body with XML declaration
    def xmlString = '<?xml version="1.0" encoding="UTF-8"?>\n' + writer.toString()
    message.setBody(xmlString)
    return message
}