import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi


def Message processData(Message message) 
{
    //Properties
    def properties = message.getProperties();
    def MSDObject = properties.get("MSDObject");
    
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def value = valueMapApi.getMappedValue('MSDynamicsCRM', 'ObjectName', MSDObject, 'Signavio', 'InclusionFields')

    message.setProperty("InclusionFields", value );
    return message;
}