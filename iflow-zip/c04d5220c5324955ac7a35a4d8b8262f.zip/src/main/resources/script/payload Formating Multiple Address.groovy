import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    body = body.replace("{\"@xsi:nil\":\"true\"}","null");
    def jsonParser = new JsonSlurper();
    if(body.indexOf('[',0) == -1 )
    {
       body = "[" + body  + "]";
        
    }
    def jsonObject = jsonParser.parseText(body);
    message.setBody(JsonOutput.toJson(jsonObject["MultiAddress"])); 
    return message;
}