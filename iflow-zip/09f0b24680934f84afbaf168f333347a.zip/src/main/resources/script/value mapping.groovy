import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;


def Message processData(Message msg) {
    def helperValMap = ITApiFactory.getApi(ValueMappingApi.class, null)
    def properties = msg.getProperties();

    def input = properties.get('rcvprn_logsys');
    def url = helperValMap.getMappedValue('GK', 'rcvprn_logsys', input , 'SAP', 'sap_binding_url_idoc');
    def credentials = helperValMap.getMappedValue('GK', 'rcvprn_logsys', input , 'SAP', 'sap_credential_id_idoc');
    def carcloudconnectionid = helperValMap.getMappedValue('GK', 'rcvprn_logsys', input , 'SAP' , 'sap_cloud_connector_id');
   
    msg.setProperty( 'binding_url', url );
    msg.setProperty( 'credentials_id', credentials);
    msg.setProperty( 'cloud_connector_id', carcloudconnectionid);
    
	return msg;
	
}