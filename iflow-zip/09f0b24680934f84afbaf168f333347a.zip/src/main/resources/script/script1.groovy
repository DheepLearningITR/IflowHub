/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {
    //Properties
    //String soapEnvBefore = '<soap-env:Envelope xmlns:soap-env="http://schemas.xmlsoap.org/soap/envelope/"><soap-env:Header/><soap-env:Body></soap-env:Body></soap-env:Envelope>';
    //def soapNode = new XmlParser().parseText( soapEnvBefore );    
    
    def map = message.getProperties();
    //def sndpor = map.get('SNDPOR');
    //def recvpor = map.get('RCVPOR');
    //Body 
    def root = new XmlParser().parse(message.getBody());
    
    if ( !map.get('SNDPOR_ORIG').trim() ){
        root.IDOC.EDI_DC40[0].SNDPOR[0].value = map.get('SNDPOR');
    }
    
    if ( !map.get('RCVPOR_ORIG').trim() ){
        root.IDOC.EDI_DC40[0].RCVPOR[0].value = map.get('RCVPOR'); 
    }
    //def edibloc = root.IDOC.EDI_DC40[0].children();
    
    //def docnum_node = new Node(null, 'DOCNUM', docnum);
    //edibloc.add(2, docnum_node);
    
    //soapNode.'soap-env:Body'[0].append( root );
    String outxml = groovy.xml.XmlUtil.serialize( root );
    message.setBody(outxml); 
    
    return message;
}