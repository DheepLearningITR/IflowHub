import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

 
 def Message processData(Message message) {

    def (pMap) = [];
    def (last_run_date,no_run_date,my_date,event) = [];
  
  // String date = "1900-01-01T00:00:00Z";
   def messageLog = messageLogFactory.getMessageLog(message); 
   pMap = message.getProperties();
   hMap = message.getHeaders();
    
   event = pMap.get("event").toString();
   last_run_date = hMap.get(event).toString();
  // last_run_date = "2019-05-20T00:00:00Z"
  no_run_date = "1900-01-01T00:00:00Z";

     if (last_run_date!= "null")
       {
           my_date = last_run_date; 
           
       }
      
       else 
       my_date=no_run_date;
         
    message.setProperty("LastRunDate",my_date);
 
    return message;
}

