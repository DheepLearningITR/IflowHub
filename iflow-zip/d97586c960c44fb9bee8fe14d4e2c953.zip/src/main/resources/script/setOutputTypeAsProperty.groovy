import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {

    def log = messageLogFactory.getMessageLog(message)
    def outputType = message.getProperty("OutputType")

    if (outputType != null) {
        def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)

        if (valueMapApi != null) {
            try {
                def senderAgency = "Corevist"
                def senderSchema = "DocumentType"
                def receiverAgency = "S4HANA"
                def receiverSchema = "ProcessDirect"

                def processDirect = valueMapApi.getMappedValue(senderAgency, senderSchema, outputType, receiverAgency, receiverSchema)
                message.setProperty("ProcessDirect", processDirect)

                if (log != null) {
                    log.addCustomHeaderProperty("ValueMappingInfo", "Mapped " + outputType + " → " + processDirect)
                }

            } catch (Exception e) {
                message.setProperty("ProcessDirect", "Mapping_Not_Found")
                if (log != null) {
                    log.addAttachmentAsString("ValueMappingError", e.message, "text/plain")
                }
            }
        } else {
            message.setProperty("ProcessDirect", "ValueMappingApi_Not_Available")
        }

        message.setProperty("OUTPUT_TYPE", outputType)
    }

    return message
}