// =============================================================================================
// History: 
// 2023-07-11 SAP [GS] - ACTUAL_PARTNER_ID changed to SAP_TPM_PARTNER_ID
// 2023-01-25 SAP [AG] - Read dynamic expression and update it with parameter values
// 2023-04-12 SAP [AG] - Removed the uasge if Apache Libraries as their support is restricted in 
//                       upcoming release. (Using standard groovy functions)
// =============================================================================================
import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import groovy.json.JsonSlurper;
import com.sap.it.api.pd.BinaryData;

def Message processData(Message message) {
    
    def recFileName;
    def messageLog = messageLogFactory.getMessageLog(message);
    StringBuilder builder = new StringBuilder();
 
    Pattern pattern = Pattern.compile("\\\$\\{(.+?)\\}");
    def headers = message.getHeaders();
    def properties = message.getProperties();
    def partnerID = headers.get("SAP_TPM_ACTIVITYPARTNER_ID");
    
    def service = ITApiFactory.getService(PartnerDirectoryService.class, null);
    if(service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }
    
    customActivityParams = service.getParameter("SAP_TPM_CustomActivityParams", partnerID, BinaryData.class);
 
    if (customActivityParams != null){
        def customActivityParamsStr = new String(customActivityParams.getData());
        def customActivityParamsJson = new JsonSlurper().parseText(customActivityParamsStr);
        customActivityParamsJson.each{
            paramKey, dynExpression ->
// Read the dynamic header expression
            if( dynExpression.contains( 'expression' ) ){
                Matcher matcher = pattern.matcher(dynExpression);
                def rebuiltExpression = dynExpression;
             
                while(matcher.find()){
                    def wholeExpression = matcher.group();
                    def effectiveExpression = matcher.group(1);
             
                    def expressionValue = processExpression(headers, properties, effectiveExpression);
                    if (expressionValue == null){
                        rebuiltExpression = rebuiltExpression.replace(wholeExpression, "null");
                    }else{
                        rebuiltExpression = rebuiltExpression.replace(wholeExpression, expressionValue);
                    }
                }
                rebuiltExpression = rebuiltExpression.replaceAll(/expression|\[|\]/, "");
                paramValue = rebuiltExpression;
                
                messageLog.addAttachmentAsString("debug_log.log", builder.toString(), "text/plain");
            }else{
                paramValue = dynExpression;        
            }
            message.setProperty(paramKey, paramValue);
            message.setHeader(paramKey, paramValue);
        }
    }
    return message
}
 
def String processExpression(Map<String, Object> headers,  Map<String, Object> properties, String exp){
    if (exp.startsWith("header") || exp.startsWith("property")){
        def variable = exp.split("\\.")[1];
        def replaceIndex = exp.indexOf("replace");
        String val;
        
        if(exp.startsWith("header")){
            val = headers.get(variable);
        }else if(exp.startsWith("property")){
            val = properties.get(variable);
        }
        
        if (val == null) {
            val = 'null';
        }
        
        if (replaceIndex > -1){
            def replaceOperands = exp.substring(exp.indexOf("(", replaceIndex)+1, exp.indexOf(")", replaceIndex));
            def pattern = replaceOperands.split(",")[0].trim().replaceAll("\"|\'", "").replaceAll("\\\\\\\\", "\\\\");
            def value = replaceOperands.split(",")[1].trim().replaceAll("\"|\'", "");
            return val.replaceAll(pattern, value);
        }else if (exp.indexOf("substring") > -1){
            replaceIndex = exp.indexOf("substring");
            replaceOperands = exp.substring(exp.indexOf("(", replaceIndex)+1, exp.indexOf(")", replaceIndex));
            pattern = replaceOperands.split(",")[0].trim().toInteger();
            value = replaceOperands.split(",")[1].trim().toInteger();
            return val.substring(pattern, value);
        }else{
            return val;
       }
    }
    //e.g. ${date-with-timezone:now:Australia/Melbourne:yyyyMMddHHmmss}
    if (exp.startsWith("date-with-timezone")){
        def groups = exp.split(":");
        def period = groups[1]
        def tz = groups[2]
        def pattern = groups[3]
 
        if (period == "now"){
            SimpleDateFormat format = new SimpleDateFormat(pattern);
            format.setTimeZone(TimeZone.getTimeZone(tz))
            return format.format(new Date())
        }
    }
        
    //current date e.g. ${date:now:HHmmssSSS}
    if (exp.startsWith("date")){
        def groups = exp.split(":");
        def period = groups[1]
        def pattern = groups[2]
 
        if (period == "now"){
            SimpleDateFormat format = new SimpleDateFormat(pattern);
            return format.format(new Date())
        }
    }
    
    return null;
}    