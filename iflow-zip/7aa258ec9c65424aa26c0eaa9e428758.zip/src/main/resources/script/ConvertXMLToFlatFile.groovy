/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.delaware.conversion.XMLToFlatFileConverter;
def Message processData(Message message) {
    //Get Source XML
    def source = message.getBody(java.lang.String) as String;
    
    //Get Configuration
    def map = message.getProperties();
    def config = map.get("Config");
    
    //Convert source using configuration
    def converter = new XMLToFlatFileConverter();
    def flatfile = converter.run(config, source);
    
    //Set message body
    message.setBody(flatfile);
    
    return message;
}