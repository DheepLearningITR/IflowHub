/*==============================================================================
This Script Reads Ids from input body and set them as custom Headers 
================================================================================
*/
import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) 
{

    
	def messageLog = messageLogFactory.getMessageLog(message);
	def body = message.getBody(java.lang.String) as String;
	
	if(messageLog != null)
	
	{
        def doc = new XmlSlurper().parseText(body);
        
        String str = ""; 
        def Ids = message.getHeaders().get("Ids");
        
        doc.'**'.findAll { it.name() == 'records' }.each
        {
            str=it.Id.text();
            if(Ids == null)
            {
                 Ids = str+"\n";
            }
            else
            {
                 Ids = Ids+str+"\n";    
            }
            
			messageLog.addCustomHeaderProperty("ID", str);	
        }
	}

	return message;
}