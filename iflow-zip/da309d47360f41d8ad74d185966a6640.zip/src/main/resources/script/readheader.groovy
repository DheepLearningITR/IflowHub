package script

import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    headers = message.getSoapHeaders()

    message.setProperty("headerSize", headers.size())
    if (headers.size() < 1) {
        return message
    }

    for (def header in headers) {
        message.setProperty(UUID.randomUUID().toString(), header.getQname().getLocalPart())
        def qName = header.getQname()
        if (qName.getLocalPart() == "Passport") {
            message.setProperty("passportHexString", header.getElement().getTextContent())
            break
        }
    }

    for (def header in headers) {
        def qName = header.getQname()

        if (qName.getLocalPart() == "Main") {
            def childNodes = header.getElement().getElementsByTagName("MessageId")
            if (childNodes.length > 1) {
                // throw new Exception("More than 1 MessageId's found");
                return message
            } else if (childNodes.length < 1) {
                // throw new Exception("No MessageId found");
                return message
            }

            for (def child in childNodes) {
                messageLog.addCustomHeaderProperty("MessageId", child.getTextContent())
            }
        }
    }

    return message
}