package script

import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    final String DOC_TRANSPORTATIONORDERQUOTATIONCREATEREQUEST          = "TransportationOrderQuotationCreateRequest"
    final String DOC_TRANSPORTATIONORDERQUOTATIONCANCELLATIONREQUEST    = "TransportationOrderQuotationCancellationRequest"
    final String DOC_TRANSPORTATIONORDERQUOTATIONNOTIFICATION           = "TransportationOrderQuotationNotification"
    final String DOC_TRANSPORTATIONORDERREQUEST                         = "TransportationOrderRequest"
    final String DOC_TRANSPORTATIONORDERCANCELLATIONREQUEST             = "TransportationOrderCancellationRequest"
    final String DOC_TRANSPORTATIONORDERGENERICTRACKEDPROCESSREQUEST    = "TransportationOrderGenericTrackedProcessRequest"
    final String DOC_TRANSPORTATIONORDERCHARGEELEMENTCONFIRMATION       = "TransportationOrderChargeElementConfirmationMessage"
    final String DOC_APPOINTMENTREQUEST                                 = "GenericAppointment_In"    
    final String DOC_APPOINTMENTCANCELLATIONREQUEST                     = "GenericAppointmentCancellation_In"
    final String DOC_LOCATIONBULKREPLICATIONREQUEST                     = "LocationBulkReplicationRequest"
    final String DOC_MATERIALTRACEABILITYEVENTNOTIFICATIONMESSAGE       = "MaterialTraceabilityEventNotificationMessage"
    final String DOC_TRANSPORTATIONORDERBOOKINGREQUEST                  = "TransportationOrderBookingRequest"
    final String DOC_TRANSPORTATIONORDERBOOKINGWAYBILLNOTIFICATION      = "TransportationOrderBookingWaybillNotification"
    final String DOC_TRANSPORTATIONDISPUTECASENOTIFICATION              = "TransportationDisputeCaseNotification"
    final String DOC_TRANSPORTATIONORDERGENERICREQUEST                  = "TransportationOrderGenericRequest"
    final String DOC_BNTRANSPORTATIONORDERCHARGEELEMENTREQUEST          = "BNTransportationOrderChargeElementRequest"

    def xmlSlurper = new XmlSlurper()
    def body= message.getBody(Reader)
    def parsedXMLBody= xmlSlurper.parse(body)

    String lbnDocumentId			= ""

    //-------------------------------------------------------------------------
    // Document Root
    //-------------------------------------------------------------------------
    String lbnDocumentRootName 		= ""
    try {
        lbnDocumentRootName = parsedXMLBody.name().localPart
    } catch (e) {
        lbnDocumentRootName = parsedXMLBody.name()
    }


    setPropertyIfNotEmpty(message, 'lbnDocumentRootName', lbnDocumentRootName)

    if (lbnDocumentRootName == null || lbnDocumentRootName == "") {
        throw new IllegalStateException("Received DocumentRootName does not has a valid element");
    }

    //-------------------------------------------------------------------------
    // LBN IDs | Docment Id
    //-------------------------------------------------------------------------
    // LBN IDs must be maintaind:
    // Receiver (Mostly Carrier): Carrier BP 	-> BP Identification -> ID Type = "LBN001"
    // Sender (Always Shipper/Ordering Party) 	-> Purchasing Organization used -> TA ppome Org. Data -> assigned BP -> maintain Identification -> ID Type = "LBN001" of the assigned BP
    def lbnReceiver = (parsedXMLBody.MessageHeader.RecipientParty.StandardID.find{StandardID -> StandardID.@schemeAgencyID == "310" }).toString()
    def lbnSender   = (parsedXMLBody.MessageHeader.SenderParty.StandardID.find{ StandardID -> StandardID.@schemeAgencyID == "310" }).toString()
    String lbnSenderSystemID  = (parsedXMLBody.MessageHeader.SenderBusinessSystemID).toString()
    
    switch (lbnDocumentRootName) {
        case DOC_TRANSPORTATIONORDERQUOTATIONCREATEREQUEST:
            lbnDocumentId 				= (parsedXMLBody.TransportationDocumentQuotation.BaseBusinessTransactionDocumentReference.find { ref -> ref.TypeCode == '1122' }).ID.toString() // RFQ Number
            break
        case DOC_TRANSPORTATIONORDERQUOTATIONNOTIFICATION:
            lbnDocumentId 				= (parsedXMLBody.TransportationOrderQuotation.BaseBusinessTransactionDocumentReference.find { ref -> ref.TypeCode == '1122' }).ID.toString() // RFQ Number
            break
        case DOC_TRANSPORTATIONORDERQUOTATIONCANCELLATIONREQUEST:
            lbnDocumentId 			    = (parsedXMLBody.TransportationDocumentQuotation.BaseBusinessTransactionDocumentReference.find { ref -> ref.TypeCode == '1122' }).ID.toString() // RFQ Number
            break
        case DOC_TRANSPORTATIONORDERREQUEST:
            lbnDocumentId 			    = (parsedXMLBody.TransportationDocument.BaseBusinessTransactionDocumentReference.find { ref -> ref.TypeCode == '1122' }).ID.toString() // FO Number
            break
        case DOC_TRANSPORTATIONORDERCANCELLATIONREQUEST:
            lbnDocumentId 			= (parsedXMLBody.TransportationDocument.BaseBusinessTransactionDocumentReference.find { ref -> ref.TypeCode == '1122' }).ID.toString() // FO Number
            break
        case DOC_TRANSPORTATIONORDERCHARGEELEMENTCONFIRMATION:
            lbnDocumentId           = (parsedXMLBody.TransportationOrder.BaseBusinessTransactionDocumentReference.find { ref -> ref.TypeCode == '1122' }).ID.toString()    // FO Number
            break
        case DOC_TRANSPORTATIONORDERGENERICTRACKEDPROCESSREQUEST:
            lbnDocumentId               = parsedXMLBody.TransportationOrderGenericTrackedProcess.ObjectReference.TransportationOrderID.toString()
            break
        case DOC_APPOINTMENTREQUEST:
            lbnDocumentId               = parsedXMLBody.GenericAppointment.Appointment.ReferenceDocuments.ReferenceDocument.DocumentId.toString() 
            break;
        case DOC_APPOINTMENTCANCELLATIONREQUEST:
            lbnDocumentId               = parsedXMLBody.GenericAppointment.Appointment.AppointmentId.toString()
            break;
        case DOC_LOCATIONBULKREPLICATIONREQUEST:
            lbnDocumentId               = parsedXMLBody.LocationReplicationRequestMessage.Location.LocationInternalID.toString()
            lbnReceiver                 = parsedXMLBody.MessageHeader.RecipientBusinessSystemID.toString()
            lbnSender                   = parsedXMLBody.MessageHeader.RecipientBusinessSystemID.toString()
            break;
        case DOC_MATERIALTRACEABILITYEVENTNOTIFICATIONMESSAGE:
            lbnDocumentId               = parsedXMLBody.MessageHeader.ID.toString()
            break;
        case DOC_TRANSPORTATIONORDERBOOKINGREQUEST:
            lbnDocumentId               = (parsedXMLBody.TransportationOrderBooking.BaseBusinessTransactionDocumentReference.find { ref -> ref.TypeCode == '1122' }).ID.toString()
            break;
        case DOC_TRANSPORTATIONORDERBOOKINGWAYBILLNOTIFICATION:
            lbnDocumentId               = (parsedXMLBody.TransportationOrderBookingWaybill.BaseBusinessTransactionDocumentReference.find { ref -> ref.TypeCode == '1122' }).ID.toString()
            break;
        case DOC_TRANSPORTATIONDISPUTECASENOTIFICATION:
            lbnDocumentId               = parsedXMLBody.TransportationDisputeCase.ID.toString()
            break;
        case DOC_TRANSPORTATIONORDERGENERICREQUEST:
            lbnDocumentId               = (parsedXMLBody.TransportationOrder.BaseBusinessTransactionDocumentReference.find { ref -> ref.TypeCode == '1122' }).ID.toString()
            break;
        case DOC_BNTRANSPORTATIONORDERCHARGEELEMENTREQUEST:
            lbnDocumentId               = (parsedXMLBody.TransportationDocument.BaseBusinessTransactionDocumentReference.find { ref -> ref.TypeCode == '1122' }).ID.toString()
            break
        default:
            break
    }

    if (lbnSender == null || lbnSender == '') {
        throw new Exception("Sender ID is missing in the payload")
    }
    setHeaderIfNotEmpty(message, 'SAP_ApplicationID', lbnDocumentId)
    setPropertyIfNotEmpty(message, 'lbnSender', lbnSender)
    setHeaderIfNotEmpty(message, 'SAP_Sender', lbnSender)
    setHeaderIfNotEmpty(message, 'SAP_Receiver', lbnReceiver)
    setHeaderIfNotEmpty(message, 'SAP_MessageType', lbnDocumentRootName)
    setHeaderIfNotEmpty(message, 'SAP_SenderSystemID', lbnSenderSystemID)

    return message;
}

private static void setHeaderIfNotEmpty(Message message, String headerName, String headerValue) {
    if (headerValue != null && !headerValue.isEmpty()) {
        message.setHeader(headerName, headerValue)
    }
}

private static void setPropertyIfNotEmpty(Message message, String propertyName, String propertyValue) {
    if (propertyValue != null && !propertyValue.isEmpty()) {
        message.setProperty(propertyName, propertyValue)
    }
}