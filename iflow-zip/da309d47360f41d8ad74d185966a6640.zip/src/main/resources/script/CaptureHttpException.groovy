package script

import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    // get a map of iflow properties
    def map = message.getProperties()

    // get an exception java class instance
    def ex = map.get("CamelExceptionCaught")
    if (ex != null) {
        if (ex.getClass().getCanonicalName() == "org.apache.camel.component.ahc.AhcOperationFailedException") {

            // save the http error response as a message attachment
            def messageLog = messageLogFactory.getMessageLog(message)
            messageLog.addAttachmentAsString("3_CamelExceptionCaught", ex.getResponseBody(), "text/plain")
        }
    }

    return message
}