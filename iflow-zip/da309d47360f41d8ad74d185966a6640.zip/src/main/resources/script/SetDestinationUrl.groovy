package script

import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.keystore.KeystoreService

import java.security.Key

Message processData(Message message) {
    final String INTEGRATION_PLATFORM_NEO = "NEO"
    final String INTEGRATION_PLATFORM_MULTI_CLOUD = "MULTI_CLOUD"

    def propertyMap = message.getProperties()
    // Validate certificate configuration
    KeystoreService keyStoreService = ITApiFactory.getService(KeystoreService.class, null)
    if (keyStoreService != null) {
        String keyAliasName = propertyMap.get("lbnClientCertificate")
        Key pKey = keyStoreService.getKey(keyAliasName)
        if (pKey == null) {
            throw new Exception("ClientCertificate not found. Please ensure a valid certificate is configured in SAP Cloud Integration for secure communication.")
        }
    }

    //Determine destination URL based on the customer's Configuration as well as datacenter (EU or US)
    def lbnDatacenterMap = [
        100: 'EU10',
        200: 'US20',
        300: 'SA30',
        110: 'EU20',
    ]

    String lbnSender = propertyMap.get("lbnSender")
    String datacenterPrefix = lbnSender.substring(0, 3)
    String datacenter = lbnDatacenterMap.get(Integer.valueOf(datacenterPrefix))

    String lbnIntegrationPlatform = propertyMap.get("lbnIntegrationPlatform")
    String lbnDestinationUrl = ""

    switch (lbnIntegrationPlatform) {
        case INTEGRATION_PLATFORM_NEO:
            lbnDestinationUrl = "https://l20398-iflmap.hcisbp.eu1.hana.ondemand.com/cxf/lbn/b2b/soap/v1"
            break
        case INTEGRATION_PLATFORM_MULTI_CLOUD:
            if (datacenter.equals("US20")) {
                lbnDestinationUrl = "https://api.logistics.us.business-network.cloud.sap/cxf/lbn/b2b/soap/v1"
            } else if (datacenter.equals("EU10")) {
                lbnDestinationUrl = "https://api.logistics.eu.business-network.cloud.sap/cxf/lbn/b2b/soap/v1"
            } else if (datacenter.equals("SA30")) {
                lbnDestinationUrl = "https://api.logistics.sa30.business-network.cloud.sap/cxf/lbn/b2b/soap/v1"
            } else if (datacenter.equals("EU20")) {
                lbnDestinationUrl = "https://api.logistics.eu20.business-network.cloud.sap/cxf/lbn/b2b/soap/v1"
            } else {
                throw new IllegalStateException("Unsupported datacenter: " + datacenter)
            }
            break
        default:
            //Setting Neo as default to avoid regression in case of any misconfiguration/errors. Will be updated once Neo is sunset.
            // lbnDestinationUrl = "https://l20398-iflmap.hcisbp.eu1.hana.ondemand.com/cxf/lbn/b2b/soap/v1"
            break
    }

    if (lbnDestinationUrl != null && lbnDestinationUrl != "") {
        propertyMap.get("lbnDestinationUrl", lbnDestinationUrl)
    } else {
        throw new IllegalStateException("Can't determine a valid destination URL. Please check you've maintained a valid configuration for 'INTEGRATION_PLATFORM' - 'NEO' or 'MULTI_CLOUD'")
    }

    return message
}