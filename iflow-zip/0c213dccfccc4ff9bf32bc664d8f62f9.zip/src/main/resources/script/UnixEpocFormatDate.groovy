import com.sap.it.api.mapping.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone
 
def String EpochFormatDateTime(String arg1) {
    // Define the date format including the timezone offset
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX")
    if(arg1=='null' || arg1=='')
    {
        return ''
    }
    else{
    // Parse the input date string with the provided timezone
    Date date = df.parse(arg1)
    // Get the epoch time in milliseconds
    long epochMillis = date.getTime()
    // Convert milliseconds to seconds (Unix epoch time)
    long epochSeconds = epochMillis / 1000
    // Return the epoch time as a string
    return String.valueOf(epochSeconds)
    }
}
 