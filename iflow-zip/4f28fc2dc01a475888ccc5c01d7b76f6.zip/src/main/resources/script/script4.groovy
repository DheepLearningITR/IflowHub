import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.MarkupBuilder;
import groovy.util.Node;
import java.util.HashMap;

def parseJSON(jsonText) {
    assert jsonText instanceof String, "You must give out a String instance for parsing json"
    return new groovy.json.JsonSlurper().parseText(jsonText)
}

def Message processData(Message message) {
    
    def bodyStr = message.getBody(java.lang.String);
    def hanaResponseNodes = parseJSON(bodyStr).value;
    def currentEmpJobContent = message.getProperty("currentEmpJob");
    def xmlNodes = new XmlParser().parseText(currentEmpJobContent);
    
    HashMap<String, String> deltawithKeyMap = new HashMap<String, String>();
    def DeltaWithKeyXML = new StringBuffer();

    if(hanaResponseNodes.size() != 0){
        hanaResponseNodes.each{ hanaResponseNode ->
            def xmlNode = xmlNodes.EmpJob.find{
                it.userId.text() == hanaResponseNode.userId.toString() && it.startDate.text() == hanaResponseNode.startDate.toString() && it.seqNumber.text() == hanaResponseNode.seqNumber.toString()
            }

            if(xmlNode){
                xmlNode.appendNode("uniquekey",hanaResponseNode.uniquekey.toString());
                deltawithKeyMap.put(xmlNode.uniquekey.text(),xmlNode);
            }
        }
        
        DeltaWithKeyXML.append("<EmpJob>");
        
        for (item in deltawithKeyMap) {
            def stringWriter = new StringWriter()
            def xmlNodePrinter = new XmlNodePrinter(new PrintWriter(stringWriter));
            xmlNodePrinter.with {
                preserveWhitespace = true
            }
            xmlNodePrinter.print(item.value);
            DeltaWithKeyXML.append(stringWriter.toString());
        }
        DeltaWithKeyXML.append("</EmpJob>");
    }
    
    message.setBody(DeltaWithKeyXML.toString());
    return message;
}