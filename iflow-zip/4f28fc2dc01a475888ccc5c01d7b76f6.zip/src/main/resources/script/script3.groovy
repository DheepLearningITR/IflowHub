import com.sap.gateway.ip.core.customdev.util.Message

import java.time.LocalDate

def Message processData(Message message) {

    def properties = message.getProperties();
    def filter = new StringBuffer();
    def body = message.getBody(java.io.Reader);
    def xmlNode = new XmlSlurper().parse(body);
    
    def init = true;
    
    xmlNode.EmpJobKey.userId.each {
        //def lv_userId = it.text().replaceAll("&","%26");
        def lv_userId = it.text();
        if (init == true) {
            filter.append("userId eq '" + lv_userId + "'");
            init = false;
        }
        else {
            filter.append(" or userId eq '" + lv_userId + "'");
        }
        
    }

    message.setBody(filter.toString());
    message.setProperty('filterId', filter.toString());

    return message;
    
}