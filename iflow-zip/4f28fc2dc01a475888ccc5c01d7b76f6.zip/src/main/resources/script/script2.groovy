import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.MarkupBuilder;
import groovy.util.Node;
import java.util.HashMap;
import java.util.HashSet;

def parseJSON(jsonText) {
    assert jsonText instanceof String, "You must give out a String instance for parsing json"
    return new groovy.json.JsonSlurper().parseText(jsonText)
}

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String);
    def xmlNodes = parseJSON(body).value;
    Set<String> idSet = new HashSet<String>();
    
    xmlNodes.each{
        idSet.add(it.userId.toString());
    }
    
	def writer = new StringWriter();
	def builder = new MarkupBuilder(writer);

	builder.EmpJobKey{
	    for(id in idSet){ 
    	    'EmpJobKey'{
    	        'userId'(id);
    	    }
	    }
	}
    
    message.setBody(writer.toString());
    message.setProperty("idSet",idSet);
    return message;
}