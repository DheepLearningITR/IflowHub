import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import groovy.util.XmlSlurper;
import groovy.xml.XmlUtil;
import groovy.json.*;
import groovy.json.JsonSlurper;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;


def Message processData(Message message) {
    def mpl = messageLogFactory.getMessageLog(message);

    def jsonInputBody = new JsonSlurper().parseText(message.getBody(String));
    def jsonObject = new JsonSlurper().parseText('{"ItemData":{"ItemOld":[],"ItemNew":[]}}');
    
    if (jsonInputBody.ItemData.ItemNew instanceof Collection) {
        jsonObject = jsonInputBody;
    } else {
        jsonObject.ItemData.ItemNew<<jsonInputBody.ItemData.ItemNew;
        jsonObject.ItemData.ItemOld<<jsonInputBody.ItemData.ItemOld;
    }
    
    def jsonPRITEMS = new groovy.json.JsonSlurper().parseText('{"PRITEM": [], "PRITEMX": []}');

    for (int i = 0; i < jsonObject.ItemData.ItemNew.size(); i++) {
        def jsonItem = new groovy.json.JsonSlurper().parseText('{"item": {}}}');
        def jsonItemx = new groovy.json.JsonSlurper().parseText('{"item": {}}}');

        def map = new groovy.json.JsonSlurper().parseText(new JsonBuilder(jsonObject.ItemData.ItemNew[i]).toPrettyString());
        map.each { key, value ->
            if (jsonObject.ItemData.ItemNew[i]."$key" != jsonObject.ItemData.ItemOld[i]."$key") {
                jsonItem.item << ["$key" : "$value"];
                jsonItemx.item << ["$key" : "X"];
            }
        }
        jsonItem.item<<["PREQ_ITEM" : jsonObject.ItemData.ItemNew[i].PREQ_ITEM];
        jsonItemx.item<<["PREQ_ITEM" : jsonObject.ItemData.ItemNew[i].PREQ_ITEM];
        
        jsonPRITEMS<<["NUMBER" : jsonObject.ItemData.ItemNew[i].PREQ_NO];
        jsonPRITEMS.PRITEM<<jsonItem.item;
        jsonPRITEMS.PRITEMX<<jsonItemx.item;
    }
    

    message.setBody(new JsonBuilder(jsonPRITEMS).toPrettyString());
    return message;
}


