import com.sap.gateway.ip.core.customdev.util.Message;

def Message trimCSID(Message message){
    def headers = message.getHeaders();
    
    def csid = headers.get("CSID");
    message.setHeader("CSID", csid.replaceAll("\\s", ""));
    return message;
}

def Message removeExtraSpaceFromPIH(Message message) {
    def properties = message.getProperties();
    
    def pih = properties.get("PIH");
    message.setProperty("PIH", pih.replaceAll("\\s",""));
    return message;
}