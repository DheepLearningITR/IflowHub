import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def map = message.getProperties();
    if(messageLog != null){
        def salesOrderID = map.get("SalesOrder_ID");
        messageLog.addCustomHeaderProperty("SalesOrder_ID", salesOrderID);
    }
    return message;
}
