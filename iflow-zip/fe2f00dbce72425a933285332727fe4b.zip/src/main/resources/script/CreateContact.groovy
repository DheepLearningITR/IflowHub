import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import groovy.util.*;
import groovy.json.*;

import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi



def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    def CampaignText = new XmlParser().parseText(body);
    def ContactText = CampaignText.CampaignTargetGroupMembers;
    
    def panelDataList = ['CONTACT_KEY', 'NAME_LAST', 'NAME_FIRST', 'SMTP_ADDR', 'PHONE', 'LANGUAGE']
    
    def panelDataMap = [:]
    def embeddedDataMap = [:]
    
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    def mappedValue = null;
    

    
    // Extract variables
    ContactText.TargetGroupMemberAttributeData.each {
		String id = "${it.AttributeId.text()}";
		if("${it.Value.text()}" != ""){
		    if(panelDataList.contains(id)){
		        mappedValue = valueMapApi.getMappedValue('MKT', 'Contacts', id, 'Qualtrics', 'Contacts')
		        panelDataMap[mappedValue] = "${it.Value.text()}";
		        if(id == 'SMTP_ADDR') {
    		        message.setProperty("Email", "${it.Value.text()}");
    	    	}
		    }
		    else{
		        mappedValue = valueMapApi.getMappedValue('MKT', 'Contacts', id, 'Qualtrics', 'Contacts')
		        if(mappedValue != null){
		            embeddedDataMap[mappedValue] = "${it.Value.text()}";
		        }
		        if(id == 'CONTACT_ID') {
        		    message.setProperty("ContactID", "${it.Value.text()}");
    		    }
		    }
		}
	}
    
    // Create message body
    def Builder = new JsonBuilder()
    
    def panelJson = Builder panelDataMap
    
    def embeddedJson = Builder{
    "embeddedData"(
        embeddedDataMap
        )
    }
    
    def finalJson = panelJson + embeddedJson
    def outputJson = JsonOutput.toJson(finalJson)

    message.setBody(outputJson)
    message.setHeader("Content-Type", "application/json");
    return message;

} 
