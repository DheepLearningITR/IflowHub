/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Properties
    def map = message.getProperties();
    //define ContactIDMap with OutboundID
    def ContactIDMapList = [:];
    //get current COntact ID map
    ContactIDMapList = map.get("ContactIDMap");
    //define ContactIDMap with UUID
    def UUIDMapList = [:];
    //get current COntact ID map
    UUIDMapList = map.get("UUIDMap");

    //get ContactID
    def ContactIDValue = map.get("ContactID");
    
	//fill into Map
    //OutboundID
    //get OutboundID
    def OutboundIDValue = map.get("OutboundId");
    ContactIDMapList.put( ContactIDValue,  OutboundIDValue);
    //UUID
    def UUIDValue = map.get("UUID")
    // convert UUID to GUID
    UUIDValue = UUIDValue.toLowerCase();
	def GUIDValue = UUIDValue.substring(0,8)+"-"+UUIDValue.substring(8,12)+"-"+UUIDValue.substring(12,16)+"-"+UUIDValue.substring(16,20)+"-"+UUIDValue.substring(20)
	
    
    UUIDMapList.put( ContactIDValue,  GUIDValue);

    return message;
}