import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import groovy.util.*;
import groovy.json.*;
import java.io.Reader;



def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    def CampaignText = new XmlParser().parseText(body);
    def ContactText = CampaignText.CampaignTargetGroupMembers;
    def map = message.getProperties();
    def surveyIDValue = null;

    ContactText.TargetGroupMemberAttributeData.each {
		def id = "${it.AttributeId.text()}";
	    if(id == 'ZOC_Q_SURVEY') {
		    surveyIDValue = "${it.Value.text()}";      
		}
	}
    
    message.setBody(body)
    message.setHeader("Content-Type", "application/json");
    message.setProperty("SurveyID", surveyIDValue);
    
    //define map for OutboundID
    def ContactIDMapList = [:]
    message.setProperty("ContactIDMap", ContactIDMapList);
    
    //define map for Transaction and Contact data
    def ContactTransactionMapList = [:]
    message.setProperty("ContactTransactionMap", ContactTransactionMapList);
    
    //define map for UUID
    def UUIDMapList = [:]
    message.setProperty("UUIDMap", UUIDMapList);
    return message;

 

}