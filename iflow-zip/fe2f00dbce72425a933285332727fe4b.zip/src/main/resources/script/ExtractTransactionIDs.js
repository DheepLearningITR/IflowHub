importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {

var body = String(message.getBody(new java.lang.String().getClass()));
    //create json object from string object
    body = JSON.parse(body);
      
    if(body && body.result){
        var transactionId = body.result.createdTransactions.a.id;
        message.getProperties().put("TransactionID", transactionId);
        
    }
   
    return message;
}



