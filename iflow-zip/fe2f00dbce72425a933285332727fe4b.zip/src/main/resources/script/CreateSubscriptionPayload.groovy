import groovy.xml.*;
import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) 
{
    
map = message.getProperties();
def contactID = map.get("ContactID");
def email = map.get("Email");
	
def builder = new StreamingMarkupBuilder()
builder.encoding = 'UTF-8'
def listXml = builder.bind {
    root {
            ContactID( contactID )
            Email( email )
    }
}

def listXMLString = XmlUtil.serialize( listXml )
listXMLString.replaceAll("<?xml version\"1.0\" encoding=\"UTF-8\"?><","<")
message.setBody(listXMLString)
return message;

}