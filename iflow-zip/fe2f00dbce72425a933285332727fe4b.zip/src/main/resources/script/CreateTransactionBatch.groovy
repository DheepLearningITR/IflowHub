import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonSlurper;



def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    def TransactionsText = new JsonSlurper().parseText(body);
    List<String> transactionList = new ArrayList<String>();
    
    // Get current Time
    /*
    //Change of coding due to https://launchpad.support.sap.com/#/notes/3289679
    TimeZone.setDefault(TimeZone.getTimeZone('UTC'))
    def now = new Date()
    def nowFormatted = now.format("yyyy-MM-dd HH:mm:ss")
    */
    
    DateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    TimeZone timeZone = TimeZone.getTimeZone("UTC"); dateFormat.setTimeZone(timeZone);
    Date date = new Date();
    def nowFormatted = dateFormat.format(date);
    
    def TransactionIDText = TransactionsText.result.createdTransactions.a.id;
    transactionList.add(TransactionIDText);

    
    // Create message body
    def Builder = new JsonBuilder()
    
    def json = Builder {
	"transactionIds"(
	                    transactionList
	                ) 
	"creationDate" nowFormatted
    }


    def outputJson = JsonOutput.toJson(json)
    message.setBody(outputJson)
    message.setHeader("Content-Type", "application/json");
    return message;

}