import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import groovy.util.*;
import groovy.json.*;
import java.util.Date;

import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi





def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    def CampaignText = new XmlParser().parseText(body);
    def ContactText = CampaignText.CampaignTargetGroupMembers;
    
    //Create HashMaps
//  This map holds data which is used for creating the transaction in Qualtrics
    def transactionMap = [:]
//  This data map hold data which will be transferred to Qualtrics
    def transactionDataMap = [:]
//  This data map holds data which will be used for email personalization
    def transactionTransferMap = [:]
    
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
    def mappedValueTransaction = null;
    def mappedValueInteraction = null;
    
    
    //Get Properties  
    def map = message.getProperties();
    
    //Get current Contact-Transaction-Map
    def ContactTransactionMapList = [:];

    ContactTransactionMapList = map.get("ContactTransactionMap");
    
    
    //Create variables
    transactionMap["contactId"] = map.get("ContactID");
    transactionMap["mailingListId"] = map.get("MailingListID");
    contactId = map.get("DataStoreId");
    
    
    
    
    ContactText.TargetGroupMemberAttributeData.each {
		def id = "${it.AttributeId.text()}";
		if("${it.Value.text()}" != ""){
		    
		    mappedValueTransaction = valueMapApi.getMappedValue('MKT', 'Trigger-IA', id, 'Qualtrics', 'Transaction')
		    if(mappedValueTransaction != null){
		        transactionDataMap[mappedValueTransaction] = "${it.Value.text()}";  
            }
            mappedValueInteraction = valueMapApi.getMappedValue('MKT', 'Trigger-IA', id, 'MKT2', 'Trigger-IA')
		    if(mappedValueInteraction != null){
		        transactionTransferMap[mappedValueInteraction] = "${it.Value.text()}";  
            }
		}
	}
    

        // Create message body
        def Builder = new JsonBuilder()
        
        def transactionJson = Builder transactionMap
        
        def transactionDataJson = Builder{
                                    "data"(
                                        transactionDataMap
                                    )
        }
        def subjson = transactionJson + transactionDataJson
        
        // create json body
        def finalJson = Builder {
            "a"(
                   subjson
            )
        }
       
    
    def outputJson = JsonOutput.toJson(finalJson)
    message.setBody(outputJson)
    message.setHeader("Content-Type", "application/json");
    ContactTransactionMapList.put(map.get("ContactID"), transactionTransferMap)
    return message;

 

}