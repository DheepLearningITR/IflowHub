import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;
import groovy.json.JsonSlurper;
import static java.util.Calendar.*


def Message processData(Message message) {
    
    //Get Properties  
    def map = message.getProperties();
    def body = message.getBody(java.lang.String) as String;
    def BatchText = new JsonSlurper().parseText(body);

    def surveyIdText = map.get("SurveyID");  
    def mailingListIdText = map.get("MailingListID")
    def batchIDText = BatchText.result.id;
    
    // Get current Time
    //Change of coding due to https://launchpad.support.sap.com/#/notes/3289679
    /*TimeZone.setDefault(TimeZone.getTimeZone('UTC'))
    def today = new Date()
    def nextMonth = today[MONTH] + 3
    def oneMonthFromNow = today.copyWith(month: nextMonth)
    def formattedDate = oneMonthFromNow.format("yyyy-MM-dd HH:mm:ss")
    */
    DateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    TimeZone timeZone = TimeZone.getTimeZone("UTC"); dateFormat.setTimeZone(timeZone);
    Date date = new Date();
    //String currentDate = dateFormat.format(date);
    def nextMonth_New = date[MONTH] + 3
    def oneMonthFromNow_New = date.copyWith(month: nextMonth_New)
    def formattedDate = dateFormat.format(oneMonthFromNow_New)
    
    // Create message body
    def Builder = new JsonBuilder()
    
    def json = Builder {
	"action" "CreateTransactionBatchDistribution"
	"surveyId" surveyIdText
	"transactionBatchId" batchIDText
	"description" "Qualtrics Survey Distribution"
	"expirationDate" formattedDate
	"linkType" "Individual"
	"mailingListId" mailingListIdText
    }


    def outputJson = JsonOutput.toJson(json)
    message.setBody(outputJson)
    message.setHeader("Content-Type", "application/json");
    return message;

}




