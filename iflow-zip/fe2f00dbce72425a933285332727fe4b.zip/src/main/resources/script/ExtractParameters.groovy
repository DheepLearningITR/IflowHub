import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;
import groovy.json.*;



def Message processData(Message message) {
    
        def body = message.getBody(java.lang.String) as String;
        def d = new XmlParser().parseText(body);
        def id_value = ''

        d.CampaignTargetGroupMembers.each {
                      it.TargetGroupMemberAttributeData.each {
             def id = "${it.AttributeId.text()}";
              if(id == 'OUTBOUND_INTERACTION') {
			   def uuid = "${it.Value.text()}";
			   
			   def IaKey = uuid.substring(0,8)+"-"+uuid.substring(8,12)+"-"+uuid.substring(12,16)+"-"+uuid.substring(16,20)+"-"+uuid.substring(20)
                message.setProperty("IaKeyOut", IaKey);
                return
			        }
          }
            
             def  OutboundID = "${it.OutboundId.text()}";
                message.setProperty("OutboundId", OutboundID);
            
                return
			        }
		
			 return message
          }
