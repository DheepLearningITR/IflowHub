import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import groovy.json.*;

Message processData(Message message) {
    
    // Get Message body
    def body = message.getBody(java.lang.String) as String;
    def DistributionLinkText = new XmlParser().parseText(body);
    

   
    // Get Message Properties
    def map = message.getProperties();
    def ContactIDMapList = map.get("ContactIDMap");
    def ContactTransactionMapList = map.get("ContactTransactionMap");

    def ContactId;
    def jsonMap = [:]
    // create json builder
    def Builder = new JsonBuilder();
    
    // Get current Time
    /*
    //Change of coding due to https://launchpad.support.sap.com/#/notes/3289679
    TimeZone.setDefault(TimeZone.getTimeZone('UTC'))
    def now = new Date()
    def nowFormatted = now.format("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'")
    */
    
    DateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'");
    TimeZone timeZone = TimeZone.getTimeZone("UTC"); dateFormat.setTimeZone(timeZone);
    Date date = new Date();
    def nowFormatted = dateFormat.format(date);
    
    
    
    def json;
    List<String> jsonList = new ArrayList<String>();
    
    DistributionLinkText.result.elements.each {
		def id = "${it.contactId.text()}";
		for (e in ContactIDMapList) {
            ContactId = e.key;
            for (t in ContactTransactionMapList) {
                TransactionContactId = t.key;
        	    if(id == ContactId && id == TransactionContactId) {
        	        jsonMap = [:]
        	        // get DistributionLink of Contact
        	        def distributionLink = "${it.link.text()}"
        	        def OutboundID = e.value;
        	        // create JSON message body
        	        jsonMap["InteractionSourceObject"] = OutboundID;;
        	        jsonMap["InteractionSourceDataURL"] = distributionLink;
        	        jsonMap["InteractionUUID"] = "00000000-0000-0000-0000-000000000000";
                    jsonMap["InteractionType"] = "SURVEY_LINK_CREATED";
                    jsonMap["InteractionSourceObjectType"] = "CUAN_CAMPAIGN_OUTBOUND";
                    jsonMap["YY1_ZustzlTypQuellObj2_MIA"] = "Q_SURVEY";
                    jsonMap["YY1_ZustzlIdQuellObj2_MIA"] = map.get("SurveyID");
                    jsonMap["InteractionTimeStampUTC"] = nowFormatted;
                    def dateString = t.value.get("Startdatum");
                    if (dateString?.trim()){
                        String[] str = dateString.getChars();
                        dateString = str[0] + str[1] + str[2] + str[3] + '-' + str[4] + str[5] + '-' + str[6] + str[7]
                        def dateFormatted = Date.parse("yyyy-MM-dd", dateString);
                        dateFormatted = dateFormatted.format("yyyy-MM-dd'T'hh:mm");
                        jsonMap["YY1_STARTDATUM_MIA"] = dateFormatted;
                    }
                    
        	    }
            }
	    }
	    json = Builder jsonMap
	    jsonList.add(json);
    }
    
    
    def resultJson = Builder{
        "Interactions"(jsonList)
    }
    
    def outputJson = JsonOutput.toJson(resultJson)
    message.setBody(outputJson)
	
    return message
}


