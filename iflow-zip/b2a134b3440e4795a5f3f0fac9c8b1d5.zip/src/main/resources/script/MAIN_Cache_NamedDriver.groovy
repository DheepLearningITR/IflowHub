import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;

/*
Stores the mapping form the Customer ID (FSA) to the BP ID (S/4) as
HEADER attribute.
It is stored as header, because Properties are not transfered through the
ProcessDirekt adapter
*/
def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);
    
    //parse the incoming XML into an object
	def rfcSet = new XmlSlurper().parseText(body);
    
    def objNamedDriver = rfcSet.breadthFirst().find { node-> node.name() == 'childInsuredObjects' }
    objNamedDriver.NamedDriver.each{ namedDriver ->
    
        if (namedDriver.customerId.text() != '') {
            message.setHeader(namedDriver.customerId.text(), namedDriver.bpId.text());
        }
    
    }
    
    return message;
    
}