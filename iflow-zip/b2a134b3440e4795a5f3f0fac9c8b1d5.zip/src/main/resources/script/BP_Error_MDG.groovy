/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.QName;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);

    // Get CPI-Session Properties
    def properties = message.getProperties()
    
    //parse the incoming XML into an object
	def rfcSet = new XmlSlurper().parseText(body);
	
    //Create new temp XML Body
    def stringNewErrorMessageSet = '<ErrorMessages></ErrorMessages>'
    def objNewErrorMessageSet = new XmlParser().parseText(stringNewErrorMessageSet)
    
    //Reformat Error Message
    def objErrorMessage = rfcSet.breadthFirst().find { node-> node.name() == 'SPECIFIC_MESSAGE' }
    objErrorMessage.item.each{ messageHead ->
            
        if (messageHead.MESSAGE_TYPE_INDICATOR.TYPE_ERROR.text( ) == 'X') {   
            
            messageHead.MESSAGES.item.each{ errorMessage ->
            
                def objNewMessage = objNewErrorMessageSet.appendNode(new QName('Message')) 
                
                objNewMessage.appendNode(new QName('cpiProcessStep'), '')  
                objNewMessage.appendNode(new QName('type'),    errorMessage.TYPE.text( ))  
                objNewMessage.appendNode(new QName('id'),      errorMessage.ID.text( ))  
                objNewMessage.appendNode(new QName('number'),  errorMessage.NUMBER.text( ))
                objNewMessage.appendNode(new QName('message'), errorMessage.MESSAGE.text( ))
                objNewMessage.appendNode(new QName('system'),  errorMessage.SYSTEM.text( ))
                
            }
        
        }  
        
    }

    //Set objNewErrorMessageSett as messageBody
    message.setBody(XmlUtil.serialize(objNewErrorMessageSet))
    return message;
    
}