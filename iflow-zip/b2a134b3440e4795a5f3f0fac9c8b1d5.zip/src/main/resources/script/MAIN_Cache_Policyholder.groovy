import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;

/*
Stores the mapping form the Customer ID (FSA) to the BP ID (S/4) as
HEADER attribute.
It is stored as header, because Properties are not transfered through the
ProcessDirekt adapter
*/
def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);
    
    //parse the incoming XML into an object
	def rfcSet = new XmlSlurper().parseText(body);
    
    def objPolicyHolder = rfcSet.breadthFirst().find { node-> node.name() == 'policyHolder' }
    objPolicyHolder.root.each{ policyHolder ->
    
        if (policyHolder.customerId.text() != null) {
            message.setHeader(policyHolder.customerId.text(), policyHolder.bpId.text());
        }
    
    }
    
    return message;
    
}