import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.QName;
import groovy.xml.XmlUtil;

/*
Mapping of BAPIRET error messages into the IFlow error Message
format.
*/
def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);

    // Get CPI-Session Properties
    def properties = message.getProperties()
    
    //parse the incoming XML into an object
	def rfcSet = new XmlSlurper().parseText(body);
	
    //Create new temp XML Body
    def stringNewErrorMessageSet = '<ErrorMessages></ErrorMessages>'
    def objNewErrorMessageSet = new XmlParser().parseText(stringNewErrorMessageSet)
    
    //Reformat Error Message
    def objErrorMessage = rfcSet.breadthFirst().find { node-> node.name() == 'RETURN' }
    objErrorMessage.item.each{ errorMessage ->
            
        def objNewMessage = objNewErrorMessageSet.appendNode(new QName('Message')) 
        
        objNewMessage.appendNode(new QName('cpiProcessStep'), '')  
        objNewMessage.appendNode(new QName('type'),    errorMessage.TYPE.text( ))  
        objNewMessage.appendNode(new QName('id'),      errorMessage.ID.text( ))  
        objNewMessage.appendNode(new QName('number'),  errorMessage.NUMBER.text( ))
        objNewMessage.appendNode(new QName('message'), errorMessage.MESSAGE.text( ))
        objNewMessage.appendNode(new QName('system'),  errorMessage.SYSTEM.text( ))
        
    }

    //Set objNewErrorMessageSett as messageBody
    message.setBody(XmlUtil.serialize(objNewErrorMessageSet))
    return message;
    
}