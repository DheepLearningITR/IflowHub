import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.QName;
import groovy.xml.XmlUtil;

/*
Extracts the error messages out of the QUO-payload and converts them to the 
IFlow error message format.
*/
def Message processData(Message message) {
    
    def errorFound = '';
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);

    // Get CPI-Session Properties
    def properties = message.getProperties()
    
    //parse the incoming XML into an object
	def rfcSet = new XmlSlurper().parseText(body);
	
    //Create new temp XML Body
    def stringNewErrorMessageSet = '<ErrorMessages></ErrorMessages>'
    def objNewErrorMessageSet = new XmlParser().parseText(stringNewErrorMessageSet)
    
    //Reformat Error Message
    def objErrorMessage = rfcSet.breadthFirst().find { node-> node.name() == 'MessageList' }
    
    //Not the expected Message errorFound
    if (objErrorMessage == null) {
        return message;
    }
    
    objErrorMessage.MessageItem.each{ errorMessage ->
            
        def objNewMessage = objNewErrorMessageSet.appendNode(new QName('Message')) 
        errorFound = 'X'
         
        objNewMessage.appendNode(new QName('type'),    '')  
        objNewMessage.appendNode(new QName('id'),      '')  
        objNewMessage.appendNode(new QName('number'),  '')
        objNewMessage.appendNode(new QName('message'), errorMessage.MESSAGETEXT_TT.text( ))
        objNewMessage.appendNode(new QName('system'),  'QUO')
        
    }

    if (errorFound != '') {
        //Set objNewErrorMessageSett as messageBody
        message.setBody(XmlUtil.serialize(objNewErrorMessageSet))
    }
    return message;
    
}