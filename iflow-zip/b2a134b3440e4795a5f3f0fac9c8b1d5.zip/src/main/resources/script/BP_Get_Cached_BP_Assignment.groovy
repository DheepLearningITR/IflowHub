import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

/*
Check HEADER attributes, if the BP ID was already determined by the IFlow to the 
given Customer ID
*/
def Message processData(Message message) {
    
    //get the body of the incoming message
    def body = message.getBody(java.lang.String);
    
    //parse the incoming XML into an object
	def rfcSet = new XmlSlurper().parseText(body);
	 
    def mapProp = message.getProperties();
    def mapHead = message.getHeaders();
    
    customer_Id = mapProp.get('com.sap.commercecloud.fsa.insurance.underwritequotation.Customer_Id');
    
    if (customer_Id == null) {
        return message;
    }
     
    def assignedBpId = mapHead.get(customer_Id);
    
    if (assignedBpId == null) {
        return message;
    }
    
    message.setProperty('com.sap.commercecloud.fsa.insurance.underwritequotation.BP_ID', assignedBpId);
    message.setProperty('com.sap.commercecloud.fsa.insurance.underwritequotation.EXITProcess', 'X');
	
    return message;
    
}