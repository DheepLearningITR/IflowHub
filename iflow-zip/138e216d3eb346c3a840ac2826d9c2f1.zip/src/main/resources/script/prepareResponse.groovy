import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper
import groovy.xml.XmlUtil

def Message processData(Message message) {
	def header = message.getHeaders();
	String property_StatusText = header.get("HttpStatusCodes");
	String propertyStatusCode = header.get("CamelHttpResponseCode");
 	
 	//If Odata Adapter does not provide status codes -> update it manually
 	if (propertyStatusCode == null){
	 	if (property_StatusText == "Created"){
	 		propertyStatusCode = "201";	
	 	} else if (property_StatusText == "OK"){
	 		propertyStatusCode = "200";	 	
	 	} else {
	 		propertyStatusCode = "400";
	 	}
 	}
 
	def newNode1 = new XmlSlurper().parseText(("<statusText>" + property_StatusText + "</statusText>")); 
	def newNode2 = new XmlSlurper().parseText(("<statusCode>" + propertyStatusCode + "</statusCode>")); 
   	def xml = new XmlSlurper().parseText(message.getBody(java.lang.String));
    xml.Background_VarPayEmpHistData.appendNode(newNode1);
    xml.Background_VarPayEmpHistData.appendNode(newNode2);
    message.setBody(XmlUtil.serialize(xml));
    return message;
}