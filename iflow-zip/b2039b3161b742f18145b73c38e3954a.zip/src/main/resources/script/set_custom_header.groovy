import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def messageLog = messageLogFactory.getMessageLog(message);
    def runMode = message.getHeaders().get("runMode")
    def jsonparse;
    
    try{
        jsonparse = new JsonSlurper().parseText(body);
        
        //set custom header
        jsonparse.data.each{
            if(it.value != '' && it.value != null){
                try{
                    messageLog.addCustomHeaderProperty(it.key, it.value);
                }
                catch(Exception e){
                }
            }
        }
    }
    catch(Exception e){
        messageLog.addCustomHeaderProperty("Error", "Unexpected Payload from SAP Event Mesh");
        messageLog.addCustomHeaderProperty("Error Type", runMode);
        message.setProperty("Error", "Unexpected Payload from SAP Event Mesh");
        message.setProperty("ErrorType", runMode);
        message.setProperty("SAP_MessageProcessingLogCustomStatus", "ERROR");
    }
    
    messageLog.addCustomHeaderProperty("Run Mode",runMode);
    return message;
}