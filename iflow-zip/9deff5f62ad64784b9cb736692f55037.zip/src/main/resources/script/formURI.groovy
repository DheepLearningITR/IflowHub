import com.sap.it.api.mapping.*;

def String customFunc(String contactId, String contactOrigin, String contactPermissionID, String contactPermissionOrigin, String communicationMedium){
	return "MarketingPermissions(ContactID='"+contactId+"',ContactOrigin='"+contactOrigin+"',ContactPermissionID='"+contactPermissionID+"',ContactPermissionOrigin='"+contactPermissionOrigin+"',MarketingArea='',CommunicationMedium='"+communicationMedium+"')";
}