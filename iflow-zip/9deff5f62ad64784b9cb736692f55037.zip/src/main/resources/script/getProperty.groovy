import com.sap.it.api.mapping.*;

//Get exchange property value by passing the propery name and mapping context
def String getExchangeProperty(String propertyName,MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}