import com.sap.it.api.mapping.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

//Get the UTC date & time
def String customFunc(String arg1){
    
    Date inputDate_parsed=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(arg1);  

    DateFormat dateFormat_required = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    def converted_datetime=dateFormat_required.format(inputDate_parsed);
    
    return converted_datetime;
}