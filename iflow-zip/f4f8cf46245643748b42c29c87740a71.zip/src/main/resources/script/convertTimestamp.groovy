import com.sap.it.api.mapping.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


def String convertTimestamp(String timestamp){

    Date inputTimestamp = new SimpleDateFormat("yyyyMMddhhmmss", Locale.ENGLISH).parse(timestamp.trim());
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.ENGLISH);
    sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
    String outputTimestamp = sdf.format(inputTimestamp);

    return outputTimestamp;
}
