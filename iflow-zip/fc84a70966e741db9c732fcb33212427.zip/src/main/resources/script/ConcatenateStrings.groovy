import com.sap.it.api.mapping.*;

def void ConcatenateString(String[] text, Output output, MappingContext context) {
        def concatenatedText = text.join(' ')
        output.addValue(concatenatedText);
}