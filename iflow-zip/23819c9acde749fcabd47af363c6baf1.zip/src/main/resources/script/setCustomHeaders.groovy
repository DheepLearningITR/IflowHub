import com.sap.gateway.ip.core.customdev.util.Message
import java.util.regex.*

def Message processData(Message message) {
    // Get all message properties
    def properties = message.getProperties()

    // Filter property keys that end with _1, _2, etc.
    def matchingKeys = properties.keySet().findAll { key ->
        key ==~ /.*_\d+$/
    }


    def messageLog = messageLogFactory.getMessageLog(message)

    for (int i = 0; i < matchingKeys.size(); i++) {
        matchingKeys.each { key ->
            def value = properties.get(key)

            if (messageLog != null) {
                messageLog.addCustomHeaderProperty(key, value)
            }
        }
    }

    return message
}
