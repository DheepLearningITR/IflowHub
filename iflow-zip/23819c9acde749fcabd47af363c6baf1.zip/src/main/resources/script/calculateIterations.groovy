// =============================================================================================
// This script is responsible to set the counter for the looping iterations and to check against
// the current index in the loop
// History:
// 2025-07-10 SAP [MÖ] - Script created
// =============================================================================================


import com.sap.gateway.ip.core.customdev.util.Message
import java.util.regex.*

def Message processData(Message message) {
    def props = message.getProperties()
    def index = message.getProperty("CamelLoopIndex") as Integer
    def currentIndex = index + 1
    def count = 0

    // Pattern: keys like MessageMapping_1, MessageMapping_2, etc.
    def pattern = ~/^MessageMapping_\d+$/

    props.each { key, value ->
        if (key ==~ pattern) {
            count++
        }
    }

    message.setProperty("MessageMappingCount", count)
    message.setProperty("loopingRequired", count > (index + 1))
    message.setProperty("currentIndex", currentIndex)

    return message
}
