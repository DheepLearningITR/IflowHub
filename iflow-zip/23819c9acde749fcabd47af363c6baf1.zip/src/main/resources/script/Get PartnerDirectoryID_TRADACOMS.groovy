import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import groovy.xml.*
import java.io.InputStream
import java.io.ByteArrayInputStream;
import com.sap.it.api.pd.BinaryData;


def Message processData(Message message) {
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null);
    if (service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }
    def map = message.getProperties();
    def headers   = message.getHeaders();
	def partnerID = headers.get("ACTUAL_PARTNER_ID");
	def partnerDirID = "TRADACOMS"
	def binaryID = message.getProperty("binaryID");
	def direction = message.getProperty("SAP_TPA_BTA_Direction");
    
    
    if (partnerDirID == null){
        throw new IllegalStateException("Partner ID is not set in Partner Directory'")
    }

    // Get the dynamic parameter name from the exchange properties
    if (binaryID == null) {
        throw new IllegalStateException(" ID BINARY is not set in the BinaryID property");
    }


    def parameterValue = service.getParameter(binaryID, partnerDirID , BinaryData.class);
    if (parameterValue == null){
        throw new IllegalStateException("ID Binary parameter not found in the Partner Directory for the partner ID = "+ partnerDirID);
    }
    if (direction == "INBOUND"){
    message.setHeader("XML_STRUCTURE_CONVERTER_TRADACOMS_INBOUND_XSLT","pd:" + partnerDirID +":" + binaryID + ":Binary");
    }
    
    else if (direction == "OUTBOUND"){
    message.setHeader("XML_STRUCTURE_CONVERTER_TRADACOMS_OUTBOUND_XSLT","pd:" + partnerDirID +":" + binaryID + ":Binary");
    }

    return message;
}
