// =============================================================================================
// This script is responsible to set the parameters for next iteration's sequence
// History:
// 2025-07-10 SAP [MÖ] - Script created
// =============================================================================================
import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import java.util.regex.Pattern

Message processData(Message message) {
    
    // Get all properties
    def props = message.getProperties()

    // Regex pattern to match keys like MessageMapping_1
    def pattern = Pattern.compile('^(.*)_(\\d+)$')
    

    // Loop through all properties
    props.keySet().each { key ->
        def matcher = pattern.matcher(key)
        
        if (matcher.matches()) {
            def baseName = matcher.group(1) 
            def currentIndex = message.getProperty("currentIndex") as Integer      
            def nextIndex = currentIndex + 1
            def nextKey = baseName + "_" + nextIndex

            // Check if next property exists
            if (props.containsKey(nextKey)) {
                def nextValue = props.get(nextKey)
                if (nextValue != null && nextValue.toString().trim().length() > 0) {
                    // Set header with base name and value from next property
                    message.setHeader(baseName, nextValue)
                }
            }

            else {
                message.setHeader(baseName, null)
            }
        }
    }

    return message
}
