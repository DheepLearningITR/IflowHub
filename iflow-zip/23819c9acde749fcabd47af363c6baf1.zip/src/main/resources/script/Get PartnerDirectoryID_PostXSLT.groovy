import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import groovy.xml.*
import java.io.InputStream
import java.io.ByteArrayInputStream;
import com.sap.it.api.pd.BinaryData;


def Message processData(Message message) {
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null);
    if (service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }
    def map = message.getProperties();
    def headers   = message.getHeaders();
	def partnerID = headers.get("SAP_TPM_ACTIVITYPARTNER_ID");
	def partnerDirID = partnerID.substring(partnerID.lastIndexOf("_")+1)
	def binaryID = message.getProperty("binaryID");
    def currentIndex = message.getProperty("currentIndex");
    def currentKey = "MessageMapping_PostProc_XSLT_${currentIndex}"
    def value = properties.get(currentKey)
    
    
    if (partnerDirID == null){
        throw new IllegalStateException("Partner ID is not set in Partner Directory'")
    }

    if (binaryID == null) {
        throw new IllegalStateException(" ID BINARY is not set in the BinaryID property");
    }

    def parameterValue = service.getParameter(binaryID, partnerDirID , BinaryData.class);
    if (parameterValue == null){
        throw new IllegalStateException("ID Binary parameter not found in the Partner Directory for the partner ID = "+ partnerDirID);
    }

    message.setHeader("CUSTOM_POST_PROC_XSLT","pd:" + partnerDirID +":" + binaryID + ":Binary");
    
    def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){

		messageLog.addCustomHeaderProperty(currentKey, "pd:" + partnerDirID +":" + binaryID + ":Binary");		
	}
	
    return message;
}
