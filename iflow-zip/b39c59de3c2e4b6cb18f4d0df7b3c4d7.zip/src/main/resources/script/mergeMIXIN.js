importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
	
	var map = message.getProperties();
    var mixinMapped = map.get("mixinMapped");
    if(!mixinMapped){
    	return message;
    }
    mixinMapped = JSON.parse(mixinMapped);
    
	var rawBP = JSON.parse(message.getBody().toString());
	mixinMapped.mixins.soa_mdg_businesspartner.businessPartner = {};
    copy(mixinMapped.mixins.soa_mdg_businesspartner.businessPartner, rawBP.BusinessPartnerSUITEReplicateRequestMessage.BusinessPartner);
	//message.setProperty("mixinMapped", mixinMapped);

	message.setBody(JSON.stringify(mixinMapped));
	return message;
}

function copy(json1, json2){
	
	var arrayType = {"Customer": true, "CustomerText": true, "TaxClassification": true, "UnloadingPoints": true, "SalesArrangement": true, "SalesArrangementText": true, "Supplier": true, "SupplierText": true, "TaxGrouping": true, "SubRange": true, "ProcurementArrangement": true, "PurchasingText": true, "PartnerFunctions": true, "QualityManagement": true, "ProcurementCardIssuingInstitutes": true, "AccountingInformation": true, "DunningInformation": true, "WithholdingTax": true, "AccountingText": true, "AddressInformation": true, "AddressUsage": true, "Web": true, "WebNote": true, "WebUsage": true, "Telephone": true, "TelephoneNote": true, "TelephoneUsage": true, "PostalAddress": true, "PersonName": true, "OrganisationName": true, "Facsimile": true, "FacsimileNote": true, "FacsimileUsage": true, "Email": true, "EmailNote": true, "EmailUsage": true, "AddressNote": true, "BankDetails": true, "Common": true, "Role": true, "Identification": true, "IndustrySector": true, "TaxNumber": true, "TextSAPScriptLine": true}; 
	var json = json1;
	for(var i in json2){
		if(i.charAt(0) === '@'){
			
		}
		else if(typeof json2[i] === "string"){
			json1[i.toLowerCase()] = json2[i];
		}
		else if(typeof json2[i] === "object"){      
	        
			// switch $ placeholder to value
	        if(json2[i].hasOwnProperty("$")){
	        	var value;
	        	value = json2[i].$;
	        	json2[i]["$"] = json2[i]["value"];
	        	json2[i].value = value;
	        }

			
			if(json2[i].hasOwnProperty("@nil")){			
				
			}
			else{
				
			if (arrayType[i]){ //handle arrays
				if(json2[i].length){
					json1[i] = copy([], json2[i]); //copy array into array
				}
				else{
					json1[i] = [copy({}, json2[i])]; //copy json into array
				}
			}
			else{
				json1[i] = copy({}, json2[i]); //copy json into json
			}
			}
		}
	}
	return json;
}