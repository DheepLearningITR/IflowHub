importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function convertNullValues(message) {
	var body = JSON.parse(message.getBody());
	if(body.contactEmail == "null"){
		body.contactEmail = null;
		message.setBody(JSON.stringify(body));
	}
	return message;
}

function checkChangesNeeded(message) {
	
	var map = message.getProperties();
    var mixinMapped = map.get("mixinMapped");
    if(!mixinMapped){
    	return message;
    }
    mixinMapped = JSON.parse(mixinMapped);
    
	var existingCustomer = JSON.parse(map.get("existingCustomerResponse"))[0];
	
	map.put("changesNeeded", changesNeeded(mixinMapped, existingCustomer));
	
	return message;
}

changesNeeded = function(json1, json2){
	var excludedObjects=["soa_mdg_businessPartner"];
	for(var i in json1){
	
		var excludedObject = false;
		for(var a in excludedObjects){
			if(excludedObjects[a] === i){
				excludedObject = true;
				break;
			}
		}
		
		if(!excludedObject && typeof(json1[i]) === "string"){
			if(json1[i] !== json2[i]){
				return true;
			}
		}
		else if (!excludedObject){
			return changesNeeded(json1[i], json2[i]);
		}
	}
	return false;
}