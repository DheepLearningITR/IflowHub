importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);


function removeBody(message) {
	var map = message.getProperties();
	var intData = map.get("internalData");
	message.setBody(intData);
	return message;
}
