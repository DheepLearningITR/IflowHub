import com.sap.gateway.ip.core.customdev.util.Message

Message countReturned(Message message){
    def body = message.getProperty("jsonArraySize") as String
    
    if (body?.isNumber()){
        message.setProperty("totalReturned",""+(Integer.parseInt(message.getProperty("totalReturned"))+ Integer.parseInt(body)))
        
    }
    
    return message
}



