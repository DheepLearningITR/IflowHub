import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    
    //Body
    def body = message.getBody(java.lang.String);

    def jsonSlurper = new JsonSlurper();
    def cfg = jsonSlurper.parseText(body);

    if(cfg.SalesOrderBulkReplication.SalesOrder != null){
        cfg.SalesOrderBulkReplication.SalesOrder.each{
            if(it.deletionIndicator != null){
                it.deletionIndicator = String.valueOf(it.deletionIndicator).toBoolean();
            }
            if(it.archivingIndicator != null){
                it.archivingIndicator = String.valueOf(it.archivingIndicator).toBoolean();
            }
            if(it.AccountingExchangeRate != null){
                it.AccountingExchangeRate = Double.parseDouble(it.AccountingExchangeRate);
            }
            if(it.TotalTaxAmount != null){
                it.TotalTaxAmount.value = Double.parseDouble(it.TotalTaxAmount.value);
            }
            if(it.TotalNetAmount != null) {
                it.TotalNetAmount.value = Double.parseDouble(it.TotalNetAmount.value);
            }
            if(it.PriceDetnExchangeRate != null){
                it.PriceDetnExchangeRate = Double.parseDouble(it.PriceDetnExchangeRate);
            }
            if(it.AdditionalValueDays != null){
                it.AdditionalValueDays = Integer.parseInt(it.AdditionalValueDays);
            }
            //Pricing Element
            if(it.PricingElement != null){
                it.PricingElement.each{
                    if(it.ConditionAmount != null){
                        it.ConditionAmount.value = Double.parseDouble(it.ConditionAmount.value);
                    }
                    if(it.ConditionBaseValue != null){
                        it.ConditionBaseValue.value = Double.parseDouble(it.ConditionBaseValue.value);
                    }
                    if(it.ConditionScaleBasisValue != null){
                        it.ConditionScaleBasisValue.value = Double.parseDouble(it.ConditionScaleBasisValue.value);
                    }
                    if(it.ConditionRateValue != null){
                        it.ConditionRateValue.value = Double.parseDouble(it.ConditionRateValue.value);
                    }
                    if(it.ConditionQuantity != null){
                        it.ConditionQuantity.value = Double.parseDouble(it.ConditionQuantity.value);
                    }
                    if(it.ConditionIsForStatistics != null){
                        it.ConditionIsForStatistics = String.valueOf(it.ConditionIsForStatistics).toBoolean();
                    }
                    if(it.ConditionIsManuallyChanged != null){
                        it.ConditionIsManuallyChanged = String.valueOf(it.ConditionIsManuallyChanged).toBoolean();
                    }
                    if(it.Properties != null){
                        it.Properties.each{
                            if(it.PricingElementIsDeletable != null){
                                it.PricingElementIsDeletable = String.valueOf(it.PricingElementIsDeletable).toBoolean();
                            }
                            if(it.PricingElementIsEditable != null){
                                it.PricingElementIsEditable = String.valueOf(it.PricingElementIsEditable).toBoolean();
                            }
                            if(it.ConditionQuantityIsEditable != null){
                                it.ConditionQuantityIsEditable = String.valueOf(it.ConditionQuantityIsEditable).toBoolean();
                            }
                            if(it.ConditionQuantityUnitIsEditable != null){
                                it.ConditionQuantityUnitIsEditable = String.valueOf(it.ConditionQuantityUnitIsEditable).toBoolean();
                            }
                            if(it.ConditionRateValueIsEditable != null){
                                it.ConditionRateValueIsEditable = String.valueOf(it.ConditionRateValueIsEditable).toBoolean();
                            }
                            if(it.ConditionRateValueUnitIsEditable != null){
                                it.ConditionRateValueUnitIsEditable = String.valueOf(it.ConditionRateValueUnitIsEditable).toBoolean();
                            }
                            if(it.ConditionAmountIsEditable != null){
                                it.ConditionAmountIsEditable = String.valueOf(it.ConditionAmountIsEditable).toBoolean();
                            }
                            if(it.ConditionAmountCurrencyIsEditable != null){
                                it.ConditionAmountCurrencyIsEditable = String.valueOf(it.ConditionAmountCurrencyIsEditable).toBoolean();
                            }
                        }
                    }
                }
            }
            //Sales Order Item
            if(it.Item != null){
                it.Item.each{
                    if(it.NetAmount != null){
                        it.NetAmount.value = Double.parseDouble(it.NetAmount.value);
                    }
                    if(it.NetPriceAmount != null){
                        it.NetPriceAmount.value = Double.parseDouble(it.NetPriceAmount.value);
                    }
                    if(it.TaxAmount != null){
                        it.TaxAmount.value = Double.parseDouble(it.TaxAmount.value);
                    }
                    if(it.CostAmount != null){
                        it.CostAmount.value = Double.parseDouble(it.CostAmount.value);
                    }
                    if(it.RequestedQuantity != null){
                        it.RequestedQuantity.value = Double.parseDouble(it.RequestedQuantity.value);
                    }
                    if(it.RequestedQuantityInBaseUnit != null){
                        it.RequestedQuantityInBaseUnit.value = Double.parseDouble(it.RequestedQuantityInBaseUnit.value);
                    }
                    if(it.ConfdDelivQtyInOrderQtyUnit != null){
                        it.ConfdDelivQtyInOrderQtyUnit.value = Double.parseDouble(it.ConfdDelivQtyInOrderQtyUnit.value);
                    }
                    if(it.ItemGrossWeight != null){
                        it.ItemGrossWeight.value = Double.parseDouble(it.ItemGrossWeight.value);
                    }
                    if(it.ItemNetWeight != null){
                        it.ItemNetWeight.value = Double.parseDouble(it.ItemNetWeight.value);
                    }
                    if(it.ItemVolume != null){
                        it.ItemVolume.value = Double.parseDouble(it.ItemVolume.value);
                    }
                    if(it.AdditionalValueDays != null){
                        it.AdditionalValueDays = Integer.parseInt(it.AdditionalValueDays);
                    }
                    //Schedule Line
                    if(it.ScheduleLine != null){
                        it.ScheduleLine.each{
                            if(it.ScheduleLineOrderQuantity != null){
                                it.ScheduleLineOrderQuantity.value = Double.parseDouble(it.ScheduleLineOrderQuantity.value);
                            }
                            if(it.ConfdOrderQtyByMatlAvailCheck != null){
                                it.ConfdOrderQtyByMatlAvailCheck.value = Double.parseDouble(it.ConfdOrderQtyByMatlAvailCheck.value);
                            }
                            if(it.DeliveredQtyInOrderQtyUnit != null){
                                it.DeliveredQtyInOrderQtyUnit.value = Double.parseDouble(it.DeliveredQtyInOrderQtyUnit.value);
                            }
                            if(it.OpenConfdDelivQtyInOrdQtyUnit != null){
                                it.OpenConfdDelivQtyInOrdQtyUnit.value = Double.parseDouble(it.OpenConfdDelivQtyInOrdQtyUnit.value);
                            }
                            if(it.CorrectedQtyInOrderQtyUnit != null) {
                                it.CorrectedQtyInOrderQtyUnit.value = Double.parseDouble(it.CorrectedQtyInOrderQtyUnit.value);
                            }
                        }
                    }
                    //Item Pricing Element
                    if(it.PricingElement != null){
                        it.PricingElement.each{
                            if(it.ConditionAmount != null){
                                it.ConditionAmount.value = Double.parseDouble(it.ConditionAmount.value);
                            }
                            if(it.ConditionBaseValue != null){
                                it.ConditionBaseValue.value = Double.parseDouble(it.ConditionBaseValue.value);
                            }
                            if(it.ConditionScaleBasisValue != null){
                                it.ConditionScaleBasisValue.value = Double.parseDouble(it.ConditionScaleBasisValue.value);
                            }
                            if(it.ConditionRateValue != null){
                                it.ConditionRateValue.value = Double.parseDouble(it.ConditionRateValue.value);
                            }
                            if(it.ConditionQuantity != null){
                                it.ConditionQuantity.value = Double.parseDouble(it.ConditionQuantity.value);
                            }
                            if(it.ConditionIsForStatistics != null){
                                it.ConditionIsForStatistics = String.valueOf(it.ConditionIsForStatistics).toBoolean();
                            }
                            if(it.ConditionIsManuallyChanged != null){
                                it.ConditionIsManuallyChanged = String.valueOf(it.ConditionIsManuallyChanged).toBoolean();
                            }
                            if(it.Properties != null){
                                it.Properties.each{
                                    if(it.PricingElementIsDeletable != null){
                                        it.PricingElementIsDeletable = String.valueOf(it.PricingElementIsDeletable).toBoolean();
                                    }
                                    if(it.PricingElementIsEditable != null){
                                        it.PricingElementIsEditable = String.valueOf(it.PricingElementIsEditable).toBoolean();
                                    }
                                    if(it.ConditionQuantityIsEditable != null){
                                        it.ConditionQuantityIsEditable = String.valueOf(it.ConditionQuantityIsEditable).toBoolean();
                                    }
                                    if(it.ConditionQuantityUnitIsEditable != null){
                                        it.ConditionQuantityUnitIsEditable = String.valueOf(it.ConditionQuantityUnitIsEditable).toBoolean();
                                    }
                                    if(it.ConditionRateValueIsEditable != null){
                                        it.ConditionRateValueIsEditable = String.valueOf(it.ConditionRateValueIsEditable).toBoolean();
                                    }
                                    if(it.ConditionRateValueUnitIsEditable != null){
                                        it.ConditionRateValueUnitIsEditable = String.valueOf(it.ConditionRateValueUnitIsEditable).toBoolean();
                                    }
                                    if(it.ConditionAmountIsEditable != null){
                                        it.ConditionAmountIsEditable = String.valueOf(it.ConditionAmountIsEditable).toBoolean();
                                    }
                                    if(it.ConditionAmountCurrencyIsEditable != null){
                                        it.ConditionAmountCurrencyIsEditable = String.valueOf(it.ConditionAmountCurrencyIsEditable).toBoolean();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if(cfg.SalesOrderBulkReplication.MessageHeader.ReconciliationIndicator != null){
        cfg.SalesOrderBulkReplication.MessageHeader.ReconciliationIndicator = String.valueOf(cfg.SalesOrderBulkReplication.MessageHeader.ReconciliationIndicator).toBoolean();
    }
    
    def builder = new groovy.json.JsonBuilder(cfg);
    //println(builder.toPrettyString());

    message.setBody(builder.toPrettyString());
    
    //Properties 
    // map = message.getProperties();
    // def sid = map.get("SalesOrderID");
    // if(sid == "900"){
    //     message.setHeader("Content-Type", "application/atom+xml");
    // } 
    // else {
    //     //message.setProperty("url", "https://cdp.eu5-st1.gigya.com/api/businessunits/4_xd1j6MCweNGhMZA8TUojbg/applications/HAIQiM9gFOa0G-UBCf0KLQ/dataevents/HCm_lOyzESKprCQq7MbCPg/webhook/event");
    //     message.setProperty("url", "https://cdp.EU5-prod.gigya.com/api/businessunits/4_xd1j6MCweNGhMZA8TUojbg/applications/HMhbhNET5Y_65b9aR2go7A/dataevents/HEwHhF_bW8QTP22lo8snjQ/cx/event");
    // }
    
    return message;

}
