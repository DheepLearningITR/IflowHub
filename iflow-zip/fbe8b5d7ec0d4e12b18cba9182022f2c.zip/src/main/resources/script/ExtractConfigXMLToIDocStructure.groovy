import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*
import groovy.xml.*

    class Config {
      String posex, lineNo, content
    }

  def Message processData(Message message) {
    def jsonPayload = new JsonSlurper().parseText(message.getBody(java.lang.String));
    def extractedString = jsonPayload.configXML;
    def counter1 = 0;
    def writer = new StringWriter();
    def Conf_XML = new MarkupBuilder(writer);
    def configContentList = []
    if (null != extractedString) {
      while (extractedString.length() > 0) {
        counter1++;
        def extractLength = 900;
        if (extractedString.length() < extractLength) {
          extractLength = extractedString.length();
        }
        def content = extractedString.substring(0, extractLength)

        configContentList << new Config(posex: "1", lineNo: counter1, content: content)
        extractedString = extractedString.replace(content, "");
      }


configContentList.eachWithIndex { item ,index ->

//If the content starts with space
    if ((item.content != null) && (item.content.length() > 0)) {
        if (item.content.startsWith(" ")) {
            item.content = configContentList[index - 1].content.drop(configContentList[index - 1].content.length() - 1).concat(item.content)
            configContentList[index - 1].content = configContentList[index - 1].content.substring(0,configContentList[index - 1].content.length() - 1)
        }
    }

// If the content ends with space
    if ((item.content != null) && (item.content.length() > 0)) {
        if (item.content.endsWith(" ")) {
            item.content = item.content.concat(configContentList[index + 1].content.substring(0,1))
            configContentList[index + 1].content = configContentList[index + 1].content.substring(1)
        }
    }
}


      Conf_XML.Configuration {
        setOmitEmptyAttributes(true)
        setOmitNullAttributes(true)
        configContentList.each {
          def that = it
          Config() {
            POSEX(that.posex)
            LINE_NO(that.lineNo)
            CONTENT(that.content)
          }
        }
      }

      String outxml = writer.toString();
      message.setBody(outxml);
      return message;
    }
  }
