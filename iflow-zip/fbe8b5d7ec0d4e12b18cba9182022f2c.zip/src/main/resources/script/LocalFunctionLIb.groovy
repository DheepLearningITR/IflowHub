import com.sap.it.api.mapping.*;

def String getSenderPort(String P1,MappingContext context){
	return context.getProperty("IDoc_SenderPort");
}

def String getSenderPartnerNumber(String P1,MappingContext context){
	return context.getProperty("IDoc_SenderPartner");
}

def String getReceiverPort(String P1,MappingContext context){
	return context.getProperty("IDoc_Receiverport");
}

def String getReceiverPartnerNumber(String P1,MappingContext context){
	return context.getProperty("IDoc_ReceiverPartnerNumber");
}

def String getSalesOrderType(String P1,MappingContext context){
	return context.getProperty("p_SalesOrderType");
}
