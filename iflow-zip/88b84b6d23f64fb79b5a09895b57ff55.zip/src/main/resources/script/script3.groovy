/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;

def Message enrichVariantAttirbutes(Message message) {
    //Body 
    def body = message.getBody();
    def jsonSlurper = new JsonSlurper();
    def productResponse = jsonSlurper.parse(body);
    
    def propertyMap = message.getProperties();
    String variantAttribPayload = propertyMap.get("variantAttribPayload");
    def mappedProduct = jsonSlurper.parseText(variantAttribPayload);
    def storedVariantAttributes = productResponse.variantAttributes;
    
    // Merge Attributes from Upscale
    storedVariantAttributes.each { storedVariantAttribute ->
        String storedVariantKey = storedVariantAttribute.key;
        def searchVariantAttribute = mappedProduct.variantAttributes.find { it.key == storedVariantKey };
        
        if(searchVariantAttribute == null) {
            def newVariantAttribute = ['key': storedVariantKey, 'value': storedVariantAttribute.value];
            mappedProduct.variantAttributes.addAll(newVariantAttribute);
        }
    }
    
    // Set body
    message.setBody(new JsonBuilder(mappedProduct).toPrettyString());
    
    return message;
}

def Message enhanceVariantAttirbutes(Message message) {
    //Body 
    def body = message.getBody(java.lang.String);
    def jsonSlurper = new JsonSlurper();
    def productPayload = jsonSlurper.parseText(body);
    String variantAttribPayload;
    Integer sleepTimer = 2000;
    
    if(productPayload.variantAttributes != null && !productPayload.variantAttributes.isEmpty()) {
        def enhancedVariantAttributes = new ArrayList();
        def groupedAttributes = productPayload.variantAttributes.groupBy {
            it.key
        }
    
        groupedAttributes.each { key, attribute -> 
            def newVariantAttribute = ['key': key];
            if(attribute.size > 1) {
                def value = "";
                attribute.each {
                    value = value + it.value + ";"
                }
                newVariantAttribute.value = value.substring(0,value.length()-1);
            }
            else{
                newVariantAttribute.value = attribute[0].value;
            }
            enhancedVariantAttributes.add(newVariantAttribute);
        }
        
        // Replace variantAttributes of payload with enhanced version
        productPayload.variantAttributes = enhancedVariantAttributes;
        
        // Set Enhanced Payload as a property
        variantAttribPayload = new JsonBuilder(productPayload).toPrettyString();
    }
    else{
        // Set body as a backup in property
        variantAttribPayload = body;
    }
    
    // Set Property - variantAttribPayload
    message.setProperty("variantAttribPayload", variantAttribPayload);
    
    // Wait for multiple variant attributes not to overlap
    def mappedProduct = jsonSlurper.parseText(variantAttribPayload);
    Integer mappedVariantLength = ((mappedProduct.variantAttributes == null) ? 0 : mappedProduct.variantAttributes.size);
    sleep(mappedVariantLength * sleepTimer);
    
    return message;
}


