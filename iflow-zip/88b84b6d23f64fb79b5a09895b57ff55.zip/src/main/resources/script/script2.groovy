/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;

def Message processCharacteristic(Message message) {
    //Body 
    def body = message.getBody();
    def jsonSlurper = new JsonSlurper();
    def variantAttribute = jsonSlurper.parse(body);
      
    if(variantAttribute.values != null && !(variantAttribute.values instanceof Collection)){
        def values = [];
        values.add(variantAttribute.values);
        variantAttribute.values = values;
        message.setBody(new JsonBuilder(variantAttribute).toPrettyString());
    }
      
    return message;
}

def Message processClassHierarchy(Message message) {
    //Body 
    def body = message.getBody();
    def jsonSlurper = new JsonSlurper();
    def categoryHierarchyData = jsonSlurper.parse(body);
      
    if(categoryHierarchyData.association != null && !(categoryHierarchyData.association instanceof Collection)){
        def categoryHierachies = [];
        categoryHierachies.add(categoryHierarchyData.association);
        message.setBody(new JsonBuilder(categoryHierachies).toPrettyString());
    }
    else {
        message.setBody(new JsonBuilder(categoryHierarchyData.association).toPrettyString());
    }
      
    return message;
}

def Message processProductCategory(Message message) {
    //Body 
    def body = message.getBody();
    def jsonSlurper = new JsonSlurper();
    def productCategoryData = jsonSlurper.parse(body);
      
    if(productCategoryData.productcategory != null && !(productCategoryData.productcategory instanceof Collection)){
        def productCategories = [];
        productCategories.add(productCategoryData.productcategory);
        message.setBody(new JsonBuilder(productCategories).toPrettyString());
    }
    else {
        message.setBody(new JsonBuilder(productCategoryData.productcategory).toPrettyString());
    }
    
    // Check Product Id
    
      
    return message;
}

def Message processVariantAssignment(Message message) {
    
    // Properties
    map = message.getProperties();
    
    //Body 
    def body = message.getBody(java.lang.String);
    def jsonSlurper = new JsonSlurper();
    def productVariantData = jsonSlurper.parseText(body);
      
    if(productVariantData.variantAttributes != null && !(productVariantData.variantAttributes instanceof Collection)){
        def variantAttributeArray = [];
        variantAttributeArray.add(productVariantData.variantAttributes);
        productVariantData.variantAttributes = variantAttributeArray;
        message.setBody(new JsonBuilder(productVariantData).toPrettyString());
    }
    else {
        message.setBody(new JsonBuilder(productVariantData).toPrettyString());
    }
    
    return message;
}

// Wait timer to ensure product replication is successful before pushing classification data
def Message waitingThread(Message message) {
    sleep(300);
    return message;
}

