import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def json = message.getBody(java.io.Reader)
    def jsonBody = new JsonSlurper().parse(json)
    
    def errors = jsonBody?.errors
    if (errors) {
        message.setProperty("medalliaError", "true")
    }
    return message
}