import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def json = message.getBody(java.io.Reader)
    def jsonBody = new JsonSlurper().parse(json)
    
    def hasNextPage = jsonBody?.data?.feedback?.pageInfo?.hasNextPage ?: false
    message.setProperty("hasNextPage", hasNextPage)

    if (hasNextPage) {
        def endCursor = jsonBody?.data?.feedback?.pageInfo?.endCursor
        message.setHeader("endCursor", endCursor)
    }
    
    return message
}