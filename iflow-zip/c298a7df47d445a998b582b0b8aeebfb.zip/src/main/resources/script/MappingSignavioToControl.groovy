import com.sap.gateway.ip.core.customdev.util.Message

import java.time.format.DateTimeFormatter

def Message processData(Message message) {
    def data = message.getProperty("controlData")

    if (data != null) {
        def extensionFieldName = message.getProperty("extensionFieldName")
        def mappings = message.getProperty("valueMappings")
        def metadatas = message.getProperty("metadatas")
        def signavioHost = message.getProperty("signavioHost")

        def output = positiveMap(data, signavioHost, mappings, metadatas, extensionFieldName)
        message.setProperty("controlData", output)
    }

    return message
}

def positiveMap(data, signavioHost, fieldMappings, metadatas, extensionFieldName) {
    def output = [:]
    def entryId = data.id
    output["name"] = data.title
    output["description"] = data.description
    output["controlRiskLevel"] = mapStandardField("controlRiskLevel", data, fieldMappings, metadatas)
    output["significance"] = mapStandardField("significance", data, fieldMappings, metadatas)
    output["operationFrequency"] = mapStandardField("operationFrequency", data, fieldMappings, metadatas)
    output["sourceSystem"] = "SIGNAVIO"
    output["externalId"] = entryId
    output["externalUrl"] = "${signavioHost}/p/hub/dictionary/entry/${entryId}".toString()

    output.extensionFieldValues = []
    output.extensionFieldValues << mapCategoryField(data, extensionFieldName)
    data.metaDataValues?.each{positiveMapOneField(it, fieldMappings, metadatas, output)}

    return output
}

def positiveMapOneField(entry, fieldMappings, metadatas, output) {
    def fieldMapping = fieldMappings.find{it.sourceIdentifier.equals(entry.key)}
    if (fieldMapping != null && fieldMapping.targetIdentifier.startsWith("Z_")) {
       def targetIdentifier = fieldMapping.targetIdentifier
       def metadata = metadatas.find{it.id.equals(entry.key)}

       if (metadata != null && targetIdentifier != null) {
          def cdfItem = [:]
          output.extensionFieldValues << cdfItem

          def handler = getValueHandler(metadata, fieldMapping, targetIdentifier)
          cdfItem.fieldName = targetIdentifier
          cdfItem.fieldValue = handler.valueFromSignavio(entry.value)
       }
    }
}

def mapStandardField(standardFieldName, data, fieldMappings, metadatas) {
    def fieldValue = ""
    def fieldMapping = fieldMappings.find{it.targetIdentifier.equals(standardFieldName)}
    if (fieldMapping != null) {
       def sourceIdentifier = fieldMapping.sourceIdentifier
       def entry = data.metaDataValues.find{it.key.equals(sourceIdentifier)}
       def metadata = metadatas.find{it.id.equals(sourceIdentifier)}

       if (metadata != null && sourceIdentifier != null && entry != null) {
          def handler = getValueHandler(metadata, fieldMapping, standardFieldName)
          fieldValue = handler.valueFromSignavio(entry.value)
       }
    }

    return fieldValue
}

def mapCategoryField(data, extensionFieldName) {
    def item = [:]
    item.fieldName = extensionFieldName

    def category = data.category
    item.fieldValue = category.substring(category.lastIndexOf('/') + 1)

    return item
}

interface ValueHandler {
    void setMetadata(metadata)

    Object valueFromSignavio(value)
}

def getValueHandler(metadata, fieldMapping, targetIdentifier) {
    def handler;
    switch (metadata.type) {
        case "MetaDataBoolean":
            handler = new BooleanValueHandler()
            break
        case "MetaDataDate":
            handler = new DateValueHandler()
            break
        case "MetaDataEnum":
            handler = new DropdownValueHandler()
            break
        case "MetaDataNumberInfo":
            handler = new NumberValueHandler()
            break
        case "MetaDataStringInfo":
            handler = new StringValueHandler()
            break
        default:
            break
    }

    handler?.metadata = metadata
    handler?.fieldMapping = fieldMapping
    handler?.targetIdentifier = targetIdentifier

    return handler
}

abstract class MetadataSupportValueHandler implements ValueHandler {
    Map metadata
    Map fieldMapping
    String targetIdentifier

    void setMetadata(metadata) {
        this.metadata = metadata
    }

    protected boolean onlyWildcards(List items) {
        return items.size() == 1 && items.find {"*".equals(it.source)} != null && items.find {"*".equals(it.target)} != null
    }
}

class BooleanValueHandler extends MetadataSupportValueHandler {
    Object valueFromSignavio(value) {
        List valueMappings = fieldMapping.valueMappings
        def stringValue = String.valueOf(value)
        def mappingValue = valueMappings.find {stringValue.equals(it.source)}?.target

        return mappingValue
    }
}

class DateValueHandler extends MetadataSupportValueHandler {
    static DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSX")
    static DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    Object valueFromSignavio(value) {
        def date = FORMATTER.parse(value.toString())

        return DATE_FORMATTER.format(date)
    }
}

class NumberValueHandler extends MetadataSupportValueHandler {
    Object valueFromSignavio(value) {
        return value
    }
}

class DropdownValueHandler extends MetadataSupportValueHandler {
    Object valueFromSignavio(value) {
        List metadataItems = metadata["items"]
        List valueMappings = fieldMapping.valueMappings
        def output = metadataItems?.find{it["value"].equals(value)}.title
        if (!onlyWildcards(metadataItems)) {
            def mappingValue = valueMappings.find {output.equals(it.source)}?.target
            if (mappingValue != null) {
                output = mappingValue
            }
        }

        return output
    }
}

class StringValueHandler extends MetadataSupportValueHandler {
    Object valueFromSignavio(value) {
        return value
    }
}
