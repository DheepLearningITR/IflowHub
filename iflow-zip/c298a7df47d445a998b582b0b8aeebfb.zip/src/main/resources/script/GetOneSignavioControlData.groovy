import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    message.setProperty("controlData", message.getProperty("data").remove(0).rep)

    return message
}
