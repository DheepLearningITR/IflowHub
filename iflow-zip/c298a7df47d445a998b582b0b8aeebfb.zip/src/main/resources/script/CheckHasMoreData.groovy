import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def controlSize = message.getProperty("controlSize") as Integer
    def offset = message.getProperty("controlOffset") as Integer
    def currentLast = (offset + 1) * 100
    if (currentLast >= controlSize) {
        message.setProperty("hasMore", false)
    } else {
        message.setProperty("hasMore", true)
        message.setProperty("controlOffset", offset + 1)
    }

    return message
}
