import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

	def map = message.getProperties();
	def SAP_ErrorModelStepID = map.get("SAP_ErrorModelStepID");
	message.setHeader("sapdme_errormodelstepid", SAP_ErrorModelStepID);

	def ex = map.get("CamelExceptionCaught");
	if (ex!=null) {
// 		message.setHeader("sapdme_errorclass",ex.getClass().getCanonicalName());
// 		message.setHeader("sapdme_errormessage",ex.getMessage());
	}

	return message;
}

def Message raiseException(Message message){
	message.setHeader("sapdme_errorclass","java.class.Exception");
    message.getProperties().put("CamelExceptionCaught", new java.lang.Exception(message.getBody().toString()));
    message.setBody(message.getProperty("CamelExceptionCaught").getMessage());
    throw new java.lang.Exception(message.getBody().toString());
	 
	return message;
}