import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.pd.BinaryData;

def Message processData(Message message) {

	def unique_id = message.getProperty('ENDPOINT_ID');
	def root_name = message.getProperty('ROOT_NAME');

	def PD_NAMESPACE = "DME_Generic_Processing_$unique_id";

	def service = ITApiFactory.getApi(PartnerDirectoryService.class, null);

	if (service == null){
		throw new IllegalStateException("Partner Directory Service not found");
	}

	def WORKFLOW_URL = service.getParameter("${root_name}_WORKFLOW_URL", PD_NAMESPACE, String.class);

	if (WORKFLOW_URL && !WORKFLOW_URL.equalsIgnoreCase("{{NULL}}")) {
		message.setProperty("WORKFLOW_TYPE", "IFLOW" );
		message.setProperty("WORKFLOW_URL", WORKFLOW_URL );
	} else {
		message.setProperty("WORKFLOW_TYPE", "DEFAULT" );
	}

	return message;
}

