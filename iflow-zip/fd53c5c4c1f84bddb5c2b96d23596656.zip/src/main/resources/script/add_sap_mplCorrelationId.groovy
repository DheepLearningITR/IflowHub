import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.slurpersupport.GPathResult
import org.codehaus.groovy.runtime.InvokerHelper

def Message processData(Message message) {

	def body = message.getBody(String.class)
	if(!body.contains("MessageHeader")) {
		return message
	}
	def sap_mplcorrelationId = message.getHeaders().get("SAP_MplCorrelationId")
	def toAdd = "<SAP_MplCorrelationId>" + sap_mplcorrelationId + "</SAP_MplCorrelationId>"
	def toAddXml = new XmlSlurper( false, true ).parseText( toAdd )
	def bodyXml = new XmlSlurper( false, true ).parseText( body)

	bodyXml.MessageHeader.appendNode(toAddXml)
	def result = asString(bodyXml);

	message.setBody(result)
	return message
}

private static String asString(GPathResult node) {
        try {
            Object builder = Class.forName("groovy.xml.StreamingMarkupBuilder").newInstance();
			InvokerHelper.setProperty(builder, "encoding", "UTF-8");
            Writable w = (Writable)InvokerHelper.invokeMethod(builder, "bindNode", node);
            return w.toString();
        } catch (Exception var3) {
            return "Couldn't convert node to string because: " + var3.getMessage();
        }
    }

