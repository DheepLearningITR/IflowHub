import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import groovy.transform.Field;

@Field String LOG_ID = 'LOIPRO04_STD_SERVICE_MERGE'
@Field Logger log = LoggerFactory.getLogger("com.sap.cpi.metviewer."+LOG_ID);

def Message processData(Message message) {
	def root_name = message.getProperty('ROOT_NAME')
	
	if(root_name.equals("LOIPRO04_PRODORDER") || root_name.equals("LOIPRO05_PRODORDER")){
	
		def bodyRequest = message.getBody(String.class);
		def bodyIdoc = message.getProperties().get('prexslt_payload');
		def ns0 = new groovy.xml.Namespace("http://sap.com/xi/XI/SplitAndMerge",'ns0');
		def sourceMessage                = new XmlParser().parseText(bodyRequest);
		def originalMessage                = new XmlParser().parseText(bodyIdoc);
		def targetMessage                = new XmlParser().parseText(getTargetMessageTemplate());
		targetMessage[ns0.Message1][0].append(sourceMessage);
		targetMessage[ns0.Message2][0].append(originalMessage);
		def result = XmlUtil.serialize(targetMessage);
		message.setBody(result);

	}
		return message;
}

def getTargetMessageTemplate() {
	return '''
<ns0:Messages xmlns:ns0="http://sap.com/xi/XI/SplitAndMerge">
<ns0:Message1>
</ns0:Message1>
<ns0:Message2>
</ns0:Message2>
</ns0:Messages>
'''.stripMargin();
}


