import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {

	def body1 = message.getBody(String.class);
	def body2 = message.getProperties().get('prexslt_payload');

	def ns0 = new groovy.xml.Namespace("http://sap.com/xi/XI/SplitAndMerge",'ns0');

	def SourceMessage                = new XmlParser().parseText(body1);
	def OriginalMessage                = new XmlParser().parseText(body2);
	def TargetMessage                = new XmlParser().parseText(getTargetMessageTemplate());

	TargetMessage[ns0.Message1][0].append(SourceMessage);
	TargetMessage[ns0.Message2][0].append(OriginalMessage);
	def result = XmlUtil.serialize(TargetMessage);

	message.setBody(result);

	return message;
}

def getTargetMessageTemplate() {
	return '''
<ns0:Messages xmlns:ns0="http://sap.com/xi/XI/SplitAndMerge">
<ns0:Message1>
</ns0:Message1>
<ns0:Message2>
</ns0:Message2>
</ns0:Messages>
'''.stripMargin();
}
