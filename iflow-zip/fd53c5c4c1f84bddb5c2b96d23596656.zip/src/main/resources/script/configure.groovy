import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.pd.BinaryData;

def Message processData(Message message) {

	def unique_id = message.getProperty('ENDPOINT_ID');
	def root_name = message.getProperty('ROOT_NAME');
	def xsltRevision = message.getHeaders().get('SAP_RequiredXsltVersion');
	if("0".equals(xsltRevision)){
		xsltRevision = null;
	}
	def xslt_id_with_ver = xsltRevision ? "_${xsltRevision}" : "";
	def PD_NAMESPACE = "DME_Generic_Processing_$unique_id";

	def service = ITApiFactory.getApi(PartnerDirectoryService.class, null);

	if (service == null){
		throw new IllegalStateException("Partner Directory Service not found");
	}

	// MATMAS03_CUSTOM_PREXSLT_IFLOW_URL
	// MATMAS03_STD_PREXSLT_IFLOW_URL

	/*
	 * Author: I043234
	 *
	 * Changes on 2020-07-15: adding support of unique_id in copy_pd_parameter
	 */
	copy_pd_parameter('PREXSLT_IFLOW_URL',      "${root_name}_CUSTOM_PREXSLT_IFLOW_URL",      "${root_name}_STD_PREXSLT_IFLOW_URL", PD_NAMESPACE,  unique_id, message, service);
	copy_pd_parameter('POSTXSLT_IFLOW_URL',     "${root_name}_CUSTOM_POSTXSLT_IFLOW_URL",     "${root_name}_STD_POSTXSLT_IFLOW_URL", PD_NAMESPACE,  unique_id, message, service);
	copy_pd_parameter('SERVICE_IFLOW_URL',      "${root_name}_CUSTOM_SERVICE_IFLOW_URL",      "${root_name}_STD_SERVICE_IFLOW_URL", PD_NAMESPACE,  unique_id, message, service);
	copy_pd_parameter('POSTSERVICE_IFLOW_URL',  "${root_name}_CUSTOM_POSTSERVICE_IFLOW_URL",  "${root_name}_STD_POSTSERVICE_IFLOW_URL", PD_NAMESPACE,  unique_id, message, service);
	copy_pd_parameter('ERRORHANDLER_IFLOW_URL', "${root_name}_CUSTOM_ERRORHANDLER_IFLOW_URL", "${root_name}_STD_ERRORHANDLER_IFLOW_URL", PD_NAMESPACE,  unique_id, message, service);
	copy_pd_parameter('IDENTIFIER', "${root_name}_CUSTOM_IDENTIFIER", "${root_name}_STD_IDENTIFIER", PD_NAMESPACE, unique_id, message, service);

	copy_pd_parameter('RAISE_EXCEP_IF_XSLT_MISSING', "${root_name}_RAISE_EXCEP_IF_XSLT_MISSING","${root_name}_RAISE_EXCEP_IF_XSLT_MISSING", PD_NAMESPACE, unique_id, message, service);
	
	copy_binary_pd_parameter('XSLT_ID',      "${root_name}_CUSTOM_XSLT${xslt_id_with_ver}",      "${root_name}_STD_XSLT${xslt_id_with_ver}", PD_NAMESPACE, unique_id, message, service);
	if(message.getProperties().get('XSLT_ID') == null && "TRUE".equalsIgnoreCase((message.getProperties().get('RAISE_EXCEP_IF_XSLT_MISSING')))){
		throw new Exception("No XSLT mapping configuration exists for ${root_name}, may caused by SAP Cloud Integarion version too low, check if there were updates available for the SAP Cloud Integraion package. Please contact administrator for checking if the issue still there after update.");
	}
	/*
	 * Author: I043234
	 *
	 * Changes on 2020-07-15: adding binary pd parameter RESPONSE_XSLT_ID for the new integration enablement
	 */
	copy_binary_pd_parameter('RESPONSE_XSLT_ID',      "${root_name}_CUSTOM_RESPONSE_XSLT${xslt_id_with_ver}",      "${root_name}_STD_RESPONSE_XSLT${xslt_id_with_ver}", PD_NAMESPACE, unique_id, message, service);
	
	/*
	 * Author: I043234
	 *
	 * Changes on 2020-09-22: adding support of value mappings
	 */
	copy_pd_parameter('REQUEST_VM_IFLOW_URL',      "${root_name}_CUSTOM_REQUEST_VM_IFLOW_URL",      "${root_name}_STD_REQUEST_VM_IFLOW_URL", PD_NAMESPACE,  unique_id, message, service);
	copy_pd_parameter('RESPONSE_VM_IFLOW_URL',      "${root_name}_CUSTOM_RESPONSE_VM_IFLOW_URLL",      "${root_name}_STD_RESPONSE_VM_IFLOW_URL", PD_NAMESPACE,  unique_id, message, service);
	
	/*
	 * Author: I043234
	 *
	 * Changes on 2020-09-15: adding support for multistep service calls (maximum 5 steps are supported for now)
	 */
	ArrayList<String> xsltIdList = new ArrayList<String>();
	for(int i = 0; i < 5; i++) {
		String suffix = String.format("%02d", i);
		String propName = "SERVICE_CHAIN_XSLT_ID_${suffix}";
		copy_binary_pd_parameter(propName, "${root_name}_CUSTOM_SERVICE_CHAIN_XSLT_${suffix}", "${root_name}_STD_SERVICE_CHAIN_XSLT_${suffix}", PD_NAMESPACE, unique_id, message, service);
		String xsltId = message.getProperty(propName);
		if (xsltId) {
			xsltIdList.add(xsltId);
		}
	}
	if (xsltIdList.size > 0) {
		message.setHeader("OriginalRequest", message.getBody(String));
		message.setHeader("ServiceChainXsltIdList", xsltIdList);
	}
	
	return message;
}

def Message preLoadConfig(Message message) {
	def unique_id = message.getProperty('ENDPOINT_ID');
	def root_name = message.getProperty('ROOT_NAME');
	
	def PD_NAMESPACE = "DME_Generic_Processing_$unique_id";

	def service = ITApiFactory.getApi(PartnerDirectoryService.class, null);

	if (service == null){
		throw new IllegalStateException("Partner Directory Service not found");
	}
	
	copy_pd_parameter('CHK_DMC_VER',      "${root_name}_CHK_DMC_VER",      "${root_name}_CHK_DMC_VER", PD_NAMESPACE,  unique_id, message, service);
	copy_single_parameter('LATEST_XSLT_REV', "${root_name}_STD_XSLT_LATEST_REV", PD_NAMESPACE, message, service);
	return message;
}

def void copy_single_parameter(String propname, String pdname, String pid, def message, def service) {
	
	def VALUE1 = service.getParameter(pdname, pid, String.class);
	message.setProperty(propname, VALUE1 );
	
}

def Message replaceOriginalRequestHeader(Message message) {
	if (message.getHeaders().get("OriginalRequest") != null){
		message.setHeader("OriginalRequest", message.getBody(String));
	}
	return message;
}
/*
 * Author: I043234
 *
 * Changes on 2020-07-15: adding support of unique_id in copy_pd_parameter
 */
def void copy_pd_parameter(String propname, String pdname1, String pdname2, String pid, def unique_id, def message, def service) {

	def VALUE1 = service.getParameter(pdname1, pid, String.class);
	def VALUE2 = service.getParameter(pdname2, pid, String.class);
	
	if (VALUE1 && !VALUE1.equalsIgnoreCase("{{NULL}}")) {
		message.setProperty(propname, VALUE1.replaceAll("\\{\\{ENDPOINT_ID\\}\\}", "$unique_id") );
	} else if (VALUE2 && !VALUE2.equalsIgnoreCase("{{NULL}}")) {
		message.setProperty(propname, VALUE2.replaceAll("\\{\\{ENDPOINT_ID\\}\\}", "$unique_id") );
	}
}

def void copy_binary_pd_parameter(String propname, String pdname1, String pdname2, String pid, def unique_id, def message, def service) {

	def VALUE1 = service.getParameter(pdname1, pid, BinaryData.class);
	def VALUE2 = service.getParameter(pdname2, pid, BinaryData.class);
	if (VALUE1) {
		// MATMAS03_CUSTOM_XSLT
		message.setProperty(propname, "pd:DME_Generic_Processing_$unique_id:$pdname1:Binary" );
	} else if (VALUE2) {
		// MATMAS03_STD_XSLT
		message.setProperty(propname, "pd:DME_Generic_Processing_$unique_id:$pdname2:Binary" );
	}
}
