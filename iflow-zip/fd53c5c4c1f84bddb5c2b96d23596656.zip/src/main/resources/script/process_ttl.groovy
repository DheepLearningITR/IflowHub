import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;


def Message processData(Message message) {
	def MAX_TTL = 10;

	// Time-To-Live header cannot be bigger than 10.
	// It is increased by every iflow execution by one

	def headerValue = message.getHeaders().get('DME_TTL');

	if (headerValue) {
		if (headerValue.isInteger()) {
			int ttl = headerValue as Integer

			if (ttl > MAX_TTL) throw new RuntimeException('DME_TTL header is too big. Possible infinite loop prevented.')
			ttl ++;
			message.setHeader('DME_TTL', "$ttl");
		} else {
			throw new RuntimeException("Unexpected value of DME_TTL: $headerValue")
		}
	} else {
		message.setHeader('DME_TTL', "1");
	}

	return message;
}

