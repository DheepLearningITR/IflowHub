import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {

	def prexslt_payload = message.getProperties().get('prexslt_payload');
	def postxslt_payload = message.getProperties().get('postxslt_payload');
	def body = getXmlBody(message);

	def ns0 = new groovy.xml.Namespace("http://sap.com/xi/XI/SplitAndMerge",'ns0');

	def prexslt_payload_xml              = new XmlParser().parseText(prexslt_payload);
	def postxslt_payload_xml             = new XmlParser().parseText(postxslt_payload);
	def TargetMessage                    = new XmlParser().parseText(getTargetMessageTemplate());

	TargetMessage[ns0.Message1][0].append(prexslt_payload_xml);
	TargetMessage[ns0.Message2][0].append(postxslt_payload_xml);
	TargetMessage[ns0.Message3][0].append(body);
	def result = XmlUtil.serialize(TargetMessage);

	message.setBody(result);

	return message;
}

/**
1. body can be empty, then it should be <Response>No Content</Response>
2. body can be a non-xml string, then it should be wrapped to xml format
3. body should be parsed out 
**/
def getXmlBody(Message message){
	String body = message.getBody(String.class)?.trim()?:"<Response>No Content</Response>";
	try{
		return new XmlParser().parseText(body);
	}catch(org.xml.sax.SAXParseException e){
		return new XmlParser().parseText("<Response>"+ body +"</Response>");
	}
}


def getTargetMessageTemplate() {
	return '''
<ns0:Messages xmlns:ns0="http://sap.com/xi/XI/SplitAndMerge">
<ns0:Message1>
</ns0:Message1>
<ns0:Message2>
</ns0:Message2>
<ns0:Message3>
</ns0:Message3>
</ns0:Messages>
'''.stripMargin();
}
