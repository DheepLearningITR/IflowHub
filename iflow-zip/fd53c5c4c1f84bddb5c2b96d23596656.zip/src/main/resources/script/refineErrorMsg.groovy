import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) { //get a map of properties
    def map = message.getProperties()
    def ex = map.get('CamelExceptionCaught')

    if (ex != null) {
        def causeMessage = ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage()
        message.setBody(causeMessage)
    }
    return message;
}
