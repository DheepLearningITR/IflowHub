import com.sap.gateway.ip.core.customdev.util.Message
import groovy.transform.Field

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;
import org.slf4j.Logger
import org.slf4j.LoggerFactory

@Field String LOG_ID = 'GENERAL_MESSAGE_PROCESSOR'
@Field Logger log = LoggerFactory.getLogger("com.sap.cpi.metviewer."+LOG_ID);


def Message processData(Message message) {

	def body = message.getBody(String.class);
	/*
	 * Author: I043234
	 *
	 * Bug fix for getting substring of message body.
	 *
	 * If the root element contains many attributes (e.g. many XML namespace prefix definitions), the substring
	 * of the first 200 characters truncates the root element and leads to exception:
	 * com.ctc.wstx.exc.WstxEOFException: Unexpected EOF in attribute value at [row,col {unknown-source}]: [1,200].
	 *
	 * To fix this issue, usage of substring should be avoided.
	 *
	 */
	//def substr = (bodyLength < 200) ? body.substring(0,bodyLength) : body.substring(0,200);
	//def ba = substr.getBytes();

	def name = null;
	/**
	 * below is for xml root name as root name scenario, extension IDoc scenario is also included
	 */
	name = getRootNameFromXmlPayload(body, message, name)
	/*
	 * Author: I043234
	 *
	 * Support custom root name
	 * Support OData operation
	 */
	String customRootName = message.getHeaders().get("CustomRootName");
	if (customRootName) {
		name = customRootName;
	} else{
		String odataMethod = message.getHeaders().get("ODataMethod");
		if (odataMethod) {
			name = "${name}_${odataMethod}";
		}
	}

	message.setProperty("ROOT_NAME", name );

	message.setHeader("SAP_MessageType", name );



	return message;
}

private String getRootNameFromXmlPayload(String body, Message message, String name) {
	// handle xml payload only
	def ba = body.getBytes();
	ByteArrayInputStream is = new ByteArrayInputStream(ba);
	XMLInputFactory xmlif = (XMLInputFactory) XMLInputFactory.newInstance();
	xmlif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.FALSE);
	xmlif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.TRUE);
	xmlif.setProperty(XMLInputFactory.IS_COALESCING, Boolean.FALSE);

	try {
		XMLStreamReader xmlr = (XMLStreamReader) xmlif.createXMLStreamReader(is);
		String originRootName = null;
		int event;
		while (xmlr.hasNext() && (name == null)) {
			event = xmlr.next();
			switch (event) {
				case XMLEvent.START_DOCUMENT:
					break;
				case XMLEvent.START_ELEMENT:
					originRootName = xmlr.getLocalName();
					name = getDocType(xmlr);
					body = changeRootNameAndRemoveExtensionIdoc(body, originRootName, name);
					message.setBody(body);
					break;
			}
		}
	} catch (Exception ex) {
		log.error("processData error", ex);
	}
	return name;
}

def String getDocType(XMLStreamReader xmlStreamReader) {
	String docRootName = xmlStreamReader.getLocalName(); // record the first rootname as the default
	//this falls into scenario doctype start with Z, the actual rootname should be the value on tag IDOCTYP
	int event;
	while (xmlStreamReader.hasNext()) {
		event = xmlStreamReader.next()
		if (event == XMLEvent.START_ELEMENT && "IDOCTYP".equals(xmlStreamReader.getLocalName())) {
			xmlStreamReader.next();
			if (xmlStreamReader.hasText()) {
				docRootName = xmlStreamReader.getText();
				break;
			}
		}
	}
	return docRootName;
}

def String changeRootNameAndRemoveExtensionIdoc(String body, String originRootName, String name) { 
	def node = new XmlSlurper(false, false).parseText(body);
	node.depthFirst().findAll { it.name()== 'IDOCTYP' }*.replaceNode{
		CUSTOMED_EXT_DOC_TYPE(originRootName)
	}; //record the Idocs original name into CUSTOMED_EXT_DOC_TYPE node

	if (!originRootName.equalsIgnoreCase(name)) {
		//when rootname is not equal to IdocType, this is extension Idoc scenario, change only the rootname of Idoc to standard to find its standard xslt
		def attributes = node.attributes();
		def content = node.children().find { it.name()== 'IDOC' }; //the content is under IDOC segment
		def newNode = new XmlSlurper(false, false).parseText(groovy.xml.XmlUtil.serialize(new Node(null, name, attributes)));
		newNode.appendNode(content);
		return groovy.xml.XmlUtil.serialize(newNode);
	} else {
		return groovy.xml.XmlUtil.serialize(node);
	}
}
