import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import groovy.transform.Field
import groovy.xml.XmlUtil

import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

@Field static final String VM_AGENCY_DM = 'DM'
@Field static final String VM_IDENTIFIER_Plant = 'Plant'
@Field static final String VM_AGENCY_ERP = 'ERP'
@Field static final String VM_IDENTIFIER_Time_Zone = 'Time Zone'
@Field static final Map FIELDS_CONFIGURATION = [
        'ERP_TT_INDIRECT_LABOR_RECORD_CRT'     : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'approvedAt'
                ],
                'dateNodes'    : [
                        'workDate': ['workDate', 'startTime']
                ],
                'timeNodes'    : [
                        'startTime': ['workDate', 'startTime'],
                        'endTime'  : ['workDate', 'endTime']
                ]
        ],
        'ERP_TT_DIRECT_LABOR_RECORD_SRV_CRT'   : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'approvedAt'
                ],
                'dateNodes'    : [
                        'startDate': ['startDate', 'startTime'],
                        'endDate'  : ['endDate', 'endTime']
                ],
                'timeNodes'    : [
                        'startTime': ['startDate', 'startTime'],
                        'endTime'  : ['endDate', 'endTime']
                ]
        ],
        'ERP_TT_PROD_TIME_RECORD_PROD_CRT'     : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'approvedAt'
                ],
                'dateNodes'    : [
                        'startDate': ['startDate', 'startTime'],
                        'endDate'  : ['endDate', 'endTime']
                ],
                'timeNodes'    : [
                        'startTime': ['startDate', 'startTime'],
                        'endTime'  : ['endDate', 'endTime']
                ]
        ],
        'ERP_TT_PROD_TIME_RECORD_PROC_CRT'     : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'approvedAt'
                ],
                'dateNodes'    : [
                        'startDate': ['startDate', 'startTime'],
                        'endDate'  : ['endDate', 'endTime']
                ],
                'timeNodes'    : [
                        'startTime': ['startDate', 'startTime'],
                        'endTime'  : ['endDate', 'endTime']
                ]
        ],
        'ERP_TT_DLR_PTR_PROD_CANCEL'           : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'cancelledAt'
                ]
        ],
        'ERP_TT_DLR_PTR_PROC_CANCEL'           : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'cancelledAt'
                ]
        ],
        'ERP_SRV_ORDER_CONF_START'             : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'postingDate'
                ]
        ],
        'ERP_SRV_ORDER_CONF_COMPLETE'          : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'postingDate'
                ]
        ],
        'ERP_SRV_ORDER_COMPONENT_ADD'          : [
                'plantNode'    : 'site',
                'dateTimeNodes': [
                        'dateTime'
                ]
        ],
        'ERP_SRV_ORDER_COMPONENT_REMOVE'       : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'postingDate'
                ]
        ],
        'ERP_TT_DIRECT_LABOR_RECORD_PROD_CRT'  : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'approvedAt'
                ],
                'dateNodes'    : [
                        'startDate': ['startDate', 'startTime'],
                        'endDate'  : ['endDate', 'endTime']
                ],
                'timeNodes'    : [
                        'startTime': ['startDate', 'startTime'],
                        'endTime'  : ['endDate', 'endTime']
                ]
        ],
        'ERP_TT_DIRECT_LABOR_RECORD_PROC_CRT'  : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'approvedAt'
                ],
                'dateNodes'    : [
                        'startDate': ['startDate', 'startTime'],
                        'endDate'  : ['endDate', 'endTime']
                ],
                'timeNodes'    : [
                        'startTime': ['startDate', 'startTime'],
                        'endTime'  : ['endDate', 'endTime']
                ]
        ],
        'ERP_TT_INDIRECT_LABOR_RECORD_CANCEL'  : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'cancelledAt'
                ]
        ],
        'ERP_TT_DIRECT_LABOR_RECORD_SRV_CANCEL': [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'cancelledAt'
                ]
        ],
        'GOODS_RECEIPT'                        : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'postingDate',
                        'manufactureDate'
                ]
        ],
        'PROD_ORDER_GOODS_RECEIPT'             : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'postingDate',
                        'manufactureDate'
                ]
        ],
        'ERP_BULK_COMPONENT_ADD'               : [
                'plantNode'    : 'plant',
                'dateTimeNodes': [
                        'dateTime'
                ]
        ]
]

Message processData(Message message) {
    String root_name = message.getHeaders().get('CustomRootName')
    def config = FIELDS_CONFIGURATION[root_name]
    if (!config) {
        return message;
    }

    def xmlPayload = message.getBody(String)
    def xml = new XmlSlurper(false, true).parseText(xmlPayload)

    // Get plantNode
    def plantNode = config.plantNode
    def plantValue = xml."${plantNode}".text()
    def timeZone = getTimeZone(plantValue)

    if (!timeZone) {
        return message;
    }
    message.setProperty('timeZoneConversion', true)
    //all changes are in the changes map
    def changes = []

    // Process dateTimeNodes
    config.dateTimeNodes.each { timeNode ->
        def nodes = getNode(xml, timeNode)
        if (nodes instanceof groovy.util.slurpersupport.GPathResult && nodes.size() > 1) {
            nodes.each { node ->
                def timeValue = node.text()
                if (timeValue != null && !timeValue.isEmpty()) {
                    def convertedTime = convertUTCTimeToERP(timeValue, timeZone)
                    changes << [node: node, newValue: convertedTime]
                }
            }
        } else {
            def timeValue = nodes.text()
            if (timeValue != null && !timeValue.isEmpty()) {
                def convertedTime = convertUTCTimeToERP(timeValue, timeZone)
                changes << [node: nodes, newValue: convertedTime]
            }
        }
    }

    //process dateNodes
    config.dateNodes.each { nodeName, value ->
        def nodes = getNode(xml, nodeName)
        if (nodes.size() > 1) {
            def dateNodeConfig = getNode(xml, value[0])
            def timeNodeConfig = getNode(xml, value[1])
            if (nodeListValid(nodes, dateNodeConfig, timeNodeConfig)) {
                // Both are lists of the same size
                processNodePairs(nodes, dateNodeConfig, timeNodeConfig, timeZone, changes, { node, dateValue, timeValue, zone ->
                    def convertedTime = convertUTCDateToERPDate(dateValue, timeValue, zone)
                    changes << [node: node, newValue: convertedTime]
                })
            } else {
                throw new IllegalArgumentException("Mismatched node sizes for dateNodes: ${nodeName}")
            }
        } else {
            // Both are single nodes
            def dateValue = xml."${value[0]}".text()
            def timeValue = xml."${value[1]}".text()
            if (dateValue && timeValue) {
                def convertedTime = convertUTCDateToERPDate(dateValue, timeValue, timeZone)
                changes << [node: nodes, newValue: convertedTime]
            }
        }
    }

    //process timeNodes
    config.timeNodes.each { nodeName, value ->
        def nodes = getNode(xml, nodeName)
        if (nodes.size() > 1) {
            def dateNodeConfig = getNode(xml, value[0])
            def timeNodeConfig = getNode(xml, value[1])
            if (nodeListValid(nodes, dateNodeConfig, timeNodeConfig)) {
                // Both are lists of the same size
                processNodePairs(nodes, dateNodeConfig, timeNodeConfig, timeZone, changes, { node, dateValue, timeValue, zone ->
                    def convertedTime = convertUTCTimeToERPTime(dateValue, timeValue, zone)
                    changes << [node: node, newValue: convertedTime]
                })
            } else {
                throw new IllegalArgumentException("Mismatched node sizes for timeNodes: ${nodeName}")
            }
        } else {
            // Both are single nodes
            def dateValue = xml."${value[0]}".text()
            def timeValue = xml."${value[1]}".text()
            if (dateValue && timeValue) {
                def convertedTime = convertUTCTimeToERPTime(dateValue, timeValue, timeZone)
                changes << [node: nodes, newValue: convertedTime]
            }
        }
    }

    // Apply changes all at once
    changes.each { change ->
        change.node.replaceBody(change.newValue)
    }

    message.setBody(XmlUtil.serialize(xml))
    return message

}

def processNodePairs(nodes, dateNodeConfig, timeNodeConfig, timeZone, changes, closure) {
    for (int i = 0; i < nodes.size(); i++) {
        def node = nodes[i]
        def dateValue = (dateNodeConfig instanceof groovy.util.slurpersupport.GPathResult && dateNodeConfig.size() > 1) ? dateNodeConfig[i].text() : dateNodeConfig.text()
        def timeValue = (timeNodeConfig instanceof groovy.util.slurpersupport.GPathResult && timeNodeConfig.size() > 1) ? timeNodeConfig[i].text() : timeNodeConfig.text()
        if (timeValue && dateValue) {
            closure(node, dateValue, timeValue, timeZone)
        }
    }
}

//check if the configured node(which is a list) is valid, if any one dateNodeConfig or timeNodeConfig is a node list, they should be of the same size
private boolean nodeListValid(def nodes, def dateNodeConfig, def timeNodeConfig) {
    boolean isDateNodeList = dateNodeConfig instanceof List && dateNodeConfig.size() > 1
    boolean isTimeNodeList = timeNodeConfig instanceof List && timeNodeConfig.size() > 1
    if (isDateNodeList && dateNodeConfig.size() != nodes.size()) {
        return false
    }
    if (isTimeNodeList && timeNodeConfig.size() != nodes.size()) {
        return false
    }

    if (isDateNodeList && isTimeNodeList && dateNodeConfig.size() != timeNodeConfig.size()) {
        return false
    }

    return true
}

private String getTimeZone(String plant) {
    def vm = ITApiFactory.getService(ValueMappingApi.class, null)
    def timeZone = vm.getMappedValue(VM_AGENCY_DM, VM_IDENTIFIER_Plant, plant, VM_AGENCY_ERP, VM_IDENTIFIER_Time_Zone)
    return timeZone
}

private String convertUTCDateToERPDate(String date, String time, String erpTimeZone) {
    if (!time.endsWith('Z')) {
        time += 'Z'
    }
    String dateTime = "${date}T${time}"
    String erpDateTime = convertUTCTimeToERP(dateTime, erpTimeZone)
    return erpDateTime.split('T')[0]
}

private String convertUTCTimeToERPTime(String date, String time, String erpTimeZone) {
    if (!time.endsWith('Z')) {
        time += 'Z'
    }
    String dateTime = "${date}T${time}"
    String erpDateTime = convertUTCTimeToERP(dateTime, erpTimeZone)
    return erpDateTime.split('T')[1]
}

private String convertUTCTimeToERP(String time, String erpTimeZone) {
    ZonedDateTime utcTime = ZonedDateTime.parse(time, DateTimeFormatter.ISO_ZONED_DATE_TIME.withZone(ZoneId.of('UTC')))
    // Convert the time to the target ERP timezone
    ZonedDateTime erpTime = utcTime.withZoneSameInstant(ZoneId.of(erpTimeZone))
    return erpTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
}

private getNode(def xml, String path) {
    def parts = path.split('\\.')
    def node = xml
    parts.each { part ->
        node = node."${part}"
    }
    return node
}
