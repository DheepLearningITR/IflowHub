import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.transform.Field

@Field static final String HEADER_CUSTOM_ROOT_NAME = "CustomRootName";
@Field static final String HEADER_INTEGRATION_WORKFLOW = "IntegrationWorkflow";
@Field static final String HEADER_ENTRY_COMPONENT_NAME = "EntryComponent";


Message processData(Message message) {

    String integrationWorkflow = message.getHeaders().get(HEADER_INTEGRATION_WORKFLOW);
    if (integrationWorkflow){
        //integrationName come from caller actively setting
        message.setHeader(HEADER_CUSTOM_ROOT_NAME, integrationWorkflow);
        message.setHeader(HEADER_ENTRY_COMPONENT_NAME, integrationWorkflow)
    }
    return message;
}