import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;
import java.lang.String;
import com.sap.it.api.mapping.*;


def validateBody(Message message) {
    try{
        //def headers = message.getHeaders();
        def body = message.getBody() as String
        //will not work because it uses the same xml parser
        containsIllegalCharacters(body)
        def xmlReader = new XmlSlurper().parse(message.getBody(java.io.Reader))
        //xmlReader?.IBPWriteBatches?.IBPWriteBatch?.@Name.find() {it -> containsIllegalCharacters(it.text())} != null
        
        
    }catch(Exception e){
        throw new Exception('Validaton Error: ' + e.getMessage(),e)
    }
    return message;
}

def containsIllegalCharacters(String stringToCheck){
    //(?<==")[^"]*([&<>])[^"]*(?=")/
    def pattern = /(?<==")[^"]*([<>])[^"]*(?=")/   
    def matcher = (stringToCheck =~ pattern)
    if(matcher.find()){throw new Exception('Illegal Character(s) in XML body(>;<)')}
    
}
