/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import org.apache.commons.codec.binary.Base64;

def Message processData(Message message) {
    
    //Properties 
    map = message.getProperties();
    def cdcAppkey = map.get("cdcAppkey")
    
    // Prepare JWT Header
    def jwtHeader = JWTHeader(cdcAppkey)
    
    // Prepare JWT JWTClaim
    def jwtClaim = JWTClaim()
    
    // Concat JWT Header and JWT Claim
    message.setBody(jwtHeader + "." + jwtClaim);

    return message;
}

def JWTHeader(cdcAppkey) {
    def jwtHeader = """
            {"alg":"RS256","typ":"JWT","kid":"${cdcAppkey}"}
            """
    def jwtHeader_str = Base64.encodeBase64URLSafeString(jwtHeader.replaceAll("\\s","").getBytes());

    return jwtHeader_str;
}

def JWTClaim() {
    def iat = (int)(new Date().getTime() / 1000);
    def uid4 = UUID.randomUUID().toString();
    def jwtClaim = """
            {"iat":${iat},"jti":"${uid4}"}
            """
    def jwtClaim_str = Base64.encodeBase64URLSafeString(jwtClaim.replaceAll("\\s","").getBytes());
    
    return jwtClaim_str;
}