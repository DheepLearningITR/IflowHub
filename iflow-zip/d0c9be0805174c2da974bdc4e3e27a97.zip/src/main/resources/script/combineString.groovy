import com.sap.it.api.mapping.*;

def String combineString(String string1,String string2,MappingContext context){
    return string1+string2;
}