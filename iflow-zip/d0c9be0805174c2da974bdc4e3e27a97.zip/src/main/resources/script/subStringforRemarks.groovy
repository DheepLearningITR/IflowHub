import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

def String subStringforRemarks(String taxationMode, String invoicetype, String note, MappingContext context){
    switch(taxationMode) {            
         case "0": 
         	if(invoicetype.equals("007")  || invoicetype.equals("026")){
         		return note.take(96)
         	}
         	if(invoicetype.equals("004") || invoicetype.equals("028")){
         		return note.take(154)
         	}
         case "2": 
           if(invoicetype.equals("007")  || invoicetype.equals("026")){
         		return note.take(114)
         	}
         	if(invoicetype.equals("004") || invoicetype.equals("028")){
         		return note.take(160)
         	}
      }
      
      return note
}