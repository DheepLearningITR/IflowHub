import com.sap.gateway.ip.core.customdev.util.Message;
import java.lang.String;
import java.math.BigDecimal;
import groovy.xml.XmlUtil;
import groovy.util.*;

def Message processData(Message message) {

	def map = message.getProperties();
	def messageLog = messageLogFactory.getMessageLog(message);

	String content = message.getBody(java.lang.String) as String;

	def rootNode = new XmlParser().parseText(content)

// 	handleEmptyAmountCase(rootNode,message,messageLog)

    setBuyerEmail(map, message)
    
    getBuyerInfo(map,message)

	calucalateInvoiceTypeCode(map, message)

	caluclateDeductionAndTaxationMode(rootNode, message)

	recaluclateItems(rootNode,map, message, messageLog);

	return message;
}

def setBuyerEmail(Map map, Message message){
	def buyerEmail = map.get("buyerEmail");
	def defaultEmail = map.get("defaultBuyerEmail");
	if(buyerEmail == "")
	{
	    message.setProperty("buyerEmail", defaultEmail);
	}
}

def getBuyerInfo(Map map, Message message){
	//Value of InvoiceMedium: P - Paper E - Elec F - full-digital 
	def invoiceMedium = map.get("invoiceMedium");
	
	def buyerMobileNumber = map.get("buyerMobileNumber");
	def buyerPhoneNumber = map.get("buyerPhoneNumber");
	def buyerAddress = map.get("buyerAddress");
	if(invoiceMedium == "F"){
	    buyerAddress = buyerAddress.replace(buyerPhoneNumber,"").replace(buyerMobileNumber,"").trim()
	    message.setProperty("buyerAddress", buyerAddress);

	    if(!buyerPhoneNumber.isEmpty()){
	        message.setProperty("buyerPhone", buyerPhoneNumber);
    	}else{
    	    message.setProperty("buyerPhone", buyerMobileNumber);
    	}
	}
	
    def buyerBankInfo = map.get("buyerBankInfo");
    if (buyerBankInfo.contains("/")) {
        def buyerBankInfoArray = buyerBankInfo.split('/');
        buyerBankInfoArray = buyerBankInfoArray.collect { it.trim() };
    	message.setProperty("buyerBankName", buyerBankInfoArray[0]);
        message.setProperty("buyerBankNumber", buyerBankInfoArray[1]);
    	message.setProperty("buyerBankAccount", buyerBankInfoArray[0]+" "+buyerBankInfoArray[1]);
    }
    
    def buyerTaxNumber = map.get("buyerTaxNumber");
    if(buyerTaxNumber == ""){
        message.setProperty("replaceBuyerInfo", "");
        message.setProperty("completionCustom", "");
    }
	
}

def calucalateInvoiceTypeCode(Map map, Message message){
    String body = message.getBody(java.lang.String) as String;
    // Value of InvoiceType:  S - special N - normal
	def invoiceTypeCode = map.get("invoiceTypeCode");
	//Value of InvoiceMedium: P - Paper E - Elec F - full-digital 
	def invoiceMedium = map.get("invoiceMedium");
	
	switch(invoiceTypeCode+invoiceMedium) {
		case "SP":
			message.setProperty("invoiceTypeCode", "004");
			break;
		case "NP":
			message.setProperty("invoiceTypeCode", "007");
			break;
		case "NE":
			message.setProperty("invoiceTypeCode", "026");
			break;
		case "SE":
			message.setProperty("invoiceTypeCode", "028");
			break;
		case "SF":
		    message.setProperty("invoiceTypeCode", "01");
			break;
		case "NF":
		    message.setProperty("invoiceTypeCode", "02");
			break;
		default: 
            message.setProperty("invoiceTypeCode", invoiceTypeCode);
			break;
	}
}

def caluclateDeductionAndTaxationMode(rootNode, message){
	def allItems = rootNode.Control.GTDocument.GTHeader.GTItem
	def deductibleAmount = 0;
	for (Node item : allItems) {
		if(item.DeductionAmount != null && !item.DeductionAmount.text().isEmpty()){
			def deduction = item.DeductionAmount.text() as Double;
			deductibleAmount = deductibleAmount + deduction;
		}
	}

	if(deductibleAmount > 0){
		message.setProperty("taxationMode", "2");
	}else{
		message.setProperty("taxationMode", "0");
	}

	if(deductibleAmount != 0){
		message.setProperty("deductibleAmount", deductibleAmount);
	}else{
		message.setProperty("deductibleAmount", "");
	}
}

def recaluclateItems(Node rootNode, Map map,Message message,Object messageLog) {
	def decimalLength = map.get("decimalLength");
	
	def originalItems = rootNode.Control.GTDocument.GTHeader.GTItem
	
	//  check item length, if length > 8, set isgoodslist to 1, else set to 0
	def originalItemsLen = originalItems.size();
	if (originalItemsLen > 8) {
	    message.setProperty("isgoodslist", "1");
	} else {
	    message.setProperty("isgoodslist", "0");
	}
	
	def newItems = new NodeList();
	for (Node node : originalItems){
	    def discountFlagNode = new Node(null, 'DISCOUNT_FLAG', '')
		node.appendNode(discountFlagNode);
	}
	
	for (Node node : originalItems) {
	    //re-calculate unitprice
		def quantityText = node.Quantity.text();
		def netvalueText = node.NetAmount.text();
		BigDecimal netvalue = new BigDecimal(netvalueText);

		if(quantityText == ""){
		    if(netvalue > 0){
		        quantityText = "1";
		        node.Quantity.get(0).setValue('1')
		    }
		    else{
		        quantityText = "-1";
		        node.Quantity.get(0).setValue('-1')
		    }
		}
		
		BigDecimal quantity = new BigDecimal(quantityText);
		BigDecimal num = netvalue.divide(quantity, decimalLength.toInteger(), BigDecimal.ROUND_HALF_UP)
		
		def unitpriceText = num.stripTrailingZeros().toString();
        node.UnitPrice.get(0).setValue(unitpriceText);

		def discountAmountContext = node.DiscountAmount.text();
		if(discountAmountContext.isEmpty()){
			node.DiscountAmount.get(0).setValue('0')
		}
		newItems.add(node);
		
		if(!discountAmountContext.isEmpty()){
			def discountAmount = discountAmountContext as Double
			if(discountAmount != 0){
				def discountTaxAmountText = node.DiscountTax.text();
				def caluclatedDiscountTaxAmountText;
				if(discountTaxAmountText != null && !discountTaxAmountText.isEmpty()){
					def discountTaxAmount = discountTaxAmountText as Double
					def caluclatedDiscountTaxAmount = -Math.abs(discountTaxAmount)
					caluclatedDiscountTaxAmountText = caluclatedDiscountTaxAmount.toString()
				}else{
					caluclatedDiscountTaxAmountText = ""
				}
				def caluclatedDiscountAmount = -Math.abs(discountAmount)
				def discountItem = node.clone();
				discountItem.NetAmount.get(0).setValue(caluclatedDiscountAmount);
				discountItem.TaxAmount.get(0).setValue(caluclatedDiscountTaxAmountText)
				if(discountItem.GoodsSpecification.size() != 0 && discountItem.GoodsSpecification.get(0).text().isEmpty() == false){
					discountItem.remove(discountItem.GoodsSpecification)
				}
				if(discountItem.Quantity.size() != 0 && discountItem.Quantity.get(0).text().isEmpty() == false){
					discountItem.remove(discountItem.Quantity)
				}
				if(discountItem.UnitPrice.size() != 0 && discountItem.UnitPrice.get(0).text().isEmpty() == false){
					discountItem.remove(discountItem.UnitPrice)
				}
				if(discountItem.UoM.size() != 0 && discountItem.UoM.get(0).text().isEmpty() == false){
					discountItem.remove(discountItem.UoM)
				}
				def noInfo = '<DISCOUNT_FLAG>X</DISCOUNT_FLAG>'
				String discountItemText = XmlUtil.serialize(discountItem);
				def discountFlagWithX = discountItemText.replaceAll('<DISCOUNT_FLAG/>', noInfo.toString());
				discountItemNode = new XmlParser().parseText(discountFlagWithX)
				newItems.add(discountItemNode)
			}
		}
	}

	for(int i = 0; i< newItems.size(); i++){
		def lineNo = i + 1
		def noInfo = '<GTD_ITEM_NMBR>'<<lineNo.toString()<<'</GTD_ITEM_NMBR>\n</GTItem>'
		def nodeContextWithoutLineNo = XmlUtil.serialize(newItems.get(i))
		def nodeContextWithLineNo = nodeContextWithoutLineNo.replaceAll('</GTItem>', noInfo.toString());
		def nodeWithLineNo = new XmlParser().parseText(nodeContextWithLineNo)
		newItems.set(i, nodeWithLineNo)
	}

	originalItems.each { b ->
		b.parent().remove(b)
	}

	newItems.each { n ->
		rootNode.Control.GTDocument.GTHeader.get(0).append(n)
	}
	def newRootNode = XmlUtil.serialize(rootNode)
    messageLog.addAttachmentAsString("newRootNode",newRootNode, "text/plain");
	message.setBody(newRootNode)

}
