import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.*;
import groovy.xml.*;
import org.w3c.dom.*;
def Message processData(Message message){
    def map = message.getProperties();
    String body = message.getBody(java.lang.String) as String;
    def messageObj = new XmlSlurper().parseText(body);
    String buyeraddrtel = messageObj.Invoices.Header.buyeraddrtel.text();
    String defaultPushEmail = message.getProperty("defaultBuyerEmail");
//     String buyerAddress = buyeraddrtel.split("  ")[0];
//     String buyerTelphone = buyeraddrtel.split("  ")[1];
// 	def invoiceTypeCode = map.get("invoiceTypeCode");
	if(message.getProperty("eInvoiceMode").equals("X")) {
        // def buyerTelNode = new XmlSlurper().parseText("<buyerTelphone>" + buyerTelphone + "</buyerTelphone>");
        def EmailNode = new XmlSlurper().parseText("<defaultPushEmail>" + defaultPushEmail + "</defaultPushEmail>");
        // messageObj.Invoices.Header.buyeraddrtel = buyerAddress;
        // messageObj.Invoices.Header.appendNode(buyerTelNode);
        messageObj.Invoices.Header.appendNode(EmailNode);
        String bodyStr = XmlUtil.serialize(messageObj);
        message.setBody(bodyStr);
	}
// 	message.setProperty("preOpen", "");
    return message;
}