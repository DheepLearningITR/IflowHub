import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

def String calculateInvoiceTypeCode(String invcType){
      switch(invcType) {            
         case "0": 
            return "004";
         case "1": 
            return "007";
         case "2": 
            return "007";
         default: 
            return invcType;
      }
}

