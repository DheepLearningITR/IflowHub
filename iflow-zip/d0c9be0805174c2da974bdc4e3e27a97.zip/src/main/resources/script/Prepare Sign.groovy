/*
 The integration developer needs to create the method processData
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
    public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties)
    public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.fasterxml.jackson.databind.JsonNode;
import groovy.json.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.gateway.ip.core.customdev.util.Message;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;

def Message processData(Message message)
{
    def map = message.getProperties();
    String request = map.get("body");

    Map<String, String> textParams = new HashMap<String, String>();
    textParams.put("method", map.get("ApiName"));
    textParams.put("version", map.get("apiVersion"));
    textParams.put("appKey", map.get("clientId"));
    textParams.put("format", "json");
    def requestId = UUID.randomUUID().toString();
    String timestamp = (new Date().time / 1000).intValue().toString();
    textParams.put("timestamp", timestamp);
    textParams.put("token", map.get("accessToken"));
    textParams.put("type", "sync");
    textParams.put("requestId", requestId);

    String signString = signTopRequest(textParams, map.get("clientSecret"), request, message);

    message.setProperty("sign", signString);
    message.setProperty("timestamp",timestamp);
	message.setProperty("requestId",requestId);
    return message;
}

def String signTopRequest(Map<String, String> params, String secret, String body, Message message) throws Exception
{
    ObjectMapper mapper = new ObjectMapper();
    
    ArrayList<String> keys = new ArrayList<String>(params.keySet());
    Collections.sort(keys);

    StringBuilder query = new StringBuilder();
    query.append(secret);
    for (String key : keys)
    {
        String value = params.get(key);
        if (!isNull(key) && !isNull(value))
        {
            query.append(key).append(value);
        }
    }

    message.setBody(body);
    
    query.append(body);
    query.append(secret);

    byte[] bytes;
    MessageDigest md5 = null;
    try
    {
        md5 = MessageDigest.getInstance("MD5");
    }
    catch (NoSuchAlgorithmException ignored)
    {
        throw new Exception(ignored);
    }

    bytes = md5.digest(query.toString().getBytes("UTF-8"));

        StringBuilder sign = new StringBuilder();
    for (byte b : bytes) {
        String hex = Integer.toHexString(b & 0xFF);
        if (hex.length() == 1) {
            sign.append("0");
        }
        sign.append(hex.toUpperCase());
    }
    return sign.toString();
}

def boolean isNull(String str)
{
    return (str==null || "".equals(str)?true:false);
}