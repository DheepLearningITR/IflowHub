import com.sap.it.api.mapping.*;

def String setMonitoringID(String arg1,  MappingContext context){
    context.setProperty("messageHeaderId", arg1)
	return arg1 
}