/*
 * Our requirement was to give different namespaces to different nodes in an XML i.e body is of different namespaces and its child differ from body(its parent).
 *So if we give namespace to bidy then its child take empty namespaces so add different namespace to both body and its child we are using this script.
 *
 *Iterate over each element of the request that is generated after the mapping and either set a namespace or add a namespace declaration
 * as per the needs. Note: If a namespace is set at the parent level, then this will by default set a empty namespace (xmlns="") at each of it * child level.Therefore, each child has to be iterated over and explicitly the namespace has to be set again so that the empty namespace 
 * declaration goes away.
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.io.StringWriter;
import org.xml.sax.InputSource;
import javax.xml.xpath.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.TransformerFactory;  
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.dom.DOMSource;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import org.jdom.Content;
import org.jdom.Document;
import org.jdom.Element
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter
import org.jdom.output.Format
import org.jaxen.JaxenException;
import org.jaxen.SimpleNamespaceContext;
import org.jaxen.XPath;
import org.jaxen.jdom.JDOMXPath
import org.jdom.Namespace;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def map = message.getHeaders();
	def prop = message.getProperties();
	SAXBuilder builder = new SAXBuilder();
	
	// Declare the Namespaces that are used in the XML request
	Namespace nS1 = Namespace.getNamespace("ns1","http://schemas.xmlsoap.org/soap/envelope/");  
	Namespace nS2 = Namespace.getNamespace("ns2","http://ns.hr-xml.org/2004-08-02");
	
	//Namespace nS4 = Namespace.getNamespace("xsi","http://www.w3.org/2001/XMLSchema-instance");
	
	InputStream stream = new ByteArrayInputStream(body.getBytes("UTF-8"));	
	Document doc = builder.build(stream);

	// Take the references of the main elements before the XML is tampered with any of the above mentioned namespaces
	Element envelope = doc.getRootElement();	
	
	Element reqbody = envelope.getChild("Body");
	Element assessmentOrderRequest = reqbody.getChild("AssessmentOrderRequest");
    
	/*
	*setNamespace will add a namespace prefix at each parent level and when used on the child, simply removed the empty namespace declaration.
	*addNamespaceDeclaration, as the name suggests, adds a namespace declaration to the XML element.
	*/
	
	if(null != envelope){
		envelope.addNamespaceDeclaration(nS1);
		envelope.setNamespace(nS1);
	}		
	
	if(null != reqbody){
		reqbody.setNamespace(nS1);
	}
	
	if(null != assessmentOrderRequest)
	{
	  Element bodyNS = envelope.getChild("Body",nS1);
	  assessmentOrderRequest.addNamespaceDeclaration(nS2);
	  assessmentOrderRequest.setNamespace(nS2)
	  
	  Element assessmentOrderRequestNS = bodyNS.getChild("AssessmentOrderRequest",nS2);
	  List<Element> requestChildren = assessmentOrderRequestNS.getChildren();
	  for(Element requestChild : requestChildren)
	  {
	    List<Element> grandChildren = requestChild.getChildren();
		for(Element grandChild : grandChildren)
		{
		  grandChild.setNamespace(nS2);
		}
		requestChild.setNamespace(nS2);
	  }
	  /*
	*setNamespace will add a namespace prefix at each parent level and when used on the child, simply removed the empty namespace declaration.
	*addNamespaceDeclaration, as the name suggests, adds a namespace declaration to the XML element. for this we are reaching to the last leaf node of the XML and set the namespace.
	*By doing this we dint get the empty namespaces. 
	*/
	  Element assessmentSubject = assessmentOrderRequestNS.getChild("AssessmentSubject",nS2);
	  List<Element> subjectChildren = assessmentSubject.getChildren();
	  for(Element subjectChild : subjectChildren)
	  {
	     List<Element> subjectGrandChildren = subjectChild.getChildren();
		 for(Element subjectGrandChild : subjectGrandChildren)
		 {
		   subjectGrandChild.setNamespace(nS2);
		 }
	  }
	  
	  //assessmentOrderRequestNS.addNamespaceDeclaration(nS4);	  
	}
	
	// Output the XML request having the appropriate namespaces
	XMLOutputter outputter = new XMLOutputter();
    is = new ByteArrayInputStream(outputter.outputString(doc).getBytes("UTF-8"));
    message.setBody(is);
    return message;
}