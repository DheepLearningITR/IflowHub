import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def b2bCustomerNode = message.getBody(java.lang.String) as String;
	def b2bCustomer = new XmlSlurper().parseText(b2bCustomerNode);
	
	//To set B2BCustomer ContactPerson ID as key.
	def internalID = message.getProperty("currentB2BCustomer").get("currentB2BCustomerId");
	
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null && message.getProperty("enableLog").equals("true")){
	    messageLog.addAttachmentAsString("Log - Single Customer " + internalID + " After Post Exit",  b2bCustomerNode,
		                                                   "text/xml");
	}

    //Set mapped customer body to property.
	message.getProperties().get("b2bCustomersXml").put(internalID, b2bCustomerNode);
	return message;
}