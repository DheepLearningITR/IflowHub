import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.StreamingMarkupBuilder;
import java.util.concurrent.ConcurrentHashMap;
import groovy.xml.XmlUtil

def Message processData(Message message) {
    def b2bUnit_xml = message.getBody(java.lang.String) ;
     
    def builder = new StreamingMarkupBuilder()
    def b2bUnit_root = new XmlSlurper().parseText(b2bUnit_xml);
    def internalId = b2bUnit_root.B2BUnit.uid.text();	

    def hmap1 = new ConcurrentHashMap<String, String>();
    hmap1.put("baseUnitId", internalId);
    message.setProperty("currentBaseUnit",hmap1);
    
    if(!isMatchedOrLaterCommerceVersion(message,"1811"))
        b2bUnit_root.B2BUnit.addresses.Address.sapAddressUUID.findAll{it!='' || it.text()==''}*.replaceNode {};
    message.setBody(XmlUtil.serialize(b2bUnit_root));
    return message;
}

def boolean isMatchedOrLaterCommerceVersion(Message message, String attributeVersionNumber){
    def commerceVersion = message.getProperty("COMMERCE_VERSION_NUMBER");
    if(commerceVersion == null) 
        return false;
    return commerceVersion.replace(".","").toUpperCase().compareTo(attributeVersionNumber.toUpperCase())>=0;
}
