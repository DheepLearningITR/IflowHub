import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.concurrent.ConcurrentHashMap;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    
    //Initiate HashMap and assign it to Property   
    def hmap1 = new ConcurrentHashMap<String, String>();
    message.setProperty("b2bCustomersXml", new ConcurrentHashMap<String, String>());
    
    def xml = message.getBody(java.lang.String);
    def xmlParser = new XmlSlurper().parseText(xml);

    //Incoming message is a BP request
    if (xmlParser.name().equals('BusinessPartnerSUITEBulkReplicateRequest')) {
        def businessPartners = xmlParser.'**'.findAll { it.BusinessPartner.CategoryCode.text().equals('2') }
    
        businessPartners.each { partner ->
            def internalID = partner.BusinessPartner.InternalID.text();
            if (internalID != null && !internalID.equals('')) {
                //To construct the base batched B2BUnit.
                hmap1.put(internalID,'<B2BUnitXml><BaseUnits></BaseUnits><SalesUnits></SalesUnits></B2BUnitXml>');
            }
        }
        message.setProperty("b2bUnitsXml",hmap1);
    }
    
   return message;
}