import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
	
	//Body 
	  def body = message.getBody(java.lang.String) as String;
	
	def messageLog = messageLogFactory.getMessageLog(message);
    def map = message.getHeaders();
    
    def jsonSlurper = new JsonSlurper()
    def parseJson = jsonSlurper.parseText(body)

	
	def fileFetchJobs = [:] //[]
	
    def runMode = map.get("runMode");
    
//     if(runMode.equalsIgnoreCase("Adhoc"))
// 	    fileFetchJobs = map.get("AdhocJobs")
// 	else
// 	    fileFetchJobs = map.get("ScheduledJobs")    
	
	
	
	if(fileFetchJobs.toString().equalsIgnoreCase("null") || fileFetchJobs.toString().equalsIgnoreCase("") || fileFetchJobs.toString().equalsIgnoreCase("[:]"))
		fileFetchJobs = [:]
	
	def template = parseJson.viewTemplateName.toString()
	def jobId = parseJson.jobId.toString()
	def jobStatus = parseJson.status.toString()
	
	def fileNames = ''
	
	if(parseJson.files!=null)
	 fileNames = parseJson.files.join(",")
 

	fileFetchJobs.put(jobId,(jobStatus+'|'+fileNames))
	message.setProperty("JobResult",fileFetchJobs)
	message.setHeader("JobResult",fileFetchJobs)
		
	message.setBody(fileFetchJobs)
	
	message.setHeader("SAP_ApplicationID",jobId.toString())
	
	messageLog.addAttachmentAsString("#3JobPayload", fileFetchJobs.toString(), "text/json");
	
	//sleep(60000)
		
	return message
				   
}

