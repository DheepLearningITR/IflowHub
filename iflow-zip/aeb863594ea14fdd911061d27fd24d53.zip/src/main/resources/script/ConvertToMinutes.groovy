import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String ConvertToMinutes(String arg1,String arg2,MappingContext context){
    
       int s=arg2.length();
       String Sfinal="";
       for(int i=0;i<s;i++)
        {   
            
            if(arg2[i]!='['&&arg2[i]!=']'&&arg2[i]!=' ')
              Sfinal=Sfinal+arg2[i];
    
        }
    String ss=context.getProperty("DurationInMinutes"); 
    if(arg1.equals(ss))
    
      {def i=Double.parseDouble(Sfinal);
      i=i*60;
      arg2=i.toString();
      }
	return arg2; 
}