import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

  String payload = message.getBody(java.lang.String)  
  if(!payload.contains("?xml")){
	payload='''<?xml version="1.0" encoding="UTF-8"?>'''+"\n"+payload
	message.setBody(payload);
  }
  
  return message;
}