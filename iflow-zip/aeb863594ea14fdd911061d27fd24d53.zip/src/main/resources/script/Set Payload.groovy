import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    def map = message.getProperties();
    message.setBody(map.OriginalPayload);
       
    return message;
}