import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def query = new XmlSlurper().parseText(body);
    def Set <String> set = new HashSet <String> ();
    query.activities.each{
        set.add(it.externalId);
    }
    
    def mssg = """{"query":"SELECT ac.externalId,ac.status,ac.executionStage from Activity ac WHERE ac.externalId IN (""";
    int i;
    for(i=0; i<set.size()-1; i++) {
        mssg = """${mssg}'${set[i]}',""";
    }
    mssg = """${mssg}'${set[i]}')"}""";
    message.setBody(JsonOutput.toJson(new JsonSlurper().parseText(mssg)));
    return message;
}