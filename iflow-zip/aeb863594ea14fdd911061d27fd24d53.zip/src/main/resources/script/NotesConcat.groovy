import com.sap.it.api.mapping.*;

def String notesConcat(String input){
     def query = new XmlSlurper().parseText(input);
     String output="";
            String flag="false"; 
       query.E102CRMXIF_TLINE.each{
            if(flag=="false")
              {
                 output=output+it.TEXT_LINE;
                 flag="true";
              }
            else
              {
                 if(it.FORMAT_COL.text()=="*")
                  output=output+"\n"+it.TEXT_LINE;
                 else if(it.FORMAT_COL.text()=="=")
                  output=output+it.TEXT_LINE;
                 else
                  output=output+" "+it.TEXT_LINE;
              }
        }
	return output; 
}