import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import groovy.util.slurpersupport.NodeChild;
import groovy.json.JsonSlurper

def Message processData(Message message){
    def body = message.getBody(java.lang.String) as String;
    def map = message.getProperties();
    def Original_mapped_payload = map.get("Mapped_ServiceCall_Payload");
    def query = new XmlSlurper().parseText(Original_mapped_payload);
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    def fragmentToAdd = new XmlSlurper()
    def extID = ""
    def status = ""
    def newNode = ""
    jsonObject.data.each{
        extID = it.ac.externalId
        status = it.ac.status
        execStage = it.ac.executionStage
        query.activities.each{
            if(it.externalId == extID && it.status == 'DRAFT' && status == 'OPEN'){
                it.status = "OPEN"
            }else if(it.externalId == extID && it.status == 'DRAFT' && status == 'CLOSED' && execStage == 'CANCELLED'){
                newNode = fragmentToAdd.parseText( '''<executionStage>DISPATCHING</executionStage>''' )
                it.appendNode (newNode)
            }else if(it.externalId == extID && it.status == 'DRAFT' && status == 'CLOSED' && execStage == 'CLOSED'){
                it.replaceNode {}
            }
        }
    }
    
  def valid_data = XmlUtil.serialize(query);
  message.setBody(valid_data);
  return message;
}