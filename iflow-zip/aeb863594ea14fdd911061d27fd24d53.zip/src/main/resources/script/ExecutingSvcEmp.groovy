import groovy.json.JsonSlurper
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def map = message.getProperties();
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def content = jsonSlurper.parseText(body);
    List<String> list = new ArrayList<String>();
    int count = 0;
    
    content.activities.externalId.each{
        count++;
    }
    
    if(map.get("Override_FSM_Planning_Board_Assignment") == "Yes") {
        content.activities.each{activity->
          if(activity.responsibles.collect{activity.keySet().contains('externalId')}[0]){
            list.add(activity.responsibles.externalId);
          }
        }
        
        if(list.size() < count) {
            throw new Exception("Override_FSM_Planning_Board_Assignment has been enabled but Executing Service Employee for one or more activity has not been declared");
        } else {
            message.setProperty("Executing_Service_Employee", list);
        }
    }

    return message;
}