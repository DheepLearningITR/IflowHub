import com.sap.it.api.mapping.*;

def String verifyStatus(String status){
    if(status == 'vvv'){
        throw new Exception("Status of the service item on CRM service order is not maintained in the value mapping. Please refer to transactional value mapping ServiceOrderCRM-ItemStatusFSM -> ServiceCallFSM-ActivityStatusFSM")
    }
	return status 
}