import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def query = new XmlSlurper().parseText(body);
    def query1 = new XmlSlurper().parseText(body);
    
    query.IDOC.E101CRMXIF_BUSTRANS.E101CRMXIF_BUSTRANS_ITEM.each {
        if(it.NUMBER_PARENT.text() != '0000000000'){
            it.replaceNode {'CHILD_NODE'(it.attributes(), it.children())};
        }
    }
    def xml = XmlUtil.serialize(query);
    query = new XmlSlurper().parseText(xml);
    
    query.IDOC.E101CRMXIF_BUSTRANS.CHILD_NODE.each {
        def parentItemType;
        def delNode = it.ITEM_NUMBER.text();
        def parentNode = it.NUMBER_PARENT.text();
        def nodeToAdd = it;
        
        query1.IDOC.E101CRMXIF_BUSTRANS.E101CRMXIF_BUSTRANS_ITEM.each {
            if(it.ITEM_NUMBER.text() == parentNode) {
                parentItemType = it.ITEM_TYPE.text();
                def type = '<PARENT_ITEM_TYPE>' + parentItemType + '</PARENT_ITEM_TYPE>';
                def toAdd = new XmlSlurper().parseText(type);
                nodeToAdd.appendNode(toAdd);
                it.appendNode(nodeToAdd);
            }
            if(it.ITEM_NUMBER.text() == delNode) {
                it.replaceNode { };
            }
        }
    }
    
    def valid_data = XmlUtil.serialize(query1);
    message.setBody(valid_data);
    
    return message;
}
