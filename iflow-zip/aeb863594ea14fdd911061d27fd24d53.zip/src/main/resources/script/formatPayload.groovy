import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message)
{
    def body = message.getBody(java.lang.String) as String;
    
    body = body.replace('<(>', "");
    body = body.replace('<)>', "");
    
    def jsonParser = new JsonSlurper();
    def jsonObject = jsonParser.parseText(body);
    message.setBody(body);
    message.setProperty("RequestPayload", body);
    
    return message;
}