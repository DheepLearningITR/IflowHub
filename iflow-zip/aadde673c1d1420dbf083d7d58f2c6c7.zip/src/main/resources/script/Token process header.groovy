import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
	
    //Get the Query String parameters
    def parameter = message.getHeaders()["CamelHttpQuery"].split("&")
    //Read State parameter and set header variable
    parameter.each {
	    if(it.tokenize("=")[0] == "state") {
	        message.setHeader("TokenKey", it.tokenize("=")[1])
        }
    }

	def map = message.getHeaders()
	map.remove("X-ConsumerKey")
		
	message.setHeader("Authorization", "Basic " + 'U0FQX1BheXJvbGw6RGgxQjBOeURwTzE=')
	//message.setHeader("Authorization", "Basic " + 'U0FQX1BheXJvbGw6b0RTY3VWcnc=')
		
	return message

}
