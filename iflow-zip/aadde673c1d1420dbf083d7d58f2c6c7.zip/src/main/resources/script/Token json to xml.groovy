import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import org.json.simple.*
import groovy.json.*
import groovy.xml.MarkupBuilder
import groovy.time.*

def Message processData(Message message) {
    //Get Body 
    def body = message.getBody(String.class)

    //Define JSONSlurper
    def jsonSlurper = new JsonSlurper()
    def list = jsonSlurper.parseText(body)

    def stringWriter = new StringWriter()
    def peopleBuilder = new MarkupBuilder(stringWriter)

    def currentdate = new Date()
	def expiry = new Date()

	use( TimeCategory ) {
			
	    expiry = currentdate + list.expires_in.seconds
		    
	}		
		
	TimeDuration duration = TimeCategory.minus(expiry, currentdate) 
     
    peopleBuilder.root {
        access_token(list.access_token)
        token_type(list.token_type)
        expires_in(list.expires_in)
        scope(list.scope)
        refresh_token(list.refresh_token)
        token(list.token_type + " " + list.access_token)
        remaining(duration)
    }
        
    def xml = stringWriter.toString()    
     
    message.setBody(xml)
    return message
}
