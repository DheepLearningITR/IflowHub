import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    
    //Body 
       def body = message.getBody(java.lang.String);
     
       throw new Exception("Business Partner Relationship Data Not Recieved\n \n ");  
      
}