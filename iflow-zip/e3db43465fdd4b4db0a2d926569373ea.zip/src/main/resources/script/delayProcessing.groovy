import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;

    def properties = message.getProperties() as Map<String, Object>;
    int timeDifference = properties.get("timeDifference").toInteger();
    timeDifference = timeDifference * 1000;
    message.sleep(timeDifference);

       return message;
}