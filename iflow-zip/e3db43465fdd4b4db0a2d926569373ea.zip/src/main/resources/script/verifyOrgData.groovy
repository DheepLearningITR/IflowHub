import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder
import groovy.util.XmlParser;
def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String;
    def properties = message.getProperties() as Map<String, Object>;
    def xmlBody = properties.get("BusinessPartnerOrganizationPayload");
    def RoleCode = properties.get("RoleCode");
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    if(!object.OrgData.isEmpty()){
    def organization = object.OrgData.organizations;
    def fieldSet = [];
     def messageLog = messageLogFactory.getMessageLog(message);
    
     def xmlObject = new XmlParser().parseText(xmlBody);
      def bpObject = xmlObject.BusinessPartnerSUITEReplicateRequestMessage;
      if( organization instanceof groovy.json.internal.LazyMap){
          for(def bp : bpObject){
           if(bp.BusinessPartner.Role.RoleCode.text().contains(RoleCode)){
               //println(bp.BusinessPartner.InternalID.text())
               def orgID = organization.get("BPID")
               //println(bp.BusinessPartner.InternalID.text())
               if(bp.BusinessPartner.InternalID.text().equals(orgID))
               {
                     
                   fieldSet.add(organization)
               }
           }
       }
          
      }else{
          for( def org : organization){
            //  println(org)
               for(def bp : bpObject){
           if(bp.BusinessPartner.Role.RoleCode.text().contains(RoleCode)){
               //println(bp.BusinessPartner.InternalID.text())
               def orgID = org.get("BPID")
               //println(bp.BusinessPartner.InternalID.text())
               if(bp.BusinessPartner.InternalID.text().equals(orgID))
               {
                   fieldSet.add(org)
               }
           }
       }
          }
      }
     object.OrgData.organizations = fieldSet
     body = new JsonBuilder(object).toPrettyString();
     def jsonCount = object.OrgData.organizations;
     
     if(jsonCount.size() == 1){
         String orgId = jsonCount.BPID[0].toString();
         def datastoreId = orgId.concat("ContactPersonMap")
        message.setProperty("OrganizationCounter", '1');   
        message.setProperty("RelationshipDataStoreID" , datastoreId)
     }else{
          message.setProperty("OrganizationCounter", '0'); 
     }
    message.setProperty("BusinessPartnerOrganisation", body);
    }else{
     message.setProperty("OrganizationCounter", '0');
    }
    return message;
}