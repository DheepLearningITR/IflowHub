import com.sap.it.api.mapping.*;

def String verifySalesArrangementDetails(String SalesOrganisationID, String DivisionCode, String DistributionChannelCode, MappingContext context){
    //def properties = context.getProperties() as Map<String, Object>;
    //int timeDifference = properties.get("timeDifference").toInteger();
	def externalisedSalesOrganisationID =  context.getProperty('SalesOrganisationID');
	//properties.get("SalesOrganisationID");
	//context.getProperty('SalesOrganisationID');
	def externalisedDistributionChannelCode = context.getProperty('DistributionChannelCode');
	def externalisedDivisionCode = context.getProperty('DivisionCode');
	//def externalisedRoleCode = context.getProperty("RoleID");
	if(externalisedSalesOrganisationID.equals(SalesOrganisationID) && externalisedDistributionChannelCode.equals(DistributionChannelCode) && externalisedDivisionCode.equals(DivisionCode)){
	    return 'successful';
	}
	else{
	    return 'unsuccessful';
	}
}