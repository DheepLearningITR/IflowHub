import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
                
                // get a map of iflow properties
                def map = message.getProperties();
                
                // get an exception java class instance
                def ex = map.get("CamelExceptionCaught");
                if (ex!=null) {
                                
                                // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
//                                if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
                                if (ex.getClass().getCanonicalName().equals("org.apache.cxf.binding.soap.SoapFault")) {
                                                
                                                // save the http error response as a message attachment 
                                                //def messageLog = messageLogFactory.getMessageLog(message);
                                                //messageLog.addAttachmentAsString("http.ResponseBody", ex.getResponseBody(), "text/plain");
                                                
                                                //String temp = "<?xml version='1.0' encoding='UTF-8'?>" + ex.getDetail();
                                                //'<?xml version=\'1.0\' encoding=\'UTF-8\'?>
                                                //String a = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">';
                                                //String b = '<soapenv:Header/><soapenv:Body><soapenv:Fault><faultcode>soapenv:Server</faultcode><faultstring>FaultMsg</faultstring><detail>';
                                                //String c = '<ins:insiteFaultType xmlns:ins=""insite:soapws:connectorn:v1""><explanation>There is no data to download</explanation><returnCode>107</returnCode>';
                                                //String d = '</ins:insiteFaultType></detail></soapenv:Fault></soapenv:Body></soapenv:Envelope>';
                                                //String temp = a + b + c + d;
                                                

                                                // copy the http error response to an iflow's property
                                                //message.setProperty("http.ResponseBody",ex.getResponseBody());
                                                //message.setProperty("http.ResponseBody",ex.getDetail());
                                                //message.setProperty("http.ResponseBody",temp);

                                                // copy the http error response to the message body
                                                //message.setBody(ex.getResponseBody());
                                                message.setBody(ex.getDetail());
                                                //message.setBody(temp);

                                                // copy the value of http error code (i.e. 500) to a property
                                                //message.setProperty("http.StatusCode",ex.getStatusCode());
                                                //message.setProperty("http.StatusCode",ex.getFaultCode());

                                                // copy the value of http error text (i.e. "Internal Server Error") to a property
                                                //message.setProperty("http.StatusText",ex.getReason());
                                                
                                                //message.setProperty("http.returnCode","107");
                                                
                                }
                }

                return message;
}