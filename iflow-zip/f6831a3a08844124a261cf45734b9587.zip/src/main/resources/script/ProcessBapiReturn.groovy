import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    def typeFilter = "[EAXW]"
    def body = message.getBody(Reader)
    def root = new XmlSlurper().parse(body)
    if ("BAPI_INSPOPER_RECORDRESULTS.Response".equalsIgnoreCase(root.name())) {
        typeFilter = "[EAX]"
    }

    // BAPI Part
    // header error
    def bapiErrItems = collectBapiErrorItems(root, typeFilter)
    def badRequestBapiErrorItems = collectBadRequestErrorItems(root)
    def notFoundBapiErrorItems = collectNotFoundErrorItems(root)
    def conflictBapiErrorItems = collectConflictErrorItems(root)

    if (bapiErrItems.size() > 0) {
        def errText = new StringBuilder()
        errText.append("\r\n-----BAPI errors begin-----\r\n")
        errText.append((String) bapiErrItems.MESSAGE.join(";\r\n"))
        errText.append("\r\n-----BAPI errors end-----\r\n")

        if (conflictBapiErrorItems.size() > 0) {
            message.setHeader("CamelHttpResponseCode", "409")
        } else if (notFoundBapiErrorItems.size() > 0) {
            message.setHeader("CamelHttpResponseCode", "404")
        } else if (badRequestBapiErrorItems.size() > 0) {
            message.setHeader("CamelHttpResponseCode", "400")
        } else {
            message.setHeader("CamelHttpResponseCode", "500")
        }
        throw new Exception(errText.toString())
    }

    // EWM Part
    def ewmErrItems = []
    ewmErrItems.addAll(root.ET_BAPIRET.item.findAll { it -> it.TYPE.text().matches(typeFilter) })

    if (ewmErrItems.size() > 0) {
        def errText = new StringBuilder()
        errText.append("\r\n-----EWM BAPI errors begin-----\r\n")
        errText.append((String) ewmErrItems.MESSAGE.join(";\r\n"))
        errText.append("\r\n-----EWM BAPI errors end-----\r\n")

        throw new Exception(errText.toString())
    }

    return message
}

def collectBapiErrorItems(root, typeFilter) {
    def bapiErrItems = []
    def rootElements = [root.RETURN, root.ES_RETURN, root.RETURN.item, root.ES_RETURN.item, root.DETAIL_RETURN.item, root.ET_DETAIL_RETURN.item, root.RETURNTABLE.item]
    rootElements.each {
        element -> bapiErrItems.addAll(element.findAll { it.TYPE.text().matches(typeFilter) })
    }
    return bapiErrItems
}

def collectNotFoundErrorItems(root) {
    def notFoundBapiErrorItems = []
    notFoundBapiErrorItems.addAll(root.ES_RETURN.findAll {
        it -> (it.ID.text().matches("RU") && it.NUMBER.text().matches("002"))
    })
    notFoundBapiErrorItems.addAll(root.RETURN.item.findAll {
        it -> (it.ID.text().matches("CL") && it.NUMBER.text().matches("763")) ||
                (it.ID.text().matches("RU") && it.NUMBER.text().matches("002")) ||
                (it.ID.text().matches("C/") && it.NUMBER.text().matches("006")) ||
                (it.ID.text().matches("M7") && it.NUMBER.text().matches("042")) ||
                (it.ID.text().matches("M3") && it.NUMBER.text().matches("238"))
    })
    notFoundBapiErrorItems.addAll(root.ET_DETAIL_RETURN.item.findAll {
        it -> (it.ID.text().matches("RU") && it.NUMBER.text().matches("002"))
    })
    notFoundBapiErrorItems.addAll(root.DETAIL_RETURN.item.findAll {
        it -> (it.ID.text().matches("RU") && it.NUMBER.text().matches("002"))
    })
    return notFoundBapiErrorItems
}

def collectBadRequestErrorItems(root) {
    def badRequestBapiErrorItems = []
    badRequestBapiErrorItems.addAll(root.ET_DETAIL_RETURN.item.findAll {
        it -> (it.ID.text().matches("RU") && it.NUMBER.text().matches("024")) ||
                (it.ID.text().matches("RU") && it.NUMBER.text().matches("005"))
    })
    badRequestBapiErrorItems.addAll(root.DETAIL_RETURN.item.findAll {
        it -> (it.ID.text().matches("RU") && it.NUMBER.text().matches("024")) ||
                (it.ID.text().matches("RU") && it.NUMBER.text().matches("005"))
    })
    badRequestBapiErrorItems.addAll(root.RETURNTABLE.item.findAll {
        it -> (it.ID.text().matches("QT") && it.NUMBER.text().matches("421")) ||
                (it.ID.text().matches("Q5") && it.NUMBER.text().matches("009")) ||
                (it.ID.text().matches("Q5") && it.NUMBER.text().matches("003")) ||
                (it.ID.text().matches("Q5") && it.NUMBER.text().matches("006")) ||
                (it.ID.text().matches("Q5") && it.NUMBER.text().matches("007")) ||
                (it.ID.text().matches("QI") && it.NUMBER.text().matches("130")) ||
                (it.ID.text().matches("QI") && it.NUMBER.text().matches("133")) ||
                (it.ID.text().matches("QI") && it.NUMBER.text().matches("139")) ||
                (it.ID.text().matches("QE") && it.NUMBER.text().matches("131")) ||
                (it.ID.text().matches("QE") && it.NUMBER.text().matches("456")) ||
                (it.ID.text().matches("QE") && it.NUMBER.text().matches("462"))
    })

    return badRequestBapiErrorItems
}

def collectConflictErrorItems(root) {
    def conflictBapiErrorItems = []

    conflictBapiErrorItems.addAll(root.DETAIL_RETURN.item.findAll {
        it -> (it.ID.text().matches("RU") && it.NUMBER.text().matches("428")) ||
                (it.ID.text().matches("CO") && it.NUMBER.text().matches("341")) ||
                (it.ID.text().matches("CO") && it.NUMBER.text().matches("469"))
    })

    conflictBapiErrorItems.addAll(root.ET_DETAIL_RETURN.item.findAll {
        it -> (it.ID.text().matches("RU") && it.NUMBER.text().matches("428")) ||
                (it.ID.text().matches("CO") && it.NUMBER.text().matches("341")) ||
                (it.ID.text().matches("CO") && it.NUMBER.text().matches("469"))
    })


    conflictBapiErrorItems.addAll(root.RETURNTABLE.item.findAll {
        it -> (it.ID.text().matches("QT") && it.NUMBER.text().matches("400")) ||
                (it.ID.text().matches("QT") && it.NUMBER.text().matches("431")) ||
                (it.ID.text().matches("QT") && it.NUMBER.text().matches("432"))
    })

    return conflictBapiErrorItems;
}