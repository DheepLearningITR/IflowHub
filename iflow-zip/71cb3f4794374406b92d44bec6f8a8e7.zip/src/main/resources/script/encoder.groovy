import com.sap.gateway.ip.core.customdev.util.Message;
import org.apache.commons.codec.binary.Base64;


def Message processData(Message message) {
    
    String body = message.getBody(java.lang.String) as String;
    
    byte[] Bytes = body.getBytes("UTF-8");

    String Str = new String(Bytes, "UTF-8");

    Str.bytes.encodeBase64();
	   
    message.setBody(Str);

 	return message;
 	
}

def Message checkForEncoding(Message message) {
    
    String body = message.getBody(java.lang.String) as String;
    
    boolean isBase64 = Base64.isArrayByteBase64(body.getBytes());
	   
    message.setProperty('isBase64',isBase64);

 	return message;
 	
}

