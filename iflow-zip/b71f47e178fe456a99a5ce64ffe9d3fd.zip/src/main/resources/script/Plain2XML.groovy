import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.File
import java.io.Reader
import groovy.xml.MarkupBuilder

def Message processData(Message message) {

	def body = message.getBody(java.io.Reader);
	def varStringWriter = new StringWriter();
	message.setProperty("IsVoid", false);
	def varXMLBuilder   = new MarkupBuilder(varStringWriter);
	String newItem ;
	body.eachLine{ line ->
		newItem = line
		
		/*if(newItem.substring(0, 2).equalsIgnoreCase("I ") && newItem[37].equals('1') ) {
			message.setProperty("IsVoid", true);
			
		}*/
		if(!newItem.substring(0, 2).equalsIgnoreCase("ST")) {
			varXMLBuilder.Line{
				Value(newItem);
			}
		}
	}

	String xml = varStringWriter.toString();
	message.setBody(xml);
	return message;
}
