import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

/*def String customFunc(String arg1){
	return arg1 
}*/


def void getTransTypeI(String[] TT,Output output, MappingContext context) {
        String res = "false";
        for (int i = 0; i< TT.length; i++) {
            if (TT[i].equals("I ")) {
                res = "true";
                break;
            }
        }
        output.addValue(res);
}
def void getTransVoidI(String[] TT, String[] VoidFlag, Output output, MappingContext context) {
        String res = "false";
        for (int i = 0; i< TT.length; i++) {
            if (TT[i].equals("I ")&&(VoidFlag[i].equals("1"))) {
                res = "true";
                break;
            }
        }
        output.addValue(res);
}
def void getItemI(String[] TType, String[] lineI, String[] TCode, String[] VoidFlag, Output output, MappingContext context) {
        int j = 1;
        for (int i = 0; i< TType.length; i++) {
            if (TType[i].equals(TCode[0])&&(!VoidFlag[i].equals("1"))) {
                output.addValue(j.toString());
                j++;
            }
        }
}
def void getItemI4T(String[] TType, String[] VoidFlag, Output output, MappingContext context) {
        int j = 1;
        for (int i = 0; i< TType.length; i++) {
            if (TType[i].equals("I ")&&(!VoidFlag[i].equals("1"))) {
                for (int k = i+1; k < TType.length; k++) {
                    if (TType[k].equals("TX")&&(!VoidFlag[k].equals("1"))) output.addValue(j.toString());
                    if (TType[k].equals("I ")&&(!VoidFlag[k].equals("1"))) break;
                }
                j++;
            }
        }
}
def void getItemD(String[] TType, String[] lineI, String[] discID, String[] discTy, String[] VoidFlag, Output output, MappingContext context) {
        for (int i = 0; i< TType.length; i++) {
            if (TType[i].equals("D1")&&discID[i].equals("true")&&(!VoidFlag[i].equals("1"))) {
                output.addValue(lineI[i]);
            }
            if (TType[i].equals("D ")) {
                if (discID[i].equals("true")&&discTy[i].equals("true")&&(!VoidFlag[i].equals("1"))) output.addValue(lineI[i]);
            }
        }
}
def void getItemC(String[] TType, String[] lineI, String[] discID, String[] VoidFlag, Output output, MappingContext context) {
        for (int i = 0; i< TType.length; i++) {
            if (TType[i].equals("D ")&&discID[i].equals("true")&&(!VoidFlag[i].equals("1"))) output.addValue(lineI[i]);
            if (TType[i].equals("D1")&&discID[i].equals("true")&&(!VoidFlag[i].equals("1"))) output.addValue(lineI[i]);
        }
}
def void getHeaderId(String[] TType,String[] f1, Output output, MappingContext context) {
        for (int i = 0; i< TType.length; i++) {
            if (TType[i].equals("I ")) {
                output.addValue(f1[i]);
                break;
            }
        }
}
def void getLineNo(String[] TType, String[] discID, String[] discTy, String[] VoidFlag, Output output, MappingContext context) {
        int k = 0;
        for (int i = 0; i< TType.length; i++) {
            if (TType[i].equals("I ")&&(!VoidFlag[i].equals("1"))) {
                k++;
                for (int j = i+1; j< TType.length; j++) {
                    if (TType[j].equals("D1")&&discID[j].equals("true")) {
                       output.addValue(Integer.toString(k));
                    }
                    if (TType[j].equals("D ")&&discID[j].equals("true")&&discTy[j].equals("true")) {
                        output.addValue(Integer.toString(k));
                    }
                    if (TType[j].equals("I ")) {
                        break;
                    }
                }
            }
        }
}
def void getIdx(String[] discIdx, String[] promoNo, Output output, MappingContext context) {
        for (int i = 0; i< discIdx.length; i++) {
            int j = Integer.parseInt(discIdx[i]);
            int k = Integer.parseInt(promoNo[0]);
            if (k<=0) k=0;
            output.addValue(Integer.toString(k+j));
        }
}
def void getCharNo(String[] TType, String[] discID, String[] VoidFlag, Output output, MappingContext context) {
        int k = 0;
        for (int i = 0; i< TType.length; i++) {
            if (TType[i].equals("I ")&&(!VoidFlag[i].equals("1"))) {
                k++;
                for (int j = i+1; j< TType.length; j++) {
                    if (TType[j].equals("I ")) {
                        break;
                    }
                    if (TType[j].equals("D ")&&discID[j].equals("true")) {
                        output.addValue(Integer.toString(k));
                        break;
                    }
                    if (TType[j].equals("D1")&&discID[j].equals("true")) {
                        output.addValue(Integer.toString(k));
                        break;
                    }
                }
            }
        }
}
def String lead0RM(String arg1){
	return arg1.replaceFirst("^0*", "");
}