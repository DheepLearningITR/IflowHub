import com.sap.gateway.ip.core.customdev.util.Message
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def currentExecutionLastProcessedBigCommerceCustomerUpdatedAtTimestamp = message.getProperty("current_execution_last_processed_bigcommerce_customer_updated_at_timestamp")

    def body = message.getBody(java.io.Reader)
    if (body == null) {
        return message
    }

    def xml = new XmlSlurper().parse(body)
    if (xml == null || xml.bigCommerceCustomer == null || xml.bigCommerceCustomer.size() == 0) {
        return message
    }

    ZonedDateTime latestProcessedBigCommerceCustomerUpdatedAt = null
    xml.bigCommerceCustomer.each { customer ->
        def updatedAtString = customer.text()
        if (updatedAtString != null && !updatedAtString.trim().isEmpty()) {
            ZonedDateTime currentIteratedBigCommerceCustomerUpdatedAt = ZonedDateTime.parse(updatedAtString, DateTimeFormatter.ISO_ZONED_DATE_TIME)
            if (latestProcessedBigCommerceCustomerUpdatedAt == null || currentIteratedBigCommerceCustomerUpdatedAt.isAfter(latestProcessedBigCommerceCustomerUpdatedAt)) {
                latestProcessedBigCommerceCustomerUpdatedAt = currentIteratedBigCommerceCustomerUpdatedAt
            }
        }
    }

    if (latestProcessedBigCommerceCustomerUpdatedAt != null) {
        if (currentExecutionLastProcessedBigCommerceCustomerUpdatedAtTimestamp != null && !currentExecutionLastProcessedBigCommerceCustomerUpdatedAtTimestamp.trim().isEmpty()) {
            ZonedDateTime currentExecutionLastProcessedBigCommerceCustomerUpdatedAtTime = ZonedDateTime.parse(currentExecutionLastProcessedBigCommerceCustomerUpdatedAtTimestamp, DateTimeFormatter.ISO_ZONED_DATE_TIME)
            if (latestProcessedBigCommerceCustomerUpdatedAt.isAfter(currentExecutionLastProcessedBigCommerceCustomerUpdatedAtTime)) {
                message.setProperty("current_execution_last_processed_bigcommerce_customer_updated_at_timestamp", latestProcessedBigCommerceCustomerUpdatedAt.toString())
            }
        } else {
            message.setProperty("current_execution_last_processed_bigcommerce_customer_updated_at_timestamp", latestProcessedBigCommerceCustomerUpdatedAt.toString())
        }
    }

    return message
}