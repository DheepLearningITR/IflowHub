import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {

        def bigCommerceCustomerId = message.getProperty("big_commerce_customer_id") as String;
        if (bigCommerceCustomerId != null && !bigCommerceCustomerId.isEmpty()) {
            messageLog.addCustomHeaderProperty("Replicated Customer with ID", bigCommerceCustomerId);
        }
    }
    return message;
}