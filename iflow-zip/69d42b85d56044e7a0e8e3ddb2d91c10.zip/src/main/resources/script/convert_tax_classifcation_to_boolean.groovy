import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)

    def xmlSlurper = new XmlSlurper()
    def xml = xmlSlurper.parse(body)

    def taxExempt = xml.tax_exempt_category.text().isEmpty() ? 1 : 0
    
    message.setProperty("taxExempt",taxExempt)
    return message;
}
