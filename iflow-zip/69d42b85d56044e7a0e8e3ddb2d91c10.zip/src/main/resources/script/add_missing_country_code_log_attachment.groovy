import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    def id = message.getProperty("big_commerce_customer_id");
    messageLog.addAttachmentAsString("Replication error", "Customer with BigCommerce id: " + id + " could not be replicated due to missing country code", "text/plain");

    return message;
}