import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def xmlSlurper = new XmlSlurper()
    def xml = xmlSlurper.parse(body)

    def metaInfo = xml.meta.pagination
    def currentPage = metaInfo.current_page.text().toInteger()
    def hasMorePages = metaInfo.total_pages.text().toInteger() > currentPage

    if (hasMorePages) {
        def nextPageNumber = currentPage + 1
        message.setProperty("get_customers_page", nextPageNumber)
    } else {
        message.setProperty("has_more_customers", false)
    }

    return message
}