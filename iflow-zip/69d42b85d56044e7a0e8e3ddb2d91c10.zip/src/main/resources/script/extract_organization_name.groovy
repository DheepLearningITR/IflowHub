import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)

    def xmlSlurper = new XmlSlurper()
    def xml = xmlSlurper.parse(body)

    def firstName = xml.first_name.text()
    def lastName = xml.last_name.text()
    
    message.setProperty("organisationName", firstName + " " + lastName)
    return message;
}
