import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    
    def body = message.getBody(java.io.Reader)

    def xml = new XmlSlurper().parse(body)

    def addressNode = xml.A_BusinessPartnerType.to_BusinessPartnerAddress.A_BusinessPartnerAddressType
    def addressMap = [
        StreetName: addressNode.StreetName.text(),
        HouseNumber: addressNode.HouseNumber.text(),
        Country: addressNode.Country.text(),
        PostalCode: addressNode.PostalCode.text(),
        CityName: addressNode.CityName.text()
    ]
    def addressJson = new JsonBuilder(addressMap).toString()
    def tax_classification = xml.A_BusinessPartnerType.to_Customer.A_CustomerType.to_CustomerSalesArea.A_CustomerSalesAreaType.to_SalesAreaTax.A_CustomerSalesAreaTaxType.CustomerTaxClassification.text()
    def organization_name = xml.A_BusinessPartnerType.OrganizationBPName1.text()
    
    message.setProperty("business_partner_tax_classification", tax_classification)
    message.setProperty("business_partner_organization_name", organization_name)
    message.setProperty("business_partner_address", addressJson)

    return message
}
