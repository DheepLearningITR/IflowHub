import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.util.XmlSlurper

def Message processData(Message message) {

    def body = message.getBody(java.io.Reader)
    def xml = new XmlSlurper().parse(body)

    def firstAddressNode = xml.addresses[0]
    def xmlAddress = [
            StreetName : firstAddressNode.address1.text(),
            HouseNumber: firstAddressNode.address2.text(),
            CityName   : firstAddressNode.city.text(),
            Country    : firstAddressNode.country_code.text(),
            PostalCode : firstAddressNode.postal_code.text()
    ]

    def jsonProperty = message.getProperty("business_partner_address")
    def jsonAddress = new JsonSlurper().parseText(jsonProperty)

    boolean isDifferent = xmlAddress.any { key, value ->
        jsonAddress[key] != value
    }

    message.setProperty("should_update_address", isDifferent)

    return message
}
