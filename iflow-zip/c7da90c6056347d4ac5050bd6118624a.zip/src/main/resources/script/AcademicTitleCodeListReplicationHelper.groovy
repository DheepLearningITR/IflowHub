import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
import groovy.json.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

def Message prepareSOAPRequest(Message message) {
  def properties = message.getProperties()
  def tableName = properties.get("TableName")


        def xml = """
<urn:COD_GET_CODE_LIST xmlns:urn="urn:sap-com:document:sap:rfc:functions">
    <IV_TABLE_NAME>${tableName}</IV_TABLE_NAME>
</urn:COD_GET_CODE_LIST>
"""

  def resultXml = XmlUtil.serialize(xml)
  message.setBody(resultXml)
  return message;
}

def Message prepareReceiverPayload(Message message) {

  def body = message.getBody(java.io.Reader)
  def soapResponse = new XmlSlurper().parse(body)

  def responsePayload = convertToJSON(soapResponse, message)
  message.setBody(responsePayload)

  return message

}

def convertToJSON(xml, message) {

  def properties = message.getProperties()
  def senderBusinessSystem = properties.get("SenderBusinessSystem")
  def receiverBusinessSystem = properties.get("ReceiverBusinessSystem")
  def messageEntityName = properties.get("MessageEntityName")
  def initialLoad = properties.get("InitialLoad")

  def jsonBuilder = new JsonBuilder()

  def codeList = []
  xml.ET_CODE_LIST.item.each {
    item ->
      def code = item.CODE.text()
     def description = item.TEXTS[0].item.TEXT.text()

    def resultMessage = [
      messageHeader: ["messageEntityName": messageEntityName, "actionCode": "SAVE", "id": generateRandomGUID()],
      body: [code: code, description: description]
    ]

    codeList.add(resultMessage)
  }
  if ('true'.equals(initialLoad)) {
    def receiverCodes = message.getHeader("ReceiverCodes", java.io.Reader)
    def receiverCodeList = new groovy.json.JsonSlurper().parse(receiverCodes)
    def erpCodes = xml.ET_CODE_LIST.item.collect {
      it.CODE.text()
    }
    def cnsCodes = receiverCodeList.value.collect {
      it.code
    }

    def codesToDelete = cnsCodes.findAll {
      !erpCodes.contains(it)
    }
    codesToDelete.each {
      code ->
        def deleteMessage = [
          messageHeader: ["messageEntityName": messageEntityName, "actionCode": "DELETE", "id": generateRandomGUID()],
          body: [code: code]
        ]

      codeList.add(deleteMessage)
    }
  }

  def creationDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))
  jsonBuilder {
    messageHeader("id": generateRandomGUID(), receiverCommunicationSystemDisplayId: receiverBusinessSystem, senderCommunicationSystemDisplayId: senderBusinessSystem, "creationDateTime": "$creationDateTime")
    messageRequests(codeList)
  }

  return JsonOutput.toJson(jsonBuilder.content)
}

def generateRandomGUID() {
  return UUID.randomUUID().toString()
}