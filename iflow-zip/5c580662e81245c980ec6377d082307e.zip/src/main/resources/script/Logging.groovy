import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	return message;
}


def Message addMessagesToAttachment(Message message) {
    def properties = message.getProperties();
    def trace = properties.get("DetailedTraceLog");
    String status = properties.get("Status") ?: '';
    if(!(status == "Closed") || (trace != null && trace.toUpperCase() == "TRUE")){
        // Get the closeMessages property
        String closeMessages = properties.get("CloseMessages") ?: '';

        // Log and format the ERPReadCloseMessages attachment
        if(closeMessages != ''){
            def messageLog = messageLogFactory.getMessageLog(message);
            if(messageLog != null){
            messageLog.addAttachmentAsString('ERPReadCloseMessages', "<Messages>" + closeMessages + "</Messages>", 'text/XML')
            }
        }
    }
    
    return message;
}


def Message logCloseInput(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    String QueryCloseInput = message.getBody();
	    messageLog.addAttachmentAsString('1CloseInput', QueryCloseInput, 'text/xml');
	}
	
	return message;
}


def Message logCloseOutput(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    String QueryCloseOutput = message.getBody();
	    messageLog.addAttachmentAsString('2CloseOutput', QueryCloseOutput, 'text/xml');
	}
	
	return message;
}