import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	return message;
}

def Message logExceptionAndMessages(Message message) {
    // Get the messageLogFactory and the CloseMessages property 
	def messageLog = messageLogFactory.getMessageLog(message);
    def properties = message.getProperties();
    String closeMessages = properties.get("CloseMessages") ?: '';
	
    if(messageLog != null){
        // Log and format the ERPReadCloseMessages attachment and Add the exception message to it if there is any
        try{
            def ex = properties.get("CamelExceptionCaught");
            String exMessage = "<Message Type=\"Error\" Origin=\"SAP IBP Add-On Read - Close\">" + ex.getMessage() + "</Message>";
            
            messageLog.addAttachmentAsString('ERPReadCloseMessages', "<Messages>" + exMessage + closeMessages + "</Messages>", 'text/XML')
            messageLog.addAttachmentAsString('latestBody', message.getBody(String), 'text/XML')
        }

        catch(Exception e){
            if(closeMessages != ''){l
                messageLog.addAttachmentAsString('ERPReadCloseMessages', "<Messages>" + closeMessages + "</Messages>", 'text/XML')
                messageLog.addAttachmentAsString('latestBody', message.getBody(String), 'text/XML')
            }  
        }
        
        //Set the body so that the next XSLT step will always have a valid body
        message.setBody("<Root/>");
    }
    
	return message;
}