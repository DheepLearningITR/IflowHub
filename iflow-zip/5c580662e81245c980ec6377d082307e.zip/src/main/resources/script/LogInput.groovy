import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
	    String QueryCloseInput = message.getBody();
	    messageLog.addAttachmentAsString('1CloseInput', QueryCloseInput, 'text/xml');
	}
	
	return message;
}

