import com.sap.gateway.ip.core.customdev.util.Message;

def Message giveEscalationMessage(Message message) {
    //Throw a custom exception and set an escalation message based on status and the existence of Close messages
    def messageLog = messageLogFactory.getMessageLog(message);
    String CloseMessages = message.getProperty('CloseMessages') ?: '';

    if (messageLog != null) {
        String status = getStatus(message)
        String escalationMessage = "There was a error during the read process check the logs"
        if (CloseMessages != '') {
            try {
                //Expectation is that the status is the worst one so we rethrow the worst message type
                escalationMessage = getFirstCloseMessageWithTypeMatchingStatus(message, status)
            }
            catch (Exception e) {
                throw new Exception(e.getMessage());
            }
            throw new CloseException(escalationMessage);
        } else {
            switch (status) {
                //Finished case is only executed when the method is called from the first status check, 
                //so it should not cause problems when called after Close messages
                case "Finished":
                    escalationMessage = "The Close process finished there is no more data in the system"
                    break
            }
            messageLog.addCustomHeaderProperty("Escalation message", escalationMessage);
            throw new CloseException(escalationMessage);
        }

    }

    return message;
}

def String getStatus(Message message) {
    //Returns the status of the iflow property has a higher priority compared to body
    String status = message.getProperty('Status') ?: ''
    if (status != '') {
        return status
    } else {
        def parsedBody = new XmlSlurper().parse(message.getBody(java.io.Reader));
        return parsedBody?.@Status?.text()
    }
}

def String getFirstCloseMessageWithTypeMatchingStatus(Message message, String status) {
    //Get the first message with the given type
    def parsedCloseMessages =new XmlSlurper().parseText(("<Messages>" + (message.getProperty('CloseMessages') as String)  + "</Messages>") as String)
    def firstCloseMessageWithTypeMatchingStatus = parsedCloseMessages?.'**'?.find { it -> it.name() == 'Message' && it.@Type.text() == status && it.text() != "" }

    return firstCloseMessageWithTypeMatchingStatus.text()
}

public class CloseException extends Exception {
    //Custom exception for Close
    public CloseException(String message) {
        super(message);
    }
}