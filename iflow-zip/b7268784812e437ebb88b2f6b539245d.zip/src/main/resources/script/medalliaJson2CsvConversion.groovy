import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def properties = message.getProperties()
    def csvHeader = properties.get("csvHeader")

    if (!csvHeader) {
        throw new IllegalStateException("CSV Header is not set in message properties.")
    }

    def isValidHeader = csvHeader.split(',').every { it =~ /^[A-Za-z_]+$/ }
    if (!isValidHeader) {
        throw new IllegalArgumentException("Invalid column names in CSV header. Column names must only contain characters from [A-Za-z_].")
    }

    def json = message.getBody(java.io.Reader)
    def jsonData = new JsonSlurper().parse(json)

    def csvOutput = new StringBuilder(csvHeader + "\n")

    jsonData?.data?.feedback?.nodes?.each { node ->
        def id = node?.id
        def email_id = node?.email?.values?.getAt(0)
        def comment = node?.name?.values?.getAt(0)
        csvOutput.append("${id},${email_id},\"${comment}\"\n")
    }

    message.setBody(csvOutput.toString())

    return message
}