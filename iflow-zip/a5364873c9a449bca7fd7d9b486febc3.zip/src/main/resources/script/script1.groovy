import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Set the auth token received into the Header 
       def c4cAuthTokenResponse = new JsonSlurper().parseText(message.getBody(String.class));
       message.setHeader("Authorization", "Bearer " + c4cAuthTokenResponse.value.access_token)

    //Set the message body to the mappedData from the previous mapping script  
       message.setBody(message.getProperty("mappedData"));

       return message;
}