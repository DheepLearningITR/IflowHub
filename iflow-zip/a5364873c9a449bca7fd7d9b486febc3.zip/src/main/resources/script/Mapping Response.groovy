import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput;
import groovy.json.JsonSlurper;
import java.time.Instant;

def Message processData(Message message) {
        
        def map = message.getProperties();
        def ems_root = new JsonSlurper().parseText(map.get("ems_body"));
        def s4_order_root = new XmlParser().parseText(map.get("s4_body"));
        //Read the BP get response from S4 and parse it
        def s4_bp_data = new XmlParser().parseText(message.getBody(String.class));
        
        def root = [
                messageHeader : [
                        id : UUID.randomUUID().toString(),
                        senderCommunicationSystemDisplayId : map.get("senderCommSysDisplayId"),
                        receiverCommunicationSystemDisplayId : map.get("receiverCommSysDisplayId"),
                        creationDateTime: Instant.now().toString()
                ],
                messageRequests : [[
                        messageHeader : [
                                id: UUID.randomUUID().toString(),
                                messageEntityName: "sap.crm.eventbridgeservice.entity.inboundEvent",
                                actionCode: "CREATE"
                        ],
                        body : [
                                eventId: ems_root.id,
                                eventType: ems_root.type,
                                sourceObjectType : "10003",
                                eventTime: ems_root.time,
                                objectAttributes: [
                                        [
                                                "key": "ID",
                                                "value": s4_order_root.content.'m:properties'.'d:ServiceOrder'.text().trim()
                                        ],
                                        [
                                                "key": "Description",
                                                "value": s4_order_root.content.'m:properties'.'d:ServiceOrderDescription'.text().trim()
                                        ],
                                        [
                                                "key": "SoldToParty",
                                                "value": s4_order_root.content.'m:properties'.'d:SoldToParty'.text().trim()
                                        ],
                                        [
                                                "key": "BusinessPartnerCategory",
                                                "value": s4_bp_data.content.'m:properties'.'d:BusinessPartnerCategory'.text().trim()
                                        ],
                                        [
                                                "key": "UUID",
                                                "value": s4_order_root.content.'m:properties'.'d:ServiceOrderUUID'.text().trim()
                                        ],
                                        [
                                                "key": "RequestedServiceStartDateTime",
                                                "value": s4_order_root.content.'m:properties'.'d:RequestedServiceStartDateTime'.text().trim()
                                        ],
                                        [
                                                "key": "RequestedServiceEndDateTime",
                                                "value": s4_order_root.content.'m:properties'.'d:RequestedServiceEndDateTime'.text().trim()
                                        ]
                                ]
                        ]
                ]]
        ]
        
        def root_out = JsonOutput.toJson(root)
        message.setBody(JsonOutput.prettyPrint(root_out.toString()))
        message.setProperty("mappedData",root_out)
        message.setHeader("SAP_ApplicationID", root.messageHeader.id);
       
       return message;
}