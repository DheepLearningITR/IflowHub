import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
     def body = message.getBody(String.class);
     message.setProperty("s4_body", body);
     
     def root = new XmlParser().parseText(body);
     
     def sold_to_party_id = "'" + root.content.'m:properties'.'d:SoldToParty'.text().trim() + "'"
     
     message.setProperty("sold_to_party_id", sold_to_party_id);
     return message;
       
}