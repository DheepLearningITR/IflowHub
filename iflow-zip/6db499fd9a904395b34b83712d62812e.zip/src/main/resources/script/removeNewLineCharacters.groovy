/*
=========================================================================================
This script processes the message body by removing newline characters and It replaces 
newlines with spaces in the body content and sets the modified body back to the message.
=========================================================================================
*/
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    // Get the body of the message as a String
    def body = message.getBody(java.lang.String);
    
    // Remove newlines from the body content
    def newBody = body.replaceAll(/(\r\n|\n)/, ' ');
    
    // Set the modified body back to the message
    message.setBody(newBody);

    return message;
}
