import com.sap.gateway.ip.core.customdev.util.Message

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import org.apache.commons.codec.binary.Base64;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.AccessTokenAndUser;
import groovy.transform.Field

import java.util.stream.Collectors;

@Field String PROPERTY_PID = 'PID';
@Field String PROPERTY_TENANT_CREDENTIALS = 'TENANT_CREDENTIALS';
@Field String PROPERTY_TENANT_URL = 'TENANT_URL';
@Field int HTTP_TIMEOUT = 600000;
@Field String RESOURCE_FOLDER = 'src/main/resources/mapping';
@Field String PAYLOAD_FOLDER = 'src/main/resources/payload';
@Field int FETCH_TOKEN_INTERNAL = 150;


// if true, DEBUG_MODE enables DEBUG_LOG property in the message context with contains traces.
// normally DEBUG_MODE must be false
@Field boolean DEBUG_MODE = false;


def Message processData(Message message) {

    Context ctx = create_context_for_message(message);
    try {
        ctx.create_http_client(HTTP_TIMEOUT);
        fetch_token(ctx);
        String meOpUrlList = message.getProperty('COMMON_DMC_REO_ME_OP_URL_LIST');
        String meOpSecurityList = message.getProperty('COMMON_DMC_REO_ME_OP_SECURITY_MATERIAL_LIST');

        Properties props = ctx.read_properties("${RESOURCE_FOLDER}/string_parameters.properties");

        if (meOpUrlList != null && !meOpUrlList.trim().equals("")) {
            props.setProperty('COMMON_DMC_REO_ME_OP_URL_LIST', meOpUrlList);
        }

        if (meOpSecurityList != null && !meOpSecurityList.trim().equals("")) {
            props.setProperty('COMMON_DMC_REO_ME_OP_SECURITY_MATERIAL_LIST', meOpSecurityList);
        }


        /*
         * Author: I043234
         *
         * Add one property ENABLE_PLANT_CONVERSION for plant conversion
         *
         */
        String enablePlantConversion = message.getProperty('ENABLE_PLANT_CONVERSION');
        if (enablePlantConversion != null && !enablePlantConversion.trim().equals("")) {
            props.setProperty('ENABLE_PLANT_CONVERSION', enablePlantConversion);
        }


        Set propNames = props.stringPropertyNames();
        int n = 0
        propNames.each {
            if (n >= FETCH_TOKEN_INTERNAL) {
                fetch_token(ctx);
                n = 0;
            } else {
                n++;
            }
            if (exists_pd_string_property("$it", ctx)) {
                update_pd_string_property("$it", props.get(it), ctx)
            } else {
                create_pd_string_property("$it", props.get(it), ctx)
            }
        }

        props = ctx.read_properties("${RESOURCE_FOLDER}/binary_parameters.properties");
        propNames = props.stringPropertyNames();
        propNames.each {
            if (n >= FETCH_TOKEN_INTERNAL) {
                fetch_token(ctx);
                n = 0;
            } else {
                n++;
            }
            String value = props.get(it);
            String binary_filename = "$PAYLOAD_FOLDER/$value";
            byte[] bytes = ctx.load_resouce_as_bytes(binary_filename);

            if (exists_pd_binary_property("$it", ctx)) {
                update_pd_binary_property("$it", bytes, 'xsl', ctx)
            } else {
                create_pd_binary_property("$it", bytes, 'xsl', ctx)
            }
        }

    } catch (Throwable ex) {
        ctx.log.println("exception: $ex");
        throw ex;
    } finally {
        if (DEBUG_MODE) message.exchange.setProperty('DEBUG_LOG', ctx.log.toString());
    }
    return message;
}

def String readCookies(Response resp) {
    return resp.getHeader("set-cookie");
}

def String fetch_token(Context ctx) {

    String url = "${ctx.tenant_url}/api/v1/StringParameters";
    ctx.log.println("fetch_token url:$url");

    Response resp = ctx.httpClient.send(Request.get(url).
            setHeader("Authorization", ctx.encodedCredentials).
            setHeader("Content-Type", "application/json").
            setHeader("Accept", "application/json").
            setHeader("x-csrf-token", "Fetch")); ;

    int statusCode = resp.getStatusCode();
    String statusText = resp.getStatusText();
    ctx.log.println("http status:$statusCode");

    String cookieString = readCookies(resp);

    ctx.log.println("cookieString = $cookieString");
    ctx.cookie = cookieString;

    if (statusCode == 200) {
        String token = resp.getHeader('x-csrf-token');
        ctx.xsrf_token = token;
        return;
    }
    if (statusCode == 401 || statusCode == 403) {
        throw new RuntimeException("Unexpected HTTP Response code $statusCode $statusText, please check if account configed in Security Material '$ctx.credential_alias' has proper authorizations.");
    }
    throw new RuntimeException("Unexpected HTTP Response code $statusCode");
}

def void create_pd_string_property(String key, String value, Context ctx) {

    String url = "${ctx.tenant_url}/api/v1/StringParameters";
    ctx.log.println("create_pd_string_property: $url");

    String body = """{ "Pid":"${ctx.pid}", "Id":"$key",  "Value": "$value"}""";

    ctx.log.println("body= $body");
    ctx.log.println("url= $url");


    Response resp = ctx.httpClient.send(Request.post(url).
            setHeader("Authorization", ctx.encodedCredentials).
            setHeader("Cookie", ctx.cookie).
            setHeader("Accept", "application/json").
            setHeader("Content-Type", "application/json").
            setHeader("x-csrf-token", ctx.xsrf_token).
            setBody(body))

    int statusCode = resp.getStatusCode();
    String statusText = resp.getStatusText();


    ctx.log.println("http status:$statusCode $statusText");

    if (statusCode == 201) {
        return;
    }
    if (statusCode == 401 || statusCode == 403) {
        throw new RuntimeException("Unexpected HTTP Response code $statusCode $statusText, please check if account configed in Security Material '$ctx.credential_alias' has proper authorizations."); ;
    }
    throw new RuntimeException("Unexpected HTTP Response code $statusCode $statusText");
}


def void create_pd_binary_property(String key, byte[] value, String content_type, Context ctx) {

    String url = "${ctx.tenant_url}/api/v1/BinaryParameters";
    ctx.log.println("create_pd_binary_property: $url");


    Base64 base64 = new Base64();
    String encodedValue = new String(base64.encode(value));

    String body = """{ "Pid":"${ctx.pid}", "Id":"$key","ContentType":"$content_type",  "Value": "$encodedValue"}""";

    ctx.log.println("body= $body");
    ctx.log.println("url= $url");


    Response resp = ctx.httpClient.send(Request.post(url).
            setHeader("Authorization", ctx.encodedCredentials).
            setHeader("Cookie", ctx.cookie).
            setHeader("Accept", "application/json").
            setHeader("Content-Type", "application/json").
            setHeader("x-csrf-token", ctx.xsrf_token).
            setBody(body))

    int statusCode = resp.getStatusCode();
    String statusText = resp.getStatusText();


    ctx.log.println("http status:$statusCode $statusText");

    if (statusCode == 201) {
        return;
    }

    if (statusCode == 401 || statusCode == 403) {
        throw new RuntimeException("Unexpected HTTP Response code $statusCode $statusText, please check if account configed in Security Material '$ctx.credential_alias' has proper authorizations."); ;
    }
    throw new RuntimeException("Unexpected HTTP Response code $statusCode $statusText");
}

def void update_pd_string_property(String key, String value, Context ctx) {

    String url = "${ctx.tenant_url}/api/v1/StringParameters(Pid='${ctx.pid}',Id='$key')";

    ctx.log.println("update_pd_string_property: $url");

    String body = """{ "Pid":"${ctx.pid}", "Id":"$key",  "Value": "$value"}""";

    ctx.log.println("body= $body");
    ctx.log.println("url= $url");


    Response resp = ctx.httpClient.send(Request.put(url).
            setHeader("Authorization", ctx.encodedCredentials).
            setHeader("Accept", "application/json").
            setHeader("Cookie", ctx.cookie).
            setHeader("Content-Type", "application/json").
            setHeader("x-csrf-token", ctx.xsrf_token).
            setBody(body))

    int statusCode = resp.getStatusCode();
    String statusText = resp.getStatusText();


    ctx.log.println("http status:$statusCode $statusText");

    if (statusCode == 204) {
        return;
    }

    if (statusCode == 401 || statusCode == 403) {
        throw new RuntimeException("Unexpected HTTP Response code $statusCode $statusText, please check if account configed in Security Material '$ctx.credential_alias' has proper authorizations."); ;
    }
    throw new RuntimeException("Unexpected HTTP Response code $statusCode $statusText");
}


def void update_pd_binary_property(String key, byte[] value, String content_type, Context ctx) {

    String url = "${ctx.tenant_url}/api/v1/BinaryParameters(Pid='${ctx.pid}',Id='$key')";

    ctx.log.println("update_pd_binary_property: $url");

    Base64 base64 = new Base64();
    String encodedValue = new String(base64.encode(value));

    String body = """{ "Pid":"${ctx.pid}", "Id":"$key","ContentType":"$content_type",  "Value": "$encodedValue"}""";

    ctx.log.println("body= $body");
    ctx.log.println("url= $url");


    Response resp = ctx.httpClient.send(Request.put(url).
            setHeader("Authorization", ctx.encodedCredentials).
            setHeader("Accept", "application/json").
            setHeader("Cookie", ctx.cookie).
            setHeader("Content-Type", "application/json").
            setHeader("x-csrf-token", ctx.xsrf_token).
            setBody(body))

    int statusCode = resp.getStatusCode();
    String statusText = resp.getStatusText();


    ctx.log.println("http status:$statusCode $statusText");

    if (statusCode == 204) {
        return;
    }
    if (statusCode == 401 || statusCode == 403) {
        throw new RuntimeException("Unexpected HTTP Response code $statusCode $statusText, please check if account configed in Security Material '$ctx.credential_alias' has proper authorizations."); ;
    }
    throw new RuntimeException("Unexpected HTTP Response code $statusCode $statusText");
}


def boolean exists_pd_string_property(String key, Context ctx) {
    return exists_pd_property(true, key, ctx);
}

def boolean exists_pd_binary_property(String key, Context ctx) {
    return exists_pd_property(false, key, ctx);
}

def boolean exists_pd_property(boolean isStringProperty, String key, Context ctx) {

    String pid = ctx.pid;
    String url_part = isStringProperty ? "StringParameters" : "BinaryParameters";

    String url = "${ctx.tenant_url}/api/v1/${url_part}(Pid='$pid',Id='$key')";
    ctx.log.println("exists_pd_property: $url");


    ctx.log.println("url= $url");

    Response resp = ctx.httpClient.send(Request.get(url).
            setHeader("Authorization", ctx.encodedCredentials).
            setHeader("Cookie", ctx.cookie).
            setHeader("Accept", "application/json").
            setHeader("Content-Type", "application/json").
            setHeader("x-csrf-token", ctx.xsrf_token))

    int statusCode = resp.getStatusCode();
    String statusText = resp.getStatusText();


    ctx.log.println("http status:$statusCode $statusText");


    if (statusCode == 200) {
        return true;
    } else if (statusCode == 404) {
        return false;
    }

    throw new RuntimeException("Unexpected HTTP Response code $statusCode $statusText");
}

void delete_pd_all_properties(Context ctx) {

    String url = "${ctx.tenant_url}/api/v1/Partners('${ctx.pid}')";

    ctx.log.println("delete_pd_all_properties: $url");


    Response resp = ctx.httpClient.send(Request.delete(url).
            setHeader("Authorization", ctx.encodedCredentials).
            setHeader("Cookie", ctx.cookie).
            setHeader("Accept", "application/json").
            setHeader("x-csrf-token", ctx.xsrf_token))

    int statusCode = resp.getStatusCode();
    String statusText = resp.getStatusText();

    ctx.log.println("http status:$statusCode $statusText");

    if (statusCode == 204) {
        return;
    }

    throw new RuntimeException("Unexpected HTTP Response code $statusCode $statusText");
}


def UserCredential readUserCredential(String alias) {
    def service = ITApiFactory.getService(SecureStoreService.class, null);
    def credential = service.getUserCredential(alias);
    return credential;
}

def AccessTokenAndUser readAccessTokenAndUser(String alias) {
    def service = ITApiFactory.getService(SecureStoreService.class, null);
    def tokenAndUser;
    try {
        tokenAndUser = service.getAccesTokenForOauth2ClientCredential(alias);
    } catch (Exception e) {
        tokenAndUser = service.getAccesTokenForOauth2AuthorizationCodeCredential(alias);
    }
    return tokenAndUser;
}


def Context create_context_for_message(Message message) {
    Context ctx = new Context();
    ctx.pid = message.getProperties().get(PROPERTY_PID);
    if (ctx.pid == null) {
        throw new RuntimeException("Property ${PROPERTY_PID} cannot be empty!");
    }

    String tenant_url = message.getProperties().get(PROPERTY_TENANT_URL);
    ctx.tenant_url = tenant_url;
    if (tenant_url == null) {
        throw new RuntimeException("Property ${PROPERTY_TENANT_URL} cannot be empty!");
    }

    String tenant_credentials = message.getProperties().get(PROPERTY_TENANT_CREDENTIALS);
    if (tenant_credentials == null) {
        throw new RuntimeException("Property ${PROPERTY_TENANT_CREDENTIALS} cannot be empty!");
    }

    ctx.encodedCredentials = getCredential(tenant_credentials);
    ctx.credential_alias = tenant_credentials;
    return ctx;
}

//get credential by alias configured in security material
def String getCredential(String alias) {
    // 2202 release we support oauth2 Authorization Code
    String credential = "";
    try {
        AccessTokenAndUser accessTokenAndUser = readAccessTokenAndUser(alias);
        credential = "Bearer " + accessTokenAndUser.getAccessToken();
    } catch (Exception e) {
        UserCredential credentials = readUserCredential(alias);
        Base64 base64 = new Base64();
        String encodedString = credentials.getUsername() + ":" + credentials.getPassword();
        credential = "Basic " + new String(base64.encode(encodedString.getBytes()));
    }
    return credential;
}

class Context {

    String pid = null;
    String xsrf_token = null;
    HttpClient httpClient = null;
    String encodedCredentials = null;
    String cookie = null;
    String tenant_url = null;
    StringWriter log = new StringWriter();
    String credential_alias = null;

    def void create_http_client(int http_timepout) {
        httpClient = new HttpClient(http_timepout, http_timepout);
    }


    def Properties read_properties(String resource_name) {
        InputStream rs = getClass().getResourceAsStream(resource_name)
        Properties props = new Properties()
        props.load(rs)
        return props;
    }

    def byte[] load_resouce_as_bytes(String resource_name) {
        log.println("load_resouce_as_bytes $resource_name");
        InputStream rs = getClass().getResourceAsStream(resource_name)
        byte[] b = rs.getBytes()
        return b;
    }

}

class HttpClient {
    int connectTimeout = 10_000
    int readTimeout = 30_000

    HttpClient() {}

    HttpClient(int connectTimeoutMillis, int readTimeoutMillis) {
        this.connectTimeout = connectTimeoutMillis
        this.readTimeout = readTimeoutMillis
    }

    Response send(Request request) throws IOException {
        URL url = new URL(request.url)
        HttpURLConnection conn = (HttpURLConnection) url.openConnection()
        conn.requestMethod = request.method
        conn.connectTimeout = connectTimeout
        conn.readTimeout = readTimeout

        // Set headers
        request.headers.each { key, value ->
            conn.setRequestProperty(key, value)
        }

        // Write body if present
        if (request.body) {
            conn.doOutput = true
            byte[] bytes = request.body.getBytes(StandardCharsets.UTF_8)
            conn.setRequestProperty("Content-Length", bytes.length.toString())
            conn.outputStream.withStream { os ->
                os.write(bytes)
            }
        }

        int status = conn.responseCode
        InputStream is = (status >= 200 && status < 400) ? conn.inputStream : conn.errorStream
        String body = readStream(is)

        Map<String, List<String>> respHeaders = conn.headerFields
        conn.disconnect()

        return new Response(status, respHeaders, body)
    }

    private String readStream(InputStream is) throws IOException {
        if (!is) return ""
        StringBuilder sb = new StringBuilder()

        new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8)).withReader { reader ->
            reader.eachLine { line ->
                sb.append(line).append('\n')
            }
        }

        return sb.toString().trim()
    }
}

class Request {
    String url
    String method = "GET"
    Map<String, String> headers = [:]
    String body

    private Request(String url) {
        this.url = url
    }

    static Request get(String url) {
        new Request(url).method("GET")
    }

    static Request post(String url) {
        new Request(url).method("POST")
    }

    static Request put(String url) {
        new Request(url).method("PUT")
    }

    static Request delete(String url) {
        new Request(url).method("DELETE")
    }

    Request method(String method) {
        this.method = method
        return this
    }

    Request setHeader(String name, String value) {
        this.headers.put(name, value)
        return this
    }

    Request setBody(String body) {
        this.body = body
        return this
    }
}

class Response {
    int statusCode
    String statusText
    Map<String, List<String>> headers
    String body

    Response(int statusCode, Map<String, List<String>> headers, String body) {
        this.statusCode = statusCode
        this.headers = headers ?: [:]
        this.body = body
    }

    String getHeader(String name) {
        Map<String, List<String>> normalizedHeaders = headers.collectEntries { key, value ->
            [(key?.toLowerCase()): value];
        }
        return normalizedHeaders.get(name)?.stream()?.collect(Collectors.joining("; ")) ?: ""
    }

}

