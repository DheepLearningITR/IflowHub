import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.exception.SecureStoreException
import groovy.json.JsonSlurper
import groovy.json.JsonOutput;
import java.time.Instant

def Message setAPIEndpoint(Message message) {

    def body = message.getBody(String) as String;
    
    def cbrAPIEndpointName = message.getHeaders().get('cbrAPIEndpointName');
    def cbrAPIEndpoint = message.getProperty(cbrAPIEndpointName);
    if(!cbrAPIEndpoint){
        throw new IllegalArgumentException("Endpoint '" +  cbrAPIEndpointName +"' not found");
    }
    message.setProperty("cbrAPIEndpoint", cbrAPIEndpoint)
    message.setProperty("cbrPayload", body)
    message.setBody(null); //clear payload
    return message;
}


def Message getCobrainerAPIKey(Message message) {

    def secureStorageService = ITApiFactory.getService(SecureStoreService.class, null)

    def apiKey_alias = message.getProperty("cbrAPIKey")
    try{
        def secureParameter = secureStorageService.getUserCredential(apiKey_alias)
        def apiKey = secureParameter.getPassword().toString()
        message.setProperty("cbrAPIKey", apiKey)
        
    } catch(Exception e){
        throw new SecureStoreException("Secure Parameter not found")
    }

    return message;
}

def Message getAPICredentials(Message message) {

    def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)

    def apiCredential_alias = message.getProperty("cbrAPIUserCredential")
    try{
        def credential = secureStorageService.getUserCredential(apiCredential_alias)
        def apiUser = credential.getUsername().toString()
        def apiPW = credential.getPassword().toString()
        message.setProperty("cbrAPIPW", apiPW)
        message.setProperty("cbrAPIUser", apiUser)
        
    } catch(Exception e){
        throw new SecureStoreException("User Credential not found")
    }

    def apiClientId_alias = message.getProperty("cbrAPIClientId")
    try{
        def secureParameter = secureStorageService.getUserCredential(apiClientId_alias)
        def apiClientId = secureParameter.getPassword().toString()
        message.setProperty("cbrAPIClientId", apiClientId)
        
    } catch(Exception e){
        throw new SecureStoreException("Secure Parameter not found")
    }

    return message;
}


def Message parseAPITokenInfo(Message message) {

    def body = message.getBody(String) as String;

    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(body)
    def authResult = jsonObject.AuthenticationResult

    // Extract properties
    def idToken = authResult.IdToken    
    def tokenType = authResult.TokenType
    def expiresIn = authResult.ExpiresIn as Long
    expiresIn = expiresIn - 120; //less 2 minutes to give some wiggle room
    
    def expiry = Instant.now().plusSeconds(expiresIn).toString()
    jsonObject.AuthenticationResult.ExpiresAt = expiry

    // Define the fields to keep
    def fieldsToKeep = ['TokenType', 'IdToken', 'ExpiresAt']

    // Remove all fields not in fieldsToKeep
    authResult.keySet().findAll { !(it in fieldsToKeep) }.each { authResult.remove(it) }

    def updatedBody = JsonOutput.toJson(jsonObject)
    
    //encrypt body
    def keyString = deriveKeyFromSecrets(message)
    def encryptedBody = xorEncode(updatedBody.toString(), keyString)
    message.setBody(encryptedBody)
    
    message.setProperty("tokenType", tokenType)
    message.setProperty("idToken", idToken)
    message.setProperty("tokenExpiry", expiry);      
    
    message.setProperty("cbrAPIClientId", null) //clear
    message.setProperty("cbrAPIPW", null)       //clear
    message.setProperty("cbrAPIUser", null)     //clear

    return message
}

def Message parseAPITokenInfoDS(Message message) {

    def body = message.getBody(String) as String
    
    if (!body || body.trim().isEmpty()) {
        //body is empty!
        message.setProperty("tokenType", '')
        message.setProperty("idToken", '')        
    }else{
    
        def keyString = deriveKeyFromSecrets(message)
        def decryptedBody = xorDecode(body, keyString)       
    
        def jsonSlurper = new JsonSlurper()
        def jsonObject = jsonSlurper.parseText(decryptedBody)
        def authResult = jsonObject.AuthenticationResult
    
        // Extract properties
        def tokenType = authResult.TokenType
        def idToken = authResult.IdToken
        def expiry = authResult.ExpiresAt

        // Check if token is expired
        def now = Instant.now()
        def expiresAtInstant = Instant.parse(expiry)

        if (now.isAfter(expiresAtInstant)) {
            //expired, clear idToken
            idToken = ''    
        }
        
        message.setProperty("dateTimeNow", now); 
        message.setProperty("tokenType", tokenType)
        message.setProperty("idToken", idToken)
        message.setProperty("tokenExpiry", expiry);      
        
        message.setBody(null); //clear body
    }
    
    return message;
}


def deriveKeyFromSecrets(Message message) {

    def username = message.getProperty("cbrAPIUser")
    def password = message.getProperty("cbrAPIPW")
    def clientId = message.getProperty("cbrAPIClientId")

    def combined = username + password + clientId
    return combined;
}

def xorEncode(String input, String key) {
    
    //just to make it unreadable when downloaded from the datastore by a support person with permissions to do so
    def result = new byte[input.length()]
    for (int i = 0; i < input.length(); i++) {
        int inputChar = (int) input.charAt(i)
        int keyChar = (int) key.charAt(i % key.length())
        result[i] = (byte) (inputChar ^ keyChar)
    }
    return result.encodeBase64().toString()
}

def xorDecode(String base64Text, String key) {
    def decoded = base64Text.decodeBase64()
    def result = new char[decoded.length]
    for (int i = 0; i < decoded.length; i++) {
        int decodedByte = decoded[i] & 0xFF
        int keyChar = (int) key.charAt(i % key.length())
        result[i] = (char) (decodedByte ^ keyChar)
    }
    return new String(result)
}


