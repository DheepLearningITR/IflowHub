import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*
import java.net.URLEncoder;

def Message processData(Message message) {
 
       //Properties 
       def map = message.getProperties();
       def value = map.get("Remark");
       def encodedValue = URLEncoder.encode(value, "UTF-8");
       
       message.setProperty('Remark', encodedValue);

       return message;
}