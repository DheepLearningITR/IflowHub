import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    def headers = message.getHeaders()
    def productId = headers.get("product_id")
    def variantId = headers.get("variant_id")
    def isEqual = (productId != null && variantId != null && productId == variantId)
    message.setProperty("productEqualsVariant", isEqual)
    return message
}