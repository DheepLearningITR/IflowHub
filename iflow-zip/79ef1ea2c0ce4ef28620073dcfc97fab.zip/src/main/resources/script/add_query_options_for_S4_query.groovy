import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def plant = message.getHeader("plant", String) ?: "";
    def storageLocationIds = message.getHeader("storage_location_ids", String) ?: "";
    def materialId = message.getHeader("s4hana_product_id", String) ?: "";
    def inventoryStockType = message.getProperty("InventoryStockType");
    def filters = []

    if (plant) {
        def plants = plant.split(',')
        def plantFilters = plants.collect { "Plant eq '${it.trim()}'" }
        if (plantFilters) {
            filters.add("(" + plantFilters.join(" or ") + ")")
        }
    }
    if (storageLocationIds) {
        def locations = storageLocationIds.split(',')
        def locationFilters = locations.collect { "StorageLocation eq '${it.trim()}'" }
        if (locationFilters) {
            filters.add("(" + locationFilters.join(" or ") + ")")
        }
    }
    if(materialId) {
        filters.add("Material eq '${materialId.trim()}'")
    }

    if(inventoryStockType) {
        filters.add("InventoryStockType eq '${inventoryStockType}'");
    }

    def filterQuery = ""
    if (!filters.isEmpty()) {
        filterQuery = "\$filter=" + filters.join(" and ")
    }

    message.setProperty("customQueryOptions", filterQuery)
    return message;
}