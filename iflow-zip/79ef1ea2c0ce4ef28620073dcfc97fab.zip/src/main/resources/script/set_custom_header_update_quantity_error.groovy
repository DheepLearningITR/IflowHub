import com.sap.gateway.ip.core.customdev.util.Message


def Message processData(Message message) {
    def map = message.getProperties()
    def logException = map.get("ExceptionLogging")?.equalsIgnoreCase("true")
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
    def headers = message.getHeaders()
    def productId = headers.get("product_id") as String
    
    if(messageLog != null){
            
        def errorTitlePattern = ~/"title"\s*:\s*"([^"]*)"/

        def errorTitleValue = null

        def ex = map.get("CamelExceptionCaught") as String
        
        if (ex == null) {
            ex = message.getBody(String)
        }
            
        def matcher = errorTitlePattern.matcher(ex)
        
        if (matcher.find()) {
            errorTitleValue = matcher.group(1)
        }

        if (productId != null && !productId.isEmpty()) {
            messageLog.addCustomHeaderProperty("Error Updating Quantity", "Quantity NOT updated for product ${productId} with reason: ${errorTitleValue}")
        }
     
        
    }
    return message
}
