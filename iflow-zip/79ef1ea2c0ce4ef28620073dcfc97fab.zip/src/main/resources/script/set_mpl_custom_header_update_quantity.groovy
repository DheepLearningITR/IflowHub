import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

	def messageLog = messageLogFactory.getMessageLog(message);

    def headers = message.getHeaders()
    
    def productId = headers.get("product_id")
    
	if(messageLog != null){
		if(productId != null && !productId.isEmpty()){
			messageLog.addCustomHeaderProperty("Quantity updated for product ", productId);		
        }
	}	
	
	return message;
}