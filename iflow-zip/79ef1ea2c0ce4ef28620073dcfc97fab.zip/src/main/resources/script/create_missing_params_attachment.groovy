import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    
    if (messageLog != null) {
        messageLog.addAttachmentAsString(
            "Missing Params for Products Stock Replication in BigCommerce",
            "One or more required parameters are missing.",
            "text/plain"
        )
    }

    return message
}
