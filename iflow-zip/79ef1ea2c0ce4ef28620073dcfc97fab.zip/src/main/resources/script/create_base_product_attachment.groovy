import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message)
{
    def messageLog = messageLogFactory.getMessageLog(message);

    if(messageLog != null)
    {
        String productId = message.getHeader("product_id", String)
        messageLog.addAttachmentAsString("Base Product attempted to update inventory in BigCommerce:", productId, "text/plain");
    }

    return message;
}