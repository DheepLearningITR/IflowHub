import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    String locationHeader = message.getHeader("location_id", String)
    def body = message.getBody(java.io.Reader)
    def xml  = new XmlSlurper().parse(body)
    
    boolean locationIsPresent = xml.data.any { it.id.text() == locationHeader }

    message.setProperty("location_present", locationIsPresent)

    return message
}