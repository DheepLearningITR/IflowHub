def void getTaxJurisdictionType(String taxType) {
    //We need to take taxtypecode from suretax
    //take the last char of the taxtypecode
    //if the last char is 1, it is state so return jurisdiction as 1
    //if the last char is 2, it is county so return jurisdiction as 2
    //if the last char is 4, it is city so return jurisdiction as 3
    //for other scenarios for now, take it as special(local) so return 4
    String jurisdictionType = 4;
    if(taxType?.trim() && taxType.length() > 0) {
        if("1".equalsIgnoreCase(taxType[-1])) {
           jurisdictionType ="1" ;
        } else if("2".equalsIgnoreCase(taxType[-1])) {
            jurisdictionType = "2";
        } else if("4".equalsIgnoreCase(taxType[-1])) {
            jurisdictionType = "3";
        } 
        
    }
    output.addValue(jurisdictionType);
}