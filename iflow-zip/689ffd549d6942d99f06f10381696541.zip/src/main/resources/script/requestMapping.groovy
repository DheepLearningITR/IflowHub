import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import com.sap.it.api.mapping.MappingContext;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import java.util.HashMap;
import java.util.List;
import groovy.transform.Field;
import net.sf.saxon.tree.tiny.*;
import java.lang.Exception;
import java.lang.Math;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.op.agent.mpl.MplConfiguration;

@Field Map<String,String> EXEMPT_CODE_MAP = new HashMap<String,String>();
    EXEMPT_CODE_MAP.put("01","Federal government");
    EXEMPT_CODE_MAP.put("02","State or local government");
    EXEMPT_CODE_MAP.put("03","Tribal government");
    EXEMPT_CODE_MAP.put("04","Foreign diplomat");
    EXEMPT_CODE_MAP.put("05","Charitable organization");
    EXEMPT_CODE_MAP.put("06","Religious or educational organization");
    EXEMPT_CODE_MAP.put("07","Resale");
    EXEMPT_CODE_MAP.put("08","Agricultural production");
    EXEMPT_CODE_MAP.put("09","Industrial production/manufacturing");
    EXEMPT_CODE_MAP.put("10","Direct pay permit");
    EXEMPT_CODE_MAP.put("11","Direct Mail");
    EXEMPT_CODE_MAP.put("12","Other");
    EXEMPT_CODE_MAP.put("13","Non Profit");

def String customGetClientNumber(String storedUsername){
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential(storedUsername);
    if (credential == null) {
        throw new IllegalStateException("No credential found for alias '$storedUsername'");
    }
    return credential.getUsername();
}

def String customGetVKey (String storedUsername){
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential(storedUsername);
    if (credential == null) {
        throw new IllegalStateException("No credential found for alias '$storedUsername'");
    }
    return new String(credential.getPassword());
}

def String getResponseType(String currency) {
    def intValue = (currency!= null && currency.isInteger()) ? currency.toInteger() : "2";
    return "12X"+intValue;
}

def String getNodeValue(String nodeValue){
	if (null != nodeValue && !nodeValue.trim().isEmpty()) {
        return nodeValue
    } else {
	    return ""
    }
}


def String selectTransactionTypeCode(String defaultTransTypeCode, String itemNo, MappingContext context) {
    Map<String, String> ttCodeValueMap = context.getProperty("exchangeTTCodeValueMap");
    if (ttCodeValueMap.containsKey(itemNo)) {
        return ttCodeValueMap.get(itemNo);
    }

    if (defaultTransTypeCode != null && !defaultTransTypeCode.trim().isEmpty()) {
        return defaultTransTypeCode;
    }
    
    return "";
}

def String getRuleOverrideValueFromAPAR(String APAR_IND,MappingContext context) {
    String ruleOverride = "0";
    if("A".equalsIgnoreCase(APAR_IND)) {
        ruleOverride = getExchangeProperty("exchangeARRuleOverride",context);
    } else if("V".equalsIgnoreCase(APAR_IND)) {
        ruleOverride = getExchangeProperty("exchangeAPRuleOverride",context);;
    }
    return ruleOverride;
}

def String getDateInFormat(String dateStr){
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	//Strict Leniency so that bad dates like 2019-02-31 will fail.
    dateFormat.setLenient(false);
	String dateToReturn = '';
	try {
		Date date = dateFormat.parse(dateStr);
	    dateToReturn = dateFormat.format(date);
	} catch(ParseException e){
		throw new Exception("Bad Date");
	}
	return dateToReturn;
}


def String getDataYear(String dateStr){
   SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
   Date date = null;
   try {
        date = Date.parse("yyyy-MM-dd",dateStr);
   } catch(ParseException e){
        throw new Exception("Bad Date");
   }
   Date currentDate = new Date();
   String currentDateStr = new Date().format("yyyy-MM-dd");
   currentDate = Date.parse("yyyy-MM-dd",currentDateStr);
   // Now we have today date or from dateStr
   String dateToReturn = dateFormat.format(date);
   if(date.compareTo(currentDate) == 1)
   {
       dateToReturn = dateFormat.format(currentDate);
   }
   
   return dateToReturn.substring(0,4);
}

def String getDataMonth(String date) {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Date date1 = null;
    try{
        date1 = Date.parse("yyyy-MM-dd",date);
    } catch(ParseException e){
        throw new Exception("Bad Date");
    }
    Date currentDate = new Date();
    String currentDateStr = new Date().format("yyyy-MM-dd");
    currentDate = Date.parse("yyyy-MM-dd",currentDateStr);
    String monthToReturn = simpleDateFormat.format(date1);
    if(date1.compareTo(currentDate) == 1)
    {
       
       monthToReturn = simpleDateFormat.format(currentDate);
    }
    return monthToReturn.substring(5,7);
}

def String getYear(String dateStr){
   SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
   Date date = null;
   try {
        date = Date.parse("yyyy-MM-dd",dateStr);
   } catch(ParseException e){
        throw new Exception("Bad Date");
   }
   
   // Now we have today date or from dateStr
   String dateToReturn = dateFormat.format(date);
   
   return dateToReturn.substring(0,4);
}

def String getMonth(String date) {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Date date1 = null;
    try{
        date1 = Date.parse("yyyy-MM-dd",date);
    } catch(ParseException e){
        throw new Exception("Bad Date");
    }
    String monthToReturn = simpleDateFormat.format(date1);
    return monthToReturn.substring(5,7);
}

def String getCurrencyDecimalToNumber(String currencyDecimal)
{
    int currencyDecimalToNumber = 100;
    try{
        if(null != currencyDecimal && !(currencyDecimal.trim().isEmpty())) {
            int currencyDecimalNumber = Integer.parseInt(currencyDecimal.trim());
            currencyDecimalToNumber = Math.pow(10,currencyDecimalNumber);
        }
    } catch (Exception e) {
        //ignore
    }
    return ""+currencyDecimalToNumber;
    
}
def String getLineNumbers(String propertyName, MappingContext context) {
    String str = "";
    try{
    ArrayList list = (ArrayList)context.getProperty(propertyName);
    for(int i=0;i<list.size();i++){
        str = str + ((TinyTextualElement)(list.get(i))).getStringValue();
    }
    }catch(Exception e){
        str = e.getMessage();
        
    }
    return str;
}

def String getExchangeProperty(String propertyName, MappingContext context) {
    String propertyValue = context.getProperty(propertyName);
    return propertyValue;
}

def String getClientTracking(String theVersion, MappingContext context) {
    String exchangeSapVersion = getExchangeProperty("exchangeSapVersion", context);
    String exchangeServerName = getExchangeProperty("exchangeServerName", context);
    return "WK;SAPS4HC;" + exchangeSapVersion + ";v" + theVersion + ";ExternalAPI;CalculateTax;" + exchangeServerName + ";N/A;";
}

// check ship to geocode
def String trimAndVerifyGeocode(String inGeocode, String jurisdictionElementName, MappingContext context) {
    String trimmedGeo = inGeocode != null ? inGeocode.trim() : "";
    
    if( trimmedGeo.equals("")){
       if (jurisdictionElementName.equals("TXJCD_ST")) {
		    throw new Exception("Jurisdiction Code not found");
	    } 
    }
    
    try {
        String jcdUnifyInd = context.getProperty("exchangeJcdUnifyInd");
        if(jcdUnifyInd != null && "X".equalsIgnoreCase(jcdUnifyInd.trim()))
        {
            //remove 3-4 chars from trimmedGeo and remove last char
            trimmedGeo = trimmedGeo.substring(0,2) + trimmedGeo.substring(4,14);
            
        }
    } catch (Exception e){
        throw new Exception("Tax Jurisdiction Code is not supported in external system. Invalid value for '$jurisdictionElementName' = '$inGeocode'");
    }
    // geocode is 12 chars
    // 1st 2 chars Alpha
    // next 5 chars numbers
    // next 5 chars alphanumeric
    def m = trimmedGeo =~ /^[a-zA-Z]{2}\d{5}[a-zA-Z0-9]{5}/;
    if(trimmedGeo.length() != 12 || !m.find() ) {
        throw new Exception("Tax Jurisdiction Code is not supported in external system. Invalid value for '$jurisdictionElementName' = '$inGeocode'");
    }
    return trimmedGeo;
}

def void getTotal(String[] amount, String[] freight,Output output,MappingContext context) {
    BigDecimal total = new BigDecimal(0);
    int currencyDecimalInt = 2;
    int currencyDecimalVal = 100;
    try{
        String currencyDecimalStr = getExchangeProperty("exchageCurrencyDecimal",context);
        currencyDecimalInt = Integer.parseInt(currencyDecimalStr.trim());
        currencyDecimalVal = Math.pow(10,currencyDecimalInt);
    } catch(Exception e){
        //ignore
    }
    
    for(int i=0; i<amount.length; i++) {
        try{
            BigDecimal val = new BigDecimal(getNegativeNormal(amount[i]));
            val /= currencyDecimalVal;
            total = total + val;
        } catch(Exception e) {
            //ignore
        }
    }
    for(int i=0;i<freight.length;i++) {
        try{
            BigDecimal val = new BigDecimal(getNegativeNormal(freight[i]));
            val /= currencyDecimalVal;
            total = total + val;
        } catch(Exception e) {
            //ignore
        }
    }
    // def retval = new BigDecimal(total).toString();
    total = total.setScale(currencyDecimalInt, BigDecimal.ROUND_HALF_EVEN);
    def retval = total.toString();
    output.addValue(retval);
}

def void getTotalFreight(String[] freight,Output output, MappingContext context) {
    int currencyDecimalInt = 2;
    int currencyDecimalVal = 100;
    try{
        String currencyDecimalStr = getExchangeProperty("exchageCurrencyDecimal",context);
        currencyDecimalInt = Integer.parseInt(currencyDecimalStr.trim());
        currencyDecimalVal = Math.pow(10,currencyDecimalInt);
    } catch(Exception e){
        //ignore
    }
    BigDecimal total = new BigDecimal(0);
    for(int i=0;i<freight.length;i++) {
        try{
            BigDecimal val = new BigDecimal(getNegativeNormal(freight[i]));
            val /= currencyDecimalVal;
            total = total + val;
        } catch(Exception e) {
            //ignore
        }
    }
    
    total = total.setScale(currencyDecimalInt, BigDecimal.ROUND_HALF_EVEN);
    def retval = total.toString();
    output.addValue(retval);
}

// def void getTotalFreight(String[] freight, Output output, MappingContext context) {
//     int total=0;
//     for(int i=0;i<freight.length;i++) {
//         try{
//             BigDecimal val = new BigDecimal(getNegativeNormal(freight[i]));
//             val /= 100;
//             total = total + (int)val;
//         } catch(Exception e) {
//             //ignore
//         }
//     }
//     def retval = new Integer(total).toString();
//     output.addValue(retval);
// }

def String getExemptionCodeListWithExemptPercent(String grossAmount, String exemptAmount) {
    grossAmount = getNegativeNormal(grossAmount);
    exemptAmount = getNegativeNormal(exemptAmount);
    int currencyDecimalInt = 2;
    int currencyDecimalVal = 100;
    try{
        String currencyDecimalStr = getExchangeProperty("exchageCurrencyDecimal",context);
        currencyDecimalInt = Integer.parseInt(currencyDecimalStr.trim());
        currencyDecimalVal = Math.pow(10,currencyDecimalInt);
    } catch(Exception e){
        
    }
    Long exemptAmt = Long.valueOf(exemptAmount) / currencyDecimalVal;
    if (exemptAmt == 0) {
        return "00";
    } else {
        Long grossAmt = Long.valueOf(grossAmount) / currencyDecimalVal;
        float exemptPercent = Math.abs((exemptAmt / grossAmt));
        return "06:" + exemptPercent.toString();
    }    
}

def String getNegativeNormal(String inVal) {
    if(inVal == null)
        return "";
    String tVal = inVal.trim();
    if (tVal[tVal.length()-1].equals("-")) {
        return "-" + tVal.substring(0, tVal.length()-1);
    }
    
    return tVal;
}

def String getExemptionReasonCode(String exemptReason, String externalizedExemptCode) {
    
    //Default is 12 other
    String returnExemptionReason = "12";
    if(exemptReason != null && !exemptReason.trim().isEmpty() && EXEMPT_CODE_MAP.containsKey(exemptReason.trim())) {
        returnExemptionReason = exemptReason;
    } else if(externalizedExemptCode!= null && !externalizedExemptCode.trim().isEmpty() && EXEMPT_CODE_MAP.containsKey(externalizedExemptCode.trim())) {
        returnExemptionReason = externalizedExemptCode;
    } 
    return returnExemptionReason;
}
