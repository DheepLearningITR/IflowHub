import com.sap.it.api.mapping.*;
import java.util.*

def String getTaxRate(String taxRate,String numberOfTaxes,String numberOfGroups) {
     int groupCount = (int)(new BigDecimal(numberOfGroups));
     int taxCount = (int)(new BigDecimal(numberOfTaxes));
     BigDecimal val = new BigDecimal(taxRate);
     if(groupCount >1){
         //that means freight is present, so get the factor
         
         //we got those many
         val = val/groupCount;
     }
     return val;
}

def String getTaxAmount(String taxAmount,String taxes,String numberOfGroups) {
    int groupCount = (int)(new BigDecimal(numberOfGroups));
    int taxCount = (int)(new BigDecimal(taxes));
    int countOfGroupTax = 1;
    BigDecimal val = new BigDecimal(taxAmount);
    countOfGroupTax = taxCount/groupCount;
    val = val/countOfGroupTax;
    return val;
}

def String getExemptAmount(String exemptAmount, String numberOfTaxes, String numberOfGroups) {
    int groupCount = (int)(new BigDecimal(numberOfGroups));
    int taxCount = (int)(new BigDecimal(numberOfTaxes));
    int countOfGroupTax = 1;
    BigDecimal val = new BigDecimal(exemptAmount);
    countOfGroupTax = taxCount/groupCount;
    val = val/countOfGroupTax;
    return val;
}

def String getNegativeSapFormat(String inVal) {
    if(inVal == null)
        return "";
    String tVal = inVal.trim();
    if (tVal[0].equals("-")) {
        return tVal.substring(1, tVal.length()) + "-";
    }
    
    return tVal;
}

def String getAmountasInt(String arg1){
    // return (int)(new BigDecimal(arg1)); 
    int intVal = (int)(new BigDecimal(arg1));
    return getNegativeSapFormat(intVal+"");
}

def String getTAType(String suretaxauth)
{
    //<TaxTypeCode>10101|12004||EX|99|All Taxes Exempt – Apply no tax or fees|||</TaxTypeCode>
    def tokens = inputString.split("\\|");
    def TaxAuth = "";
    if(tokens != null && tokens.size() >=1 )
    {
       TaxAuth = tokens[0].trim();
    }
    if(!TaxAuth.isEmpty() && TaxAuth.length >= 3) {
       TaxAuth = TaxAuth.substring(0, 3);
    }
    return TaxAuth;
    
}

def String getExemptCode(String suretaxauth)
{
    //<TaxTypeCode>10101|12004||EX|99|All Taxes Exempt – Apply no tax or fees|||</TaxTypeCode>
    def exemptCode = "";
    def tokens = inputString.split("\\|");
    if (tokens != null && tokens.size() >= 5) {
        exemptCode = tokens[4].trim();
    }
    
    return exemptCode;
    
}
def String getCurrencyDecimalValue(String propertyName,MappingContext context) {
    int currencyDecimalInt = 2;
    int currencyDecimalVal = 100;
    String currencyDecimalStr = context.getProperty(propertyName);
    currencyDecimalInt = Integer.parseInt(currencyDecimalStr);
    currencyDecimalVal = Math.pow(10,currencyDecimalInt);
    return ""+currencyDecimalVal;
    
}