import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;


def void generateTaxAmountNodes(String[] taxAmount,Output result,MappingContext context) 
{
    BigDecimal amount = 0.0;
    for(int i=0;i<taxAmount.length;i++) {
        amount = amount + new BigDecimal(taxAmount[i]);
    }
    
    for(int i=0;i<taxAmount.length;i++) {
        if(i==0) {
            result.addValue((int)(amount*100));
        } else {
            result.addValue("");
        }}

}



def void generateTaxRateNodes(String[] taxRate,Output result,MappingContext context) 
{
    BigDecimal rate = 0.0;
    for(int i=0;i<taxRate.length;i++) {
        rate =rate + new BigDecimal(taxRate[i]);
    }
    
    for(int i=0;i<taxRate.length;i++) {
        if(i==0) {
        // this is multiplied twice because we need to tax rate in pct and then SAP the last three digits are decimals
            result.addValue((int)(rate*100000));
        }
        else {
            result.addValue("");
        }}
}

def void multiplyAndConvertToInt(Double amount,Output result,MappingContext context) {
    
    output.addValue((int)(100*amount));
}


