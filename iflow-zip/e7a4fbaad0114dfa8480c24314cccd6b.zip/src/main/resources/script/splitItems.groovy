import com.sap.gateway.ip.core.customdev.util.Message;
import static java.util.Calendar.*;
import java.util.Locale.*;
import java.text.SimpleDateFormat;
import groovy.util.XmlSlurper;
import groovy.xml.QName;
import groovy.xml.XmlUtil;

def Message processData(Message message) {    
    def body = message.getBody(java.lang.String) as String;
    def xml = new XmlSlurper().parseText(body.trim());
    
    def oldItems = new XmlParser().parseText(XmlUtil.serialize(xml.ServiceOrder.Item));
    xml.ServiceOrder.Item.clear();
    
    oldItems.each { oldItem ->
        def quantity = oldItem.Quantity.toInteger();
        oldItem.Quantity = '1';
        (1 .. quantity).each() {
            xml.ServiceOrder.Item.add( new XmlParser().parseText(XmlUtil.serialize(oldItem)) );
        }
    }
   
    message.setBody(XmlUtil.serialize(xml));
    return message;
}