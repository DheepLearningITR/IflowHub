import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    //Exception message encoding
    def headers = message.getHeaders();
    def exceptionMessage = headers.get("exceptionMessage");
    message.setHeader("exceptionMessage", exceptionMessage.bytes.encodeBase64().toString())
    
    //Payload encoding
    def properties = message.getProperties();
    def payload = properties.get("payload");
    message.setProperty("payload", payload.bytes.encodeBase64().toString())
    
    def exclusions = ["SAP_MessageProcessingLogID", "SAP_MplCorrelationId", "SAP_PregeneratedMplId"]  
    // Create a copy of the header names so the original map isn't modified during iteration. 
    def headerKeys = new ArrayList(headers.keySet())  
    headerKeys.each { headerName -> 
        if (headerName.startsWith("SAP_") && !(headerName in exclusions)) { 
            def newHeaderName = "original_${headerName}" 
            message.setHeader(newHeaderName, headers[headerName]) 
        } 
    }

    
    return message;
}