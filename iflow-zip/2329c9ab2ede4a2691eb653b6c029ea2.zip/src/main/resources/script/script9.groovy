/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-GB/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-GB/index.html */
import com.sap.gateway.ip.core.customdev.util.Message
import javax.activation.DataHandler
import groovy.xml.MarkupBuilder

// Function to read InputStream into byte[]
def readInputStream(InputStream is) {
    def bufferSize = 8192 // 8 KB buffer size
    ByteArrayOutputStream buffer = new ByteArrayOutputStream()

    byte[] chunk = new byte[bufferSize]
    int bytesRead
    while ((bytesRead = is.read(chunk)) != -1) {
        buffer.write(chunk, 0, bytesRead)
    }

    return buffer.toByteArray()
}


def Message processData(Message message) {
    // Access message body via Reader for streaming
    def body = message.getBody(java.io.Reader)
    def headers = message.getHeaders()
    def properties = message.getProperties()
    message.setProperty("customHeader_DataStoreEntryID",properties.get("entryID"))
    message.setHeader("customX_entryID",properties.get("entryID"))
    
    def attachments = new HashMap<String, DataHandler>(message.getAttachments())

    message.getAttachments().clear()
    message.getAttachmentWrapperObjects().clear()

    //build XML
    def writer = new StringWriter()
    def builder = new MarkupBuilder(writer)
    builder.mkp.xmlDeclaration(version: "1.0", encoding: "utf-8")
    builder.Message {
            'MsgHeader'{
                'RestartQueue'(headers.get("incomingQueue"))
                'EntryID'(properties.get("entryID"))
                'RetryDataStore'(properties.get("retryDataStore"))
                'MaxRetryCount'(properties.get("maxDataStoreRetries"))
                'Error'(headers.get("exceptionMessage"))
            }
        'Payload'(properties.get("payload"))
        if (attachments.size()!= 0){
            'Attachments'{
                attachments.values().each{ attachment ->
                    'Attachment'{
                        'AttachmentName'(attachment.getName())
                        'AttachmentContentType'(attachment.getContentType())
                        //InputStream is returned and not ByteArrayInputStream, hence conversion is needed before base64 encoding
                        def content = attachment.getContent()
                        byte[] bytes
                        if (content instanceof InputStream) {
                            bytes = readInputStream(content)
                        } else if (content instanceof byte[]) {
                            bytes = (byte[]) content
                        } else if (content instanceof String) {
                            bytes = content.getBytes("UTF-8") // or other encoding
                        } else {
                            // fallback, attempt to get content as string then bytes
                            bytes = new byte[0]
                        }
                        def encodedContent = Base64.encoder.encodeToString(bytes)
                        'AttachmentContent'(encodedContent)
                    }
                }
            }
        }
    }
    message.setBody(writer.toString())

    return message
}
