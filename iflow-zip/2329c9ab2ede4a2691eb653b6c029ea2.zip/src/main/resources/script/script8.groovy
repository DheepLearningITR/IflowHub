import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;

def Message processData(Message message) {
    
    //get partnerID, current stage and entryID
    def headers = message.getHeaders()
    def Pid = headers.get("partnerID")
    def pipelineStepID = headers.get("pipelineStepID")
    def entryID = headers.get("customX_entryID");
    
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null)
    if (service == null){
        throw new IllegalStateException("Partner Directory Service not found")
    }
    
    //get interface based maximum number of retries, useable in case in both JMS or DS based restart, if nothing found, set to 3 
    def maxndlvDataStoreRetries = service.getParameter("MaxNDLVDataStoreRetries", pid, String) ?: "3" 
    message.setProperty("maxndlvDataStoreRetries", maxndlvDataStoreRetries)
        
    //get the restartmode from partnerID level
    def restartMode = service.getParameter("restartMode", Pid , String.class)
    
    //if nothing found, set the restartMode to noRestart or if we are in receiver or interface determination stage 
    if (restartMode == null || pipelineStepID == "com.sap.integration.cloud.pipeline.generic.step04.receiver.determination" || pipelineStepID == "com.sap.integration.cloud.pipeline.generic.step05.interface.determination"){
        message.setProperty("restartMode", "noRestart")
    }
    else if (restartMode == "JMS"){
        message.setProperty("restartMode", "JMS")
    }
    else if (restartMode == "DS" && entryID != null){
        def restartCount= entryID.substring(entryID.lastIndexOf("~") + 1)
        message.setProperty("retryDsCount", restartCount)
        message.setProperty("restartMode", "DS")
    }
    else{
        message.setProperty("retryDsCount", "0")
        message.setProperty("restartMode", "DS")
    }

    
    return message;
}
