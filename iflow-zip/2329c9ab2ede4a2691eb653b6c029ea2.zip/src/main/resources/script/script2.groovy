/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-GB/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-GB/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {

    //headers
    def headers = message.getHeaders();
    def properties = message.getProperties()

    //get dynamic configuration entryID header
    def entryID = headers.get("customX_entryID");
    def restartMode = properties.get("restartMode")

    //read headers to construct the entryid pattern <Interface>~<Stage>~<ReceiverOrPlaceholder>~<MplId>~<Timestamp>~<RetryCount>
    def Pid = headers.get("partnerID");
    def receiver = headers.get("SAP_Receiver")
    def mplID = headers.get("SAP_MessageProcessingLogID")
    def timestamp = headers.get("timestamp")

    //check what is the caller if the custom error handling and set stage identifier
    def pipelineStepID = headers.get("pipelineStepID")
    def stage=""
    def stages = [
            "com.sap.integration.cloud.pipeline.generic.step06.outbound.processing": "OB",
            "com.sap.integration.cloud.pipeline.generic.step05.interface.determination": "ID",
            "com.sap.integration.cloud.pipeline.generic.step04.receiver.determination": "RD",
            "com.sap.integration.cloud.pipeline.generic.step02.inbound.processing": "IB"
    ]
    def currentStage= stages[pipelineStepID]
    def knownReceiver = currentStage in ["OB", "ID"]

    //set retry count to starting at 0
    def retryCount = "0"

    //if entryID doesn't exist, create it.         
    if (entryID == null){
        if (restartMode == "DS"){
            if (knownReceiver) { //in case of interface determination or outbound processing, the receiver is known, add it to the entryID
                entryID = Pid + "~" + currentStage + "~" + receiver + "~" + mplID + "~" + timestamp + "~" + retryCount
            }
            else {
                entryID = Pid + "~" + currentStage + "~" + mplID + "~" + timestamp + "~" + retryCount
            }
            message.setHeader("customX_restartMode_DS","true")
        }
        else {
            if (knownReceiver) { //in case of interface determination or outbound processing, the receiver is known, add it to the entryID
                entryID = Pid + "~" + currentStage + "~" + receiver + "~" + mplID + "~" + timestamp
            }
            else {
                entryID = Pid + "~" + currentStage + "~" + mplID + "~" + timestamp
            }

        }
    }
    //if entryID exists, verify if we are in the same stage or a different
    else {
        //retrieve the stage from the entryID
        def firstTilde = entryID.indexOf('~')
        def secondTilde = entryID.indexOf('~', firstTilde + 1)
        def extractedStage = entryID.substring(firstTilde + 1, secondTilde)

        if (currentStage && extractedStage != currentStage)
            stage = currentStage
        else
            stage = extractedStage

        if (restartMode == "DS"){
            //in case of different stage, overwrite the entryID's stage
            //if entryID exist then increase counter by casting to Integer and back to String
            def counterString= entryID.substring(entryID.lastIndexOf("~") + 1)
            int retryCountIncreased = Integer.parseInt(counterString)
            retryCountIncreased++
            message.setProperty("retryCount",retryCountIncreased)

            if (knownReceiver)   {
                entryID = Pid + "~" + stage + "~" + receiver + "~" + mplID + "~" + timestamp + "~" + retryCountIncreased
            }
            else {
                entryID = Pid + "~" + stage + "~" + mplID + "~" + timestamp + "~" + retryCountIncreased
            }
        }
        else {
            //in case of different stage, overwrite the entryID's stage

            if (knownReceiver)   {
                entryID = Pid + "~" + stage + "~" + receiver + "~" + mplID + "~" + timestamp
            }
            else {
                entryID = Pid + "~" + stage + "~" + mplID + "~" + timestamp
            }
        }
    }

    message.setProperty("entryID",entryID)


    return message;

}