import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;

def Message processData(Message message) {
    
    //get job profile name
    def properties = message.getProperties()
    def restartJobProfileName = properties.get("RestartJobProfileName")
    
     //get the restartmode of the restart job
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 
    if (service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }
    def restartMode = service.getParameter("restartMode", restartJobProfileName , String.class);

    if (restartMode == null){
        restartMode = "noRestart"
    }
    
    
     //headers
    def headers = message.getHeaders();
    //check what is the caller if the custom error handling and set stage identifier
    def pipelineStepID = headers.get("pipelineStepID")
    def stage = ""
    
    //in case of failing receiver or interface deternination messages should not go into hot store, only cold store -> hence no restart
    if (pipelineStepID == "com.sap.integration.cloud.pipeline.generic.step05.interface.determination"){
        restartMode = "noRestart" 
    }
    else if (pipelineStepID == "com.sap.integration.cloud.pipeline.generic.step04.receiver.determination"){
        restartMode = "noRestart"
    }
	
    message.setProperty("restartMode", restartMode)
    return message;
}
