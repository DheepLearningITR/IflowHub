import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;


def Message processData(Message message) {
	def body = message.getBody(String.class);
	def parseJSON = new JsonSlurper().parseText(body)
		
	def tenantcode = parseJSON.tenant.code
	def systemname = parseJSON.system.name
	def executionversion = parseJSON.execution.version
	def executiontype = parseJSON.execution.type
	def executionmonitoringstartat = parseJSON.execution.monitoringStartAt.replaceAll(" ","T")
	def executionmonitoringendat = parseJSON.execution.monitoringEndAt.replaceAll(" ","T")
	def executionmonitoringexecutedat = parseJSON.execution.executedAt.replaceAll(" ","T")
	def new_body = ""
	def salida = ""
	
	// Tenants
	
	def artifactsOverviewerror = parseJSON.artifactsOverview.error
	def artifactsOverviewstarted = parseJSON.artifactsOverview.started
	def artifactsOverviewstarting = parseJSON.artifactsOverview.starting
	def artifactsOverviewstopping = parseJSON.artifactsOverview.stopping
	def messageOverviewcompleted = parseJSON.messageOverview.completed
	def messageOverviewerror = parseJSON.messageOverview.error
	def messageOverviewescalated = parseJSON.messageOverview.escalated
	def messageOverviewfailed = parseJSON.messageOverview.failed
	def messageOverviewnumberDays = parseJSON.messageOverview.numberDays
	def messageOverviewprocessing = parseJSON.messageOverview.processing
	def messageOverviewretry = parseJSON.messageOverview.retry
	
	def date = parseJSON.execution.monitoringStartAt;
	message.setProperty("url_date", date.substring(0,10));
	message.setHeader("Content-Type","application/x-ndjson");

	
	new_body = 	"{" +
	"    \"execution.executedAt\": \"" + executionmonitoringexecutedat + "\"," +
	"    \"execution.monitoringEndAt\": \"" + executionmonitoringendat + "\"," +
	"    \"execution.monitoringStartAt\": \"" + executionmonitoringstartat + "\"," +
	"    \"execution.type\": \"" + executiontype + "\"," +
	"    \"execution.version\": \"" + executionversion + "\"," +
	"    \"messageOverview.completed\": " + messageOverviewcompleted + "," +
	"    \"messageOverview.error\": " + messageOverviewerror + "," +
	"    \"messageOverview.escalated\": " + messageOverviewescalated + "," +
	"    \"messageOverview.failed\": " + messageOverviewfailed + "," +
	"    \"messageOverviewp.rocessing\": " + messageOverviewprocessing + "," +
	"    \"messageOverview.retry\": " + messageOverviewretry + "," +
	"    \"messageOverview.numberDays\": " + messageOverviewnumberDays + "," +
	"    \"artifactsOverview.error\": " + artifactsOverviewerror + "," +
	"    \"artifactsOverview.started\": " + artifactsOverviewstarted + "," +
	"    \"artifactsOverview.starting\": " + artifactsOverviewstarting + "," +
	"    \"artifactsOverview.stopping\": " + artifactsOverviewstopping + "," +
	"    \"system.name\": \"" + systemname + "\"," +
	"    \"tenant.code\": \"" + tenantcode + "\"," +
		"}" ;
	def resultJSON = new JsonSlurper().parseText(new_body)
	def jsonFormateado = JsonOutput.toJson(resultJSON)
	salida = salida + "{\"index\":{\"_index\": \"bplus-scpi-overview-" + date.substring(0,10) + "\"}}\r\n" + jsonFormateado + "\r\n"
	
	// Artefactos
	parseJSON.runtimeArtifactsDetail.each{ ra ->
		
		def category = ra.category
		def deployedby = ra.deployedby
		def deployedon =  ra.deployedon.replaceAll(" ","T")
		def id =  ra.id
		def name = ra.name
		def status = ra.status
		def type = ra.type
		def version =  ra.version
		
		new_body = 	"{" +
				"    \"execution.executedAt\": \"" + executionmonitoringexecutedat + "\"," +
				"    \"execution.monitoringEndAt\": \"" + executionmonitoringendat + "\"," +
				"    \"execution.monitoringStartAt\": \"" + executionmonitoringstartat + "\"," +
				"    \"execution.type\": \"" + executiontype + "\"," +
				"    \"execution.version\": \"" + executionversion + "\"," +
				"    \"runtimeArtifactsDetail.category\": \"" + category + "\"," +
				"    \"runtimeArtifactsDetail.deployedby\": \"" + deployedby + "\"," +
				"    \"runtimeArtifactsDetail.deployedon\": \"" + deployedon + "\"," +
				"    \"runtimeArtifactsDetail.id\": \"" + id + "\"," +
				"    \"runtimeArtifactsDetail.name\": \"" + name + "\"," +
				"    \"runtimeArtifactsDetail.status\": \"" + status + "\"," +
				"    \"runtimeArtifactsDetail.type\": \"" + type + "\"," +
				"    \"runtimeArtifactsDetail.version\": \"" + version + "\"," +
				"    \"system.name\": \"" + systemname + "\"," +
				"    \"tenant.code\": \"" + tenantcode + "\"," +
					"}" ;
		resultJSON = new JsonSlurper().parseText(new_body)
		jsonFormateado = JsonOutput.toJson(resultJSON)
    	salida = salida + "{\"index\":{\"_index\": \"bplus-scpi-artifacts-" + date.substring(0,10) + "\"}}\r\n" + jsonFormateado + "\r\n"

		
	}
	
	
	// Certificates
	parseJSON.certificatesDetail.each{ cd ->
		
		def alias = cd.alias
		def keystoreView = cd.keystoreView
		def keytype =  cd.keytype
		def keysize =  cd.keysize
		def validNotBefore = cd.validNotBefore.replaceAll(" ","T")
		def validNotAfter = cd.validNotAfter.replaceAll(" ","T")
		def serialNumber = cd.serialNumber
		def signatureAlgorithm =  cd.signatureAlgorithm
		def version =  cd.version
		def fingerprintSha1 =  cd.fingerprintSha1
		def fingerprintSha256 =  cd.fingerprintSha256
		def fingerprintSha512 =  cd.fingerprintSha512
		def type =  cd.type
		def owner = cd.owner
		def lastModifiedBy =  cd.lastModifiedBy
		def lastModifiedTime =  cd.lastModifiedTime
		def createdBy =  cd.createdBy
		def createdTime =  cd.createdTime.replaceAll(" ","T")
		def status =  cd.status
		def relatedIflows =  cd.relatedIflows
		
		if ((cd.subjectDN != null) && (!cd.subjectDN.equals("")))
			{
				byte[] decoded_sdn = cd.subjectDN.decodeBase64()
				String decoded = new String(decoded_sdn)
				decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
				cd.subjectDN = decoded
			}
			if ((cd.issuerDN != null) && (!cd.issuerDN.equals("")))
			{
				byte[] decoded_idn = cd.issuerDN.decodeBase64()
				String decoded = new String(decoded_idn)
				decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
				cd.issuerDN = decoded
			}
		
		def subjectDN =  cd.subjectDN
		def issuerDN =  cd.issuerDN

		
		new_body = 	"{" +
				"    \"execution.executedAt\": \"" + executionmonitoringexecutedat + "\"," +
				"    \"execution.monitoringEndAt\": \"" + executionmonitoringendat + "\"," +
				"    \"execution.monitoringStartAt\": \"" + executionmonitoringstartat + "\"," +
				"    \"execution.type\": \"" + executiontype + "\"," +
				"    \"execution.version\": \"" + executionversion + "\"," +
				"    \"certificatesDetail.relatedIflows\": \"" + relatedIflows + "\"," +
				"    \"certificatesDetail.alias\": \"" + alias + "\"," +
				"    \"certificatesDetail.issuerDN\": \"" + issuerDN + "\"," +
				"    \"certificatesDetail.subjectDN\": \"" + subjectDN + "\"," +
				"    \"certificatesDetail.validNotAfter\": \"" + validNotAfter + "\"," +
				"    \"certificatesDetail.validNotBefore\": \"" + validNotBefore + "\"," +
				"    \"system.name\": \"" + systemname + "\"," +
				"    \"tenant.code\": \"" + tenantcode + "\"," +
					"}" ;
		resultJSON = new JsonSlurper().parseText(new_body)
		jsonFormateado = JsonOutput.toJson(resultJSON)
		salida = salida + "{\"index\":{\"_index\": \"bplus-scpi-certificates-" + date.substring(0,10) + "\"}}\r\n" + jsonFormateado + "\r\n"

		
	}
	
	
	// Messages
	parseJSON.messagesDetail.each{ md ->
		
		def messageGuid = md.messageGuid
		def correlationId = md.correlationId
		def applicationMessageId =  md.applicationMessageId
		def applicationMessageType =  md.applicationMessageType
		def logStart = md.logStart.replaceAll(" ","T")
		def logEnd = md.logEnd.replaceAll(" ","T")
		def sender = md.sender
		def receiver =  md.receiver
		def integrationFlowName =  md.integrationFlowName
		def customStatus =  md.customStatus
		def alternateWebLink =  md.alternateWebLink
		def integrationArtifactId =  md.integrationArtifactId
		def integrationArtifactName =  md.integrationArtifactName
		def integrationArtifactType =  md.integrationArtifactType
		def integrationArtifactPackageId =  md.integrationArtifactPackageId
		def integrationArtifactPackageName =  md.integrationArtifactPackageName
		def transactionId =  md.transactionId
		def previousComponentName =  md.previousComponentName
		def localComponentName =  md.localComponentName
		def originComponentName =  md.originComponentName
		def messageSize =  md.messageSize
		
		if ((md.errorDetail != null) && (!md.errorDetail.equals("")))
			{
				byte[] decoded_errorDetail = md.errorDetail.decodeBase64()
				String decoded = new String(decoded_errorDetail)
				decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
				md.errorDetail = decoded
			}
		
		def errorDetail =  md.errorDetail
		
		new_body = 	"{" +
				"    \"execution.executedAt\": \"" + executionmonitoringexecutedat + "\"," +
				"    \"execution.monitoringEndAt\": \"" + executionmonitoringendat + "\"," +
				"    \"execution.monitoringStartAt\": \"" + executionmonitoringstartat + "\"," +
				"    \"execution.type\": \"" + executiontype + "\"," +
				"    \"execution.version\": \"" + executionversion + "\"," +
				"    \"messagesDetail.alternateWebLink\": \"" + alternateWebLink + "\"," +
				"    \"messagesDetail.correlationId\": \"" + correlationId + "\"," +
				"    \"messagesDetail.customStatus\": \"" + customStatus + "\"," +
				"    \"messagesDetail.errorDetail\": \"" + errorDetail + "\"," +
				"    \"messagesDetail.integrationArtifactId\": \"" + integrationArtifactId + "\"," +
				"    \"messagesDetail.integrationArtifactName\": \"" + integrationArtifactName + "\"," +
				"    \"messagesDetail.integrationArtifactPackageId\": \"" + integrationArtifactPackageId + "\"," +
				"    \"messagesDetail.integrationArtifactPackageName\": \"" + integrationArtifactPackageName + "\"," +
				"    \"messagesDetail.integrationArtifactType\": \"" + integrationArtifactType + "\"," +
				"    \"messagesDetail.integrationFlowName\": \"" + integrationFlowName + "\"," +
				"    \"messagesDetail.localComponentName\": \"" + localComponentName + "\"," +
				"    \"messagesDetail.logEnd\": \"" + logEnd + "\"," +
				"    \"messagesDetail.logStart\": \"" + logStart + "\"," +
				"    \"messagesDetail.messageGuid\": \"" + messageGuid + "\"," +
				"    \"messagesDetail.originComponentName\": \"" + originComponentName + "\"," +
				"    \"messagesDetail.previousComponentName\": \"" + previousComponentName + "\"," +
				"    \"messagesDetail.transactionId\": \"" + transactionId + "\"," +
				"    \"system.name\": \"" + systemname + "\"," +
				"    \"tenant.code\": \"" + tenantcode + "\"," +
					"}" ;
		resultJSON = new JsonSlurper().parseText(new_body)
		jsonFormateado = JsonOutput.toJson(resultJSON)
		salida = salida + "{\"index\":{\"_index\": \"bplus-scpi-messages-" + date.substring(0,10) + "\"}}\r\n" + jsonFormateado + "\r\n"		
	}

	
	salida = salida + "\r\n"
	
	message.setBody(salida)
	return message;
}