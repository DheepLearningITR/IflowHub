import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;


def Message processData(Message message) {

	def body = message.getBody(String.class);
	def request = message.getProperties().get('requestBody');
	
	def removeHeader = 'xml version="1.0" encoding="UTF-8"';
	def blunk = '';
	body = body.replaceAll("<\\?$removeHeader\\?>", "$blunk");
	
	// merge content
	def endTag = "</shopOrderCompleteRequest>";
	def replaceContent = "$body" + "$endTag";
	request = request.replaceAll("$endTag", "$replaceContent");
	
	message.setBody(request);
	return message;
}