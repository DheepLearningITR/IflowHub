import com.sap.gateway.ip.core.customdev.util.Message;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;


def Message processData(Message message) {

    def body = message.getBody(String.class);
  
    def root_name = 'xmlns="http://sap.com/xi/ME/erpcon"';
    def new_root_name = 'BAPI_PRODORDCONF_CREATE_TT';
    body = body.replaceAll("$root_name", "");
 
    message.setBody(body);
    
    return message;
 }