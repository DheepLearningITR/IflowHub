import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message extractDataWithCleansing(Message message) {


    def body = message.getBody(String.class)

    def jsonSlurper = new JsonSlurper()
    def json = jsonSlurper.parseText(body)

    def finalBody

    if (json.record instanceof List){

        finalBody = json

    } else {
        finalBody = [json]

    }
    finalBody = finalBody?.findAll{it}
    message.setBody(JsonOutput.toJson(finalBody))

    return message
}

def Message setConditionRecordField(Message message) {
    String key = message.getProperty("key")

    message.setProperty("conditionRecordKey", message.getProperty(key));
    
    return message;
}

def Message setApplicationField(Message message) {
    String key = message.getProperty("key")

    message.setProperty("applicationKey", message.getProperty(key));
    
    return message;
}

Message countReturned(Message message){
    def body = message.getProperty("jsonArraySize") as String
    
    if (body?.isNumber()){
        message.setProperty("totalReturned",""+(Integer.parseInt(message.getProperty("totalReturned"))+ Integer.parseInt(body)))
        
    }
    
    return message
}