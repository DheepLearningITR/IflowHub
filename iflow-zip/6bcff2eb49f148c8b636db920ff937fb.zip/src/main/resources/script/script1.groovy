/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory; 
import com.sap.it.api.securestore.SecureStoreService; 
import com.sap.it.api.securestore.UserCredential; 
import java.util.Calendar.*;
import groovy.xml.*;
import groovy.json.JsonSlurper

def Message SetProperty(Message message) {
       //Properties 
       def map = message.getProperties();
       def value = map.get("MessageId");
       def log = map.get("EnableAttachments") as String;
       def id = map.get("ConversationId");
       def messageLog = messageLogFactory.getMessageLog(message);
       def pool = ['a'..'z','A'..'Z',0..9,'-'].flatten()
       def Random rand = new Random(System.currentTimeMillis())
       def RandomChars = (0..35).collect { pool[rand.nextInt(pool.size())] }
       def MessageID = RandomChars.join()
       message.setProperty("MessageId", MessageID);

       //set StatusSignal
       def statusSignal = map.get("StatusSignal");
       if(statusSignal == "") { message.setProperty("StatusSignal", "ARISSUE") }
       
       def now = new Date()
       message.setProperty("RequestTime", now.format("yyyyMMdd", TimeZone.getTimeZone('Asia/Seoul'))); 
       
       def body = message.getBody(java.lang.String) as String;       
       def Sender = map.get("SendComRegno") as String;
       def documentid = map.get("ConversationId") as String;
       
       Sender = documentid.substring(0,10);
       
       def email = map.get("Email") as String;
       message.setProperty("Email", email);
     
       def service = ITApiFactory.getApi(SecureStoreService.class, null); 
       def CredentialName = "edoc_kr_smartbill_token_"+Sender;
       def credential = service.getUserCredential(CredentialName ); 
       if (credential == null){ throw new IllegalStateException("No credential found for alias" + CredentialName ); }
       String token = new String(credential.getPassword()); 
      
       message.setProperty("SendComRegno", Sender);
       message.setProperty("AuthToken", token);
       
       if(log == 'X')
       {messageLog.addAttachmentAsString(id+'_send2smartbill_xml', body, "text/plain");}

       return message;
       
}

def Message Logmessage(Message message) {
    
    def map = message.getProperties();
    def id = map.get("ConversationId");
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def log = map.get("EnableAttachments") as String;

    
    if(log == 'X')
       {messageLog.addAttachmentAsString(id+'_request_xml', body, "text/plain");}
    

    return message;
}


def Message SetStatus(Message message) {
    def map = message.getProperties();
    def id = map.get("ConversationId");
    def log = map.get("EnableAttachments") as String;
    def send = map.get("SendComRegno") as String;
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body);
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
    def Signal = object.Signal as String;
    message.setProperty("signal",Signal);
    def now = new Date()
    message.setProperty("responsetime", now.format("yyyyMMdd", TimeZone.getTimeZone('Asia/Seoul'))); 
    
    def Resultmessage = object.ResultMessage as String;
    Resultmessage = Resultmessage.replaceAll("<","&lt;");
    Resultmessage = Resultmessage.replaceAll(">","&gt;");
    
    message.setProperty("resultmessage",Resultmessage);
    def Edoc_status = object.ResultCode as String;
    
    if(Edoc_status=='30000'){
         message.setProperty("resultCode", '05');
         if( log == 'X')
                 {messageLog.addAttachmentAsString(id+'_success_reponse', body, "text/plain");}
    }else{
         message.setProperty("resultCode", '02');
         if( log == 'X')
                 {messageLog.addAttachmentAsString(id+'_failed_reponse', body, "text/plain");}
    }
   
    return message;
}