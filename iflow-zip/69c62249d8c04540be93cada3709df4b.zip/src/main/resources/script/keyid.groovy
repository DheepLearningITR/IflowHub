import com.sap.gateway.ip.core.customdev.logging.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

import org.apache.commons.codec.binary.Base64;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;


import com.sap.it.api.keystore.KeystoreService;
import java.security.KeyStore;
import java.security.Key;
import java.security.KeyPair;
import java.security.cert.Certificate;

import java.security.cert.CertPathBuilder;
import java.security.cert.CertStore;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.PKIXBuilderParameters;
import java.security.cert.PKIXCertPathBuilderResult;
import java.security.cert.X509Certificate;
import java.security.cert.X509CertSelector;

import javax.net.ssl.*;
import java.security.SecureRandom;


def Message processData(Message message) {

      
// Get certificate name using configuration details 	
	def CertificateName = message.getProperties().get('CertificateName');
	 
// Get certificate from keystore	 
	 def service = ITApiFactory.getApi(KeystoreService.class, null);
     Certificate cert = service.getCertificate(CertificateName);
// Write to properties - for information	 
	 message.getProperties().put('cert',cert);
	 message.getProperties().put('cert-class',cert.getClass());
	 message.getProperties().put('cert-class-name',cert.getClass().getName());

	 
	 def serial =  cert.getSerialNumber();
// write to properties - for information	 
	 String serialHex = serial.toString(16);
	 message.getProperties().put('serial',serial);
	 message.getProperties().put('serialHex',serialHex);
	 
// Certificate in bytes	 
	 byte[] cert_bytes = cert.getEncoded();
// certificate as a base64 encoded string	 
	 byte[] encodedBytes = Base64.encodeBase64(cert_bytes);
	 
// concatenate strings to form signing string
// write to header 	 
	 message.getProperties().put('keyId',new String(encodedBytes));

	return message;

}
