import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    //Body 
    def map = message.getProperties();
    def ex = map.get("CamelExceptionCaught");
    def errorMessage=ex.getResponseBody();
    message.setBody(errorMessage);
    return message;
}