import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def body = message.getBody(java.lang.String) as String;
    message.setProperty("responseBody",body);
    if(body == "CSRF token validation failed"){
        message.setProperty("tokenEnable","false");
    }else{
        message.setProperty("tokenEnable","true");
    }

    return message;
}