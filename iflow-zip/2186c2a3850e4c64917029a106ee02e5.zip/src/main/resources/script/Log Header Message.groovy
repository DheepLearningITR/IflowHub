import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    
    StringBuilder builder = new StringBuilder()
    def headers = message.getHeaders()
    def messageLog = messageLogFactory.getMessageLog(message)
    
    headers.each { key, value -> builder << "${key}=${value}\n" 
        if(key == 'x-csrf-token')
            message.setProperty('token',value);
            
        // if(key=='cookie')
        //     message.setProperty('cookie',value);
            
        if(key=='APIKey')
            message.setProperty('APIKey',value);
    }
    messageLog.addAttachmentAsString("Incoming message headers", builder.toString(), "text/plain")
    
    return message

}