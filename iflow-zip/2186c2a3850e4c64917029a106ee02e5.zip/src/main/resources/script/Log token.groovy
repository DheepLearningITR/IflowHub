import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    
    StringBuilder builder = new StringBuilder()
    def headers = message.getHeaders()
    def messageLog = messageLogFactory.getMessageLog(message)
    String body = message.getBody(java.lang.String) as String;
    def map = message.getProperties();
    def token=map.get("token");
    def action=map.get("action");
    def logType=map.get("logType");
    def logName=action+"_"+token+"_"+logType
    messageLog.addAttachmentAsString(logName,body, "text/plain")
    
    return message

}