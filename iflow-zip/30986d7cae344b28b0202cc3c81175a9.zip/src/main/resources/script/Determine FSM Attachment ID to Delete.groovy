import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    
    def body = message.getBody(String) as String
    def xml = new XmlSlurper().parseText(body)

    def S4_Attachment_IDs = message.getProperty("S4_Attachment_IDs")
    def Read_S4_Attachment_IDs = new JsonSlurper().parseText(S4_Attachment_IDs)
    def S4ExternalIds = Read_S4_Attachment_IDs.collect { it.externalId }
    def xmlExternalIds = xml.data.collect { it.at.externalId.text() }.findAll { it }

    def deleteJsonList = xmlExternalIds.findAll { !S4ExternalIds.contains(it) }
                                   .collect { [externalId: it] }

    if (deleteJsonList.isEmpty()) {
        message.setProperty("DeleteAttachments", "NOTHING_TO_DELETE")
        message.setBody("[]")
    } else {
        message.setBody(JsonOutput.toJson(deleteJsonList))
    }

    return message
}
