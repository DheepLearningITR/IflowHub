import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.MarkupBuilder;
import groovy.xml.*;
import groovy.json.JsonOutput;
import java.util.HashMap;
import java.io.StringWriter;

Message processData(Message message) {

    def body = message.getBody(String) as String
    def ReadPayload = new XmlSlurper().parseText(body)

    def ServiceCallDTO = message.getProperty("ServiceCallDTO")
    def ItemDTO = message.getProperty("ItemDTO")
    def OriginalPayload = message.getProperty("OriginalPayload")

    def ServiceOrderID = [] as Set
    def ItemID = [] as Set
    def attachmentExternalIds = [] as List

    ReadPayload.AttachmentDetails.each { attachment ->
        def objectType = attachment.object?.objectType?.text()
        def objectId = attachment.object?.objectId?.externalId?.text()
        def attachmentExternalId = attachment?.externalId?.text()

        if (attachmentExternalId) {
            attachmentExternalIds << attachmentExternalId
        }
        
    }

    def S4externalIdList = JsonOutput.toJson(
        attachmentExternalIds.collect { [externalId: it] }
    )

    message.setProperty("S4_Attachment_IDs", S4externalIdList)

    def writer = new StringWriter()
    def builder = new MarkupBuilder(writer)
    
    def InputPayload = new XmlSlurper().parseText(OriginalPayload)
        def ServiceOrderIdValue = InputPayload?.externalId?.text()
        if (ServiceOrderIdValue) {
            ServiceOrderID << ServiceOrderIdValue
        }

        InputPayload?.activities?.each { activity ->
            def itemId = activity?.externalId?.text()
            if (itemId) {
                ItemID << itemId
            }
        }

    builder.root {
        PrepareQuery {
            Query("SELECT at.externalId, at.id FROM Attachment at JOIN ServiceCall sc ON at.object.objectId = sc.id WHERE at.externalId IS NOT NULL AND sc.externalId IN (${ServiceOrderID.collect { "'${it}'" }.join(", ")})")
            DTOversion(ServiceCallDTO)
        }
        PrepareQuery {
            Query("SELECT at.externalId, at.id FROM Attachment at JOIN Activity sc ON at.object.objectId = sc.id WHERE at.externalId IS NOT NULL AND sc.externalId IN (${ItemID.collect { "'${it}'" }.join(", ")})")
            DTOversion(ItemDTO)
        }
    }

    message.setBody(writer.toString())
    return message
}
