import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message){
    def map = message.getProperties()
    def attachmentMsg = map.get("OriginalPayload").toString();
    def attachmentXml = new XmlSlurper().parseText(attachmentMsg);
    def RespFSMActivityCode = map.get("RespFSMActivityCode");
    def ActivityExternalID;
    
    attachmentXml?.activities.each { act ->
        if(act.fsmactivitycode == RespFSMActivityCode){
            ActivityExternalID = act.externalId
        }
    }
    
    message.setProperty("ActivityExternalID",ActivityExternalID)
    

  return message;
}