import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;


def Message processData(Message msg) {
    def helperValMap = ITApiFactory.getApi(ValueMappingApi.class, null)
    def properties = msg.getProperties();

    def input = properties.get('sender_logsys');
    def url = helperValMap.getMappedValue('SAP', 'sender_logsys', input , 'GK', 'binding_url_idoc');
    def credentials = helperValMap.getMappedValue('SAP', 'sender_logsys', input , 'GK', 'credentials_id_idoc');
    def cloudconnectionid = helperValMap.getMappedValue('SAP', 'sender_logsys', input , 'GK' , 'cloud_connector_id_idoc');
    msg.setProperty( 'binding_url', url );
    msg.setProperty( 'credentials_id', credentials);
    msg.setProperty( 'cloud_connector_id', cloudconnectionid);
	return msg;
	
}