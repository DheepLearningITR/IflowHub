import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){

		def po_number = message.getHeaders().get("PONumber");
		if(po_number!=null){
			messageLog.addCustomHeaderProperty("po", po_number);
        }
	}
	return message;
}
