import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    message.setBody('{\"query\":\"query getToken{ token(username: \"test_sapcc_9538", password: \"5e56f60cd\", clientId: \"71_2xgiwioe808wc4s8408g8coos8wkkcg8888k0w0k8ksoc4k40o\", clientSecret: \"36mcvzyn3xmo044wkkokwgc0wc8gkc4844k8o80ksk8so84wgw\") { data { accessToken } }}\"}')
    return message;
}