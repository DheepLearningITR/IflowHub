import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) { 
    
    //Constants
    String ERROR = "Error";
    String PLAIN_TEXT = "text/plain";
    String CAMEL_EXCEPTION_CAUGHT = "CamelExceptionCaught";
    
    def map  = message.getProperties();
    def body = message.getBody(String);
    
    def ex = map.get(CAMEL_EXCEPTION_CAUGHT);
    if (ex != null) {
        exceptionText = ex.getMessage();
        def messageLog = messageLogFactory.getMessageLog(message);
        if (messageLog != null) {
	        messageLog.addAttachmentAsString(ERROR, exceptionText, PLAIN_TEXT);
	    }
    } else {
        def messageLog = messageLogFactory.getMessageLog(message);
    	if (messageLog != null) {
    	    messageLog.addAttachmentAsString(ERROR, body, PLAIN_TEXT);
    	}   
    }
	
    return message;
}