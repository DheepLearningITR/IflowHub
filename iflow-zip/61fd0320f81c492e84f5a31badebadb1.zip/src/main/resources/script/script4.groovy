import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.json.JsonBuilder

def Message processData(Message message) {
    
    //Constants
    String UTF8 = "UTF-8";
    
    //Body
    def body = message.getBody();
    def slurper = new JsonSlurper();
    def responseData = slurper.parse(body);
    
    def jsonData = responseData;
    
    jsonData = responseData.data.categories;
    
    if(jsonData) {
        def jsonBuilder = new JsonBuilder();
        def json = jsonBuilder{
            "items" jsonData.items;
        }
        
        message.setBody(JsonOutput.toJson(json).getBytes(UTF8))
    }
    
    return message;
}