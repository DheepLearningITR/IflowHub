import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {
    
    //Constants
    String X_PIM_TOKEN = "X-PIM-TOKEN";

    def slurper = new JsonSlurper();
    
    if(!message.getBody(String).isEmpty()){
        def body = slurper.parseText(message.getBody(String));
        
        def json = message.getBody(java.io.Reader);
        def reponseData  = new JsonSlurper().parse(json);
        
        message.setHeader(X_PIM_TOKEN, reponseData.data.token.data.accessToken);
    }
    
    return message;
}