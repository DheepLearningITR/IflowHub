import com.sap.gateway.ip.core.customdev.util.Message;

Message processData(Message message) {

	def body = message.getBody(java.io.Reader);
	def root = new XmlSlurper().parse(body);
	
	// BAPI Part
	def errItems = root.Name.findAll { it -> it.text().matches("SELECTED_SET_NOT_FOUND") };
	
	def errText;
	if(message.getProperties().get("CamelExceptionCaught") == null){
	    errText = "";
	}else{
	    //extract previous CamelExceptionCaught format like '-----BAPI errors begin-----', or we negelect it
	    def exceptionMessage = message.getProperties().get("CamelExceptionCaught").toString();  
	    if(exceptionMessage.lastIndexOf("-----BAPI errors begin-----") < 0){
	        errText = "";
	    }else{
	        errText = exceptionMessage.substring(exceptionMessage.lastIndexOf("-----BAPI errors begin-----")+1);
	    }
	}
	
	if (errItems.size() != 0) {
		errText += "\r\n-----BAPI errors begin-----\r\n";
		errText += errItems.TEXT.join(";\r\n");
		errText += "\r\n-----BAPI errors end-----\r\n";
	}
	
	//possible exeption
	errItems = root.findAll { it -> it.name().endsWith(".Exception") };
	if(errItems.size() != 0) {
	  errItems.each{
	    errText += "\r\n-----BAPI errors begin-----\r\n";
		  errText += it.text();
		  errText += "\r\n-----BAPI errors end-----\r\n";
	  }
	}
	
	message.getProperties().put("CamelExceptionCaught", errText);
	
	return message;
}