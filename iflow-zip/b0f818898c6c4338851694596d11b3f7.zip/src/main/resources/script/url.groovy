/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
		var body = message.getBody();
		message.setBody("redirect_uri=https://cd3gbp1-hcioem.hci.int.sap.hana.ondemand.com/http/return&grant_type=authorization_code&" + ${header.CamelHttpQuery} );
		// Get the OAuth token value from the properties
		def map = message.getProperties();
		//def token = map.get("token");
		//def myCookie = map.get("cookie");
		// Remove the Consumer key from previous header
		map = message.getHeaders();
		
		map.remove("X-ConsumerKey");
		// Set the OAuth authorization credentials
		
		message.setHeader("Authorization", "Basic " + 'SAP:SAPID'.bytes.encodeBase64().toString()); 
		message.setHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
		//message.setHeader("Cookie", "OAUTH_SESSION_ID " + myCookie);
		return message;

}