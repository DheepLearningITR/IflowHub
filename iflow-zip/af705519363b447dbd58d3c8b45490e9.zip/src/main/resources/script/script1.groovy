import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
 
    
    def body = message.getBody(java.lang.String) as String;
    body = body.replaceAll("<s:Envelope xmlns:s=", "");
    body = body.replaceAll("\"http://schemas.xmlsoap.org/soap/envelope/\">", "");
    body = body.replaceAll("<s:Body xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">", "");
    //body = body.removeSurrounding("\"");
    body = body.replaceAll("<ns1:Body>", "");
	body = body.replaceAll("</s:Body>", "");
	body = body.replaceAll("</s:Envelope>", "");
	message.setBody(body);
	return message;
}