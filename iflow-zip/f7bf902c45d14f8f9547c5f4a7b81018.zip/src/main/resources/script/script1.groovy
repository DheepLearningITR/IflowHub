import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
	
	//Body 
	
	def messageLog = messageLogFactory.getMessageLog(message);
    def map = message.getHeaders();
    
        def jsonSlurper = new JsonSlurper()

        def js = message.getBody(String).replaceAll("\\r\\n|\\r|\\n", " ")
        
        def fileHeader = map.get("ReportHeaders")

        def jsonSlupRC = jsonSlurper.parseText(js)

        def fileHeader_List = fileHeader.split(",")
        def reportContent =''

        jsonSlupRC.each { eachLine ->
            def fileContentsList = []
            fileHeader_List.eachWithIndex{ String entry, int i ->
                def modEntry = entry.substring(1, entry.length()-1)
                if(!modEntry.contains(".")) {
                    fileContentsList.add(eachLine[modEntry].toString().replaceAll('\\r\\n|\\r|\\n', " ").replaceAll('"',''))
                }
                else
                {
                    //println modEntry
                    def arrayField = modEntry.split("\\.")
                    def arrayField_Evaluation =eachLine
                    arrayField.eachWithIndex{ String entryKeys, int iZ ->
                        arrayField_Evaluation = arrayField_Evaluation[entryKeys]
                    }
                    fileContentsList.add(arrayField_Evaluation.toString().replaceAll("\\r\\n|\\r|\\n", " ").replaceAll('"',''))//.replaceAll('"','')
                }
            }
            def selectClauseFields_P = ''
            fileContentsList.eachWithIndex { def entry, int i ->
                if (i == 0)
                    selectClauseFields_P = selectClauseFields_P + '"' + entry
                else {
                    if (i == (fileHeader_List.size() - 1)) {
                        if (fileHeader_List.size() == 2)
                            selectClauseFields_P = selectClauseFields_P + '","' + entry + '"'
                        else {
                            //println "LAST =>" + entry
                            selectClauseFields_P = selectClauseFields_P + '","' + entry + '"'
                        }
                    } else
                        selectClauseFields_P = selectClauseFields_P + '","' + entry
                }

                if(fileHeader_List.size() == 1)
                    selectClauseFields_P = selectClauseFields_P + '"'

            }
            reportContent = reportContent  + selectClauseFields_P + "\n"
        }

		
	message.setBody(fileHeader + "\n" + reportContent)
	
	messageLog.addAttachmentAsString("#ReportContent",fileHeader + "\n" + reportContent, "text/plain");
		
	return message
				   
}

