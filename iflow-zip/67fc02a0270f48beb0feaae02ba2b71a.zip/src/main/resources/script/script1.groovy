import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import java.util.HashMap

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    message.setHeader('processReceiveEvents', 'N')
    message.setHeader('hasReceiveEvents', 'N')
    message.setHeader('hasReceiveSerialNumberEvents', 'N')
    def configSystemId = message.getProperties().get('systemId')
    def eventPackages =  input['n0:MaterialTraceabilityEventNotificationMessage'].EventPackage

    // Handle Receive Events and Clone each SerialNumber to own Record and add SystemId if missing
    if (eventPackages.ReceiveEvents) {
        message.setHeader('processReceiveEvents', 'Y')
        message.setHeader('hasReceiveEvents', 'Y')
        if (eventPackages.ReceiveEvents instanceof List) {
            eventPackages.ReceiveEvents.each {
                checkAndAddSystemId(it, configSystemId)
            }
        } else {
            checkAndAddSystemId(eventPackages.ReceiveEvents, configSystemId)
        }
    }

    // Handle Receive Events and Clone each SerialNumber to own Record and add SystemId if missing
    if (eventPackages.ReceiveSerialNumberEvents) {
        message.setHeader('processReceiveEvents', 'Y')
        message.setHeader('hasReceiveSerialNumberEvents', 'Y')
        if (eventPackages.ReceiveSerialNumberEvents instanceof List) {
            def receiveSerialNumberEventsArray = []
            eventPackages.ReceiveSerialNumberEvents.each {
                checkAndAddSystemId(it, configSystemId)
                def tempEventMap = it
                if (it.SerialNumbers instanceof List) {
                    def serialNumbers = it.SerialNumbers
                    serialNumbers.each {
                        tempEventMap.SerialNumbers = it
                        receiveSerialNumberEventsArray << tempEventMap.clone()
                    }
                } else {
					receiveSerialNumberEventsArray << tempEventMap
				}
            }
            eventPackages.ReceiveSerialNumberEvents = receiveSerialNumberEventsArray
        } else {
            checkAndAddSystemId(eventPackages.ReceiveSerialNumberEvents, configSystemId)
            def tempEventMap = eventPackages.ReceiveSerialNumberEvents
            def receiveSerialNumberEventsArray = []
            if (eventPackages.ReceiveSerialNumberEvents.SerialNumbers instanceof List) {
                def serialNumbers = eventPackages.ReceiveSerialNumberEvents.SerialNumbers
                serialNumbers.each {
                    tempEventMap.SerialNumbers = it
                    receiveSerialNumberEventsArray << tempEventMap.clone()
                }
                eventPackages.ReceiveSerialNumberEvents = receiveSerialNumberEventsArray
            }
        }
    }

    // ProduceEvent - If CatenaX ID doesn't exist, create a new UUID and add SystemId if missing
    if (eventPackages.ProduceEvents) {
        if (eventPackages.ProduceEvents instanceof List) {
            eventPackages.ProduceEvents.each {
                checkAndAddSystemId(it, configSystemId)
                setKeyAssignments(it, 'CATENA_X_BATCH')
                if (it.Components) {
                    if (it.Components instanceof List) {
                        def components = it.Components
                        components.each {
                            checkAndAddSystemId(it, configSystemId)
                        }
                    } else {
                        checkAndAddSystemId(it.Components, configSystemId)
                    }
                }
            }
        } else {
            checkAndAddSystemId(eventPackages.ProduceEvents, configSystemId)
            setKeyAssignments(eventPackages.ProduceEvents, 'CATENA_X_BATCH')
                if (eventPackages.ProduceEvents.Components) {
                    if (eventPackages.ProduceEvents.Components instanceof List) {
                        def components = eventPackages.ProduceEvents.Components
                        components.each {
                            checkAndAddSystemId(it, configSystemId)
                        }
                    } else {
                        checkAndAddSystemId(eventPackages.ProduceEvents.Components, configSystemId)
                    }
                }
        }
    }

    if (eventPackages.ProduceSerialNumberEvents) {
        if (eventPackages.ProduceSerialNumberEvents instanceof List) {
            eventPackages.ProduceSerialNumberEvents.each {
                checkAndAddSystemId(it, configSystemId)
                if (it.SerialNumbers instanceof List) {
                    def serialNumbers = it.SerialNumbers
                    serialNumbers.each {
                        setKeyAssignments(it, 'CATENA_X_PART')
                        if (it.ComponentSerialNumbers) {
                            if (it.ComponentSerialNumbers instanceof List) {
                                def componentSerialNumbers = it.ComponentSerialNumbers
                                componentSerialNumbers.each {
                                    checkAndAddSystemId(it, configSystemId)
                                }
                            } else {
                                checkAndAddSystemId(it.ComponentSerialNumbers, configSystemId)
                            }
                        }
                    }
                } else {
                    setKeyAssignments(it.SerialNumbers, 'CATENA_X_PART')
                    if (it.SerialNumbers.ComponentSerialNumbers) {
                        if (it.SerialNumbers.ComponentSerialNumbers instanceof List) {
                            def componentSerialNumbers = it.SerialNumbers.ComponentSerialNumbers
                            componentSerialNumbers.each {
                                checkAndAddSystemId(it, configSystemId)
                            }
                        } else {
                            checkAndAddSystemId(it.SerialNumbers.ComponentSerialNumbers, configSystemId)
                        }
                    }
                }
            }
        } else {
            checkAndAddSystemId(eventPackages.ProduceSerialNumberEvents, configSystemId)
            if (eventPackages.ProduceSerialNumberEvents.SerialNumbers instanceof List) {
                def serialNumbers = eventPackages.ProduceSerialNumberEvents.SerialNumbers
                serialNumbers.each {
                    setKeyAssignments(it, 'CATENA_X_PART')
                    if (it.ComponentSerialNumbers) {
                        if (it.ComponentSerialNumbers instanceof List) {
                            def componentSerialNumbers = it.ComponentSerialNumbers
                            componentSerialNumbers.each {
                                checkAndAddSystemId(it, configSystemId)
                            }
                        } else {
                            checkAndAddSystemId(it.ComponentSerialNumbers, configSystemId)
                        }
                    }
                }
            } else {
                setKeyAssignments(eventPackages.ProduceSerialNumberEvents.SerialNumbers, 'CATENA_X_PART')
                    if (eventPackages.ProduceSerialNumberEvents.SerialNumbers.ComponentSerialNumbers) {
                        if (eventPackages.ProduceSerialNumberEvents.SerialNumbers.ComponentSerialNumbers instanceof List) {
                            def componentSerialNumbers = eventPackages.ProduceSerialNumberEvents.SerialNumbers.ComponentSerialNumbers
                            componentSerialNumbers.each {
                                checkAndAddSystemId(it, configSystemId)
                            }
                        } else {
                            checkAndAddSystemId(eventPackages.ProduceSerialNumberEvents.SerialNumbers.ComponentSerialNumbers, configSystemId)
                        }
                    }
            }
        }
    }


    // Handle Deliver Events and add SystemId if missing
    if (eventPackages.DeliverEvents) {
        if (eventPackages.DeliverEvents instanceof List) {
            eventPackages.DeliverEvents.each {
                checkAndAddSystemId(it, configSystemId)
            }
        } else {
            checkAndAddSystemId(eventPackages.DeliverEvents, configSystemId)
        }
    }
    // Handle DeliverSerialNumberEvents Events and add SystemId if missing
    if (eventPackages.DeliverSerialNumberEvents) {
        if (eventPackages.DeliverSerialNumberEvents instanceof List) {
            eventPackages.DeliverSerialNumberEvents.each {
                checkAndAddSystemId(it, configSystemId)
            }
        } else {
            checkAndAddSystemId(eventPackages.DeliverSerialNumberEvents, configSystemId)
        }
    }

    input['n0:MaterialTraceabilityEventNotificationMessage'].EventPackage = eventPackages
    message.setHeader('payload', input)
    def aasJson = new JsonBuilder(input)
    message.setBody(aasJson.toPrettyString())
    return message
}

def checkAndAddSystemId(def event, def configSystemId) {
    // If SystemId is missing in Input, add the configured value
    if(event.SystemID == null || event.SystemID == '') {
        if(configSystemId) {
            event.SystemID = configSystemId
        }
    }
}

def setKeyAssignments(def events, def qualifier) {
    if (events.KeyAssignments) {
        if (!getKeyAssignments(events.KeyAssignments, qualifier)) {
            def keyAssignmentsNode = [:]
            def keyAssignmentsArray = []
            def value = UUID.randomUUID().toString()
            keyAssignmentsArray << events.KeyAssignments
            keyAssignmentsNode.Qualifier = qualifier
            keyAssignmentsNode.Value = value
            keyAssignmentsArray << keyAssignmentsNode
            events.KeyAssignments = keyAssignmentsArray
        }
    } else {
        def keyAssignmentsNode = [:]
        def value = UUID.randomUUID().toString()
        keyAssignmentsNode.Qualifier = qualifier
        keyAssignmentsNode. Value = value
        events.KeyAssignments = keyAssignmentsNode
    }
}

def getKeyAssignments(def keyAssignments, def qualifier) {
    def  res = ""
    if (keyAssignments) {
        if (keyAssignments instanceof List) {
            keyAssignments.each{
                if (it.Qualifier == qualifier) {
                    res = it.Value
                }
            }
	    } else if (keyAssignments.Qualifier == qualifier) {
            res = keyAssignments.Value
        } else {
            res = ''
        }
    } else {
        res = ''
    }
    return res
}
