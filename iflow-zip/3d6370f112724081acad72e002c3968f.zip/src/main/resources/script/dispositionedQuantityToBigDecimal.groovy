import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

Map transformToJson(Message message) {

    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    return json

}

def void updateMessageBody(Message message, Map messageBody) {

    def messageBodyJson = JsonOutput.toJson(messageBody);
    def prettyMessageBody = JsonOutput.prettyPrint(messageBodyJson);

    message.setBody(prettyMessageBody)

}


Message dispositionedQuantityToBigDecimal(Message message) {

    def messageJson = transformToJson(message)
    def materialItems = messageJson.data.materialItem

    materialItems.each { materialItem -> 

        if(materialItem.dispositionedQuantity != null) {
            materialItem.dispositionedQuantity = new BigDecimal(materialItem.dispositionedQuantity);
        }

        if(materialItem.isOutOfSpec != null) {
            materialItem.isOutOfSpec = materialItem.isOutOfSpec.toBoolean()
        }
           
        def materialSubUnits = materialItem.materialSubUnit

        if(materialItem.materialSubUnit != null) {
            materialSubUnits.each { materialSubUnit ->

                if(materialSubUnit.isOutOfSpec != null){
                    materialSubUnit.isOutOfSpec = materialSubUnit.isOutOfSpec.toBoolean()
                }

            }
        }
    }

    updateMessageBody(message, messageJson)

    return message

}