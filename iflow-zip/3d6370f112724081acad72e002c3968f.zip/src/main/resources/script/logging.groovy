import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.ArrayList;
import groovy.json.*;


def void updateMessageBody(Message message, Map messageBody) {

    def messageBodyJson = JsonOutput.toJson(messageBody);
    def prettyMessageBody = JsonOutput.prettyPrint(messageBodyJson);

    message.setBody(prettyMessageBody)

}

def Message addCustomHeaders(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message)
    
	if(messageLog != null) {

		def coiId = message.getProperty("CGTOcoiId")
		
		if(coiId != null) {
			messageLog.addCustomHeaderProperty("coiId", coiId);		
        }
	}
	
	return message
	
}


def getLogginProperty(Message message) {

    String loggingProperty = message.getProperty("Logging");  

    return loggingProperty;

}

def Message logOriginalPayload(Message message) {

    addLoggingAttachment(message, "original")
    
    return message;

}

def Message logMappedPayload(Message message) {

    addLoggingAttachment(message, "mapped")
    
    return message;
    
}

def void addLoggingAttachment(Message message, String step) {

    String logging = getLogginProperty(message);

    if (Boolean.parseBoolean(logging)) {
        
        def messageLog = messageLogFactory.getMessageLog(message);
        String messageBody = message.getBody(String);
        //def messageBodyJson = JsonOutput.toJson(messageBody);
        def prettyMessageBody = JsonOutput.prettyPrint(messageBody);

        print("Message_Payload_${step}")

        messageLog.addAttachmentAsString("Message_Payload_${step}", prettyMessageBody, "application/json");
    }

}