/*
Delay Message for 20 seconds
 */
import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
    
    def sleepTime = Integer.parseInt(message.getProperty("SleepTime"))
    
    sleep(sleepTime * 1000)

    
    return message;
}
