import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import groovy.transform.Field

@Field static final String VM_TARGET_SYSTEM = "TargetSystem";
@Field static final String VM_IDENTIFIER_TARGET_ADDRESS = "Address";
@Field static final String VM_IDENTIFIER_TARGET_LOCATION_ID = "LocationId";
@Field static final String VM_IDENTIFIER_TARGET_CREDENTIAL = "Credential";
@Field static final String VM_IDENTIFIER_TARGET_SAP_CLIENT = "SapClient";
@Field static final String VM_SOURCE_DMC = "DMC";
@Field static final String VM_IDENTIFIER_DMC_PLANT = "Plant";
@Field static final String PROPERTY_ADDRESS = "TargetAddress";
@Field static final String PROPERTY_LOCATION_ID = "locationId";
@Field static final String PROPERTY_CREDENTIAL = "credential";
@Field static final String QUERY_STRING_SAP_CLIENT = "sap-client";
@Field static final String HEADER_DMC_PLANT = "DmcPlant";


@Field static final String EXCEPTION_MESSAGE = "%s is not correctly configured for DM plant %s in HTTP Outbound Processor Config Value Mapping";

Message processData(Message message) {

    String integrationPlant = message.getHeaders().get(HEADER_DMC_PLANT);
    ValueMappingApi vm = ITApiFactory.getService(ValueMappingApi.class, null);
    String address = vm.getMappedValue(VM_SOURCE_DMC, VM_IDENTIFIER_DMC_PLANT, integrationPlant, VM_TARGET_SYSTEM, VM_IDENTIFIER_TARGET_ADDRESS);
    if (address == null) {
        throw new IllegalStateException(String.format(EXCEPTION_MESSAGE, VM_IDENTIFIER_TARGET_ADDRESS, integrationPlant))
    }
    String locationId = vm.getMappedValue(VM_SOURCE_DMC, VM_IDENTIFIER_DMC_PLANT, integrationPlant, VM_TARGET_SYSTEM, VM_IDENTIFIER_TARGET_LOCATION_ID);
    if (locationId == null) {
        throw new IllegalStateException(String.format(EXCEPTION_MESSAGE, VM_IDENTIFIER_TARGET_LOCATION_ID, integrationPlant))
    }
    String credential = vm.getMappedValue(VM_SOURCE_DMC, VM_IDENTIFIER_DMC_PLANT, integrationPlant, VM_TARGET_SYSTEM, VM_IDENTIFIER_TARGET_CREDENTIAL);
    if (credential == null) {
        throw new IllegalStateException(String.format(EXCEPTION_MESSAGE, VM_IDENTIFIER_TARGET_CREDENTIAL, integrationPlant))
    }
    message.setProperty(PROPERTY_ADDRESS, address);
    message.setProperty(PROPERTY_LOCATION_ID, locationId);
    message.setProperty(PROPERTY_CREDENTIAL, credential);

    String sapClient = vm.getMappedValue(VM_SOURCE_DMC, VM_IDENTIFIER_DMC_PLANT, integrationPlant, VM_TARGET_SYSTEM, VM_IDENTIFIER_TARGET_SAP_CLIENT);
    if (sapClient == null || sapClient.isEmpty()) {
        return message;
    }
    //sap client set to the start of query to override possible intentional sap-client
    String sapClientQuery = QUERY_STRING_SAP_CLIENT + "=" + sapClient;
    String httpQuery = message.getHeaders().get("CamelHttpQuery");
    if (httpQuery != null && !httpQuery.isEmpty()) {
        query = sapClientQuery + "&" + httpQuery;
    } else {
        query = sapClientQuery;
    }
    message.setHeader("CamelHttpQuery", query);

    return message;
}


