import com.sap.gateway.ip.core.customdev.util.Message

def Message processData( Message message ) throws Exception {


       mapProps = message.getProperties();
       mapHeaders = message.getHeaders(); 
       String  Mode = mapProps.get("Mode");
       String  Credentials = mapHeaders.get("CredentialName");

if(Credentials == null) { 
    switch(Mode) {            
         case 'PROD': 
            message.setProperty("EndpointAddress", "https://ebill.postfinance.ch/B2BService/B2BServiceCert.svc");
            break; 
         default: 
            message.setProperty("EndpointAddress", "https://ebill-ki.postfinance.ch/B2BService/B2BServiceCert.svc");
            break; 
      }

} else{ 
    switch(Mode) {            
         case 'PROD': 
            message.setProperty("EndpointAddress", "https://ebill.postfinance.ch/B2BService/B2BService.svc");
            break; 
         default: 
            message.setProperty("EndpointAddress", "https://ebill-ki.postfinance.ch/B2BService/B2BService.svc");
            break; 
      }
   
}

	return message;
}
