import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def xmlParser               = new XmlParser();
    String body                 = message.getBody(String.class);
    def batchResponse           = xmlParser.parseText(body);
    def responseParts = batchResponse.batchChangeSetResponse.batchChangeSetPartResponse;
    String statusCode;
    def bErrorOccured = false;

    for (def item in responseParts) {
        statusCode = item.statusCode.text();
        if (statusCode.startsWith("4") == true || statusCode.startsWith("5") == true) {
            if (statusCode == "423") { 
                message.setHeader("CamelHttpResponseCode", 423);
            }
            bErrorOccured = true;
        }
    }
    
    message.setProperty("BatchErrorResponse", body);
    message.setProperty("ErrorInBatchDetected", bErrorOccured);

   return message;
}