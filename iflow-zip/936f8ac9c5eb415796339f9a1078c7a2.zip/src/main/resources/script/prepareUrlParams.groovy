import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	def map = message.getProperties();
	def header = message.getHeaders();
	String property_API_OPTION_PROFILE = map.get("apiOptionProfileID");
	String property_PURGE_TYPE = map.get("purgeType");
	String purgeTypeDefaultValue = "purgeType=record";
	String apiOptionConcat;
	String purgeTypeConcat;
	String fullConcatUrl;
	
	if ((property_API_OPTION_PROFILE=="")||(property_API_OPTION_PROFILE=="<profileID>")) {
		//Keep apiOptionProfile empty
		apiOptionConcat = "";	
	}else {
		apiOptionConcat = "apiOptionProfileID=" + property_API_OPTION_PROFILE;
	}
	
	if ((property_PURGE_TYPE=="")||(property_PURGE_TYPE=="<purgeType>")) {
		//Keep purgeType empty
		purgeTypeConcat = "";	
	}else {
		//Check whether apiOptionProfile is empty to include '&' to the URL
		if (apiOptionConcat.length() > 0){		
			purgeTypeConcat = "&purgeType=" + property_PURGE_TYPE;
		}else {
			purgeTypeConcat = "purgeType=" + property_PURGE_TYPE;
		} 
	}
	
	fullConcatUrl = apiOptionConcat + purgeTypeConcat;
	
	header.put("AdditionalURLParams", fullConcatUrl);	
	return message;
}