import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.gateway.ip.core.customdev.logging.*;

def Message processData(Message message) {
	def odataURI = new StringBuilder();
	def urlDelimiter = "&";
	
	def body = message.getBody(java.lang.String) as String;
	def headers = message.getHeaders() as Map<String, Object>;
	def properties = message.getProperties() as Map<String, Object>;

	def productId = properties.get("productId") as String;
	def skip = properties.get("skip") as Integer;
	def top  = properties.get("top") as Integer;
	def select = properties.get("select") as String;
	
	//Escaping OData special character single quote with two single quotes.
    productId = URLEncoder.encode(productId.replace("'", "''"));
    
 	odataURI.append("\$filter=").append("substringof(Product,'"+productId.toString()+"')");
 	
 	    odataURI.append(urlDelimiter);
 	    
     	odataURI.append("\$select=").append("Product,BaseUnit,to_Description/Product,to_ProductUnitsOfMeasure/Product,to_ProductUnitsOfMeasure/AlternativeUnit,to_Description/Language,to_Description/ProductDescription");
     	
    	odataURI.append(urlDelimiter);
    	
    	odataURI.append("\$expand=").append("to_Description,to_ProductUnitsOfMeasure");
    	
    	odataURI.append(urlDelimiter);
     	
     	odataURI.append("\$skip=").append(skip);
	    
	    odataURI.append(urlDelimiter);
	    
	    odataURI.append("\$top=").append(top);
 	message.setHeader("odataURI",odataURI.toString());
	return message;
}