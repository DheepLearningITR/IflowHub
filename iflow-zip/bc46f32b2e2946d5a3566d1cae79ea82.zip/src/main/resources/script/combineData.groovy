import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.stream.Collectors;
import com.sap.gateway.ip.core.customdev.util.Message;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

class To_Description{
  @JsonProperty("A_ProductDescriptionType")
  List<A_ProductDescriptionType> a_ProductDescriptionType;
}

class A_ProductDescriptionType{
  @JsonProperty("Language")
  String language;
  @JsonProperty("Product")
  String product;
  @JsonProperty("ProductDescription")
  String productDescription;
}

class To_ProductUnitsOfMeasure{
  @JsonProperty("A_ProductUnitsOfMeasureType")
  List<A_ProductUnitsOfMeasureType> a_ProductUnitsOfMeasureType;
}

class A_ProductUnitsOfMeasureType{
  @JsonProperty("Product")
  String product;
  @JsonProperty("AlternativeUnit")
  String alternativeUnit;
}

class CustomStringDeserializer extends JsonDeserializer<String> {

  @Override
  public String deserialize(JsonParser p, DeserializationContext context)
          throws IOException, JsonProcessingException {
    JsonNode node = p.getCodec().readTree(p);

    if (node.isObject() || node.isArray()) {
      return node.toString();
    } else {
      return node.asText();
    }
  }
}

class A_ProductType{
  @JsonProperty("Product")
  @JsonDeserialize(using = CustomStringDeserializer.class)
  String product = null;
  @JsonProperty("BaseUnit")
  String baseUnit = null;

  To_Description to_Description;

  To_ProductUnitsOfMeasure to_ProductUnitsOfMeasure;
}

class Messages{
  @JsonProperty("Message1")
  Message1 message1;
  @JsonProperty("Message2")
  Message2 message2;
}

class Response{
  @JsonProperty("Messages")
  Messages messages;
}

class Message1 {
  @JsonProperty("A_Product")
  A_Product a_Product;
}

class Message2{
  @JsonProperty("A_Product")
  A_Product a_Product;
}
class A_Product {
  @JsonProperty("A_ProductType")
  List<A_ProductType> a_ProductType;
}

def Message processData(Message message) {	
	def body = message.getBody(java.lang.String) as String;
	def headers = message.getHeaders() as Map<String, Object>;
	def properties = message.getProperties() as Map<String, Object>;

    Response response = new ObjectMapper().enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY).enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT).configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false).readValue(body,Response.class);
    List finalList = new ArrayList();
    if(null!=response.getMessages().getMessage2().getA_Product() && null!=response.getMessages().getMessage1().getA_Product()){
        response.getMessages().getMessage2().getA_Product().getA_ProductType().addAll(response.getMessages().getMessage1().getA_Product().getA_ProductType());
        Set<String> nameSet = new HashSet<>();
        finalList = response.getMessages().getMessage2().getA_Product().getA_ProductType().stream().filter {e -> nameSet.add(e.getProduct())}.collect(Collectors.toList());
    }else if(null!=response.getMessages().getMessage1().getA_Product() && null == response.getMessages().getMessage2().getA_Product()) {
        finalList = response.getMessages().getMessage1().getA_Product().getA_ProductType();
    }else if(null!=response.getMessages().getMessage2().getA_Product() && null == response.getMessages().getMessage1().getA_Product()) {
        finalList = response.getMessages().getMessage2().getA_Product().getA_ProductType();
    }
    
    Message1 message1 = new Message1();
    A_Product a_product = null;
    if(!finalList.isEmpty()){
        a_product = new A_Product();
        a_product.setA_ProductType(finalList);
    }
    message1.setA_Product(a_product);
    def newBody = new ObjectMapper().writeValueAsString(message1);

    message.setBody(newBody);
	
	def propertiesAsString ="\n";
	properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };
	
	def enableLog = properties.get("enableLog") as String;
	
	def headersAsString ="\n";
	headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };
	

	def messageLog = messageLogFactory.getMessageLog(message);
    if(enableLog == "true" && messageLog != null){
		messageLog.addAttachmentAsString("Combined Response S/4HANA Response",   "\n Properties \n ----------   \n" + propertiesAsString +
                                                            "\n Headers \n ----------   \n" + headersAsString +
		                                                    "\n Body \n ----------  \n\n" + newBody,
		                                                    "text/xml");
	}
	
	return message;
}
