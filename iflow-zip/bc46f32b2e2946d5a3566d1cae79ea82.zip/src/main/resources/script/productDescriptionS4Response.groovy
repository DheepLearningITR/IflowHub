import groovy.xml.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.DeserializationContext
import com.fasterxml.jackson.databind.DeserializationFeature
import com.fasterxml.jackson.databind.JsonDeserializer
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.annotation.JsonDeserialize

class A_Product {
  @JsonProperty("A_ProductType")
  List<A_ProductType> a_ProductType;
}

class Product {
  @JsonProperty("A_Product")
  A_Product a_Product;
}

class ProductDescription {
  @JsonProperty("A_ProductDescription")
  A_ProductDescription a_ProductDescription;
}

class A_ProductDescription{
  @JsonProperty("A_ProductDescriptionType")
  List<A_ProductDescriptionType> a_ProductDescriptionType;
}

class A_ProductDescriptionType{
  @JsonProperty("Product")
  String product;

  @JsonProperty("Language")
  String language;

  @JsonProperty("ProductDescription")
  String productDescription;
}

class To_ProductUnitsOfMeasure{
  @JsonProperty("A_ProductUnitsOfMeasureType")
  List<A_ProductUnitsOfMeasureType> a_ProductUnitsOfMeasureType;
}

class A_ProductUnitsOfMeasureType{
  @JsonProperty("Product")
  String product;
  @JsonProperty("AlternativeUnit")
  String alternativeUnit;
}

class To_Description{
  @JsonProperty("A_ProductDescriptionType")
  List<A_ProductDescriptionType> a_ProductDescriptionType;
}

class CustomStringDeserializer extends JsonDeserializer<String> {

  @Override
  public String deserialize(JsonParser p, DeserializationContext context)
          throws IOException, JsonProcessingException {
    JsonNode node = p.getCodec().readTree(p);

    if (node.isObject() || node.isArray()) {
      return node.toString();
    } else {
      return node.asText();
    }
  }
}

class A_ProductType{
  @JsonProperty("Product")
  @JsonDeserialize(using = CustomStringDeserializer.class)
  String product;
  @JsonProperty("BaseUnit")
  String baseUnit;

  To_Description to_Description;

  To_ProductUnitsOfMeasure to_ProductUnitsOfMeasure;
}

def Message processData(Message message) {	
	def body = message.getBody(java.lang.String) as String;
	def headers = message.getHeaders() as Map<String, Object>;
	def properties = message.getProperties() as Map<String, Object>;
  String newBody = '{"A_Product":null}';

  ProductDescription productDescription = new ObjectMapper().enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY).enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT).configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false).readValue(body,ProductDescription.class);
  if(null != productDescription.getA_ProductDescription()){
    Map<String,List<A_ProductDescriptionType>> productDescriptionTypeMap = productDescription.getA_ProductDescription().getA_ProductDescriptionType().groupBy { p -> p.product};

    Product product = new Product();
    A_Product a_product = new A_Product();
    List<A_ProductType> aProductTypeList = new ArrayList<>();
    for(Map.Entry<String, List<A_ProductDescriptionType>> entry : productDescriptionTypeMap.entrySet()){
      if(!entry.getKey().toString().isEmpty()){
        List<A_ProductDescriptionType> productDescriptionTypeList = new ArrayList<>();
        for(int i=0;i<entry.getValue().size();i++){
          A_ProductDescriptionType a_ProductDescriptionType = new A_ProductDescriptionType();
          a_ProductDescriptionType.setProduct(entry.getKey());
          a_ProductDescriptionType.setLanguage(entry.getValue().get(i).getLanguage());
          a_ProductDescriptionType.setProductDescription(entry.getValue().get(i).getProductDescription());
          productDescriptionTypeList.add(a_ProductDescriptionType);
        }
        A_ProductType a_productType = new A_ProductType();
        To_Description to_Description = new To_Description();
        to_Description.setA_ProductDescriptionType(productDescriptionTypeList);
        a_productType.setProduct(entry.getKey());
        a_productType.setTo_Description(to_Description);
        aProductTypeList.add(a_productType);
      }
    }
    a_product.setA_ProductType(aProductTypeList);
    product.setA_Product(a_product);

    newBody = new ObjectMapper().writeValueAsString(product);
    
  }
  message.setBody(newBody);
  
	def propertiesAsString ="\n";
	properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };
	
	def enableLog = properties.get("enableLog") as String;
	
	def headersAsString ="\n";
	headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };
	

	def messageLog = messageLogFactory.getMessageLog(message);
    if(enableLog == "true" && messageLog != null){
		messageLog.addAttachmentAsString("Product Description S/4HANA Response",   "\n Properties \n ----------   \n" + propertiesAsString +
                                                            "\n Headers \n ----------   \n" + headersAsString +
		                                                    "\n Body \n ----------  \n\n" + newBody,
		                                                    "text/xml");
	}
	
	return message;
}