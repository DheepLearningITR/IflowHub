import groovy.xml.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;

class A_ProductDescriptionType{
  String Language;
  String Product;
  String ProductDescription;
}

class A_ProductType{
  String Product;
  String BaseUnit;
  List<String> to_Description;
  List<String> to_ProductUnitsOfMeasure;
}

class A_Product {
  List<String> A_ProductType;
}

def Writable pojoToXml( object ) {
  new groovy.xml.StreamingMarkupBuilder().bind {
    "${object.getClass().name}" {
      object.getClass().declaredFields.grep { !it.synthetic }.name.each { n ->
        "$n"( object."$n" )
      }
    }
  }
}

def Message processData(Message message) {	
	def body = message.getBody(java.lang.String) as String;
	def headers = message.getHeaders() as Map<String, Object>;
	def properties = message.getProperties() as Map<String, Object>;

    def aProductDescriptionString = new XmlSlurper().parseText(body);

    Map m = aProductDescriptionString."A_ProductDescriptionType".groupBy({p->p.Product});
    Map<String,List<String>> productDescriptionTypeMap = new HashMap<>();
    for(Map.Entry<String, List<A_ProductDescriptionType>> entry : m.entrySet()){
    if(!entry.getKey().toString().isEmpty()){
      List<String> productDescriptionTypeList = new ArrayList<>();
      for(int i=0;i<entry.getValue().Product.size();i++){
        A_ProductDescriptionType a_productDescriptionType = new A_ProductDescriptionType();
        a_productDescriptionType.Language = entry.getValue().Language.get(i);
        a_productDescriptionType.ProductDescription = entry.getValue().ProductDescription.get(i);
        a_productDescriptionType.Product = entry.getValue().Product.get(i).toString();
        productDescriptionTypeList.add(pojoToXml(a_productDescriptionType).toString());
      }
      productDescriptionTypeMap.put(entry.getKey(),productDescriptionTypeList);
    }
  }

    List<String> aProductTypeList = new ArrayList<>();
    for(Map.Entry<String,List<Writable>> entry : productDescriptionTypeMap.entrySet()){
        A_ProductType a_productType = new A_ProductType(Product: entry.getKey(),BaseUnit: "",to_Description: entry.getValue(),to_ProductUnitsOfMeasure: null);
        aProductTypeList.add(pojoToXml(a_productType).toString());
    }
    String xml = "";
    for(String s: aProductTypeList){
        xml += s;
    }
    xml = "<A_Product>"+xml+"</A_Product>";
    xml = xml.replaceAll('&lt;','<');
    xml = xml.replaceAll('&gt;','>');
    def newBody = xml;
    message.setBody(newBody);
	
	def propertiesAsString ="\n";
	properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };
	
	def enableLog = properties.get("enableLog") as String;
	
	def headersAsString ="\n";
	headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };
	

	def messageLog = messageLogFactory.getMessageLog(message);
    if(enableLog == "true" && messageLog != null){
		messageLog.addAttachmentAsString("S/4HANA Response",   "\n Properties \n ----------   \n" + propertiesAsString +
                                                            "\n Headers \n ----------   \n" + headersAsString +
		                                                    "\n Body \n ----------  \n\n" + newBody,
		                                                    "text/xml");
	}
	
	return message;
}