import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*
import groovy.transform.Field
import groovy.json.*

def recursivelyRemoveEmpties(item) {
  switch(item) {
    case Map:
      return item.collectEntries { k, v ->
        [k, recursivelyRemoveEmpties(v)]
      }.findAll { k, v -> v }

    case List:
      return item.collect { 
        recursivelyRemoveEmpties(it) 
      }.findAll { v -> v }

    default: 
      return item
  }
}

def getrefundingStatus(String refundStatus){
    def refunStatus = ''
    switch(refundStatus){
        case "4":
            refunStatus = "WITH_ERRORS"
            break
        case "3":
            refunStatus = "WAITING_FOR_CREDIT_MEMO"
            break
        case "1":
            refunStatus = "PARTIALLY_PROCESSED"
            break
        case "0":
            refunStatus = "OPEN"
            break
        case "2":
            refunStatus = "COMPLETE"
            break
        default:
            break
    }
    return refunStatus
}

def getCancellationStatus(String cancellationStatus){
    def cancStatus = ''
    switch(cancellationStatus){
        case "A":
            cancStatus = "NOTHING_CANCELLED"
            break
        case "B":
            cancStatus = "PARTIALLY_CANCELLED"
            break
        case "C":
            cancStatus = "EVERYTHING_CANCELLED"
            break
        default: 
            break
    }
    return cancStatus
}

def Message processData(Message message) {
    def s4_body = new XmlParser().parseText(message.getProperty("s4_soap_payload"))
    def header_body = s4_body.MessageHeader
    s4_body = s4_body.CustomerReturn[0]
    def date = new Date();
    JsonBuilder builder = new JsonBuilder();

    def input_body = new XmlParser().parseText(message.getBody(String.class))
    def batch_nodes = input_body.'**'.findAll{it.name() == 'batchQueryPartResponse'}
    def odata_body = batch_nodes[0].body.A_CustomerReturn.A_CustomerReturnType
    def itemCount = 0
    def itemReleaseCount = 0


    def itemList = []
    batch_nodes[1].body.A_CustomerReturnItem.A_CustomerReturnItemType.each{item->
    itemCount = itemCount + 1
        def itemReleStatus = item.RetsMgmtProcessingBlock.text() ? "NOT_RELEASED" : "RELEASED"
        if(itemReleStatus == "RELEASED"){
            itemReleaseCount = itemReleaseCount + 1
        }
        def itemMap = [
            "id" : item.CustomerReturnItem.text(),
            "returnQuantity" : [
                "content" : item.RequestedQuantity.text(),
                "uomCode" : item.RequestedQuantityUnit.text()
            ],
            "rmaNumber" : item.CustRetMatlAuthzn.text(),
            "refundType" : item.ReturnsRefundType.text(),
            "itemReturnReason" : item.ReturnReason.text(),
            "itemRefundingStatus" : getrefundingStatus(item.RetsMgmtItmCompnProcgStatus.text()),
            "itemCancellationStatus" : getCancellationStatus(item.SDDocumentRejectionStatus.text()),
            "itemCancellationReason" : item.SalesDocumentRjcnReason.text(),
            "itemReleaseStatus": itemReleStatus
        ]
        itemList << itemMap 
    }
    
    def headerReleaseCount = "NOT_RELEASED"
    if(itemReleaseCount > 1){
        headerReleaseCount = "PARTIALLY_RELEASED"
        if(itemReleaseCount == itemCount){
        headerReleaseCount = "RELEASED"
    }
        
    }
    
    def appStatus = ''
    switch(odata_body.SalesDocApprovalStatus.text()){
        case 'A':
            appStatus = "IN_APPROVAL"
            break
        case 'C':
            appStatus = "REJECTED"
            break
        case 'B':
            appStatus = "RELEASED"
            break
        case 'D':
            appStatus = "TO_BE_REWORKED"
            break
        default:
            break
    }
    
    def procStatus = ''
    switch(odata_body.RetsMgmtProcessingStatus.text()){
        case "1":
            procStatus = "COMPLETE"
            break
        case "0":
            procStatus = "OPEN"
            break
        case "2":
            procStatus = "WITH_ERRORS"
        default:
            break
    }

    def refunStatus = getrefundingStatus(odata_body.RetsMgmtCompnProcgStatus.text())
    def cancStatus = getCancellationStatus(odata_body.OverallSDDocumentRejectionSts.text())
    
    builder{
        messageHeader{
            id java.util.UUID.randomUUID()
            senderCommunicationSystemDisplayId header_body.SenderBusinessSystemID.text()
            receiverCommunicationSystemDisplayId header_body.RecipientBusinessSystemID.text()
            creationDateTime date.format("yyyy-MM-dd'T'HH:mm:ss'Z'")
        }
         messageRequests ([{
            messageHeader{
                messageEntityName "sap.crm.returnorderservice.entity.returnOrderReplicationMessageIn"
                actionCode "SAVE"
                id java.util.UUID.randomUUID()
            }
            body{
                receiverDisplayId message.getProperty("c4cId")
                displayId s4_body.CustomerReturnID.text()
                businessArea{
                    //salesOrganisationReceiverId(s4_body.SalesOrganization.text())
                    distributionChannel(s4_body.DistributionChannel.text())
                    division(s4_body.OrganizationDivision.text())
                    salesGroupReceiverId(odata_body.SalesGroup.text())
                }
                approvalStatus(appStatus)
                releasedStatus(headerReleaseCount)
                refundingStatus(refunStatus)
                processingStatus(procStatus)
                cancellationStatus(cancStatus)
                documentCurrency(odata_body.TransactionCurrency.text())
                totalValues{
                    netAmount{
                        content(odata_body.TotalNetAmount.text())
                        currencyCode(odata_body.TransactionCurrency.text())
                    }
                }
                items itemList
            }
        }])
    }
    
    def json = new JsonSlurper().parseText(builder.toString());
    json = recursivelyRemoveEmpties(json);
    def outPayload = JsonOutput.prettyPrint(JsonOutput.toJson(json));
    message.setHeader("referenceMessageRequestId",message.getProperty("SAP_ApplicationID"));
    message.setProperty("jsonPayload",outPayload);
    message.setProperty("CustomerReturnId", s4_body.CustomerReturnID.text());
    message.setBody(outPayload)
    return message;
}