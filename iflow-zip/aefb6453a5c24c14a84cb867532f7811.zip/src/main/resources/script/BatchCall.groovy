import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message){
    Node batch_payload = new NodeBuilder().batchParts{}
    def tempNode
	def s4_id = message.getProperty("s4_id")
    
	tempNode = new NodeBuilder().batchQueryPart{
	uri("A_CustomerReturn('" + s4_id + "')")
	}
	batch_payload.append(tempNode)
	
	tempNode = new NodeBuilder().batchQueryPart{
	uri("A_CustomerReturn('" + s4_id + "')/to_Item")
	}
	batch_payload.append(tempNode)
	
	tempNode = new NodeBuilder().batchQueryPart{
	uri("A_CustomerReturn('" + s4_id + "')/to_Partner")
	}
	batch_payload.append(tempNode)
    
    def xml = new XmlParser().parseText(groovy.xml.XmlUtil.serialize(batch_payload))
    String outxml = groovy.xml.XmlUtil.serialize(xml)
    message.setProperty("SAP_BatchLineSeparator","CRLF")
    message.setBody(outxml)
    return message
}