import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message){
	sleep(8000)
	return message;
}