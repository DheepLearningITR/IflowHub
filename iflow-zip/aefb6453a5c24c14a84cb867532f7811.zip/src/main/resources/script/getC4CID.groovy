import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*
import groovy.json.*

def Message processData(Message message) {
    def c4c_body = new JsonSlurper().parseText(message.getBody(String.class))
   
    message.setProperty("c4cId", c4c_body.value.displayId[0])
    return message;
}