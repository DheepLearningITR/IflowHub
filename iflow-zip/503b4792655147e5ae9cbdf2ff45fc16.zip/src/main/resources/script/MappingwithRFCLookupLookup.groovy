import com.sap.it.api.mapping.*;

def void custom_SXIDEMO_AIRL_FLIGHT_CHECKAVAIL_1(String[] i1, String[] i2, Output O1, Output O2, Output O3, MappingContext context) {
  //TODO remove function or fill it interface
  
  /*
 <rfcTempl xmlns="urn:sap-com:xi">
    <request>
        <payload>
            <ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL xmlns:ns0="urn:sap-com:document:sap:rfc:functions" xmlns:p7="http://rfc.lookup.mt.sap.com" p7:occ="1:1">
                <FLIGHT_KEY p7:occ="1:1">
                    <AIRLINEID p7:occ="0:1">asd</AIRLINEID>
                    <CONNECTID p7:occ="0:1"/>
                    <FLIGHTDATE p7:occ="0:1"/>
                </FLIGHT_KEY>
            </ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL>
        </payload>
        <paths>
            <path>/ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL/FLIGHT_KEY/CONNECTID</path>
            <path>/ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL/FLIGHT_KEY/FLIGHTDATE</path>
        </paths>
    </request>
    <response>
        <payload>
            <ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL.Response xmlns:ns0="urn:sap-com:document:sap:rfc:functions">
                <FLIGHT_AVAILABILITY>
                    <ECONOMAX/>
                    <ECONOFREE/>
                    <BUSINMAX/>
                    <BUSINFREE/>
                    <FIRSTMAX/>
                    <FIRSTFREE/>
                </FLIGHT_AVAILABILITY>
            </ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL.Response>
        </payload>
        <paths>
            <path>/ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL.Response/FLIGHT_AVAILABILITY</path>
            <path>/ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL.Response/FLIGHT_AVAILABILITY/ECONOMAX</path>
            <path>/ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL.Response/FLIGHT_AVAILABILITY/BUSINMAX</path>
        </paths>
    </response>
</rfcTempl>
*/
}

def void custom_SXIDEMO_AIRL_FLIGHT_CHECKAVAIL_2(String[] i1, Output O1, MappingContext context) {
  //TODO remove function or fill it interface
  
  /*
 <rfcTempl xmlns="urn:sap-com:xi">
    <request>
        <payload>
            <ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL xmlns:ns0="urn:sap-com:document:sap:rfc:functions" xmlns:p7="http://rfc.lookup.mt.sap.com" p7:occ="1:1">
                <FLIGHT_KEY p7:occ="1:1">
                    <AIRLINEID p7:occ="0:1"/>
                    <CONNECTID p7:occ="0:1"/>
                    <FLIGHTDATE p7:occ="0:1"/>
                </FLIGHT_KEY>
            </ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL>
        </payload>
        <paths>
            <path>/ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL/FLIGHT_KEY/AIRLINEID</path>
        </paths>
    </request>
    <response>
        <payload>
            <ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL.Response xmlns:ns0="urn:sap-com:document:sap:rfc:functions">
                <FLIGHT_AVAILABILITY>
                    <ECONOMAX/>
                    <ECONOFREE/>
                    <BUSINMAX/>
                    <BUSINFREE/>
                    <FIRSTMAX/>
                    <FIRSTFREE/>
                </FLIGHT_AVAILABILITY>
            </ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL.Response>
        </payload>
        <paths>
            <path>/ns0:SXIDEMO_AIRL_FLIGHT_CHECKAVAIL.Response/FLIGHT_AVAILABILITY/ECONOFREE</path>
        </paths>
    </response>
</rfcTempl>
*/
}

