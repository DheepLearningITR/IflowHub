import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    
    //Body (SFSF payload)
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def payload = jsonSlurper.parseText(body);
    def skillsDegreedResponse = payload['data']
    def skillsDegreed = []
    def skillsSFSF = []
    
    // Get properties
    def properties = message.getProperties();
    def itemID = properties.get("itemID") as String;
    def createSkillList = ["data": []];
    def deleteSkillList = ["data": []];
    def payloadCreate = ["data": []];
    def payloadRemove = ["data": []];
    
    if (properties.containsKey("degreedSubjectAreasFeed")) {
        skillsSFSF = properties.get("degreedSubjectAreasFeed") as ArrayList;
        skillsSFSFReady = [];
        def skillName = [];
        for (skill in skillsSFSF) {
            skillString = skill.toString();
            if (skillString.contains("subjectAreaDesc=")) {
                skillName = skillString.split('subjectAreaDesc=');
                skillsSFSFReady.add(skillName[1]);
            };
        };

        for (skill in skillsDegreedResponse) {
            skillsDegreed.add(skill['id']);
        };
        
        def commons = skillsDegreed.intersect(skillsSFSFReady);
        def difference = skillsDegreed.plus(skillsSFSFReady)
        difference.removeAll(commons)
        
        
        
        for (skill in difference) {
            if (skillsSFSFReady.contains(skill)) {
                createSkillList["data"].add(skill);
            };
            
            if (skillsDegreed.contains(skill)) {
                deleteSkillList["data"].add(skill);
            };
        };
        
        // Create payload for degreed
        for (skill in createSkillList["data"]) {
            payloadCreate["data"].add(["id": skill, "type": "skills"])
        };
        
        for (skill in deleteSkillList["data"]) {
            payloadRemove["data"].add(["id": skill, "type": "skills"])
        };
    };
    
    // Logic to create a log
    def createSkillListSize = createSkillList["data"].size 
    def deleteSkillListSize = deleteSkillList["data"].size
    def messageLog = messageLogFactory.getMessageLog(message);
    if(createSkillListSize > 0){
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString(itemID + " create skill size: " + createSkillListSize as String, payloadCreate as String, "text/plain");
    };
    
    if(deleteSkillListSize > 0){
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString(itemID + " remove skill size: " + deleteSkillListSize as String, payloadRemove as String, "text/plain");
    };
    
    // Set up properties
    if (createSkillListSize == 0) {
        message.setProperty("degreedCreateSkillList", 'false');
    } else {
        message.setProperty("degreedCreateSkillList", new JsonBuilder(payloadCreate).toPrettyString());
    }
    
    if (deleteSkillListSize == 0) {
        message.setProperty("degreedDeleteSkillList", 'false');
    } else {
        message.setProperty("degreedDeleteSkillList", new JsonBuilder(payloadRemove).toPrettyString());
    }
    
    return message;
}
