import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Properties
    def properties = message.getProperties();
    value = properties.get("access_token");
    key_type = properties.get("key_type");
    
    def map = message.getHeaders();
    
    if (key_type == "admin"){
        HashMap<String, String> cacheData = map.get("token");
        cacheData.put("token",value)
        message.setHeader("token",cacheData);
    }
    else {
        HashMap<String, String> cacheData = map.get("tokenUser");
        cacheData.put("tokenUser",value)
        message.setHeader("tokenUser",cacheData);
    }


    return message;
}