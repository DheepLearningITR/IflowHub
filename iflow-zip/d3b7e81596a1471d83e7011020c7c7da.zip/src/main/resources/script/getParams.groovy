import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.exception.SecureStoreException;

def Message processData(Message message) {
    // Initialize Secure Store Service
    def secureStorageService = ITApiFactory.getService(SecureStoreService.class, null);
    if (!secureStorageService) {
        throw new Exception("SecureStoreService is not available");
    }

    try {
        // Retrieve properties from the message
        def properties = message.getProperties();
        
        // Default to "false" if the property is missing
        def gat_enabled = properties.get("is_GAT_enabled") ?: "false";

        def cred_prefix = (gat_enabled == "true") ? "GAT_" : "";

        // Retrieve secure credentials for Client ID
        def degreedClientId = properties.get(cred_prefix + "Degreed_Client_Id");
        if (!degreedClientId) {
            throw new Exception("Property '${cred_prefix}Degreed_Client_Id' is missing");
        }
        def secureParameter1 = secureStorageService.getUserCredential(degreedClientId);
        if (!secureParameter1) {
            throw new SecureStoreException("${cred_prefix}Degreed_Client_Id not found in secure store");
        }
        def clientId = secureParameter1.getPassword().toString();
        message.setProperty("client_id", clientId);

        // Retrieve secure credentials for Client Secret
        def degreedClientSecret = properties.get(cred_prefix + "Degreed_Client_Secret");
        if (!degreedClientSecret) {
            throw new Exception("Property '${cred_prefix}Degreed_Client_Secret' is missing");
        }
        def secureParameter2 = secureStorageService.getUserCredential(degreedClientSecret);
        if (!secureParameter2) {
            throw new SecureStoreException("${cred_prefix}Degreed_Client_Secret not found in secure store");
        }
        def clientSecret = secureParameter2.getPassword().toString();
        message.setProperty("client_secret", clientSecret);

    } catch (Exception e) {
        throw new SecureStoreException("Secure Parameter not available: " + e.getMessage(), e);
    }
    return message;
}
