import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    def properties = message.getProperties();
    mainLanguage = properties.get('language');
    def map = message.getHeaders();
    HashMap<String, String> cacheData2 = map.get("processedItems");
    
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment");
        messageLog.addAttachmentAsString("Lenguage " + mainLanguage + " Item processes before: " + cacheData2.size() as String, "No body", "text/plain");
    };
    
    // Wait 5 seconds before start the lenguaje
    Thread.sleep(5000);
    
    return message;
}
