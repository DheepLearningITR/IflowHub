import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    //Body (SFSF payload)
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def payload = jsonSlurper.parseText(body);
    
    // Get properties
    def properties = message.getProperties();
    
    // Empty contentType
    if (payload['root']['value'] == "") {
        message.setProperty("degreedEndpoint", 'NOT_FOUND');
        return message;
    }
        
    // Normal logic
    def contentType = payload['root']['value']['itemTypeID'];
    def degreedType = '';
    def listCourseTypes = ["COURSE", "ONLINE", "MOOC", "OJT", "CHANNEL", "SELF", "VIRT", "CLASS"]
    def listBookTypes = ["BOOK", "AUDIO SUMMARY", "AUDIOBOOK", "BOOK SUMMARY"]
    def listAssessmentTypes = ["EXAM", "CERT", "JPM"]
    def listArticleTypes = ["DOC", "SOP", "TASK", "BRIEF", "INFORMAL", "LINKED CONTENT"]
    def listVideoTypes = ["VIDEO"]
    def listEventTypes = ["OTHER"]

    if (listCourseTypes.contains(contentType)) {
        degreedType = 'COURSE';
    } else if (listBookTypes.contains(contentType)) {
        degreedType = 'BOOK';
    } else if (listAssessmentTypes.contains(contentType)) {
        degreedType = 'ASSESSMENTS';
    } else if (listArticleTypes.contains(contentType)) {
        degreedType = 'ARTICLES';
    } else if (listVideoTypes.contains(contentType)) {
        degreedType = 'VIDEO';
    } else if (listEventTypes.contains(contentType)) {
        degreedType = 'EVENT';
    } else {
        degreedType = 'NOT_FOUND';
    };
    
    // Update Logic based in diff with SFSF
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("degreedItems");
    
    // Active logic
    def isObsolote = true;
 
    
    // URL logic -> It's the same for all
    payloadUrl = properties.get("payloadUrl");
    paylaodDestUrl = properties.get("paylaodDestUrl");
    payloadCompany = properties.get("payloadCompany");
    def itemID = payload['root']['value']['itemID'];
    def itemTypeID = payload['root']['value']['itemTypeID'];
    def revisionDate = payload['root']['value']['revisionDate'];
    def dommain_url = 'https://'+payloadUrl+'/sf/learning?destUrl=';
    def query_url = paylaodDestUrl+'/learning/user/deeplink_redirect.jsp?linkId=ITEM_DETAILS&componentID=' +itemID+'&componentTypeID='+itemTypeID+'&revisionDate='+revisionDate+'&fromSF=Y';
    query_url_utf8 = URLEncoder.encode(query_url, "UTF-8");
    def end_url = '&company='+payloadCompany;
    message.setProperty("itemID", itemID);
    
    // Update Logic based in Last Execution Date and Revision Date
    def jsonSlurper2 = new JsonSlurper();
    def wasUpdated = false;
    
    // Payload logic
    def payloadType = "";
    def attributes = [:];

    if (degreedType == 'COURSE') {
        def degreedExternalId = itemID + "_" + itemTypeID + "_" + revisionDate
        def degreedUrl = dommain_url + query_url_utf8 + end_url;
        def degreedTitle = payload['root']['value']['itemTitle'];

        attributes = [
            "external-id": degreedExternalId,
            "url": degreedUrl,
            "title": degreedTitle,
            "obsolete": isObsolote
        ];

        if (contentType == 'OJT') {
            attributes.put("format","On The Job Training");
        };
        
        if (contentType == 'MOOC') {
            attributes.put("format","MOOC");
        };
        
        if (contentType == 'ONLINE') {
            attributes.put("format","Online Course");
        };
        
        if (contentType == 'COURSE') {
            attributes.put("format","Course");
        };
        
        if (contentType == 'SELF') {
            attributes.put("format","Self study");
        };
        
        if (contentType == 'VIRT') {
            attributes.put("format","Virtual");
        };

        message.setProperty("degreedEndpoint", '/api/v2/content/courses');
        
        // Logic to update Courses
        if (cacheData.get(degreedExternalId) != null) {
            def keys = attributes.keySet() as String[];
            def degreedCurrentData = jsonSlurper2.parseText(cacheData.get(degreedExternalId));
            
            for (key in keys) {
                if (degreedCurrentData[key] != attributes.get(key)) {
                    wasUpdated = true;
                };
            }
            
            cacheData.remove(degreedExternalId);
            
        };
        

    } else if (degreedType == 'VIDEO') {
        
        def degreedExternalId = itemID + "_" + itemTypeID + "_" + revisionDate
        def degreedUrl = dommain_url + query_url_utf8 + end_url;
        def degreedTitle = payload['root']['value']['itemTitle'];

        attributes = [
            "external-id": degreedExternalId,
            "url": degreedUrl,
            "title": degreedTitle,
            "obsolete": isObsolote
        ];
    
        
        message.setProperty("degreedEndpoint", '/api/v2/content/videos');
        
        // Logic to update Videos
        if (cacheData.get(degreedExternalId) != null) {
            def keys = attributes.keySet() as String[];
            def degreedCurrentData = jsonSlurper2.parseText(cacheData.get(degreedExternalId));
            
            for (key in keys) {
                if (degreedCurrentData[key] != attributes.get(key)) {
                    wasUpdated = true;
                };
            }
            
            cacheData.remove(degreedExternalId);
            
        };
        
    } else if (degreedType == 'BOOK') {
        def degreedUrl = dommain_url + query_url_utf8 + end_url;
        def degreedTitle = payload['root']['value']['itemTitle'];
    
        payloadType = "content/books";
        attributes = [
            "external-id": degreedUrl,
            "title": degreedTitle,
            "obsolete": isObsolote
        ];

        message.setProperty("degreedEndpoint", '/api/v2/content/books');
        
        // Logic to update Book
        if (cacheData.get(degreedUrl) != null) {
            def keys = attributes.keySet() as String[];
            def degreedCurrentData = jsonSlurper2.parseText(cacheData.get(degreedUrl));
            
            for (key in keys) {
                if (degreedCurrentData[key] != attributes.get(key)) {
                    wasUpdated = true;
                };
            }
            
            cacheData.remove(degreedUrl);
            
        };
        
    } else if (degreedType == 'EVENT') {
        def degreedUrl = dommain_url + query_url_utf8 + end_url;
        def degreedTitle = payload['root']['value']['itemTitle'];
    
        payloadType = "content/events";
        attributes = [
            "external-id": degreedUrl,
            "name": degreedTitle,
            "obsolete": isObsolote
        ];

        message.setProperty("degreedEndpoint", '/api/v2/content/events');
        
        // Logic to update Events
        if (cacheData.get(degreedUrl) != null) {
            def keys = attributes.keySet() as String[];
            def degreedCurrentData = jsonSlurper2.parseText(cacheData.get(degreedUrl));
            
            for (key in keys) {
                if (degreedCurrentData[key] != attributes.get(key)) {
                    wasUpdated = true;
                };
            }
            
            cacheData.remove(degreedUrl);
            
        };

    } else if (degreedType == 'ARTICLES') {
        // Payload Logic
        def degreedExternalId = itemID + "_" + itemTypeID + "_" + revisionDate
        def degreedUrl = dommain_url + query_url_utf8 + end_url;
        def degreedTitle = payload['root']['value']['itemTitle'];
        // def degreedNumWords = 100;

        attributes = [
            "external-id": degreedExternalId,
            "url": degreedUrl,
            "title": degreedTitle,
            "obsolete": isObsolote
            
        ];

        message.setProperty("degreedEndpoint", '/api/v2/content/articles');
        
        // Logic to update Articles
        if (cacheData.get(degreedExternalId) != null) {
            def keys = attributes.keySet() as String[];
            def degreedCurrentData = jsonSlurper2.parseText(cacheData.get(degreedExternalId));
            
            for (key in keys) {
                if (degreedCurrentData[key] != attributes.get(key)) {
                    wasUpdated = true;
                };
            }
            
            cacheData.remove(degreedExternalId);
            
        };
  
    } else if (degreedType == 'ASSESSMENTS') {
        def degreedExternalId = itemID + "_" + itemTypeID + "_" + revisionDate
        def degreedUrl = dommain_url + query_url_utf8 + end_url;
        def degreedTitle = payload['root']['value']['itemTitle'];
        
        attributes = [
            "external-id": degreedExternalId,
            "num-questions": 1,
            "url": degreedUrl,
            "title": degreedTitle,
            "obsolete": isObsolote
        ];
        
        payloadType = "content/assessments";
        message.setProperty("degreedEndpoint", '/api/v2/content/assessments');
        
        // Logic to update Assessments
        if (cacheData.get(degreedExternalId) != null) {
            def keys = attributes.keySet() as String[];
            def degreedCurrentData = jsonSlurper2.parseText(cacheData.get(degreedExternalId));
            
            for (key in keys) {
                if (degreedCurrentData[key] != attributes.get(key)) {
                    wasUpdated = true;
                };
            }
            
            cacheData.remove(degreedExternalId);
            
        };
    
    } else (degreedType == 'NOT_FOUND') {
        message.setProperty("degreedEndpoint", 'NOT_FOUND');
    };

    if (degreedType == 'COURSE' || degreedType == 'ARTICLES') {
        payload = [
            "data": [
                "attributes": attributes
                ]
        ];

    } else {
        payload = [
            "data": [
                "type": payloadType,
                "attributes": attributes
            ]
        ]
    };

    def json = new groovy.json.JsonBuilder(payload);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString());
    message.setBody(bodyPayload);
    
    
    
    message.setProperty("updated", wasUpdated);
    return message;
}
