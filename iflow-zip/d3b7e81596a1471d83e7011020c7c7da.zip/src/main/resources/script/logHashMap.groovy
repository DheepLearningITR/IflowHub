import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    // Update Logic based in diff with SFSF
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("degreedItems");
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("Degreed Items not found", cacheData as String, "text/plain");
    }
    
    return message;
}
