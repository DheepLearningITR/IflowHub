import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    //Body (SFSF payload)
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def payload = jsonSlurper.parseText(body);
    
    // Get properties
    def properties = message.getProperties();
    
    // Empty contentType
    if (payload['root']['value'] == "") {
        message.setProperty("degreedEndpoint", 'NOT_FOUND');
        return message;
    }
    
    // ------------------------------------------------------------------------
    // Save data for skills
    // ------------------------------------------------------------------------
    def skillsSFSF = [];
    
    if (payload['root']['value'] != "") {
        def subjectAreasFeed = payload['root']['value']['SubjectAreasFeed'];
        
        for (skill in subjectAreasFeed) {
            skillsSFSF.add(skill);
        };
    };
    
    // ------------------------------------------------------------------------
    // Logic to assign the type
    // ------------------------------------------------------------------------
    
    def contentType = properties.get("contentName");
    def degreedType = '';
    def listCourseTypes = ["COURSE", "ONLINE", "MOOC", "OJT", "CHANNEL", "SELF", "VIRT", "CLASS"]
    def listBookTypes = ["BOOK", "AUDIO SUMMARY", "AUDIOBOOK", "BOOK SUMMARY"]
    def listAssessmentTypes = ["EXAM", "CERT", "JPM"]
    def listArticleTypes = ["DOC", "SOP", "TASK", "BRIEF", "INFORMAL", "LINKED CONTENT"]
    def listVideoTypes = ["VIDEO"]
    def listEventTypes = ["OTHER"]

    if (listCourseTypes.contains(contentType)) {
        degreedType = 'COURSE';
    } else if (listBookTypes.contains(contentType)) {
        degreedType = 'BOOK';
    } else if (listAssessmentTypes.contains(contentType)) {
        degreedType = 'ASSESSMENTS';
    } else if (listArticleTypes.contains(contentType)) {
        degreedType = 'ARTICLES';
    } else if (listVideoTypes.contains(contentType)) {
        degreedType = 'VIDEO';
    } else if (listEventTypes.contains(contentType)) {
        degreedType = 'EVENT';
    } else {
        degreedType = 'NOT_FOUND';
    };
    
    // ------------------------------------------------------------------------
    // Active logic
    // ------------------------------------------------------------------------
    
    def isObsolote = false;
    def isActive = payload['root']['value']['active'];
    if (isActive == false || isActive == 'false') {
        isObsolote = true;
    }
    
    // ------------------------------------------------------------------------
    // URL logic -> It's the same for all
    // ------------------------------------------------------------------------
    
    payloadUrl = properties.get("payloadUrl");
    paylaodDestUrl = properties.get("paylaodDestUrl");
    payloadCompany = properties.get("payloadCompany");
    def itemID = payload['root']['value']['componentID'];
    def itemTypeID = payload['root']['value']['componentTypeID'];
    def revisionDate = payload['root']['value']['revisionDate'];
    def dommain_url = 'https://'+payloadUrl+'/sf/learning?destUrl=';
    def query_url = paylaodDestUrl+'/learning/user/deeplink_redirect.jsp?linkId=ITEM_DETAILS&componentID=' +itemID+'&componentTypeID='+itemTypeID+'&revisionDate='+revisionDate+'&fromSF=Y';
    query_url_utf8 = URLEncoder.encode(query_url, "UTF-8");
    def end_url = '&company='+payloadCompany;
    message.setProperty("itemID", itemID);
    
    // ------------------------------------------------------------------------
    // Payload logic
    // ------------------------------------------------------------------------
    
    def language = properties.get("language");
    def payloadType = "";
    def attributes = [:];
    def mainKey = '';

    if (degreedType == 'COURSE') {
        def degreedExternalId = itemID + ":" + itemTypeID + ":" + revisionDate
        def degreedUrl = dommain_url + query_url_utf8 + end_url;
        def degreedTitle = payload['root']['value']['title'];
        def degreedSummary = payload['root']['value']['description'];
        //def degreedDuration = payload['root']['value']['totalLength'];
        def degreedDuration = payload['root']['value']['creditHours'];
        def degreedContinuingEducationHours = payload['root']['value']['cpeHours'];
        
        if (!(degreedContinuingEducationHours ==~ /.*\d+.*/)) {
            degreedContinuingEducationHours = null
        }
        
        def degreedDurationType = 'hours';
        if (degreedDuration == "") {
            attributes = [
                "external-id": degreedExternalId,
                "url": degreedUrl,
                "title": degreedTitle,
                "summary": degreedSummary,
                // "duration": degreedDuration,
                // "duration-type": degreedDurationType,
                //"continuing-education-units": degreedContinuingEducationHours,
                "language": language,
                "obsolete": isObsolote
            ];
        };
        else {
            attributes = [
                "external-id": degreedExternalId,
                "url": degreedUrl,
                "title": degreedTitle,
                "summary": degreedSummary,
                "duration": degreedDuration,
                "duration-type": degreedDurationType,
                //"continuing-education-units": degreedContinuingEducationHours,
                "language": language,
                "obsolete": isObsolote
            ];
        };
        
        if (degreedContinuingEducationHours != null) {
            attributes['continuing-education-units'] = degreedContinuingEducationHours
        };
        
        if (contentType == 'OJT') {
            //attributes.put("format","On The Job Training"); // Key not valid in Degreed 07-23
            attributes.put("format","Online");
        };
        
        if (contentType == 'MOOC') {
            //attributes.put("format","MOOC"); // Key not valid in Degreed 07-23
            attributes.put("format","Online");
        };
        
        if (contentType == 'ONLINE') {
            //attributes.put("format","Online Course"); // Key not valid in Degreed 07-23
            attributes.put("format","Online");
        };
        
        if (contentType == 'COURSE') {
            //attributes.put("format","Course"); // Key not valid in Degreed 07-23
            attributes.put("format","Online");
        };
        
        if (contentType == 'SELF') {
            attributes.put("format","Self study");
        };
        
        if (contentType == 'VIRT') {
            attributes.put("format","Virtual");
        };

        message.setProperty("degreedEndpoint", '/api/v2/content/courses');
        
        // Logic to update Courses
        mainKey = degreedExternalId;
        

    } else if (degreedType == 'VIDEO') {
        
        def degreedExternalId = itemID + ":" + itemTypeID + ":" + revisionDate
        def degreedUrl = dommain_url + query_url_utf8 + end_url;
        def degreedTitle = payload['root']['value']['title'];
        def degreedSummary = payload['root']['value']['description'];
        //def degreedDuration = payload['root']['value']['totalLength'];
        def degreedDuration = payload['root']['value']['creditHours'];
        def degreedContinuingEducationHours = payload['root']['value']['cpeHours'];
        def degreedDurationType = 'hours';
        if (degreedDuration == "") {
            attributes = [
            "external-id": degreedExternalId,
            "url": degreedUrl,
            "title": degreedTitle,
            "summary": degreedSummary,
            // "duration": degreedDuration,
            // "duration-type": degreedDurationType,
            // "continuing-education-units": degreedContinuingEducationHours,
            "language": language,
            "obsolete": isObsolote
        ];
        };
        else {
            attributes = [
            "external-id": degreedExternalId,
            "url": degreedUrl,
            "title": degreedTitle,
            "summary": degreedSummary,
            "duration": degreedDuration,
            "duration-type": degreedDurationType,
            // "continuing-education-units": degreedContinuingEducationHours,
            "language": language,
            "obsolete": isObsolote
        ];
        };
        
        message.setProperty("degreedEndpoint", '/api/v2/content/videos');
        
        // Logic to update Videos
        mainKey = degreedExternalId;
        
    } else if (degreedType == 'BOOK') {
        def degreedExternalId = itemID + ":" + itemTypeID + ":" + revisionDate
        def degreedUrl = dommain_url + query_url_utf8 + end_url;
        def degreedTitle = payload['root']['value']['title'];
        def degreedSummary = payload['root']['value']['description'];
    
        payloadType = "content/books";
        attributes = [
            "external-id": degreedExternalId,
            "url": degreedUrl,
            "title": degreedTitle,
            "summary": degreedSummary,
            "language": language,
            "obsolete": isObsolote
        ];

        message.setProperty("degreedEndpoint", '/api/v2/content/books');
        
        // Logic to update Book
        mainKey = degreedUrl;

        
    } else if (degreedType == 'EVENT') {
        def degreedExternalId = itemID + ":" + itemTypeID + ":" + revisionDate
        def degreedUrl = dommain_url + query_url_utf8 + end_url;
        def degreedTitle = payload['root']['value']['title'];
        def degreedSummary = payload['root']['value']['description'];
    
        payloadType = "content/events";
        attributes = [
            "external-id": degreedExternalId,
            "url": degreedUrl,
            "name": degreedTitle,
            "summary": degreedSummary,
            "language": language,
            "obsolete": isObsolote
        ];

        message.setProperty("degreedEndpoint", '/api/v2/content/events');
        
        // Logic to update Events
        mainKey = degreedExternalId;

    } else if (degreedType == 'ARTICLES') {
        // Payload Logic
        def degreedExternalId = itemID + ":" + itemTypeID + ":" + revisionDate
        def degreedUrl = dommain_url + query_url_utf8 + end_url;
        def degreedTitle = payload['root']['value']['title'];
        def degreedSummary = payload['root']['value']['description'];
        // def degreedNumWords = 100;

        attributes = [
            "external-id": degreedExternalId,
            "url": degreedUrl,
            "title": degreedTitle,
            "summary": degreedSummary,
            // "num-words": degreedNumWords,
            "language": language,
            "obsolete": isObsolote
            
        ];

        message.setProperty("degreedEndpoint", '/api/v2/content/articles');
        
        // Logic to update Articles
        mainKey = degreedExternalId;
  
    } else if (degreedType == 'ASSESSMENTS') {
        def degreedExternalId = itemID + ":" + itemTypeID + ":" + revisionDate
        def degreedUrl = dommain_url + query_url_utf8 + end_url;
        def degreedTitle = payload['root']['value']['title'];
        def degreedSummary = payload['root']['value']['description'];
        //def degreedDuration = payload['root']['value']['totalLength'];
        def degreedDuration = payload['root']['value']['creditHours'];
        def degreedContinuingEducationHours = payload['root']['value']['cpeHours'];
        def degreedDurationType = 'hours';
        if (degreedDuration == "") {
            attributes = [
            "external-id": degreedExternalId,
            "num-questions": 1,
            "url": degreedUrl,
            "title": degreedTitle,
            "summary": degreedSummary,
            // "duration": degreedDuration,
            // "duration-type": degreedDurationType,
            // "continuing-education-units": degreedContinuingEducationHours,
            "language": language,
            "obsolete": isObsolote
        ];
        };
        else {
            attributes = [
            "external-id": degreedExternalId,
            "num-questions": 1,
            "url": degreedUrl,
            "title": degreedTitle,
            "summary": degreedSummary,
            "duration": degreedDuration,
            "duration-type": degreedDurationType,
            // "continuing-education-units": degreedContinuingEducationHours,
            "language": language,
            "obsolete": isObsolote
        ];
        };
        
        payloadType = "content/assessments";
        message.setProperty("degreedEndpoint", '/api/v2/content/assessments');
        
        // Logic to update Assessments
        mainKey = degreedExternalId;

    } else (degreedType == 'NOT_FOUND') {
        message.setProperty("degreedEndpoint", 'NOT_FOUND');
    };
    
    // ------------------------------------------------------------------------
    // Logic to update items
    // ------------------------------------------------------------------------
    
    def jsonSlurper2 = new JsonSlurper();
    def wasUpdated = false;
    
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("degreedItems"); // Items created in Degreed
    HashMap<String, String> cacheData2 = map.get("processedItems"); // Items that was already processed in this Iflow
    
    def degreedContentId = '';
    
    if (mainKey.length() > 255) {
        // Degreed has a limit of 255 characters 
        // We are cutting this to get exatly the same key
       
        mainKey = mainKey.substring(0,255); 
    };
    
    if (cacheData2.get(mainKey) != null) {
        // Means that the items was processed
        
        wasUpdated = false; 
        degreedContentId = 'false';
        
    
    } else {
        cacheData2.put(mainKey, true); 
        // We are saving the item in the ProcessesItems HashMap
        
        if (cacheData.get(mainKey) != null) {  
            // Means that it's new, beacause is not in Degreed
            
            def keys = attributes.keySet() as String[];
            def degreedData = jsonSlurper2.parseText(cacheData.get(mainKey));
            def degreedCurrentData = degreedData['attributes']; // Data in Degreed
            degreedContentId = degreedData['id'];
            for (key in keys) { 
                // Checking difference in the keys
                
                if (degreedCurrentData[key] != null) {
                    
                    // Special logic to check external-id
                    fieldSFSF = attributes.get(key) as String;
                    if (fieldSFSF.length() > 255 && key == 'external-id') {
                        fieldSFSF = fieldSFSF.substring(0,255);
                    };
                    
                    // Special logic to check summary
                    if (key == 'summary' && fieldSFSF.contains(degreedCurrentData[key]) && degreedCurrentData[key].length() > 1900) {
                        fieldSFSF = degreedCurrentData[key];
                    };
                    
                    // Special logic to check duration type
                    if (key == 'duration-type' && degreedType == 'ASSESSMENTS') {
                        fieldSFSF = 'Questions';
                    };
                    
                    if (degreedCurrentData[key] instanceof String && fieldSFSF != degreedCurrentData[key]) {
                        // Means there is at least 1 difference
                        
                        // Log to debug
                        def messageLog = messageLogFactory.getMessageLog(message);
                        if(messageLog != null){
                            messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment");
                            def currentDataPrint = degreedCurrentData[key] as String;
                            def newDataPrint = attributes.get(key) as String;
                            messageLog.addAttachmentAsString("Diff " + mainKey.take(6) + " Key " + key + " " + currentDataPrint.length() as String, "Current: " + currentDataPrint + " New: " + newDataPrint, "text/plain");
                        };
                        
                        degreedCurrentData[key] = attributes.get(key);
                        degreedData['attributes'] = degreedCurrentData;
                        
                        // Pushing to the HashMap od Degreed Items to avoid do that again
                        // Comment: (Now this step is not necesary due to processedItems HashMap)
                        cacheData.put(mainKey, new JsonBuilder(degreedData).toPrettyString());
                        
                        wasUpdated = true;
                        break;
                    };
                };
            };
            
        } else {
            wasUpdated = true; 
        };
    };
    
    // ------------------------------------------------------------------------
    // Final payload structure & Save data
    // ------------------------------------------------------------------------
    
    if (degreedType == 'COURSE' || degreedType == 'ARTICLES') {
        payload = [
            "data": [
                "attributes": attributes
                ]
        ];

    } else {
        payload = [
            "data": [
                "type": payloadType,
                "attributes": attributes
            ]
        ]
    };
    
    // Set body and proporties
    def json = new groovy.json.JsonBuilder(payload);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString());
    
    // Save body and properties
    message.setBody(bodyPayload);
    message.setHeader("degreedItems",cacheData);
    message.setHeader("processedItems",cacheData2);
    message.setProperty("updated", wasUpdated);
    message.setProperty("degreedContentId", degreedContentId);
    message.setProperty("degreedSubjectAreasFeed", skillsSFSF);
    
    // newly added for live events
    message.setProperty("itemID", itemID);
    message.setProperty("itemTypeID", itemTypeID);
    message.setProperty("revisionDate", revisionDate);
    return message;
}
