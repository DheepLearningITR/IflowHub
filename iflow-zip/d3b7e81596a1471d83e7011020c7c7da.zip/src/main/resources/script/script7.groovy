import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);	
        messageLog.addAttachmentAsString("SAML_Assertion:", body, "text/xml");
        message.setBody("company_id=SFCPART001252&client_id=NTI3YmRmMGZhOGJhOGUxOWI3YjE3YzMxNzhkZA&grant_type=urn:ietf:params:oauth:grant-type:saml2-bearer&assertion=" + body);
        return message;
}