import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    
    //Body (Degreed payload)
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def payload = jsonSlurper.parseText(body);
    def currentExternalsIds = [];
    
    //Header
    def map = message.getHeaders();
    def nextParams = map.get("nextParams");
    
    //Next Logic
    if (payload['links'].containsKey('next')) {
        def link = payload['links']['next'].replace("?", "params").split("params")
        nextParams = link[1];
    } else {
        nextParams = 'finish';
    }
    
    // Logic to put all the learning content inside a HashMap
    HashMap<String, String> cacheData = map.get("degreedItems");
    
    for (item in payload['data']) {
        cacheData.put(item['attributes']['external-id'], new JsonBuilder(item).toPrettyString());
        currentExternalsIds.add(item['attributes']['external-id'])
    };
    
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
    messageLog.addAttachmentAsString("List of Degreed items, size " + cacheData.size() as String, currentExternalsIds as String, "text/plain");
    message.setHeader("degreedItems",cacheData);
    
    // logic to processed items
    HashMap<String, String> cacheData2 = map.get("processedItems");
    message.setHeader("processedItems",cacheData2);
    message.setHeader("nextParams", nextParams as String);
    return message;
}