import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    //Body (SFSF payload)
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def payload = jsonSlurper.parseText(body);
    
    // Get properties
    def properties = message.getProperties();
    def messageLog = messageLogFactory.getMessageLog(message);
    
    messageLog.addAttachmentAsString("Started Classes Logic", body, "text/plain");
    
    def degreedContentId = properties.get("degreedContentId");
    def eventIDSFSF = payload['root']['value']['scheduleID'];
    def facilityDescription = payload['root']['value']['facilityDescription'];
    def locationDescription = payload['root']['value']['locationDescription'];
    def startDateTime = payload['root']['value']['startDateTime'];
    def endDateTime = payload['root']['value']['endDateTime'];
    def timeZoneID = payload['root']['value']['timeZoneID'];
    
    def formatSDate = ""
    def formatEDate = ""
    
    if(startDateTime != null || startDateTime != ''){
        def sDate = Long.valueOf(startDateTime)
        def fStartDate = new Date(sDate)
        def forSDate = fStartDate.format("YYYY-MM-dd HH:mm:ss.SSSSSSS")
        formatSDate = forSDate.replace(" ", "T")
    }
    
    if(endDateTime != null || endDateTime != ''){
        def eDate = Long.valueOf(endDateTime)
        def fEndDate = new Date(eDate)
        def forEDate = fEndDate.format("YYYY-MM-dd HH:mm:ss.SSSSSSS")
        formatEDate = forEDate.replace(" ", "T")
    }
    
    def attributes = [
                    "location-type": "InPerson",
                    "location-address": facilityDescription + locationDescription,
                    "external-id": eventIDSFSF,
                    "utc-start-date-time": formatSDate,
                    "utc-end-date-time": formatEDate,
                    // "is-active": true,
                    "time-zone": timeZoneID
                        ]
    requestPayload = [
        "data" :[
            "attributes": attributes]
        ]
    
    
    // Set body and proporties
    def json = new groovy.json.JsonBuilder(requestPayload);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString());
    
    // Save body and properties
    message.setBody(bodyPayload);
    
    messageLog.addAttachmentAsString("Create Live Event Request Payload", bodyPayload, "text/plain");
    return message;
}
