import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Variables in cache
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("tokenDegreed");
    
    HashMap<String, String> cacheData2 = map.get("expireDateDegreed");
    message.setProperty("expiresDate", cacheData2.get("expireDateDegreed"));
    message.setProperty("degreedToken", cacheData.get("tokenDegreed"));

    //Properties
    def properties = message.getProperties();

    // Set variables
    def headerParam = "application/json";
    def auth_value = "Bearer " + cacheData.get("tokenDegreed");
    message.setHeader("accept",headerParam);
    message.setHeader("content-type",headerParam);
    message.setHeader("Authorization",auth_value);

    return message;
}