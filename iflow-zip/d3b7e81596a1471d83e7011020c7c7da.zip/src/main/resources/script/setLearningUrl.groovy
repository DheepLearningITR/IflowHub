import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.net.URLEncoder;
def Message processData(Message message) {
    //Properties
    def properties = message.getProperties();
    payloadUrl = properties.get("payloadUrl");
    paylaodDestUrl = properties.get("paylaodDestUrl");
    payloadCompany = properties.get("payloadCompany");
    itemID = properties.get("itemID");
    itemTypeID = properties.get("itemTypeID");
    revisionDate = properties.get("revisionDate");
    

    def dommain_url = 'https://'+payloadUrl+'/sf/learning?destUrl='
    def query_url = paylaodDestUrl+'/learning/user/deeplink_redirect.jsp?linkId=ITEM_DETAILS&componentID=' +itemID+'&componentTypeID='+itemTypeID+'&revisionDate='+revisionDate+'&fromSF=Y'
    query_url_utf8 = URLEncoder.encode(query_url, "UTF-8");
    def end_url = '&company='+payloadCompany
    
    def learning_url = dommain_url + query_url_utf8 + end_url;

    message.setBody(learning_url);
    return message;
}