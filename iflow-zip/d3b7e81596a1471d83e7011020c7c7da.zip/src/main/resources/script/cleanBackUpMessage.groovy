import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    // Wait 20 seconds to avoid rate limit in retry process
    Thread.sleep(20000);

    //Body
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def payload = jsonSlurper.parseText(body);
    def data = payload['messages']['message']['root']['data'];
    def endpoint = payload['messages']['message']['root']['endpoint'];
    def attemp = payload['messages']['message']['root']['attemp'];
    message.setProperty("attempsNumbers", attemp);
    message.setProperty("degreedEndpoint", endpoint);
    
    payload = [
            "data": data
    ]

    def json = new groovy.json.JsonBuilder(payload);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString())
    message.setBody(bodyPayload);
    return message;
}
