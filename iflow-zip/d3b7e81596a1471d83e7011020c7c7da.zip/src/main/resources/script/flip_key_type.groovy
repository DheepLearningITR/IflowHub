import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    def properties = message.getProperties();
    key_type = properties.get('key_type');
	
	message.setProperty("key_type", "user");
    
    return message;
}
