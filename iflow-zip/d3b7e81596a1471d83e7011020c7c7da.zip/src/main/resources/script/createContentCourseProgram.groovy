import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {

    //Body
    def properties = message.getProperties();
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def payload = jsonSlurper.parseText(body);
    def wasUpdated = false;
    def mainKey = '';
    
    if (payload['root']['value'] == null || payload['root']['value'] == '') {
        message.setProperty("discardeMessage", 'true');
        return message;
    };
    
    // ------------------------------------------------------------------------
    // URL logic
    // ------------------------------------------------------------------------
    
    payloadUrl = properties.get("payloadUrl");
    paylaodDestUrl = properties.get("paylaodDestUrl");
    payloadCompany = properties.get("payloadCompany");
    def curriculumID = payload['root']['value']['programID'];
    def dommain_url = 'https://'+payloadUrl+'/sf/learning?destUrl=';
    def query_url = paylaodDestUrl+'/learning/user/deeplink_redirect.jsp?linkId=PROGRAM_DETAILS&programID=' +curriculumID+'&fromSF=Y';
    query_url_utf8 = URLEncoder.encode(query_url, "UTF-8");
    def end_url = '&company='+payloadCompany;
    
    // ------------------------------------------------------------------------
    // Payload logic
    // ------------------------------------------------------------------------
    
    def degreedExternalId = curriculumID
    def degreedUrl = dommain_url + query_url_utf8 + end_url;
    def degreedTitle = payload['root']['value']['programTitle'];
    def degreedSummary = payload['root']['value']['description'];
    // def degreedDuration = 100;
    // def degreedDurationType = 'hours';
    
    mainKey = degreedExternalId;

    payload = [
            "data": [
                "attributes": [
                    "external-id": degreedExternalId,
                    "url": degreedUrl,
                    "title": degreedTitle,
                    "summary": degreedSummary
                    // "duration": degreedDuration,
                    // "duration-type": degreedDurationType
                    
                    ]
        ]
    ]
    
    // ------------------------------------------------------------------------
    // Update logic - Check item script
    // ------------------------------------------------------------------------
    
    def map = message.getHeaders();
    def jsonSlurper2 = new JsonSlurper();
    HashMap<String, String> cacheData = map.get("degreedItems");
    HashMap<String, String> cacheData2 = map.get("processedItems");
    
    if (cacheData2.get(mainKey) != null) {
        wasUpdated = false;
    
    } else {
        
        if (cacheData.get(mainKey) != null) {
            def keys = payload["data"]["attributes"].keySet() as String[];
            def degreedData = jsonSlurper2.parseText(cacheData.get(mainKey));
            def degreedCurrentData = degreedData['attributes'];
            
            for (key in keys) {
                if (degreedCurrentData[key] != null) {
                    if (degreedCurrentData[key] instanceof String && payload["data"]["attributes"].get(key) != degreedCurrentData[key]) {
                        def messageLog = messageLogFactory.getMessageLog(message);
                        if(messageLog != null){
                            messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment");
                            def currentDataPrint = degreedCurrentData[key] as String;
                            def newDataPrint = payload["data"]["attributes"].get(key) as String;
                            messageLog.addAttachmentAsString("Diff " + mainKey + " Key " + key, "Current: " + currentDataPrint + " New: " + newDataPrint, "text/plain");
                        };
                        wasUpdated = true;
                        break;
                    };
                };
            };
    
            
        } else {
           wasUpdated = true; 
        };
        
        cacheData2.put(mainKey, true);
        
    };
    
    // ------------------------------------------------------------------------
    // Save data 
    // ------------------------------------------------------------------------
    
    message.setHeader("degreedItems",cacheData);
    message.setHeader("processedItems",cacheData2);
    message.setProperty("pushToDegreed", wasUpdated);
    message.setProperty("degreedEndpoint", '/api/v2/content/courses');
    message.setProperty("discardeMessage", 'false');
    def json = new groovy.json.JsonBuilder(payload);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString());
    message.setBody(bodyPayload);
    return message;
}
