import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat

def Message processData(Message message) {
    // Properties
    def properties = message.getProperties()
    def lookBackTime = properties.get("lookBackPeriodStartTime")

    def formatPattern = "yyyy-MM-dd'T'HH:mm:ss"
    def simpleDateFormat = new SimpleDateFormat(formatPattern)

    try {
          Date date = simpleDateFormat.parse(lookBackTime)
          def timestamp = date.time

          message.setProperty("lookBackTime", timestamp);
        }
    catch (Exception e) {
          println "Error: ${e.message}"
      }
    // def messageLog = messageLogFactory.getMessageLog(message);
    // messageLog.addAttachmentAsString("Look Back Time", timestamp, "text/plain");


    return message
}
