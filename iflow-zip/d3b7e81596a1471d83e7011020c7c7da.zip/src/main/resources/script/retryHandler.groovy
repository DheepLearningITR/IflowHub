import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {

    //Body
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def payload = jsonSlurper.parseText(body);
    def data = payload['data'];

    //Proporties
    def properties = message.getProperties();
    def endpoint = properties.get("degreedEndpoint");
    def expiresDate = properties.get("expiresDate");
    def degreedToken = properties.get("degreedToken");
    def attemp = properties.get("attempsNumbers") as Integer;
    def newAttemp = attemp + 1;

    payload = [
            "data": data,
            "attemp": newAttemp,
            "endpoint": endpoint
    ]

    def json = new groovy.json.JsonBuilder(payload);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString())
    message.setBody(bodyPayload);
    
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
    messageLog.addAttachmentAsString("Message fails, saving payload", payload as String, "text/plain");
    return message;
}
