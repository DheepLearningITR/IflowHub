import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    // Retrieve and parse the incoming JSON body
    def body = message.getBody(String) as String; // Get the body as a string
    def jsonParser = new JsonSlurper();
    def jsonBody = jsonParser.parseText(body); // Parse the JSON string into a map

    // Extract the access_token from the JSON
    def accessToken = jsonBody.access_token;

    // Set the access_token as a property for reference in other steps (optional)
    message.setProperty("access_token", accessToken);

    // Retrieve the key_type property
    def properties = message.getProperties();
    def keyType = properties.get("key_type"); // Get the key_type property

    // Conditional logic to update headers based on the key_type
    if (keyType == "admin") {
        // Set the token header with the access_token value
        message.setHeader("token", accessToken);
    } else {
        // Set the tokenUser header with the access_token value
        message.setHeader("tokenUser", accessToken);
    }

    return message; // Return the updated message
}
