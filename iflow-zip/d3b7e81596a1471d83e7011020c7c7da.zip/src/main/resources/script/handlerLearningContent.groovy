import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	throw new Exception("This is for testing of custom exception thrown!");
	return message;
}