import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Variables in cache
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("tokenUser");

    //Properties
    def properties = message.getProperties();
    
    // Set variables
    def headerParam = "application/json";
    def auth_value = "Bearer " + cacheData.get("tokenUser");
    message.setHeader("accept",headerParam);
    message.setHeader("content-type",headerParam);
    message.setHeader("Authorization",auth_value);

    return message;
}