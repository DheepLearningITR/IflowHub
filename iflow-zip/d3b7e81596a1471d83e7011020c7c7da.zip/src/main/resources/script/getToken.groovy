import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    HashMap<String, String> token = new HashMap<String, String>();
    HashMap<String, String> tokenUser = new HashMap<String, String>();
    HashMap<String, String> tokenDegreed = new HashMap<String, String>();
    HashMap<String, String> expireDateDegreed = new HashMap<String, String>();
    HashMap<String, String> degreedItems = new HashMap<String, String>();
    HashMap<String, String> processedItems = new HashMap<String, String>();
    message.setHeader("token", token);
    message.setHeader("tokenUser", tokenUser);
    message.setHeader("tokenDegreed", tokenDegreed);
    message.setHeader("expireDateDegreed", expireDateDegreed);
    message.setHeader("degreedItems", degreedItems);
    message.setHeader("processedItems", processedItems);
    return message;
}