import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    // Get properties
    def properties = message.getProperties();
    def itemID = properties.get("itemID") as String;
    
    //Body (SFSF payload)
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def payload = jsonSlurper.parseText(body);
    def currentAttributes = payload['data']['attributes'];
    def newAttributes = [:];
    currentAttributes.each { key, val ->
        if (key != 'external-id') {
            newAttributes[key] = val;
        };
    };
    
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
    messageLog.addAttachmentAsString(itemID + " started update process", payload as String, "text/plain");

    
    payload['data']['attributes'] = newAttributes;
    def json = new groovy.json.JsonBuilder(payload);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString());
    message.setBody(bodyPayload);
    return message;
}
