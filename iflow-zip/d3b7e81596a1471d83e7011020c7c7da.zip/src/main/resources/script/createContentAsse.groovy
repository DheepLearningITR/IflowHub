import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {

    //Body
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def payload = jsonSlurper.parseText(body);
    
    // URL logic
    def properties = message.getProperties();
    payloadUrl = properties.get("payloadUrl");
    paylaodDestUrl = properties.get("paylaodDestUrl");
    payloadCompany = properties.get("payloadCompany");
    def itemID = payload['root']['value']['componentID'];
    def itemTypeID = payload['root']['value']['componentTypeID'];
    def revisionDate = payload['root']['value']['revisionDate'];
    def dommain_url = 'https://'+payloadUrl+'/sf/learning?destUrl=';
    def query_url = paylaodDestUrl+'/learning/user/deeplink_redirect.jsp?linkId=ITEM_DETAILS&componentID=' +itemID+'&componentTypeID='+itemTypeID+'&revisionDate='+revisionDate+'&fromSF=Y';
    query_url_utf8 = URLEncoder.encode(query_url, "UTF-8");
    def end_url = '&company='+payloadCompany;
    
    // Payload Logic
    def degreedExternalId = itemID + "_" + itemTypeID + "_" + revisionDate
    def degreedUrl = dommain_url + query_url_utf8 + end_url;
    def degreedTitle = payload['root']['value']['title'];
    def degreedSummary = payload['root']['value']['description'];
    def degreedDuration = payload['root']['value']['totalLength'];
    def degreedDurationType = 'hours';
    
    // Body logic
    
    payload = [
            "data": [
                "type": "content/assessments",
                "attributes": [
                    "external-id": degreedExternalId,
                    "num-questions": 1,
                    "url": degreedUrl,
                    "title": degreedTitle,
                    "summary": degreedSummary,
                    "duration": degreedDuration,
                    "duration-type": degreedDurationType
                    
                    ]
        ]
    ]

    def json = new groovy.json.JsonBuilder(payload);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString());
    message.setBody(bodyPayload);
    return message;
}
