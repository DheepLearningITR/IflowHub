import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*;
import java.net.URLEncoder;

def Message processData(Message message) {
    
    // Default language order
    
    def languageList = [];
        
    // Get properties
    def properties = message.getProperties();
    def defaultLanguage = payloadUrl = properties.get("defaultLanguage");
    def langList = properties.get("languageList");
    languageList = langList.split(',')
    def mainList = [];
    
    /*if (languageList.contains(defaultLanguage)) {
        mainList[0] = defaultLanguage;
        languageList.removeElement(defaultLanguage);
        mainList.addAll(languageList);
        
    } else {
        mainList += languageList;
        def messageLog = messageLogFactory.getMessageLog(message);
        if(messageLog != null){
            messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment");
            messageLog.addAttachmentAsString("Default language is not valid", "Default language: " + defaultLanguage + " , possibles values: " + languageList as String, "text/plain");
        }
    };*/
    mainList = languageList;

    def newBody = ['values': []];
    
    for (language in mainList) {
        newBody['values'].add(['language': language]);
    };
    
    def json = new groovy.json.JsonBuilder(newBody);
    def bodyPayload = groovy.json.JsonOutput.prettyPrint(json.toString());
    message.setBody(bodyPayload);
    return message;
}