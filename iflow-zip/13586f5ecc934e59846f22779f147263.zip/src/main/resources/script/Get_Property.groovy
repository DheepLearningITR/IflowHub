import com.sap.it.api.mapping.*

def String getProperty(String Response_Code,MappingContext context)

{
  String PropertyValue= context.getProperty(Response_Code);

  PropertyValue= PropertyValue.toString();

  return PropertyValue;

}