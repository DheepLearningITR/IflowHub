import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput;

def Message validate(Message message) {

    // Retrieve headers
    def headers = message.getHeaders();
    
    // Extract specific headers with defaults if necessary
    def cbrJobProfIds = headers.get("cbrJobProfileIds");  //INT-388 either jobLevel/id or jobRole/id
    def cbrJobArchitecture = headers.get("cbrJobArchitecture");
    def cbrJobProfileType = headers.get("cbrJobProfileType");
    def cbrJobProfileGetTexts = headers.get("cbrJobProfileGetTexts") ?: "false";
    def cbrSkillGetTexts = headers.get("cbrSkillGetTexts") ?: "false";
    def cbrCompetencyGetTexts = headers.get("cbrCompetencyGetTexts") ?: "false";
    def cbrCompetencyGet = headers.get("cbrCompetencyGet") ?: "false";
    def sfsfFamilyContext = headers.get("sfsfFamilyContext") ?: "null";

    def errors = []; // Unified error list
    
    // Validate HEADERS --------------------
    def mandatoryHeaders = [
        "cbrJobArchitecture",
        "cbrJobProfileType"
    ]
    
    mandatoryHeaders.each { key ->
        if (!headers[key]?.trim()) {
            errors.add(["errorCode": "[SAP-IS] MISSING_HDR", "errorMessage": key]);
        }
    }    

    // If there are any errors, set the error response and return
    if (!errors.isEmpty()) {
        def errorJson = JsonOutput.toJson(["errors": errors]);
        message.setProperty("errorJson", errorJson);
        throw new IllegalArgumentException(errorJson); // Exit with all errors
    }
    
    //Validation passed!  ---------------------
    
    //JIRA INT-388
    def cbrQueryEntity = 'jobRoles'
    if(cbrJobProfileType.toLowerCase()=='level'){
        cbrQueryEntity = 'jobLevels'
    }
    
    def cbrJobFamilyContext = '';
    if(sfsfFamilyContext!='null'){
        //cobrainer hierarchy: job architecture,family,cluster,role,level
        def cbrEntityType = 'jobArchitectureLevel';
        cbrJobFamilyContext = 'jobArchitectureLevel { parent { parent { parent { id } } } }';
        if(sfsfFamilyContext=='cluster'){
            cbrJobFamilyContext = 'jobArchitectureLevel { parent { parent { id } } }';
        }
        if(cbrJobProfileType.toLowerCase() == 'role'){
            cbrEntityType = 'jobArchitectureRole';
            cbrJobFamilyContext = 'jobArchitectureRole { parent { parent { id } } }';
            if(sfsfFamilyContext=='cluster'){
                cbrJobFamilyContext = 'jobArchitectureRole { parent { id } }';
            }            
        }
        message.setProperty("cbrEntityType",cbrEntityType); //used in XSLT mapping
    }
    
    def cbrJobProfileTexts = '';
    if(cbrJobProfileGetTexts.toLowerCase() == 'true'){
        cbrJobProfileTexts = 'translations { language title structured { tag value } }';
    }
    
    def cbrSkillTexts ='';
    if(cbrSkillGetTexts.toLowerCase() == 'true'){
        cbrSkillTexts = 'translations { language title description }';
    }
    
    def cbrCompetency = '';
    if(cbrCompetencyGet.toLowerCase() == 'true'){
        if(cbrCompetencyGetTexts.toLowerCase() == 'true'){
            cbrCompetency = 'competency { id translations { language title description } }';
        }else{
            cbrCompetency = 'competency { id }';
        }
    }        
    
    def cbrJobProfIdsFilter = "";
    if(cbrJobProfIds != null && cbrJobProfIds != ''){
        //enclose list in double quotes
        def jobProfIds = cbrJobProfIds.split(',');  //split by comma
        jobProfIds.each{j->
            if(cbrJobProfIdsFilter == ''){
                cbrJobProfIdsFilter = '\\"' + j.toString() + '\\"';
            }else{
                cbrJobProfIdsFilter = cbrJobProfIdsFilter + ',\\"' + j.toString() + '\\"';
            }
        }
        cbrJobProfIdsFilter = '{op: \\"in\\", field: \\"id\\", values: ['+cbrJobProfIdsFilter+'] },';
    }    
    
    message.setProperty("cbrQueryEntity", cbrQueryEntity); //JIRA INT-388
    message.setProperty("cbrJobProfileTexts", cbrJobProfileTexts);
    message.setProperty("cbrSkillTexts", cbrSkillTexts);
    message.setProperty("cbrCompetency", cbrCompetency);
    message.setProperty("cbrJobArchitecture", cbrJobArchitecture);
    message.setProperty("cbrJobProfileType", cbrJobProfileType);
    message.setProperty("cbrJobProfIds", cbrJobProfIds);
    message.setProperty("cbrJobProfIdsFilter", cbrJobProfIdsFilter);
    message.setProperty("cbrJobFamilyContext",cbrJobFamilyContext);    
    message.setProperty("sfsfFamilyContext", sfsfFamilyContext);    
    message.setBody(null);

    return message;
}

