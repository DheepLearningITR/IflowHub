import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        def cbrJobArchitecture = message.getProperties().get("cbrJobArchitecture");
		if(cbrJobArchitecture!=null){
			messageLog.addCustomHeaderProperty("cbrJobArchitecture", cbrJobArchitecture);		
        }        
        def sfsfFamilyContext = message.getProperties().get("sfsfFamilyContext");
		if(sfsfFamilyContext!=null && sfsfFamilyContext!='null'){
			messageLog.addCustomHeaderProperty("sfsfFamilyContext", sfsfFamilyContext);		
        }
        def cbrJobProfileType = message.getProperties().get("cbrJobProfileType");
		if(cbrJobProfileType!=null){
			messageLog.addCustomHeaderProperty("cbrJobProfileType", cbrJobProfileType);		
        }
        def mapCBRCompetency2SFSFTag = message.getHeaders().get("mapCBRCompetency2SFSFTag");
		if(mapCBRCompetency2SFSFTag!=null){
			messageLog.addCustomHeaderProperty("cbr_mapCBRCompetency2SFSFTag", mapCBRCompetency2SFSFTag);		
        }         
	}
	return message;
}

