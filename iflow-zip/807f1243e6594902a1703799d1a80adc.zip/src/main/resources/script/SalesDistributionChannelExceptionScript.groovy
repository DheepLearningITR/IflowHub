import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.*


def Message processData(Message message) {

	// get a map of iflow properties
	def map = message.getProperties();

	//Get Headers 
	def hmap = message.getHeaders();
	def csvfilename = hmap.get("CamelFileName");
	message.setProperty("csvfilename", csvfilename);
	
	String csvdata = "{\"row\": [";
	
	
	//Setting the timestamp
	def now = new Date();
	message.setProperty("timestamp", now.format("yyyyMMddHHmmss", TimeZone.getTimeZone('UTC')));
	
	//deriving the exception type
	String detailErrorMsg = message.getProperty("CamelExceptionCaught");
	def exceptionMessage = message.getProperty("CamelFailureEndpoint");
	def xsderror,deserializeError,artifactError
	if(null != detailErrorMsg){
		deserializeError = detailErrorMsg.contains("Could not deserialize request payload");
	    artifactError = detailErrorMsg.contains("NoArtifactDecriptorFoundForArtifactName");
	}
	if(null != exceptionMessage){
	    xsderror = exceptionMessage.contains("sap-xml-validator:///xsd/");
	}
	
	//getting the input payload for finding the failed records
	List<String> inputlist = new ArrayList<String>();
	inputlist = message.getProperty("P_ArrayData");
	
	
    if(xsderror) {
		
		//extracting the error and failed record logic
		detailErrorMsg = detailErrorMsg.substring(detailErrorMsg.indexOf("org.xml.sax.SAXParseException: "), detailErrorMsg.indexOf("].")-1);
		detailErrorMsg = detailErrorMsg.trim();
		
		
		detailErrorMsg.split("org.xml.sax.SAXParseException: ").each{ record ->
			
			String sfield,sfielderrormsg,srecordNo,sfieldValue;

			def TErrorMsg1 = "$record".toString();

			if((TErrorMsg1 != null) && !(TErrorMsg1.equals(""))) {
			
				sfield = "$record".substring("$record".indexOf("<")+1, "$record".indexOf(">"));
				if("$record".contains("convert")) {
				    sfieldValue = "$record".substring("$record".indexOf(". Cannot")+25, "$record".indexOf(" to xs:decimal")-1);
				    sfielderrormsg = "$record".substring("$record".indexOf(". Cannot")+2, "$record".indexOf(", L"));
				}
				else if("$record".contains("Invalid date")) {
					sfieldValue = "$record".substring("$record".indexOf("The content")+13, "$record".indexOf("The content ")+23);
				    sfielderrormsg = record.substring("$record".indexOf("Invalid date"), "$record".indexOf("Invalid date")+25);
				}
				else {
				    sfieldValue = "$record".substring("$record".indexOf(". Value")+9, "$record".indexOf(" contravenes")-1);
				    sfielderrormsg = "$record".substring("$record".indexOf(". Value")+2, "$record".indexOf(", L"));
				}
				sfielderrormsg = sfielderrormsg.replaceAll("\"", "'");
                
                //finding the failed records by parsing the input payload
				int j=1;
				for (j = 1; j <inputlist.size(); j++) {
					if(inputlist[j].contains(sfieldValue)) {
						
						inputlist[j] = inputlist[j].replace(sfieldValue, "XX");
						
						srecordNo = j;
					}
				}  
				if((srecordNo == null) || (srecordNo == "")) {
				    srecordNo = "Unable to derive the error record"; 
				}
				//setting up the error csv file
				csvdata = csvdata + '{"Record\":"' + srecordNo + '","Field\":"' + sfield + '","Error Details":"' + sfielderrormsg + '"},'; 
			}
		}
		message.setProperty("FailureMessage", "Unable to process the file as it contains errors.");		
		message.setProperty("FinalArr", inputlist);
		
		csvdata = csvdata + "]}";
		def index2 = csvdata.indexOf(",]}");
		csvdata = csvdata.substring(0, index2) + csvdata.substring(index2+1);
		csvdata = mapHeaders(csvdata);
	} 
	else if(artifactError){
	    detailErrorMsg = detailErrorMsg.substring(detailErrorMsg.indexOf("]:")+2);
	    detailErrorMsg = detailErrorMsg.trim();
        message.setProperty("FailureMessage", "Please check the Configuration");
        csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + detailErrorMsg + "\"}]}"; 
    }
	else if (deserializeError){
		message.setProperty("FailureMessage", "Unable to process the file as it contains errors.");	
		def sdeserializeError = "Could not deserialize request payload";
		csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + sdeserializeError + "\"}]}"; 
	}
	else {
		
		// get an exception java class instance
		def ex = map.get("CamelExceptionCaught");
		if (ex!=null) {

			// an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
			if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {

				// save the http error response as a message attachment 
				def messageLog = messageLogFactory.getMessageLog(message);
				messageLog.addAttachmentAsString("http.ResponseBody", ex.getResponseBody(), "text/plain");

				// copy the http error response to an iflow's property
				if(ex.getResponseBody() != null)  {
				    message.setProperty("FailureMessage", ex.getResponseBody());
				}
				else {
				    message.setProperty("FailureMessage", hmap.get("Www-Authenticate"));
				}

				csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + detailErrorMsg + "\"}]}"; 
			}  else {
				message.setProperty("FailureMessage", "Unknown Error, please contact your system administrator.");
				csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + "Unknown Error, please contact your system administrator." + "\"}]}"; 
		    }
		}
		else {
				message.setProperty("FailureMessage", "Unknown Error, please contact your system administrator.");

				csvdata = csvdata + "{\"Status\":\"Error\",\"Details\": \"" + "Unknown Error, please contact your system administrator." + "\"}]}"; 
		}
	}
	message.setBody(csvdata);
	
	return message;
}

def String mapHeaders(String input) {

	def mappings = [["distributionChannel", "Distribution Channel"],
					["salesOrganization", "Sales Organization"]
					]		
	mappings.each { mapping ->
		input = input.replace(mapping[0], mapping[1])
	}

	return input
}