import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    String content = message.getBody(String)

    if (content.contains('<MaximumLogItemSeverityCode>3</MaximumLogItemSeverityCode>')) {
        if (messageLog != null) {
            messageLog.setStringProperty("Logging#5", "Printing Payload ")
            messageLog.addAttachmentAsString("S4HC-IMPORT-ERRORRESPONSE", content, "text/xml");
        }

        throw new Exception("(CustomException)=>PostingIssue(Check Message Log Attachments for more details)")
    }

    return message;
}

