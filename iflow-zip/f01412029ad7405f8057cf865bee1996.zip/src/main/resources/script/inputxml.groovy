import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

import groovy.xml.MarkupBuilder
import groovy.xml.MarkupBuilderHelper
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil
import org.jaxen.XPath
import org.jaxen.jdom.JDOMXPath
import org.jdom.Document
import org.jdom.Element
import org.jdom.input.SAXBuilder
import org.jdom.output.Format
import org.jdom.output.XMLOutputter

import com.sap.it.spi.ITApiHandler;
import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.*;


def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def bankNumber_S4HC = message.getProperty("BankNumber")
    def swiftCodeBank_S4HC = message.getProperty("SWIFTCode")
    def bankAccount_S4HC = message.getProperty("BankAccount")
    def openingBalanceDS = message.getProperty("openingBalanceDS")
    def openingBalance_OverRide = message.getProperty("openingBalance_OverRide")

    def openingBalAmtInBankAcctCrcy_Manual = ""

    if(openingBalanceDS == null || openingBalanceDS.toString().equalsIgnoreCase(""))
        openingBalAmtInBankAcctCrcy_Manual = openingBalance_OverRide
    else
        openingBalAmtInBankAcctCrcy_Manual = openingBalanceDS


    def propertyMap = message.getProperties();
    def divisor = new BigDecimal("100")

    def openingBalanceTracker = ""


    String[] splitData = body.split("\n");
    String localval = ""

    // Build XML Document
    SAXBuilder builder = new SAXBuilder();


    //E.O. global document to hold all GL entries

    Element outputDocRoot = new Element("ALLUpdates");
    Document outputDoc = new Document(outputDocRoot);
    Element Header = null
    Element Item = null

    splitData.eachWithIndex { eachSplit, i ->

        def idetifier = eachSplit.substring(0, 2)
        if (idetifier == "01") {
            Header = new Element("Header")
            outputDocRoot.addContent(Header)

            String[] localdata = eachSplit.split("\\,")
            def bankNumber = localdata[1]
            if (bankNumber == "ANZ") {
                bankNumber = bankNumber_S4HC
            }
            Header.addContent(new Element("BankNumber").setText(bankNumber))

        }

        if (idetifier == "02") {
            String[] localdata = eachSplit.split("\\,")
            Header.addContent(new Element("SWIFTCode").setText(swiftCodeBank_S4HC))

            def bankStatementDate = localdata[4]
            Header.addContent(new Element("BankStatementDate").setText(bankStatementDate))
        }


        if (idetifier == "03") {

            String[] localdata = eachSplit.split("\\,")
            def currency = localdata[2]
            def country = ""
            if (currency == "AUD") {
                country = "AU"
            }
            Header.addContent(new Element("BankCountry").setText(country))
            Header.addContent(new Element("Currency").setText(currency))

            Header.addContent(new Element("BankAccount").setText(bankAccount_S4HC))

            Header.addContent(new Element("BankAccountHolderName").setText("Taronga Conservation Society Australia"))
            Header.addContent(new Element("BankStatement").setText("1"))

            try {
                def firstpos = Arrays.asList(localdata).indexOf("040");  //localdata.indexOf('040')
                def openingBalAmtInBankAcctCrcy = localdata[firstpos + 1]

                // Assignment of OpeningBalance Based on Custom Logic
                openingBalAmtInBankAcctCrcy = openingBalAmtInBankAcctCrcy_Manual

                openingBalanceTracker = openingBalAmtInBankAcctCrcy
                openingBalAmtInBankAcctCrcy = (new BigDecimal(openingBalAmtInBankAcctCrcy) / divisor).toString()
                Header.addContent(new Element("OpeningBalAmtInBankAcctCrcy").setText(openingBalAmtInBankAcctCrcy))
            }
            catch (Exception e) {
                Header.addContent(new Element("OpeningBalAmtInBankAcctCrcy").setText("0"))
            }

            try {
                def firstpos = Arrays.asList(localdata).indexOf("400")  //localdata.indexOf("400")
                def totalDebitAmtInBkAcctCrcy = localdata[firstpos + 1]
                totalDebitAmtInBkAcctCrcy = (new BigDecimal(totalDebitAmtInBkAcctCrcy) / divisor).toString()
                Header.addContent(new Element("TotalDebitAmtInBkAcctCrcy").setText(totalDebitAmtInBkAcctCrcy))
            }
            catch (Exception e) {
                Header.addContent(new Element("TotalDebitAmtInBkAcctCrcy").setText("0"))
            }


            try {
                def firstpos = Arrays.asList(localdata).indexOf("100");
                def totalCreditAmtInBkAcctCrcy = localdata[firstpos + 1]
                totalCreditAmtInBkAcctCrcy = (new BigDecimal(totalCreditAmtInBkAcctCrcy) / divisor).toString()
                Header.addContent(new Element("TotalCreditAmtInBkAcctCrcy").setText(totalCreditAmtInBkAcctCrcy))
            }
            catch (Exception e) {
                Header.addContent(new Element("TotalCreditAmtInBkAcctCrcy").setText("0"))
            }

            try {

                def pos_CreditBalance = Arrays.asList(localdata).indexOf("100");
                def totalCreditAmtInBkAcctCrcy_Calculated = new BigDecimal(localdata[pos_CreditBalance + 1])

                def pos_DebitBalance = Arrays.asList(localdata).indexOf("400");
                def totalDebitAmtInBkAcctCrcy_Calculated = localdata[pos_DebitBalance + 1]

                def diffBalance = new BigDecimal(totalCreditAmtInBkAcctCrcy_Calculated) - new BigDecimal(totalDebitAmtInBkAcctCrcy_Calculated)

                def calculatedClosingBalance = (new BigDecimal(openingBalanceTracker) + new BigDecimal(diffBalance)).toString()

                clsgBalAmtInBkAcctCrcy = (new BigDecimal(calculatedClosingBalance) / divisor).toString()

                Header.addContent(new Element("ClsgBalAmtInBkAcctCrcy").setText(clsgBalAmtInBkAcctCrcy))

                message.setProperty("openingBalance_DS",calculatedClosingBalance)
            }
            catch (Exception e) {
                Header.addContent(new Element("ClsgBalAmtInBkAcctCrcy").setText("0"))
            }


        }

        if (idetifier == "16") {
            Item = new Element("Item")
            outputDocRoot.addContent(Item)

            String[] localdata = eachSplit.split("\\,")

            def amountInBankAccountCurrency = localdata[2]
            amountInBankAccountCurrency = (new BigDecimal(amountInBankAccountCurrency) / divisor).toString()

            def paymentTransactionCode = localdata[1]

            if (Integer.parseInt(paymentTransactionCode) < 400)
                Item.addContent(new Element("AmountInBankAccountCurrency").setText(amountInBankAccountCurrency))
            else
                Item.addContent(new Element("AmountInBankAccountCurrency").setText("-" + amountInBankAccountCurrency))

            Item.addContent(new Element("PaymentTransactionCode").setText(paymentTransactionCode))

            def bankStatementItemDescription1 = localdata[4].trim().replaceAll("/", "").trim()

            def bankStatementItemDescription2 = localdata[6].replaceAll('#', '').replaceAll("/", "").trim()

            Item.addContent(new Element("BankStatementItemDescription2").setText(bankStatementItemDescription2))
            Item.addContent(new Element("BankStatementItemDescription1").setText(bankStatementItemDescription1))

        }


    }

    ByteArrayOutputStream bo = new ByteArrayOutputStream(); //E.O. moved from top
    Format format = Format.getPrettyFormat();
    format.setEncoding("UTF-8");
    XMLOutputter xmlout = new XMLOutputter(format);
    xmlout.output(outputDoc, bo);

    message.setBody(bo.toString("UTF-8"))

    return message;
} 