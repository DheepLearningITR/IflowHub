import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String readNRO(String arg1,MappingContext context){
    def nro = context.getProperty("BankStatementNumber")
    nro = nro.replaceAll("^0+",""); 
    //def nro_int = Integer.parseInt(nro)
    //nro = "7"
	return nro
}

def String readBankNumber(String arg1,MappingContext context){
    def nro = context.getProperty("BankNumber")
    //def nro_int = Integer.parseInt(nro)
	return nro
}

def String readSwiftCode(String arg1,MappingContext context){
    def nro = context.getProperty("SWIFTCode")
    //def nro_int = Integer.parseInt(nro)
	return nro
}

def String readBankAccountNumber(String arg1,MappingContext context){
    def nro = context.getProperty("BankAccount")
    //def nro_int = Integer.parseInt(nro)
	return nro
}

def String fieldLength(String arg1,int num,MappingContext context)
{
    def modifiedValue = arg1.take(num)
    return modifiedValue
}