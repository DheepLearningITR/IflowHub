import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.TimeZone;


def Message processData(Message message) {
    // definations
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def propertyMap = message.getProperties();
    def logger = message.getProperty("logger")

    //logs
    if (messageLog != null && logger.equalsIgnoreCase("true")) {
        messageLog.setStringProperty("Logging#2", "Printing Payload ")
        messageLog.addAttachmentAsString("S4HC-REQUEST-PREMAPPING", stringResponse, "text/xml");
    }

    return message;
}

def Message logPostS4HCCall(Message message) {
    // definations
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def logger = message.getProperty("logger")

    //logs
    if (messageLog != null && logger.equalsIgnoreCase("true")) {
        messageLog.setStringProperty("Logging#4", "Printing Payload ")
        messageLog.addAttachmentAsString("S4HC-RESPONSE", stringResponse, "text/xml");
    }

    return message;
}

def Message logPreS4HCCall(Message message) {
    // definations
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def propertyMap = message.getProperties();
    def logger = message.getProperty("logger")

    //logs
    if (messageLog != null && logger.equalsIgnoreCase("true")) {
        messageLog.setStringProperty("Logging#3", "Printing Payload ")
        messageLog.addAttachmentAsString("S4HC-REQUEST", stringResponse, "text/xml");
    }

    return message;
}