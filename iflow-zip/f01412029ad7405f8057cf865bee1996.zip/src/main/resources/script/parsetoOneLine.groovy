import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.IOException;
import java.io.InputStream;

import groovy.xml.MarkupBuilder
import groovy.xml.MarkupBuilderHelper
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil


def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    def propertyMap = message.getProperties();
    def logger = message.getProperty("logger")

    String[] splitData = body.split("\n");
    String transformedBAI = ""

    splitData.eachWithIndex { eachSplit, i ->
        def search = 0
        def idetifier = eachSplit.substring(0, 2)
        if (idetifier == "88") {
            return
        }
        transformedBAI = transformedBAI + eachSplit
        search = eachSplit.indexOf('/')

        // looping for next lines to check if the line continues with "88" as line identifier
        for (j = i + 1; j < splitData.size(); j++) {
            def seperation = '###'

            if (search > 0) {
                seperation = '##,'
            }
            def innerval = splitData[j]

            def inneridentifier = innerval.substring(0, 2)
            search = innerval.indexOf('/')

            if (inneridentifier == "88") {
                transformedBAI = transformedBAI + seperation + innerval.substring(3)
            } else {
                break;
            }

        }
        transformedBAI = transformedBAI + "\n"

    }

    if (messageLog != null && logger.equalsIgnoreCase("true")) {
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("Transformed-BAI File#", transformedBAI, "text/plain");
    }

    message.setBody(transformedBAI)
    return message;
}