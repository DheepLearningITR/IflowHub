import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Get the JSON string from the header
    def headers = message.getHeaders()
    def jsonString = headers.get("FormattedHTTPQuery")
    
    // Parse the JSON string
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(jsonString)

    // Initialize the writer for XML
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.setDoubleQuotes(true)

    // Define a mapping from JSON field names to XML field names only for "orderBy" field conversions 
    def fieldMapping = [
        'issueDate'              : 'ISSUE_DATE',
        'printDate'              : 'PRINT_DATE',
        'dunningProcedureCode'   : 'DUNNING_PROCEDURE',
        'dunningProcedureText'   : 'DUNNING_PROCEDURE_TEXT',
        'collectionStrategy'     : 'COLLECTION_STRATEGY',
        'collectionStrategyText' : 'COLLECTION_STRATEGY_TEXT',
        'dunningLevel'           : 'DUNNING_LEVEL',
        'dunningLevelText'       : 'DUNNING_LEVEL_TEXT',
        'collectionStep'         : 'COLLECTION_STEP',
        'collectionStepText'     : 'COLLECTION_STEP_TEXT',
        'statusCode'             : 'STATUS_CODE',
        'statusText'             : 'STATUS_TEXT',
        'nextDunningDate'        : 'NEXT_DUNNING_DATE',
        'paymentTargetDate'      : 'PAYMENT_TARGET_DATE'
    ]

    // Build the XML structure with namespace
    xml.'n0:IsuC4cV2DunningGet'('xmlns:n0': 'urn:sap-com:document:sap:soap:functions:mc-style') {
        jsonObject.each { key, value ->
            switch (key) {
                case 'top':
                    IvTop(value)
                    break
                case 'search':
                    IvSearchValue(value)
                    break
                case 'skip':
                    IvSkip(value)
                    break
                case 'orderBy':
                    // Convert the value if a mapping exists; otherwise, use the original value
                    def mappedValue = fieldMapping.get(value, value)
                    IvSortField(mappedValue)
                    break
                case 'orderByType':
                    IvSortType(value)
                    break
                case 'businessPartnerId':
                    ItBusinessPartner(value[0].value)
                    break
                case 'cancelledFlag':
                    IvCancelledDunning(value[0].value == 'true' ? 'X' : '')
                    break
                case 'collectionStepCode':
                    IvCollectionStep(value[0].value)
                    break
                case 'contractAccountId':
                    IvContractAccount(value[0].value)
                    break
                case 'dunningLevelCode':
                    IvDunningLevel(value[0].value)
                    break
                case 'dunningProcedureCode':
                    IvDunningProcedure(value[0].value)
                    break
                case 'dateFrom':
                    IvIssueDateFrom(value[0].value)
                    break
                case 'dateTo':
                    IvIssueDateTo(value[0].value)
                    break
                default:
                    // Handle any additional dynamic fields here if necessary
                    break
            }
        }

        // Always include ItFilter with constant values
        ItAdditionalFilter {
            'item' {
                Fieldname('QueryFilter')
                FieldValue(headers.get("QueryFilter"))
                Sign('I')
                Option('')
                Low("")
                High("")
            }
        }
    }

    // Set the XML output as the message body
    message.setBody(writer.toString())

    return message
}
