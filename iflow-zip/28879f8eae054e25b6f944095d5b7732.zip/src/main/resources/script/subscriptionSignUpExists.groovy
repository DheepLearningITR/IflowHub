import com.sap.it.api.mapping.*;

def String subscriptionSignUpExists(String propertyName, MappingContext context){
String subscriptionExists = propertyName;
switch(subscriptionExists)
{
    case "true":
        subscriptionExists = "Y";
        break;
    case "false":
        subscriptionExists = "N";
        break;
    default:
        subscriptionExists = "";
        break;
}
    return subscriptionExists; 
}