import com.sap.it.api.mapping.*;

//This method forms the Contact Origin Data URI
def String formUriAdditionalIDs(String contactId, String contactOrigin, String contactAdditionalOrigin, String contactAdditionalID){
	return "AdditionalIDs(ContactID='"+contactId+"',ContactOrigin='"+contactOrigin+"',ContactAdditionalOrigin='"+contactAdditionalOrigin+"',ContactAdditionalID='"+contactAdditionalID+"')";
}