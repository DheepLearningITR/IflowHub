import com.sap.it.api.mapping.*;

def String getPermissionGranted(String propertyName, MappingContext context){
String permissionGranted = propertyName;
switch(permissionGranted)
{
    case "true":
        permissionGranted = "Y";
        break;
    case "false":
        permissionGranted = "N";
        break;
    default:
        permissionGranted = "";
        break;
}
    return permissionGranted; 
}