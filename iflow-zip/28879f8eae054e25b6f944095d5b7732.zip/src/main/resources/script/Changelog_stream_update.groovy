/*
 The integration developer needs to create the method processData
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties)
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders)
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
def Message processData(Message message) {
       //Body
       def body = message.getBody();
       //Headers
       def map = message.getHeaders();
       message.setHeader("Content-Type", "application/x-www-form-urlencoded");
       message.setHeader("Accept", "application/json");
       //Properties
       map = message.getProperties();

       body_str = "apiKey=" + URLEncoder.encode(map.get("apiKey"), "UTF-8");
       body_str += "&userKey=" + URLEncoder.encode(map.get("userKey"), "UTF-8");
       body_str += "&secret=" + URLEncoder.encode(map.get("secret"), "UTF-8");
       
      if(map.get("openCursor")){
         def lastSuccessTimeStamps = [];
         def currentTime = new Date();
         def timeBefore;
         if(map.get("lastSuccess")){
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            def root = new XmlSlurper().parseText(new String(body));
            root.message.children().each { node ->
              lastSuccessTimeStamps.add(sdf.parse(node.toString()));
            }
            lastSuccessTimeStamps.sort();
            timeBefore = new Date(lastSuccessTimeStamps[lastSuccessTimeStamps.size() - 1].getTime());
            
            //Store current time 
            message.setProperty("currentTime", currentTime.format("dd-MM-yyyy HH:mm:ss"));
         }else{
            timeBefore = new Date(currentTime.getTime() - (30 * 60 * 1000));           //timeBefore = new Date(currentTime.getTime() - (Long.valueOf(map.get("runInterval")) * 60 * 1000));
            //Store current time 
            message.setProperty("currentTime", currentTime.format("dd-MM-yyyy HH:mm:ss"));
         }
         
         body_str += "&since=" + URLEncoder.encode(timeBefore.getTime().toString(), "UTF-8");
         body_str += "&openCursor=" + URLEncoder.encode(map.get("openCursor"), "UTF-8");
         body_str += "&query=" + URLEncoder.encode('select * from changelog where type in ("move","merge","upsert","delete") limit 100');    //("move","merge","upsert","delete")
      } else {
         body_str += "&cursorId=" + URLEncoder.encode(map.get("nextCursorId"), "UTF-8");
      }

       message.setBody(body_str);

       return message;
}
