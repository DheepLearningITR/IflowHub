import com.sap.it.api.mapping.*;

def String getPermissionId(String propertyName, MappingContext context){
String permissionId = propertyName;
switch(permissionId)
{
    case "Email":
        permissionId = "email";
        break;
    case "EMAIL":
        permissionId = "email";
        break;
    case "Sms":
        permissionId = "phoneNumber";
        break;
    case "SMS":
        permissionId = "phoneNumber";
        break;
    default:
        permissionId = "email";
        break;
}
    return permissionId; 
}