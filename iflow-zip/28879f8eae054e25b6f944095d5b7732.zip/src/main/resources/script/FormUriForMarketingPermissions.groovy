import com.sap.it.api.mapping.*;

//This method forms the Contact Origin Data URI
def String formUriMarketingPermission(String contactId, String contactOrigin, String contactPermissionId, String contactPermissionOrigin, String marketingArea, String communicationMedium){
	return "MarketingPermissions(ContactID='"+contactId+"',ContactOrigin='"+contactOrigin+"',ContactPermissionID='"+contactPermissionId+"',ContactPermissionOrigin='"+contactPermissionOrigin+"',MarketingArea='"+marketingArea+"',CommunicationMedium='"+communicationMedium+"')";
}