import com.sap.it.api.mapping.*;

def String getCommMedium(String propertyName, MappingContext context){
String commMedium = propertyName;
switch(commMedium)
{
    case "Email":
        commMedium = "EMAIL";
        break;
    case "EMAIL":
        commMedium = "EMAIL";
        break;
    case "Sms":
        commMedium = "SMS";
        break;
    case "SMS":
        commMedium = "SMS";
        break;
    default:
        commMedium = "EMAIL";
        break;
}
    return commMedium; 
}