import com.sap.it.api.mapping.*;

//This method forms the Contact Origin Data URI
def String formUriContactOriginDeleteAdditionalIDs(String contactId, String contactOrigin){
	return "ContactOriginDeleteAdditionalIDs?ContactID='"+contactId+"'&ContactOrigin='"+contactOrigin+"'";
}