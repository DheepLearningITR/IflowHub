/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.net.URLEncoder;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    
  // Save current payload for future processing
  //message.setProperty("cdcQueryPayload",message.getBody(java.lang.String));

  def body = message.getBody();
  def results = new XmlSlurper().parseText(body);
  def subscriptionName1 = [];
  def subscriptionName2 = [];

  results.subscriptions.children().each { node ->
    println node;
    subscriptionName1.add(node.name());
  }
  println subscriptionName1;

  for(i=0; i<subscriptionName1.size(); i++){
      results.subscriptions.children().each { node ->
          node.find {it.name() == subscriptionName1[i]  }.replaceNode {
              Newsletter {
                  email{
                      isSubscribed(node.email.isSubscribed.text())
                      lastUpdatedSubscriptionState(node.email.lastUpdatedSubscriptionState.text())
                      doubleOptIn{
                          status(node.email.doubleOptIn.status.text())
                      }
                  }
              }
          }
      }
  }

  results = new XmlSlurper().parseText(XmlUtil.serialize(results))
  results.subscriptions.children().each { node ->
      subscriptionName2.add(node.name());
  }

  println subscriptionName2;

  def result = results.collect { 
    XmlUtil.serialize(it).replaceAll(/<.xml.*?>/,"") 
  }

  message.setProperty("subscriptionTopicCount", 0);
  for(i=0;i<subscriptionName1.size();i++){
    message.setProperty("subscriptionTopicName" + i,subscriptionName1[i]);
  }
  
  message.setBody(result[0]);
   
  return message;
}