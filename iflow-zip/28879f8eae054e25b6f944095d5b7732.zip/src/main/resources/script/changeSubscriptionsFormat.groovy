import groovy.xml.XmlUtil;
import com.sap.it.api.mapping.*;

def String changeSubscriptionsFormat(String property, MappingContext context){
    //println("Hello world")
    //String xml = "<subscriptions><brand1DailyNewsletter><email><isSubscribed>false</isSubscribed><lastUpdatedSubscriptionState>2020-03-07T15:55:19.789Z</lastUpdatedSubscriptionState> <doubleOptIn><status>NotConfirmed</status></doubleOptIn></email> </brand1DailyNewsletter><brand2DailyNewsletter><email><isSubscribed>true</isSubscribed> <lastUpdatedSubscriptionState>2020-04-07T15:55:19.789Z</lastUpdatedSubscriptionState> <doubleOptIn><status>NotConfirmed</status></doubleOptIn></email> </brand2DailyNewsletter></subscriptions>";
    println property;
    def subscriptions = new XmlSlurper().parseText(property);
    //subscriptions.iterator().each{ System.out.println( it.name() ) }
    def node1 = [];
    def node2 = [];

    subscriptions.children().each { node ->
        node1.add(node.name());
    }
    println node1;

    for(i=0; i<node1.size(); i++){
        subscriptions.children().each { node ->
            node.find {it.name() == node1[i]  }.replaceNode {
                Newsletter {
                    email{
                        isSubscribed(node.email.isSubscribed)
                        lastUpdatedSubscriptionState(node.email.lastUpdatedSubscriptionState)
                        doubleOptIn{
                            status(node.email.doubleOptIn.status)
                        }
                    }
                }
            }
        }
    }

    // subscriptions.children().find{it.name() == "brand1DailyNewsletter"}.replaceNode{
    // }
    subscriptions = new XmlSlurper().parseText(XmlUtil.serialize(subscriptions));
    subscriptions.children().each { node ->
        node2.add(node.name());
    }

    println node2;
    println subscriptions.children().toString();

    //assert subscriptions.brand1DailyNewsletter.size() == 1;
    // def reader = new StringReader(xml);
    // def doc = DOMBuilder.parse(reader);
    //def subscriptions = doc.documentElement;

    // use(DOMCategory) { 
    //     assert subscriptions.brand1DailyNewsletter.size() == 1;
    // }
    //def field1 = subscriptions.text();
    //def field4 = subscriptions.Line.Field4.text();

    //System.out.println("Value of Field1 = " + subscriptions.name()  );
    //System.out.println("Value of Field1 = " + subscriptions.children().size());
    //System.out.println("Value of /Records/Line/Field4 = " + field4);
    return subscriptions.Newsletter;

}




