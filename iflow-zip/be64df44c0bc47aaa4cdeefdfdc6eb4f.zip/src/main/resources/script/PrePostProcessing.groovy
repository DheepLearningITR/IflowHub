import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil

def Message processData(Message message) {
    
    def body = message.getBody(java.io.Reader)
    def xml = new XmlSlurper().parse(body)
    
    def messages = xml.'**'.findAll {
        it.name() == 'BusinessPartnerRelationshipSUITEReplicateRequestMessage'
    }
    def toRemove = []
    messages.each {
        msg -> if (msg.BusinessPartnerRelationship.@actionCode == '05') {
            def bpInternalID = msg.BusinessPartnerRelationship.BusinessPartnerInternalID.text()
            def receiverBpInternalID = msg.BusinessPartnerRelationship.ReceiverBusinessPartnerInternalID.text()
            def relBpInternalID = msg.BusinessPartnerRelationship.RelationshipBusinessPartnerInternalID.text()
            def receiverRelBpInternalID = msg.BusinessPartnerRelationship.ReceiverRelationshipBusinessPartnerInternalID.text()
            def roleCode = msg.BusinessPartnerRelationship.RoleCode.text()
            // Check for matching actionCode="04" node
            def matchingNode = messages.find {
                otherMsg -> otherMsg.BusinessPartnerRelationship.@actionCode == '04' && 
                    otherMsg.BusinessPartnerRelationship.BusinessPartnerInternalID.text() == bpInternalID && 
                    otherMsg.BusinessPartnerRelationship.ReceiverBusinessPartnerInternalID.text() == receiverBpInternalID && 
                    otherMsg.BusinessPartnerRelationship.RelationshipBusinessPartnerInternalID.text() == relBpInternalID && 
                    otherMsg.BusinessPartnerRelationship.ReceiverRelationshipBusinessPartnerInternalID.text() == receiverRelBpInternalID && 
                    otherMsg.BusinessPartnerRelationship.RoleCode.text() == roleCode
            }
            if (matchingNode) {
                toRemove << msg
            }
        }
    }
    // Remove matching nodes
    toRemove.each {
        node -> node.replaceNode {
            
        }
    }
    // Serialize the modified XML
    def writer = new StringWriter()
    XmlUtil.serialize(xml, writer)
    message.setBody(writer.toString())
    return message
}

