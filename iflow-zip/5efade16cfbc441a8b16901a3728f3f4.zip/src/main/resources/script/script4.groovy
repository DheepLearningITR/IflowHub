import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def bpnList = message.getProperties().get('EDC_Policy_BPN_List')
    def collectDataRecord = message.getHeaders().get('collectDataRecord')

    if (collectDataRecord.vendorBPN) {
        if (bpnList && !bpnList.contains(collectDataRecord.vendorBPN)) {
            StringBuilder sb = new StringBuilder()
            sb.append(bpnList).append(',').append(collectDataRecord.vendorBPN)
            bpnList = sb.toString()
        } else {
            bpnList = collectDataRecord.vendorBPN
        }
    } else if (collectDataRecord.customerBPN) {
        if (bpnList && !bpnList.contains(collectDataRecord.customerBPN)) {
            StringBuilder sb = new StringBuilder()
            sb.append(bpnList).append(',').append(collectDataRecord.customerBPN)
            bpnList = sb.toString()
        } else {
            bpnList = collectDataRecord.customerBPN
        }
    }

    def policyPayloadMap = [:]
    
    def globalAssetId = message.getHeaders().get('globalAssetId')
	def contextMap = [:]
    contextMap.odrl = 'http://www.w3.org/ns/odrl/2/'
    contextMap.edc = 'https://w3id.org/edc/v0.0.1/ns/'
    policyPayloadMap.'@context' = contextMap
	getPolicyPayLoad(policyPayloadMap, bpnList, globalAssetId)
    def edcjson = new JsonBuilder(policyPayloadMap)
    message.setBody(edcjson.toPrettyString())
    return message
}

def getPolicyPayLoad(def policyPayloadMap, def inBPNList, def globalAssetId) {
    def policyMap = [:]
	def permissionsArray = []
	def permissionsMap = [:]
	def propertyMap = [:]
	def privatePropertyMap = [:]
	def uid = UUID.randomUUID().toString()
	policyPayloadMap.'@id' = uid
	policyPayloadMap.'@type' = 'edc:PolicyDefinition'
    
	if (inBPNList) {
        def constraintsMap = [:]
        def orConstraintsArray = []
        def splitArray = inBPNList.split(',')
        permissionsMap.'odrl:action' = 'USE'
        if (splitArray != null && splitArray.size() > 0) {
            for (int i = 0; i < splitArray.size(); i++) {
                buildOrConstraints(orConstraintsArray, splitArray[i])
            }
        } else {
            buildOrConstraints(orConstraintsArray, inBPNList)
        }
        constraintsMap.'@type' = 'LogicalConstraint'
        constraintsMap.'odrl:or' = orConstraintsArray
        permissionsMap.'odrl:constraint' = constraintsMap
	}
	permissionsArray << permissionsMap
	policyMap.'@type' = 'odrl:Set'
	policyMap.'odrl:permission' = permissionsArray
	propertyMap.'edc:name' = uid
	propertyMap.'edc:description' = globalAssetId
    policyMap.'edc:properties' = propertyMap
    privatePropertyMap.'edc:policyType' = 'access'
    policyMap.'edc:privateProperties' = privatePropertyMap
	policyPayloadMap.'edc:policy' = policyMap
}

def buildOrConstraints(def orConstraintsArray, def value) {
	def expressionMap = [:]
	def operatorMap = [:]
    // Left
    expressionMap.'@type' = 'Constraint'
    expressionMap.'odrl:leftOperand' = 'BusinessPartnerNumber'
    // Operator
    operatorMap.'@id' = 'odrl:eq'
    expressionMap.'odrl:operator' = operatorMap
    //Right
    expressionMap.'odrl:rightOperand' = value
    orConstraintsArray << expressionMap
}
