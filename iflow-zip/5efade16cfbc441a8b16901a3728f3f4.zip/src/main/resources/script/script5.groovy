import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    def globalAssetId = message.getHeaders().get('globalAssetId')
    def assetId = message.getHeaders().get('assetId')

    def uid = UUID.randomUUID().toString()
    def assetsSelectorArray = []
    def contractDefinitionsPayloadMap = [:]
    def contextMap = [:]

    contextMap.'@vocab' = 'https://w3id.org/edc/v0.0.1/ns/'
    contractDefinitionsPayloadMap.'@context' = contextMap

    //contractDefinitionsPayloadMap.'@context' = []
    contractDefinitionsPayloadMap.'@type' = 'ContractDefinitionRequestDto'
    contractDefinitionsPayloadMap.'@id' = uid
    contractDefinitionsPayloadMap.name = uid
    contractDefinitionsPayloadMap.description = globalAssetId
    contractDefinitionsPayloadMap.accessPolicyId = input.'@id'
    contractDefinitionsPayloadMap.contractPolicyId = input.'@id'

    buildAssetsSelector(assetsSelectorArray, assetId)
	contractDefinitionsPayloadMap.assetsSelector = assetsSelectorArray

    def edcjson = new JsonBuilder(contractDefinitionsPayloadMap)
    message.setBody(edcjson.toPrettyString())
    return message
}

def buildAssetsSelector(def assetsSelectorArray, def assetId) {
	def assetsSelectorMap = [:]
	assetsSelectorMap.'@type' = 'CriterionDto'
	assetsSelectorMap.operandLeft = 'https://w3id.org/edc/v0.0.1/ns/id'
	assetsSelectorMap.operator = '='
	assetsSelectorMap.operandRight = assetId
	assetsSelectorArray << assetsSelectorMap
}
