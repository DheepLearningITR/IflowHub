import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def inputPayload = new JsonSlurper().parse(json)
    def eventsDataArray = []
    def endPayLoad = [:]

    message.setHeader('hasDeliverEventsData','N')

    // Only work on data if a Deliver Event is present
    if (inputPayload.EventPackage.DeliverSerialNumberEvents == null && inputPayload.EventPackage.DeliverEvents == null) {
        return message
    }    

    // ProduceEvents
    if (inputPayload.EventPackage.ProduceEvents && inputPayload.EventPackage.DeliverEvents) {
        if (inputPayload.EventPackage.ProduceEvents instanceof List) {
            inputPayload.EventPackage.ProduceEvents.each {
                createProduceEventsData(eventsDataArray, it)
            }
        } else {
            createProduceEventsData(eventsDataArray, inputPayload.EventPackage.ProduceEvents)
        }
    }

    // ProduceSerialNumberEvents
    if (inputPayload.EventPackage.ProduceSerialNumberEvents && inputPayload.EventPackage.DeliverSerialNumberEvents) {
        if (inputPayload.EventPackage.ProduceSerialNumberEvents instanceof List) {
            inputPayload.EventPackage.ProduceSerialNumberEvents.each {
                createProduceSerialNumberEventsData(eventsDataArray, it)
            }
        } else {
            createProduceSerialNumberEventsData(eventsDataArray, inputPayload.EventPackage.ProduceSerialNumberEvents)
        }
    }
        
    // DeliverEvents
    if (inputPayload.EventPackage.DeliverEvents) {
        message.setHeader('hasDeliverEventsData','Y')
        if (inputPayload.EventPackage.DeliverEvents instanceof List) {
            inputPayload.EventPackage.DeliverEvents.each {
                createDeliverEventsData(eventsDataArray, 'batch', it)
            }
        } else {
            createDeliverEventsData(eventsDataArray, 'batch', inputPayload.EventPackage.DeliverEvents)
        }
    }

    // DeliverSerialNumberEvents
    if (inputPayload.EventPackage.DeliverSerialNumberEvents) {
        message.setHeader('hasDeliverEventsData','Y')
        if (inputPayload.EventPackage.DeliverSerialNumberEvents instanceof List) {
            inputPayload.EventPackage.DeliverSerialNumberEvents.each {
                createDeliverEventsData(eventsDataArray, 'serial', it)
            }
        } else {
            createDeliverEventsData(eventsDataArray, 'serial', inputPayload.EventPackage.DeliverSerialNumberEvents)
        }
    }

    // ReceiveEvents
    if (inputPayload.EventPackage.ReceiveEvents && inputPayload.EventPackage.DeliverEvents) {
        if (inputPayload.EventPackage.ReceiveEvents instanceof List) {
            inputPayload.EventPackage.ReceiveEvents.each {
                createReceiveEventsData(eventsDataArray, it)
            }
        } else {
            createReceiveEventsData(eventsDataArray, inputPayload.EventPackage.ReceiveEvents)
        }
    }

    // ReceiveSerialNumberEvents
    if (inputPayload.EventPackage.ReceiveSerialNumberEvents && inputPayload.EventPackage.DeliverSerialNumberEvents) {
        if (inputPayload.EventPackage.ReceiveSerialNumberEvents instanceof List) {
            inputPayload.EventPackage.ReceiveSerialNumberEvents.each {
                createReceiveEventsData(eventsDataArray, it)
            }
        } else {
            createReceiveEventsData(eventsDataArray, inputPayload.EventPackage.ReceiveSerialNumberEvents)
        }
    }

    endPayLoad.events = eventsDataArray
    def aasJson = new JsonBuilder(endPayLoad)

    message.setBody(aasJson.toPrettyString())
    return message
}

def createProduceEventsData(def eventsDataArray, def produceEvents) {
    def key = new StringBuilder()
    key.append(produceEvents.BatchID).append('_').append(produceEvents.ProductID).append('_').append(produceEvents.SystemID)
    def eventsDataMap = [:]
    eventsDataMap.type = 'batch'
    eventsDataMap.id = key.toString()
    eventsDataMap.systemId = produceEvents.SystemID
    eventsDataMap.batchId = produceEvents.BatchID
    eventsDataMap.partInstanceId = produceEvents.BatchID
    eventsDataMap.manufacturerPartId = produceEvents.ProductID
    eventsDataMap.productName = getValue(produceEvents.ProductName)
    eventsDataMap.globalAssetId = getKeyAssignments(produceEvents.KeyAssignments, 'CATENA_X_BATCH')
    if (produceEvents.Components) {
        eventsDataMap.assemblyPartRelation = 'Y'
        getComponents(eventsDataMap, produceEvents.Components)
    }
    eventsDataArray << eventsDataMap
}

def createProduceSerialNumberEventsData(def eventsDataArray, def produceSerialNumberEvents) {
    if (produceSerialNumberEvents.SerialNumbers instanceof List) {
        produceSerialNumberEvents.SerialNumbers.each {
            createEventDataMap(eventsDataArray, produceSerialNumberEvents, it)
        }
    } else {
        createEventDataMap(eventsDataArray, produceSerialNumberEvents, produceSerialNumberEvents.SerialNumbers)
    }
}

def createEventDataMap(def eventsDataArray, def produceEvents, def serialNumbers) {
    def key = new StringBuilder()
    key.append(serialNumbers.SerialID).append('_').append(produceEvents.ProductID).append('_').append(produceEvents.SystemID)
    def eventsDataMap = [:]
    eventsDataMap.type = 'serial'
    eventsDataMap.id = key.toString()
    eventsDataMap.systemId = produceEvents.SystemID
    eventsDataMap.partInstanceId = serialNumbers.SerialID
    eventsDataMap.manufacturerPartId = produceEvents.ProductID
    eventsDataMap.productName = produceEvents.ProductDetail.ProductName
    eventsDataMap.globalAssetId = getKeyAssignments(produceEvents.SerialNumbers.KeyAssignments, 'CATENA_X_PART')
    if (serialNumbers.ComponentSerialNumbers) {
        eventsDataMap.assemblyPartRelation = 'Y'
        getComponentSerialNumbers(eventsDataMap, serialNumbers.ComponentSerialNumbers)
    }
    if (produceEvents.Components) {
        eventsDataMap.assemblyPartRelation = 'Y'
        getComponents(eventsDataMap, produceEvents.Components)
    }
    eventsDataArray << eventsDataMap
}

def getComponentSerialNumbers(def eventsDataMap, def ComponentSerialNumbers) {
    def componentsArray = []
    if (ComponentSerialNumbers instanceof List) {
        ComponentSerialNumbers.each {
            def componentsMap = [:]
            componentsMap.SerialId = it.SerialID
            componentsMap.ProductId = it.ProductID
            componentsMap.SystemId = it.SystemID
            componentsArray << componentsMap
        }
    } else {
        def componentsMap = [:]
        componentsMap.SerialId = ComponentSerialNumbers.SerialID
        componentsMap.ProductId = ComponentSerialNumbers.ProductID
        componentsMap.SystemId = ComponentSerialNumbers.SystemID
        componentsArray << componentsMap
    }
    eventsDataMap.components = componentsArray
}

def getComponents(def eventsDataMap, def Components) {
    def componentsArray = []
    if (eventsDataMap.components) {
        componentsArray = eventsDataMap.components
    }
    if (Components instanceof List) {
        Components.each {
            def componentsMap = [:]
            componentsMap.BatchId = it.BatchID
            componentsMap.ProductId = it.ProductID
            componentsMap.SystemId = it.SystemID
            componentsArray << componentsMap
        }
    } else {
        def componentsMap = [:]
        componentsMap.BatchId = Components.BatchID
        componentsMap.ProductId = Components.ProductID
        componentsMap.SystemId = Components.SystemID
        componentsArray << componentsMap
    }
    eventsDataMap.components = componentsArray
}

def createDeliverEventsData(def eventsDataArray, def type, def inDeliverEvents){
    def key = new StringBuilder()
    if (type == 'serial') {
        key.append(inDeliverEvents.SerialNumbers.SerialID).append('_').append(inDeliverEvents.ProductID).append('_').append(inDeliverEvents.SystemID)
    } else {
        key.append(inDeliverEvents.VendorBatchID).append('_').append(inDeliverEvents.ProductID).append('_').append(inDeliverEvents.SystemID)
    }
    def eventsDataMap = [:]
    eventsDataMap.type = type
    eventsDataMap.id = key.toString()
    eventsDataMap.systemId = inDeliverEvents.SystemID
    if (type == 'serial') {
        eventsDataMap.partInstanceId = inDeliverEvents.SerialNumbers.SerialID
    } else {
        eventsDataMap.batchId = inDeliverEvents.VendorBatchID
        eventsDataMap.partInstanceId = inDeliverEvents.VendorBatchID
    }
    eventsDataMap.manufacturerPartId = inDeliverEvents.ProductID
    eventsDataMap.customerBPN = getKeyAssignments(inDeliverEvents.KeyAssignments, 'CATENA_X_CUSTOMER')
    eventsDataMap.assemblyPartRelation = 'N'
    eventsDataArray << eventsDataMap
}

def createReceiveEventsData(def eventsDataArray, def ReceiveEvents) {
    if (eventsDataArray) {
        if (eventsDataArray instanceof List) {
            eventsDataArray.each {
                appendVenderBPN(it, ReceiveEvents)
            }
        } else {
            appendVenderBPN(eventsDataArray, ReceiveEvents)
        }
    }
}

def appendVenderBPN(def inEventsDataArray, def inReceiveEvents){
    if (inEventsDataArray.type == 'serial') {
        def key
        if (inReceiveEvents.SerialNumbers instanceof List) {
            key = inReceiveEvents.SerialNumbers[0].SerialID
        } else {
            key = inReceiveEvents.SerialNumbers.SerialID
        }
        def component = inEventsDataArray.components.find{it.SerialId == key}
        if (component != null && component.size() > 0) {
            inEventsDataArray.put('vendorBPN', getKeyAssignments(inReceiveEvents.KeyAssignments, 'CATENA_X_VENDOR'))
        }
    }
    else if (inEventsDataArray.type == 'batch') {
        def key = inReceiveEvents.BatchID
        def component = inEventsDataArray.components.find{it.BatchId == key}
        if (component != null && component.size() > 0) {
            inEventsDataArray.put('vendorBPN', getKeyAssignments(inReceiveEvents.KeyAssignments, 'CATENA_X_VENDOR'))
        }
    }
}

def getKeyAssignments(def keyAssignments, def qualifier) {
    def  res = ''
    if (keyAssignments) {
        if (keyAssignments instanceof List) {
            keyAssignments.each {
                if (it.Qualifier == qualifier) {
                    res = it.Value
                }
            }
	    }else {
	        if (keyAssignments.Qualifier == qualifier) {
                res = keyAssignments.Value
	        } else {
                res = ''
            }
        }
    } else {
        res = ''
    }
    return res
}

def getProperties(def properties, def name) {
    def  res = ''
    if (properties) {
        if (properties instanceof List) {
            properties.each {
                if (it.Name == name) {
                    res = it.Value
                }
            }
        }else {
            res = properties.Value
        }
    } else {
        res = ''
    }
    return res
}

def getValue(def inValue) {
    def  res = ''
    if (inValue) {
        if (inValue.$) {
           res = inValue.$
        }else {
            res =inValue
        }
    } else {
        res = ''
    }
    return res
}
