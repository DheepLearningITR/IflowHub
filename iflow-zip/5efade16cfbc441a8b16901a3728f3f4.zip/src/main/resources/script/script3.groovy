import com.sap.gateway.ip.core.customdev.util.Message
import org.apache.commons.codec.binary.Base64
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    Reader json = message.getBody(java.io.Reader)
    def input = new JsonSlurper().parse(json)
    def partTypizationMap = [:]
    getPartTypizationMap(partTypizationMap, input, message)
    def edcjson = new JsonBuilder(partTypizationMap)

    message.setBody(edcjson.toPrettyString())
    return message
}

def getPartTypizationMap(def partTypizationMap, def input, Message message ) {
	def edc_name
	def urlFunction
	def subModel
	if (input.type.equals('batch')) {
		edc_name = 'Submodel Batch'
        urlFunction = '/http/api/v3.0/serial_part/'
        subModel = '/SerialPart'
	} else if (input.type.equals('serialPartTypization')) {
	    edc_name =  'Submodel SerialPartTypization'
	    urlFunction = '/http/api/v3.0/serial_part/'
        subModel = '/SerialPart'
    } else if (input.type.equals('assemblyPartRelationship')) {
        edc_name =  'Submodel Single Level BOM as Built'
        urlFunction = '/http/api/v3.0/single_level_bom_as_built/'
        subModel = '/SingleLevelBomAsBuilt'
    } else {
        return 
    }
    def endPoint = message.getProperties().get('AssetAddress_Endpoint')
	def authCode = message.getProperties().get('AssetAddress_AuthCode')
	def authKey = message.getProperties().get('AssetAddress_AuthKey')
	def contextMap = [:]
	def assetMap = [:]
	def dataAddressMap = [:]
	def propertiesMap = [:]
    contextMap.edc = 'https://w3id.org/edc/v0.0.1/ns/'
    contextMap.'@vocab' = 'https://w3id.org/edc/v0.0.1/ns/'
    partTypizationMap.'@context' = contextMap
	StringBuilder sb = new StringBuilder()
	sb.append('urn:aas:').append(input.vendorBPN).append(subModel).append('/urn:uuid:').append(input.globalAssetId)
	def assetId = sb.toString()
	byte[] bytesEncoded = Base64.encodeBase64(assetId.getBytes())
	def assetIdEncoded = new String(bytesEncoded)
	assetMap.'@type' = 'Asset'
	assetMap.'@id' = assetIdEncoded
	assetMap.'edc:type' = 'Asset'
	message.setHeader('assetId', assetIdEncoded)
	sb = new StringBuilder()
	sb.append('urn:uuid:').append(input.globalAssetId)
	message.setHeader('globalAssetId', sb.toString())
	assetMap.'edc:name' = sb.toString()
	assetMap.'edc:description' = edc_name
	assetMap.'edc:version' = '0.5.0'
	assetMap.'edc:contenttype' = 'application/json'
	propertiesMap.additionalDescription = 'Asset'
	assetMap.'edc:properties' = propertiesMap
	partTypizationMap.'edc:asset' = assetMap
	dataAddressMap.'@type' = 'DataAddress'
	dataAddressMap.type = 'HttpData'
	sb = new StringBuilder()
	sb.append(endPoint).append(urlFunction).append('urn%3Auuid%3A').append(input.globalAssetId).append('/$value')
	dataAddressMap.baseUrl = sb.toString()
	dataAddressMap.authKey = authKey
	dataAddressMap.authCode = authCode
    dataAddressMap.proxyBody ='true'
    dataAddressMap.proxyPath = 'true'
    dataAddressMap.proxyQueryParams = 'true'
    dataAddressMap.proxyMethod = 'true'
    dataAddressMap.contenttype = 'application/octet-stream'
	partTypizationMap.'edc:dataAddress' = dataAddressMap
}
