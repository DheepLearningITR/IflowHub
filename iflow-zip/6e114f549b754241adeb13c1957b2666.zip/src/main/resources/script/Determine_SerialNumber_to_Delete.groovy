import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    
    CRM_SerialNumbers = message.getProperty('CRM_SerialNumbers');
    ArrayList FSM_SerialNumbers = []
    def parsedObj = new JsonSlurper().parseText(body);
    
    parsedObj.data.each{
        FSM_SerialNumbers.add(it.s.externalId);
    }

    CRM_SerialNumbers.intersect(FSM_SerialNumbers).each{FSM_SerialNumbers.remove(it)}

    String Delete_JSON_str = "";
    FSM_SerialNumbers.each{
        if (Delete_JSON_str == ""){
            Delete_JSON_str = '{\"externalId\" : ' + '\"'+it+'\"}]';
        }
        else
        {
            Delete_JSON_str = '{\"externalId\" : ' + '\"'+it+'\"}, ' + Delete_JSON_str; 
        }
    }
    
    if (Delete_JSON_str == "")
    {
        message.setProperty('CRM_SerialNumbers','DELETE_NOTHING');
    }
    else
    {
        Delete_JSON_str = '[' + Delete_JSON_str;
        message.setBody(Delete_JSON_str);
    }

    return message;
}
