import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def parsedObj = new JsonSlurper().parseText(body);
    JsonBuilder builder = new JsonBuilder(parsedObj.data);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
    
    message.setBody(jsonBody);
    return message;
}
