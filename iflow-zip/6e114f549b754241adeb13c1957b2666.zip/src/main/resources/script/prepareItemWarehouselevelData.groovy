import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def query = new XmlSlurper().parseText(body);
    def map = message.getProperties();
    def codeToIdMapString = map.get("codeToIdMap");
    
    def codeToIdMap = 
    // Take the String value between
    // the [ and ] brackets.
    codeToIdMapString[1..-2]
    // Split on , to get a List.
    .split(', ')
    // Each list item is transformed
    // to a Map entry with key/value.
    .collectEntries { entry -> 
        def pair = entry.split(':')
        [(pair.first()): pair.last()]
    }
    
    query.data.each {
        if(codeToIdMap[it.item.externalId.toString()] == null) {
            it.replaceNode { };
        }
    }
    query = XmlUtil.serialize(query);
        
    message.setBody(query);
    return message;
}
