import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.util.XmlSlurper;
import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def parsedObj = new XmlSlurper().parseText(body);
    def map = message.getProperties();
    def codeToIdMapString = map.get("codeToIdMap");
    String SerialNumber_DTO = map.get("SerialNumber_DTO");
    String Item_DTO = map.get("Item_DTO");
    def WarehouseID = map.get("WarehouseID");
    String param = "(";
    String queryContent;
    ArrayList ItemList = [];
    ArrayList CRM_SerialNumbers = [];
    
    parsedObj.data.each{
        CRM_SerialNumbers.add(it.externalId.text());
    }
    message.setProperty("CRM_SerialNumbers",CRM_SerialNumbers);
    
    def codeToIdMap = 
    codeToIdMapString[1..-2]
    .split(', ')
    .collectEntries { entry -> 
        def pair = entry.split(':')
        [(pair.first()): pair.last()]
    }
    
    ItemList = codeToIdMap.keySet() as String[];
    ItemList.each {param += "\'" + it + "\'" + ","}
    param = param.substring(0, param.length()-1);
    param += ")";
    
    String newJson="{}";
    def jsonSlurper = new JsonSlurper();
    def newJsonObject = jsonSlurper.parseText(newJson);
    
    queryContent = "SELECT s.externalId FROM SerialNumber s JOIN Item i ON s.item = i.id WHERE s.externalId IS NOT NULL AND i.externalId IN" + param + " AND s.warehouse = '" + WarehouseID + "'" ;
    message.setProperty("query_dtos", SerialNumber_DTO + ";" + Item_DTO);
    newJsonObject.put("query", queryContent)
    
    message.setBody(JsonOutput.toJson(newJsonObject));
    return message;
}
