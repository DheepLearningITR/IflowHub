import com.sap.it.api.mapping.*;

def String formatExternalId(String value) {
    if (value.matches("^[0-9]*\$") == true) {
        value = String.format("%040d", Integer.parseInt(value));
    }

	return value;
}
