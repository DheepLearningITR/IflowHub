import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def parsedObj = new XmlSlurper().parseText(body);
    String query = "{\"query\": \"SELECT w from Warehouse w WHERE w.externalId IN (";
    String s = '\'';
    String e = '\')\"}';
    String id = parsedObj.data.externalId.toString();
    
    query = query + s + id + e; 
    message.setProperty("WarehouseExternalId", id);
    
    message.setBody(query);
    return message;
}
