import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def parsedObj = new JsonSlurper().parseText(body);
    def prop = message.getProperties();
    def codeToIdMapEmp = prop.get("codeToIdMapEmp");
    def parseJson = new JsonSlurper().parseText(codeToIdMapEmp);
    def ownersArr = new String[1];
       
    if(parseJson[parsedObj.data[0].owners.toString()] != null){
        ownersArr = [parseJson[parsedObj.data[0].owners.toString()].toString()]; 
    }else{
        ownersArr = [parseJson[parsedObj.data[0].owners.toString().replaceFirst("^0+(?!\$)", "")].toString()]; 
    }
    parsedObj.data[0].owners = ownersArr;
    
    JsonBuilder builder = new JsonBuilder(parsedObj.data);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
       
    message.setBody(jsonBody);
    message.setProperty("RequestPayload", jsonBody);
    return message;
}
