import groovy.json.JsonSlurper;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def parsedObj = new JsonSlurper().parseText(body);
    def codeToIdJson = [:];
    def itr=0;

    parsedObj.data.each{
        codeToIdJson[parsedObj.data[itr]["itm"]["externalId"]] = parsedObj.data[itr]["itm"]["id"];
        itr = itr + 1;
    };
    
    if (codeToIdJson.isEmpty() == true) {
        message.setProperty("NoItemFound", 'true');
    } else {
        message.setProperty("NoItemFound", 'false');
        codeToIdJson = codeToIdJson.toString();
        message.setProperty("codeToIdMap", codeToIdJson);
    }
    
    return message;
}
