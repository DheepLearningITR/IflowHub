import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    //Get Body and parse it.
    def body = message.getBody(String.class);
    def parsedObj = new XmlSlurper().parseText(body);
    String query = "{\"query\": \"SELECT itm.id,itm.externalId from Item itm WHERE itm.externalId IN (";
    String s = '\'';
    String e = '\',';
    String eend = '\')\"}';
    String whereIn;
      
    parsedObj.IDOC.E101COD_S_STOCK_ROOT.E101COD_S_STOCK.E101COD_S_MATNR_STOCK.each{
        if (whereIn == null) {
            id = it.MATNR.toString();
            if (id.matches("^[0-9]*\$") == true) {
                whereIn = s + String.format("%040d", Integer.parseInt(id)) + eend;
            } else {
                whereIn = s + id + eend;
            }
        }
        else {
            id = it.MATNR.toString();
            if (id.matches("^[0-9]*\$") == true) {
                whereIn = s + String.format("%040d", Integer.parseInt(id)) + e + whereIn;
            } else {
                whereIn = s + id + e + whereIn;
            }
        }
    };
    
    //Set final query statement which has to be send as payload of the query API request     
    query = query + whereIn;
    
    // Set the query in the message body   
    message.setBody(query);
    return message;
}
