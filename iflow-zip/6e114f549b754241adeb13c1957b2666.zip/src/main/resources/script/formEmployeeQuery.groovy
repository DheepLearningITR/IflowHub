import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def parsedObj = new XmlSlurper().parseText(body);
    String query = "{\"query\": \"SELECT up.id, up.code from UnifiedPerson up WHERE up.code IN (";
    String s = '\'';
    String e = '\',';
    String eend = '\')\"}';
    String whereIn;
    String id;
    
    parsedObj.IDOC.E101COD_S_STOCK_ROOT.E101COD_S_STOCK.each{
        if (whereIn == null) {
            id = it.SERVICE_TECH.toString();
            whereIn = s + id + eend;
        }
        else {
            id = it.SERVICE_TECH.toString();
            whereIn = s + id + e + whereIn;
        }
    };
    query = query + whereIn;
    
    message.setBody(query);
    return message;
}
