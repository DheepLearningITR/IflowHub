import groovy.json.JsonSlurper;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def fsmWarehouseID = "";
    def parsedObj = new JsonSlurper().parseText(body);

    if(!(parsedObj.data.isEmpty())){
        fsmWarehouseID = parsedObj.data[0].w.id.toString()
        fsmWarehouseID = fsmWarehouseID.toString();
    }

    message.setProperty("fsmWarehouseID",fsmWarehouseID);
    return message;
}
