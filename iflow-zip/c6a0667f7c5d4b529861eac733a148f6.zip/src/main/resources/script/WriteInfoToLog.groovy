import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
       map = message.getProperties();
       CPQQuoteID = map.get("CPQ_QuoteNumber");
       S4QuoteID = map.get("S4_BusinessSolutionQuotationId")
       S4QuoteItemID = map.get("S4_BusinessSolutionQuotationItemId")
       ExceptionMessage = map.get("CamelExceptionCaught");
       ExceptionProcessName = map.get("ExceptionProcessName");
       Notification = map.get("EventMessage");
       def messageLog = messageLogFactory.getMessageLog(message);
       if(messageLog != null){
         def loggingmessage = "Retry failed after 5 Retries/10 Seconds for CPQ-Quote: " + CPQQuoteID + " S/4 Solution Quote ID: " + S4QuoteID + " S/4 Solution Quote Item ID: " + S4QuoteItemID + " with error " + ExceptionMessage + ". Notification is stored in SCI data store for 30 days"
         messageLog.addAttachmentAsString("Error during processing: ", loggingmessage, "text/plain")
         messageLog.addAttachmentAsString("Notification-Content:", Notification, "text/plain");
       }
       return message;
}
