import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


def String fetchPropertyValue(String p1, MappingContext context) {

        def propVal= context.getProperty(p1);
        return propVal;
}

def String replaceValueforEmptyField(String arg1,String arg2,MappingContext context){
 String propval=context.getProperty(arg1);
 String defaultVal= context.getProperty(arg2);
    return propval+"-------"+defaultVal;
 }

def String replaceValueforEmptyCustomField(String arg1,String arg2,MappingContext context){
 String defaultVal= context.getProperty(arg2);
 if(arg1==null || arg1== "")
 return defaultVal;
 else
 return arg1;
 }
 
 def String getImageName(String arg1,String arg2){
      String imageName="";
      if(arg1==null || arg1== ""){
        imageName=arg2.tokenize('/').last();
      }
      else{
          imageName=arg1;
      }
     return imageName;
 }
 
 def String dateConversion(String arg1){
    
    Date inputDate_parsed=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").parse(arg1);  
    DateFormat dateFormat_required = new SimpleDateFormat(" ");

    def converted_datetime=dateFormat_required.format(inputDate_parsed);
    
    return converted_datetime;
}
 

