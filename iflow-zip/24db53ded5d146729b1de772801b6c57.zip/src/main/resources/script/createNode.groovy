import com.sap.it.api.mapping.*;
def void createNode(int[] arg1,Output output,MappingContext context){

for(int i=0;i<arg1[0];i++){
output.addValue("");
}

}