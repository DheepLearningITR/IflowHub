import groovy.json.*
import groovy.json.JsonSlurper
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def map = message.getProperties();
    def body = message.getBody(java.lang.String) as String;
    def jsonSlurper = new JsonSlurper();
    def jsonObject = jsonSlurper.parseText(body);
    def mssg = '[{';
    def empList = map.get("Executing_Service_Employee");
    def i;
    
    for(i = 0; i < jsonObject.activities.size() - 1; i++) {
        mssg = """${mssg}"id": "${jsonObject.activities[i].id}","technician": {"externalId": "${empList[i]}"},"startDateTime": "${jsonObject.activities[i].earliestStartDateTime}","duration": ${jsonObject.activities[i].durationInMinutes}}, {""";
    }
    
    mssg = """${mssg}"id": "${jsonObject.activities[i].id}","technician": {"externalId": "${empList[i]}"},"startDateTime": "${jsonObject.activities[i].earliestStartDateTime}","duration": ${jsonObject.activities[i].durationInMinutes}}]""";

    message.setBody(new JsonBuilder(new JsonSlurper().parseText(mssg)).toPrettyString());
    return message;
}