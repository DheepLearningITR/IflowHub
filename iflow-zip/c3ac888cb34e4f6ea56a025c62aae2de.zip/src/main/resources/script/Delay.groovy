import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody();
       map = message.getProperties();
       delay = map.get("DelayBeforeAssignment").toInteger();
       sleep(delay * 1000);
       message.setBody(body);
       return message;
}
