import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;

def Message processData(Message message){
    def a = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    //format sourceAgency, sourceIdentifier, sourceValue, targetAgency, targetIdentifier
    def map = message.getHeaders();
    
    def srcSystem = map.get("SrcSystem").toString();
    def trgSystem = map.get("TrgSystem").toString();
    def srcIdentifier = map.get("SrcIdentifier").toString();
    def trgidentifier = map.get("TrgIdentifier").toString();
    def sourceValue = map.get("CRM_Service_Order_Status");
    def mappedValue = a.getMappedValue(srcSystem, srcIdentifier, sourceValue, trgSystem, trgidentifier);
    
    if(mappedValue != null) {
        message.setProperty("Status_For_Service_Order_Create", mappedValue);
    }
    
    return message;
}