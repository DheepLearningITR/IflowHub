import com.sap.it.api.mapping.*;
def String headerNotesConcate(String input,String serviceOrderTextID){
     def query = new XmlSlurper().parseText(input);
     String output="";
     if(query.TEXT_ID.text()==serviceOrderTextID)
     {
       String flag="false"; 
       query.E101CRMXIF_TLINE.each{
            if(flag=="false")
              {
                 output=output+it.TEXT_LINE;
                 flag="true";
              }
            else
              {
                 if(it.FORMAT_COL.text()=="*")
                  output=output+"\n"+it.TEXT_LINE;
                 else if(it.FORMAT_COL.text()=="=")
                  output=output+it.TEXT_LINE;
                 else
                  output=output+" "+it.TEXT_LINE;
              }
       }
	   return output;
     }
}