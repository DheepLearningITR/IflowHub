import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Properties
    def properties = message.getProperties();
    value = properties.get("t2_access_token");
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("t2_token");
    cacheData.put("t2_token",value)
    message.setHeader("t2_token",cacheData);
    message.setHeader("degreedAccessToken", 'true');
    return message;
}
