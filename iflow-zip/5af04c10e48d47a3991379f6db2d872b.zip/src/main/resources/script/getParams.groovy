import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential
import com.sap.it.api.securestore.exception.SecureStoreException

def Message processData(Message message) {
    def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)
    def messageLog = messageLogFactory.getMessageLog(message);

    try{
        def properties = message.getProperties();
        
        def gat_enabled = properties.get("is_GAT_enabled")
        
        // def cred_prefix = ''
        // if (gat_enabled == "true") {
        //     cred_prefix = "GAT_"
        // }
        
        def degreedClientId = properties.get("Degreed_Client_Id")
        def secureParameter1 = secureStorageService.getUserCredential(degreedClientId) // From Secure material
        def clientId = secureParameter1.getPassword().toString()
        message.setProperty("client_id", clientId)
       // messageLog.addAttachmentAsString("ClientID", clientId, "text/plain");

        def degreedClientSecret = properties.get("Degreed_Client_Secret")
        def secureParameter2 = secureStorageService.getUserCredential(degreedClientSecret) // From Secure material
        def clientSecret = secureParameter2.getPassword().toString()
        message.setProperty("client_secret", clientSecret)
        
      //  messageLog.addAttachmentAsString("client_secret", clientSecret, "text/plain");
      
        def tenant1ClientId = properties.get("Tenant1_api_client_id")
        def t1SecureParameter1 = secureStorageService.getUserCredential(tenant1ClientId) // From Secure material
        def t1ClientId = t1SecureParameter1.getPassword().toString()
        message.setProperty("t1_client_id", t1ClientId)
       // messageLog.addAttachmentAsString("ClientID", clientId, "text/plain");
    
        def tenant1ClientSecret = properties.get("Tenant1_api_client_secret")
        def t1SecureParameter2 = secureStorageService.getUserCredential(tenant1ClientSecret) // From Secure material
        def t1ClientSecret = t1SecureParameter2.getPassword().toString()
        message.setProperty("t1_client_secret", t1ClientSecret)
        
      //  messageLog.addAttachmentAsString("client_secret", clientSecret, "text/plain");
      
        def tenant2ClientId = properties.get("Tenant2_api_client_id")
        def t2SecureParameter1 = secureStorageService.getUserCredential(tenant2ClientId) // From Secure material
        def t2ClientId = t2SecureParameter1.getPassword().toString()
        message.setProperty("t2_client_id", t2ClientId)
       // messageLog.addAttachmentAsString("ClientID", clientId, "text/plain");
    
        def tenant2ClientSecret = properties.get("Tenant2_api_client_secret")
        def t2SecureParameter2 = secureStorageService.getUserCredential(tenant2ClientSecret) // From Secure material
        def t2ClientSecret = t2SecureParameter2.getPassword().toString()
        message.setProperty("t2_client_secret", t2ClientSecret)
        
      //  messageLog.addAttachmentAsString("client_secret", clientSecret, "text/plain");
        

    } catch(Exception e){
        throw new SecureStoreException("Secure Parameter not available")
    }
    return message;
}