import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    
    //Variables in cache
    def map = message.getHeaders();
    HashMap<String, String> cacheData = map.get("token");
    HashMap<String, String> t1CacheData = map.get("t1_token");
    HashMap<String, String> t2CacheData = map.get("t2_token");

    // Set variables
    def t1_auth_value = "Bearer " + t1CacheData.get("t1_token");
    def t2_auth_value = "Bearer " + t2CacheData.get("t2_token");
    def messageLog = messageLogFactory.getMessageLog(message);
    //Properties
    def properties = message.getProperties();
    
    // To avoid rate limit
    def sleepTime =  properties.get("sleepTime")
    
    if (sleepTime == "YES") {
        Thread.sleep(60000);
    }
    
    // Set variables
    def headerParam = "application/json";
    def auth_value = "Bearer " + cacheData.get("token");
    message.setHeader("accept",headerParam);
    message.setHeader("content-type",headerParam);
    def no_auth_code = "false"
    
    def gat_enabled = properties.get("is_GAT_enabled")
    def country = properties.get("Country")
    //messageLog.addAttachmentAsString("Check Country", country, "text/plain");
    if (gat_enabled == 'true') {
        
        def tenant1 = properties.get("tenantCountryList1")
        def tenant2 = properties.get("tenantCountryList2")
        // def tenant1Xcode = properties.get("tenant1XCode")
        // def tenant2Xcode = properties.get("tenant2XCode")
        // def gatXCode = properties.get("gatXCode")
        
        // messageLog.addAttachmentAsString("Check Payload for tenant", tenant1Xcode, "text/plain");
        
        def tenantList1 = tenant1.split(',')
        def tenantList2 = tenant2.split(',')
        
        if (country in tenantList1) {
            message.setHeader("Authorization",t1_auth_value);
        }
        else if (country in tenantList2) {
            message.setHeader("Authorization",t2_auth_value);
        }
        else {
            no_auth_code = "true"
        }
        
    }
    
    
    else {
        message.setHeader("Authorization",auth_value);
    }
    //messageLog.addAttachmentAsString("Check Auth 1", t1_auth_value, "text/plain");
    //messageLog.addAttachmentAsString("Check Auth", t2_auth_value, "text/plain");
    message.setProperty("no_auth_code", no_auth_code)
    return message;
}