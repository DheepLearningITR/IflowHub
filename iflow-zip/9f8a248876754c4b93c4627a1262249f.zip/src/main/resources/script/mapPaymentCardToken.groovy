import com.sap.it.api.mapping.*;



def String mapPaymentCardToken(String p1, MappingContext context) {
         
         String value2 = context.getProperty("paymentMethod");
         if(value2.equalsIgnoreCase("invoice"))
         {
             return "";
         }
         return p1;
}




