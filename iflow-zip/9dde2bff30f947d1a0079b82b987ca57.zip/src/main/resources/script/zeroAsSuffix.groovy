import com.sap.it.api.mapping.*;

def String zeroAsSuffix(String arg1,int entityLen){
    len=arg1.length()
    int len2
    String addstr
    if (len<=entityLen)
    {
       len2=entityLen-len
       addstr="0"*len2
       arg1=addstr+arg1
    }
	return  arg1
}