import com.sap.it.api.mapping.*
import com.sap.it.api.mapping.MappingContext;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.xml.QName;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.ITApiFactory;
import static java.util.UUID.randomUUID;
import java.text.*; 
import java.util.*;

def String genMapping(String Template_PM_ID,String Input_Value,String Attribute_Name,MappingContext context){
    
	// Get Value Mapping Service
	def valueMapService = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    String valueFSPMVersion   = 'FSPM_'+ context.getProperty("com.sap.commercecloud.fsa.insurance.anonymousquote.FSPM_Version");
    String valueHybrisVersion = 'FSA_'+ context.getProperty("com.sap.commercecloud.fsa.insurance.anonymousquote.FSA_Version");
    
    String valueMappedPayFrqId = Input_Value;
    
            // Go for attributes with mapping (first template specific)
            valueMappedPayFrqId = valueMapService.getMappedValue(valueHybrisVersion, Template_PM_ID+"_"+Attribute_Name, Input_Value, valueFSPMVersion, Template_PM_ID+"_"+Attribute_Name);
            if (valueMappedPayFrqId == null) {
                // ...second try is without template ID
                   valueMappedPayFrqId = valueMapService.getMappedValue(valueHybrisVersion, Attribute_Name, Input_Value, valueFSPMVersion, Attribute_Name); 
            }
    return valueMappedPayFrqId;
}



def String getProperty(String property_name, MappingContext context) {

    def propValue= context.getProperty(property_name);
    return propValue;

}

def String genAttrMapping(String FSA_Context,String FSPM_Context,String Input_Value,String FSA_Attribute_Name,String FSPM_Attribute_Name,MappingContext context){
    
	// Get Value Mapping Service
	def valueMapService = ITApiFactory.getApi(ValueMappingApi.class, null);
    
    String valueFSPMVersion   = 'FSPM_'+ context.getProperty("com.sap.commercecloud.fsa.insurance.anonymousquote.FSPM_Version");
    String valueHybrisVersion = 'FSA_'+ context.getProperty("com.sap.commercecloud.fsa.insurance.anonymousquote.FSA_Version");
    
    String valueMapped = Input_Value;
    
            // Go for attributes with mapping (first template specific)
            valueMapped = valueMapService.getMappedValue(valueHybrisVersion, FSA_Context+"_"+FSA_Attribute_Name, Input_Value, valueFSPMVersion, FSPM_Context+"_"+FSPM_Attribute_Name);
            if (valueMapped == null) {
                // ...try without FSPM template ID
                   valueMapped = valueMapService.getMappedValue(valueHybrisVersion, FSA_Context+"_"+FSA_Attribute_Name, Input_Value, valueFSPMVersion, FSPM_Attribute_Name); 
            }
             if (valueMapped == null) {
                // ...try without FSA template ID
                   valueMapped = valueMapService.getMappedValue(valueHybrisVersion, FSA_Attribute_Name, Input_Value, valueFSPMVersion, FSPM_Context+"_"+FSPM_Attribute_Name); 
            }
             if (valueMapped == null) {
                // ... try is without FSA&FSPM template ID
                   valueMapped = valueMapService.getMappedValue(valueHybrisVersion, FSA_Attribute_Name, Input_Value, valueFSPMVersion, FSPM_Attribute_Name); 
            }
            
            if (valueMapped == null) {
                valueMapped == 'MAPPING_ERROR';
            }
    return valueMapped;
}