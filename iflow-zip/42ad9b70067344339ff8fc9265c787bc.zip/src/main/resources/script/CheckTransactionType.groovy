import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser

def Message processData(Message message) {
    
    def body = message.getBody(java.lang.String) as String
    def parser = new XmlSlurper()
    def parserResult = parser.parseText(body)

    message.setProperty('TransactionTypeSupported', 'false')
    
    if(parserResult != null){
        // Transaction Type 
        try {
            def transactionType = parserResult.'**'.find { it.name() == 'ServiceOrderType' }.text()
            if (transactionType != null && transactionType != '') {
                transactionTypesList = message.getProperty("TransactionTypesUsedInReplication") as String ?: ''
                def supportedTransactionTypesList = transactionTypesList.split("\\|")*.trim();
                if (transactionType in supportedTransactionTypesList) {
                    message.setProperty('TransactionTypeSupported', 'true')
                }
            }
        } catch (ex) { /*ignore*/ }
    }
  
  return message;
}