import com.sap.gateway.ip.core.customdev.util.Message;
 
def Message processData(Message message) {
     
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        def map = message.getProperties()
        def multiCompFlag = map.get("EnableMultiCompany");
        if(multiCompFlag == "true"){
            messageLog.addCustomHeaderProperty("FSMAccountCompany_Success", map.get("X-Account-ID") + '|' + map.get("X-Company-ID"));
        }
    }
    return message;
}


