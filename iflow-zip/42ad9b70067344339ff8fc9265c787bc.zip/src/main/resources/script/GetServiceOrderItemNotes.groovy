import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;
import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;
import groovy.util.XmlParser;

def String GetServiceOrderItemNotes(String ItemNum, MappingContext context ){
    
     def noteType      = context.getProperty("ServiceOrderINoteType");
     def noteLanguage  = context.getProperty("ServiceOrderINoteLang");
     def sourcePayload = context.getProperty("SourcePayload");   
      
     def sourcePayloadXml = new XmlParser().parseText(sourcePayload);
     def result;

     sourcePayloadXml.A_ServiceOrderType.to_Item.A_ServiceOrderItemType.to_Text.A_ServiceOrderItemTextType.find{ 
        if( it.ServiceOrderItem.text() == ItemNum && it.LongTextID.text() == noteType && it.Language.text() == noteLanguage){
            result = it.LongText.text();
        }
        if(result != null){
            return;
        }
    }
        return result;
}