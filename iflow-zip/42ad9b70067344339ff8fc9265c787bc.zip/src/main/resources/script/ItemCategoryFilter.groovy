import com.sap.it.api.mapping.*;

def String ItemFilter(String value, String itemCategory, String reservedMaterial, MappingContext context){

    def activitiesCategories = [ 'SVP1', 'SVP2', 'SVP4' ]
    def reservedMaterialsCategories = [ 'SVS1', 'SVS2', 'SVS4', 'SVR1', 'SVR2', 'SVR4' ]
    def result = null
    

     if (reservedMaterial ==~ /(?i)(true|x)/ ) {
        if (itemCategory in reservedMaterialsCategories) {
            result = value
        }
    } else {
        if (itemCategory in activitiesCategories) {
            result = value
        }
    }

	return result 
	
}
