import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlParser;
import groovy.*
def Message processData(Message message) {
    
    //Get Body
    def body = message.getBody(String.class)
    def root = new XmlParser().parseText(body)

    // check all materials for parent items
    root.reservedMaterials.each{ rm ->
    
        def parentItem = root.activities.find{ act ->
        
            //the id could be a simple number or a concatenation of two numbers 
            // (In case of a Service Bundle)
            // check for the slash indicating a concatenation
            def id = ( act.temp_ItemId.text() =~ "\\/(.*)" )
            
            // if no slash has been found: take the whole id
            id = (id.size() > 0) ? id[0][1] : act.temp_ItemId.text()
            rm.temp_ParentItem.text() == id
        }
        //check if parent item is a service item
        if (parentItem?.temp_Category?.text() in ["SVP1","SVP2","SVP4"]){

        //remove temporary node (cannot be done later)
        rm.remove(rm.temp_ParentItem)
        //add the material to the activity
        parentItem.appendNode("reservedMaterials",rm.collect())
        //remove material from Service Call
        rm.parent().remove(rm)
        }
    }

    // delete all temporary fields
    root.depthFirst().each{ it ->
        if (it.name().startsWith("temp_")){
            it.replaceNode{}
        }
    }

    //build output
    String outxml = groovy.xml.XmlUtil.serialize( root )
    message.setBody(outxml)
    return message
}
