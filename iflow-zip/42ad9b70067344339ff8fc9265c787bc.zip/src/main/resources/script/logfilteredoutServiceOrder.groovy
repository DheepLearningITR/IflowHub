import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil;
import groovy.util.slurpersupport.NodeChild;

def Message processData(Message message) {
    /* This script is to log the service orders that are filtered out with no FSM company. */
	
    def body = message.getBody(java.lang.String)
    def query = new XmlSlurper().parseText(body)
    def messageLog = messageLogFactory.getMessageLog(message)
	
    query.A_ServiceOrder.A_ServiceOrderType.each { srvMessage ->        
        def internalID = srvMessage.ServiceOrder.text()
        if (messageLog != null) {
            messageLog.addCustomHeaderProperty("FSMCompanyNotFoundForServiceOrder", internalID)
        }
    }
    return message
}
