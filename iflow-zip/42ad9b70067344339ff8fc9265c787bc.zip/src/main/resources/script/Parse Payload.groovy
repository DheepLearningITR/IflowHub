import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlParser;
import groovy.util.Node;
import javax.xml.namespace.QName;
import groovy.*

def Message processData(Message message) {
    //Get Body
    def body = message.getBody(String.class)
    def parser = new XmlParser()
    def root = parser.parseText(body)
    def map = [:]
    def activityCategories = [ 'SVP1', 'SVP2', 'SVP4' ]
    def reservedMaterialCategories = [ 'SVS1', 'SVS2', 'SVS4', 'SVR1', 'SVR2', 'SVR4' ]
    def emptyServiceOrder = 'X'
    
    root.A_ServiceOrderType.to_Item.A_ServiceOrderItemType.each{
// If a service item <> "Released" is not replicated yet to FSM (no external FSM ID available), it shall be ignored, i.e. not be replicated to FSM.
        if (!(it.ServiceOrderItemIsReleased.text() ==~ /(?i)(true|x)/) && (it.FSMServiceActivity == null || it.FSMServiceActivity.text() == "")){
            it.replaceNode {}
            return false
        }
        
        // Unplanned Items are filtered out
        if (it.SrvcOrdItemIsUnplanned.text() ==~ /(?i)(true|x)/) {
            it.replaceNode {};
            return;
        }

// Previously, Service Items without bundle context that contain a higher level item ID were removed from the payload (i.e. they were not replicated to FSM).
// Now, they are not removed anymore (i.e. now they are replicated to FSM).

// If the item does not belong to an allowed category, it is deleted; otherwise, the flag "EmptyServiceOrder" is reset.
        if (!(it.ServiceOrderItemCategory.text() in activityCategories)) {
            // store items that are not activities and remove the item
            map.put(it.ServiceOrderItem.text(),it)
            it.replaceNode {}
        } else {
            emptyServiceOrder = ''
        }
    }
    message.setProperty('EmptyServiceOrder', emptyServiceOrder)

    root.A_ServiceOrderType.each{
        map.each { key, value ->
            if ( value.ServiceOrderItemCategory.text() in reservedMaterialCategories ) {
                // add items with a reserved material category again under the artificial node to_ReservedMaterial
                it.appendNode ( 'to_ReservedMaterial' , value.collect() )
            } 
        }
    }

// fetch ServiceDocChangedDateTime
    try {
        def serviceDocChangedDateTime = root.'**'.find { it.name() == 'ServiceDocChangedDateTime' }.text()
        if (serviceDocChangedDateTime != '') {
            message.setHeader('X-Source-Last-Changed', serviceDocChangedDateTime+"Z")
        }
        } catch(Exception ex0) {}

    String outxml = groovy.xml.XmlUtil.serialize( root )
    message.setBody(outxml)
    return message
}