import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper;
import groovy.*
def Message processData(Message message) {
    //Get Body
    def body = message.getBody(String.class)
    def root = new XmlSlurper().parseText(body)
    def ServiceItemId = '' as String
    def ParentItemId = '' as String

    // loop over the items
    root.A_ServiceOrderType.to_Item.A_ServiceOrderItemType.each{
        // find all service order items w/ category "SVP4", "SVP1" or "SVP2" that have a parent
        if ((it.ServiceOrderItemCategory.text() == "SVP4" || it.ServiceOrderItemCategory.text() == "SVP1" || it.ServiceOrderItemCategory.text() == "SVP2") && it.ParentServiceOrderItem.text() != "0"){
            ParentItemId = it.ParentServiceOrderItem.text();

            // retrieve the parent item 
            BundleItem = root.A_ServiceOrderType.to_Item.A_ServiceOrderItemType.find { it.ServiceOrderItem.text() == ParentItemId };
            
            // replace the service order item id by the concatenation ParentItemId/ItemId if Parent is of type bundle ("SVB4", "SVB1", or "SVB6")
            if (BundleItem && (BundleItem.ServiceOrderItemCategory.text() == "SVB4" || BundleItem.ServiceOrderItemCategory.text() == "SVB1" || BundleItem.ServiceOrderItemCategory.text() == "SVB6") ){
                ServiceItemId = ParentItemId + '/' + it.ServiceOrderItem.text();
                it.ServiceOrderItem.replaceBody(ServiceItemId);
            }
        }
    }
  
    String outxml = groovy.xml.XmlUtil.serialize( root )
    message.setBody(outxml);
    return message;
}