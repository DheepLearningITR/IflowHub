import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.json.JsonSlurper
// Version 1.0
// get ids from incoming message from S4/EMS for setting SAP Application ID, X-Request-ID and custom log headers
def Message processData(Message message) { 
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonResult = jsonSlurper.parseText(body)
    
    // fetch EMS id as SAP_ApplicationID and set X-Request-ID
    try {
        def emsId = jsonResult['id']
        if (emsId != null && emsId != '') {
            message.setHeader("SAP_ApplicationID", emsId)
            message.setHeader("X-Request-ID", emsId)   
        }
    } catch(Exception ex1) { /* not found */ }
    // add ServiceOrder (id) to message headers and custom log headers
    def messageLog = messageLogFactory.getMessageLog(message)
    if(messageLog != null) {
        try {
            def serviceOrder = jsonResult['data']['ServiceOrder'] as String
            if(serviceOrder != null && serviceOrder != '') {
                message.setHeader("ServiceOrder", serviceOrder)
                messageLog.addCustomHeaderProperty("ServiceOrder", serviceOrder)
            }
        } catch(Exception ex2) { /* not found */ }
    }
    return message
}