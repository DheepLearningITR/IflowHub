import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

// recursive method for parsing whole json
def formatDeep(def node){
    node.each{ subnode ->
        
        // case 1: format an array containing an empty string to an empty array
        if (subnode.value == [""]){
            subnode.value = [];
            
        // case 2: format empty string and empty objects to null values
        // FSM interprets null values as a deletion
        } else if ((subnode.value instanceof Map && subnode.value.isEmpty()) || subnode.value == ""){
            
            // S4 service order/item description is optional, FSM subject is mandatory
            // >> empty service order/item description replaced with subject " "
            if (subnode.key == "subject"){
                subnode.value = " ";
            } else {
                subnode.value = null;
            }
            
        // if the current node has subnodes (that means, it is a map or a list)
        //-> go further down in the tree and repeat the logic
        } else if (subnode.value instanceof Map || 
                   subnode.value instanceof List) {
            formatDeep(subnode.value);
        } else if (subnode instanceof Map) {
            formatDeep(subnode);
        }
        
// If the value mapping ServiceOrder.TransactionType => ServiceCall.Type still contains the string "<Field Service>" or "<In-House Repair>",
// this value stands for "empty" and has to be deleted from the payload!
        if (subnode.key == "type" && ( subnode.value == "<Field Service>" || subnode.value == "<In-House Repair>" )){
            subnode.value = null;
        }
    }
} 

def Message processData(Message message) { 

    def body = message.getBody(String.class);
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);

    formatDeep(object);

    message.setBody(JsonOutput.toJson(object.root));	

// To access FSM, company and account are required -- either their name or their ID.
// If the IDs are configured, they are used; otherwise, the names are used.
    def accountCompany = '';
    def accountID = message.getProperty('X-Account-ID');
    def accountName = message.getProperty('X-Account-Name');
    def companyID = message.getProperty('X-Company-ID');
    def companyName = message.getProperty('X-Company-Name');

    if (accountID == null || accountID == '' || accountID == '<FSM_Account_ID>' || companyID == null || companyID == '' || companyID == '<FSM_Company_ID>') {
        accountCompany = 'account='+accountName+'&company='+companyName+'&';
        message.setHeader('X-Account-Name', accountName);
        message.setHeader('X-Company-Name', companyName);
    } else {
        accountCompany = '';
        message.setHeader('X-Account-ID', accountID);
        message.setHeader('X-Company-ID', companyID);
    }
    message.setProperty('AccountCompany', accountCompany);

    return message;
}