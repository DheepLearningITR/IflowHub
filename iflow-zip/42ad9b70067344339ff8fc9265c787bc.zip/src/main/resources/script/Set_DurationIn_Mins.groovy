import com.sap.it.api.mapping.*;


def String Set_DurationIn_Mins(String ServiceOrderItemCategory , String Quantity , String QuantityUnit){
    def result
    
    if( ( ServiceOrderItemCategory == "SVP1" || ServiceOrderItemCategory == "SVP2" || ServiceOrderItemCategory == "SVP4" )  && 
        ( QuantityUnit == "HR" || QuantityUnit == "HOR" || QuantityUnit =='H') && Quantity.isFloat() ) {      
            
        result = (int)(Quantity.toFloat() * 60)
    } else if ( QuantityUnit == "MIN" && Quantity.isFloat() ) {
        result = (int)Quantity.toFloat()
    }
    
	return result
	
}




