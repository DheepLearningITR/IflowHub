import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;

def String GetServiceCallType(String input, MappingContext context){
    def serviceOrderType = input;
    def service = ITApiFactory.getApi(ValueMappingApi.class, null);
    String serviceCallType = service.getMappedValue('ServiceOrder', 'TransactionType', serviceOrderType , 'ServiceCall', 'Type');
    
    //<null> is used as a placeholder in the ValueMapping for a null or initial value as such values can't be maintained directly in the Value Mapping
    //<Field Service> and <In-House Repair> are the delivered vlues that have to be replaced by the customer
    if (serviceCallType == "<null>" || serviceCallType == "<Field Service>" || serviceCallType == "<In-House Repair>") {
        serviceCallType = null;
    }
    
	return serviceCallType; 
}
