import com.sap.it.api.mapping.*;
import com.sap.it.api.mapping.MappingContext;
import com.sap.it.api.mapping.*;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import com.sap.it.api.mapping.ValueMappingApi;
import groovy.util.XmlParser;

def String GetServiceOrderHeaderNotes(String text, MappingContext context ){
    
     def noteType      = context.getProperty("ServiceOrderHNoteType");
     def noteLanguage  = context.getProperty("ServiceOrderHNoteLang");
     def sourcePayload = context.getProperty("SourcePayload");   
      
     def sourcePayloadXml = new XmlParser().parseText(sourcePayload);
     def result;

     sourcePayloadXml.A_ServiceOrderType.to_Text.A_ServiceOrderTextType.find{ 
        if( it.LongTextID.text() == noteType && it.Language.text() == noteLanguage){
            result = it.LongText.text();
        }
        if(result != null){
            return;
        }
    }
        return result;
    
}