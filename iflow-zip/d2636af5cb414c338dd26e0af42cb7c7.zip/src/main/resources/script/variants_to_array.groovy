import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {

def body = message.getBody(java.lang.String) as String;
def jsonSlurper = new JsonSlurper()

def object = jsonSlurper.parseText(body)
object.product.variants = [object.product.variants]

def jsonBuilder = new JsonBuilder(object)
message.setBody(jsonBuilder)
       return message;
}