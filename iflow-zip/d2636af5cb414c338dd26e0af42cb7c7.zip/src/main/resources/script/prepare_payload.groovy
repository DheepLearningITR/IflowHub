import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {
	def body = message.getBody(java.io.Reader)
	def json = new JsonSlurper().parse(body)
	
	json.is_visible = json.is_visible.toBoolean(); 
	
	String output = JsonOutput.toJson(json)
	
	message.setBody(output.trim())

    return message;
}