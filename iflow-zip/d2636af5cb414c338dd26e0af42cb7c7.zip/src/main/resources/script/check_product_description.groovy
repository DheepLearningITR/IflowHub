import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {

    def xmlPayload = message.getBody(String)
    
    def language = message.getProperties().get('description_language_code')

    def xmlSlurper = new XmlSlurper().parseText(xmlPayload)
    def description = ""
    def bigcommerceProductId = ""

    xmlSlurper.A_ProductType.each { productType ->
        productType.to_Description.A_ProductDescriptionType.each { descriptionType ->
            if (descriptionType.Language.text() == language) {
                description = descriptionType.ProductDescription.text()
            }
        }
    }
   
    def existing_product = description != null && !description.isEmpty()
    message.setProperty("existing_product", existing_product)

    if (existing_product) {
        if (description != null && description.contains("Big Commerce Product ID:")) {
            def matcher = description =~ /Big Commerce Product ID\s*:\s*(\d+)/
            if (matcher.find()) {
                bigcommerceProductId = "${matcher.group(1)}"
            }
        }
        message.setProperty("bigcommerce_product_id", bigcommerceProductId)
    }

    return message
}
