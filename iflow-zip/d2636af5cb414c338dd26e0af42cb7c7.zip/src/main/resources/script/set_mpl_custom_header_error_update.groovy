import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
	def map = message.getProperties()
    def logException = map.get("ExceptionLogging")?.equalsIgnoreCase("true")
	
	def messageLog = messageLogFactory.getMessageLog(message);
	
	def s4hana_product_id = message.getProperty("s4hana_product_id") as String;	
	
	if(messageLog != null){
	    
	    def titlePattern = ~/"title"\s*:\s*"([^"]*)"/

        def titleValue = null

        def ex = map.get("CamelExceptionCaught") as String
        
        if (ex == null) {
            ex = message.getBody(String)
        }
            
        def matcher = titlePattern.matcher(ex)
        
        if (matcher.find()) {
            titleValue = matcher.group(1)
        }

		if(s4hana_product_id!=null && !s4hana_product_id.isEmpty()){
			messageLog.addCustomHeaderProperty("S/4HANA Product ID ${s4hana_product_id} NOT Updated", "Reason: ${titleValue}" );		
        }
	}
	
	return message;
}

