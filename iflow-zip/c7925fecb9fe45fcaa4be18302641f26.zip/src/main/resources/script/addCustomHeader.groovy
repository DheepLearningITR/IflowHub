import com.sap.gateway.ip.core.customdev.util.Message;

def Message addCustomHeader(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def map = message.getProperties();
    if(messageLog != null){
        def originationDocNo = map.get("OriginationDocNo");
        def originationItemNo = map.get("OriginationItemNo");
        messageLog.addCustomHeaderProperty("OriginationDocNo", originationDocNo);
        messageLog.addCustomHeaderProperty("OriginationItemNo", originationItemNo);
    }
    return message;
}
