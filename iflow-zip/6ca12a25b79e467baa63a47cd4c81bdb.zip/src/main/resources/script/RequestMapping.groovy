import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Retrieve headers from the message
    def headers = message.getHeaders()
    // Extract the JSON string from the header named 'FormattedHTTPQuery'
    def jsonString = headers.get("FormattedHTTPQuery")
    
    // Parse the JSON string into a JSON object
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(jsonString)

    // Initialize a writer for building the XML string
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    xml.setDoubleQuotes(true) // Use double quotes for XML attributes

    // Build the XML structure with the root element and namespace
    xml.'n0:IsuC4cV2ObjectFinder'('xmlns:n0': 'urn:sap-com:document:sap:soap:functions:mc-style') {
        // Handle dueDateFrom and dueDateTo if present in the JSON object
        if (jsonObject.dueDateFrom || jsonObject.dueDateTo) {
            ItDueDate {
                'item' {
                    Sign('I') 
                    Option('BT') 
                    DateFrom(jsonObject.dueDateFrom?.get(0)?.value ?: '') 
                    DateTo(jsonObject.dueDateTo?.get(0)?.value ?: '') 
                }
            }
        }

        // Add the IsFindpar root node
        IsFindpar {
            // Iterate through each key-value pair in the JSON object
            jsonObject.each { key, value ->
                switch (key) {
                    // case 'businessPartnerId':
                    //     BusinessPartner(value[0].value) 
                    //     break
                    // case 'contractAccountId':
                    //     ContractAccount(value[0].value)
                    //     break
                    // case 'contractDateUsed':
                    //     DateFindingObject(value[0].value) 
                    //     break
                    // case 'premiseId':
                    //     Premise(value[0].value) 
                    //     break
                    // case 'insDateUsed':
                    //     InstallationDate(value[0].value) 
                    //     break
                    // case 'genericSearch':
                    //     Searchstring(value[0].value) 
                    //     break
                    // case 'contractDateUsedTo':
                    //     VaildDateTo(value[0].value) 
                    //     break
                    // case 'bankBranch':
                    //     BankBranch(value[0].value) 
                    //     break
                    
                    
            case 'businessPartnerId':
                BusinessPartner(value[0].value)
                break
            case 'bpName1':
                BpLastName(value[0].value)
                break
            case 'bpName2':
                BpFirstName(value[0].value)
                break
            case 'bpCity':
                BpCity(value[0].value)
                break
            case 'bpDistrict':
                BpDistrict(value[0].value)
                break
            case 'bpPostalCode':
                BpCityPostalCode(value[0].value)
                break
            case 'bpPoBoxPostalCode':
                BpPoBoxPostalCode(value[0].value)
                break
            case 'bpCompanyPostalCode':
                BpCompanyPostalCode(value[0].value)
                break
            case 'bpPoBoxCity':
                BpPoBoxCity(value[0].value)
                break
            case 'bpStreet':
                BpStreet(value[0].value)
                break
            case 'bpHouseNo':
                BpHouseNumber(value[0].value)
                break
            case 'bpHouseSupplement':
                BpHouseNumberSuppl(value[0].value)
                break
            case 'bpCountryKey':
                BpCountry(value[0].value)
                break
            case 'bpRegionKey':
                BpRegion(value[0].value)
                break
            case 'bpSearchTerm1':
                BpSearchTerm1(value[0].value)
                break
            case 'bpSearchTerm2':
                BpSearchTerm2(value[0].value)
                break
            case 'bpAddressNumber':
                BpAddressNumber(value[0].value)
                break
            case 'bpMobileNumber':
                BpCompepletTeleNumber(value[0].value)
                break
            case 'bpSocialInsuranceNo':
                BpSocialInsuranceNumber(value[0].value)
                break
            case 'bpDivingLicenseNo':
                BpDriverLicense(value[0].value)
                break
            case 'bpWelfareOffice':
                BpWelfareOffice(value[0].value)
                break
            case 'bpBankAccountNo':
                BpBankAccount(value[0].value)
                break
            case 'bpBankNo':
                BpBankNumber(value[0].value)
                break
            case 'bpBankCountryKey':
                BpBankCountry(value[0].value)
                break
            case 'bpTaxCategory':
                BpTaxType(value[0].value)
                break
            case 'bpTaxNo':
                BpTaxNumber(value[0].value)
                break
            case 'contractAccountId':
                ContractAccount(value[0].value)
                break
            case 'caAlternativePayerId':
                AlternativePayer(value[0].value)
                break
            case 'caAlternativePayeeId':
                AlternativePayee(value[0].value)
                break
            case 'caAltInvRecipientId':
                AlternativeInvoiceRecipient(value[0].value)
                break
            case 'caAltDunningRecipientId':
                AlternativeDunningRecipient(value[0].value)
                break
            case 'caAltCaCollBillId':
                AlternativeCaCollBills(value[0].value)
                break
            case 'caPaymentCa':
                CaUsedForPayTrans(value[0].value)
                break
            case 'contractId':
                Contract(value[0].value)
                break
            case 'companyCode':
                CaCompanyCode(value[0].value)
                break
            case 'division':
                CaDivision(value[0].value)
                break
            case 'contractDateUsed':
                DateFindingObject(value[0].value)
                break
            case 'budgeBilling':
                BudgetBillingPlan(value[0].value)
                break
            case 'bBDateUsed':
                DateFindObj(value[0].value)
                break
            case 'connectionObjectId':
                ConnectionObject(value[0].value)
                break
            case 'coCity':
                ConnObjCity(value[0].value)
                break
            case 'coDistrict':
                ConnObjDist(value[0].value)
                break
            case 'coPostalCode':
                ConnObjPostalCode(value[0].value)
                break
            case 'coPoBoxPostalCode':
                ConnObjPoBoxPostalCode(value[0].value)
                break
            case 'coCompanyPostalCode':
                ConnObjCompanyPostalCode(value[0].value)
                break
            case 'coPoBoxCity':
                ConnObjPoBoxCity(value[0].value)
                break
            case 'coStreet':
                ConnObjStreet(value[0].value)
                break
            case 'coHouseNumber':
                ConnObjHouseNumber(value[0].value)
                break
            case 'coHouseSupplement':
                ConnObjHouseNumberSuppl(value[0].value)
                break
            case 'coHouseNo':
                ConnObjHouseNum(value[0].value)
                break
            case 'coCountryKey':
                ConnObjCountry(value[0].value)
                break
            case 'coRegionKey':
                ConnObjRegion(value[0].value)
                break
            case 'coSearchTerm1':
                ConnObjSearchTerm1(value[0].value)
                break
            case 'coSearchTerm2':
                ConnObjSearchTerm2(value[0].value)
                break
            case 'coAddressNumber':
                ConnObjAddrnum(value[0].value)
                break
            case 'premiseId':
                Premise(value[0].value)
                break
            case 'premiseHouseNo':
                PremiseHouseNumberSuppl(value[0].value)
                break
            case 'street3':
                PremiseStreet3(value[0].value)
                break
            case 'street5':
                PremiseStreet4(value[0].value)
                break
            case 'floor':
                PremiseFloor(value[0].value)
                break
            case 'room':
                PremiseRoomnumber(value[0].value)
                break
            case 'ownerId':
                PremiseOwner(value[0].value)
                break
            case 'installationId':
                InstallationId(value[0].value)
                break
            case 'insDivision':
                InstallationDivision(value[0].value)
                break
            case 'insBillingClass':
                InstallationBillingClass(value[0].value)
                break
            case 'insDateUsed':
                InstallationDate(value[0].value)
                break
            case 'podId':
                InstallationPod(value[0].value)
                break
            case 'podDateUsed':
                InstallationPodDate(value[0].value)
                break
            case 'deviceLocation':
                DeviceLocation(value[0].value)
                break
            case 'maintenanceObject':
                LocationMaintenanceObj(value[0].value)
                break
            case 'equipmentNo':
                DeviceEquipmentNumber(value[0].value)
                break
            case 'serialNo':
                DeviceSerialNumber(value[0].value)
                break
            case 'eqDivision':
                DeviceDivison(value[0].value)
                break
            case 'eqDateUsed':
                DeviceDate(value[0].value)
                break
            case 'invoiceNo':
                FicaDocNumber(value[0].value)
                break
            case 'invPostingDate':
                PostingDate(value[0].value)
                break
            case 'orderNo':
                ServiceOrderNumber(value[0].value)
                break
            case 'orderStatus':
                ServiceOrderStatus(value[0].value)
                break
            case 'orderCategory':
                ServiceOrderCategory(value[0].value)
                break
            case 'orderType':
                ServiceOrderType(value[0].value)
                break
            case 'sNotificationNo':
                SoNotificationNumber(value[0].value)
                break
            case 'mOrderNo':
                ServiceNotificationNumber(value[0].value)
                break
            case 'mOrderStatus':
                ServiceNotificationStatus(value[0].value)
                break
            case 'mNotificationNo':
                SnNotificationNumber(value[0].value)
                break
            case 'mOrderType':
                ServiceNotificationOrderTyp(value[0].value)
                break
            case 'xGlobalDate':
                GlobalDate(value[0].value)
                break
            case 'xCompayCode':
                CompanyCode(value[0].value)
                break
            case 'xDivision':
                Division(value[0].value)
                break
            case 'findDeviceLocationViaDeviceIndicator':
                FindLocByDeviceId(value[0].value)
                break
            case 'dataFinderKeepSelectionIndicator':
                KeepSelection(value[0].value)
                break
            case 'genericSearch':
                Searchstring(value[0].value)
                break
            case 'bpDateOfBirth':
                BusinessPartnerBirthdate(value[0].value)
                break
            case 'bpBirthPlace':
                BusinessPartnerBirthPlace(value[0].value)
                break
            case 'bpEmail':
                BusinessPartnerEmail(value[0].value)
                break
            case 'contractDateUsedTo':
                VaildDateTo(value[0].value)
                break
            case 'customerReference':
                SaleasDistributionPonumber(value[0].value)
                break
            case 'salesAndDistributionNo':
                SalesDocumentNumber(value[0].value)
                break
            case 'salesOrganization':
                SalesOrganization(value[0].value)
                break
            case 'salesDocumentType':
                SalesDocumentType(value[0].value)
                break
            case 'internationalAddrIndicator':
                InternationalAddrIndicator(value[0].value)
                break
            case 'versionIdIndicator':
                InternationalVersionAddr(value[0].value)
                break
            case 'processingVariant':
                ProcessingVariantDisconnRec(value[0].value)
                break
            case 'disconnectionReason':
                DisconnectionReason(value[0].value)
                break
            case 'disconnDocStatus':
                DisconnectionDocumentStatus(value[0].value)
                break
            case 'recordCreatedDate':
                CreationDate(value[0].value)
                break
            case 'disconnDocNo':
                DisconnectionDocumentNumber(value[0].value)
                break
            case 'iBan':
                IbanNumber(value[0].value)
                break
            case 'bpIdentificationType':
                IdentificationType(value[0].value)
                break
            case 'bpIdentificationNo':
                IdentificationNumber(value[0].value)
                break
            case 'docNotReleasedIndicator':
                DocumentToBeReleased(value[0].value)
                break
                    
                    
                    
                    default:
                        // Handle any additional dynamic fields here if necessary
                        break
                }
            }
        }

        // Iterate through key-value pairs again for fields outside IsFindpar
        jsonObject.each { key, value ->
            switch (key) {
                case 'maxRows':
                    IvMaxrows(value[0].value) 
                    break
                case 'objectType':
                    IvObjtype(value[0].value) 
                    break
            }
        }

        // Always include ItAdditionalFilter with constant values
        ItAdditionalFilter {
            'item' {
                Fieldname('QueryFilter') 
                FieldValue(headers.get("QueryFilter")) 
                Sign('I') 
                Option('') 
                Low("") 
                High("") 
            }
        }
    }

    // Set the XML output as the message body
    message.setBody(writer.toString())

    // Return the modified message
    return message
}
