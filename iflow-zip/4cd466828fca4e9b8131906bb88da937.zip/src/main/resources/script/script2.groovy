import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.IOException;
import java.util.Map;
import groovy.util.XmlSlurper;
import groovy.xml.*

def Message processData(Message message) {
    
	def ErrorCode = '0000';
    def ErrorDesc = '';
	try{	
	
	def map = message.getProperties();
	def ex = map.get("CamelExceptionCaught");
	if (ex!=null){
	    if (ex.getClass().getCanonicalName().equals("org.apache.cxf.binding.soap.SoapFault")) {
        def xml = XmlUtil.serialize(ex.getOrCreateDetail());
        message.setBody(xml);
    }
		
		if (ex instanceof org.apache.cxf.interceptor.Fault) {
			String xml = ex.getDetail() as String;
			ErrorDesc = ex.getMessage() as String;
			def detail = new XmlSlurper().parseText(xml);
		    def Code = detail.ProcessingFault.Code.text();
		    def ParamDetail = detail.ProcessingFault.Message.text();

		    String temp, mes;
			if(Code == '1020'){
				String[] err_msg = ParamDetail.split("([.][:])|([.]..[:])");
				for(int i =0;i<err_msg.length;i = i+1){
				temp = err_msg[i];
				err_msg[i] = temp.replaceAll('[/][*]\\[(localname|local-name).*[/][*]\\[(localname|local-name)..=.[a-zA-Z]*.\\]', '');
				if (err_msg[i] != ' '){
					if(mes == null){
						mes = err_msg[i];
					}
					else
						mes = mes + ', ' + err_msg[i];
					}	
				}
			}
			if (mes != null){
				ParamDetail = mes;
			}
			message.setProperty("Code",Code);
		    message.setProperty("ParamDetail",ParamDetail);
		}	
	}
	} catch (Exception ex01) {
	    message.setProperty("Code",ErrorCode);
	    message.setProperty("ParamDetail",ErrorDesc);
	}
    return message;

}