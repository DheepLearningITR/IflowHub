/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String) as String;
       def root = new XmlSlurper().parseText(body);
       def targetXMLString = "<sendInvoiceResponseType xmlns=\"http://fitcons.com/earchive/invoice\"> <Detail xmlns=\"\"/> <Result xmlns=\"\"> <Result/> </Result> <preCheckErrorResults xmlns=\"\"> <preCheckError> <UUID></UUID> <Vkn/> <InvoiceNumber/> <ErrorCode/> <ErrorDesc/> <Filename/> </preCheckError> </preCheckErrorResults> <preCheckSuccessResults xmlns=\"\"> <preCheckSuccess> <UUID/> <Vkn/> <InvoiceNumber/> <SuccessCode/> <SuccessDesc/> <Filename/> <sha256Hash/> <binaryData/> </preCheckSuccess> </preCheckSuccessResults> <Attachements xmlns=\"http://fitcons.com/earchive/invoice\"> <Name xmlns=\"\"/> <Value xmlns=\"\"/> </Attachements> </sendInvoiceResponseType>";
       def targetXML = new XmlSlurper().parseText(targetXMLString);

       String UUID = root.UUID.text();
       String ID = root.ID.text();
       String DocData = root.DocData.text();
       String RespCode = root.ResponseCode.text();
       String RespDesc = root.RespDescription.text();
      // String response = message.getProperty("RESPONSE_PAYLOAD");
       if ( (ID == '' && DocData != '') || (ID != '' && DocData == '') || ( ID == '' && UUID != '' ) ){
           targetXML.Detail.replaceBody("Invoice is not signed");
           targetXML.Result.Result.replaceBody("FAIL");
           targetXML.preCheckSuccessResults.replaceBody("");
           targetXML.preCheckErrorResults.preCheckError.each { error ->
           error.UUID.replaceBody(UUID);
           error.ErrorCode.replaceBody("70");
           error.ErrorDesc.replaceBody(" Invoice isn’t signed yet.");
           error.InvoiceNumber.replaceBody(ID);
           }
       }
       else{
           targetXML.Detail.replaceBody(RespCode + " " + RespDesc);
           targetXML.Result.Result.replaceBody("SUCCESS");
           targetXML.preCheckErrorResults.replaceBody("");
           targetXML.preCheckSuccessResults.preCheckSuccess.each { success ->
           success.UUID.replaceBody(UUID);
           success.InvoiceNumber.replaceBody(ID);
           success.SuccessCode.replaceBody(RespCode);
           success.SuccessDesc.replaceBody(RespDesc);
           success.binaryData.replaceBody(DocData);
           }
       }
        targetXML.Attachements.each { attach ->
        attach.Name.replaceBody("RESPONSE_PAYLOAD");
        attach.Value.replaceBody(body);

        }
       String outxml = groovy.xml.XmlUtil.serialize( targetXML );
       message.setBody( outxml );
       return message;
}