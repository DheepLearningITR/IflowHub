import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.io.IOException;
import java.util.Map;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    def ErrorCode = '0000';
    def ErrorDesc = '';
	def exType;
	def cause;
	try{	
	
	def map = message.getProperties();
	def ex = map.get("CamelExceptionCaught");
	
	if (ex!=null){
		if (ex instanceof org.apache.cxf.interceptor.Fault) {
		    cause = ex.getCause();
		    exType = cause.getClass().getCanonicalName();
		    if (exType == "org.apache.cxf.transport.http.HTTPException"){
		        def stat_code = cause.getResponseCode();
		        def stat_res = cause.getMessage();
		        stat_res = stat_res.replaceAll('([<][!]DOCTYPE\\s*[a-zA-Z\\s0-9\\W]*[>])?\\s*[<]html\\s*[a-zA-Z\\s0-9\\W]*[>]\\s*[a-zA-Z\\s0-9\\W]+[<][\\/]html[>]\\s*\\n*', '');
		        message.setProperty("sendUBLeArchive", 'false');
		        message.setProperty("Code",stat_code);
		         message.setProperty("ParamDetail",stat_res);
		    }
		    else{
			String xml = ex.getDetail() as String;
			ErrorDesc = ex.getMessage() as String;
			def detail = new XmlSlurper().parseText(xml);
		    def Code = detail.ProcessingFault.Code.text();
		    def ParamDetail = detail.ProcessingFault.Message.text();
		    message.setProperty("Code",Code)
		    message.setProperty("ParamDetail",ParamDetail);
		    }
		}	
	}
	} catch (Exception ex01) {
	    message.setProperty("Code",ErrorCode);
	    message.setProperty("ParamDetail",ErrorDesc);
	}
    return message;
}
