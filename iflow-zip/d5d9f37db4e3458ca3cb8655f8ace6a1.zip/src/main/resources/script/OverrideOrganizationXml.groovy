import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

    def properties = message.getProperties() as Map<String, Object>;

    def body = message.getBody(java.lang.String) as String;

    message.setProperty("organizationXml" , body);

    return message;


}
