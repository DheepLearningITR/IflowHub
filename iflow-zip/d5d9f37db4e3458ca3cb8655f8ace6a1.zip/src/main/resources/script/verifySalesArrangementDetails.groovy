import com.sap.it.api.mapping.*;

def String verifySalesArrangementDetails(String SalesOrganisationID, String DivisionCode, String DistributionChannelCode, MappingContext context){
    //def properties = context.getProperties() as Map<String, Object>;
    //int timeDifference = properties.get("timeDifference").toInteger();
    
    // def messageLog = messageLogFactory.getMessageLog(message);
    // messageLog.addAttachmentAsString("Sales Org Groovy", SalesOrganisationID + "---" + DivisionCode + "---" + DistributionChannelCode  , "text/json");
    
	def externalisedSalesOrganisationID =  context.getProperty('SalesOrganisationID');
	//properties.get("SalesOrganisationID");
	//context.getProperty('SalesOrganisationID');
	def externalisedDistributionChannelCode = context.getProperty('DistributionChannelCode');
	def externalisedDivisionCode = context.getProperty('DivisionCode');
	//def externalisedRoleCode = context.getProperty("RoleID");
	if((externalisedSalesOrganisationID.equals(SalesOrganisationID) || externalisedSalesOrganisationID.equals("*")) && (externalisedDistributionChannelCode.equals(DistributionChannelCode) || externalisedDistributionChannelCode.equals("*"))  && (externalisedDivisionCode.equals(DivisionCode) || externalisedDivisionCode.equals("*"))){
	    
	   // messageLog.addAttachmentAsString("Sales Org Groovy", "successful"  , "text/json");
	    return 'successful';
	}
	else{
	   // messageLog.addAttachmentAsString("Sales Org Groovy", "unsuccessful"  , "text/json");
	    return 'unsuccessful';
	}
}