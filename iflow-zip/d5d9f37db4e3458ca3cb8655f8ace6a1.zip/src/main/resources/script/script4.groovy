import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
       def jsonSlurper = new JsonSlurper();
       def response = jsonSlurper.parseText(message.getBody(java.lang.String) as String) ;
       
      if (response.statusCode == 200)
      {
        if(message.getProperty("NewAccountCreation")){
            message.setProperty("AccountIsNewUser" ,response.newUser);
            message.setProperty("AccountNewUid" ,java.net.URLEncoder.encode( response.uid));
            message.setProperty("AccountNewUserFirstTimePassword" , response.firstTimePassword);
        }
      }
      
    return message;
}