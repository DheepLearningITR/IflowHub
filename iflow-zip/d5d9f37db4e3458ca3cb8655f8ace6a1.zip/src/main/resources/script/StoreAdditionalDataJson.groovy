import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);

    messageLog.addAttachmentAsString("Additional Data Json", body , "text/xml");

    def properties = message.getProperties() as Map<String, Object>;

    message.setProperty("additionalDataJson" , body);

    return message;
}
