import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
    //Body
    def jsonSlurper = new JsonSlurper();
    def properties = message.getProperties() as Map<String, Object>;
    
    def index = properties.get("contactPersonIndex").toInteger();
    def isSingleContactPerson = properties.get("isSingleContactPerson");
    
    if( isSingleContactPerson )
    {
        def contactPersonsData = properties.get("contactPersons") as String;
        message.setProperty("contactPersonData" , contactPersonsData );
        
        def storedPayload = jsonSlurper.parseText(contactPersonsData as String);
        message.setProperty("AccountUID" , storedPayload.email );
        message.setProperty("AccountUIDEncoded" , java.net.URLEncoder.encode(storedPayload.email) );
    }
    else{
        def contactPersonsData = jsonSlurper.parseText(properties.get("contactPersons")); 
        def jsonBuilder = new JsonBuilder(contactPersonsData[index].customer);
        message.setProperty("contactPersonData" , jsonBuilder );
        message.setProperty("AccountUID" , contactPersonsData.customer[index].email );
        message.setProperty("AccountUIDEncoded" , java.net.URLEncoder.encode(contactPersonsData.customer[index].email) );
    }
    
    message.setProperty("contactPersonIndex" , index + 1 );

    return message;
}
