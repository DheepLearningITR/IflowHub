import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

    def properties = message.getProperties() as Map<String, Object>;

    message.setProperty("AccountUIDEncoded" , java.net.URLEncoder.encode(properties.get("AccountUID")) );

    def messageLog = messageLogFactory.getMessageLog(message);

    messageLog.addAttachmentAsString("EncodeAccountUID : ", java.net.URLEncoder.encode(properties.get("AccountUID")) , "text/json");

    return message;
}
