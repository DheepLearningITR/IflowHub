import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
    
    def jsonSlurper = new JsonSlurper();

   
        def properties = message.getProperties() as Map<String, Object>;
   
    def messageLog = messageLogFactory.getMessageLog(message);

    def contactPersonsData = jsonSlurper.parseText(properties.get("contactPersons") as String);
    
   def contactPersons = contactPersonsData.Payload.customers; 
   
   def index = properties.get("contactPersonIndex").toInteger();
   
    messageLog.addAttachmentAsString("Contact Person" , "\n\n" + contactPersons[index].customer,
                                                        "text/xml");
                                                        
    
    
    message.setProperty("contactPersonIndex" , index + 1 );
    
   
    return message;
}
