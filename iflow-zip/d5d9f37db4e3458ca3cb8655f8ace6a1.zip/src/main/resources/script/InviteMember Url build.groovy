import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
def Message processData(Message message) {

    def jsonSlurper = new JsonSlurper();

    def getAccountSearchRespose =  jsonSlurper.parseText(message.getBody(java.lang.String) as String);
    def properties = message.getProperties() as Map<String, Object>;
    
    def organizationPayload = jsonSlurper.parseText(properties.get("BusinessPartnerOrganisation") as String) ;
    
    def storedPayload = jsonSlurper.parseText(properties.get("contactPersonData") as String);
    def org = organizationPayload.OrgData.organizations[0];
    
    message.setProperty("additionalDataXml" , "<Data></Data>");
    message.setProperty("NewAccountCreation" , false);
    
    if (getAccountSearchRespose.totalCount == 0){
        
        def profile = new JsonBuilder()
        profile([
                firstName: storedPayload.firstName,
                lastName: storedPayload.lastName,
                email:  storedPayload.email,
                phones: [[type : "" ,number :storedPayload.phone  ]]
        ]);

        def accountOrganization = new JsonBuilder()
        accountOrganization([
                department: storedPayload.department,
                job: storedPayload.jobFunction,
                status:"active",
                roles: []
        ]);
        
        message.setProperty("profile" , profile.toString());
        message.setProperty("accountOrganization" , accountOrganization.toString());
        
        
        
        message.setProperty("AccountAssociated" , false);
        message.setProperty("NewAccountCreation" , true);
    }
    else
    {
        
         def accountAssociated = false;
         for(def accountOrg : getAccountSearchRespose.results.groups.organizations){   
             if (accountOrg.bpid == org.BPID) accountAssociated = true;
         }     		
        
        message.setProperty("AccountAssociated" , accountAssociated);
        
        def profile = new JsonBuilder()
        profile([
                firstName: storedPayload.firstName,
                lastName: storedPayload.lastName,
                email:  storedPayload.email,
                phones: [[type : "" ,number :storedPayload.phone  ]]
        ]);
        
        def organizationInfo = new JsonBuilder()
        organizationInfo([
                department: storedPayload.department,
                job: storedPayload.jobFunction,
                status:"active"
        ]);
        
        message.setProperty("profile" , profile.toString());
        message.setProperty("accountOrganization" , organizationInfo.toString());
        message.setProperty("uid" , getAccountSearchRespose.results.UID[0] as String );

    }

    return message;
}