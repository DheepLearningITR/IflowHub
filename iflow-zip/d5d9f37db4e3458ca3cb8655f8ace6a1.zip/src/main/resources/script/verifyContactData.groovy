import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
   
    //def pmap = message.getProperties();
    
    def body = message.getBody(java.lang.String) as String;
  
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    def jsonValue = object.Payload.customers;
    String pay = '';
    
    if(jsonValue instanceof groovy.json.internal.LazyMap){
        pay = new JsonBuilder(jsonValue.customer).toPrettyString();
    }else{
            pay = new JsonBuilder(jsonValue).toPrettyString();
    }
    if(pay.isEmpty()){
    message.setProperty("BPCustomerStatus" , '0')}
    else{
    message.setProperty("BusinessPartnerCustomer",pay);
     message.setProperty("BPCustomerStatus" , '1')
    }

return message;
}
