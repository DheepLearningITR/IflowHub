import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();

    def properties = message.getProperties();
    def count = properties.get("count");
    def resultRows = properties.get("resultRows");
    message.setProperty("eventId", resultRows[count].INTERNAL_ID);
    
    return message;
}