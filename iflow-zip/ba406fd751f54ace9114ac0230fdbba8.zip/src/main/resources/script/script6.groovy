import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def properties = message.getProperties();
    def eventId = properties.get("eventId");
    
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);

    def db_schema = properties.get('Database_Schema_Name');
    
    sqlStatement.root {
        sqlStatement.UpdateStatement {
            sqlStatement.app_sourcing_events(action: 'UPDATE') {
                sqlStatement.table(db_schema + '.APP_SOURCING_EVENTS')
                sqlStatement.access {
                    sqlStatement.MODIFIEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                    sqlStatement.MODIFIEDBY(properties.get('Extension_User'))
                    sqlStatement.STEP_FLOW('EVENT_ITEMS_BID')
                }
                sqlStatement.key {
                    sqlStatement.INTERNAL_ID(eventId)
                }
            }
        }
    };
   
   message.setBody(writer.toString());
  
    return message;
}