import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def jsonSlurper = new JsonSlurper();
    def apiResult = jsonSlurper.parse(body);
    
    def properties = message.getProperties();
    valueCount = properties.get("count");
    valueCount = valueCount + 1;
    message.setProperty("count", valueCount);
    def eventId = properties.get("eventId");
    
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    def db_schema = properties.get('Database_Schema_Name');
    
    sqlStatement.root {
        for (rfxInvitation in apiResult.payload) {
            sqlStatement.InsertStatement {
                sqlStatement.app_sourcing_supplier_invitation(action: 'INSERT') {
                    sqlStatement.table(db_schema + '.APP_SOURCING_SUPPLIER_INVITATION')
                    sqlStatement.access {
                        sqlStatement.EVENT_ID(eventId)
                        sqlStatement.SUPPLIER_ORG_ID(rfxInvitation.orgId)
                        if (rfxInvitation.organization) {
                            sqlStatement.SUPPLIER_ORG_NAME(rfxInvitation.organization.name)
                        }
                        sqlStatement.SUPPLIER_INVITATION_ID(rfxInvitation.invitationId)
                        sqlStatement.SUPPLIER_USER_ID(rfxInvitation.userId)
                        sqlStatement.SUPPLIER_HAS_BID(rfxInvitation.hasBid)
                        sqlStatement.SUPPLIER_BID_STATUS(rfxInvitation.supplierBidStatus)
                        
                        sqlStatement.CREATEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                        sqlStatement.CREATEDBY(properties.get('Extension_User'))
                    }
                }
            }
        }
    };
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('RFXItem SQL Insert - Event: ' + eventId, writer.toString(), 'text/plain');
   
    //set body
    message.setBody(writer.toString());
  
    return message;
}