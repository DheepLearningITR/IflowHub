import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;

    
def Message build_request_run_query(Message message) {

	JsonBuilder builder = new JsonBuilder();
    
    def MAX_RESULTS         =  message.getProperty("DEFAULT_MAX_RESULTS");
    def TIMEOUT_MS          =  message.getProperty("TIMEOUT_MS ");
    def dryMode             =  message.getProperty("testQuery").toString().toBoolean();
	def queryString = message.getProperty("queryString");
	def projectId = message.getHeader("projectId", java.lang.String.class);
	
	if ( dryMode ) {
	    MAX_RESULTS = 1;
	}
	
	message.setProperty("MAX_RESULTS",MAX_RESULTS)
	
     builder { query            queryString
                maxResults      MAX_RESULTS 
               timeoutMs        TIMEOUT_MS
               dryRun           false
               useLegacySql     false
            
         
            };
            
    def queryRequest = JsonOutput.prettyPrint(builder.toString());
    message.setBody(queryRequest);          
	
	return message;
}

def Message process_response_run_query(Message message) {
    
    def response = new JsonSlurper().parseText(message.getBody(String));
    message.setProperty('jobId',response.jobReference.jobId);
    message.setProperty('location',response.jobReference.location);
    message.setProperty('totalRecordCount',response.totalRows);
    
    
    return message;

}


def Message build_response_run_query_rowcount(Message message) {
            
   	JsonBuilder builder = new JsonBuilder();
    
 	def totalRows = message.getProperty("totalRecordCount");
	
     builder { d { results 
                    {
                        totalRecordCount    totalRows     
                    }
                 }
            }
    
    def queryResponse = JsonOutput.prettyPrint(builder.toString());
    message.setBody(queryResponse);        
    
    return message;

}

def Message build_request_get_query_Results(Message message) {

    def MAX_RESULTS     =  message.getProperty("DEFAULT_MAX_RESULTS");
    def location        =  message.getProperty('location');
    def pageToken       =  message.getProperty('pageToken');
    
    def queryParameters = 'location=' + location  + '&maxResults=' + MAX_RESULTS;
    
    if ( pageToken != null && pageToken != '' ) {
        queryParameters = queryParameters + '&pageToken=' + pageToken;
    }
    
    message.setProperty('queryParameters',queryParameters);
    
    def body = "";
    message.setBody(body) 
 
	return message;
}


def Message build_response_get_query_Results(Message message) {

    
    def payload = message.getBody(java.lang.String.class)toString();
    def slurper = new JsonSlurper();
    def payloadParsed = slurper.parseText( payload );
    JsonBuilder builder = new JsonBuilder();
    
    def totalRows = payloadParsed.totalRows;
    def pageToken = payloadParsed.pageToken;
    def jobId     = payloadParsed.jobReference.jobId;
    
    def columns = [];	
    payloadParsed.schema.fields.each { field ->
        Map column = [
            name: ""
        ]
        column.name = field.name;
        columns.add(column);
     }

    JsonArray recordArray = new JsonArray();
    JsonObject record;
   
    def i = 0;
    payloadParsed.rows.each { row ->
        i = 0;
        record = new JsonObject();
     	row.f.each { element ->
            record.addProperty(columns[i].name, element.v.toString());
            i = i + 1;
     	};
     	recordArray.add(record);
      };
     
     
    JsonObject d = new JsonObject();
	JsonObject results = new JsonObject();
	JsonObject records = new JsonObject();

	records.add("records", recordArray);
	results.add("results", records);
	results.addProperty("returnedRecordCount", recordArray.size());
	results.addProperty("totalRecordCount", totalRows == null ? 0 : totalRows);

	if (pageToken != null) {
			JsonObject next = new JsonObject();
			next.addProperty("jobId", jobId);
			next.addProperty("pageToken",pageToken );
			results.add("next", next);
	}

	d.add("d", results);
  
    message.setBody(d.toString());  
        
    return message;
    
}


def Message build_response_get_job(Message message) {

    def payload = message.getBody(java.lang.String.class)toString();
    def slurper = new JsonSlurper();
    def payloadParsed = slurper.parseText( payload );
    JsonBuilder builder = new JsonBuilder();
    
    def location = payloadParsed.jobReference.location;
    message.setProperty('location',location);
    
    return message;

}
 
    
             
    

