package src.main.resources.script;

import com.sap.gateway.ip.core.customdev.util.Message;

import java.util.AbstractMap;
import java.util.HashMap;
import java.util.ListIterator;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;

import java.lang.reflect.Type;
import java.security.Key;
import java.security.KeyPair;
import java.security.PrivateKey;

import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.GenericJson;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.util.Data;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;

import com.google.api.services.bigquery.BigqueryScopes;
import com.google.api.services.bigquery.Bigquery;
import com.google.api.services.bigquery.BigqueryRequest;
import com.google.api.services.bigquery.model.DatasetList;
import com.google.api.services.bigquery.model.ProjectList;
import com.google.api.services.bigquery.model.QueryRequest;
import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.QueryResponse;
import com.google.api.services.bigquery.model.GetQueryResultsResponse;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableCell;
import com.google.api.services.bigquery.model.Job;
import com.google.api.services.bigquery.Bigquery.Jobs.GetQueryResults;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonNull;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import com.google.api.client.http.HttpRequestInitializer
import com.google.api.client.http.HttpRequest
import com.google.api.services.bigquery.model.ErrorProto
import java.math.BigInteger

class MyHttpRequestInitializer {

	HttpRequestInitializer setHttpTimeout(final HttpRequestInitializer requestInitializer) {
		return new HttpRequestInitializer() {
			@Override
			public void initialize(HttpRequest httpRequest) throws IOException {
				requestInitializer.initialize(httpRequest);
				httpRequest.setConnectTimeout(3 * 60000);  // 3 minutes connect timeout
				httpRequest.setReadTimeout(3 * 60000);  // 3 minutes read timeout
			}
		}

	}

}

abstract class BaseGsonSerializer<T extends GenericJson> implements JsonSerializer<T> {

	protected <U extends AbstractMap> Object getValueOrJsonNull(U map, String key) {
		return getJsonPrimitiveOrNull(map.get(key));
	}

	protected JsonElement getValueOrJsonNull(Object value) {
		return getJsonPrimitiveOrNull(value);
	}

	protected <U extends AbstractMap> Object getValueOrJsonNull(U map) {
		if ( map == null ) {
			return JsonNull.INSTANCE;
		}
		return map;
	}

	protected JsonElement getJsonPrimitiveOrNull(Object value) {
		try {
			if (value != null) {
				// TODO: Maybe use the serialize method from serialization context here instead
				return new JsonPrimitive(value);
			}
		} catch (Exception ex) {
			return JsonNull.INSTANCE;
		}
		return JsonNull.INSTANCE;
	}

	public abstract JsonElement serialize(T arg0, Type arg1, JsonSerializationContext arg2);
}

class DatasetListSerializer extends BaseGsonSerializer<DatasetList> {
	@Override
	public JsonElement serialize(DatasetList src, Type typeOfSrc, JsonSerializationContext context) {
		JsonArray jsonDatasetList = new JsonArray();
		JsonObject jsonDataset;
		for(DatasetList.Datasets dataset: src.getDatasets()) {
			jsonDataset = new JsonObject();
			jsonDataset.add("datasetId", getValueOrJsonNull(dataset.getDatasetReference().getDatasetId()));
			jsonDataset.add("datasetName", getValueOrJsonNull(dataset.getFriendlyName()));
			jsonDatasetList.add(jsonDataset);
		}

		return jsonDatasetList;
	}
}

class ProjectListSerializer extends BaseGsonSerializer<ProjectList> {
	@Override
	public JsonElement serialize(ProjectList src, Type typeOfSrc, JsonSerializationContext context) {
		JsonArray jsonProjectList = new JsonArray();
		JsonObject jsonProject;
		for(ProjectList.Projects project: src.getProjects()) {
			jsonProject = new JsonObject();
			jsonProject.add("projectNumericId", getValueOrJsonNull(project.getNumericId()));
			jsonProject.add("projectId", getValueOrJsonNull(project.getId()));
			jsonProject.add("projectName", getValueOrJsonNull(project.getFriendlyName()));
			jsonProject.add("datasets", context.serialize(project.get("datasetList"), DatasetList.class));
			jsonProjectList.add(jsonProject);
		}

		return jsonProjectList;
	}
}

class GetQueryResultsResponseSerializer extends BaseGsonSerializer<GetQueryResultsResponse> {
	@Override
	public JsonElement serialize(GetQueryResultsResponse src, Type typeOfSrc, JsonSerializationContext context) {
		ArrayList<TableFieldSchema> schema;
		JsonArray records = new JsonArray();
		JsonObject record;
        
        if (src.getSchema() != null ) {
        	schema = src.getSchema().getFields();
    		for(TableRow row: src.getRows()) {
    			record = new JsonObject();
    			TableCell field;
    			for(int i=0; i<row.getF().size(); i++) {
    				field = row.getF()[i];
    
    				if (Data.isNull(field.getV())) {
    					record.add(schema[i].getName(), JsonNull.INSTANCE);
    				} else {
    					record.addProperty(schema[i].getName(), field.getV().toString());
    				}
    			}
    			records.add(record);
    		}
        } else {
            record = new JsonObject();
            record.addProperty('TotalRows',src.getTotalRows().toString());
            for(ErrorProto error: src.getErrors()) {
    		    record.addProperty('Message',error.getMessage());
    		}
    		records.add(record);
    		
        }
		return records;
	}
}

class PageIterator <T extends GenericJson> implements Iterator<T> {
	private BigqueryRequest<T> request;
	private boolean hasNext = true;
	public PageIterator(final BigqueryRequest<T> requestTemplate) {
		this.request = requestTemplate;
	}

	public boolean hasNext() {
		return this.hasNext;
	}

	public T next() {
		if (!hasNext) {
			throw new NoSuchElementException();
		}
		try {
			T response = request.execute();
			if (response.containsKey("pageToken")) {
				request = request.set("pageToken", response.get("pageToken"));
			} else {
				this.hasNext = false;
			}
			return response;
		} catch (IOException e) {
			return null;
		}
	}

	public void remove() {
		this.next();
	}
}

public class GoogleBigQueryManager {
	
	static final int MAX_RESULTS = 5000;
	static final int TIMEOUT_MS = 10000;
	
	Bigquery bigquery;
	Gson gson;

	GoogleBigQueryManager() {}

	GoogleBigQueryManager(String service_account_id,String service_account_email) {
		this.bigquery = getBigQuery(service_account_id, service_account_email);
	}

	private Bigquery getBigQuery(String service_account_id,String service_account_email) {
		HttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
		JsonFactory jsonFactory = JacksonFactory.getDefaultInstance();
		GoogleCredential credential = this.authenticate(service_account_id, service_account_email, httpTransport, jsonFactory);
		return new Bigquery.Builder(httpTransport, jsonFactory,  new MyHttpRequestInitializer().setHttpTimeout(credential)).build();
	}

	public void setBigquery(Bigquery bigquery) {
		this.bigquery = bigquery;
	}

	private GoogleCredential authenticate(String service_account_id, String service_account_email, HttpTransport httpTransport, JsonFactory jsonFactory) {
		KeystoreService service = ITApiFactory.getApi(KeystoreService.class, null);
		KeyPair keyPair = service.getKeyPair(service_account_id);
		PrivateKey privateKey = keyPair.getPrivate();

		//Get Google Credential
		GoogleCredential credential = new GoogleCredential.Builder()
				.setTransport(httpTransport)
				.setJsonFactory(jsonFactory)
				.setServiceAccountId(service_account_id)
				.setServiceAccountPrivateKey(privateKey)
				.setServiceAccountScopes(BigqueryScopes.all())
				.build();
		return credential;
	}

	private Gson getGson() {
		if (this.gson == null) {
			this.gson = new GsonBuilder()
					.registerTypeAdapter(ProjectList.class, new ProjectListSerializer())
					.registerTypeAdapter(DatasetList.class, new DatasetListSerializer())
					.registerTypeAdapter(GetQueryResultsResponse.class, new GetQueryResultsResponseSerializer())
					.serializeNulls()
					.create();
		}
		return this.gson;
	}

	private ProjectList getProjectList() {

		ProjectList projectList = this.bigquery.projects().list().execute();
		String projectId;

		for (ListIterator<ProjectList.Projects> iter = projectList.getProjects().listIterator(); iter.hasNext(); ) {
			ProjectList.Projects project = iter.next();

			projectId = project.getId();
			Bigquery.Datasets.List datasetRequest = bigquery.datasets().list(projectId);
			DatasetList datasetResponse = datasetRequest.execute();
			project.put("datasetList", datasetResponse);
		}

		return projectList;
	}
	
	public JsonElement getProjectsJsonElement() {
		JsonObject d = new JsonObject();
		JsonObject results = new JsonObject();

		ProjectList projects = getProjectList();
		Gson gson = this.getGson();

		results.add("results", gson.toJsonTree(projects, ProjectList.class));
		d.add("d", results);

		return d;
	}

	private QueryRequest getQueryRequest(String queryString, Long maxResults = MAX_RESULTS, Long timeout = TIMEOUT_MS, Boolean useLegacySQL = false, Boolean dryRun = false) {
		return new QueryRequest()
				.setQuery(queryString)
				.setMaxResults(maxResults)
				.setTimeoutMs(timeout)
				.setUseLegacySql(useLegacySQL)
				.setDryRun(dryRun);
	}

	

	private String getJsonFromGetQueryResults(GetQueryResults getQueryResults) {
		JsonObject d = new JsonObject();
		JsonArray recordArray = new JsonArray();
		JsonObject results = new JsonObject();
		JsonObject records = new JsonObject();

		GetQueryResultsResponse queryResponse = getQueryResults.execute();
		recordArray = (JsonArray) getGson().toJsonTree(queryResponse);
		records.add("records", recordArray);
		results.add("results", records);
		results.addProperty("returnedRecordCount", recordArray.size());
		results.addProperty("totalRecordCount", queryResponse.getTotalRows() == null ? 0 : queryResponse.getTotalRows() );

		if (queryResponse.getPageToken() != null) {
			JsonObject next = new JsonObject();
			next.addProperty("jobId", queryResponse.getJobReference().getJobId());
			next.addProperty("pageToken", queryResponse.getPageToken());
			results.add("next", next);
		} else {
			results.add("next", JsonNull.INSTANCE);
		}

		d.add("d", results);

		return d.toString();
	}

	private JsonArray getRecordsFromPages(Iterator<GetQueryResultsResponse> pages) {

		ArrayList<TableFieldSchema> schema;
		JsonArray records = new JsonArray();
		JsonObject record;
		GetQueryResultsResponse queryResultsResponse;

		while(pages.hasNext()) {
			queryResultsResponse = pages.next();
			records.addAll(getGson().toJsonTree(queryResultsResponse));
		}

		return records;
	}

	private static <T extends GenericJson> Iterator<T> getPagesIterator(final BigqueryRequest<T> requestTemplate) {
		return new PageIterator(requestTemplate);
	}
	
	public String getQueryRowCount(String projId, String queryString) {
		QueryRequest queryRequest = this.getQueryRequest(queryString, 1, 600000);
		QueryResponse queryResponse = this.bigquery
				.jobs()
				.query(projId, queryRequest)
				.execute();
        
        String jobId = queryResponse.getJobReference().getJobId();
		String projectId = queryResponse.getJobReference().getProjectId();
		
		Job job = this.bigquery.jobs().get(projectId, jobId).execute();
		String jobLocation = job.getJobReference().getLocation();
		
		GetQueryResults getQueryResults = this.bigquery
				.jobs()
				.getQueryResults(projectId,jobId)
				.setLocation(jobLocation)
				.setMaxResults(1);
				
        queryResponse = getQueryResults.execute();		

		JsonObject d = new JsonObject();
		JsonObject results = new JsonObject()
		JsonObject items = new JsonObject();

		items.addProperty("totalRecordCount", queryResponse.getTotalRows() == null ? 0 : queryResponse.getTotalRows() );
		results.add("results", items);
		d.add("d", results);

		return d.toString();
	}
	
	public String getQueryResults(String projId, String queryString, Long maxResults = MAX_RESULTS, Long timeout = TIMEOUT_MS) {
		QueryRequest queryRequest = this.getQueryRequest(queryString, maxResults, 600000);
		
		long start = System.currentTimeMillis();
		long end   = start + 30*1000;
		
		QueryResponse queryResponse = this.bigquery
				.jobs()
				.query(projId, queryRequest)				
				.execute();
		
		String jobId = queryResponse.getJobReference().getJobId();
		String projectId = queryResponse.getJobReference().getProjectId();
		
		Job job = this.bigquery.jobs().get(projectId, jobId).execute();
		
		String jobLocation = job.getJobReference().getLocation();
		
		GetQueryResults queryResults = this.bigquery
				.jobs()
				.getQueryResults(projectId,jobId)
				.setLocation(jobLocation)
				.setMaxResults(maxResults);
				
		return getJsonFromGetQueryResults(queryResults);
	}

	public String getQueryResultsForJobAndPageToken(String projectId, String jobId, String pageToken, Long maxResults = MAX_RESULTS, Long timeout = TIMEOUT_MS) {
		GetQueryResults queryResults = this.bigquery
				.jobs()
				.getQueryResults(projectId, jobId)
				.setPageToken(pageToken)
				.setMaxResults(maxResults);
		return getJsonFromGetQueryResults(queryResults);
	}
}

def Message executeQuery(Message message) {

	GoogleBigQueryManager bigqueryManager = new GoogleBigQueryManager(message.getProperty("service_account_id").toString(),message.getProperty("service_account_email").toString());

	String queryString = message.getBody(java.lang.String.class);
	String projectId = message.getHeader("projectId", java.lang.String.class);
	String jobId = message.getHeader("jobId", java.lang.String.class);
	String pageToken = message.getHeader("pageToken", java.lang.String.class);
	Boolean isTestQuery = message.getHeader("testQuery", java.lang.String.class) != null;

	String queryResult;
	try {
		if (jobId != null && pageToken != null) {
			queryResult = bigqueryManager.getQueryResultsForJobAndPageToken(projectId, jobId, pageToken)
		} else if (queryString != null && isTestQuery) {
			queryResult = bigqueryManager.getQueryRowCount(projectId, queryString);
		} else if (queryString != null) {
			queryResult = bigqueryManager.getQueryResults(projectId, queryString);
		}
		message.setBody(queryResult);
	}  catch (GoogleJsonResponseException ex) {
		String errors = build_error_response(ex.getDetails().getCode(),ex.getDetails().getErrors()[0].getMessage());
		message.setBody(errors);
		message.setProperty("response","exception")
	}

	message.setHeader("Content-Type","application/json");
	return message;
}


//------------------------------------------------------------------------------------------------------------------------------------------------------------
//Build error response
//------------------------------------------------------------------------------------------------------------------------------------------------------------
String build_error_response(int code,String message) {

	def error = [
		"code": code,
		"value": message
	]

	def errorObject = [
		"error": error
	]

	def jsonBuilder = new JsonBuilder()
	def response = JsonOutput.toJson(jsonBuilder(errorObject));

	return response;
}