
import com.sap.gateway.ip.core.customdev.util.Message;

import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

def Message logAdHoc(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    
    //headers
    def headers = message.getHeaders();
    def runMode = headers.get("runMode")
    def initializeLastRunDateTime = headers.get("initializeLastRunDateTime")
    def rerunScheduled = headers.get("rerunScheduled")
    def filter = headers.get("filter")
    def initialRunDateTime = headers.get("initialRunDateTime")
    
    //Properties
    def properties = message.getProperties();
    def toDateTime = properties.get("toDateTime");
    def fromDateTime = properties.get("fromDateTime");
    
    messageLog.addCustomHeaderProperty("Run mode", runMode);
    
    if(initializeLastRunDateTime == true && rerunScheduled == false){
        messageLog.addCustomHeaderProperty("Initial Last Run DateTime", initialRunDateTime);
    }
    else if(initializeLastRunDateTime == false && rerunScheduled == true){
        //do nothing
    }
    else{
        messageLog.addCustomHeaderProperty("From DateTime", fromDateTime);
        messageLog.addCustomHeaderProperty("To DateTime", toDateTime);
    }
	
    return message;
}

def Message buildFilter(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    //headers
    def headers = message.getHeaders();
    def runMode = headers.get("runMode")
    
    //Properties
    def properties = message.getProperties();
    def currentRunDateTime = properties.get("currentRunDateTime");
    def lastRunDateTime = properties.get("lastRunDateTime");

    //dateTime variables
    def dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'"
    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(dateFormat)
    LocalDateTime ldtObj
    def fromDateTime
    def toDateTime
    
    //filter variables
    def varFromDateTime = "updatedDateFrom"
    def varToDateTime = "updatedDateTo"
    def filter
    
    messageLog.addCustomHeaderProperty("Run mode", runMode);
    
    ldtObj = LocalDateTime.parse(currentRunDateTime,dateFormatter)
    toDateTime = dateFormatter.format(ldtObj)
    ldtObj = LocalDateTime.parse(lastRunDateTime,dateFormatter)
    fromDateTime = dateFormatter.format(ldtObj)
        
    message.setProperty("fromDateTime", fromDateTime)
    message.setProperty("toDateTime", toDateTime)
    messageLog.addCustomHeaderProperty("From DateTime", fromDateTime);
    messageLog.addCustomHeaderProperty("To DateTime", toDateTime);
    
    filter = '{"' + varFromDateTime + '":"' + fromDateTime + '","' + varToDateTime + '":"' + toDateTime + '"}'

    message.setProperty("filter",filter)
    
    return message;
}
