
import com.sap.gateway.ip.core.customdev.util.Message;

def Message determineException(Message message) {
    final messageLog = messageLogFactory.getMessageLog(message);
    def mapProperties = message.getProperties();
    def mapheaders= message.getHeaders();
    
    Exception exception = mapProperties.get("CamelExceptionCaught");
    
    def errorStep = mapProperties.get("errorStep");
    def exceptionMsg = mapProperties.get("exceptionMsg");
    
    if(exception.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException"))
    {
        message.setProperty("Error", exceptionMsg + "\n" + exception.getResponseBody());
        message.setProperty("ErrorType","Send Data");
        messageLog.addCustomHeaderProperty("Error", exceptionMsg + "\n" + exception.getResponseBody());
        messageLog.addCustomHeaderProperty("Error Type","Send Data");
        
    } else{
        message.setProperty("Error", exceptionMsg);
        message.setProperty("ErrorType", errorStep);
        messageLog.addCustomHeaderProperty("Error", exceptionMsg);
        messageLog.addCustomHeaderProperty("Error Type", errorStep);
    }
    
    return message;
}