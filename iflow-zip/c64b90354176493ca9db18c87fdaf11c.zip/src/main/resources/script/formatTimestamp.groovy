import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;

def String formatTimestamp(String timeStamp) {
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    def createTime = df.parse(timeStamp);
    return createTime.format("yyyyMMddHHmmss");
}