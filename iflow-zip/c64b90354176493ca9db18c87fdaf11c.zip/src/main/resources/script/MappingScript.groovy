import com.sap.it.api.mapping.*;

def void parseAndFind(String[] xmlContent,String[] factName, String[] requiredNode, Output output){
    String nodeToSearch = requiredNode[0]
    def UtilitiesInstallation = new XmlSlurper().parseText(xmlContent[0]);
    UtilitiesInstallation.UtilityInstallationFacts.each{
        String fName = it.FactName.text();
        if(fName.equals(factName[0])){
            output.addValue(it."$nodeToSearch".text());
        }
    }
}

def void parseAndFindAttribute(String[] xmlContent,String[] factName, String[] requiredNode,String[] attrName, Output output){
    String nodeToSearch = requiredNode[0];
    String attributeName = attrName[0];
    def UtilitiesInstallation = new XmlSlurper().parseText(xmlContent[0]);
    UtilitiesInstallation.UtilityInstallationFacts.each{
        String fName = it.FactName.text();
        if(fName.equals(factName[0])){
            output.addValue(it."$nodeToSearch"."$attributeName".text());
        }
    }
}