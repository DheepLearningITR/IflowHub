/*
 * The integration developer needs to create the method processData 
 * This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 * which includes helper methods useful for the content developer:
 * 
 * The methods available are:
    public java.lang.Object getBody()
    
    //This method helps User to retrieve message body as specific type ( InputStream , String , byte[] ) - e.g. message.getBody(java.io.InputStream)
    public java.lang.Object getBody(java.lang.String fullyQualifiedClassName)

    public void setBody(java.lang.Object exchangeBody)

    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()

    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)

    public void setHeader(java.lang.String name, java.lang.Object value)

    public java.util.Map<java.lang.String,java.lang.Object> getProperties()

    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 

	public void setProperty(java.lang.String name, java.lang.Object value)
 * 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;


def Message determineAction(Message message) {
    def body = message.getBody(java.lang.String.class);
    int startIndex = body.indexOf("<action>");
    int endIndex = body.indexOf("</action>");

    if (startIndex >= 0 && endIndex >= 0) {
        def http_action = body.substring(startIndex + 8, endIndex);
        if (http_action != null) {
            switch (http_action) {
                case "Create":
                    message.setHeader("METHOD_ACTION", "POST");
                    break;
                case "Change":
                    message.setHeader("METHOD_ACTION", "PUT");
                    break;
                case "Delete":
                    throw new IllegalStateException("Delete BOM is not supported")
                    break;
                default:
                    message.setHeader("METHOD_ACTION", "POST");
                    break;

            }
        }
    } else {
        //default setting to POST
        message.setHeader("METHOD_ACTION", "POST");
    }
    return message;
}

