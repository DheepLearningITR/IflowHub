import com.sap.it.api.mapping.*;
import java.util.UUID; 
import java.util.Arrays;
import java.util.Set;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.ITApi;
import java.security.MessageDigest;

def String getUUID(String header, MappingContext context){
    def flag = context.getProperty("replicateReconciliationFlag");
    if(flag == 1)
    return UUID.randomUUID().toString();
    else 
    return context.getProperty("mdmUUID");
}   

def String getAddressUUID(String UID, MappingContext context){
    String result = MessageDigest.getInstance("MD5").digest(UID.bytes).encodeHex().toString();
 
    // Compiled regex for UUID
    def p = ~"(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})"
    String formattedUUID = p.matcher(result).replaceAll("\$1-\$2-\$3-\$4-\$5");
    
    return formattedUUID;
} 

def String getBPGroupCode(String header, MappingContext context){
    return context.getProperty("bpGroupCode");
} 

def String removeLeadingZeros(String header, MappingContext context){
    header = header.replaceAll("^0+", "");
    return  header;
} 
