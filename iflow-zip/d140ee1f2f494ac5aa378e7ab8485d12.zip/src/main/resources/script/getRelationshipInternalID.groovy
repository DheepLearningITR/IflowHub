import com.sap.it.api.mapping.*;
def String getInternalID(String internalID, MappingContext context){
    String mdmInternalID = context.getProperty("mdmInternalID");
    if(mdmInternalID != '')
	return mdmInternalID;
	else
	return internalID;
}