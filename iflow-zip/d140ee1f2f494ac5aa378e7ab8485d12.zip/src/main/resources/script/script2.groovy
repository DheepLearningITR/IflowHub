
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.UUID;
import java.util.*;

/********************************/
/***  Set BP Header ID and UUID  ***/
/******************************/
    
def Message processData(Message message) {
    
    def BP_UUID = UUID.randomUUID().toString();
    message.setProperty("BP_UUID", BP_UUID);
    
    return message;
  
}