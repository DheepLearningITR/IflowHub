
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.UUID;
import groovy.xml.XmlUtil;
import java.util.*;

/********************************/
/***  Set Rel Header ID and UUID  ***/
/******************************/
    
def Message processData(Message message) {
    
    def Rel_UUID = UUID.randomUUID().toString();
    message.setProperty("Rel_UUID", Rel_UUID);

    return message;
  
}