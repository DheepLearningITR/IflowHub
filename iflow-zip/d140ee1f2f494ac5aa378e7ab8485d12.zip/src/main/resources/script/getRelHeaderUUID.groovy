import com.sap.it.api.mapping.*;

// get relationship header UUID
def String getRelHeaderUUID(String header, MappingContext context){
    
    String Rel_UUID = context.getProperty("Rel_UUID");
    
	return Rel_UUID;
}