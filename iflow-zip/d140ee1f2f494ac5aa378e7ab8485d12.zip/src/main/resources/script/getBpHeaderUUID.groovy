import com.sap.it.api.mapping.*;

// get business partner header UUID
def String getBpHeaderUUID(String header, MappingContext context){
    
    String BP_UUID = context.getProperty("BP_UUID");
    
	return BP_UUID;
}