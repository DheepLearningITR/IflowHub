import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
def Message processData(Message message) {
    // ************Delete records which does not have email****************
    def body = message.getBody(java.lang.String);
    def rootNode = new XmlSlurper().parseText(body);
     rootNode.SAPCpiOutboundB2BCustomers.SAPCpiOutboundB2BCustomer.sapCpiOutboundB2BContacts.SAPCpiOutboundB2BContact.each{it-> 
             if(it.email == null)
             it.replaceNode{};
      
    }
    message.setBody( XmlUtil.serialize(rootNode));
     return message;
}