import com.sap.it.api.mapping.*;

def String getCountryCode(String dummy, MappingContext context){
    return context.getProperty("defaultCountry");
}