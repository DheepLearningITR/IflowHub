import com.sap.it.api.mapping.*;
import java.security.MessageDigest;


def String genAddrUUID(String UID){

    String result = MessageDigest.getInstance("MD5").digest(UID.bytes).encodeHex().toString();
 
    // Compiled regex for UUID
    def p = ~"(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})"
    String formattedUUID = p.matcher(result).replaceAll("\$1-\$2-\$3-\$4-\$5");
    
    return formattedUUID;
}

