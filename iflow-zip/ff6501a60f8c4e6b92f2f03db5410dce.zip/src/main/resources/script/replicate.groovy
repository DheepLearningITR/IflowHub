import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.json.JsonOutput;

//resynch logic
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

def Message validate(Message message) {
    // Retrieve headers
    def headers = message.getHeaders();
    def properties = message.getProperties();
    
    // Extract specific headers with defaults if necessary
    def sfsfDeactivateJobProfiles = headers.get("sfsfDeactivateJobProfiles") ?: "false";
    def cbrJobProfIds = headers.get("cbrJobProfileIds");
    def sfsfFamilyContext = headers.get("sfsfFamilyContext");
    def cbrJobProfileType = headers.get("cbrJobProfileType");
    def cbrJobArchitecture = headers.get("cbrJobArchitecture");
    def cbrLastSynchDateTime = headers.get("cbrLastSynchDateTime");
    def testRun = headers.get("testRun") ?: "false";
    
    def errors = []; // Unified error list
    
    // Validate IFLOW PARAMETERS --------------------
    def mandatoryParams = [
        "sfsfCompanyId"
    ]
    mandatoryParams.each { key ->
        if (!headers[key]?.trim()) {
            errors.add(["errorCode": "[SAP-IS] MISSING_IFLOW_PARAM", "errorMessage": key]);
        }
    }
    
    // Validate HEADERS --------------------
    def mandatoryHeaders = [
        "cbrJobArchitecture",
        "cbrJobProfileType"
    ]
    
    mandatoryHeaders.each { key ->
        if (!headers[key]?.trim()) {
            errors.add(["errorCode": "[SAP-IS] MISSING_HDR", "errorMessage": key]);
        }
    }    

    // Validate VM CONFIG ---------------------

    def configMappings = [
        "sfsfAddress"                   : "cbrInt_SuccessFactors_API:Address",
        "sfsfCredential"                : "cbrInt_SuccessFactors_API:Credential",
        "sfsfJobProfileTemplate"        : "cbrInt_SuccessFactors_JobProfileTemplate:TemplateId",
        "sfsfJobProfileSections"        : "cbrInt_SuccessFactors_JobProfileTemplate:Sections"
    ];

    configMappings.each { property, vmconfig ->
        if (!properties[property]?.trim()) {
            errors.add(["errorCode": "[SAP-IS] MISSING_VMCONFIG", "errorMessage": "${vmconfig}"]);
        }
    }    
    
    //check JobProfile Sections Config
    def sfsfSections = properties.get("sfsfJobProfileSections").split('\\|');
    sfsfSections.each { sect ->
        def prop = 'sfsf'+sect;
        if (!properties[prop]?.trim()) {
            def errorMsg = 'cbrInt_SuccessFactors_JobProfileTemplate:'+sect;
            errors.add(["errorCode": "[SAP-IS] MISSING_VMCONFIG", "errorMessage": errorMsg ]);
        }
    }

    // If there are any errors, set the error response and return
    if (!errors.isEmpty()) {
        def errorJson = JsonOutput.toJson(["errors": errors]);
        message.setProperty("errorJson", errorJson);
        throw new IllegalArgumentException(errorJson); // Exit with all errors
    }
    
    //Validation passed! continue processing the headers ---------------------
    def sfsfSectionsStr = properties.get("sfsfJobProfileSections");
    def getSFSFAttributes = false; //do not get/process/map attributes if not included in the JP Template
    if(sfsfSectionsStr.contains('competency') || sfsfSectionsStr.contains('skills')){
        getSFSFAttributes = true;
    }
    message.setProperty("getSFSFAttributes", getSFSFAttributes.toString());
    
    def sfsfJobProfIdsFilter = "";
    if(cbrJobProfIds){
        //enclose list in double quotes
        def jobProfIds = cbrJobProfIds.split(',');  //split by comma
        
        jobProfIds.each{j->
            if(sfsfJobProfIdsFilter == ''){
                sfsfJobProfIdsFilter = ' and cust_cbrJobProfileId in guid\'' + j.toString() + '\'';
            }else{
                sfsfJobProfIdsFilter = sfsfJobProfIdsFilter + ',guid\'' + j.toString() + '\'';
            }
        }
    }
    
    if(cbrLastSynchDateTime){
        //truncate time to only include seconds: e.g. '2025-12-10T14:05:31.807480Z'
        cbrLastSynchDateTime = Instant.parse(cbrLastSynchDateTime).truncatedTo(ChronoUnit.SECONDS).toString();
    }

    message.setProperty("cbrLastSynchDateTime", cbrLastSynchDateTime);
    message.setProperty("cbrJobArchitecture", cbrJobArchitecture);
    message.setProperty("cbrJobProfileIds", cbrJobProfIds);
    message.setProperty("cbrJobProfileType", cbrJobProfileType);
    message.setProperty("sfsfFamilyContext", sfsfFamilyContext);    
    message.setProperty("sfsfJobProfIdsFilter", sfsfJobProfIdsFilter);
	message.setProperty("sfsfDeactivateJobProfiles", sfsfDeactivateJobProfiles);
	message.setProperty("testRun", testRun);    

	//used to clear hashmap global variables
	def emptyHmap = new HashMap<String, String>();
	emptyHmap.put('null','');
	message.setProperty("emptyHmap", emptyHmap);

    return message;
}


def Message build_listJobProf(Message message) {
    
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
    def cbrJobProfIds = map.get("cbrJobProfileIds");
    
    //create list only if sycnhing for specific job profiles!
    if(cbrJobProfIds){
	    def Root = new XmlSlurper().parse(body);
	    def jobProfList = ''; 
	
        Root.data.each{
            if(jobProfList == ''){
                jobProfList = it.id.toString();
            }else{
                jobProfList = jobProfList + ',' + it.id.toString();
            }
        }
        //list of Job Profiles being synched!
	    message.setProperty("cbrJobProfIdList", jobProfList);
    }
	return message;
}

def Message build_hsetCBRJobProfile(Message message) {
	
	def body = message.getBody(java.lang.String);
	def map = message.getProperties();
	
	//build CBR Job Profiles	
	Set<String> hset_cbrJobProf = map.get("hset_cbrJobProf"); 
	if(hset_cbrJobProf==null){ 
	    hset_cbrJobProf = new HashSet<>();
	}	

    def Root = new XmlParser().parseText(body);	
    Root.data.each{
        hset_cbrJobProf.add(it.id[0].text());    //CBR JobProfile
    }
    
    message.setProperty("hset_cbrJobProf", hset_cbrJobProf);
    return message;
}


def Message build_hmapSFSFCoCAttributes(Message message) {
	
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
	def sfsfAttributeType = map.get("sfsfAttributeType") ?: "SKILL";
	def sfsfCoCAttrEntity = map.get("sfsfCoCAttrEntity");
	Set<String> hsetAttr = map.get("hset_sfsfCoCAttribute"); 
	if( hsetAttr == null ){
	    hsetAttr = new HashSet<>();	
	}

	def Root = new XmlSlurper().parse(body);
    	Root."${sfsfCoCAttrEntity}".each{
    	    hsetAttr.add(sfsfAttributeType+'-en_US-'+ it.name_en_US.toString().trim().toLowerCase()); //English name
    	    hsetAttr.add(sfsfAttributeType+'-de_DE-'+ it.name_de_DE.toString().trim().toLowerCase()); //Deutsch name
    	}
	message.setProperty("hset_sfsfCoCAttribute", hsetAttr);
	message.setBody(''); //clear body, not needed anymore as it has been converted to hmap
	return message;
}

def Message filter_SFSFAttributes(Message message) {
	
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
	
	Set<String> hsetCoCAttr = map.get("hset_sfsfCoCAttribute"); 
    HashMap<String, String> hmapTIHAttrib = map.get("hmap_sfsfAttributes");
    Set<String> hsetCoCAttrError = new HashSet<>();	

	def Root = new XmlSlurper().parse(body);
	Root.AttributeEntity.each{
	    String name = it.type.toString() + '-' + it.defaultLocale.toString() + '-'+ it.name.toString().trim().toLowerCase();
        if(!hsetCoCAttr.contains(name)){
            hmapTIHAttrib.remove(it.type.toString()+'|'+it.externalId.toString()); //remove in hmap, TIH Attribute not synched back to CoC
            hsetCoCAttrError.add(it.type.toString()+'|'+it.externalId.toString()); //Attribute has CoC Synch Error
        }
	}
    	
    message.setProperty("hmap_sfsfAttributes", hmapTIHAttrib);
    message.setProperty("hset_sfsfAttributeCoCError", hsetCoCAttrError);
    message.setProperty("hset_sfsfCoCAttribute",null); //clear hset, done processing
    
    message.setBody(XmlUtil.serialize(Root));
	return message;
}

def Message build_hmapSFSFJobProfile(Message message) {
	
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
	
	HashMap<String, String> hmap_sfsfJobProf = map.get("hmap_sfsfJobProf"); 
	if( hmap_sfsfJobProf == null ){
	    hmap_sfsfJobProf = new HashMap<String, String>();	
	}
	HashMap<String, String> hmap_sfsfJobProfSections = map.get("hmap_sfsfJobProfSections"); 
	if( hmap_sfsfJobProfSections == null ){
	    hmap_sfsfJobProfSections = new HashMap<String, String>();	
	}	
	
	//create reverse HashMap for sfsfAttributes >> used to filter out sfsfAttributeMappings not involving Cobrainer attributes
	def rMap_sfsfAttributes = new HashMap<String, String>();
	HashMap<String, String> hmap_sfsfAttributes = map.get("hmap_sfsfAttributes"); 
	if(hmap_sfsfAttributes){
	    rMap_sfsfAttributes = hmap_sfsfAttributes.collectEntries { [(it.value): it.key] }
	}
	
	Set<String> hset_cbrJobProf = map.get("hset_cbrJobProf");
    //def sfsfAttrMappingEntityNav = map.get("sfsfAttrMappingEntityNav");
    //def sfsfAttrMappingEntity = map.get("sfsfAttrMappingEntity");
    HashMap<String, String> hmapSkillMapping = map.get("hmap_sfsfSkillMapping");
    if (hmapSkillMapping == null) {
        hmapSkillMapping = new HashMap<String, String>();    
    }	
    HashMap<String, String> hmapCompMapping = map.get("hmap_sfsfCompMapping");
    if (hmapCompMapping == null) {
        hmapCompMapping = new HashMap<String, String>();    
    }
    
    def dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    String attrMap = '';
    String newEntry = '';
	def Root = new XmlSlurper().parse(body);
	Root.JobProfile.each{
	    //convert to UTC format: e.g. 2025-03-19T10:58:17.000 >> 2025-03-19T10:58:17Z
	    def sfsfModDateTime = LocalDateTime.parse(it.lastModifiedDateTime.toString(), dateFormat);
	    def sfsfModDateTimeUTC = sfsfModDateTime.toInstant(ZoneOffset.UTC); // Convert to UTC
	    
	    //status|jobProfExtCode|RoleExtCode|modifiedDateTime
	    def stat = it.status.toString();
	    if(it.draft.toString() == 'true' && it.status.toString() == 'A'){
	        stat = 'D';
	    }
    	hmap_sfsfJobProf.put(it.cust_cbrJobProfileId.toString(),stat+'|'+it.externalCode.toString()+'|'+it.roleNav.RoleEntity.externalCode.toString()+'|'+sfsfModDateTimeUTC.toString());

        //build sectionId=externalCode for text updates
        it.longDesciptions.JobProfileLocalizedData.each{ ldesc->
            hmap_sfsfJobProfSections.put(it.cust_cbrJobProfileId.toString()+'_'+ldesc.sectionId.toString(),ldesc.externalCode.toString());
        }

        //Store existing SFSF attribute mappings -------------
        //include only sfsfJobProfileMappings wherein the sfsfJobProfile is included in cbrJobArchitecture
        if(hset_cbrJobProf.contains(it.cust_cbrJobProfileId.toString())){
        	it.roleNav.RoleEntity.roleSkillMappings.RoleSkillMappingEntity.each{ s->
                //check that the attribute in the mapping is Cobrainer's 
                if(rMap_sfsfAttributes.containsKey(s.wsmId.toString())){
                    attrMap = hmapSkillMapping.get(s.wsmId.toString()); 
                    def sfsfSkillProf = s.wsmProficiencyLevel.toString() ?: "0";  //default with 0, null errors during parse
                    def sfsfSkillExtCode = s.externalCode.toString();
                    newEntry = it.cust_cbrJobProfileId.toString() +"|"+s.RoleEntity_externalCode.toString() + "|" + sfsfSkillExtCode + "|" + sfsfSkillProf;   //INT-366 Skill Prof Mapping
                    if (attrMap == null) {
                        // If attribute mapping doesn't exist, create new mapping
                        attrMap = newEntry;
                    } else {
                        // attribute mapping exists already, concatenate Role
                        attrMap += ";" + newEntry;
                    }
                    hmapSkillMapping.put(s.wsmId.toString(), attrMap)    	
                }
        	}
            it.roleNav.RoleEntity.roleCompetencyMappings.RoleCompetencyMappingEntity.each{ c->
                //check that the attribute in the mapping is Cobrainer's 
                if(rMap_sfsfAttributes.containsKey(c.wsmId.toString())){
                    attrMap = hmapCompMapping.get(c.wsmId.toString()); 
                    def sfsfCompWeight = c.weight_defaultValue.toString() ?: "0";   //default with 0, null errors during parse
                    def sfsfCompRating = c.rating_defaultValue.toString() ?: "0";   //default with 0, null errors during parse
                    def sfsfCompExtCode = c.externalCode.toString();      
                    newEntry = it.cust_cbrJobProfileId.toString() +"|"+c.RoleEntity_externalCode.toString() + "|" + sfsfCompExtCode + "|" + sfsfCompWeight + "|" + sfsfCompRating; //INT-366 Comp Weight Defaulting
                    if (attrMap == null) {
                        // If attribute mapping doesn't exist, create new mapping
                        attrMap = newEntry;
                    } else {
                        // attribute mapping exists already, concatenate Role
                        attrMap += ";" + newEntry;
                    }
                    hmapCompMapping.put(c.wsmId.toString(), attrMap)    	
                }
        	}        	
        }
    	it.roleNav.replaceNode{};   //remove Role Node, this is not needed anymore
	}
	
	message.setBody(XmlUtil.serialize(Root));
	message.setProperty("hmap_sfsfJobProf", hmap_sfsfJobProf);
	message.setProperty("hmap_sfsfJobProfSections", hmap_sfsfJobProfSections);	
	message.setProperty("hmap_sfsfSkillMapping", hmapSkillMapping);
	message.setProperty("hmap_sfsfCompMapping", hmapCompMapping);
	return message;
}

def Message build_hmapSFSFJobFamily(Message message) {
	
	def body = message.getBody(java.io.Reader);
	def map = message.getProperties();
	HashMap<String, String> hmapJobFamily = map.get("hmap_sfsfJobFamily"); 
	if( hmapJobFamily == null ){
	    hmapJobFamily = new HashMap<String, String>();	
	}
	def Root = new XmlSlurper().parse(body);
    	Root.FamilyEntity.each{
        	hmapJobFamily.put(it.cust_cbrJobFamilyId.toString(),it.externalCode.toString()); 
    	}
	message.setProperty("hmap_sfsfJobFamily", hmapJobFamily);
	return message;
}

def Message map_cbrJobFamily(Message message) {
	
	def body = message.getBody(java.lang.String);
	def map = message.getProperties();
	HashMap<String, String> hmapJobFamily = map.get("hmap_sfsfJobFamily"); 

    def sumJobProf = 0;
    def sumJobProfNotSync = 0;
    //List<String> missingJobFamily = [];
    Set<String> missingJobFamily = new HashSet<>();
	def Root = new XmlParser().parseText(body);
    Root.data.each{r->
        sumJobProf = sumJobProf + 1; //counter
        if(r.jobFamily[0].text()!=''){
            def sfsfJobFamily = hmapJobFamily.get(r.jobFamily[0].text());
            if(sfsfJobFamily){
                r.jobFamily[0].value = sfsfJobFamily;
            }else{
                //cbrJobFamily not found in SFSF, delete node (cannot be replicated!)
                r.replaceNode { };
                sumJobProfNotSync++;
                missingJobFamily.add(r.jobFamily[0].text()); 
            }
        }
    }
    
    message.setProperty("sumJobProf", sumJobProf.toString());
    message.setProperty("sumMissingJobFamilies", missingJobFamily.size()); //get sum
    message.setProperty("sfsfMissingJobFamilies", JsonOutput.toJson(missingJobFamily)); 
	message.setProperty("hmap_sfsfJobFamily", null); //clear hashMap, done processing
	message.setProperty("sumJobProfNotSync", sumJobProfNotSync.toString());
	message.setBody(XmlUtil.serialize(Root));
	
	return message;
}

def Message process(Message message) {
	
	def body = message.getBody(java.lang.String);
	def map = message.getProperties();
	
	def sfsfJobProfileTemplate = map.get("sfsfJobProfileTemplate");
	def mapping_jobProfileCreate = map.get("mapping_jobProfileCreate");	
	def mapping_jobProfileUpdate = map.get("mapping_jobProfileUpdate");	
    def sfsfSectionId_skills = map.get('sfsfSectionId_skills');
    def sfsfSectionId_competency = map.get('sfsfSectionId_competency');	
    def sfsfCompetencyRating = map.get('sfsfCompetencyRating') ?: '0';	//default to 0
    
    def cbrLastSynchDateTime = map.get('cbrLastSynchDateTime');	
    def cbrLastSynchDateTimeInst = null;
    if(cbrLastSynchDateTime){
        cbrLastSynchDateTimeInst = Instant.parse(cbrLastSynchDateTime); //convert to Instant
    }
    
	HashMap<String, String> hmap_sfsfJobProfSections = map.get("hmap_sfsfJobProfSections"); 
    if(hmap_sfsfJobProfSections==null){
        hmap_sfsfJobProfSections = new HashMap<String, String>();
    }
	
	HashMap<String, String> hmap_sfsfJobProf = map.get("hmap_sfsfJobProf"); 
	if(hmap_sfsfJobProf==null){
	    hmap_sfsfJobProf = new HashMap<String, String>();
	}	
    Set<String> hsetCoCError = map.get("hset_sfsfAttributeCoCError"); 
    if(hsetCoCError==null){
        hsetCoCError = new HashSet<>();
    }
	HashMap<String, String> hmapSFSFAttributes = map.get("hmap_sfsfAttributes"); 
	if(hmapSFSFAttributes==null){
	    hmapSFSFAttributes = new HashMap<String, String>();
	}
    
    HashMap<String, String> hmapCBRSkills = new HashMap<String, String>();
    HashMap<String, String> hmapCBRComp = new HashMap<String, String>();
    Set<String> missingAttributes = new HashSet<>();
	Set<String> cocError = new HashSet<>();
	
	def cbrSkillId = '';
	def cbrCompId = '';
	def wsmId = '';
	def sumCreate = 0;
	def sumReactivate = 0;
	def sumResynch = 0;
	def Root = new XmlParser().parseText(body);
	
    Root.data.each{r->
    
        def cbrJobProfId = r.id[0].text();
        
        //ModifiedDateTime in UTC
        def cbrUpdatedAtInst = null; 
        if(r.updatedAt[0].text()){
            //truncate time to only include seconds: e.g. '2025-12-10T14:05:31.807480Z'
            def cbrUpdatedAt = Instant.parse(r.updatedAt[0].text()).truncatedTo(ChronoUnit.SECONDS).toString();
            cbrUpdatedAtInst = Instant.parse(cbrUpdatedAt); //convert to Instant
        }
        
        //count all compWeight regardless of whether it exists in SFSF or not
        def compWeight = 0;
        def compCount = r.findAll { it.name() == 'competency' }.size();
        if(compCount>0){
            //calculate Weight based on the number of Competencies per JP
            compWeight = Math.floor(100 / compCount) as int;
        }
        
        //get sections Ids and ExtCodes of the long descriptions
        r.translations.each{t->
            t.structured.each{ txt->
                //get sfsfSectionId from properties
                def sectionId = map.get('sfsfSectionId_'+txt.tag[0].text());
                if(sectionId){
                    txt.appendNode("sfsfSectionId", [:], sectionId);
                    def sfsfSectionExtCode = hmap_sfsfJobProfSections.get(cbrJobProfId+'_'+sectionId);
                    if(sfsfSectionExtCode){
                        //JobProfile sectionId exists! add SectionExtCode for Job Text Updates
                        txt.appendNode("sfsfSectionExtCode", [:], sfsfSectionExtCode);
                    }
                }else{
                    //cbrText Value-mapping to sfsfJobProfile Section NOT FOUND
                    //delete Text NODE
                    txt.replaceNode { };
                }
            }
        }        
        
        if(hmap_sfsfJobProf.containsKey(cbrJobProfId)){
            //JobProfile FOUND in SFSF, Build hmap_cbrSkills for the sfsfAttributeMappings to be created or deleted
            
            if(sfsfSectionId_skills){
                //map skills only if SectionId is configured in the VM Config
                r.skills.each{s->
                    if(s.id){
                        cbrSkillId = 'SKILL|cbr_'+s.id[0].text();
                        wsmId = hmapSFSFAttributes.get(cbrSkillId);
                        if(wsmId){ 
                            def jobExtIds_str = hmapCBRSkills.get(wsmId);
                            if(jobExtIds_str == null){
                                jobExtIds_str = cbrJobProfId + ';' + s.level[0].text(); //INT-366 Skill Prof Mapping
                            }else{
                                // attribute mapping exists already, concatenate JobProfile
                                jobExtIds_str = jobExtIds_str + '|' + cbrJobProfId + ';' + s.level[0].text(); //INT-366 Skill Prof Mapping
                            }
                            hmapCBRSkills.put(wsmId.toString(),jobExtIds_str);
                        }else{
                            //skill id does not exists yet in SFSF OR has CoC Synch Error: remove skill mapping or JobCreation will error!
                            if(hsetCoCError != null && hsetCoCError.contains(cbrSkillId)){
                                //Attribute found but has CoC Sync Error
                                cocError.add(cbrSkillId);
                            }else{
                                //skill not found in COC Error, skill is REALLY missing!
                                missingAttributes.add(cbrSkillId);   
                            }
                        }
                    }
                }   
            }
            if(sfsfSectionId_competency){
                //map competencies only if SectionId is configured in the VM Config
                r.competency.each{c->
                    if(c.id){
                        cbrCompId = 'COMPETENCY|cbr_'+c.id[0].text();
                        wsmId = hmapSFSFAttributes.get(cbrCompId);
                        if(wsmId){ 
                            def jobExtIds_str = hmapCBRComp.get(wsmId);
                            if(jobExtIds_str == null){
                                jobExtIds_str = cbrJobProfId + ';' + compWeight;   //INT-366 Comp Weight Defaulting
                            }else{
                                // attribute mapping exists already, concatenate JobProfile
                                jobExtIds_str = jobExtIds_str + '|' + cbrJobProfId + ';' + compWeight; //INT-366 Comp Weight Defaulting
                            }
                            hmapCBRComp.put(wsmId.toString(),jobExtIds_str);
                        }else{
                            //skill id does not exists yet in SFSF OR has CoC Synch Error: remove skill mapping or JobCreation will error!
                            if(hsetCoCError != null && hsetCoCError.contains(cbrCompId)){
                                //Attribute found but has CoC Sync Error
                                cocError.add(cbrCompId);
                            }else{
                                //skill not found in COC Error, skill is REALLY missing!
                                missingAttributes.add(cbrCompId);   
                            }
                        }
                    }
                }            
            }
            
            //def reactivate = false;
            def(sfsfJPStatus,sfsfJPExtCode,sfsfRoleExtCode,sfsfModDateTime) = hmap_sfsfJobProf.get(cbrJobProfId).toString().split('\\|');
            if(sfsfJPStatus=='I' || sfsfJPStatus=='D'){
                //reactivate if current status is inactive or draft
                //reactivate = true;
                sumReactivate++; //counter
                r.appendNode("mapping_jobProfileUpdate",[:],mapping_jobProfileUpdate);
                r.appendNode("sfsfJobProfExtCode",[:],sfsfJPExtCode);
                r.appendNode("sfsfRoleExtCode",[:],sfsfRoleExtCode);
            }else{
                //RESYNCH LOGIC ----------------------------
                def changeDetected = false;
                if(cbrLastSynchDateTime){
                    def sfsfModDateTimeInst = Instant.parse(sfsfModDateTime); //convert to Instant
                    //compare sfsfJobProfile modified date with last sync date. Resynch only if sfsfJP has been modified AFTER last synch date
                    if(sfsfModDateTimeInst.isAfter(cbrLastSynchDateTimeInst)){
                        //sfsfJobProfile has been changed after the last synch
                        changeDetected = true;
                    }else if(cbrUpdatedAtInst.isAfter(cbrLastSynchDateTimeInst)){
                        //cobrainer JobProfile has been changed after the last synch
                        changeDetected = true;
                    }else{
                        //no changes after last Synch date AND JP is still active, do not resynch
                        r.replaceNode { };
                    }
                }else{
                    //always synch of cbrLastSynchDateTime is not sent!
                    changeDetected = true;
                }
                if(changeDetected==true){
                    sumResynch++; //existing sfsfJob Profiles to update texts
                    r.appendNode("mapping_jobProfileUpdate",[:],mapping_jobProfileUpdate);
                    r.appendNode("sfsfJobProfExtCode",[:],sfsfJPExtCode);
                    r.appendNode("sfsfRoleExtCode",[:],sfsfRoleExtCode);
                }
            }
        }else{
            //Talent JobProfile NOT FOUND in SFSF, CREATE
            sumCreate = sumCreate + 1; //counter
            r.appendNode("mapping_jobProfileCreate",[:],mapping_jobProfileCreate);
            r.appendNode("sfsfJobProfileTemplate",[:],sfsfJobProfileTemplate);
            
            if(sfsfSectionId_skills){
                //map skills only if SectionId is configured in the VM Config
                r.appendNode("sfsfSectionId_skills",[:],sfsfSectionId_skills);
            
                //include only skills which already exists
                r.skills.each{s->
                    if(s.id){
                        cbrSkillId = 'SKILL|cbr_'+s.id[0].text();
                        if(hmapSFSFAttributes != null && hmapSFSFAttributes.containsKey(cbrSkillId)){ 
                            //append new nodes
                            s.appendNode("wsmId",[:],hmapSFSFAttributes.get(cbrSkillId));
                        }else{
                            //skill id does not exists yet in SFSF OR has CoC Synch Error: remove skill mapping or JobCreation will error!
                            s.replaceNode { };
                            if(hsetCoCError != null && hsetCoCError.contains(cbrSkillId)){
                                //Attribute found but has CoC Sync Error
                                cocError.add(cbrSkillId);
                            }else{
                                //skill not found in COC Error, skill is REALLY missing!
                                missingAttributes.add(cbrSkillId);   
                            }
                        }
                    }
                }
            }
            
            if(sfsfSectionId_competency){
                //map competencies only if SectionId is configured in the VM Config
                r.appendNode("sfsfSectionId_competency",[:],sfsfSectionId_competency);
                        
                //set Competency Weight based on the number of competencies per Job Profile
                if(compWeight>0){
                    r.appendNode("sfsfCompWeight",[:],compWeight.toString());
                }
                
                //include Default Competency Rating from VM Config, default to 0
                r.appendNode("sfsfCompRating",[:],sfsfCompetencyRating.toString());
                
                r.competency.each{c->
                    if(c.id){
                        //include only competencies which already exists
                        cbrCompId = 'COMPETENCY|cbr_'+c.id[0].text();
                        if(hmapSFSFAttributes != null && hmapSFSFAttributes.containsKey(cbrCompId)){ 
                            //append new nodes
                            c.appendNode("wsmId",[:],hmapSFSFAttributes.get(cbrCompId));
                        }else{
                            //Competency id does not exists yet in SFSF OR has CoC Synch Error: remove Competency mapping or JobCreation will error!
                            c.replaceNode { };
                            if(hsetCoCError != null && hsetCoCError.contains(cbrCompId)){
                                //Attribute found but has CoC Sync Error
                                cocError.add(cbrCompId);
                            }else{
                                //skill not found in COC Error, Competency is REALLY missing!
                                missingAttributes.add(cbrCompId);   
                            }
                        }
                    }
                }
            }
        }
    }
    
    message.setProperty("hmap_cbrSkills", hmapCBRSkills);
    message.setProperty("hmap_cbrComp", hmapCBRComp);
    message.setProperty("sumCoCError", cocError.size()); //get sum
    message.setProperty("sfsfCoCError", JsonOutput.toJson(cocError)); //get unique list, replace with json (final state!)
    message.setProperty("sfsfMissingAttributes", JsonOutput.toJson(missingAttributes)); //get unique list, replace with json (final state!)
    message.setProperty("sumMissingAttributes", missingAttributes.size()); //get sum
    message.setProperty("cbrPayload",null);                  //clear processed data
    message.setProperty("hset_sfsfAttributeCoCError",null);  //clear processed data
    message.setProperty("hmap_sfsfAttributes",null);          //clear processed data

    message.setBody(XmlUtil.serialize(Root));
    message.setProperty("sumCreate",sumCreate.toString());
    message.setProperty("sumResynch",sumResynch.toString());
    message.setProperty("sumReactivate",sumReactivate.toString());
	return message;
}

def Message process_updates_deactivate(Message message) {
	
	def body = message.getBody(java.lang.String);
	def map = message.getProperties();
	Set<String> hset_cbrJobProf = map.get("hset_cbrJobProf"); 
	String sfsfDeactivateJobProfiles = map.get("sfsfDeactivateJobProfiles");
	
	//def sumReactivate = 0;
	def sumArchive = 0;
	def Root = new XmlParser().parseText(body);
    Root.JobProfile.each{r->
        if(hset_cbrJobProf.contains(r.cust_cbrJobProfileId[0].text())){
           /* if(r.status[0].text() == 'I'){
                //found but inactive: update and Activate!
                r.status[0].value = 'A'; 
                sumReactivate = sumReactivate + 1; //counter
            }else{
            */
                //found and active: delete node, nothing to do
                r.replaceNode { };
            //}
        }else{
            if(sfsfDeactivateJobProfiles == 'false'){
                //Do not deactivate anything! delete node, nothing to do
                r.replaceNode { };
            }else{
                if(r.status[0].text() == 'A' || r.status[0].text() == 'D'){
                    //NOT Found and active or draft: update and DEACTIVATE
                    r.status[0].value = 'I';
                    sumArchive = sumArchive + 1; //counter
                }else{
                     //NOT Found and inactive: delete node, nothing to do
                    r.replaceNode { };
                }
            }
        }
    }

    message.setProperty("sfsfJobProfile_payload",null);    //clear processed data
    message.setProperty("hset_cbrJobProf",null);           //clear processed data
    message.setBody(XmlUtil.serialize(Root));
    message.setProperty("sumArchive",sumArchive.toString());
    //message.setProperty("sumReactivate",sumReactivate.toString());
	return message;
}


import groovy.xml.MarkupBuilder;
def Message process_mappingUpdates(Message message) {
    
    //perform deletes and updates first before create to make sure CompWeights are updated before 100% and accommodate CompMapping creates
    //avoids error: <message>Sum of competency mapping Weight in US English exceeds 100%. with the index 0</message>
    
	def map = message.getProperties();
    def sfsfAttrMappingEntity = map.get("sfsfAttrMappingEntity");	
    def sfsfCompRatingDefault = map.get("sfsfCompetencyRating") ?: "0";
    
    def sfsfSectionId_skills = map.get('sfsfSectionId_skills');
    def sfsfSectionId_competency = map.get('sfsfSectionId_competency');	    
    
    // Create a writer to hold the XML
    def writer = new StringWriter();
    def xml = new MarkupBuilder(writer);
    
    if(sfsfAttrMappingEntity=='RoleSkillMappingEntity'){
        HashMap<String, String> hmap_cbrSkills = map.get("hmap_cbrSkills"); 
	    HashMap<String, String> hmap_sfsfSkillMapping = map.get("hmap_sfsfSkillMapping"); 
        def sumDeleteMappingSkill = 0;
        def sumUpdateMappingSkill = 0;
        xml."${sfsfAttrMappingEntity}" { // add parent Node
        
            if(sfsfSectionId_skills){
                //only process Skills mappping if found in VM config!
                hmap_sfsfSkillMapping.each{wsmId, sfsfJobProfileList ->        
                
                    //get list of cbrJobProfiles the skill is mapped to
                    def sfsfJobProfArray = sfsfJobProfileList.split(';');
                    String cbrMappingJPList = hmap_cbrSkills.get(wsmId.toString());  
                    
                    sfsfJobProfArray.each{ sfsfJPData->
                        //e.g. 2650=fe18c391-af81-4fb3-adb5-3fa14203cd65|1210403|1210602|3
                        def(sfsfJP,sfsfRoleExtCode,sfsfAttrMapExtCode,sfsfSkillProf) = sfsfJPData.split('\\|'); 
                        //check if sfsfJobProfile mapping exists in cbrAttributeMappings:
                        //if it doesn't, delete sfsfRoleAttribute node so that mapping will be removed
                        if(cbrMappingJPList == null || !cbrMappingJPList.contains(sfsfJP.toString())){
                            //get sfsfRoleExtCode using cbrJobProfile Id
                            sumDeleteMappingSkill++; //counter
                            addAttrMappingNode(xml,sfsfAttrMappingEntity,sfsfRoleExtCode,sfsfAttrMapExtCode,wsmId.toString(),"","","","");
                        }else{
                            //mapping still valid in Cobrainer, check for updates
                            //e.g: 2991=fe18c391-af81-4fb3-adb5-3fa14203cd65;3
                            def cbrJPDataArray = cbrMappingJPList.split('\\|');
                            cbrJPDataArray .each{ cbrJPData->
                                def(cbrJPId,cbrSkillLevel) = cbrJPData.split(';') 
                                if(cbrJPId==sfsfJP){
                                    if(sfsfSkillProf!=cbrSkillLevel){
                                        //UPDATE SFSF mapping!!
                                        sumUpdateMappingSkill++;
                                        addAttrMappingNode(xml,sfsfAttrMappingEntity,sfsfRoleExtCode,sfsfAttrMapExtCode,wsmId.toString(),"A","","",cbrSkillLevel);
                                    }
                                }
                            }                            
                        }
                    }
                }
            }
        }
        message.setProperty("sumDeleteMappingSkill",sumDeleteMappingSkill.toString());
        message.setProperty("sumUpdateMappingSkill",sumUpdateMappingSkill.toString());
        
    }else{
        
        HashMap<String, String> hmap_cbrComp = map.get("hmap_cbrComp"); 
        HashMap<String, String> hmap_sfsfCompMapping = map.get("hmap_sfsfCompMapping");     
        def sumDeleteMappingComp = 0;
        def sumUpdateMappingComp = 0;
        xml."${sfsfAttrMappingEntity}" { // add parent Node
        
            if(sfsfSectionId_competency){
                //only process Competency mappping if found in VM config!
                hmap_sfsfCompMapping.each{wsmId, sfsfJobProfileList ->        
                
                    //get list of cbrJobProfiles the skill is mapped to
                    def sfsfJobProfArray = sfsfJobProfileList.split(';');
                    String cbrMappingJPList = hmap_cbrComp.get(wsmId.toString());  
                    
                    sfsfJobProfArray.each{ sfsfJPData->
                        //e.g. 2504=fe18c391-af81-4fb3-adb5-3fa14203cd65|1210403|1211528|10|50
                        def(sfsfJP,sfsfRoleExtCode,sfsfAttrMapExtCode,sfsfCompWeight,sfsfCompRating) = sfsfJPData.split('\\|'); 
                        //check if sfsfJobProfile mapping exists in cbrCompMappings:
                        //if it doesn't, delete sfsfRoleAttribute node so that mapping will be removed
                        if(cbrMappingJPList == null || !cbrMappingJPList.contains(sfsfJP.toString())){
                            //get sfsfRoleExtCode using cbrJobProfile Id
                            sumDeleteMappingComp++; //counter
                            addAttrMappingNode(xml,sfsfAttrMappingEntity,sfsfRoleExtCode,sfsfAttrMapExtCode,wsmId.toString(),"","","","");
                        }else{
                            //mapping still valid in Cobrainer, check for updates
                            //e.g: 2551=2449e620-7c18-4946-87f7-380c67175e5e;11|7318cac1-d402-4934-adf5-3a45758afe47;16|e53f7171-a0e0-414b-8f80-e6468612c805;20
                            def cbrJPDataArray = cbrMappingJPList.split('\\|');
                            cbrJPDataArray .each{ cbrJPData->
                                def(cbrJPId,cbrCompWeight) = cbrJPData.split(';') 
                                if(cbrJPId==sfsfJP){
                                    if(sfsfCompWeight!=cbrCompWeight || sfsfCompRating!= sfsfCompRatingDefault){
                                        //UPDATE SFSF mapping!!
                                        sumUpdateMappingComp++;
                                        addAttrMappingNode(xml,sfsfAttrMappingEntity,sfsfRoleExtCode,sfsfAttrMapExtCode,wsmId.toString(),"A",cbrCompWeight,sfsfCompRatingDefault,"");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        message.setProperty("sumDeleteMappingComp",sumDeleteMappingComp.toString());
        message.setProperty("sumUpdateMappingComp",sumUpdateMappingComp.toString());
    }    
    message.setBody(writer.toString());
	return message;    
}

def Message process_mappingCreates(Message message) {
	
	def map = message.getProperties();
    def sfsfAttrMappingEntity = map.get("sfsfAttrMappingEntity");	
    def cbrCompRating = map.get("sfsfCompetencyRating");	
	HashMap<String, String> hmap_cbrSkills = map.get("hmap_cbrSkills"); 
	HashMap<String, String> hmap_cbrComp = map.get("hmap_cbrComp"); 
	HashMap<String, String> hmap_sfsfSkillMapping = map.get("hmap_sfsfSkillMapping"); 
	HashMap<String, String> hmap_sfsfCompMapping = map.get("hmap_sfsfCompMapping"); 
	HashMap<String, String> hmap_sfsfJobProf = map.get("hmap_sfsfJobProf"); 

    def sfsfSectionId_skills = map.get('sfsfSectionId_skills');
    def sfsfSectionId_competency = map.get('sfsfSectionId_competency');	  

    // Create a writer to hold the XML
    def writer = new StringWriter();
    def xml = new MarkupBuilder(writer);	

    if(sfsfAttrMappingEntity=="RoleSkillMappingEntity"){
        def sumCreateMappingSkill = 0;	
        xml."${sfsfAttrMappingEntity}" { // add parent Node
            
            if(sfsfSectionId_skills){
                //only process Skills mappping if found in VM config!
                String[] sfsfMappingArray;
                hmap_cbrSkills.each{wsmId, cbrJobProfileList ->
        
                    //get list of cbrJobProfiles the skill is mapped to
                    def cbrJobProfArray = cbrJobProfileList.split('\\|');
                    String sfsfMapping_str = hmap_sfsfSkillMapping.get(wsmId.toString());
                    String sfsfMappingJPList = null;
                    if(sfsfMapping_str){
                        //cbrSkill FOUND in sfsfAttributeMappings, CHECK EACH PROFILE
                        sfsfMappingArray = sfsfMapping_str.split(';');  //split by semicolon
                        
                        //get list of JobProfiles from SFSF mappingsArray
                        sfsfMappingJPList = sfsfMappingArray.collect { m ->
                            m.split('\\|')[0] // extract only Role External Code
                        }.join(',');
                    }
                        
                    cbrJobProfArray.each{ cbrJPData->
                        def(cbrJP,cbrSkillLevel) = cbrJPData.toString().split(';');  //INT-362 Skill Prof mapping
                        //check if cbrJobProfile mapping already exists in sfsfAttributeMappings:
                        //if it doesn't yet, create sfsfRoleAttribute node so that mapping will be created
                        if(sfsfMappingJPList==null || !sfsfMappingJPList.contains(cbrJP.toString())){
                            //get sfsfRoleExtCode using cbrJobProfile Id
                            def sfsfExtCodes = hmap_sfsfJobProf.get(cbrJP.toString());
                            def(sfsfJPStatus,sfsfJPExtCode,sfsfRoleExtCode) = sfsfExtCodes.toString().split('\\|');
                            if(sfsfRoleExtCode){
                                if(sfsfJPStatus){sfsfJPStatus = 'placeholders'}; if(sfsfJPExtCode){sfsfJPExtCode = 'placeholders'}; //ignore placeholders in design guidelines
                                sumCreateMappingSkill++; //counter
                                addAttrMappingNode(xml,sfsfAttrMappingEntity,sfsfRoleExtCode,"",wsmId.toString(),"A","","",cbrSkillLevel);
                            }
                        }
                    }
                }
            }
        }
        message.setProperty("hmap_cbrSkills",null);
        message.setProperty("hmap_sfsfSkillMapping",null);  //clear processed data        
        message.setProperty("sumCreateMappingSkill",sumCreateMappingSkill.toString());
    }else{
    
        //sfsfAttrMappingEntity = "RoleCompetencyMappingEntity";
        def sumCreateMappingComp = 0;	
        xml."${sfsfAttrMappingEntity}" { // add parent Node
            
            if(sfsfSectionId_competency){
                //only process Competency mappping if found in VM config!
                String[] sfsfMappingArray;
                hmap_cbrComp.each{wsmId, cbrJobProfileList ->
        
                    //get list of cbrJobProfiles the skill is mapped to
                    def cbrJobProfArray = cbrJobProfileList.split('\\|');
                    String sfsfMapping_str = hmap_sfsfCompMapping.get(wsmId.toString());
                    String sfsfMappingJPList = null;
                    if(sfsfMapping_str){
                        //cbrSkill FOUND in sfsfAttributeMappings, CHECK EACH PROFILE
                        sfsfMappingArray = sfsfMapping_str.split(';');  //split by semicolon
                        
                        //get list of JobProfiles from SFSF mappingsArray
                        sfsfMappingJPList = sfsfMappingArray.collect { m ->
                            m.split('\\|')[0] // extract only Role External Code
                        }.join(',');
                    }
                        
                    cbrJobProfArray.each{ cbrJPData->
                        def(cbrJP,cbrCompWeight) = cbrJPData.toString().split(';'); //INT-362 Comp Weight Defaulting
                        //check if cbrJobProfile mapping already exists in sfsfAttributeMappings:
                        //if it doesn't yet, create sfsfRoleAttribute node so that mapping will be created
                        if(sfsfMappingJPList==null || !sfsfMappingJPList.contains(cbrJP)){
                            def sfsfExtCodes = hmap_sfsfJobProf.get(cbrJP.toString());
                            def(sfsfJPStatus,sfsfJPExtCode,sfsfRoleExtCode) = sfsfExtCodes.toString().split('\\|');                            
                            if(sfsfRoleExtCode){
                                if(sfsfJPStatus){sfsfJPStatus = 'placeholders'}; if(sfsfJPExtCode){sfsfJPExtCode = 'placeholders'}; //ignore placeholders in design guidelines
                                sumCreateMappingComp++; //counter
                                addAttrMappingNode(xml,sfsfAttrMappingEntity,sfsfRoleExtCode,"",wsmId.toString(),"A",cbrCompWeight.toString(),cbrCompRating,""); 
                            }
                        }
                    }
                }
            }
        }
        message.setProperty("hmap_cbrComp",null);           //clear processed data
        message.setProperty("hmap_sfsfJobProf",null);       //clear processed data
        message.setProperty("hmap_sfsfCompMapping",null);  //clear processed data        
        message.setProperty("sumCreateMappingComp",sumCreateMappingComp.toString());
    }
    message.setBody(writer.toString());
	return message;
}

def addAttrMappingNode(xml,String sfsfAttrMappingEntity,String sfsfEntityExtCode,String sfsfAttrMapExtCode, String wsmIdStr,String sfsfStatus, String cbrCompWeightStr, String cbrCompRating, String cbrSkillLevel) {    
    xml."${sfsfAttrMappingEntity}" {
        externalCode(sfsfAttrMapExtCode)
        RoleEntity_externalCode(sfsfEntityExtCode)
        wsmId(wsmIdStr)
        status(sfsfStatus)
        
        if(sfsfAttrMappingEntity=='RoleSkillMappingEntity'){
            //INT-362 Skill Proficiency
            wsmProficiencyLevel(cbrSkillLevel) 
        }        
        
        if(sfsfAttrMappingEntity=='RoleCompetencyMappingEntity'){
            //INT-362 compWeight & Rating
            weight_defaultValue(cbrCompWeightStr) 
            weight_en_US(cbrCompWeightStr) 
            weight_de_DE(cbrCompWeightStr) 
            
            rating_defaultValue(cbrCompRating)
            rating_en_US(cbrCompRating)
            rating_de_DE(cbrCompRating)            
        }
    }
}


