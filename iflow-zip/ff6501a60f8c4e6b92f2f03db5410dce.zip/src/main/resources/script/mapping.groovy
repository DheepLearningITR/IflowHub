import com.sap.it.api.mapping.MappingContext
import groovy.json.*;
def String format(String description, MappingContext context) {
    //double-escape ampersands or sfsf will reject it with error: //You can’t save the sections ([???JOBPROFILE_LOCALIZED_DATA_desc???]) because they contain non-alphanumeric text. The use of non-alphanumeric text may create potential vulnerabilities for cross-site scripting (XSS) attacks. Update each of the sections to use only alphanumeric text.; 1:You can’t save the sections ([???JOBPROFILE_LOCALIZED_DATA_desc???]) because they contain non-alphanumeric text. The use of non-alphanumeric text may create potential vulnerabilities for cross-site scripting (XSS) attacks. Update each of the sections to use only alphanumeric text. with the index 0
    description = description.replaceAll ('&','&amp;');
    return description;
}

def String getLocalizedText(String language_out, String language_in, String text_in, MappingContext context) {
    String text_out = '';
    if(language_in == language_out){
        text_out = text_in;
    }
    return text_out;
}
