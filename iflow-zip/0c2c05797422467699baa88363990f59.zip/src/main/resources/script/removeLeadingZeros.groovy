import com.sap.it.api.mapping.*;
import org.apache.commons.lang3.StringUtils;

def String removeLeadingZeros(String id){
    if (StringUtils.isNumeric(id)) {
    return StringUtils.stripStart(id,"0");}
    else {
    return id;}
}
