import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.LinkedHashMap;
import java.util.regex.Pattern;

def Message processData(Message message) {

    // mergeHeaders(message);

    List<String> mandatoryParameters = ["DestinationforAddon","DestinationforSAPIBP","DestinationforSAPIBP","PlanningArea","DataSource","BatchCommand","BatchName","TypeOfData","TargetFieldsInSAPIBP","BatchKey"];
    if(message.getProperty("TypeOfData").toUpperCase() == 'KEYFIGURES'){
        mandatoryParameters.add("TargetTimeProfileLevelinSAPIBP")
    }
    else if(message.getProperty("TypeOfData").toUpperCase() == 'MASTERDATA'){
        mandatoryParameters.addAll("MasterDataPrefix","MasterDataType")
    }
    else{
        throw new InvalidParameterException("TypeOfData parameter must have the value MasterData or KeyFigures");
    }

    mandatoryParameterValidation(message,mandatoryParameters);

    validateFieldMap(message.getProperty("FieldMapping"))

    List<String> extensions = ["CustomMappingExtensionIntegrationFlowAddress","PostFetchFilterExtensionAddress"]
    extensions.each {   validateExtensionID(message, it)}

    //remove spaces from specific properties
    removeParameterSpaces(message,"TargetFieldsInSAPIBP");
    removeParameterSpaces(message,"SourceFieldsfromAddon");
    removeParameterSpacesFromMapping(message);

    return message
}

def removeParameterSpaces (Message message, String propertyName) {
    def properties = message.getProperties();
    def property = properties.get(propertyName);

    def cleanedProperty = property.replaceAll("\\s", "")

    message.setProperty(propertyName,cleanedProperty);

}

def removeParameterSpacesFromMapping(Message message) {
    def properties = message.getProperties();
    def fieldMap = properties.get("FieldMapping");

    //remove every space which not between quotes
    def cleanedProperty = fieldMap.findAll(Pattern.compile('(?:"[^"]*"|[^,])+')).collect { field ->
        def (key, value) = field.split(':', 2)
        def trimUnlessQuoted = { s ->
            s.startsWith('"') && s.endsWith('"') ? s : s.replaceAll(' ', '')
        }
        "${trimUnlessQuoted(key)}:${trimUnlessQuoted(value)}"
    }.join(',')

    message.setProperty("FieldMapping",cleanedProperty);
}

def validateFieldMap(String fieldMap){
    //if(fieldMap != null && fieldMap != ''){
    //if(!fieldMap.matches("(?<=(^))(?:(?:[^:\\n\\r,]+|(?:\"(?:[^\":\\n\\r,]+|\"\")*\")):(?:[^:\\n\\r,]+|(?:\"(?:[^\":\\n\\r,]+|\"\")*\"))+(?:,|\$))+(?=(\$))")){
    //  throw new InvalidParameterException("Field Map parameter is invalid");
    // }
    // }

    if(fieldMap != null && fieldMap != ''){
        if(!fieldMap.matches('(?<=(^))(?:(?:[^:\\n\\r,]+|"(?:[^"]|"")*"):(?:[^:\\n\\r,]+|"(?:[^"]|"")*")+(?:,|$))+(?=($))')){
            throw new InvalidParameterException("Field Map parameter is invalid");
        }
    }
}

def mandatoryParameterValidation(Message message,List<String> mandatoryParameters){
    def propertyMap = message.getProperties()

    def mandatoryParametersWithoutValues = []

    mandatoryParameters.each { it ->
        def currItem = propertyMap.get(it).toString();

        if(currItem == null || currItem == '' ){
            mandatoryParametersWithoutValues.add(it)
        }
    }

    if(mandatoryParametersWithoutValues.size() > 0){
        throw new MandatoryParameterException("Mandatory Parameter(s) ${mandatoryParametersWithoutValues.join(',')} do(es) not have value(s)")
    }

}

class MandatoryParameterException extends Exception {
    //Custom exception for mandatory parameters
    MandatoryParameterException(String message) {
        super(message);
    }
}

class InvalidParameterException extends Exception {
    //Custom exception for mandatory parameters
    InvalidParameterException(String message) {
        super(message);
    }
}

// The validation is based on the https://help.sap.com/docs/cloud-integration/sap-cloud-integration/configure-processdirect-receiver-adapter
// Simple expressions should already be evaluated
def validateExtensionID(Message message, String extensionID) {
    if (extensionID) {
        def extensionIDValue = message.getProperty(extensionID)
        if (!(extensionIDValue == null || extensionIDValue == '' ||extensionIDValue.matches('^/?[A-Za-z0-9_-]+$'))) {
            throw new InvalidParameterException("${extensionID} parameter with value ${extensionIDValue} is not a well formatted extension ID");
        }
    }
}
