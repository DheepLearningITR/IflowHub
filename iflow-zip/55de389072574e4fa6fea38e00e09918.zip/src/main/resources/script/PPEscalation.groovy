import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    def bodyAsString = message.getBody(java.lang.String);
    def xml = new XmlSlurper().parseText(bodyAsString)

    def firstErrorValues = xml.'**'.findAll { node -> 
        node.name() == 'File' && node.@FirstError
        }.collect { it.@FirstError.toString() }
    
    message.setProperty("FirstErrors", firstErrorValues.toString())
    
    throw new Exception("Error(s) occurred during processing of data written to IBP Batch: " + firstErrorValues); 


    return message;
}

def Message storeEscalation(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    def headers = message.getHeaders();
    def properties = message.getProperties();
    
    message.setHeader("EscalationMessage", message.getProperty("CamelExceptionCaught"))
    

    return message;
}
