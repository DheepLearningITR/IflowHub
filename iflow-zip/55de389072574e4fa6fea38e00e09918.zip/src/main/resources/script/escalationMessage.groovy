import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.msglog.*;


def Message giveEscalationMessage(Message message) {
    //Throw a custom exception and set an escalation message based on status and the existence of messages
    def messageLog = messageLogFactory.getMessageLog(message);
    def bodyAsString = message.getBody(java.lang.String);
    def properties = message.getProperties();
    def headers = message.getHeaders();
    String correlationID = headers.get("SAP_MplCorrelationId") ?: '';
    String createBatchMessages = properties.get("CreateBatchesMessages") ?: '';
    String dataTransferMessages = properties.get("DataTransferMessages") ?: '';
    String closeMessages = properties.get("CloseMessages") ?: '';

    if (messageLog != null) {
        String status = getStatus(message)
        String escalationMessage = "There was a error during the read process, check the logs for Correlation ID: " + correlationID + " "
        if (closeMessages != '') {
            try {
                //Expectation is that the status is the worst one so we rethrow the worst message type
                escalationMessage = getFirstCloseMessageWithTypeMatchingStatus(message, status)
            }
            catch (Exception e) {
                throw new Exception(e.getMessage());
            }
            throw new CloseException(escalationMessage);
        }
        else if (dataTransferMessages != '') {
            try {
                //Expectation is that the status is the worst one so we rethrow the worst message type
                escalationMessage = getFirstDataTransferMessageWithTypeMatchingStatus(message, status)
            }
            catch (Exception e) {
                throw new Exception(e.getMessage());
            }
            throw new DataTransferException(escalationMessage);
        }
        else if (createBatchMessages != '') {
            try {
                //Expectation is that the status is the worst one so we rethrow the worst message type
                escalationMessage = getFirstCreateBatchMessageWithTypeMatchingStatus(message, status)
            }
            catch (Exception e) {
                throw new Exception(e.getMessage());
            }
            throw new CreateBatchException(escalationMessage);
        }
        else {
            messageLog.addCustomHeaderProperty("Escalation message", escalationMessage);
            messageLog.addAttachmentAsString('Body before escalation:', bodyAsString, 'text/xml')
            throw new Exception(escalationMessage);
        }

    }
    messageLog.addAttachmentAsString('Body before error', bodyAsString, 'text/xml')
    return message;
}

def String getStatus(Message message) {
    //Returns the status of the iflow property has a higher priority compared to body
    String status = message.getProperty('Status') ?: ''
    if (status != '') {
        return status
    } else {
        def parsedBody = new XmlSlurper().parse(message.getBody(java.io.Reader));
        return parsedBody?.@Status?.text()
    }
}

def String getFirstCreateBatchMessageWithTypeMatchingStatus(Message message, String status) {
    //Get the first message with the given type
    def parsedCreateBatchMessages = new XmlSlurper().parseText("<Messages>" + (message.getProperty('CreateBatchesMessagesMessages') as String)  + "</Messages>")
    def firstCreateBatchMessageWithTypeMatchingStatus = parsedCreateBatchMessages?.'**'?.find { it -> it.name() == 'Message' && it.@Type.text() == status && it.text() != "" }

    return firstCreateBatchMessageWithTypeMatchingStatus.text()
}

public class CreateBatchException extends Exception {
    //Custom exception for Create Batch
    public CreateBatchException(String message) {
        super(message);
    }
}

def String getFirstCloseMessageWithTypeMatchingStatus(Message message, String status) {
    //Get the first message with the given type
    def parsedCloseMessages = new XmlSlurper().parseText("<Messages>" + (message.getProperty('CloseMessages') as String)  + "</Messages>")
    def firstCloseMessageWithTypeMatchingStatus = parsedCloseMessages?.'**'?.find { it -> it.name() == 'Message' && it.@Type.text() == status && it.text() != "" }

    return firstCloseMessageWithTypeMatchingStatus.text()
}

public class CloseException extends Exception {
    //Custom exception for close
    public CloseException(String message) {
        super(message);
    }
}


def String getFirstDataTransferMessageWithTypeMatchingStatus(Message message, String status) {
    //Get the first message with the given type
    def parsedDataTransferMessages = new XmlSlurper().parseText("<Messages>" + (message.getProperty('DataTransferMessages') as String)  + "</Messages>")
    def firstDataTransferMessageWithTypeMatchingStatus = parsedDataTransferMessages?.'**'?.find { it -> it.name() == 'Message' && it.@Type.text() == status && it.text() != "" }

    return firstDataTransferMessageWithTypeMatchingStatus.text()
}

public class DataTransferException extends Exception {
    //Custom exception for Data Transfer
    public DataTransferException(String message) {
        super(message);
    }
}
