import com.sap.gateway.ip.core.customdev.util.Message;
// import com.sap.it.api.msglog.MessageLogFactory;
import com.sap.it.api.msglog.MessageLog;
import java.util.Map.Entry;

def Message processData(Message message) {

    def headers = message.getHeaders();
	def properties = message.getProperties();
	MessageLog messageLog = messageLogFactory.getMessageLog(message);
	
    if(messageLog != null){
        String logHeaders = ""
        String logProperties = ""
        
        for(Entry<String, Object> entry: headers.entrySet()) {
           logHeaders = logHeaders + entry.getKey() + ": " + entry.getValue() + "\n"
        }
        for(Entry<String, Object> entry2: properties.entrySet()) {
           logProperties = logProperties + entry2.getKey() + ": " + entry2.getValue() + "\n"
        }
        
        messageLog.addAttachmentAsString('Headers', logHeaders, 'text/plain')
        messageLog.addAttachmentAsString('Properties', logProperties, 'text/plain')
        messageLog.addAttachmentAsString('Body', message.getBody(String), 'text/csv')
    }
    
	return message;
}