import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    
    def properties = message.getProperties()
    def headers = message.getHeaders()
    
    def numPerPage = properties.get("numPerPage")
    def endCursor = headers.get("endCursor")
    def nodeStructure = properties.get("nodeStructure")
    def filter = properties.get("filter") ?: null

    // Construct GraphQL query cursor dynamically - depending on numPerPage, if there are more pages, then the main flow provides the header endCursor. The first (initial) Call is always with "first: ${numPerPage}"
    def cursor = endCursor ? "after: \"${endCursor}\"" : "first: ${numPerPage}"

    def graphQLQueryTemplate = """query getSurveyTakerContactDetails(\$filter: Filter) {
        feedback(filter: \$filter, ${cursor}) {
            ${nodeStructure}
            totalCount
            pageInfo {
                hasNextPage
                endCursor
            }
        }
    }"""

    def payload = [
        query: graphQLQueryTemplate,
        variables: [filter: filter]
    ]

    message.setHeader("Content-Type", "application/json")
    message.setHeader("Accept", "application/json")
    message.setBody(JsonOutput.toJson(payload))
    
    return message
}
