import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential
import com.sap.it.api.securestore.exception.SecureStoreException
import groovy.xml.StreamingMarkupBuilder;
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import groovy.util.XmlSlurper
import groovy.json.JsonSlurper
import groovy.xml.XmlUtil

// Class to handle fetching the OAuth2 access token.
class OAuth2TokenService {
    String tokenUrl
    String clientId
    String clientSecret
    
    // Constructor that initializes the token endpoint and credentials.
    OAuth2TokenService(String tokenUrl, String clientId, String clientSecret) {
        this.tokenUrl = tokenUrl
        this.clientId = clientId
        this.clientSecret = clientSecret
    }
    
    // Method to perform the token fetch. It sends a POST request to the token URL.
    String fetchAccessToken() {
        URL url = new URL(tokenUrl)
        // Open HTTP connection for sending a POST request
        // set the form content type
        HttpURLConnection connection = (HttpURLConnection) url.openConnection()
        connection.requestMethod = "POST"
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        
        // Build the POST request body with necessary parameters.
        def requestBody = "grant_type=client_credentials" +
        "&client_id=" + URLEncoder.encode(clientId, "UTF-8") +
        "&client_secret=" + URLEncoder.encode(clientSecret, "UTF-8")
        
        // Write the POST data into the request's output stream.
        connection.outputStream.withWriter("UTF-8") { writer ->
            writer << requestBody
        }
        
        // Check for a successful response.
        int responseCode = connection.responseCode
        if (responseCode != HttpURLConnection.HTTP_OK) {
        def errMsg = connection.errorStream?.text
                throw new RuntimeException("Failed to obtain token: HTTP ${responseCode}. Error: ${errMsg}")
        }
        
        // Parse the JSON response.
        def responseText = connection.inputStream.text
        def json = new JsonSlurper().parseText(responseText)
        if (json.access_token) {
            return json.access_token.toString()
        } else {
            prinln("Access token not found in the response: ${responseText}")
            throw new RuntimeException("Access token not found in the response: ${responseText}")
        }
    }
}

def Message processData(Message message) {
    
    //get interface PID list from Partner Directory
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 
    def interfaces = service.getParameter("InterfacePidList", "RestartJobProfile_1hour" , String.class)
    
    // get tokenURL and set apiUrl
    String tokenUrl = message.getProperty("tokenUrl")
    def apiUrl = message.getProperty("hostname") + "/DataStores"
    
    //get clientId and clientSecret for CI API Call maintained as User Credential 
    def CredentialAlias = message.getProperty("oauth_client_credentials_alias")
    def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)
    def credential = secureStorageService.getUserCredential(CredentialAlias)
    String clientId = credential.getUsername()
    String clientSecret = credential.getPassword().toString()
    
    // Create an instance of OAuth2TokenService and fetch the access token.
    def tokenService = new OAuth2TokenService(tokenUrl, clientId, clientSecret)
    String accessToken
    try {
        accessToken = tokenService.fetchAccessToken()
    } catch (Exception e) {
        throw new RuntimeException("Error fetching access token: ${e.message}")
        System.exit(1)
    }
    
    //execute GET call with set Bearer token
    URL apiEndpoint = new URL(apiUrl)
    HttpURLConnection apiConnection = (HttpURLConnection) apiEndpoint.openConnection()
    apiConnection.requestMethod = "GET"
    apiConnection.setRequestProperty("Authorization", "Bearer " + accessToken)
    apiConnection.setRequestProperty("Accept", "application/xml")

    //check responseCode 
    int apiResponseCode = apiConnection.responseCode
    if (apiResponseCode == HttpURLConnection.HTTP_OK) {
        def apiResponseText = apiConnection.inputStream.text
        def apiXml = new XmlSlurper().parseText(apiResponseText)
        // Read the expected XML string from the message properties.
        def dataStoresToCheck = message.getProperty("DataStoresToCheckXML")
        def dataStoresToCheckXML = new XmlSlurper().parseText(dataStoresToCheck)
        // Create an empty list to store the DataStoreName values
        def apiDataStoreNames = []
        // Second list to store DataStoreName values from the provided XML.
        def secondDataStoreNames = []
        
        // Iterate over each entry in the API XML response.
        apiXml.entry.each { entry ->
            // Retrieve the DataStoreName value from the API XML response
            def dsName = entry.content.properties.DataStoreName.text()
            if (dsName) {
                // Add the DataStoreName to the list.
                apiDataStoreNames << dsName
            }
            
            // For each interface in the provided XML, collect DataStoreName value.
            dataStoresToCheckXML.Interface.each { iface ->
                def dsName2 = iface.DataStoreName.text()
                if (dsName2) {
                    secondDataStoreNames << dsName2
                }
            }
        }
        // ----- Compare the two lists -----
        // For each datastore name obtained from the first API response XML, check if it exists in the second XML and log it into foundDataStoreNames 
        def foundDataStoreNames = [] // Also keep as a List for filtering
        apiDataStoreNames.each { dsName3 ->
            if (secondDataStoreNames.contains(dsName3))
                foundDataStoreNames << dsName3
        }
        
        // Retrieve the message log  to record additional information.
        def messageLog = messageLogFactory.getMessageLog(message)

        // Convert the StringBuilder to a String for logging
        def foundDataStoresString = foundDataStoreNames.join(', ')
        //if nothing found log it in custom header and set property for later routing
        if (foundDataStoreNames.isEmpty()){
            message.setProperty("DataStoresFound", false)
            if(messageLog != null){
			    messageLog.addCustomHeaderProperty("No Data Stores found for interfaces", interfaces);		
            }
	    }
        else{ //if there are some matching data stores, log the ones found and set property for later routing 
            message.setProperty("DataStoresFound", true)
            if(messageLog != null){
			    messageLog.addCustomHeaderProperty("Data Stores found for interfaces", foundDataStoresString);		
            }
        }


        // Filter the second XML so that only <Interface> nodes whose DataStoreName text exists in foundDataStoreNames remain.
        // Use trim() when comparing.
        def filteredInterfaces =[]
        def builder = new StreamingMarkupBuilder()
        def newSecondXml = builder.bind {
            mkp.xmlDeclaration(version: "1.0", encoding: "utf-8")
            DataStores { 
                dataStoresToCheckXML.Interface.'**'.findAll { it.name() == 'DataStoreName' }.each { item -> // Process each DataStoreName node in the provided XML
                    if (foundDataStoreNames.contains(item)) { // If the DataStoreName exists in the matched list, include its parent Interface.
                        Interface {
                            InterfacePID(item.parent().InterfacePID.text())
                            DataStoreName(item.parent().DataStoreName.text())
                            MaxRetryCount(item.parent().MaxRetryCount.text())
                        }
                    }
                }
            }
        }

        // Serialize the newly built XML to a string and replace message body
        def newSecondXmlString = XmlUtil.serialize(newSecondXml)
        message.setBody(newSecondXmlString)
    }
    else {
        // If the API response is not HTTP_OK, read the error response from the connection and set it to the body which later triggers an exception
        def errorResponse = apiConnection.errorStream?.text
        message.setBody(errorResponse)
    }
    return message;
}