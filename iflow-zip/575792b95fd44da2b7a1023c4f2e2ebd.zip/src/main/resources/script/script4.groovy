import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {

    //Exception message encoding
    def headers = message.getHeaders();
    def exceptionMessage = headers.get("exceptionMessage");
    def encodedexceptionMessage = exceptionMessage.bytes.encodeBase64().toString()
    message.setHeader("exceptionMessage", encodedexceptionMessage);
    
    //Payload encoding
    def properties = message.getProperties();
    def payload = properties.get("payload");
    def encodedPayload = payload.bytes.encodeBase64().toString()
    message.setProperty("payload", encodedPayload);
    
    return message;
}