import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential
import com.sap.it.api.securestore.exception.SecureStoreException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import groovy.util.XmlSlurper
import groovy.json.JsonSlurper
import groovy.xml.XmlUtil


class OAuth2TokenService {
    String tokenUrl
    String clientId
    String clientSecret

    OAuth2TokenService(String tokenUrl, String clientId, String clientSecret) {
        this.tokenUrl = tokenUrl
        this.clientId = clientId
        this.clientSecret = clientSecret
    }
    
    
    String fetchAccessToken() {
        URL url = new URL(tokenUrl)
        HttpURLConnection connection = (HttpURLConnection) url.openConnection()
        connection.requestMethod = "POST"
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        
        
        def requestBody = "grant_type=client_credentials" +
        "&client_id=" + URLEncoder.encode(clientId, "UTF-8") +
        "&client_secret=" + URLEncoder.encode(clientSecret, "UTF-8")
        
        // Write the POST data.
        connection.outputStream.withWriter("UTF-8") { writer ->
            writer << requestBody
        }
        
        // Check for a successful response.
        int responseCode = connection.responseCode
        if (responseCode != HttpURLConnection.HTTP_OK) {
        def errMsg = connection.errorStream?.text
                throw new RuntimeException("Failed to obtain token: HTTP ${responseCode}. Error: ${errMsg}")
        }
        
        // Parse the JSON response.
        def responseText = connection.inputStream.text
        def json = new JsonSlurper().parseText(responseText)
        if (json.access_token) {
            return json.access_token.toString()
        } else {
            throw new RuntimeException("Access token not found in the response: ${responseText}")
        }
    }
}

def Message processData(Message message) {
    /*def tokenUrl = 'https://tech.authentication.eu10.hana.ondemand.com/oauth/token' // Replace with your token endpoint
    def apiUrl = "https://tech.it-cpi018.cfapps.eu10-003.hana.ondemand.com:443/api/v1/DataStores(DataStoreName='ECCTempo~InvoiceDRC_out_DLQ',IntegrationFlow='',Type='')/Entries" 
    def clientId = 'sb-8fffa4b7-bba5-4523-ac82-dc60f9111f88!b15282|it!b117912' // Replace with your client ID
    def clientSecret = 'add953e2-e9fa-4a46-af46-ac320390a905$epvlvyFgQJBvXoZp2DJ5t5-N9strUwnqhfPvZ8wYjLI=' // Replace with your client secret*/
    def tokenUrl = message.getProperty("tokenUrl")
    def apiUrl = message.getProperty("hostname") + "/DataStores"
    
    def CredentialAlias = message.getProperty("oauth_client_credentials_alias")
    def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)
    def credential = secureStorageService.getUserCredential(CredentialAlias)
    def clientId = credential.getUsername()
    def clientSecret = credential.getPassword().toString()
    
    message.setProperty("apiUrl",apiUrl)
    message.setProperty("tokenUrl",tokenUrl)
    message.setProperty("clientId",clientId)
    message.setProperty("clientSecret",clientSecret)
    
    return message;
}