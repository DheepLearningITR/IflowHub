/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
      public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Calendar.*;
import groovy.xml.*;
import com.sap.it.api.ITApiFactory; 
import com.sap.it.api.securestore.SecureStoreService; 
import com.sap.it.api.securestore.UserCredential; 
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import groovy.json.JsonSlurper;
import groovy.xml.XmlUtil;

def Message SetSecurityProperties(Message message) {
    def body = message.getBody(java.lang.String) as String; 
    def map = message.getProperties();
    def taxID = map.get("TaxID") as String;

    def service = ITApiFactory.getApi(SecureStoreService.class, null); 
    if (service == null){
        throw new IllegalStateException("SecureStoreService not found");
    }
    
    //Authorization maintained in Security Material with name like "edoc_th_stream_auth_1234567890123"
    def credentialName = "edoc_th_stream_auth_" + taxID;
    def credential = service.getUserCredential(credentialName); // exception will be raised automatically

    def userName = credential.getUsername(); 
    def password = credential.getPassword().toString(); 
    def auth2BeEncoded = userName + ":" + password;
    message.setProperty("Auth", "Basic " + auth2BeEncoded.bytes.encodeBase64().toString());
    
    //API Key maintained in Security Material with name like "edoc_th_stream_apikey_1234567890123"
    credentialName = "edoc_th_stream_apikey_" + taxID;
    def secureParameter = service.getUserCredential(credentialName); // exception will be raised automatically
    def apiKey = secureParameter.getPassword().toString()
    message.setProperty("ApiKey", apiKey);
    
	return message;
}

def Message GenerateResponseNamespace(Message message) {
    def body = message.getBody(java.lang.String) as String; 
	
    def xmlSlurper = new XmlSlurper()
    def data = xmlSlurper.parseText(body); 
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
    switch (data.name()) {
        case 'SendTaxInvoiceRequest':
            message.setProperty("responseNamespace","http://www.sap.com/eDocument/TH/SendTaxInvoice/v1.0");
            break
        case 'SendReceiptRequest':
            message.setProperty("responseNamespace","http://www.sap.com/eDocument/TH/SendReceipt/v1.0");
            break
        case 'SendDebitCreditNoteRequest':
            message.setProperty("responseNamespace","http://www.sap.com/eDocument/TH/SendDebitCreditNote/v1.0");
            break
        default: 
            message.setProperty("responseNamespace","http://www.sap.com/eDocument/TH/SendTaxInvoice/v1.0");
            // we cannot throw exception here, not knowing the correct response XML namespace
            // throw new IllegalStateException("Wrong XML root node name that SAP sends out"); 
            break
    }
    
    return message;
}

def Message LogRequest(Message message) {
    def map = message.getProperties();
    def log = map.get("EnableLog") as String;
    def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	def logID = map.get("LogID") as String;
	
	if (log == 'X') {
	    messageLog.addAttachmentAsString(logID + '_send_invoice_request', body, "text/xml"); 
	}
     
    return message;
}

def Message LogStreamResponse(Message message) {
    def map = message.getProperties();
    def log = map.get("EnableLog") as String;
    def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	def logID = map.get("LogID") as String;
	
    if (log == 'X') {
	    messageLog.addAttachmentAsString(logID + '_send_invoice_response', body, "text/json"); 
	}
    
    return message;
}

def Message PrepareCustomizedResponse(Message message) {
    def map = message.getProperties();

    def body = message.getBody(java.lang.String) as String;
    
    def jsonSlurper = new JsonSlurper()
    def object = jsonSlurper.parseText(body);

    message.setProperty("resultCode",object.data.resultCode);
    message.setProperty("resultMessage",groovy.xml.XmlUtil.escapeXml(object.data.resultMessage));

    return message;
}


def Message PrepareExceptionResponse(Message message) {
    def map = message.getProperties();
    // get an exception java class instance
    def ex = map.get("CamelExceptionCaught");
    
    if (ex!=null) {
        // an http adapter throws an instance of org.apache.camel.component.ahc.AhcOperationFailedException
        if (ex.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
            def httpResponseBody = ex.getResponseBody();
            def jsonSlurper = new JsonSlurper()
            def httpResponseBodyJson = jsonSlurper.parseText(httpResponseBody);

            message.setProperty("ExceptionStatusCode",ex.getStatusCode());
            message.setProperty("ExceptionMessage",groovy.xml.XmlUtil.escapeXml(httpResponseBodyJson.exception + " message: " + httpResponseBodyJson.message));
        } else {
            // message.setProperty("httpStatusCode",ex.getStatusCode());
            message.setProperty("ExceptionMessage",groovy.xml.XmlUtil.escapeXml("iFlow Exception: " + ex.getMessage()));
        }
    }

    return message;
}

def Message ChangeProductCode(Message message) {
    def body = message.getBody(java.lang.String) as String; 
    def map = message.getProperties();
    def productcode = map.get("ProductCode") as String;

    //Parse the xml
    def root = new XmlParser().parseText(body);
  
    if ( productcode!= null && !productcode.isEmpty()) {
        root.ExchangedDocument.ProductCode[0].value = productcode;
    };
    
    //root.SupplyChainTradeTransaction.ApplicableHeaderTradeAgreement.SellerTradeParty.ID[0].value = "SAP";
    message.setBody(XmlUtil.serialize(root));
    
	return message;
}
