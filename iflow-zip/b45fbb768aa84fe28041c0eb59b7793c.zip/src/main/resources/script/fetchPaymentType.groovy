import com.sap.it.api.mapping.*;



def String fetchPaymentType(String p1, MappingContext context) {
         
         String value2 = context.getProperty("paymentMethod");
         if(value2==null || value2.trim().equals(""))
         {
             value2 = p1;
         }
         return value2;
}




