import com.sap.it.api.mapping.*;



def String fetchPropertyValue(String p1, MappingContext context) {
         
         String value2 = context.getProperty("revenueCloudCustomerId");
         if(value2==null || value2.trim().equals(""))
         {
             value2 = context.getProperty("b2c_revenueCloudCustomerId");
         }
         return value2;
}




