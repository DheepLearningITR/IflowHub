import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message){
	def body = message.getBody(java.lang.String) as String
    def jsonObject = new JsonSlurper().parseText(body);
    def items = jsonObject.get('items');
	def itemArr = [];
	
	items.each { itemArr.add( it.getValue() ) }
    jsonObject.put('items', itemArr);
    
    print JsonOutput.toJson(jsonObject);
	message.setBody(JsonOutput.toJson(jsonObject))
	return message;
}