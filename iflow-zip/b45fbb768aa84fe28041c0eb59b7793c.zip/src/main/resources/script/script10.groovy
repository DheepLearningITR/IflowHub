import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

	def pmap = message.getProperties();
	
	def properties = message.getProperties() as Map<String, Object>;
	
	def messageLog = messageLogFactory.getMessageLog(message);

	if(messageLog != null){
			messageLog.addAttachmentAsString("b2c_revenueCloudCustomerId", properties.get("b2c_revenueCloudCustomerId") as String);
	
	}
	
	return message;
}