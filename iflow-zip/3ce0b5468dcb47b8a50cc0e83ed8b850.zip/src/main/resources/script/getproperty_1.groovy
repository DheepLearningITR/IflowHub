import com.sap.it.api.mapping.*;

import com.sap.it.api.mapping.MappingContext;

def String getproperty_1(String inp, MappingContext context){
    
    def customProp= context.getProperty(inp);
    
	return customProp; 
}