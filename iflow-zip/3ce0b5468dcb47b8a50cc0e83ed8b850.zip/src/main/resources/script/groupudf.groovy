import com.sap.it.api.mapping.*;



def String customFunc(String str, MappingContext context){
    String value = context.getProperty(str);
    return value;
}