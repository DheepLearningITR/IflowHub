import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser
import groovy.xml.XmlUtil

Message processData(Message message) {
    
    def body = message.getBody(java.io.Reader)
    def parser = new XmlParser().parse(body)
    def customerReturn = parser.A_CustomerReturnType.CustomerReturn.text()

    def orderReturnsXml = message.getProperty("currentShopifyReturnOrderXML")

    if (orderReturnsXml) {
        def orderReturns = new XmlParser().parseText(orderReturnsXml)

        def returnNode = orderReturns.Return[0]
        if (returnNode) {
            def s4HanaCloudReturnIDNode = returnNode.S4HanaCloudReturnID[0]
            
            if (s4HanaCloudReturnIDNode) {
                s4HanaCloudReturnIDNode.setValue(customerReturn)
            } else {
                returnNode.appendNode('S4HanaCloudReturnID', customerReturn)
            }
        }

        def updatedOrderReturnsXml = XmlUtil.serialize(orderReturns)

        message.setProperty("currentShopifyReturnOrderXML", updatedOrderReturnsXml)
    } else {
        message.setProperty("currentShopifyReturnOrderXML", "<Returns/>")
    }

    return message
}