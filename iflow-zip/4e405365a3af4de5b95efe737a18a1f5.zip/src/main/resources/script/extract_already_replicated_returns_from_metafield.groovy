import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def xmlParser = new XmlSlurper().parseText(body)
    def replicatedReturnsElement = xmlParser.s4HanaCloudOrderReplicatedReturns
    if (replicatedReturnsElement && replicatedReturnsElement.value && replicatedReturnsElement.value.text()) {
        def replicatedReturnsValue = replicatedReturnsElement.value.text()
        println(replicatedReturnsValue)
        if (replicatedReturnsValue) {
            message.setProperty("shopifyOrderAlreadyReplicatedReturnsJson", replicatedReturnsValue)
        }
    }

    return message
}