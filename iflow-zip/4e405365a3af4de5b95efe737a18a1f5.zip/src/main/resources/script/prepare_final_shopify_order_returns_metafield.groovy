import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def xmlBody = message.getBody(String)
    def newlyAddedReturns = extractNewlyAddedReturnsFromXml(xmlBody)
    def alreadyReplicatedReturnsJson = message.getProperty("shopifyOrderAlreadyReplicatedReturnsJson")

    if (alreadyReplicatedReturnsJson && alreadyReplicatedReturnsJson.trim()) {
        def alreadyReplicatedReturns = new JsonSlurper().parseText(alreadyReplicatedReturnsJson)

        if (alreadyReplicatedReturns.returns) {
            newlyAddedReturns.addAll(alreadyReplicatedReturns.returns)
        }
    }

    def jsonMap = [returns: newlyAddedReturns]
    def jsonOutput = JsonOutput.toJson(jsonMap)

    message.setProperty("shopifyOrderUpdatedReturnsJson", jsonOutput)

    def escapedJsonOutput = jsonOutput.replace("\\", "\\\\").replace("\"", "\\\"")

    message.setBody(escapedJsonOutput)

    return message
}

def extractNewlyAddedReturnsFromXml(String xmlBody) {
    def xmlParser = new XmlSlurper().parseText(xmlBody)
    def newlyAddedReturns = []

    xmlParser.Return.each { returnElement ->
        def returnMap = [
                shopifyReturnID: returnElement.ShopifyReturnID.text(),
                shopifyReturnName: returnElement.ShopifyReturnName.text(),
                s4HanaCloudReturnID: returnElement.S4HanaCloudReturnID.text()
        ]

        newlyAddedReturns.add(returnMap)
    }
    return newlyAddedReturns
}