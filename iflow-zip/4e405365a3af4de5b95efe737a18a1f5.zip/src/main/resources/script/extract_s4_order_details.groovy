import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def xmlBody = new XmlSlurper().parse(body)
    def orderInformation = xmlBody

    if (orderInformation) {
        def shopifyOrderID = orderInformation.id.text();
        def shopifyOrderIDPaths = shopifyOrderID ? shopifyOrderID.split("/") : [];

        if (shopifyOrderID && shopifyOrderIDPaths && shopifyOrderIDPaths.size() > 0) {
            def shopifyOrderIDTrimmed = shopifyOrderIDPaths[shopifyOrderIDPaths.size() - 1]
            
            message.setProperty("shopifyOrderIDTrimmed", shopifyOrderIDTrimmed);
            message.setProperty("shopifyOrderID", shopifyOrderID)
        }

        def s4HanaCloudOrderId = orderInformation.s4HanaCloudOrderId;

        if (s4HanaCloudOrderId && s4HanaCloudOrderId.key.text() == "shopifyaccelerator.s_4hana_cloud_order_id") {
            def s4HanaCloudOrderValue = s4HanaCloudOrderId.value.text();
            if (s4HanaCloudOrderValue) {
                message.setProperty("S4HanaCloudOrderID", s4HanaCloudOrderValue);
            }
        }
        
        def currentProcessedShopifyOrderUpdatedAtTimestamp = orderInformation.updatedAt;
        
        if(currentProcessedShopifyOrderUpdatedAtTimestamp && currentProcessedShopifyOrderUpdatedAtTimestamp.text()) {
            message.setProperty("currentProcessedShopifyOrderUpdatedAtTimestamp", currentProcessedShopifyOrderUpdatedAtTimestamp)
        }
    }

    return message;
}