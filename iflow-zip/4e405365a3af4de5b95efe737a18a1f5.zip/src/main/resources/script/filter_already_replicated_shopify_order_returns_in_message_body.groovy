import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.xml.MarkupBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def xmlBody = message.getBody(String)
    def xmlParser = new XmlSlurper().parseText(xmlBody)

    def jsonString = message.getProperty("shopifyOrderAlreadyReplicatedReturnsJson")

    def replicatedReturnIDs = []

    if (jsonString && jsonString.trim()) {
        def jsonParser = new JsonSlurper().parseText(jsonString)

        replicatedReturnIDs = jsonParser.returns.collect { it.shopifyReturnID }
    }

    def filteredReturns = xmlParser.Return.findAll { returnElement ->
        !replicatedReturnIDs.contains(returnElement.ShopifyReturnID.text())
    }

    def resultsXml = new StringWriter()
    def xmlBuilder = new MarkupBuilder(resultsXml)
    xmlBuilder.Returns {
        filteredReturns.each { returnElement ->
            Return {
                ShopifyReturnID(returnElement.ShopifyReturnID.text())
                ShopifyReturnName(returnElement.ShopifyReturnName.text())
                S4HanaCloudReturnID(returnElement.S4HanaCloudReturnID.text())
                returnElement.ReturnLineItem.each { lineItem ->
                    ReturnLineItem {
                        shopifyReturnLineItem(lineItem.shopifyReturnLineItem.text())
                        returnQuantity(lineItem.returnQuantity.text())
                        SKU(lineItem.SKU.text())
                    }
                }
            }
        }
    }

    message.setBody(resultsXml.toString())

    return message
}