import com.sap.gateway.ip.core.customdev.util.Message
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def currentExecutionLastProcessedShopifyOrderUpdatedAtTimestamp = message.getProperty("current_execution_last_processed_shopify_order_updated_at_timestamp")

    def body = message.getBody(java.io.Reader)
    if (body == null) {
        return message
    }

    def xml = new XmlSlurper().parse(body)
    if (xml == null || xml.shopifyOrder == null || xml.shopifyOrder.size() == 0) {
        return message
    }

    ZonedDateTime latestProcessedShopifyOrderUpdatedAt = null
    xml.shopifyOrder.each { order ->
        def updatedAtString = order.updatedAt.text()
        if (updatedAtString != null && !updatedAtString.trim().isEmpty()) {
            ZonedDateTime currentIteratedShopifyOrderUpdatedAt = ZonedDateTime.parse(updatedAtString, DateTimeFormatter.ISO_ZONED_DATE_TIME)
            if (latestProcessedShopifyOrderUpdatedAt == null || currentIteratedShopifyOrderUpdatedAt.isAfter(latestProcessedShopifyOrderUpdatedAt)) {
                latestProcessedShopifyOrderUpdatedAt = currentIteratedShopifyOrderUpdatedAt
            }
        }
    }

    if (latestProcessedShopifyOrderUpdatedAt != null) {
        if (currentExecutionLastProcessedShopifyOrderUpdatedAtTimestamp != null && !currentExecutionLastProcessedShopifyOrderUpdatedAtTimestamp.trim().isEmpty()) {
            ZonedDateTime currentExecutionLastProcessedShopifyOrderUpdatedAtTime = ZonedDateTime.parse(currentExecutionLastProcessedShopifyOrderUpdatedAtTimestamp, DateTimeFormatter.ISO_ZONED_DATE_TIME)
            if (latestProcessedShopifyOrderUpdatedAt.isAfter(currentExecutionLastProcessedShopifyOrderUpdatedAtTime)) {
                message.setProperty("current_execution_last_processed_shopify_order_updated_at_timestamp", latestProcessedShopifyOrderUpdatedAt.toString())
            }
        } else {
            message.setProperty("current_execution_last_processed_shopify_order_updated_at_timestamp", latestProcessedShopifyOrderUpdatedAt.toString())
        }
    }

    return message
}