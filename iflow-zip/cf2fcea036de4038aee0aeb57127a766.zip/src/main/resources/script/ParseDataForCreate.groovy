import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;
import groovy.json.JsonOutput;

def Message processData(Message message) {
	
	def body = message.getBody(String.class);
	def parsedObj = new JsonSlurper().parseText(body);

	def finalObj = new JsonSlurper().parseText('{}');
	
	finalObj <<[parsedObj.LeadCollection];

	JsonBuilder builder = new JsonBuilder(finalObj);
    String jsonBody = JsonOutput.prettyPrint(builder.toString());
    message.setBody(jsonBody);
	
	return message;
	
}