import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody();
    
    def headers = message.getHeaders();

    def properties = message.getProperties();
    
    def count = properties.get("count");
     def eventId = properties.get("eventId");
    
    //check if the row exist in DB
    def hasResult = '0';
    
    // get results
    def jsonSlurper = new JsonSlurper();
    def dbResult = jsonSlurper.parse(body);
    
    if (dbResult && dbResult.SelectStatement_response && 
        dbResult.SelectStatement_response.row && dbResult.SelectStatement_response.row.size() > 0) {
       hasResult = '1';
       
         //log Result
        //def messageLog = messageLogFactory.getMessageLog(message);
        //messageLog.addAttachmentAsString('hasResult-DB-'+count.toString()+'-'+eventId.toString(), dbResult.SelectStatement_response.row.toString(), 'text/plain');
    }
    
    message.setProperty("hasResult", hasResult);
    
   

    return message;
}