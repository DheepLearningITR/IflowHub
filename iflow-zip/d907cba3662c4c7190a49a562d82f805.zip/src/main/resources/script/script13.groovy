import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();

    def properties = message.getProperties();
    
    //get db schema
    def eventId = properties.get('eventId');
    def db_schema = properties.get('Database_Schema_Name');
    
     // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    
    //eventState -> 6 -> pendingSelection
    
    sqlStatement.root {
        sqlStatement.SelectStatement {
            sqlStatement.app_sourcing_supplier_invitation(action: 'SELECT') {
                sqlStatement.table(db_schema + '.APP_SOURCING_SUPPLIER_INVITATION')
                sqlStatement.access {
                    sqlStatement.EVENT_ID()
                    sqlStatement.SUPPLIER_ORG_ID()
                    sqlStatement.SUPPLIER_INVITATION_ID()
                }
                sqlStatement.key {
                    sqlStatement.EVENT_ID(eventId)
                }
            }
        }
    };
    
    //set body
    message.setBody(writer.toString());
    
    //log Result
    //def messageLog = messageLogFactory.getMessageLog(message);
    //messageLog.addAttachmentAsString('db-query-'+count.toString(), writer.toString(), 'text/plain');

    
    return message;
}