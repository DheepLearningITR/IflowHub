/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Body
    def body = message.getBody();
    
    //Headers
    def headers = message.getHeaders();

    //Properties
    def properties = message.getProperties();
     def count = properties.get("count");
    
    //check if the row exist in DB
    def hasResult = '0';
    
    // get results
    def jsonSlurper = new JsonSlurper();
    def dbResult = jsonSlurper.parse(body);
    
    def bidKeyList = new ArrayList<String>();
    
    if (dbResult && dbResult.SelectStatement_response && 
        dbResult.SelectStatement_response.row && dbResult.SelectStatement_response.row.size() > 0) {
       hasResult = '1';
       
       for (result in dbResult.SelectStatement_response.row) {
           //create unique-key
           def bidKey = result.EVENT_ID + '|'+ result.INVITATION_ID + '|'+ result.BID_ALTERNATE_NAME + '|' + result.ITEM_ID;
           if (!bidKeyList.contains(bidKey)) {
               bidKeyList.add(bidKey)
           }
       }
       
        //log Result
        //def messageLog = messageLogFactory.getMessageLog(message);
        //messageLog.addAttachmentAsString('KeyList-'+count.toString(), bidKeyList.toString(), 'text/plain');
       
    }
    
    //add bidKey list in properties   
   message.setProperty('bidsListInDB', bidKeyList)
    
    return message;
}