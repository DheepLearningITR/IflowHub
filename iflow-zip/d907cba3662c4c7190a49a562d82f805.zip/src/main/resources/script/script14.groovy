import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    def body = message.getBody();
    
    def headers = message.getHeaders();

    def properties = message.getProperties();
    
    def jsonSlurper = new JsonSlurper();
    def dbResult = jsonSlurper.parse(body);
    
    def supInvKeyList = new ArrayList<String>();
    
    if (dbResult && dbResult.SelectStatement_response && 
        dbResult.SelectStatement_response.row && dbResult.SelectStatement_response.row.size() > 0) {
       
       for (result in dbResult.SelectStatement_response.row) {
           //create unique-key
           def siKey = result.EVENT_ID + '|'+ result.SUPPLIER_INVITATION_ID + '|'+ result.SUPPLIER_ORG_ID;
           if (!supInvKeyList.contains(siKey)) {
               supInvKeyList.add(siKey)
           }
       }
       
        //log Result
        //def messageLog = messageLogFactory.getMessageLog(message);
        //messageLog.addAttachmentAsString('KeyList-'+count.toString(), bidKeyList.toString(), 'text/plain');
       
    }
    
    //add bidKey list in properties   
   message.setProperty('supInvListInDB', supInvKeyList)
    
    return message;
}