import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def properties = message.getProperties();
    def count = properties.get('count');
    
    //get Json result
    def jsonSlurper = new JsonSlurper();
    def apiResult = jsonSlurper.parse(body);
    
     // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    //get db Schema
    def db_schema = properties.get('Database_Schema_Name');
    
    def eventHasBidsToInsert = '0';
    
    //bidsListInDB
    def arrExistingBids = properties.get('bidsListInDB');
    
    if (apiResult.payload && apiResult.payload.size() > 0 ) {

        sqlStatement.root {
            for (rfxEventItem in apiResult.payload) {
                
                //skip if is header items
                if (rfxEventItem.itemsWithBid && rfxEventItem.itemsWithBid.size() > 0) {
                    continue;
                }
                
                //valid item with Bid
                if (rfxEventItem.item && rfxEventItem.item.terms && rfxEventItem.item.terms.size() > 0) {
                    
                    //get key from itemsWithBid
                    //rfxEventItem.eventId
                    //rfxEventItem.itemId
                    //rfxEventItem.invitationId
                    //rfxEventItem.alternateBidName
                    
                    // check if the Bid exist in DB
                    def bidExistInDB = false;
                    if (arrExistingBids.size() > 0) {
                        for (dbBid in arrExistingBids) {
                            def dbBidSplit = dbBid.split('\\|');
                            if (dbBidSplit.size() == 4) {
                                def dbEventId = dbBidSplit[0];
                                def dbInvitationId = dbBidSplit[1];
                                def dbAltBidName = dbBidSplit[2];
                                def dbItemId = dbBidSplit[3];
                                
                                // check if is the same
                                if (dbEventId==rfxEventItem.eventId && dbInvitationId==rfxEventItem.invitationId
                                    && dbAltBidName == (rfxEventItem.alternateBidName == null ? ' ' : rfxEventItem.alternateBidName)
                                    && dbItemId == rfxEventItem.itemId) {
                                    bidExistInDB = true;
                                    break;
                                }
                            }
                        }
                        
                        // exit the for and search for other item
                        if (bidExistInDB) {
                            continue;
                        }
                    }
                    
                    //create a new list to avoid the duplicate terms in the API result
                    def termsList = new ArrayList<String>();
                    for (rfxEventItemTerm in rfxEventItem.item.terms) {
                        if (!termsList.contains(rfxEventItemTerm.fieldId)) {
                            termsList.add(rfxEventItemTerm.fieldId);
                            eventHasBidsToInsert ='1';
                            sqlStatement.InsertStatement {
                                sqlStatement.app_sourcing_item_term_bid(action: 'INSERT') {
                                    sqlStatement.table(db_schema + '.APP_SOURCING_ITEM_TERM_BID')
                                    sqlStatement.access {
                                        sqlStatement.ITEM_ID(rfxEventItem.itemId)
                                        sqlStatement.EVENT_ID(rfxEventItem.eventId)
                                        sqlStatement.INVITATION_ID(rfxEventItem.invitationId)
                                        sqlStatement.BID_RANK(rfxEventItem.bidRank)
                                        sqlStatement.BID_TYPE(rfxEventItem.bidType)
                                        sqlStatement.BID_ALTERNATE_NAME(rfxEventItem.alternateBidName != null ? rfxEventItem.alternateBidName : ' ')
                                        
                                        sqlStatement.ITEM_TERM_ID(rfxEventItemTerm.fieldId)
                                        sqlStatement.TITLE(rfxEventItemTerm.title)
                                        sqlStatement.VALUE_TYPE_NAME(rfxEventItemTerm.valueTypeName)
                                        
                                        if ( (rfxEventItemTerm.valueTypeName == 'ShortText' || rfxEventItemTerm.valueTypeName == 'Text' 
                                                    || rfxEventItemTerm.valueTypeName == 'MultilineFreeText' || rfxEventItemTerm.valueTypeName == 'MasterDataType') 
                                                && rfxEventItemTerm.value && rfxEventItemTerm.value.simpleValue) {
                                            sqlStatement.VALUE_STRING(rfxEventItemTerm.value.simpleValue.size()>1000 ? rfxEventItemTerm.value.simpleValue.substring(0,1000) :  rfxEventItemTerm.value.simpleValue)
                                        }
                                        else if ((rfxEventItemTerm.valueTypeName == 'DecimalNumber' || rfxEventItemTerm.valueTypeName == 'Percentage') 
                                                    && rfxEventItemTerm.value) {
                                            sqlStatement.VALUE_AMOUNT(rfxEventItemTerm.value.bigDecimalValue)
                                        }
                                        else if (rfxEventItemTerm.valueTypeName == 'Money' &&  rfxEventItemTerm.value && rfxEventItemTerm.value.supplierValue) {
                                            sqlStatement.VALUE_AMOUNT(rfxEventItemTerm.value.supplierValue.amount)
                                            sqlStatement.VALUE_CURRENCY_CODE(rfxEventItemTerm.value.supplierValue.currency)
                                        }
                                        else if (rfxEventItemTerm.valueTypeName == 'Quantity' && rfxEventItemTerm.value && rfxEventItemTerm.value.quantityValue) {
                                            sqlStatement.VALUE_AMOUNT(rfxEventItemTerm.value.quantityValue.amount)
                                            sqlStatement.UM_NAME(rfxEventItemTerm.value.quantityValue.unitOfMeasureName)
                                            sqlStatement.UM_CODE(rfxEventItemTerm.value.quantityValue.unitOfMeasureCode)
                                        }
                                        else if (rfxEventItemTerm.valueTypeName == 'MoneyDifference' &&  rfxEventItemTerm.value && rfxEventItemTerm.value.moneyDifferenceValue
                                                && rfxEventItemTerm.value.moneyDifferenceValue.difference) {
                                            sqlStatement.VALUE_AMOUNT(rfxEventItemTerm.value.moneyDifferenceValue.difference.amount)
                                            sqlStatement.VALUE_CURRENCY_CODE(rfxEventItemTerm.value.moneyDifferenceValue.difference.currency)
                                        }
                                        
                                        
                                        sqlStatement.CREATEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                                        sqlStatement.CREATEDBY(properties.get('Extension_User'))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        };
    }

    message.setProperty("eventHasBids", eventHasBidsToInsert);
    
    /*if (eventHasBidsToInsert == '1') {
         //log Result
        def messageLog = messageLogFactory.getMessageLog(message);
        messageLog.addAttachmentAsString('Existing Bids-' + count.toString(), arrExistingBids.toString(), 'text/plain');
        messageLog.addAttachmentAsString('apireult-' + count.toString(), apiResult.toString(), 'text/plain');
        messageLog.addAttachmentAsString('writertoDB-' + count.toString(), writer.toString(), 'text/plain');
    }*/
   
   //set body
    message.setBody(writer.toString());
  
    return message;
}