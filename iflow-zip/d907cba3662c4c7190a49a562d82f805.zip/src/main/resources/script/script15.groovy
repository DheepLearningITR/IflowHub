import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.xml.MarkupBuilder;

def Message processData(Message message) {
    def body = message.getBody();

    def headers = message.getHeaders();
    
    def properties = message.getProperties();
    
    //get Json result
    def jsonSlurper = new JsonSlurper();
    def apiResult = jsonSlurper.parse(body);
    
    // create SQL statement
    def writer = new StringWriter();
    def sqlStatement = new MarkupBuilder(writer);
    //get db Schema
    def db_schema = properties.get('Database_Schema_Name');
    def eventId = properties.get('eventId');
    
    def eventHasSIToInsert = '0';
    
    //bidsListInDB
    def arrExistingSI = properties.get('supInvListInDB');
    
    if (apiResult.payload && apiResult.payload.size() > 0 ) {

        sqlStatement.root {
            for (rfxInvitation in apiResult.payload) {
                    
                //get key from itemsWithBid
                //rfxInvitation.eventId
                //rfxInvitation.invitationId
                //rfxInvitation.orgId
                
                // check if the Bid exist in DB
                def siExistInDB = false;
                if (arrExistingSI.size() > 0) {
                    for (dbSI in arrExistingSI) {
                        def dbSISplit = dbSI.split('\\|');
                        if (dbSISplit.size() == 3) {
                            def dbEventId = dbSISplit[0];
                            def dbInvitationId = dbSISplit[1];
                            def dbOrgId = dbSISplit[2];
                            
                            // check if is the same
                            if (dbEventId==eventId && dbInvitationId==rfxInvitation.invitationId
                                && dbOrgId == rfxInvitation.orgId) {
                                siExistInDB = true;
                                break;
                            }
                        }
                    }
                    
                    // exit the for and search for other item
                    if (siExistInDB) {
                        //update Supplier_Has_Bid and Supplier_Has_Status
                        sqlStatement.UpdateStatement {
                            sqlStatement.app_sourcing_supplier_invitation(action: 'UPDATE') {
                                sqlStatement.table(db_schema + '.APP_SOURCING_SUPPLIER_INVITATION')
                                sqlStatement.access {
                                    sqlStatement.SUPPLIER_HAS_BID(rfxInvitation.hasBid)
                                    sqlStatement.SUPPLIER_BID_STATUS(rfxInvitation.supplierBidStatus)
                                    
                                    sqlStatement.MODIFIEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                                    sqlStatement.MODIFIEDBY(properties.get('Extension_User'))
                                }
                                sqlStatement.key {
                                    sqlStatement.EVENT_ID(eventId)
                                    sqlStatement.SUPPLIER_ORG_ID(rfxInvitation.orgId)
                                    sqlStatement.SUPPLIER_INVITATION_ID(rfxInvitation.invitationId)
                                }
                            }
                        }
                        eventHasSIToInsert = '1';
                        continue;
                    }
                }
                
                eventHasSIToInsert = '1';
                sqlStatement.InsertStatement {
                    sqlStatement.app_sourcing_supplier_invitation(action: 'INSERT') {
                        sqlStatement.table(db_schema + '.APP_SOURCING_SUPPLIER_INVITATION')
                        sqlStatement.access {
                            sqlStatement.EVENT_ID(eventId)
                            sqlStatement.SUPPLIER_ORG_ID(rfxInvitation.orgId)
                            if (rfxInvitation.organization) {
                                sqlStatement.SUPPLIER_ORG_NAME(rfxInvitation.organization.name)
                            }
                            sqlStatement.SUPPLIER_INVITATION_ID(rfxInvitation.invitationId)
                            sqlStatement.SUPPLIER_USER_ID(rfxInvitation.userId)
                            sqlStatement.SUPPLIER_HAS_BID(rfxInvitation.hasBid)
                            sqlStatement.SUPPLIER_BID_STATUS(rfxInvitation.supplierBidStatus)
                            
                            sqlStatement.CREATEDAT((new Date()).format('yyyy-MM-dd HH:mm:ss'))
                            sqlStatement.CREATEDBY(properties.get('Extension_User'))
                        }
                    }
                }
            }
        };
    }

    message.setProperty("eventHasSI", eventHasSIToInsert);
    
    /*if (eventHasBidsToInsert == '1') {
         //log Result
        def messageLog = messageLogFactory.getMessageLog(message);
        messageLog.addAttachmentAsString('Existing Bids-' + count.toString(), arrExistingSI.toString(), 'text/plain');
        messageLog.addAttachmentAsString('apireult-' + count.toString(), apiResult.toString(), 'text/plain');
        messageLog.addAttachmentAsString('writertoDB-' + count.toString(), writer.toString(), 'text/plain');
    }*/
   
   //set body
    message.setBody(writer.toString());
  
    return message;
}