import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import java.io.*

//function processInitialData definition
Message processInitialData(Message message) {
    map = message.properties
    property_EnableLogging = map.get('EnableLogging')
    message.setHeader('SAP_IsIgnoreProperties', true)
    //logs if EnableLogging property is set as true
    if (property_EnableLogging.toUpperCase() == 'TRUE') {
        String body = message.getBody(String) as String
        def messageLog = messageLogFactory.getMessageLog(message)
        //file name
        messageLog.addAttachmentAsString('Initial Payload', body, 'text/plain')
    }

    return message
}

//function processNotProcessedPayload definition
Message processNotProcessedPayload(Message message) {
    map = message.properties
    property_EnableLogging = map.get('EnableLogging')
    message.setHeader('SAP_IsIgnoreProperties', true)
    //logs if EnableLogging property is set as true
    if (property_EnableLogging.toUpperCase() == 'TRUE') {
        String body = message.getBody(String) as String
        def messageLog = messageLogFactory.getMessageLog(message)
        //file name
        messageLog.addAttachmentAsString('Not Processed Payload', body, 'text/plain')
    }

    return message
}

def Message processMultimapTag(Message message) {
//get Body
	def body = message.getBody(java.lang.String) as String;
//replaceMultimap tag

    body = body.replace("<root>","")
	body = body.replaceAll("</root>", "")

//set body
	message.setBody(body)

	return message
}

//function processCurrentPayload definition
Message processCurrentPayload(Message message) {
    map = message.properties
    property_EnableLogging = map.get('EnableLogging')
    message.setHeader('SAP_IsIgnoreProperties', true)
    //logs if EnableLogging property is set as true
    if (property_EnableLogging.toUpperCase() == 'TRUE') {
        String body = message.getBody(String) as String
        def messageLog = messageLogFactory.getMessageLog(message)
        //file name
        messageLog.addAttachmentAsString('After Mapping Payload', body, 'text/plain')
    }

    return message
}

//function processAfterMappingERPAccount definition
Message processAfterMappingERPAccount(Message message) {
    map = message.properties
    property_EnableLogging = map.get('EnableLogging')
    message.setHeader('SAP_IsIgnoreProperties', true)
    //logs if EnableLogging property is set as true
    if (property_EnableLogging.toUpperCase() == 'TRUE') {
        String body = message.getBody(String) as String
        def messageLog = messageLogFactory.getMessageLog(message)
        //file name
        messageLog.addAttachmentAsString('After Mapping ERP Account Payload', body, 'text/plain')
    }

    return message
}

//function processAfterMappingERPAccountDetail definition
Message processAfterMappingERPAccountDetail(Message message) {
    map = message.properties
    property_EnableLogging = map.get('EnableLogging')
    message.setHeader('SAP_IsIgnoreProperties', true)
    //logs if EnableLogging property is set as true
    if (property_EnableLogging.toUpperCase() == 'TRUE') {
        String body = message.getBody(String) as String
        def messageLog = messageLogFactory.getMessageLog(message)
        //file name
        messageLog.addAttachmentAsString('After Mapping ERP Account Detail Payload', body, 'text/plain')
    }

    return message
}